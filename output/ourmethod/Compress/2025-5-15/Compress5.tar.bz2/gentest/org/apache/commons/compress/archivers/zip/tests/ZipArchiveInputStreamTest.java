package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                         public void testRead_WhenClosed_ThrowsIOException() throws Exception {
                                                                                                                                                             // Create a mock input stream
                                                                                                                                                             InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                                             
                                                                                                                                                             // Set closed field to true using reflection
                                                                                                                                                             Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                             closedField.setAccessible(true);
                                                                                                                                                             closedField.setBoolean(zais, true);
                                                                                                                                                             
                                                                                                                                                             // Set up expected exception
                                                                                                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                             expectedException.expect(IOException.class);
                                                                                                                                                             expectedException.expectMessage("The stream is closed");
                                                                                                                                                             
                                                                                                                                                             // Perform the test
                                                                                                                                                             zais.read(new byte[10], 0, 10);
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_WhenFinishedOrNullEntry_ReturnsMinusOne() throws Exception {
                                                                                                                                                             // Create a mock input stream
                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                             // Create the ZipArchiveInputStream to test
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                             
                                                                                                                                                             // Create mock objects
                                                                                                                                                             ZipArchiveEntry mockEntry = new ZipArchiveEntry("test");
                                                                                                                                                             Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                             
                                                                                                                                                             // Set current to null and test
                                                                                                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             currentField.setAccessible(true);
                                                                                                                                                             currentField.set(zais, null);
                                                                                                                                                             
                                                                                                                                                             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                             infField.setAccessible(true);
                                                                                                                                                             infField.set(zais, mockInflater);
                                                                                                                                                             
                                                                                                                                                             assertEquals(-1, zais.read(new byte[10], 0, 10));
                                                                                                                                                             
                                                                                                                                                             // Set current to mockEntry and mock finished=true
                                                                                                                                                             when(mockInflater.finished()).thenReturn(true);
                                                                                                                                                             currentField.set(zais, mockEntry);
                                                                                                                                                             assertEquals(-1, zais.read(new byte[10], 0, 10));
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_WithInvalidBufferParameters_ThrowsArrayIndexOutOfBounds() throws Exception {
                                                                                                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                             expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                             
                                                                                                                                                             // Create a mock input stream that will never provide data
                                                                                                                                                             InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                             try (ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput)) {
                                                                                                                                                                 // Test various invalid buffer scenarios
                                                                                                                                                                 zais.read(new byte[10], -1, 5);  // negative start
                                                                                                                                                                 zais.read(new byte[10], 0, -1);  // negative length
                                                                                                                                                                 zais.read(new byte[10], 8, 5);   // start + length > buffer.length
                                                                                                                                                             }
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_StoredMethod_WhenAllBytesRead_ReturnsMinusOne() throws Exception {
                                                                                                                                                             // Setup mock entry
                                                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                             when(mockEntry.getSize()).thenReturn(100L);
                                                                                                                                                             
                                                                                                                                                             // Setup mock input stream that returns -1 (EOF)
                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                             when(mockInputStream.read(any(byte[].class))).thenReturn(-1);
                                                                                                                                                             
                                                                                                                                                             // Create real ZipArchiveInputStream with mock input
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                             
                                                                                                                                                             // Set current entry and readBytesOfEntry via reflection
                                                                                                                                                             Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                             currentEntryField.set(zais, mockEntry);
                                                                                                                                                             
                                                                                                                                                             Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                                             readBytesField.setAccessible(true);
                                                                                                                                                             readBytesField.set(zais, 100L);
                                                                                                                                                             
                                                                                                                                                             assertEquals(-1, zais.read(new byte[10], 0, 10));
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_StoredMethod_ReadsDataCorrectly() throws Exception {
                                                                                                                                                             // Setup mock objects
                                                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                             when(mockEntry.getSize()).thenReturn(100L);
                                                                                                                                                             
                                                                                                                                                             // Initialize input stream with empty input
                                                                                                                                                             ByteArrayInputStream emptyInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(emptyInput);
                                                                                                                                                             
                                                                                                                                                             // Set private fields using reflection
                                                                                                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             currentField.setAccessible(true);
                                                                                                                                                             currentField.set(zais, mockEntry);
                                                                                                                                                             
                                                                                                                                                             Field readBytesOfEntryField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                                             readBytesOfEntryField.setAccessible(true);
                                                                                                                                                             readBytesOfEntryField.set(zais, 0);
                                                                                                                                                             
                                                                                                                                                             Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                             lengthOfLastReadField.setAccessible(true);
                                                                                                                                                             lengthOfLastReadField.set(zais, 10);
                                                                                                                                                             
                                                                                                                                                             Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                                                                                             bufField.setAccessible(true);
                                                                                                                                                             bufField.set(zais, new byte[]{1,2,3,4,5,6,7,8,9,10});
                                                                                                                                                             
                                                                                                                                                             // Test the read operation
                                                                                                                                                             byte[] buffer = new byte[10];
                                                                                                                                                             int read = zais.read(buffer, 0, 10);
                                                                                                                                                             
                                                                                                                                                             // Verify results
                                                                                                                                                             assertEquals(10, read);
                                                                                                                                                             assertArrayEquals(new byte[]{1,2,3,4,5,6,7,8,9,10}, buffer);
                                                                                                                                                             assertEquals(10, readBytesOfEntryField.get(zais));
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_StoredMethod_WithPartialRead() throws Exception {
                                                                                                                                                             // Setup mock objects
                                                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                             when(mockInputStream.read(any(byte[].class))).thenReturn(-1); // EOF
                                                                                                                                                             
                                                                                                                                                             // Create real ZipArchiveInputStream with mock input
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                             
                                                                                                                                                             // Helper method to set private field
                                                                                                                                                             Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                                             readBytesField.setAccessible(true);
                                                                                                                                                             readBytesField.set(zais, 95);
                                                                                                                                                             
                                                                                                                                                             Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                             lengthOfLastReadField.setAccessible(true);
                                                                                                                                                             lengthOfLastReadField.set(zais, 10);
                                                                                                                                                             
                                                                                                                                                             Field offsetInBufferField = ZipArchiveInputStream.class.getDeclaredField("offsetInBuffer");
                                                                                                                                                             offsetInBufferField.setAccessible(true);
                                                                                                                                                             offsetInBufferField.set(zais, 0);
                                                                                                                                                             
                                                                                                                                                             Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                                                                                             bufField.setAccessible(true);
                                                                                                                                                             bufField.set(zais, new byte[]{1,2,3,4,5,6,7,8,9,10});
                                                                                                                                                             
                                                                                                                                                             // Set current entry via reflection
                                                                                                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             currentField.setAccessible(true);
                                                                                                                                                             currentField.set(zais, mockEntry);
                                                                                                                                                             
                                                                                                                                                             // Configure mock entry
                                                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                             when(mockEntry.getSize()).thenReturn(100L);
                                                                                                                                                             
                                                                                                                                                             // Test read operation
                                                                                                                                                             byte[] buffer = new byte[10];
                                                                                                                                                             int read = zais.read(buffer, 0, 10);
                                                                                                                                                             
                                                                                                                                                             // Verify results
                                                                                                                                                             assertEquals(5, read);  // Only 5 bytes left in entry
                                                                                                                                                             assertArrayEquals(new byte[]{1,2,3,4,5,0,0,0,0,0}, buffer);
                                                                                                                                                             assertEquals(100, readBytesField.get(zais));
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_DeflatedMethod_NeedsInput() throws Exception {
                                                                                                                                                             // Create mock objects
                                                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                             Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                             
                                                                                                                                                             // Create real input stream with empty input
                                                                                                                                                             ByteArrayInputStream emptyInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(emptyInput);
                                                                                                                                                             
                                                                                                                                                             // Set up mocks
                                                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                             when(mockInflater.needsInput()).thenReturn(true);
                                                                                                                                                             
                                                                                                                                                             // Set private fields using reflection
                                                                                                                                                             Field entryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             entryField.setAccessible(true);
                                                                                                                                                             entryField.set(zais, mockEntry);
                                                                                                                                                             
                                                                                                                                                             Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                             inflaterField.setAccessible(true);
                                                                                                                                                             inflaterField.set(zais, mockInflater);
                                                                                                                                                             
                                                                                                                                                             Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                             lengthField.setAccessible(true);
                                                                                                                                                             lengthField.set(zais, 10);
                                                                                                                                                             
                                                                                                                                                             when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                             
                                                                                                                                                             byte[] buffer = new byte[10];
                                                                                                                                                             int read = zais.read(buffer, 0, 10);
                                                                                                                                                             
                                                                                                                                                             assertEquals(5, read);
                                                                                                                                                             
                                                                                                                                                             Field bytesReadField = ZipArchiveInputStream.class.getDeclaredField("bytesReadFromStream");
                                                                                                                                                             bytesReadField.setAccessible(true);
                                                                                                                                                             assertEquals(10, bytesReadField.get(zais));
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_DeflatedMethod_Finished() throws Exception {
                                                                                                                                                             // Create mock objects
                                                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                             Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                             
                                                                                                                                                             // Create real object with mocked dependencies
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to inject mocks into private fields
                                                                                                                                                             Field entryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             entryField.setAccessible(true);
                                                                                                                                                             entryField.set(zais, mockEntry);
                                                                                                                                                             
                                                                                                                                                             Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                             inflaterField.setAccessible(true);
                                                                                                                                                             inflaterField.set(zais, mockInflater);
                                                                                                                                                             
                                                                                                                                                             // Setup mock behavior
                                                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                             when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                             when(mockInflater.finished()).thenReturn(true);
                                                                                                                                                             when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                                             
                                                                                                                                                             // Test
                                                                                                                                                             assertEquals(-1, zais.read(new byte[10], 0, 10));
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_DeflatedMethod_SuccessfulRead() throws Exception {
                                                                                                                                                             // Create mock objects
                                                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                             Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                             
                                                                                                                                                             // Create real ZipArchiveInputStream
                                                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to inject our mocks into the real object
                                                                                                                                                             Field entryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                             entryField.setAccessible(true);
                                                                                                                                                             entryField.set(zais, mockEntry);
                                                                                                                                                             
                                                                                                                                                             Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                             inflaterField.setAccessible(true);
                                                                                                                                                             inflaterField.set(zais, mockInflater);
                                                                                                                                                             
                                                                                                                                                             // Set up mock behavior
                                                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                             when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                             when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5);
                                                                                                                                                             
                                                                                                                                                             // Test the read operation
                                                                                                                                                             byte[] buffer = new byte[10];
                                                                                                                                                             int read = zais.read(buffer, 0, 10);
                                                                                                                                                             
                                                                                                                                                             assertEquals(5, read);
                                                                                                                                                             // Verify CRC was updated (would need to mock CRC32 to verify this)
                                                                                                                                                         }

 @Test
                                                                                                                                                     public void testRead_DeflatedMethod_ThrowsDataFormatException() throws Exception {
                                                                                                                                                         // Setup expected exception rule
                                                                                                                                                         ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                         
                                                                                                                                                         // Setup mocks
                                                                                                                                                         ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                         Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                         
                                                                                                                                                         // Create ZipArchiveInputStream with mock input stream
                                                                                                                                                         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to inject our mocks since they're private fields
                                                                                                                                                         Field entryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                         entryField.setAccessible(true);
                                                                                                                                                         entryField.set(zais, mockEntry);
                                                                                                                                                         
                                                                                                                                                         Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                         inflaterField.setAccessible(true);
                                                                                                                                                         inflaterField.set(zais, mockInflater);
                                                                                                                                                         
                                                                                                                                                         // Configure mocks
                                                                                                                                                         when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                         when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                         
                                                                                                                                                         DataFormatException dfe = new DataFormatException("Bad data");
                                                                                                                                                         when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenThrow(dfe);
                                                                                                                                                         
                                                                                                                                                         // Expected exception
                                                                                                                                                         expectedException.expect(ZipException.class);
                                                                                                                                                         expectedException.expectMessage(dfe.getMessage());
                                                                                                                                                         
                                                                                                                                                         // Test
                                                                                                                                                         zais.read(new byte[10], 0, 10);
                                                                                                                                                     }

 @Test
                                                                                                                                                     public void testRead_DeflatedMethod_TruncatedZipFile() throws Exception {
                                                                                                                                                         // Create mock objects
                                                                                                                                                         ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                         Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                         InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                         
                                                                                                                                                         // Create real ZipArchiveInputStream with mock input stream
                                                                                                                                                         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                         
                                                                                                                                                         // Set up mock behavior
                                                                                                                                                         when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                         when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                         when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to set private fields
                                                                                                                                                         Field entryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                         entryField.setAccessible(true);
                                                                                                                                                         entryField.set(zais, mockEntry);
                                                                                                                                                         
                                                                                                                                                         Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                         inflaterField.setAccessible(true);
                                                                                                                                                         inflaterField.set(zais, mockInflater);
                                                                                                                                                         
                                                                                                                                                         Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                         lengthField.setAccessible(true);
                                                                                                                                                         lengthField.set(zais, -1);
                                                                                                                                                         
                                                                                                                                                         // Set up expected exception
                                                                                                                                                         try {
                                                                                                                                                             // Test the read method
                                                                                                                                                             zais.read(new byte[10], 0, 10);
                                                                                                                                                             fail("Expected IOException for truncated ZIP file");
                                                                                                                                                         } catch (IOException e) {
                                                                                                                                                             assertEquals("Truncated ZIP file", e.getMessage());
                                                                                                                                                         }
                                                                                                                                                     }

 @Test(expected = RuntimeException.class)
                                                                                                                                                 public void testReadShouldNotCatchGenericException() throws Exception {
                                                                                                                                                     // Setup
                                                                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                     Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                     
                                                                                                                                                     // Create test instance using reflection since constructor may need setup
                                                                                                                                                     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                     
                                                                                                                                                     // Set internal state via reflection
                                                                                                                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                     infField.setAccessible(true);
                                                                                                                                                     infField.set(zais, mockInflater);
                                                                                                                                                     
                                                                                                                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                     currentField.setAccessible(true);
                                                                                                                                                     currentField.set(zais, mockEntry);
                                                                                                                                                     
                                                                                                                                                     Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                     closedField.setAccessible(true);
                                                                                                                                                     closedField.set(zais, false);
                                                                                                                                                     
                                                                                                                                                     // Mock behavior
                                                                                                                                                     when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                     when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                     
                                                                                                                                                     // Make inflate throw RuntimeException instead of DataFormatException
                                                                                                                                                     doThrow(new RuntimeException("Test exception"))
                                                                                                                                                         .when(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                     
                                                                                                                                                     // Test - should throw the RuntimeException directly
                                                                                                                                                     byte[] buffer = new byte[10];
                                                                                                                                                     zais.read(buffer, 0, 10);
                                                                                                                                                     
                                                                                                                                                     // If we get here, the test fails (exception wasn't thrown)
                                                                                                                                                     fail("Expected RuntimeException to be thrown");
                                                                                                                                                 }

 @Test(expected = ZipException.class)
                                                                                                                                                public void testRead_ThrowsZipExceptionWhenDataFormatExceptionOccurs() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                    Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                    
                                                                                                                                                    // Create test instance using reflection since constructor may need setup
                                                                                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                    
                                                                                                                                                    // Set up internal state
                                                                                                                                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                    infField.setAccessible(true);
                                                                                                                                                    infField.set(zais, mockInflater);
                                                                                                                                                    
                                                                                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                    currentField.setAccessible(true);
                                                                                                                                                    currentField.set(zais, mockEntry);
                                                                                                                                                    
                                                                                                                                                    Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                    closedField.setAccessible(true);
                                                                                                                                                    closedField.set(zais, false);
                                                                                                                                                    
                                                                                                                                                    // Mock behavior
                                                                                                                                                    when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                    when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                    doThrow(new DataFormatException("test")).when(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                    
                                                                                                                                                    // Test - should throw ZipException
                                                                                                                                                    byte[] buffer = new byte[10];
                                                                                                                                                    zais.read(buffer, 0, 10);
                                                                                                                                                    
                                                                                                                                                    // Verification is done via expected exception in @Test annotation
                                                                                                                                                }

 @Test
                                                                                                                                              public void testRead_DataFormatException_ShouldThrowWithOriginalMessage() throws Exception {
                                                                                                                                                  // Setup
                                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                  Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                  
                                                                                                                                                  // Create test instance
                                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                  
                                                                                                                                                  // Mock behavior to reach the inflation code path
                                                                                                                                                  when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                  
                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                  currentField.setAccessible(true);
                                                                                                                                                  currentField.set(zais, mockEntry);
                                                                                                                                                  
                                                                                                                                                  Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                  closedField.setAccessible(true);
                                                                                                                                                  closedField.set(zais, false);
                                                                                                                                                  
                                                                                                                                                  Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                  lengthField.setAccessible(true);
                                                                                                                                                  lengthField.set(zais, 1); // Ensure we don't hit early return
                                                                                                                                                  
                                                                                                                                                  // Mock inflater to throw DataFormatException
                                                                                                                                                  when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                  when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                      .thenThrow(new DataFormatException("Invalid data format"));
                                                                                                                                                  
                                                                                                                                                  // Replace real inflater with mock
                                                                                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                  infField.setAccessible(true);
                                                                                                                                                  infField.set(zais, mockInflater);
                                                                                                                                                  
                                                                                                                                                  // Prepare test buffer
                                                                                                                                                  byte[] buffer = new byte[10];
                                                                                                                                                  
                                                                                                                                                  try {
                                                                                                                                                      // Act - should throw ZipException
                                                                                                                                                      zais.read(buffer, 0, 10);
                                                                                                                                                  } catch (ZipException e) {
                                                                                                                                                      // Assert exception message contains original DataFormatException message
                                                                                                                                                      assertTrue("Exception message should contain original DataFormatException message", 
                                                                                                                                                                e.getMessage().contains("Invalid data format"));
                                                                                                                                                      throw e;
                                                                                                                                                  }
                                                                                                                                                  
                                                                                                                                                  fail("Expected ZipException to be thrown");
                                                                                                                                              }

 @Test(expected = ZipException.class)
                                                                                                                                          public void testRead_ThrowsZipExceptionWhenDataFormatExceptionOccurs1() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                              Inflater mockInflater = mock(Inflater.class);
                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                              
                                                                                                                                              // Create test instance using reflection to inject mocks
                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                              
                                                                                                                                              // Set current entry (non-STORED method)
                                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                              currentField.setAccessible(true);
                                                                                                                                              currentField.set(zais, mockEntry);
                                                                                                                                              
                                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                              
                                                                                                                                              // Inject mock inflater
                                                                                                                                              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                              infField.setAccessible(true);
                                                                                                                                              infField.set(zais, mockInflater);
                                                                                                                                              
                                                                                                                                              // Setup inflater to throw DataFormatException
                                                                                                                                              when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                              doThrow(new DataFormatException("test")).when(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                                              
                                                                                                                                              // Prepare valid buffer
                                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                                              
                                                                                                                                              // This should throw ZipException (original behavior)
                                                                                                                                              // If mutant is present, it will throw RuntimeException instead
                                                                                                                                              zais.read(buffer, 0, 10);
                                                                                                                                          }

 @Test
                                                                                                                                        public void testReadWithInflaterNegativeReturnShouldNotTriggerFinishedCheck() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            InputStream inputStream = mock(InputStream.class);
                                                                                                                                            ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream);
                                                                                                                                            ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                            
                                                                                                                                            // Mock entry to use DEFLATED method
                                                                                                                                            when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                            
                                                                                                                                            // Use reflection to set private fields since we need to test internal behavior
                                                                                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                            currentField.setAccessible(true);
                                                                                                                                            currentField.set(zis, entry);
                                                                                                                                            
                                                                                                                                            Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                            infField.setAccessible(true);
                                                                                                                                            Inflater inf = mock(Inflater.class);
                                                                                                                                            infField.set(zis, inf);
                                                                                                                                            
                                                                                                                                            // Mock inflater to return -1 (error case)
                                                                                                                                            when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                            
                                                                                                                                            // Prepare buffer
                                                                                                                                            byte[] buffer = new byte[10];
                                                                                                                                            
                                                                                                                                            // Test - should not throw exception or return -1 just because inflate returned -1
                                                                                                                                            // The original code would proceed normally with negative return values
                                                                                                                                            // The mutant would incorrectly enter the finished/truncated check branch
                                                                                                                                            int result = zis.read(buffer, 0, 10);
                                                                                                                                            
                                                                                                                                            // Verify
                                                                                                                                            assertNotEquals("Should not return -1 for negative inflate return", -1, result);
                                                                                                                                            verify(inf, times(1)).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                                            
                                                                                                                                            // Additional test case for read=0
                                                                                                                                            when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                            when(inf.finished()).thenReturn(false);
                                                                                                                                            
                                                                                                                                            // Use reflection to set lengthOfLastRead field
                                                                                                                                            Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                            lengthOfLastReadField.setAccessible(true);
                                                                                                                                            lengthOfLastReadField.set(zis, 10); // Not -1
                                                                                                                                            
                                                                                                                                            result = zis.read(buffer, 0, 10);
                                                                                                                                            assertEquals("Should return -1 only when finished", -1, result);
                                                                                                                                        }

 @Test
                                                                                                                                    public void testReadWithZeroInflateResult() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        InputStream mockInput = mock(InputStream.class);
                                                                                                                                        Inflater mockInf = mock(Inflater.class);
                                                                                                                                        CRC32 mockCrc = mock(CRC32.class);
                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                        entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                        
                                                                                                                                        // Create instance using reflection to inject mocks
                                                                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                        Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                        infField.setAccessible(true);
                                                                                                                                        infField.set(zais, mockInf);
                                                                                                                                        
                                                                                                                                        Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                                        crcField.setAccessible(true);
                                                                                                                                        crcField.set(zais, mockCrc);
                                                                                                                                        
                                                                                                                                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                        currentField.setAccessible(true);
                                                                                                                                        currentField.set(zais, entry);
                                                                                                                                        
                                                                                                                                        Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                                                                        bufField.setAccessible(true);
                                                                                                                                        bufField.set(zais, new byte[1024]);
                                                                                                                                        
                                                                                                                                        // Case 1: inflate returns 0 but not finished
                                                                                                                                        when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                        when(mockInf.finished()).thenReturn(false);
                                                                                                                                        when(mockInf.needsInput()).thenReturn(false);
                                                                                                                                        
                                                                                                                                        byte[] buffer = new byte[10];
                                                                                                                                        assertEquals(0, zais.read(buffer, 0, 10)); // Should return 0, not -1
                                                                                                                                        
                                                                                                                                        // Case 2: inflate returns 0 and finished
                                                                                                                                        when(mockInf.finished()).thenReturn(true);
                                                                                                                                        assertEquals(-1, zais.read(buffer, 0, 10)); // Should return -1
                                                                                                                                        
                                                                                                                                        // Case 3: inflate returns 0 with truncated file
                                                                                                                                        Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                        lengthOfLastReadField.setAccessible(true);
                                                                                                                                        lengthOfLastReadField.set(zais, -1);
                                                                                                                                        
                                                                                                                                        when(mockInf.finished()).thenReturn(false);
                                                                                                                                        try {
                                                                                                                                            zais.read(buffer, 0, 10);
                                                                                                                                            fail("Should have thrown IOException");
                                                                                                                                        } catch (IOException e) {
                                                                                                                                            assertEquals("Truncated ZIP file", e.getMessage());
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Verify CRC was updated for successful reads
                                                                                                                                        verify(mockCrc, times(1)).update(any(byte[].class), anyInt(), anyInt());
                                                                                                                                    }

 @Test
                                                                                                                                   public void testReadWhenInflaterReturnsZeroButNotFinished() throws Exception {
                                                                                                                                       // Setup
                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                       Inflater mockInflater = mock(Inflater.class);
                                                                                                                                       ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                       
                                                                                                                                       // Create test instance using reflection to inject mocks
                                                                                                                                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                       Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                       infField.setAccessible(true);
                                                                                                                                       infField.set(zais, mockInflater);
                                                                                                                                       
                                                                                                                                       Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                       currentField.setAccessible(true);
                                                                                                                                       currentField.set(zais, mockEntry);
                                                                                                                                       
                                                                                                                                       Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                       lengthOfLastReadField.setAccessible(true);
                                                                                                                                       lengthOfLastReadField.set(zais, 1); // Indicates there's still data
                                                                                                                                       
                                                                                                                                       // Mock behavior
                                                                                                                                       when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                       when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                       when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                       when(mockInflater.finished()).thenReturn(false);
                                                                                                                                       
                                                                                                                                       // Test
                                                                                                                                       byte[] buffer = new byte[10];
                                                                                                                                       int result = zais.read(buffer, 0, 10);
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       // Original code would continue, mutant would enter the if block and potentially return -1 or throw
                                                                                                                                       assertNotEquals(-1, result); // Should not return -1 when inflater returns 0 but isn't finished
                                                                                                                                       verify(mockInflater, never()).finished(); // In original code, finished() check wouldn't happen when read=0
                                                                                                                                   }

 @Test
                                                                                                                                  public void testRead_ShouldNotReturnNegativeOneWhenInflateReturnsNegativeOne() throws Exception {
                                                                                                                                      // Arrange
                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                      Inflater mockInflater = mock(Inflater.class);
                                                                                                                                      ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                      
                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                      
                                                                                                                                      // Use reflection to set private fields since we need to test specific conditions
                                                                                                                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                      infField.setAccessible(true);
                                                                                                                                      infField.set(zais, mockInflater);
                                                                                                                                      
                                                                                                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                      currentField.setAccessible(true);
                                                                                                                                      currentField.set(zais, mockEntry);
                                                                                                                                      
                                                                                                                                      Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                                                                      bufField.setAccessible(true);
                                                                                                                                      bufField.set(zais, new byte[1024]);
                                                                                                                                      
                                                                                                                                      // Setup mock behavior
                                                                                                                                      when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                      when(mockInflater.finished()).thenReturn(false);
                                                                                                                                      when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                          .thenReturn(-1); // This is the key condition we're testing
                                                                                                                                      
                                                                                                                                      // Act
                                                                                                                                      byte[] buffer = new byte[1024];
                                                                                                                                      int result = zais.read(buffer, 0, 1024);
                                                                                                                                      
                                                                                                                                      // Assert
                                                                                                                                      // Original behavior should throw IOException when inflate returns -1
                                                                                                                                      // Mutant would return -1 instead
                                                                                                                                      assertNotEquals("Method should not return -1 when inflate returns -1", -1, result);
                                                                                                                                      // Alternatively, we could expect an exception
                                                                                                                                  }

 @Test
                                                                                                                                 public void testReadReturnsMinusOneWhenInflaterFinished() throws Exception {
                                                                                                                                     // Setup
                                                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                     Inflater mockInflater = mock(Inflater.class);
                                                                                                                                     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                     
                                                                                                                                     // Create test instance using reflection to inject mocks
                                                                                                                                     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                     
                                                                                                                                     // Set up mocks
                                                                                                                                     when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                     when(mockInflater.finished()).thenReturn(true);  // Inflater reports it's finished
                                                                                                                                     when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                     
                                                                                                                                     // Inject mocks into private fields
                                                                                                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                     infField.setAccessible(true);
                                                                                                                                     infField.set(zais, mockInflater);
                                                                                                                                     
                                                                                                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                     currentField.setAccessible(true);
                                                                                                                                     currentField.set(zais, mockEntry);
                                                                                                                                     
                                                                                                                                     Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                                                                     bufField.setAccessible(true);
                                                                                                                                     bufField.set(zais, new byte[1024]);
                                                                                                                                     
                                                                                                                                     // Test
                                                                                                                                     byte[] buffer = new byte[1024];
                                                                                                                                     int result = zais.read(buffer, 0, 1024);
                                                                                                                                     
                                                                                                                                     // Verify
                                                                                                                                     assertEquals("Should return -1 when inflater is finished", -1, result);
                                                                                                                                 }

 @Test
                                                                                                                                public void testReadStoredMethodWhenEntryFullyRead() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    InputStream mockIn = mock(InputStream.class);
                                                                                                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                    
                                                                                                                                    // Create test instance
                                                                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                                    
                                                                                                                                    // Set up state using reflection since fields are private
                                                                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                    currentField.setAccessible(true);
                                                                                                                                    currentField.set(zais, mockEntry);
                                                                                                                                    
                                                                                                                                    Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                    readBytesField.setAccessible(true);
                                                                                                                                    readBytesField.set(zais, 100); // Set to value >= csize
                                                                                                                                    
                                                                                                                                    Field methodField = ZipArchiveEntry.class.getDeclaredField("method");
                                                                                                                                    methodField.setAccessible(true);
                                                                                                                                    methodField.set(mockEntry, ZipArchiveOutputStream.STORED);
                                                                                                                                    
                                                                                                                                    Field sizeField = ZipArchiveEntry.class.getDeclaredField("size");
                                                                                                                                    sizeField.setAccessible(true);
                                                                                                                                    sizeField.set(mockEntry, 100L); // Set csize to 100
                                                                                                                                    
                                                                                                                                    // Test buffer
                                                                                                                                    byte[] buffer = new byte[1024];
                                                                                                                                    
                                                                                                                                    // Test - should return -1 when readBytesOfEntry >= csize
                                                                                                                                    int result = zais.read(buffer, 0, 100);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals("Should return -1 when entry fully read", -1, result);
                                                                                                                                }

 @Test
                                                                                                                               public void testRead_StoredEntry_WhenReadBytesExceedEntrySize_ShouldReturnMinusOne() throws Exception {
                                                                                                                                   // Arrange
                                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                   ZipArchiveEntry storedEntry = mock(ZipArchiveEntry.class);
                                                                                                                                   when(storedEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                   when(storedEntry.getSize()).thenReturn(100L); // csize = 100
                                                                                                                                   
                                                                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                   
                                                                                                                                   // Use reflection to set private fields since we need to test internal state
                                                                                                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                   currentField.setAccessible(true);
                                                                                                                                   currentField.set(zais, storedEntry);
                                                                                                                                   
                                                                                                                                   Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                   readBytesField.setAccessible(true);
                                                                                                                                   readBytesField.set(zais, 100); // readBytesOfEntry = csize
                                                                                                                                   
                                                                                                                                   Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                   closedField.setAccessible(true);
                                                                                                                                   closedField.set(zais, false);
                                                                                                                                   
                                                                                                                                   // Act
                                                                                                                                   byte[] buffer = new byte[10];
                                                                                                                                   int result = zais.read(buffer, 0, 10);
                                                                                                                                   
                                                                                                                                   // Assert
                                                                                                                                   assertEquals("Should return -1 when readBytesOfEntry >= csize", -1, result);
                                                                                                                               }

 @Test
                                                                                                                              public void testRead_DeflatedEntryWithZeroLengthRead_ShouldNotThrowException() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                                                  Inflater mockInf = mock(Inflater.class);
                                                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                  entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                  
                                                                                                                                  // Create test instance using reflection to inject mocks
                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                  infField.setAccessible(true);
                                                                                                                                  infField.set(zais, mockInf);
                                                                                                                                  
                                                                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                  currentField.setAccessible(true);
                                                                                                                                  currentField.set(zais, entry);
                                                                                                                                  
                                                                                                                                  Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                  lengthOfLastReadField.setAccessible(true);
                                                                                                                                  lengthOfLastReadField.set(zais, 0); // Critical value for this test
                                                                                                                                  
                                                                                                                                  // Mock behavior
                                                                                                                                  when(mockInf.needsInput()).thenReturn(true);
                                                                                                                                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                  when(mockInput.read(any(byte[].class))).thenReturn(0);
                                                                                                                                  
                                                                                                                                  // Test
                                                                                                                                  byte[] buffer = new byte[1024];
                                                                                                                                  int read = zais.read(buffer, 0, 1024);
                                                                                                                                  
                                                                                                                                  // Verify - should not throw exception and return -1
                                                                                                                                  assertEquals(-1, read);
                                                                                                                                  
                                                                                                                                  // Additional verification to ensure we hit the right path
                                                                                                                                  verify(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                              }

 @Test
                                                                                                                             public void testRead_ShouldNotThrowWhenReadZeroButStreamNotFinished() throws Exception {
                                                                                                                                 // Setup
                                                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                                                 Inflater mockInf = mock(Inflater.class);
                                                                                                                                 ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                 
                                                                                                                                 // Create test instance using reflection to inject mocks
                                                                                                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                 Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                 infField.setAccessible(true);
                                                                                                                                 infField.set(zais, mockInf);
                                                                                                                                 
                                                                                                                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                 currentField.setAccessible(true);
                                                                                                                                 currentField.set(zais, mockEntry);
                                                                                                                                 
                                                                                                                                 Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                 lengthOfLastReadField.setAccessible(true);
                                                                                                                                 lengthOfLastReadField.set(zais, 0); // Not -1
                                                                                                                                 
                                                                                                                                 // Mock behavior
                                                                                                                                 when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                 when(mockInf.needsInput()).thenReturn(true);
                                                                                                                                 when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                 when(mockInf.finished()).thenReturn(false);
                                                                                                                                 
                                                                                                                                 // Test - should not throw exception
                                                                                                                                 byte[] buffer = new byte[10];
                                                                                                                                 int result = zais.read(buffer, 0, 10);
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 assertEquals(0, result); // Expect normal continuation
                                                                                                                                 verify(mockInf).inflate(buffer, 0, 10);
                                                                                                                             }

 @Test(expected = IOException.class)
                                                                                                                            public void testRead_ThrowsIOExceptionWhenTruncatedZipFile() throws Exception {
                                                                                                                                // Setup
                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                Inflater mockInflater = mock(Inflater.class);
                                                                                                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                
                                                                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                
                                                                                                                                // Use reflection to set private fields since we need to control test conditions
                                                                                                                                Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                infField.setAccessible(true);
                                                                                                                                infField.set(zais, mockInflater);
                                                                                                                                
                                                                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                currentField.setAccessible(true);
                                                                                                                                currentField.set(zais, mockEntry);
                                                                                                                                
                                                                                                                                Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                lengthOfLastReadField.setAccessible(true);
                                                                                                                                lengthOfLastReadField.set(zais, -1);
                                                                                                                                
                                                                                                                                // Mock behavior
                                                                                                                                when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                when(mockInflater.finished()).thenReturn(false);
                                                                                                                                
                                                                                                                                // Test - should throw IOException for truncated ZIP file
                                                                                                                                byte[] buffer = new byte[1024];
                                                                                                                                zais.read(buffer, 0, buffer.length);
                                                                                                                                
                                                                                                                                // Verification is handled by expected exception in @Test annotation
                                                                                                                            }

 @Test(expected = IOException.class)
                                                                                                                           public void testRead_ThrowsCorrectExceptionForTruncatedZipFile() throws Exception {
                                                                                                                               // Setup
                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                               Inflater mockInf = mock(Inflater.class);
                                                                                                                               CRC32 mockCrc = mock(CRC32.class);
                                                                                                                               ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                               
                                                                                                                               // Create instance using reflection to inject mocks
                                                                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                               
                                                                                                                               // Set private fields using reflection
                                                                                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                               infField.setAccessible(true);
                                                                                                                               infField.set(zais, mockInf);
                                                                                                                               
                                                                                                                               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                               crcField.setAccessible(true);
                                                                                                                               crcField.set(zais, mockCrc);
                                                                                                                               
                                                                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                               currentField.setAccessible(true);
                                                                                                                               currentField.set(zais, mockEntry);
                                                                                                                               
                                                                                                                               Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                               lengthOfLastReadField.setAccessible(true);
                                                                                                                               lengthOfLastReadField.set(zais, -1);
                                                                                                                               
                                                                                                                               // Mock behavior
                                                                                                                               when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                               when(mockInf.finished()).thenReturn(false);
                                                                                                                               
                                                                                                                               // Test
                                                                                                                               try {
                                                                                                                                   zais.read(new byte[10], 0, 10);
                                                                                                                               } catch (IOException e) {
                                                                                                                                   assertEquals("Truncated ZIP file", e.getMessage());
                                                                                                                                   throw e;
                                                                                                                               }
                                                                                                                           }

 @Test(expected = IOException.class)
                                                                                                                          public void testRead_DetectsTruncatedZipFile() throws Exception {
                                                                                                                              // Arrange
                                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                                              Inflater mockInf = mock(Inflater.class);
                                                                                                                              CRC32 mockCrc = mock(CRC32.class);
                                                                                                                              
                                                                                                                              ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                                              
                                                                                                                              // Use reflection to set private fields to reach the mutation point
                                                                                                                              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                              infField.setAccessible(true);
                                                                                                                              infField.set(zis, mockInf);
                                                                                                                              
                                                                                                                              Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                              crcField.setAccessible(true);
                                                                                                                              crcField.set(zis, mockCrc);
                                                                                                                              
                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                              currentField.setAccessible(true);
                                                                                                                              currentField.set(zis, new ZipArchiveEntry("test"));
                                                                                                                              
                                                                                                                              Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                              lengthOfLastReadField.setAccessible(true);
                                                                                                                              lengthOfLastReadField.set(zis, -1);
                                                                                                                              
                                                                                                                              // Mock behavior
                                                                                                                              when(mockInf.finished()).thenReturn(false);
                                                                                                                              when(mockInf.needsInput()).thenReturn(false);
                                                                                                                              when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                              
                                                                                                                              // Act - should throw IOException for original, return -1 for mutant
                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                              zis.read(buffer, 0, 10);
                                                                                                                              
                                                                                                                              // Assert - handled by @Test(expected)
                                                                                                                          }

 @Test
                                                                                                                public void testReadUpdatesCrcFromCorrectBufferPosition() throws Exception {
                                                                                                                    // Setup test data
                                                                                                                    byte[] testData = "TestDataForCRC".getBytes();
                                                                                                                    byte[] buffer = new byte[testData.length + 10]; // Extra space for offset
                                                                                                                    int startOffset = 5; // Non-zero start position
                                                                                                                    
                                                                                                                    // Mock the input stream to return our test data
                                                                                                                    InputStream mockInput = new ByteArrayInputStream(testData);
                                                                                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                                    
                                                                                                                    // Mock the inflater to return our test data length
                                                                                                                    Inflater mockInflater = mock(Inflater.class);
                                                                                                                    when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                        .thenAnswer(invocation -> {
                                                                                                                            byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                            int offset = (Integer) invocation.getArguments()[1];
                                                                                                                            int len = (Integer) invocation.getArguments()[2];
                                                                                                                            System.arraycopy(testData, 0, buf, offset, Math.min(len, testData.length));
                                                                                                                            return testData.length;
                                                                                                                        });
                                                                                                                    when(mockInflater.finished()).thenReturn(false);
                                                                                                                    when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                    
                                                                                                                    // Use reflection to inject our mock inflater
                                                                                                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                    infField.setAccessible(true);
                                                                                                                    infField.set(zis, mockInflater);
                                                                                                                    
                                                                                                                    // Also set current entry to non-null
                                                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                    currentField.setAccessible(true);
                                                                                                                    currentField.set(zis, new ZipArchiveEntry("test"));
                                                                                                                    
                                                                                                                    // Get the CRC object to verify later
                                                                                                                    Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                    crcField.setAccessible(true);
                                                                                                                    CRC32 crc = (CRC32) crcField.get(zis);
                                                                                                                    
                                                                                                                    // Perform the read operation
                                                                                                                    int bytesRead = zis.read(buffer, startOffset, testData.length);
                                                                                                                    
                                                                                                                    // Verify the CRC was calculated correctly
                                                                                                                    CRC32 expectedCrc = new CRC32();
                                                                                                                    expectedCrc.update(buffer, startOffset, bytesRead); // How it should work
                                                                                                                    
                                                                                                                    CRC32 mutatedCrc = new CRC32();
                                                                                                                    mutatedCrc.update(buffer, 0, bytesRead); // How the mutant would work
                                                                                                                    
                                                                                                                    // This assertion will fail if the mutant is present
                                                                                                                    assertEquals("CRC should be calculated from start position", 
                                                                                                                                expectedCrc.getValue(), crc.getValue());
                                                                                                                    
                                                                                                                    // Additional verification that mutated version would be different
                                                                                                                    assertNotEquals("Test would not detect mutant if these are equal",
                                                                                                                                   mutatedCrc.getValue(), crc.getValue());
                                                                                                                }

 @Test
                                                                                                           public void testReadUpdatesCrcCorrectly() throws Exception {
                                                                                                               // Setup test data
                                                                                                               byte[] testData = {1, 2, 3, 4, 5};
                                                                                                               byte[] buffer = new byte[10];
                                                                                                               
                                                                                                               // Mock dependencies
                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                               when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                   System.arraycopy(testData, 0, buf, 0, testData.length);
                                                                                                                   return testData.length;
                                                                                                               });
                                                                                                               
                                                                                                               Inflater mockInf = mock(Inflater.class);
                                                                                                               when(mockInf.needsInput()).thenReturn(true);
                                                                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(testData.length);
                                                                                                               
                                                                                                               ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                               when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                               
                                                                                                               // Create instance and set state using reflection
                                                                                                               ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                               
                                                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                               currentField.setAccessible(true);
                                                                                                               currentField.set(zis, mockEntry);
                                                                                                               
                                                                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                               infField.setAccessible(true);
                                                                                                               infField.set(zis, mockInf);
                                                                                                               
                                                                                                               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                               crcField.setAccessible(true);
                                                                                                               crcField.set(zis, new CRC32());
                                                                                                               
                                                                                                               // Perform read
                                                                                                               int read = zis.read(buffer, 0, buffer.length);
                                                                                                               
                                                                                                               // Verify CRC was updated with correct length
                                                                                                               CRC32 expectedCrc = new CRC32();
                                                                                                               expectedCrc.update(testData, 0, testData.length);
                                                                                                               
                                                                                                               assertEquals(expectedCrc.getValue(), ((CRC32)crcField.get(zis)).getValue());
                                                                                                               assertEquals(testData.length, read);
                                                                                                           }

 @Test
                                                                                                       public void testReadUpdatesCrcWithCorrectByteCount() throws Exception {
                                                                                                           // Setup test data
                                                                                                           byte[] testData = {1, 2, 3, 4, 5};
                                                                                                           byte[] buffer = new byte[10];
                                                                                                           int start = 0;
                                                                                                           int length = 5;
                                                                                                           
                                                                                                           // Mock dependencies
                                                                                                           InputStream mockInputStream = mock(InputStream.class);
                                                                                                           Inflater mockInflater = mock(Inflater.class);
                                                                                                           ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                           
                                                                                                           // Create test instance using reflection to inject mocks
                                                                                                           ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
                                                                                                           
                                                                                                           // Set up mock behavior
                                                                                                           when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                           when(mockInflater.needsInput()).thenReturn(false);
                                                                                                           when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                               .thenReturn(length); // return that we read 'length' bytes
                                                                                                           
                                                                                                           // Inject mocks and set state
                                                                                                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                           infField.setAccessible(true);
                                                                                                           infField.set(zis, mockInflater);
                                                                                                           
                                                                                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                           currentField.setAccessible(true);
                                                                                                           currentField.set(zis, mockEntry);
                                                                                                           
                                                                                                           Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                           crcField.setAccessible(true);
                                                                                                           CRC32 crc = (CRC32) crcField.get(zis);
                                                                                                           
                                                                                                           // Perform the read operation
                                                                                                           int bytesRead = zis.read(buffer, start, length);
                                                                                                           
                                                                                                           // Verify results
                                                                                                           assertEquals(length, bytesRead);
                                                                                                           
                                                                                                           // Calculate expected CRC
                                                                                                           CRC32 expectedCrc = new CRC32();
                                                                                                           expectedCrc.update(testData, 0, length);
                                                                                                           
                                                                                                           // This assertion will fail if the mutation is present
                                                                                                           // because the mutation updates CRC with 0 bytes instead of 'length' bytes
                                                                                                           assertEquals(expectedCrc.getValue(), crc.getValue());
                                                                                                           
                                                                                                           // Verify inflate was called correctly
                                                                                                           verify(mockInflater).inflate(buffer, start, length);
                                                                                                       }

 @Test
                                                                                                     public void testReadUpdatesCrcForDeflatedEntry() throws Exception {
                                                                                                         // Setup test data
                                                                                                         byte[] testData = "Test data for CRC check".getBytes();
                                                                                                         byte[] buffer = new byte[1024];
                                                                                                         
                                                                                                         // Mock InputStream to return test data
                                                                                                         InputStream mockInput = mock(InputStream.class);
                                                                                                         when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                             byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                             System.arraycopy(testData, 0, buf, 0, testData.length);
                                                                                                             return testData.length;
                                                                                                         });
                                                                                                         
                                                                                                         // Create ZipArchiveInputStream with mock input
                                                                                                         ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                         
                                                                                                         // Mock ZipArchiveEntry
                                                                                                         ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                         when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                         when(entry.getSize()).thenReturn((long)testData.length);
                                                                                                         
                                                                                                         // Use reflection to set current entry (since it's private)
                                                                                                         Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                         currentField.setAccessible(true);
                                                                                                         currentField.set(zis, entry);
                                                                                                         
                                                                                                         // Get initial CRC value
                                                                                                         CRC32 originalCrc = new CRC32();
                                                                                                         originalCrc.update(testData);
                                                                                                         long expectedCrcValue = originalCrc.getValue();
                                                                                                         
                                                                                                         // Read some data
                                                                                                         int read = zis.read(buffer, 0, buffer.length);
                                                                                                         assertTrue(read > 0);
                                                                                                         
                                                                                                         // Get the actual CRC from the stream
                                                                                                         Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                         crcField.setAccessible(true);
                                                                                                         CRC32 actualCrc = (CRC32)crcField.get(zis);
                                                                                                         
                                                                                                         // Verify CRC was updated (would fail with mutant)
                                                                                                         assertEquals("CRC should be updated after read", 
                                                                                                                     expectedCrcValue, actualCrc.getValue());
                                                                                                         
                                                                                                         // Clean up
                                                                                                         zis.close();
                                                                                                     }

 @Test
                                                                                                 public void testReadCompressedEntryReturnsCorrectByteCount() throws Exception {
                                                                                                     // Setup
                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                     Inflater mockInf = mock(Inflater.class);
                                                                                                     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                     
                                                                                                     // Create test instance using reflection to inject mocks
                                                                                                     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                     
                                                                                                     // Set up test scenario for compressed entry
                                                                                                     when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED); // non-STORED
                                                                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                     currentField.setAccessible(true);
                                                                                                     currentField.set(zais, mockEntry);
                                                                                                     
                                                                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                     infField.setAccessible(true);
                                                                                                     infField.set(zais, mockInf);
                                                                                                     
                                                                                                     // Configure inflater to return specific value
                                                                                                     when(mockInf.needsInput()).thenReturn(false);
                                                                                                     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                         .thenAnswer(invocation -> {
                                                                                                             // Return 5 bytes inflated
                                                                                                             return 5;
                                                                                                         });
                                                                                                     
                                                                                                     // Prepare test buffer
                                                                                                     byte[] buffer = new byte[10];
                                                                                                     int start = 0;
                                                                                                     int length = 10;
                                                                                                     
                                                                                                     // Execute
                                                                                                     int bytesRead = zais.read(buffer, start, length);
                                                                                                     
                                                                                                     // Verify
                                                                                                     assertEquals("Should return exact number of bytes read from inflater", 
                                                                                                                  5, bytesRead);
                                                                                                     
                                                                                                     // Verify mutation would fail - mutant would return 6 instead of 5
                                                                                                 }

 @Test
                                                                                               public void testReadCompressedEntryReturnsActualBytesRead() throws Exception {
                                                                                                   // Setup test data
                                                                                                   byte[] testData = "Test compressed data".getBytes();
                                                                                                   byte[] buffer = new byte[1024];
                                                                                                   
                                                                                                   // Mock dependencies
                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                   Inflater mockInflater = mock(Inflater.class);
                                                                                                   ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                   
                                                                                                   // Configure mocks
                                                                                                   when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                   when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                       .thenAnswer(invocation -> {
                                                                                                           byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                           int len = (Integer) invocation.getArguments()[2];
                                                                                                           System.arraycopy(testData, 0, buf, 0, Math.min(len, testData.length));
                                                                                                           return testData.length;
                                                                                                       });
                                                                                                   
                                                                                                   // Create test instance and set state using reflection
                                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                   infField.setAccessible(true);
                                                                                                   infField.set(zais, mockInflater);
                                                                                                   
                                                                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                   currentField.setAccessible(true);
                                                                                                   currentField.set(zais, mockEntry);
                                                                                                   
                                                                                                   Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                   closedField.setAccessible(true);
                                                                                                   closedField.set(zais, false);
                                                                                                   
                                                                                                   Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                   lengthField.setAccessible(true);
                                                                                                   lengthField.set(zais, 1); // Pretend we have data
                                                                                                   
                                                                                                   // Test - should return actual bytes read (testData.length)
                                                                                                   int bytesRead = zais.read(buffer, 0, buffer.length);
                                                                                                   
                                                                                                   // Verify - this will catch the mutant that returns 0
                                                                                                   assertEquals("Should return actual number of bytes read", 
                                                                                                               testData.length, bytesRead);
                                                                                                   
                                                                                                   // Additional verification that data was copied
                                                                                                   assertArrayEquals("Buffer should contain test data",
                                                                                                                   testData, 
                                                                                                                   java.util.Arrays.copyOf(buffer, testData.length));
                                                                                               }

 @Test
                                                                                           public void testReadReturnsActualBytesReadInsteadOfMinusOne() throws Exception {
                                                                                               // Setup
                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                               Inflater mockInf = mock(Inflater.class);
                                                                                               ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                               entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                               
                                                                                               // Create test instance using reflection to inject mocks
                                                                                               ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                               infField.setAccessible(true);
                                                                                               infField.set(zis, mockInf);
                                                                                               
                                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                               currentField.setAccessible(true);
                                                                                               currentField.set(zis, entry);
                                                                                               
                                                                                               Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                               bufField.setAccessible(true);
                                                                                               bufField.set(zis, new byte[1024]);
                                                                                               
                                                                                               // Mock behavior
                                                                                               when(mockInf.needsInput()).thenReturn(false);
                                                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                   .thenReturn(10); // simulate reading 10 bytes
                                                                                               
                                                                                               // Test buffer
                                                                                               byte[] testBuffer = new byte[100];
                                                                                               
                                                                                               // Execute
                                                                                               int result = zis.read(testBuffer, 0, 100);
                                                                                               
                                                                                               // Verify
                                                                                               assertEquals("Should return actual bytes read (10)", 10, result);
                                                                                               
                                                                                               // Verify mutation would fail - mutant returns -1 instead of 10
                                                                                           }

 @Test(expected = RuntimeException.class)
                                                                                          public void testReadShouldNotCatchNonDataFormatException() throws Exception {
                                                                                              // Setup
                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                              Inflater mockInf = mock(Inflater.class);
                                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                              entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                              
                                                                                              // Create test instance using reflection to inject mocks
                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                              
                                                                                              // Set required internal state
                                                                                              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                              infField.setAccessible(true);
                                                                                              infField.set(zais, mockInf);
                                                                                              
                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                              currentField.setAccessible(true);
                                                                                              currentField.set(zais, entry);
                                                                                              
                                                                                              Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                              bufField.setAccessible(true);
                                                                                              bufField.set(zais, new byte[1024]);
                                                                                              
                                                                                              // Mock behavior
                                                                                              when(mockInf.needsInput()).thenReturn(false);
                                                                                              // Make inflate throw a different exception
                                                                                              when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                  .thenThrow(new RuntimeException("Test exception"));
                                                                                              
                                                                                              // Test - should throw the original RuntimeException, not wrap it
                                                                                              byte[] buffer = new byte[1024];
                                                                                              zais.read(buffer, 0, 1024);
                                                                                          }

 @Test(expected = ZipException.class)
                                                                                         public void testRead_ThrowsZipExceptionOnDataFormatError() throws Exception {
                                                                                             // Setup
                                                                                             InputStream mockInput = mock(InputStream.class);
                                                                                             Inflater mockInf = mock(Inflater.class);
                                                                                             ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                             entry.setMethod(ZipArchiveOutputStream.DEFLATED); // Ensure we take the inflation path
                                                                                             
                                                                                             // Create instance using reflection to inject mocks
                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                             
                                                                                             // Set required internal state
                                                                                             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                             infField.setAccessible(true);
                                                                                             infField.set(zais, mockInf);
                                                                                             
                                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                             currentField.setAccessible(true);
                                                                                             currentField.set(zais, entry);
                                                                                             
                                                                                             Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                             bufField.setAccessible(true);
                                                                                             bufField.set(zais, new byte[1024]);
                                                                                             
                                                                                             // Mock behavior
                                                                                             when(mockInf.needsInput()).thenReturn(true);
                                                                                             doThrow(new DataFormatException("test error")).when(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                             
                                                                                             // Test - should throw ZipException
                                                                                             byte[] buffer = new byte[1024];
                                                                                             zais.read(buffer, 0, 1024);
                                                                                         }

 @Test(expected = ZipException.class)
                                                                                        public void testRead_DataFormatException_ShouldContainOriginalMessage() throws Exception {
                                                                                            // Setup
                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                            Inflater mockInflater = mock(Inflater.class);
                                                                                            ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                            
                                                                                            // Create test instance using reflection to inject mocks
                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                            
                                                                                            // Set up current entry and other required state
                                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                            currentField.setAccessible(true);
                                                                                            currentField.set(zais, mockEntry);
                                                                                            
                                                                                            Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                            infField.setAccessible(true);
                                                                                            infField.set(zais, mockInflater);
                                                                                            
                                                                                            Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                            closedField.setAccessible(true);
                                                                                            closedField.set(zais, false);
                                                                                            
                                                                                            // Mock behavior
                                                                                            when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                            when(mockInflater.needsInput()).thenReturn(true);
                                                                                            
                                                                                            // Setup buffer and parameters
                                                                                            byte[] buffer = new byte[10];
                                                                                            int start = 0;
                                                                                            int length = 10;
                                                                                            
                                                                                            // Make inflater throw DataFormatException with specific message
                                                                                            String expectedMessage = "Invalid data format";
                                                                                            doThrow(new DataFormatException(expectedMessage))
                                                                                                .when(mockInflater).inflate(buffer, start, length);
                                                                                            
                                                                                            // Test and verify
                                                                                            try {
                                                                                                zais.read(buffer, start, length);
                                                                                            } catch (ZipException e) {
                                                                                                // Verify the exception contains the original message
                                                                                                assertTrue("Exception message should contain original error", 
                                                                                                          e.getMessage().contains(expectedMessage));
                                                                                                throw e;
                                                                                            }
                                                                                        }

 @Test(expected = ZipException.class)
                                                                                       public void testRead_ThrowsZipExceptionOnDataFormatError1() throws Exception {
                                                                                           // Arrange
                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                           Inflater mockInf = mock(Inflater.class);
                                                                                           ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                           entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                           
                                                                                           // Create instance with reflection to inject mocks
                                                                                           ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                           
                                                                                           // Set required internal state
                                                                                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                           infField.setAccessible(true);
                                                                                           infField.set(zis, mockInf);
                                                                                           
                                                                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                           currentField.setAccessible(true);
                                                                                           currentField.set(zis, entry);
                                                                                           
                                                                                           Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                           bufField.setAccessible(true);
                                                                                           bufField.set(zis, new byte[1024]);
                                                                                           
                                                                                           // Mock behavior
                                                                                           when(mockInf.needsInput()).thenReturn(false);
                                                                                           when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                               .thenThrow(new DataFormatException("Invalid data"));
                                                                                           
                                                                                           // Act
                                                                                           zis.read(new byte[1024], 0, 1024);
                                                                                           
                                                                                           // Assert - expected exception is declared in annotation
                                                                                       }

 @Test(expected = IOException.class)
                                                                                      public void testReadWithNegativeInflateReturn() throws Exception {
                                                                                          // Setup
                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                          Inflater mockInf = mock(Inflater.class);
                                                                                          CRC32 mockCrc = mock(CRC32.class);
                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                          entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                          
                                                                                          // Create instance using reflection to inject mocks
                                                                                          ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                          
                                                                                          // Set internal state
                                                                                          Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                          infField.setAccessible(true);
                                                                                          infField.set(zais, mockInf);
                                                                                          
                                                                                          Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                          crcField.setAccessible(true);
                                                                                          crcField.set(zais, mockCrc);
                                                                                          
                                                                                          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                          currentField.setAccessible(true);
                                                                                          currentField.set(zais, entry);
                                                                                          
                                                                                          Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                          lengthOfLastReadField.setAccessible(true);
                                                                                          lengthOfLastReadField.set(zais, 1024); // Not -1
                                                                                          
                                                                                          // Mock behavior
                                                                                          when(mockInf.needsInput()).thenReturn(true);
                                                                                          doNothing().when(mockInf).reset();
                                                                                          when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                              .thenReturn(-1); // Simulate error case
                                                                                          
                                                                                          // Test
                                                                                          byte[] buffer = new byte[1024];
                                                                                          zais.read(buffer, 0, 1024); // Should throw IOException
                                                                                          
                                                                                          // Verify - expected exception should be thrown
                                                                                      }

 @Test
                                                                                    public void testReadWithZeroInflateOutput() throws Exception {
                                                                                        // Setup
                                                                                        InputStream mockInput = mock(InputStream.class);
                                                                                        Inflater mockInf = mock(Inflater.class);
                                                                                        ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                        
                                                                                        // Create test instance using reflection to inject mocks
                                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                        
                                                                                        // Set up mocks and test conditions
                                                                                        Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                        infField.setAccessible(true);
                                                                                        infField.set(zais, mockInf);
                                                                                        
                                                                                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                        currentField.setAccessible(true);
                                                                                        currentField.set(zais, mockEntry);
                                                                                        
                                                                                        when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                        when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                        when(mockInf.finished()).thenReturn(false);
                                                                                        
                                                                                        // Set lengthOfLastRead to -1 to trigger IOException
                                                                                        Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                        lengthField.setAccessible(true);
                                                                                        lengthField.set(zais, -1);
                                                                                        
                                                                                        // Test
                                                                                        byte[] buffer = new byte[10];
                                                                                        try {
                                                                                            zais.read(buffer, 0, 10);
                                                                                            fail("Expected IOException not thrown");
                                                                                        } catch (IOException e) {
                                                                                            assertEquals("Truncated ZIP file", e.getMessage());
                                                                                        }
                                                                                        
                                                                                        // Verify the mutant would not reach this point
                                                                                        verify(mockInf, times(1)).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                        verify(mockInf, times(1)).finished();
                                                                                    }

 @Test
                                                                                public void testReadWithNonZeroInflateShouldNotCheckForCompletion() throws Exception {
                                                                                    // Setup
                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                    Inflater mockInf = mock(Inflater.class);
                                                                                    CRC32 mockCrc = mock(CRC32.class);
                                                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                    
                                                                                    // Create test instance using reflection since constructor may be private
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                    
                                                                                    // Set up internal state using reflection
                                                                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                    infField.setAccessible(true);
                                                                                    infField.set(zais, mockInf);
                                                                                    
                                                                                    Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                    crcField.setAccessible(true);
                                                                                    crcField.set(zais, mockCrc);
                                                                                    
                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                    currentField.setAccessible(true);
                                                                                    currentField.set(zais, mockEntry);
                                                                                    
                                                                                    Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                    closedField.setAccessible(true);
                                                                                    closedField.set(zais, false);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                    when(mockInf.needsInput()).thenReturn(false);
                                                                                    when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // return non-zero read
                                                                                    
                                                                                    // Test
                                                                                    byte[] buffer = new byte[10];
                                                                                    int result = zais.read(buffer, 0, 10);
                                                                                    
                                                                                    // Verify
                                                                                    assertEquals(5, result); // Should return the actual read count
                                                                                    verify(mockCrc).update(buffer, 0, 5); // Should update CRC with actual bytes
                                                                                    // Should NOT check for inf.finished() or lengthOfLastRead when read>0
                                                                                }

 @Test
                                                                               public void testReadShouldNotReturnNegativeOneWhenInflaterReturnsNegativeOneButNotFinished() throws Exception {
                                                                                   // Setup
                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                   Inflater mockInflater = mock(Inflater.class);
                                                                                   ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                   
                                                                                   // Create instance using reflection since constructor is complex
                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                   
                                                                                   // Set up mocks
                                                                                   when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                   when(mockInflater.finished()).thenReturn(false);
                                                                                   when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                       .thenReturn(-1); // Inflater returns -1 but not finished
                                                                                   
                                                                                   // Use reflection to set private fields since we need specific state
                                                                                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                   infField.setAccessible(true);
                                                                                   infField.set(zais, mockInflater);
                                                                                   
                                                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                   currentField.setAccessible(true);
                                                                                   currentField.set(zais, mockEntry);
                                                                                   
                                                                                   Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                   closedField.setAccessible(true);
                                                                                   closedField.set(zais, false);
                                                                                   
                                                                                   // Prepare test buffer
                                                                                   byte[] buffer = new byte[1024];
                                                                                   
                                                                                   // Test - should throw IOException for truncated file (original behavior)
                                                                                   try {
                                                                                       zais.read(buffer, 0, 100);
                                                                                       fail("Should have thrown IOException for truncated file");
                                                                                   } catch (IOException e) {
                                                                                       assertEquals("Truncated ZIP file", e.getMessage());
                                                                                   }
                                                                                   
                                                                                   // Verify interactions
                                                                                   verify(mockInflater).inflate(buffer, 0, 100);
                                                                               }

 @Test
                                                                              public void testReadReturnsMinusOneWhenInflaterFinished1() throws Exception {
                                                                                  // Setup
                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                  Inflater mockInf = mock(Inflater.class);
                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                  entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                  
                                                                                  // Create test instance using reflection to inject mocks
                                                                                  ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                  
                                                                                  // Set internal state using reflection
                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                  infField.setAccessible(true);
                                                                                  infField.set(zis, mockInf);
                                                                                  
                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                  currentField.setAccessible(true);
                                                                                  currentField.set(zis, entry);
                                                                                  
                                                                                  Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                  bufField.setAccessible(true);
                                                                                  bufField.set(zis, new byte[1024]);
                                                                                  
                                                                                  // Mock behavior
                                                                                  when(mockInf.finished()).thenReturn(true);  // Inflater reports finished
                                                                                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);  // No more data
                                                                                  
                                                                                  // Test
                                                                                  byte[] buffer = new byte[1024];
                                                                                  int result = zis.read(buffer, 0, 1024);
                                                                                  
                                                                                  // Verify
                                                                                  assertEquals("Should return -1 when inflater is finished", -1, result);
                                                                                  
                                                                                  // Clean up
                                                                                  infField.setAccessible(false);
                                                                                  currentField.setAccessible(false);
                                                                                  bufField.setAccessible(false);
                                                                              }

 @Test
                                                                             public void testReadReturnsNegativeOneWhenEntryFullyRead() throws Exception {
                                                                                 // Setup for STORED entry case
                                                                                 ZipArchiveEntry storedEntry = new ZipArchiveEntry("test");
                                                                                 storedEntry.setMethod(ZipArchiveOutputStream.STORED);
                                                                                 storedEntry.setSize(10); // Small size for testing
                                                                                 storedEntry.setCompressedSize(10);
                                                                                 storedEntry.setCrc(12345L);
                                                                                 
                                                                                 // Mock input stream to return some data then EOF
                                                                                 byte[] testData = new byte[]{1,2,3,4,5,6,7,8,9,10};
                                                                                 InputStream mockStream = new ByteArrayInputStream(testData);
                                                                                 ZipArchiveInputStream zis = new ZipArchiveInputStream(mockStream);
                                                                                 
                                                                                 // Use reflection to set private fields for testing
                                                                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                 currentField.setAccessible(true);
                                                                                 currentField.set(zis, storedEntry);
                                                                                 
                                                                                 Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                 readBytesField.setAccessible(true);
                                                                                 readBytesField.set(zis, 10); // Set to full size
                                                                                 
                                                                                 // Create buffer
                                                                                 byte[] buffer = new byte[10];
                                                                                 
                                                                                 // Test - should return -1 when readBytesOfEntry >= csize
                                                                                 int result = zis.read(buffer, 0, 10);
                                                                                 assertEquals("Should return -1 when entry fully read", -1, result);
                                                                                 
                                                                                 // Setup for compressed entry case
                                                                                 ZipArchiveEntry compressedEntry = new ZipArchiveEntry("test2");
                                                                                 compressedEntry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                 currentField.set(zis, compressedEntry);
                                                                                 
                                                                                 // Mock inflater to be finished
                                                                                 Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                 infField.setAccessible(true);
                                                                                 Inflater mockInflater = mock(Inflater.class);
                                                                                 when(mockInflater.finished()).thenReturn(true);
                                                                                 infField.set(zis, mockInflater);
                                                                                 
                                                                                 // Test - should return -1 when inflater is finished
                                                                                 result = zis.read(buffer, 0, 10);
                                                                                 assertEquals("Should return -1 when inflater finished", -1, result);
                                                                             }

 @Test
                                                                            public void testRead_ShouldReturnMinusOneWhenReadBytesExceedEntrySize() throws Exception {
                                                                                // Setup
                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                
                                                                                // Create test instance using reflection to set internal state
                                                                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
                                                                                
                                                                                // Set up mocks and internal state
                                                                                when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                when(mockEntry.getSize()).thenReturn(100L); // Entry size is 100 bytes
                                                                                
                                                                                // Use reflection to set internal fields since they're private
                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                currentField.setAccessible(true);
                                                                                currentField.set(zis, mockEntry);
                                                                                
                                                                                Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                readBytesField.setAccessible(true);
                                                                                readBytesField.set(zis, 100); // Already read all bytes
                                                                                
                                                                                Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                closedField.setAccessible(true);
                                                                                closedField.set(zis, false);
                                                                                
                                                                                // Prepare buffer
                                                                                byte[] buffer = new byte[1024];
                                                                                
                                                                                // Test
                                                                                int result = zis.read(buffer, 0, 100);
                                                                                
                                                                                // Verify
                                                                                assertEquals("Should return -1 when readBytesOfEntry >= entry size", -1, result);
                                                                                
                                                                                // Clean up
                                                                                currentField.setAccessible(false);
                                                                                readBytesField.setAccessible(false);
                                                                                closedField.setAccessible(false);
                                                                            }

 @Test
                                                                           public void testReadWithZeroLengthOfLastReadShouldNotThrowException() throws Exception {
                                                                               // Setup
                                                                               InputStream mockInput = mock(InputStream.class);
                                                                               Inflater mockInf = mock(Inflater.class);
                                                                               CRC32 mockCrc = mock(CRC32.class);
                                                                               ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                               
                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                               
                                                                               // Use reflection to set private fields since we need to control test conditions
                                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                               infField.setAccessible(true);
                                                                               infField.set(zais, mockInf);
                                                                               
                                                                               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                               crcField.setAccessible(true);
                                                                               crcField.set(zais, mockCrc);
                                                                               
                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                               currentField.setAccessible(true);
                                                                               currentField.set(zais, mockEntry);
                                                                               
                                                                               Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                               lengthOfLastReadField.setAccessible(true);
                                                                               lengthOfLastReadField.set(zais, 0); // Critical value for this test
                                                                               
                                                                               // Mock behavior
                                                                               when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                               when(mockInf.finished()).thenReturn(false);
                                                                               
                                                                               // Test - should not throw exception with original code
                                                                               byte[] buffer = new byte[10];
                                                                               int result = zais.read(buffer, 0, 10);
                                                                               
                                                                               // Verify
                                                                               assertEquals(-1, result); // Expected behavior when inflate returns 0 but not finished
                                                                               // If mutant is present, it would throw IOException instead
                                                                           }

 @Test
                                                                          public void testRead_ShouldNotThrowWhenInflaterReturnsZeroButStreamNotEnded() throws Exception {
                                                                              // Setup
                                                                              InputStream mockInput = mock(InputStream.class);
                                                                              Inflater mockInf = mock(Inflater.class);
                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                              entry.setMethod(ZipArchiveOutputStream.DEFLATED); // compressed method
                                                                              
                                                                              // Create test instance using reflection to inject mocks
                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                              
                                                                              // Set internal state
                                                                              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                              infField.setAccessible(true);
                                                                              infField.set(zais, mockInf);
                                                                              
                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                              currentField.setAccessible(true);
                                                                              currentField.set(zais, entry);
                                                                              
                                                                              Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                              lengthOfLastReadField.setAccessible(true);
                                                                              lengthOfLastReadField.set(zais, 1); // not -1
                                                                              
                                                                              // Mock behavior
                                                                              when(mockInf.finished()).thenReturn(false);
                                                                              when(mockInf.needsInput()).thenReturn(false);
                                                                              when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                              
                                                                              // Test - should not throw exception
                                                                              byte[] buffer = new byte[1024];
                                                                              int result = zais.read(buffer, 0, 1024);
                                                                              
                                                                              // Verify
                                                                              assertEquals(-1, result); // Should return -1, not throw exception
                                                                              
                                                                              // Verify mutant would have thrown exception
                                                                              try {
                                                                                  // Simulate mutant behavior by forcing the else-if branch
                                                                                  Field mutantField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                  mutantField.setAccessible(true);
                                                                                  mutantField.set(zais, -1);
                                                                                  
                                                                                  zais.read(buffer, 0, 1024);
                                                                                  fail("Should have thrown IOException for mutant");
                                                                              } catch (IOException e) {
                                                                                  assertEquals("Truncated ZIP file", e.getMessage());
                                                                              }
                                                                          }

 @Test(expected = IOException.class)
                                                                         public void testRead_ThrowsIOExceptionForTruncatedZipFile() throws Exception {
                                                                             // Setup
                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                             Inflater mockInflater = mock(Inflater.class);
                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                             
                                                                             // Create test instance using reflection since constructor may be complex
                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                             
                                                                             // Set up internal state to trigger the truncated file scenario
                                                                             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                             infField.setAccessible(true);
                                                                             infField.set(zais, mockInflater);
                                                                             
                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                             currentField.setAccessible(true);
                                                                             currentField.set(zais, mockEntry);
                                                                             
                                                                             Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                             lengthOfLastReadField.setAccessible(true);
                                                                             lengthOfLastReadField.set(zais, -1);
                                                                             
                                                                             // Mock behavior
                                                                             when(mockInflater.finished()).thenReturn(false);
                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                             
                                                                             // This should trigger the exception
                                                                             byte[] buffer = new byte[10];
                                                                             zais.read(buffer, 0, buffer.length);
                                                                         }

 @Test(expected = IOException.class)
                                                                        public void testRead_ThrowsCorrectTruncatedZipFileException() throws Exception {
                                                                            // Setup
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            Inflater mockInflater = mock(Inflater.class);
                                                                            ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                            
                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                            
                                                                            // Use reflection to set private fields since we need to control test conditions
                                                                            Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                            infField.setAccessible(true);
                                                                            infField.set(zais, mockInflater);
                                                                            
                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                            currentField.setAccessible(true);
                                                                            currentField.set(zais, mockEntry);
                                                                            
                                                                            Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                            lengthOfLastReadField.setAccessible(true);
                                                                            lengthOfLastReadField.set(zais, -1);
                                                                            
                                                                            // Mock behavior
                                                                            when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                            when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                            when(mockInflater.finished()).thenReturn(false);
                                                                            
                                                                            // Test
                                                                            try {
                                                                                zais.read(new byte[10], 0, 10);
                                                                            } catch (IOException e) {
                                                                                // Verify the exact exception message
                                                                                assertEquals("Truncated ZIP file", e.getMessage());
                                                                                throw e;
                                                                            }
                                                                        }

 @Test(expected = IOException.class)
                                                                       public void testRead_DetectsTruncatedZipFile1() throws Exception {
                                                                           // Setup
                                                                           InputStream mockInput = mock(InputStream.class);
                                                                           Inflater mockInf = mock(Inflater.class);
                                                                           ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                           
                                                                           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                           
                                                                           // Use reflection to set private fields since we need to simulate specific state
                                                                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                           infField.setAccessible(true);
                                                                           infField.set(zais, mockInf);
                                                                           
                                                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                           currentField.setAccessible(true);
                                                                           currentField.set(zais, mockEntry);
                                                                           
                                                                           Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                           lengthOfLastReadField.setAccessible(true);
                                                                           lengthOfLastReadField.set(zais, -1);
                                                                           
                                                                           // Mock behavior
                                                                           when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                           when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                           when(mockInf.finished()).thenReturn(false);
                                                                           
                                                                           // Test - should throw IOException for truncated file
                                                                           byte[] buffer = new byte[1024];
                                                                           zais.read(buffer, 0, 1024);
                                                                           
                                                                           // Verify
                                                                           verify(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                       }

 @Test
                                                             public void testReadUpdatesCrcWithCorrectBufferPosition() throws Exception {
                                                                 // Setup test data with non-zero start position
                                                                 byte[] testData = "TestDataForCRC".getBytes();
                                                                 byte[] buffer = new byte[100];
                                                                 int startPos = 10;
                                                                 int length = testData.length;
                                                                 
                                                                 // Mock dependencies
                                                                 InputStream mockInput = mock(InputStream.class);
                                                                 Inflater mockInf = mock(Inflater.class);
                                                                 ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                 
                                                                 // Create test instance using reflection to inject mocks
                                                                 ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                 
                                                                 // Set up mock behavior
                                                                 when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                 when(mockInf.needsInput()).thenReturn(false);
                                                                 when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                     .thenAnswer(invocation -> {
                                                                         byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                         int off = (Integer) invocation.getArguments()[1];
                                                                         int len = (Integer) invocation.getArguments()[2];
                                                                         System.arraycopy(testData, 0, buf, off, len);
                                                                         return len;
                                                                     });
                                                                 
                                                                 // Inject mocks into test instance
                                                                 Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                 infField.setAccessible(true);
                                                                 infField.set(zis, mockInf);
                                                                 
                                                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                 currentField.setAccessible(true);
                                                                 currentField.set(zis, mockEntry);
                                                                 
                                                                 Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                 crcField.setAccessible(true);
                                                                 CRC32 crc = (CRC32)crcField.get(zis);
                                                                 
                                                                 // Perform read operation
                                                                 int bytesRead = zis.read(buffer, startPos, length);
                                                                 
                                                                 // Verify CRC was updated with correct buffer portion
                                                                 CRC32 expectedCrc = new CRC32();
                                                                 expectedCrc.update(testData, 0, testData.length);
                                                                 
                                                                 CRC32 actualCrc = new CRC32();
                                                                 actualCrc.update(buffer, startPos, bytesRead);
                                                                 
                                                                 // This assertion will fail with the mutant since it uses buffer from position 0
                                                                 assertEquals("CRC should be calculated from correct buffer position",
                                                                             expectedCrc.getValue(), crc.getValue());
                                                                 
                                                                 // Additional verification that data was written to correct position
                                                                 byte[] readData = new byte[bytesRead];
                                                                 System.arraycopy(buffer, startPos, readData, 0, bytesRead);
                                                                 assertArrayEquals("Data should be written to correct buffer position",
                                                                                  testData, readData);
                                                             }

 @Test
                                                         public void testReadUpdatesCrcWithCorrectLength() throws Exception {
                                                             // Setup test data
                                                             byte[] testData = {1, 2, 3, 4, 5};
                                                             byte[] buffer = new byte[10];
                                                             int start = 0;
                                                             int length = 5;
                                                             
                                                             // Mock dependencies
                                                             InputStream mockInputStream = mock(InputStream.class);
                                                             Inflater mockInflater = mock(Inflater.class);
                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                             
                                                             // Create test instance using reflection to inject mocks
                                                             ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
                                                             
                                                             // Set up mock behavior
                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                             when(mockInflater.needsInput()).thenReturn(false);
                                                             when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                 .thenReturn(length); // return that we read 'length' bytes
                                                             
                                                             // Inject mocks and set state
                                                             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                             infField.setAccessible(true);
                                                             infField.set(zis, mockInflater);
                                                             
                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                             currentField.setAccessible(true);
                                                             currentField.set(zis, mockEntry);
                                                             
                                                             Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                             crcField.setAccessible(true);
                                                             CRC32 crc = (CRC32) crcField.get(zis);
                                                             
                                                             // Perform read operation
                                                             int bytesRead = zis.read(buffer, start, length);
                                                             
                                                             // Verify results
                                                             assertEquals(length, bytesRead);
                                                             
                                                             // Calculate expected CRC value
                                                             CRC32 expectedCrc = new CRC32();
                                                             expectedCrc.update(testData, 0, length);
                                                             
                                                             // Verify CRC was updated with correct length
                                                             // The mutant would update with length+1, causing this to fail
                                                             assertEquals(expectedCrc.getValue(), crc.getValue());
                                                         }

 @Test
                                                       public void testReadUpdatesCrcCorrectly1() throws Exception {
                                                           // Setup test data
                                                           byte[] testData = "Test data for CRC check".getBytes();
                                                           byte[] buffer = new byte[testData.length];
                                                           
                                                           // Mock dependencies
                                                           InputStream mockInput = mock(InputStream.class);
                                                           when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                                               System.arraycopy(testData, 0, buf, 0, testData.length);
                                                               return testData.length;
                                                           });
                                                           
                                                           // Create test instance
                                                           ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                           
                                                           // Set up entry (STORED method to test the CRC update path)
                                                           ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                           entry.setMethod(ZipArchiveOutputStream.STORED);
                                                           entry.setSize(testData.length);
                                                           entry.setCompressedSize(testData.length);
                                                           entry.setCrc(0); // Will be calculated during read
                                                           
                                                           // Use reflection to set current entry (since it's private)
                                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                           currentField.setAccessible(true);
                                                           currentField.set(zis, entry);
                                                           
                                                           // Read the data
                                                           int bytesRead = zis.read(buffer, 0, buffer.length);
                                                           
                                                           // Verify CRC was updated with correct length
                                                           CRC32 crc = new CRC32();
                                                           crc.update(testData);
                                                           long expectedCrc = crc.getValue();
                                                           
                                                           // Get actual CRC from the stream
                                                           Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                           crcField.setAccessible(true);
                                                           CRC32 actualCrc = (CRC32) crcField.get(zis);
                                                           
                                                           // Assertions
                                                           assertEquals(testData.length, bytesRead);
                                                           assertEquals(expectedCrc, actualCrc.getValue());
                                                       }

 @Test
                                                   public void testReadUpdatesCrcForDeflatedEntry1() throws Exception {
                                                       // Setup test data
                                                       byte[] testData = "Test data for CRC check".getBytes();
                                                       byte[] buffer = new byte[1024];
                                                       
                                                       // Mock the input stream to return test data
                                                       InputStream mockInput = new ByteArrayInputStream(testData);
                                                       ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                       
                                                       // Use reflection to access private fields for testing
                                                       Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                       crcField.setAccessible(true);
                                                       CRC32 crc = (CRC32) crcField.get(zis);
                                                       
                                                       Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                       currentField.setAccessible(true);
                                                       currentField.set(zis, new ZipArchiveEntry("test"));
                                                       
                                                       Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                       infField.setAccessible(true);
                                                       Inflater inf = (Inflater) infField.get(zis);
                                                       
                                                       // Get initial CRC value
                                                       long initialCrc = crc.getValue();
                                                       
                                                       // Perform read operation
                                                       int bytesRead = zis.read(buffer, 0, buffer.length);
                                                       
                                                       // Verify CRC was updated
                                                       long updatedCrc = crc.getValue();
                                                       
                                                       // Calculate expected CRC
                                                       CRC32 expectedCrc = new CRC32();
                                                       expectedCrc.update(testData, 0, bytesRead);
                                                       
                                                       // Assertions
                                                       assertTrue("Should read some bytes", bytesRead > 0);
                                                       assertNotEquals("CRC should be updated", initialCrc, updatedCrc);
                                                       assertEquals("CRC should match expected value", 
                                                                   expectedCrc.getValue(), 
                                                                   updatedCrc);
                                                       
                                                       // Clean up
                                                       zis.close();
                                                   }

 @Test
                                                  public void testReadReturnsCorrectByteCountForCompressedEntry() throws Exception {
                                                      // Setup
                                                      InputStream mockInput = mock(InputStream.class);
                                                      Inflater mockInf = mock(Inflater.class);
                                                      ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                      CRC32 mockCrc = mock(CRC32.class);
                                                      
                                                      // Create test instance using reflection to inject mocks
                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                      
                                                      // Set up mocks
                                                      when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED); // Not STORED
                                                      when(mockInf.needsInput()).thenReturn(false);
                                                      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                          .thenReturn(5); // We expect to read 5 bytes
                                                      
                                                      // Inject mocks into the instance
                                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                      infField.setAccessible(true);
                                                      infField.set(zais, mockInf);
                                                      
                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                      currentField.setAccessible(true);
                                                      currentField.set(zais, mockEntry);
                                                      
                                                      Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                      crcField.setAccessible(true);
                                                      crcField.set(zais, mockCrc);
                                                      
                                                      Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                      closedField.setAccessible(true);
                                                      closedField.set(zais, false);
                                                      
                                                      // Test buffer
                                                      byte[] buffer = new byte[10];
                                                      
                                                      // Execute
                                                      int bytesRead = zais.read(buffer, 0, 10);
                                                      
                                                      // Verify
                                                      assertEquals("Should return exact number of bytes inflated", 5, bytesRead);
                                                      
                                                      // Verify CRC was updated with correct length
                                                      verify(mockCrc).update(buffer, 0, 5);
                                                  }

 @Test
                                                 public void testReadReturnsActualBytesReadForDeflatedEntry() throws Exception {
                                                     // Setup
                                                     InputStream mockInput = mock(InputStream.class);
                                                     Inflater mockInf = mock(Inflater.class);
                                                     ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                     entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                     
                                                     // Create test instance using reflection to inject mocks
                                                     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                     infField.setAccessible(true);
                                                     infField.set(zis, mockInf);
                                                     
                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                     currentField.setAccessible(true);
                                                     currentField.set(zis, entry);
                                                     
                                                     // Configure mocks
                                                     when(mockInf.finished()).thenReturn(false);
                                                     when(mockInf.needsInput()).thenReturn(false);
                                                     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // return 5 bytes
                                                     
                                                     // Test buffer
                                                     byte[] buffer = new byte[10];
                                                     
                                                     // Execute
                                                     int bytesRead = zis.read(buffer, 0, 10);
                                                     
                                                     // Verify
                                                     assertEquals("Should return actual number of bytes read", 5, bytesRead);
                                                     
                                                     // Clean up
                                                     infField.setAccessible(false);
                                                     currentField.setAccessible(false);
                                                 }

 @Test
                                                public void testReadCompressedEntryReturnsActualBytesRead1() throws Exception {
                                                    // Setup
                                                    InputStream mockInput = mock(InputStream.class);
                                                    Inflater mockInf = mock(Inflater.class);
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                    entry.setMethod(ZipArchiveOutputStream.DEFLATED); // Compressed method
                                                    
                                                    // Create test instance using reflection since constructor may be private
                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                    
                                                    // Set internal state
                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                    currentField.setAccessible(true);
                                                    currentField.set(zis, entry);
                                                    
                                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                    infField.setAccessible(true);
                                                    infField.set(zis, mockInf);
                                                    
                                                    Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                    closedField.setAccessible(true);
                                                    closedField.set(zis, false);
                                                    
                                                    // Mock behavior
                                                    when(mockInf.needsInput()).thenReturn(false);
                                                    when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                        .thenReturn(5); // Simulate reading 5 bytes
                                                    
                                                    // Test
                                                    byte[] buffer = new byte[10];
                                                    int bytesRead = zis.read(buffer, 0, 10);
                                                    
                                                    // Verify
                                                    assertEquals("Should return actual bytes read (5)", 5, bytesRead);
                                                    
                                                    // Clean up
                                                    currentField.setAccessible(false);
                                                    infField.setAccessible(false);
                                                    closedField.setAccessible(false);
                                                }

 @Test(expected = RuntimeException.class)
                                               public void testReadShouldNotCatchGenericException1() throws Exception {
                                                   // Setup
                                                   InputStream mockInput = mock(InputStream.class);
                                                   Inflater mockInf = mock(Inflater.class);
                                                   ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                   entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                   
                                                   // Create test instance using reflection to inject mocks
                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                   
                                                   // Set required internal state
                                                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                   infField.setAccessible(true);
                                                   infField.set(zais, mockInf);
                                                   
                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                   currentField.setAccessible(true);
                                                   currentField.set(zais, entry);
                                                   
                                                   Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                   bufField.setAccessible(true);
                                                   bufField.set(zais, new byte[1024]);
                                                   
                                                   // Mock behavior
                                                   when(mockInf.needsInput()).thenReturn(true);
                                                   when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                       .thenThrow(new RuntimeException("Test exception"));
                                                   
                                                   // Create test buffer
                                                   byte[] buffer = new byte[1024];
                                                   
                                                   // This should throw the original RuntimeException, not wrap it
                                                   zais.read(buffer, 0, 1024);
                                               }

 @Test(expected = ZipException.class)
                                              public void testRead_ThrowsZipExceptionOnDataFormatError2() throws Exception {
                                                  // Setup
                                                  InputStream mockInput = mock(InputStream.class);
                                                  Inflater mockInf = mock(Inflater.class);
                                                  ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                  entry.setMethod(ZipArchiveOutputStream.DEFLATED); // Ensure we take the inflation path
                                                  
                                                  // Create instance using reflection to inject our mocks
                                                  ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                  
                                                  // Use reflection to set private fields
                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                  infField.setAccessible(true);
                                                  infField.set(zis, mockInf);
                                                  
                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                  currentField.setAccessible(true);
                                                  currentField.set(zis, entry);
                                                  
                                                  // Mock behavior
                                                  when(mockInf.needsInput()).thenReturn(false);
                                                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                      .thenThrow(new DataFormatException("Corrupted data"));
                                                  
                                                  // Test - this should throw ZipException (original) or IOException (mutant)
                                                  byte[] buffer = new byte[1024];
                                                  zis.read(buffer, 0, 1024);
                                              }

 @Test(expected = ZipException.class)
                                             public void testRead_ThrowsZipExceptionWithOriginalMessage_WhenDataFormatExceptionOccurs() throws Exception {
                                                 // Arrange
                                                 InputStream mockInputStream = mock(InputStream.class);
                                                 Inflater mockInflater = mock(Inflater.class);
                                                 ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                 
                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                 
                                                 // Use reflection to inject mock inflater since it's final
                                                 Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                 inflaterField.setAccessible(true);
                                                 inflaterField.set(zais, mockInflater);
                                                 
                                                 Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                 currentEntryField.setAccessible(true);
                                                 currentEntryField.set(zais, mockEntry);
                                                 
                                                 when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                 when(mockInflater.needsInput()).thenReturn(true);
                                                 
                                                 // Setup to trigger DataFormatException with specific message
                                                 String expectedMessage = "Invalid compression data";
                                                 DataFormatException dfe = new DataFormatException(expectedMessage);
                                                 when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenThrow(dfe);
                                                 
                                                 // Act & Assert
                                                 try {
                                                     zais.read(new byte[10], 0, 10);
                                                 } catch (ZipException ze) {
                                                     // Verify the exception contains the original message
                                                     assertEquals("Exception message should contain original DataFormatException message", 
                                                                 expectedMessage, ze.getMessage());
                                                     throw ze;
                                                 }
                                                 fail("Expected ZipException to be thrown");
                                             }

 @Test(expected = ZipException.class)
                                            public void testRead_ThrowsZipExceptionWhenDataFormatExceptionOccurs2() throws Exception {
                                                // Arrange
                                                InputStream mockInputStream = mock(InputStream.class);
                                                Inflater mockInflater = mock(Inflater.class);
                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                
                                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
                                                
                                                // Use reflection to inject our mock inflater since it's final
                                                Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                inflaterField.setAccessible(true);
                                                inflaterField.set(zis, mockInflater);
                                                
                                                Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                currentEntryField.setAccessible(true);
                                                currentEntryField.set(zis, mockEntry);
                                                
                                                when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                when(mockInflater.needsInput()).thenReturn(false);
                                                doThrow(new DataFormatException("Invalid data format")).when(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                                
                                                byte[] buffer = new byte[1024];
                                                
                                                // Act & Assert
                                                try {
                                                    zis.read(buffer, 0, 1024);
                                                } catch (RuntimeException e) {
                                                    // Additional check to ensure it's not RuntimeException
                                                    fail("Should throw ZipException, not RuntimeException");
                                                }
                                            }

 @Test
                                           public void testReadWithNegativeInflateResult() throws Exception {
                                               // Setup
                                               InputStream mockInput = mock(InputStream.class);
                                               Inflater mockInf = mock(Inflater.class);
                                               ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                               entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                               
                                               // Create test instance using reflection to inject mocks
                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                               infField.setAccessible(true);
                                               infField.set(zais, mockInf);
                                               
                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                               currentField.setAccessible(true);
                                               currentField.set(zais, entry);
                                               
                                               // Mock behavior
                                               when(mockInf.needsInput()).thenReturn(false);
                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                   .thenReturn(-1); // Simulate negative inflate result
                                               
                                               // Test
                                               byte[] buffer = new byte[10];
                                               int result = zais.read(buffer, 0, 10);
                                               
                                               // Verify - original would process negative value, mutant would return -1
                                               assertNotEquals("Should not return -1 for negative inflate result", -1, result);
                                               verify(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                           }

 @Test
                                          public void testReadWithZeroInflateResult1() throws Exception {
                                              // Setup
                                              InputStream mockInput = mock(InputStream.class);
                                              Inflater mockInf = mock(Inflater.class);
                                              ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                              entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                              
                                              // Create instance using reflection to inject mocks
                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                              
                                              // Set current entry and inflater via reflection
                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                              currentField.setAccessible(true);
                                              currentField.set(zais, entry);
                                              
                                              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                              infField.setAccessible(true);
                                              infField.set(zais, mockInf);
                                              
                                              // Mock behavior
                                              when(mockInf.needsInput()).thenReturn(false);
                                              when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                              when(mockInf.finished()).thenReturn(true);
                                              
                                              // Test
                                              byte[] buffer = new byte[10];
                                              int result = zais.read(buffer, 0, 10);
                                              
                                              // Verify
                                              assertEquals("Should return -1 when inflate returns 0 and inflation is finished", -1, result);
                                              
                                              // Test case where inflation isn't finished but returns 0
                                              when(mockInf.finished()).thenReturn(false);
                                              Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                              lengthField.setAccessible(true);
                                              lengthField.set(zais, -1);
                                              
                                              try {
                                                  zais.read(buffer, 0, 10);
                                                  fail("Should have thrown IOException for truncated ZIP file");
                                              } catch (IOException e) {
                                                  assertEquals("Truncated ZIP file", e.getMessage());
                                              }
                                          }

 @Test
                                        public void testReadWithZeroInflateResult2() throws Exception {
                                            // Setup
                                            InputStream mockInput = mock(InputStream.class);
                                            Inflater mockInf = mock(Inflater.class);
                                            ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                            
                                            // Create test instance using reflection to inject mocks
                                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                            Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                            infField.setAccessible(true);
                                            infField.set(zis, mockInf);
                                            
                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                            currentField.setAccessible(true);
                                            currentField.set(zis, mockEntry);
                                            
                                            Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                            bufField.setAccessible(true);
                                            bufField.set(zis, new byte[1024]);
                                            
                                            // Case 1: read=0 but inflater not finished (should continue)
                                            when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                            when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                            when(mockInf.finished()).thenReturn(false);
                                            when(mockInf.needsInput()).thenReturn(false);
                                            
                                            byte[] buffer = new byte[10];
                                            int result = zis.read(buffer, 0, 10);
                                            assertNotEquals("Should not return -1 when inflater returns 0 but isn't finished", -1, result);
                                            
                                            // Case 2: read=0 and inflater finished (should return -1)
                                            when(mockInf.finished()).thenReturn(true);
                                            result = zis.read(buffer, 0, 10);
                                            assertEquals("Should return -1 when inflater returns 0 and is finished", -1, result);
                                            
                                            // Case 3: read=0 with truncated input (should throw IOException)
                                            when(mockInf.finished()).thenReturn(false);
                                            Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                            lengthOfLastReadField.setAccessible(true);
                                            lengthOfLastReadField.set(zis, -1);
                                            
                                            try {
                                                zis.read(buffer, 0, 10);
                                                fail("Should throw IOException when inflater returns 0 with truncated input");
                                            } catch (IOException e) {
                                                assertEquals("Exception message should indicate truncated ZIP file", 
                                                            "Truncated ZIP file", e.getMessage());
                                            }
                                        }

 @Test
                                    public void testRead_ShouldNotReturnNegativeOneWhenInflaterReturnsNegativeOne() throws Exception {
                                        // Setup
                                        InputStream mockInputStream = mock(InputStream.class);
                                        Inflater mockInflater = mock(Inflater.class);
                                        ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                        
                                        // Create test instance using reflection since constructor is complex
                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                        
                                        // Set up internal state via reflection
                                        Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                        infField.setAccessible(true);
                                        infField.set(zais, mockInflater);
                                        
                                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                        currentField.setAccessible(true);
                                        currentField.set(zais, mockEntry);
                                        
                                        Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                        bufField.setAccessible(true);
                                        bufField.set(zais, new byte[1024]);
                                        
                                        // Mock behavior
                                        when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                        when(mockInflater.finished()).thenReturn(false);
                                        when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                            .thenReturn(-1); // Simulate impossible case
                                        
                                        // Test
                                        byte[] buffer = new byte[10];
                                        int result = zais.read(buffer, 0, 10);
                                        
                                        // Verify - original would continue, mutant would return -1
                                        assertNotEquals("Method should not return -1 when inflater returns -1 but isn't finished", 
                                                       -1, result);
                                        
                                        // Verify inflate was called
                                        verify(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                    }

 @Test
                                   public void testReadReturnsMinusOneWhenInflaterFinishes() throws Exception {
                                       // Setup
                                       InputStream mockInput = mock(InputStream.class);
                                       Inflater mockInf = mock(Inflater.class);
                                       ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                       
                                       // Create test instance using reflection to inject mocks
                                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                       
                                       // Set up mocks
                                       when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                       when(mockInf.finished()).thenReturn(true);  // Inflater is finished
                                       when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                       
                                       // Inject mocks into private fields
                                       Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                       infField.setAccessible(true);
                                       infField.set(zais, mockInf);
                                       
                                       Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                       currentField.setAccessible(true);
                                       currentField.set(zais, mockEntry);
                                       
                                       Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                       closedField.setAccessible(true);
                                       closedField.set(zais, false);
                                       
                                       // Test buffer
                                       byte[] buffer = new byte[1024];
                                       
                                       // Execute and verify
                                       int result = zais.read(buffer, 0, buffer.length);
                                       assertEquals("Should return -1 when inflater finishes", -1, result);
                                       
                                       // Verify interaction
                                       verify(mockInf).finished();  // Ensures we check inflater state
                                   }

 @Test
                                  public void testReadReturnsNegativeOneAtEndOfEntry() throws Exception {
                                      // Setup for STORED entry case
                                      ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                      ZipArchiveEntry storedEntry = new ZipArchiveEntry("test");
                                      storedEntry.setMethod(ZipArchiveOutputStream.STORED);
                                      storedEntry.setSize(10);
                                      
                                      // Use reflection to set private fields since we need to simulate specific state
                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                      currentField.setAccessible(true);
                                      currentField.set(zis, storedEntry);
                                      
                                      Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                      readBytesField.setAccessible(true);
                                      readBytesField.set(zis, 10); // Set to equal csize
                                      
                                      byte[] buffer = new byte[10];
                                      int result = zis.read(buffer, 0, 10);
                                      
                                      // Should return -1 for EOF, mutant would return 0
                                      assertEquals("Should return -1 when readBytesOfEntry >= csize", -1, result);
                                      
                                      // Setup for compressed entry case
                                      ZipArchiveEntry compressedEntry = new ZipArchiveEntry("test2");
                                      compressedEntry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                      currentField.set(zis, compressedEntry);
                                      
                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                      infField.setAccessible(true);
                                      Inflater inf = (Inflater) infField.get(zis);
                                      
                                      // Mock the inflater to return finished state
                                      Field finishedField = Inflater.class.getDeclaredField("finished");
                                      finishedField.setAccessible(true);
                                      finishedField.set(inf, true);
                                      
                                      result = zis.read(buffer, 0, 10);
                                      
                                      // Should return -1 when inflater is finished, mutant would return 0
                                      assertEquals("Should return -1 when inflater is finished", -1, result);
                                  }

 @Test
                                 public void testRead_StoredEntry_ReturnsMinusOneWhenEntryFullyRead() throws Exception {
                                     // Setup
                                     InputStream mockInput = mock(InputStream.class);
                                     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                     
                                     // Create test instance using reflection to set internal state
                                     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                     
                                     // Set up stored entry (STORED method)
                                     when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                     when(mockEntry.getSize()).thenReturn(100L); // Entry size is 100 bytes
                                     
                                     // Set internal state to simulate having read all bytes
                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                     currentField.setAccessible(true);
                                     currentField.set(zais, mockEntry);
                                     
                                     Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                     readBytesField.setAccessible(true);
                                     readBytesField.set(zais, 100); // Already read all 100 bytes
                                     
                                     Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                     closedField.setAccessible(true);
                                     closedField.set(zais, false);
                                     
                                     // Create test buffer
                                     byte[] buffer = new byte[10];
                                     
                                     // Test - should return -1 when trying to read past entry size
                                     int result = zais.read(buffer, 0, 10);
                                     
                                     // Verify
                                     assertEquals("Should return -1 when entry fully read", -1, result);
                                 }

 @Test
                                public void testReadShouldNotThrowWhenLengthOfLastReadIsZero() throws Exception {
                                    // Setup
                                    InputStream mockInput = mock(InputStream.class);
                                    Inflater mockInf = mock(Inflater.class);
                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                    
                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                    
                                    // Use reflection to set private fields since we need to test internal behavior
                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                    infField.setAccessible(true);
                                    infField.set(zis, mockInf);
                                    
                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                    currentField.setAccessible(true);
                                    currentField.set(zis, mockEntry);
                                    
                                    Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                    lengthOfLastReadField.setAccessible(true);
                                    lengthOfLastReadField.set(zis, 0); // Critical value for this test
                                    
                                    // Mock behavior
                                    when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                    when(mockInf.needsInput()).thenReturn(false);
                                    when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                    when(mockInf.finished()).thenReturn(false);
                                    
                                    // Test - should not throw in original, but mutant would throw
                                    byte[] buffer = new byte[10];
                                    int result = zis.read(buffer, 0, 10);
                                    
                                    // Verify
                                    assertEquals(0, result); // Expect 0 bytes read, no exception
                                }

 @Test
                               public void testRead_ShouldNotThrowTruncatedWhenValidRead() throws Exception {
                                   // Setup
                                   InputStream mockInput = mock(InputStream.class);
                                   Inflater mockInf = mock(Inflater.class);
                                   ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                   entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                   
                                   // Create test instance using reflection to inject mocks
                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                   infField.setAccessible(true);
                                   infField.set(zais, mockInf);
                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                   currentField.setAccessible(true);
                                   currentField.set(zais, entry);
                                   Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                   lengthOfLastReadField.setAccessible(true);
                                   lengthOfLastReadField.set(zais, 1); // Valid read
                                   
                                   // Mock behavior
                                   when(mockInf.needsInput()).thenReturn(false);
                                   when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                   when(mockInf.finished()).thenReturn(false);
                                   
                                   // Test buffer
                                   byte[] buffer = new byte[10];
                                   
                                   // Test - should not throw exception
                                   int result = zais.read(buffer, 0, 10);
                                   
                                   // Verify
                                   assertEquals(0, result); // Expect 0 read bytes but no exception
                                   verify(mockInf).inflate(buffer, 0, 10);
                                   
                                   // The mutant would throw IOException here
                               }

 @Test(expected = IOException.class)
                              public void testRead_ThrowsIOExceptionOnTruncatedZipFile() throws Exception {
                                  // Arrange
                                  InputStream mockInputStream = mock(InputStream.class);
                                  Inflater mockInflater = mock(Inflater.class);
                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                  
                                  // Create instance using reflection since constructor may be private
                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                  
                                  // Set up mocks to reach the truncated file condition
                                  when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                  when(mockInflater.finished()).thenReturn(false);
                                  when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                  
                                  // Inject mocks into the instance
                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                  infField.setAccessible(true);
                                  infField.set(zais, mockInflater);
                                  
                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                  currentField.setAccessible(true);
                                  currentField.set(zais, mockEntry);
                                  
                                  Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                  lengthOfLastReadField.setAccessible(true);
                                  lengthOfLastReadField.set(zais, -1);
                                  
                                  // Act - should throw IOException for original, RuntimeException for mutant
                                  zais.read(new byte[1024], 0, 1024);
                                  
                                  // Assertion is handled by @Test(expected)
                              }

 @Test
                            public void testRead_ThrowsCorrectTruncatedZipException() throws Exception {
                                // Setup mock objects
                                InputStream mockInput = mock(InputStream.class);
                                Inflater mockInf = mock(Inflater.class);
                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                
                                // Configure mocks
                                when(mockInput.read(any(byte[].class))).thenReturn(-1); // Simulate truncated stream
                                when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                when(mockInf.finished()).thenReturn(false);
                                when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                
                                // Create test instance using reflection to inject mocks
                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                infField.setAccessible(true);
                                infField.set(zis, mockInf);
                                
                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                currentField.setAccessible(true);
                                currentField.set(zis, mockEntry);
                                
                                Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                lengthOfLastReadField.setAccessible(true);
                                lengthOfLastReadField.set(zis, -1);
                                
                                // Prepare test buffer
                                byte[] buffer = new byte[1024];
                                
                                try {
                                    zis.read(buffer, 0, 1024);
                                    fail("Expected IOException not thrown");
                                } catch (IOException e) {
                                    assertEquals("Truncated ZIP file", e.getMessage());
                                    throw e;
                                }
                            }

 @Test(expected = IOException.class)
                        public void testRead_DetectsTruncatedZipFile2() throws Exception {
                            // Arrange
                            InputStream mockInputStream = mock(InputStream.class);
                            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
                            
                            // Use reflection to set internal state since fields are private
                            Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                            infField.setAccessible(true);
                            Inflater inf = (Inflater) infField.get(zis);
                            
                            Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                            lengthOfLastReadField.setAccessible(true);
                            lengthOfLastReadField.set(zis, -1); // Simulate EOF
                            
                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                            currentField.setAccessible(true);
                            currentField.set(zis, new ZipArchiveEntry("test")); // Need a current entry
                            
                            // Mock inflater to return 0 (needs input) but we've already hit EOF
                            when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                            when(inf.finished()).thenReturn(false);
                            
                            // Act
                            byte[] buffer = new byte[1024];
                            zis.read(buffer, 0, 1024); // This should throw IOException for original, return -1 for mutant
                            
                            // Assertion is handled by @Test(expected)
                        }

 @Test
                      public void testReadUpdatesCrcFromCorrectBufferPosition1() throws Exception {
                          // Setup test data with known CRC values
                          byte[] testData = new byte[]{1, 2, 3, 4, 5, 6, 7, 8};
                          byte[] buffer = new byte[10];
                          int startPos = 3;
                          int readLen = 4;
                          
                          // Mock the input stream to return our test data
                          InputStream mockInput = mock(InputStream.class);
                          when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                              byte[] buf = (byte[]) invocation.getArguments()[0];
                              System.arraycopy(testData, 0, buf, 0, testData.length);
                              return testData.length;
                          });
                          
                          // Create ZIP stream with our mock
                          ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                          
                          // Mock the entry to be STORED (simpler to test)
                          ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                          when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                          when(entry.getSize()).thenReturn((long)testData.length);
                          
                          // Use reflection to set private fields for testing
                          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                          currentField.setAccessible(true);
                          currentField.set(zis, entry);
                          
                          Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                          lengthOfLastReadField.setAccessible(true);
                          lengthOfLastReadField.set(zis, testData.length);
                          
                          // Get the CRC object to verify
                          Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                          crcField.setAccessible(true);
                          CRC32 crc = (CRC32) crcField.get(zis);
                          
                          // Perform the read operation
                          int bytesRead = zis.read(buffer, startPos, readLen);
                          
                          // Calculate expected CRC manually
                          CRC32 expectedCrc = new CRC32();
                          expectedCrc.update(buffer, startPos, bytesRead);
                          
                          // Verify CRC was updated with correct buffer segment
                          assertEquals("CRC should be calculated from correct buffer position", 
                                       expectedCrc.getValue(), crc.getValue());
                          
                          // Verify the read operation itself
                          assertEquals("Should read correct number of bytes", readLen, bytesRead);
                          assertArrayEquals("Buffer should contain correct data", 
                                           new byte[]{0, 0, 0, 1, 2, 3, 4, 0, 0, 0}, 
                                           buffer);
                      }

 @Test
                  public void testReadUpdatesCrcCorrectly2() throws Exception {
                      // Setup test data
                      byte[] testData = {1, 2, 3, 4, 5};
                      byte[] buffer = new byte[5];
                      
                      // Mock dependencies
                      InputStream mockInput = mock(InputStream.class);
                      Inflater mockInf = mock(Inflater.class);
                      ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                      CRC32 mockCrc = mock(CRC32.class);
                      
                      // Create test instance using reflection to inject mocks
                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                      
                      // Set up internal state
                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                      infField.setAccessible(true);
                      infField.set(zais, mockInf);
                      
                      Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                      crcField.setAccessible(true);
                      crcField.set(zais, mockCrc);
                      
                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                      currentField.setAccessible(true);
                      currentField.set(zais, mockEntry);
                      
                      // Configure mocks
                      when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(3); // return 3 bytes read
                      when(mockInf.needsInput()).thenReturn(false);
                      when(mockInf.finished()).thenReturn(false);
                      
                      // Execute test
                      int bytesRead = zais.read(buffer, 0, 5);
                      
                      // Verify CRC was updated with exactly the number of bytes read
                      verify(mockCrc).update(buffer, 0, 3); // Should fail if mutant is present (would expect 4)
                      
                      // Additional assertions
                      assertEquals(3, bytesRead);
                  }

 @Test
                public void testReadUpdatesCrcWithCorrectByteCount1() throws Exception {
                    // Setup test data
                    byte[] testData = "Test data for CRC check".getBytes();
                    byte[] buffer = new byte[testData.length];
                    
                    // Mock dependencies
                    InputStream mockInput = mock(InputStream.class);
                    when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                        byte[] buf = (byte[]) invocation.getArguments()[0];
                        System.arraycopy(testData, 0, buf, 0, testData.length);
                        return testData.length;
                    });
                    
                    Inflater inf = new Inflater();
                    CRC32 crc = new CRC32();
                    
                    // Create test instance
                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                    
                    // Use reflection to set private fields for testing
                    Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                    crcField.setAccessible(true);
                    crcField.set(zais, crc);
                    
                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                    infField.setAccessible(true);
                    infField.set(zais, inf);
                    
                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                    currentField.setAccessible(true);
                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                    entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                    currentField.set(zais, entry);
                    
                    // Perform read operation
                    int bytesRead = zais.read(buffer, 0, buffer.length);
                    
                    // Verify CRC was updated with correct byte count
                    long expectedCrcValue = 0;
                    CRC32 expectedCrc = new CRC32();
                    expectedCrc.update(testData, 0, bytesRead);
                    expectedCrcValue = expectedCrc.getValue();
                    
                    assertEquals("CRC should be updated with actual bytes read", 
                               expectedCrcValue, crc.getValue());
                    assertTrue("Should have read some bytes", bytesRead > 0);
                }

 @Test
           public void testReadUpdatesCrcForDeflatedEntry2() throws Exception {
               // Setup test data
               byte[] testData = "Test data for CRC check".getBytes();
               byte[] buffer = new byte[1024];
               
               // Mock dependencies
               InputStream mockInput = mock(InputStream.class);
               Inflater mockInf = mock(Inflater.class);
               ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
               
               // Create instance
               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
               
               // Set private fields using reflection
               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
               infField.setAccessible(true);
               infField.set(zais, mockInf);
               
               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
               currentField.setAccessible(true);
               currentField.set(zais, mockEntry);
               
               Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
               bufField.setAccessible(true);
               bufField.set(zais, new byte[1024]);
               
               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
               crcField.setAccessible(true);
               crcField.set(zais, new CRC32());
               
               // Configure mocks
               when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                   .thenAnswer(invocation -> {
                       byte[] dest = (byte[]) invocation.getArguments()[0];
                       int off = (int) invocation.getArguments()[1];
                       int len = (int) invocation.getArguments()[2];
                       System.arraycopy(testData, 0, dest, off, Math.min(len, testData.length));
                       return testData.length;
                   });
               
               // Get initial CRC value
               CRC32 initialCrc = (CRC32) crcField.get(zais);
               long initialCrcValue = initialCrc.getValue();
               
               // Perform read operation
               int bytesRead = zais.read(buffer, 0, buffer.length);
               
               // Verify results
               assertEquals(testData.length, bytesRead);
               
               // Calculate expected CRC
               CRC32 expectedCrc = new CRC32();
               expectedCrc.update(testData);
               long expectedValue = expectedCrc.getValue();
               
               // Get current CRC value
               CRC32 actualCrc = (CRC32) crcField.get(zais);
               long actualValue = actualCrc.getValue();
               
               // Verify CRC was updated
               assertEquals("CRC should be updated after read", 
                           expectedValue, 
                           actualValue);
               
               // Additional verification that CRC was updated from initial state
               assertTrue("CRC value should change after read", 
                          actualValue != initialCrcValue);
           }

 @Test
      public void testReadReturnsCorrectByteCountForDeflatedEntry() throws Exception {
          // Setup
          InputStream mockInput = mock(InputStream.class);
          Inflater mockInf = mock(Inflater.class);
          ZipArchiveEntry entry = new ZipArchiveEntry("test");
          entry.setMethod(ZipArchiveOutputStream.DEFLATED);
          
          // Create test instance using reflection to inject mocks
          ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
          Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
          infField.setAccessible(true);
          infField.set(zis, mockInf);
          
          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
          currentField.setAccessible(true);
          currentField.set(zis, entry);
          
          // Configure mocks
          when(mockInf.needsInput()).thenReturn(false);
          when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
              .thenAnswer(invocation -> {
                  // Simulate reading 5 bytes
                  return 5;
              });
          
          // Test data
          byte[] buffer = new byte[10];
          int expectedRead = 5;
          
          // Execute
          int actualRead = zis.read(buffer, 0, buffer.length);
          
          // Verify
          assertEquals("Should return exact number of bytes read", 
                      expectedRead, actualRead);
          
          // Verify CRC was updated with correct length
          Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
          crcField.setAccessible(true);
          CRC32 crc = (CRC32) crcField.get(zis);
          verify(crc).update(buffer, 0, expectedRead);
      }

 @Test
  public void testReadDeflatedEntryReturnsActualBytesRead() throws Exception {
      // Setup test data
      byte[] buffer = new byte[1024];
      int start = 0;
      int length = 512;
      
      // Mock dependencies
      InputStream mockInputStream = mock(InputStream.class);
      Inflater mockInflater = mock(Inflater.class);
      ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
      CRC32 mockCrc = mock(CRC32.class);
      
      // Create test instance using reflection to inject mocks
      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
      
      // Set internal state using reflection
      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
      infField.setAccessible(true);
      infField.set(zais, mockInflater);
      
      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
      currentField.setAccessible(true);
      currentField.set(zais, mockEntry);
      
      Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
      crcField.setAccessible(true);
      crcField.set(zais, mockCrc);
      
      Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
      closedField.setAccessible(true);
      closedField.set(zais, false);
      
      // Mock behavior
      when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
      when(mockInflater.needsInput()).thenReturn(false);
      when(mockInflater.inflate(buffer, start, length)).thenReturn(256); // simulate reading 256 bytes
      
      // Test
      int bytesRead = zais.read(buffer, start, length);
      
      // Verify
      assertEquals("Should return actual number of bytes read", 256, bytesRead);
      
      // Verify CRC was updated
      verify(mockCrc).update(buffer, start, 256);
      
      // Verify inflater was called
      verify(mockInflater).inflate(buffer, start, length);
  }

 @Test
 public void testReadWithDeflatedEntryReturnsActualBytesRead() throws Exception {
     // Setup
     InputStream mockInput = mock(InputStream.class);
     Inflater mockInf = mock(Inflater.class);
     ZipArchiveEntry entry = new ZipArchiveEntry("test");
     entry.setMethod(ZipArchiveOutputStream.DEFLATED);
     
     // Create test instance using reflection to inject mocks
     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
     infField.setAccessible(true);
     infField.set(zis, mockInf);
     
     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
     currentField.setAccessible(true);
     currentField.set(zis, entry);
     
     // Mock behavior
     when(mockInf.needsInput()).thenReturn(false);
     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
         .thenReturn(10); // Simulate reading 10 bytes
     
     // Test
     byte[] buffer = new byte[100];
     int bytesRead = zis.read(buffer, 0, 100);
     
     // Verify
     assertEquals("Should return actual bytes read (10)", 10, bytesRead);
     
     // Clean up
     infField.setAccessible(false);
     currentField.setAccessible(false);
 }

}
