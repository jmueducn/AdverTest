package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                 public void testFinish_WithoutUnclosedEntry_WritesTwoEOFRecords() throws Exception {
                                                                     // Arrange
                                                                     OutputStream mockOutputStream = mock(OutputStream.class);
                                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                     
                                                                     // Ensure haveUnclosedEntry is false (should be by default)
                                                                     try {
                                                                         java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                         field.setAccessible(true);
                                                                         field.set(tarOutput, false);
                                                                     } catch (Exception e) {
                                                                         throw new RuntimeException("Failed to set haveUnclosedEntry field", e);
                                                                     }
                                                                     
                                                                     // Act
                                                                     tarOutput.finish();
                                                                     
                                                                     // Assert - verify that finish() results in two writes to the output stream
                                                                     // Each EOF record is 512 bytes (default block size)
                                                                     verify(mockOutputStream, times(2)).write(any(byte[].class), eq(0), eq(512));
                                                                 }

    @Test
                                                                 public void testFinish_WhenAlreadyClosed_DoesNothing() throws Exception {
                                                                     // Arrange
                                                                     OutputStream mockOutputStream = mock(OutputStream.class);
                                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                     
                                                                     // Set closed to true
                                                                     try {
                                                                         java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("closed");
                                                                         field.setAccessible(true);
                                                                         field.set(tarOutput, true);
                                                                     } catch (Exception e) {
                                                                         throw new RuntimeException("Failed to set closed field", e);
                                                                     }
                                                                     
                                                                     // Act
                                                                     tarOutput.finish();
                                                                     
                                                                     // Assert - should not perform any writes when already closed
                                                                     verify(mockOutputStream, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                 }

    @Test
                                                                 public void testPutArchiveEntry_ShortFileName() throws Exception {
                                                                     // Setup
                                                                     OutputStream os = new ByteArrayOutputStream();
                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                     tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
                                                                     
                                                                     TarArchiveEntry entry = new TarArchiveEntry("short.txt");
                                                                     entry.setSize(100);
                                                                     
                                                                     // Test
                                                                     tarOut.putArchiveEntry(entry);
                                                                     
                                                                     // Verify using reflection to access private fields
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     boolean haveUnclosedEntry = (boolean) haveUnclosedEntryField.get(tarOut);
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     long currSize = (long) currSizeField.get(tarOut);
                                                                     
                                                                     Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                     currNameField.setAccessible(true);
                                                                     String currName = (String) currNameField.get(tarOut);
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     long currBytes = (long) currBytesField.get(tarOut);
                                                                     
                                                                     assertFalse(haveUnclosedEntry);
                                                                     assertEquals(100, currSize);
                                                                     assertEquals("short.txt", currName);
                                                                     assertEquals(0, currBytes);
                                                                 }

    @Test
                                                                 public void testPutArchiveEntry_LongFileName_GnuMode() throws Exception {
                                                                     // Setup
                                                                     OutputStream os = new ByteArrayOutputStream();
                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                     tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
                                                                     
                                                                     // Create a very long filename
                                                                     StringBuilder longName = new StringBuilder();
                                                                     for (int i = 0; i < TarConstants.NAMELEN + 10; i++) {
                                                                         longName.append('a');
                                                                     }
                                                                     TarArchiveEntry entry = new TarArchiveEntry(longName.toString());
                                                                     entry.setSize(200);
                                                                     
                                                                     // Test
                                                                     tarOut.putArchiveEntry(entry);
                                                                     
                                                                     // Verify using reflection
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     assertTrue((boolean) haveUnclosedEntryField.get(tarOut));
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     assertEquals(200L, currSizeField.get(tarOut));
                                                                     
                                                                     Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                     currNameField.setAccessible(true);
                                                                     assertEquals(longName.toString(), currNameField.get(tarOut));
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     assertEquals(0L, currBytesField.get(tarOut));
                                                                 }

    @Test
                                                                 public void testPutArchiveEntry_LongFileName_TruncateMode() throws Exception {
                                                                     // Setup
                                                                     OutputStream os = new ByteArrayOutputStream();
                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                     tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_TRUNCATE);
                                                                     
                                                                     // Create a very long filename
                                                                     StringBuilder longName = new StringBuilder();
                                                                     for (int i = 0; i < TarConstants.NAMELEN + 10; i++) {
                                                                         longName.append('a');
                                                                     }
                                                                     TarArchiveEntry entry = new TarArchiveEntry(longName.toString());
                                                                     entry.setSize(300);
                                                                     
                                                                     // Test
                                                                     tarOut.putArchiveEntry(entry);
                                                                     
                                                                     // Verify using reflection
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     assertTrue((boolean) haveUnclosedEntryField.get(tarOut));
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     assertEquals(300L, currSizeField.get(tarOut));
                                                                     
                                                                     Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                     currNameField.setAccessible(true);
                                                                     String currName = (String) currNameField.get(tarOut);
                                                                     assertTrue(currName.length() <= TarConstants.NAMELEN);
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     assertEquals(0L, currBytesField.get(tarOut));
                                                                 }

    @Test
                                                                 public void testPutArchiveEntry_Directory() throws Exception {
                                                                     // Setup
                                                                     OutputStream os = new ByteArrayOutputStream();
                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                     
                                                                     TarArchiveEntry entry = new TarArchiveEntry("directory/");
                                                                     entry.setSize(500); // Size should be ignored for directories
                                                                     
                                                                     // Test
                                                                     tarOut.putArchiveEntry(entry);
                                                                     
                                                                     // Verify using reflection
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     assertTrue((boolean) haveUnclosedEntryField.get(tarOut));
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     assertEquals(0, currSizeField.get(tarOut));
                                                                     
                                                                     Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                     currNameField.setAccessible(true);
                                                                     assertEquals("directory/", currNameField.get(tarOut));
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     assertEquals(0, currBytesField.get(tarOut));
                                                                 }

    @Test
                                                                 public void testCloseArchiveEntry_WithExactByteCount() throws Exception {
                                                                     // Setup
                                                                     ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(out);
                                                                     
                                                                     // Use reflection to set private fields
                                                                     Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                     assemLenField.setAccessible(true);
                                                                     assemLenField.set(tarOutput, 0);
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     currBytesField.set(tarOutput, 500L);
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     currSizeField.set(tarOutput, 500L);
                                                                     
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     haveUnclosedEntryField.set(tarOutput, true);
                                                                     
                                                                     // Execute
                                                                     tarOutput.closeArchiveEntry();
                                                                     
                                                                     // Verify
                                                                     assertFalse((boolean) haveUnclosedEntryField.get(tarOutput));
                                                                     assertEquals(500L, currBytesField.get(tarOutput));
                                                                 }

    @Test
                                                                 public void testCloseArchiveEntry_WithEmptyEntry() throws Exception {
                                                                     // Setup
                                                                     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                     
                                                                     // Use reflection to access private fields
                                                                     Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                     assemLenField.setAccessible(true);
                                                                     assemLenField.set(tarOutput, 0);
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     currBytesField.set(tarOutput, 0L);
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     currSizeField.set(tarOutput, 0L);
                                                                     
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     haveUnclosedEntryField.set(tarOutput, true);
                                                                     
                                                                     // Execute
                                                                     tarOutput.closeArchiveEntry();
                                                                     
                                                                     // Verify
                                                                     assertFalse(haveUnclosedEntryField.getBoolean(tarOutput));
                                                                     assertEquals(0L, currBytesField.getLong(tarOutput));
                                                                 }

    @Test
                                                                 public void testCloseArchiveEntry_WithPartialBufferAndCompleteEntry() throws Exception {
                                                                     // Setup
                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                     TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOut);
                                                                     
                                                                     // Use reflection to access private fields
                                                                     Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                     assemBufField.setAccessible(true);
                                                                     byte[] assemBuf = new byte[512];
                                                                     assemBufField.set(tarOutput, assemBuf);
                                                                     
                                                                     // Fill first 100 bytes with test data
                                                                     for (int i = 0; i < 100; i++) {
                                                                         assemBuf[i] = (byte)(i % 128);
                                                                     }
                                                                     
                                                                     Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                     assemLenField.setAccessible(true);
                                                                     assemLenField.set(tarOutput, 100);
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     currBytesField.set(tarOutput, 412L); // 512 total when adding 100
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     currSizeField.set(tarOutput, 512L);
                                                                     
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     haveUnclosedEntryField.set(tarOutput, true);
                                                                     
                                                                     // Execute
                                                                     tarOutput.closeArchiveEntry();
                                                                     
                                                                     // Verify
                                                                     // Check buffer was zero-padded
                                                                     for (int i = 100; i < assemBuf.length; i++) {
                                                                         assertEquals(0, assemBuf[i]);
                                                                     }
                                                                     
                                                                     // Verify fields were updated correctly
                                                                     assertEquals(512L, currBytesField.get(tarOutput));
                                                                     assertEquals(0, assemLenField.get(tarOutput));
                                                                     assertFalse((Boolean)haveUnclosedEntryField.get(tarOutput));
                                                                 }

    @Test
                                                             public void testFinish_WithUnclosedEntry_ThrowsIOException() throws Exception {
                                                                 // Arrange
                                                                 OutputStream mockOutputStream = mock(OutputStream.class);
                                                                 TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                 
                                                                 // Use reflection to set the private haveUnclosedEntry field to true
                                                                 // This is necessary to test the exception case
                                                                 try {
                                                                     java.lang.reflect.Field field = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     field.setAccessible(true);
                                                                     field.set(tarOutput, true);
                                                                 } catch (Exception e) {
                                                                     throw new RuntimeException("Failed to set haveUnclosedEntry field", e);
                                                                 }
                                                                 
                                                                 // Expect exception
                                                                 try {
                                                                     tarOutput.finish();
                                                                     fail("Expected IOException to be thrown");
                                                                 } catch (IOException e) {
                                                                     assertEquals("This archives contains unclosed entries.", e.getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testPutArchiveEntry_LongFileName_ErrorMode() throws Exception {
                                                                 // Setup
                                                                 OutputStream os = new ByteArrayOutputStream();
                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                 tarOut.setLongFileMode(TarArchiveOutputStream.LONGFILE_ERROR);
                                                                 
                                                                 // Create a very long filename
                                                                 StringBuilder longName = new StringBuilder();
                                                                 for (int i = 0; i < 100 + 10; i++) { // Using 100 as NAMELEN since TarConstants isn't available
                                                                     longName.append('a');
                                                                 }
                                                                 TarArchiveEntry entry = new TarArchiveEntry(longName.toString());
                                                                 
                                                                 // Test and verify exception
                                                                 try {
                                                                     tarOut.putArchiveEntry(entry);
                                                                     fail("Expected RuntimeException for long file name");
                                                                 } catch (RuntimeException e) {
                                                                     assertEquals("file name '" + longName.toString() + "' is too long ( > " + 100 + " bytes)", 
                                                                                 e.getMessage());
                                                                 }
                                                             }

    @Test
                                                             public void testPutArchiveEntry_NullEntry() throws Exception {
                                                                 // Setup
                                                                 OutputStream os = new ByteArrayOutputStream();
                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                 
                                                                 // Expect exception
                                                                 org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                                 expectedException.expect(NullPointerException.class);
                                                                 expectedException.expectMessage("entry");
                                                                 
                                                                 // Test
                                                                 tarOut.putArchiveEntry(null);
                                                             }

    @Test
                                                             public void testPutArchiveEntry_ClosedStream() throws Exception {
                                                                 // Setup
                                                                 OutputStream os = new ByteArrayOutputStream();
                                                                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os);
                                                                 tarOut.close();
                                                                 
                                                                 TarArchiveEntry entry = new TarArchiveEntry("test.txt");
                                                                 
                                                                 // Expect exception
                                                                 ExpectedException expectedException = ExpectedException.none();
                                                                 expectedException.expect(IOException.class);
                                                                 expectedException.expectMessage("Stream has already been finished");
                                                                 
                                                                 // Test
                                                                 tarOut.putArchiveEntry(entry);
                                                             }

    @Test
                                                             public void testCloseArchiveEntry_WithAssembledData() throws Exception {
                                                                 // Setup
                                                                 ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                 TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(out);
                                                                 
                                                                 // Use reflection to access private fields
                                                                 Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                 assemBufField.setAccessible(true);
                                                                 byte[] assemBuf = new byte[512];
                                                                 assemBufField.set(tarOutput, assemBuf);
                                                                 
                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                 assemLenField.setAccessible(true);
                                                                 assemLenField.set(tarOutput, 100);
                                                                 
                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                 currBytesField.setAccessible(true);
                                                                 currBytesField.set(tarOutput, 500L);
                                                                 
                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                 currSizeField.setAccessible(true);
                                                                 currSizeField.set(tarOutput, 500L);
                                                                 
                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                 haveUnclosedEntryField.set(tarOutput, true);
                                                                 
                                                                 // Instead of mocking TarBuffer, we'll work with the real one created by the constructor
                                                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                 bufferField.setAccessible(true);
                                                                 
                                                                 // Execute
                                                                 tarOutput.closeArchiveEntry();
                                                                 
                                                                 // Verify
                                                                 // Check that remaining buffer was zeroed out
                                                                 for (int i = 100; i < assemBuf.length; i++) {
                                                                     assertEquals(0, assemBuf[i]);
                                                                 }
                                                                 // Verify the output contains the expected data
                                                                 byte[] output = out.toByteArray();
                                                                 assertTrue(output.length >= 512); // At least one record should be written
                                                                 assertEquals(600L, currBytesField.get(tarOutput)); // 500 + 100
                                                                 assertEquals(0, assemLenField.get(tarOutput));
                                                                 assertFalse((Boolean)haveUnclosedEntryField.get(tarOutput));
                                                             }

    @Test
                                                             public void testCloseArchiveEntry_WithoutAssembledData() throws Exception {
                                                                 // Setup
                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                 TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOut);
                                                                 
                                                                 // Use reflection to set private fields
                                                                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                 bufferField.setAccessible(true);
                                                                 Object buffer = bufferField.get(tarOutput);  // Get the real buffer instance
                                                                 
                                                                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                 assemLenField.setAccessible(true);
                                                                 assemLenField.set(tarOutput, 0);
                                                                 
                                                                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                 currBytesField.setAccessible(true);
                                                                 currBytesField.set(tarOutput, 500L);
                                                                 
                                                                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                 currSizeField.setAccessible(true);
                                                                 currSizeField.set(tarOutput, 500L);
                                                                 
                                                                 Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                 haveUnclosedEntryField.setAccessible(true);
                                                                 haveUnclosedEntryField.set(tarOutput, true);
                                                                 
                                                                 // Execute
                                                                 tarOutput.closeArchiveEntry();
                                                                 
                                                                 // Verify
                                                                 // We can't verify buffer writes directly, but we can verify the state changes
                                                                 assertEquals(500L, currBytesField.get(tarOutput));
                                                                 assertEquals(0, assemLenField.get(tarOutput));
                                                                 assertFalse(haveUnclosedEntryField.getBoolean(tarOutput));
                                                             }

    @Test(expected = IOException.class)
                                                             public void testCloseArchiveEntry_ThrowsWhenIncomplete() throws IOException {
                                                                 // Setup
                                                                 ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                 TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(bos);
                                                                 
                                                                 // Use reflection to set private fields since they're not publicly accessible
                                                                 try {
                                                                     Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                     currNameField.setAccessible(true);
                                                                     currNameField.set(tarOutput, "test.txt");
                                                                     
                                                                     Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                     currBytesField.setAccessible(true);
                                                                     currBytesField.set(tarOutput, 499L);
                                                                     
                                                                     Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                     currSizeField.setAccessible(true);
                                                                     currSizeField.set(tarOutput, 500L);
                                                                     
                                                                     Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                                     haveUnclosedEntryField.setAccessible(true);
                                                                     haveUnclosedEntryField.set(tarOutput, true);
                                                                 } catch (Exception e) {
                                                                     throw new RuntimeException("Failed to set up test via reflection", e);
                                                                 }
                                                                 
                                                                 // Execute and verify exception
                                                                 try {
                                                                     tarOutput.closeArchiveEntry();
                                                                 } catch (IOException e) {
                                                                     assertEquals("entry 'test.txt' closed at '499' before the '500' bytes specified in the header were written", 
                                                                         e.getMessage());
                                                                     throw e;
                                                                 }
                                                             }

    @Test
                                                    public void testCloseArchiveEntryWithZeroAssemLen() throws Exception {
                                                        // Setup
                                                        OutputStream mockOut = mock(OutputStream.class);
                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                        
                                                        // Use reflection to access private fields
                                                        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                        assemLenField.setAccessible(true);
                                                        assemLenField.set(tarOut, 0);
                                                        
                                                        Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                        assemBufField.setAccessible(true);
                                                        byte[] originalAssemBuf = new byte[512];
                                                        byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                        System.arraycopy(assemBuf, 0, originalAssemBuf, 0, assemBuf.length);
                                                        
                                                        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                        currBytesField.setAccessible(true);
                                                        currBytesField.set(tarOut, 100L);
                                                        long originalCurrBytes = 100L;
                                                        
                                                        Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                        currSizeField.setAccessible(true);
                                                        currSizeField.set(tarOut, 100L);
                                                        
                                                        // Execute
                                                        tarOut.closeArchiveEntry();
                                                        
                                                        // Verify output stream was NOT written to (since assemLen is 0)
                                                        verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                        
                                                        // Verify assemBuf was NOT modified
                                                        byte[] currentAssemBuf = (byte[]) assemBufField.get(tarOut);
                                                        assertArrayEquals(originalAssemBuf, currentAssemBuf);
                                                        
                                                        // Verify currBytes was NOT incremented
                                                        assertEquals(originalCurrBytes, currBytesField.get(tarOut));
                                                        
                                                        // Verify state was properly cleared
                                                        assertEquals(0, assemLenField.get(tarOut));
                                                        
                                                        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                                        haveUnclosedEntryField.setAccessible(true);
                                                        assertFalse(haveUnclosedEntryField.getBoolean(tarOut));
                                                    }

    @Test
                                               public void testCloseArchiveEntry_shouldPadRemainingBufferWithZeros() throws Exception {
                                                   // Setup test data
                                                   int recordSize = 512; // Typical tar record size
                                                   byte[] testData = new byte[100]; // Partial data (less than full record)
                                                   java.util.Arrays.fill(testData, (byte) 0xAA); // Fill with some test pattern
                                                   
                                                   // Create instance and set state
                                                   ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                   
                                                   // Use reflection to access private fields since we need to test internal behavior
                                                   Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                   assemBufField.setAccessible(true);
                                                   byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                   
                                                   Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                   assemLenField.setAccessible(true);
                                                   
                                                   // Set up partial data in assembly buffer
                                                   System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                                                   assemLenField.set(tarOut, testData.length);
                                                   
                                                   // Set other required fields
                                                   Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                   currSizeField.setAccessible(true);
                                                   currSizeField.set(tarOut, (long) testData.length); // Set to match written bytes
                                                   
                                                   // Call method under test
                                                   tarOut.closeArchiveEntry();
                                                   
                                                   // Verify the padding was done with zeros by checking the output stream
                                                   byte[] output = baos.toByteArray();
                                                   assertEquals(recordSize, output.length); // Should have written one full record
                                                   
                                                   // First part should match our test data
                                                   for (int i = 0; i < testData.length; i++) {
                                                       assertEquals(testData[i], output[i]);
                                                   }
                                                   
                                                   // Remainder should be zeros
                                                   for (int i = testData.length; i < output.length; i++) {
                                                       assertEquals(0, output[i]);
                                                   }
                                               }

    @Test
                                          public void testCloseArchiveEntryAccumulatesAssemLen() throws Exception {
                                              // Setup
                                              OutputStream mockOut = mock(OutputStream.class);
                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                              
                                              // Get field references via reflection
                                              Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                              currBytesField.setAccessible(true);
                                              Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                              assemLenField.setAccessible(true);
                                              Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                              assemBufField.setAccessible(true);
                                              Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                              currSizeField.setAccessible(true);
                                              Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                                              haveUnclosedEntryField.setAccessible(true);
                                              
                                              // Set initial state
                                              currBytesField.set(tarOut, 100L);  // Initial value
                                              assemLenField.set(tarOut, 50);     // First assembly length
                                              assemBufField.set(tarOut, new byte[512]); // Need to initialize array
                                              currSizeField.set(tarOut, 200L);   // Set to avoid exception
                                              
                                              // First call - should add 50 to currBytes (original) or set to 50 (mutant)
                                              tarOut.closeArchiveEntry();
                                              
                                              // Prepare for second call
                                              assemLenField.set(tarOut, 30);     // Second assembly length
                                              haveUnclosedEntryField.set(tarOut, true); // Reset flag since closeArchiveEntry sets it to false
                                              
                                              // Second call - should add 30 (original: 150 total) or set to 30 (mutant)
                                              tarOut.closeArchiveEntry();
                                              
                                              // Verify
                                              // Original would be 100 + 50 + 30 = 180
                                              // Mutant would be just 30 (last assemLen)
                                              assertEquals("currBytes should accumulate assemLen values", 180L, currBytesField.get(tarOut));
                                              
                                              // Verify buffer was written twice (once per call)
                                              verify(mockOut, times(2)).write(any(byte[].class), anyInt(), anyInt());
                                          }

    @Test
                                     public void testCloseArchiveEntry_ResetsAssemLenToZero() throws IOException, NoSuchFieldException, IllegalAccessException {
                                         // Setup
                                         OutputStream mockOutputStream = mock(OutputStream.class);
                                         
                                         // Create instance - we'll use the real buffer implementation
                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOutputStream);
                                         
                                         // Set private fields needed for test
                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                         assemLenField.setAccessible(true);
                                         assemLenField.set(tarOut, 10); // Set initial assemLen > 0
                                         
                                         Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                         assemBufField.setAccessible(true);
                                         assemBufField.set(tarOut, new byte[512]); // Default record size
                                         
                                         // Execute
                                         tarOut.closeArchiveEntry();
                                         
                                         // Verify
                                         assertEquals("assemLen should be reset to 0 after closing entry", 
                                                     0, assemLenField.getInt(tarOut));
                                         
                                         // Verify buffer interaction through the mock output stream
                                         // Since we can't mock TarBuffer, we verify the output stream was written to
                                         verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                     }

    @Test
                                public void testCloseArchiveEntry_ShouldZeroOutRemainingBuffer() throws IOException, NoSuchFieldException, IllegalAccessException {
                                    // Setup
                                    ByteArrayOutputStream mockOut = new ByteArrayOutputStream();
                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                    
                                    // Use reflection to access private fields since we need to test internal behavior
                                    Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                    assemBufField.setAccessible(true);
                                    byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                    
                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                    assemLenField.setAccessible(true);
                                    assemLenField.set(tarOut, 10); // Set partial buffer usage
                                    
                                    // Initialize buffer with non-zero values
                                    java.util.Arrays.fill(assemBuf, (byte) 0x55);
                                    
                                    // Act
                                    tarOut.closeArchiveEntry();
                                    
                                    // Assert
                                    // Check that remaining buffer was zeroed out (10 to end)
                                    for (int i = 10; i < assemBuf.length; i++) {
                                        assertEquals("Buffer position " + i + " should be zero", 0, assemBuf[i]);
                                    }
                                    
                                    // Also verify the buffer written to output (optional)
                                    byte[] writtenData = mockOut.toByteArray();
                                    for (int i = 10; i < assemBuf.length; i++) {
                                        if (writtenData.length > i) {
                                            assertEquals("Output position " + i + " should be zero", 0, writtenData[i]);
                                        }
                                    }
                                }

    @Test
                       public void testCloseArchiveEntry_ResetsAssemLenToZero1() throws Exception {
                           // Setup
                           ByteArrayOutputStream out = new ByteArrayOutputStream();
                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                           
                           // Get assemBuf field via reflection
                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                           assemBufField.setAccessible(true);
                           byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                           
                           // Set initial state where we have some assembled data
                           byte[] testData = new byte[10];
                           java.util.Arrays.fill(testData, (byte)1);
                           System.arraycopy(testData, 0, assemBuf, 0, testData.length);
                           
                           // Use reflection to set private fields since they're not accessible directly
                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                           assemLenField.setAccessible(true);
                           assemLenField.set(tarOut, testData.length); // assemLen = 10
                           
                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                           currBytesField.setAccessible(true);
                           currBytesField.set(tarOut, testData.length); // currBytes = 10
                           
                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                           currSizeField.setAccessible(true);
                           currSizeField.set(tarOut, testData.length); // currSize = 10
                           
                           // Execute
                           tarOut.closeArchiveEntry();
                           
                           // Verify
                           int finalAssemLen = (int) assemLenField.get(tarOut);
                           assertEquals("assemLen should be reset to 0", 0, finalAssemLen);
                           
                           // Clean up
                           tarOut.close();
                       }

    @Test
                  public void testCloseArchiveEntry_ResetsAssemLen() throws Exception {
                      // Setup
                      ByteArrayOutputStream out = new ByteArrayOutputStream();
                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out);
                      
                      // Use reflection to access private fields since we need to test internal state
                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                      assemLenField.setAccessible(true);
                      
                      // Set initial state with non-zero assemLen
                      assemLenField.set(tarOut, 10);
                      
                      // Set other required fields to avoid NPE
                      Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                      assemBufField.setAccessible(true);
                      byte[] testBuf = new byte[512]; // Default record size
                      assemBufField.set(tarOut, testBuf);
                      
                      Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                      bufferField.setAccessible(true);
                      // Don't mock TarBuffer since it's not accessible, just use the real one
                      
                      // Set currSize to match currBytes to avoid exception
                      Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                      currBytesField.setAccessible(true);
                      currBytesField.set(tarOut, 100L);
                      
                      Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                      currSizeField.setAccessible(true);
                      currSizeField.set(tarOut, 100L);
                      
                      // Execute
                      tarOut.closeArchiveEntry();
                      
                      // Verify
                      assertEquals("assemLen should be reset to 0", 0, assemLenField.get(tarOut));
                      
                      // Clean up
                      assemLenField.setAccessible(false);
                      assemBufField.setAccessible(false);
                      bufferField.setAccessible(false);
                      currBytesField.setAccessible(false);
                      currSizeField.setAccessible(false);
                  }

    @Test(expected = IOException.class)
             public void testCloseArchiveEntry_ThrowsIOExceptionWhenEntryNotFullyWritten() throws Exception {
                 // Setup
                 OutputStream mockOut = mock(OutputStream.class);
                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                 
                 // Create a mock entry
                 TarArchiveEntry entry = new TarArchiveEntry("testEntry");
                 entry.setSize(100L);  // Expected size
                 
                 // Put the entry into the stream
                 tarOut.putArchiveEntry(entry);
                 
                 // Write only 50 bytes (less than expected)
                 byte[] data = new byte[50];
                 tarOut.write(data);
                 
                 // This should throw IOException
                 tarOut.closeArchiveEntry();
             }

    @Test
             public void testCloseArchiveEntry_ExceptionMessageWhenEntryNotFullyWritten() throws Exception {
                 // Setup
                 OutputStream mockOut = mock(OutputStream.class);
                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                 
                 // Create and put archive entry
                 String entryName = "partialEntry";
                 long expectedSize = 200L;
                 TarArchiveEntry entry = new TarArchiveEntry(entryName);
                 entry.setSize(expectedSize);
                 tarOut.putArchiveEntry(entry);
                 
                 // Write partial data
                 byte[] data = new byte[150];
                 tarOut.write(data);
                 
                 try {
                     tarOut.closeArchiveEntry();
                     fail("Expected IOException to be thrown");
                 } catch (IOException e) {
                     // Verify exact exception message
                     String expectedMsg = "entry '" + entryName + "' closed at '150' before the '200' bytes specified in the header were written";
                     assertEquals(expectedMsg, e.getMessage());
                 } catch (RuntimeException e) {
                     fail("Expected IOException but got RuntimeException: " + e.getClass());
                 }
             }

    @Test(expected = IOException.class)
        public void testCloseArchiveEntry_throwsCorrectExceptionMessage() throws IOException {
            // Create output stream
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(bos);
            
            // Use reflection to set private fields
            try {
                Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                currNameField.setAccessible(true);
                currNameField.set(tarOutput, "testEntry");
                
                Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                currSizeField.setAccessible(true);
                currSizeField.set(tarOutput, 100L);
                
                Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                currBytesField.setAccessible(true);
                currBytesField.set(tarOutput, 50L);
                
                Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
                haveUnclosedEntryField.setAccessible(true);
                haveUnclosedEntryField.set(tarOutput, true);
            } catch (Exception e) {
                fail("Failed to set up test conditions via reflection: " + e.getMessage());
            }
            
            try {
                tarOutput.closeArchiveEntry();
                fail("Expected IOException to be thrown");
            } catch (IOException e) {
                // Verify the exact error message
                String expectedMsg = "entry 'testEntry' closed at '50' before the '100' bytes specified in the header were written";
                assertEquals("Exception message should match exactly", expectedMsg, e.getMessage());
                throw e;
            }
        }

    @Test
    public void testCloseArchiveEntry_successfulClose() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Setup output stream
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(out);
        
        // Create and add test entry
        TarArchiveEntry entry = new TarArchiveEntry("testEntry");
        entry.setSize(100L);
        tarOutput.putArchiveEntry(entry);
        
        // Write test data (100 bytes)
        byte[] testData = new byte[100];
        tarOutput.write(testData);
        
        // Close the entry
        tarOutput.closeArchiveEntry();
        
        // Verify state after close using reflection
        Field haveUnclosedEntryField = TarArchiveOutputStream.class.getDeclaredField("haveUnclosedEntry");
        haveUnclosedEntryField.setAccessible(true);
        boolean haveUnclosedEntry = haveUnclosedEntryField.getBoolean(tarOutput);
        assertFalse("haveUnclosedEntry should be false after close", haveUnclosedEntry);
        
        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
        assemLenField.setAccessible(true);
        int assemLen = assemLenField.getInt(tarOutput);
        assertEquals("assemLen should be reset to 0", 0, assemLen);
    }


}
