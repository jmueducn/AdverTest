package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_WithNoDataWritten() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       OutputStream mockOs = mock(OutputStream.class);
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOs);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertEquals(0, bytesWritten);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_AfterWritingData() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                       byte[] testData = "Test data".getBytes();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertEquals(testData.length, bytesWritten);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_AfterMultipleWrites() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                       byte[] data1 = "First part".getBytes();
                                                                                                                                                                                                                       byte[] data2 = "Second part".getBytes();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       tarOut.write(data1, 0, data1.length);
                                                                                                                                                                                                                       tarOut.write(data2, 0, data2.length);
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertEquals(data1.length + data2.length, bytesWritten);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_AfterArchiveEntryOperations() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                       ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                                                                       byte[] testData = "Entry data".getBytes();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       tarOut.putArchiveEntry(mockEntry);
                                                                                                                                                                                                                       tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                       tarOut.closeArchiveEntry();
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertTrue(bytesWritten > testData.length); // Should include tar headers
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_AfterFinish() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                       byte[] testData = "Test data".getBytes();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                       tarOut.finish();
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertTrue(bytesWritten > testData.length); // Should include EOF records
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_AfterClose() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                       byte[] testData = "Test data".getBytes();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                       tarOut.close();
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertEquals(testData.length, bytesWritten);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testGetBytesWritten_WithDifferentBlockSizes() throws Exception {
                                                                                                                                                                                                                       // Arrange
                                                                                                                                                                                                                       ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                       int blockSize = 1024; // Different from default
                                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos, blockSize);
                                                                                                                                                                                                                       byte[] testData = "Test data".getBytes();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Act
                                                                                                                                                                                                                       tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                                                       long bytesWritten = tarOut.getBytesWritten();
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Assert
                                                                                                                                                                                                                       assertEquals(testData.length, bytesWritten);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                           public void testGetCount_WhenNoBytesWritten() {
                                                                                                                                                                                                               // Create a new output stream (we can use ByteArrayOutputStream since we're not actually writing to a file)
                                                                                                                                                                                                               OutputStream os = new ByteArrayOutputStream();
                                                                                                                                                                                                               // Create the TarArchiveOutputStream instance
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(os);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // When no bytes have been written
                                                                                                                                                                                                               assertEquals(0, tarOutputStream.getCount());
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterWritingSingleByte() throws IOException {
                                                                                                                                                                                                               // Create a ByteArrayOutputStream to capture the tar output
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               // Create the TarArchiveOutputStream to test
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Write a single byte
                                                                                                                                                                                                               byte[] data = {0x01};
                                                                                                                                                                                                               tarOutputStream.write(data, 0, 1);
                                                                                                                                                                                                               
                                                                                                                                                                                                               assertEquals(1, tarOutputStream.getCount());
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Clean up
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterWritingMultipleBytes() throws IOException {
                                                                                                                                                                                                               // Create a ByteArrayOutputStream to capture the output
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               // Create the TarArchiveOutputStream with default parameters
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Write multiple bytes
                                                                                                                                                                                                               byte[] data = {0x01, 0x02, 0x03, 0x04};
                                                                                                                                                                                                               tarOutputStream.write(data, 0, data.length);
                                                                                                                                                                                                               
                                                                                                                                                                                                               assertEquals(4, tarOutputStream.getCount());
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Clean up
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterWritingLargeAmountOfData() throws IOException {
                                                                                                                                                                                                               // Create a mock OutputStream
                                                                                                                                                                                                               OutputStream mockOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create a TarArchiveOutputStream instance
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Write a large amount of data (more than Integer.MAX_VALUE)
                                                                                                                                                                                                               // Note: This test is theoretical since we can't actually write that much in a test
                                                                                                                                                                                                               // We'll mock the getBytesWritten() method to return a large value
                                                                                                                                                                                                               
                                                                                                                                                                                                               TarArchiveOutputStream spy = spy(tarOutputStream);
                                                                                                                                                                                                               when(spy.getBytesWritten()).thenReturn((long)Integer.MAX_VALUE + 100L);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Should return Integer.MAX_VALUE due to integer overflow
                                                                                                                                                                                                               assertEquals(Integer.MAX_VALUE, spy.getCount());
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterClosingStream() throws IOException {
                                                                                                                                                                                                               // Create a temporary output stream to write to
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               // Initialize the TarArchiveOutputStream
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Write some data
                                                                                                                                                                                                               byte[] data = {0x01, 0x02, 0x03};
                                                                                                                                                                                                               tarOutputStream.write(data, 0, data.length);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Close the stream
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Should still return the count after closing
                                                                                                                                                                                                               assertEquals(3, tarOutputStream.getCount());
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterFinishing() throws IOException {
                                                                                                                                                                                                               // Create a byte array output stream to write to
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create the tar output stream
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Write some data
                                                                                                                                                                                                               byte[] data = {0x01, 0x02};
                                                                                                                                                                                                               tarOutputStream.write(data, 0, data.length);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Finish the stream
                                                                                                                                                                                                               tarOutputStream.finish();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Should still return the count after finishing
                                                                                                                                                                                                               assertEquals(2, tarOutputStream.getCount());
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Clean up
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_WithMultipleWriteOperations() throws IOException {
                                                                                                                                                                                                               // Create a ByteArrayOutputStream to write to
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               // Create the TarArchiveOutputStream instance
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // First write
                                                                                                                                                                                                               byte[] data1 = {0x01, 0x02};
                                                                                                                                                                                                               tarOutputStream.write(data1, 0, data1.length);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Second write
                                                                                                                                                                                                               byte[] data2 = {0x03, 0x04, 0x05};
                                                                                                                                                                                                               tarOutputStream.write(data2, 0, data2.length);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Should return the total count
                                                                                                                                                                                                               assertEquals(5, tarOutputStream.getCount());
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Clean up
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_WithZeroLengthWrite() throws IOException {
                                                                                                                                                                                                               // Create a dummy output stream
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               // Create TarArchiveOutputStream instance
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Write with zero length
                                                                                                                                                                                                               byte[] data = {0x01, 0x02};
                                                                                                                                                                                                               tarOutputStream.write(data, 0, 0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               assertEquals(0, tarOutputStream.getCount());
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterPutArchiveEntry() throws IOException {
                                                                                                                                                                                                               // Create a ByteArrayOutputStream to write to
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create a TarArchiveOutputStream with the ByteArrayOutputStream
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock an ArchiveEntry
                                                                                                                                                                                                               ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Put an archive entry (this might write header data)
                                                                                                                                                                                                               tarOutputStream.putArchiveEntry(mockEntry);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // The exact count depends on implementation, but we can verify it's not negative
                                                                                                                                                                                                               assertTrue(tarOutputStream.getCount() >= 0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Clean up
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testGetCount_AfterCloseArchiveEntry() throws IOException {
                                                                                                                                                                                                               // Create a ByteArrayOutputStream to use with TarArchiveOutputStream
                                                                                                                                                                                                               ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create the TarArchiveOutputStream instance
                                                                                                                                                                                                               TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock an ArchiveEntry
                                                                                                                                                                                                               ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Put and close an archive entry
                                                                                                                                                                                                               tarOutputStream.putArchiveEntry(mockEntry);
                                                                                                                                                                                                               tarOutputStream.closeArchiveEntry();
                                                                                                                                                                                                               
                                                                                                                                                                                                               // The exact count depends on implementation, but we can verify it's not negative
                                                                                                                                                                                                               assertTrue(tarOutputStream.getCount() >= 0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Clean up
                                                                                                                                                                                                               tarOutputStream.close();
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                           public void testWrite_EmptyWriteDoesNothing() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                               OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Use reflection to access private fields
                                                                                                                                                                                                               Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                               bufferField.setAccessible(true);
                                                                                                                                                                                                               Object buffer = bufferField.get(tarOut);
                                                                                                                                                                                                               
                                                                                                                                                                                                               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                               currSizeField.setAccessible(true);
                                                                                                                                                                                                               currSizeField.setInt(tarOut, 1024);
                                                                                                                                                                                                               
                                                                                                                                                                                                               byte[] data = new byte[0];
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Test
                                                                                                                                                                                                               tarOut.write(data, 0, 0);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify - mock the buffer's behavior indirectly through the output stream
                                                                                                                                                                                                               verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify private fields using reflection
                                                                                                                                                                                                               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                               currBytesField.setAccessible(true);
                                                                                                                                                                                                               assertEquals(0, currBytesField.getInt(tarOut));
                                                                                                                                                                                                               
                                                                                                                                                                                                               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                               assemLenField.setAccessible(true);
                                                                                                                                                                                                               assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                       public void testWrite_ThrowsWhenExceedingEntrySize() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Set private fields using reflection
                                                                                                                                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                           currSizeField.setAccessible(true);
                                                                                                                                                                                                           currSizeField.set(tarOut, 100L);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                           currBytesField.setAccessible(true);
                                                                                                                                                                                                           currBytesField.set(tarOut, 90L);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                                                           currNameField.setAccessible(true);
                                                                                                                                                                                                           currNameField.set(tarOut, "test.txt");
                                                                                                                                                                                                           
                                                                                                                                                                                                           byte[] data = new byte[20];
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Expect exception
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               tarOut.write(data, 0, 20);
                                                                                                                                                                                                               fail("Expected IOException to be thrown");
                                                                                                                                                                                                           } catch (IOException e) {
                                                                                                                                                                                                               assertEquals("request to write '20' bytes exceeds size in header of '100' bytes for entry 'test.txt'", 
                                                                                                                                                                                                                          e.getMessage());
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testWrite_AssembleBufferFullWritesRecord() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to access private fields
                                                                                                                                                                                                           Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                           bufferField.setAccessible(true);
                                                                                                                                                                                                           Object buffer = bufferField.get(tarOut);  // Get the actual buffer instance
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                           currSizeField.setAccessible(true);
                                                                                                                                                                                                           currSizeField.set(tarOut, 1024);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                           assemLenField.setAccessible(true);
                                                                                                                                                                                                           assemLenField.set(tarOut, 500);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                           recordBufField.setAccessible(true);
                                                                                                                                                                                                           byte[] recordBuf = new byte[512];
                                                                                                                                                                                                           recordBufField.set(tarOut, recordBuf);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                           assemBufField.setAccessible(true);
                                                                                                                                                                                                           assemBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                           
                                                                                                                                                                                                           byte[] data = new byte[100];
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Test
                                                                                                                                                                                                           tarOut.write(data, 0, 100);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           // Instead of verifying mock buffer, we verify the recordBuf was modified
                                                                                                                                                                                                           byte[] modifiedRecordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                                           assertNotNull(modifiedRecordBuf);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                           currBytesField.setAccessible(true);
                                                                                                                                                                                                           assertEquals(512, currBytesField.get(tarOut));
                                                                                                                                                                                                           
                                                                                                                                                                                                           assertEquals(88, assemLenField.get(tarOut)); // 500 + 100 - 512 = 88
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testWrite_WritesFullRecordsDirectly() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to set private fields
                                                                                                                                                                                                           Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                           bufferField.setAccessible(true);
                                                                                                                                                                                                           Object mockBuffer = mock(bufferField.getType());
                                                                                                                                                                                                           bufferField.set(tarOut, mockBuffer);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                           currSizeField.setAccessible(true);
                                                                                                                                                                                                           currSizeField.set(tarOut, 2048);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                           assemLenField.setAccessible(true);
                                                                                                                                                                                                           assemLenField.set(tarOut, 0);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                           recordBufField.setAccessible(true);
                                                                                                                                                                                                           recordBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                           assemBufField.setAccessible(true);
                                                                                                                                                                                                           assemBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                           
                                                                                                                                                                                                           byte[] data = new byte[1024];
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Test
                                                                                                                                                                                                           tarOut.write(data, 0, 1024);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           // Changed verification to use write method instead of writeRecord
                                                                                                                                                                                                           verify(mockOut, times(2)).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                           currBytesField.setAccessible(true);
                                                                                                                                                                                                           assertEquals(1024, currBytesField.get(tarOut));
                                                                                                                                                                                                           
                                                                                                                                                                                                           assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                       public void testWrite_HandlesPartialFinalRecord() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to access private fields
                                                                                                                                                                                                           Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                           currSizeField.setAccessible(true);
                                                                                                                                                                                                           currSizeField.set(tarOut, 2048L);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                           assemLenField.setAccessible(true);
                                                                                                                                                                                                           assemLenField.set(tarOut, 0);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                           recordBufField.setAccessible(true);
                                                                                                                                                                                                           recordBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                           assemBufField.setAccessible(true);
                                                                                                                                                                                                           assemBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                           
                                                                                                                                                                                                           byte[] data = new byte[600];
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Test
                                                                                                                                                                                                           tarOut.write(data, 0, 600);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                           bufferField.setAccessible(true);
                                                                                                                                                                                                           Object buffer = bufferField.get(tarOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                           currBytesField.setAccessible(true);
                                                                                                                                                                                                           assertEquals(512, currBytesField.get(tarOut));
                                                                                                                                                                                                           
                                                                                                                                                                                                           assertEquals(88, assemLenField.get(tarOut));
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                   public void testWrite_AddsToAssembleBufferWhenSpaceAvailable() throws Exception {
                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Use reflection to access private fields
                                                                                                                                                                                                       Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                                       bufferField.setAccessible(true);
                                                                                                                                                                                                       Object buffer = bufferField.get(tarOut);  // Get the actual TarBuffer instance
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                                       currSizeField.setAccessible(true);
                                                                                                                                                                                                       currSizeField.set(tarOut, 1024);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                                       assemLenField.setAccessible(true);
                                                                                                                                                                                                       assemLenField.set(tarOut, 100);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                                       recordBufField.setAccessible(true);
                                                                                                                                                                                                       recordBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                                       assemBufField.setAccessible(true);
                                                                                                                                                                                                       assemBufField.set(tarOut, new byte[512]);
                                                                                                                                                                                                       
                                                                                                                                                                                                       byte[] data = new byte[200];
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Test
                                                                                                                                                                                                       tarOut.write(data, 0, 200);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                       // We can't verify the TarBuffer directly, so we verify the state changes instead
                                                                                                                                                                                                       assertEquals(300, assemLenField.getInt(tarOut));
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                                       currBytesField.setAccessible(true);
                                                                                                                                                                                                       assertEquals(0, currBytesField.getInt(tarOut));
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                          public void testWriteWithZeroAssemLenShouldNotEnterAssemblyBlock() throws Exception {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              java.io.OutputStream mockOut = mock(java.io.OutputStream.class);
                                                                                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to inject mock buffer and set state
                                                                                                                                                                                              Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                              bufferField.setAccessible(true);
                                                                                                                                                                                              Object mockBuffer = mock(bufferField.getType());  // Create mock using reflection
                                                                                                                                                                                              bufferField.set(tarOut, mockBuffer);
                                                                                                                                                                                              
                                                                                                                                                                                              Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                              assemLenField.setAccessible(true);
                                                                                                                                                                                              assemLenField.set(tarOut, 0);  // Critical: assemLen = 0
                                                                                                                                                                                              
                                                                                                                                                                                              Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                              recordBufField.setAccessible(true);
                                                                                                                                                                                              byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                              int recordSize = recordBuf.length;
                                                                                                                                                                                              
                                                                                                                                                                                              // Test data - smaller than record size to potentially trigger assembly
                                                                                                                                                                                              byte[] testData = new byte[recordSize / 2];
                                                                                                                                                                                              java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                                              
                                                                                                                                                                                              // Execute
                                                                                                                                                                                              tarOut.write(testData, 0, testData.length);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify - should not have written to the output stream (no full record written)
                                                                                                                                                                                              verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify final state
                                                                                                                                                                                              assertEquals("assemLen should equal written data size", 
                                                                                                                                                                                                           testData.length, assemLenField.get(tarOut));
                                                                                                                                                                                              
                                                                                                                                                                                              Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                              assemBufField.setAccessible(true);
                                                                                                                                                                                              byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                              assertArrayEquals("assemBuf should contain written data",
                                                                                                                                                                                                               testData,
                                                                                                                                                                                                               java.util.Arrays.copyOf(assemBuf, testData.length));
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                     public void testWrite_WhenAssembledLengthPlusWriteExactlyEqualsBufferSize_ShouldWriteRecord() throws Exception {
                                                                                                                                                                                         // Setup
                                                                                                                                                                                         ByteArrayOutputStream mockOut = new ByteArrayOutputStream();
                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private fields
                                                                                                                                                                                         Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                                         bufferField.setAccessible(true);
                                                                                                                                                                                         Object buffer = bufferField.get(tarOut);
                                                                                                                                                                                         
                                                                                                                                                                                         Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                                                         recordBufField.setAccessible(true);
                                                                                                                                                                                         byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                                                         int recordSize = recordBuf.length;
                                                                                                                                                                                         
                                                                                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                                                                                         assemLenField.set(tarOut, 1); // Set some initial assembled length
                                                                                                                                                                                         
                                                                                                                                                                                         Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                                                                         assemBufField.setAccessible(true);
                                                                                                                                                                                         byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                                                                         
                                                                                                                                                                                         // Prepare test data where assemLen + numToWrite exactly equals record size
                                                                                                                                                                                         int numToWrite = recordSize - 1;
                                                                                                                                                                                         byte[] wBuf = new byte[numToWrite];
                                                                                                                                                                                         
                                                                                                                                                                                         // Remember initial output size
                                                                                                                                                                                         int initialSize = mockOut.size();
                                                                                                                                                                                         
                                                                                                                                                                                         // Test
                                                                                                                                                                                         tarOut.write(wBuf, 0, numToWrite);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify - should write record when sum equals buffer size
                                                                                                                                                                                         // Instead of verifying mock buffer, we check that output was written
                                                                                                                                                                                         assertTrue("Output should be written", mockOut.size() > initialSize);
                                                                                                                                                                                         
                                                                                                                                                                                         // Additional verification
                                                                                                                                                                                         assertEquals(0, assemLenField.get(tarOut)); // Assembled length should be reset
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                public void testWriteWithPartialAssembledData() throws Exception {
                                                                                                                                                                                    // Setup
                                                                                                                                                                                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                                                                                    int recordSize = 512; // Default tar record size
                                                                                                                                                                                    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(out, recordSize);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up test entry
                                                                                                                                                                                    tarOut.putArchiveEntry(new TarArchiveEntry("test.txt"));
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private fields
                                                                                                                                                                                    Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                                    currSizeField.setAccessible(true);
                                                                                                                                                                                    currSizeField.set(tarOut, 1024L); // Allow enough space
                                                                                                                                                                                    
                                                                                                                                                                                    // Prepare test data - first partial write to create assembled data
                                                                                                                                                                                    byte[] firstWrite = new byte[300];
                                                                                                                                                                                    java.util.Arrays.fill(firstWrite, (byte)1);
                                                                                                                                                                                    tarOut.write(firstWrite, 0, firstWrite.length);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify we have partial assembled data
                                                                                                                                                                                    Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                                    assemLenField.setAccessible(true);
                                                                                                                                                                                    assertEquals(300, assemLenField.getInt(tarOut));
                                                                                                                                                                                    
                                                                                                                                                                                    // Second write that will trigger the mutated code path
                                                                                                                                                                                    byte[] secondWrite = new byte[300];
                                                                                                                                                                                    java.util.Arrays.fill(secondWrite, (byte)2);
                                                                                                                                                                                    tarOut.write(secondWrite, 0, secondWrite.length);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify the mutation by checking numToWrite would have been processed
                                                                                                                                                                                    // Original: numToWrite should be 300 - (512-300) = 88
                                                                                                                                                                                    // Mutant: numToWrite would be 300 + (512-300) = 512
                                                                                                                                                                                    
                                                                                                                                                                                    // Should have written one complete record (512 bytes)
                                                                                                                                                                                    Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                                    currBytesField.setAccessible(true);
                                                                                                                                                                                    assertEquals(512, currBytesField.getInt(tarOut));
                                                                                                                                                                                    
                                                                                                                                                                                    // Should have remaining data (88 bytes) in assembly buffer
                                                                                                                                                                                    assertEquals(88, assemLenField.getInt(tarOut));
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify the buffer content
                                                                                                                                                                                    tarOut.closeArchiveEntry();
                                                                                                                                                                                    byte[] result = out.toByteArray();
                                                                                                                                                                                    
                                                                                                                                                                                    // First record should contain:
                                                                                                                                                                                    // - First 300 bytes from first write
                                                                                                                                                                                    // - 212 bytes from second write
                                                                                                                                                                                    for (int i = 0; i < 300; i++) {
                                                                                                                                                                                        assertEquals(1, result[i]);
                                                                                                                                                                                    }
                                                                                                                                                                                    for (int i = 300; i < 512; i++) {
                                                                                                                                                                                        assertEquals(2, result[i]);
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testWriteWithExactRecordSize() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                                               // Setup
                                                                                                                                                                               OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                               TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private fields
                                                                                                                                                                               Field currNameField = TarArchiveOutputStream.class.getDeclaredField("currName");
                                                                                                                                                                               currNameField.setAccessible(true);
                                                                                                                                                                               currNameField.set(tarOut, "testEntry");
                                                                                                                                                                               
                                                                                                                                                                               Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                               currSizeField.setAccessible(true);
                                                                                                                                                                               currSizeField.set(tarOut, 1024L); // Enough space
                                                                                                                                                                               
                                                                                                                                                                               Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                                               currBytesField.setAccessible(true);
                                                                                                                                                                               currBytesField.set(tarOut, 0L);
                                                                                                                                                                               
                                                                                                                                                                               Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                               assemLenField.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               // Create test data that exactly matches record size
                                                                                                                                                                               int recordSize = tarOut.getRecordSize();
                                                                                                                                                                               byte[] testData = new byte[recordSize];
                                                                                                                                                                               
                                                                                                                                                                               // First write - should go directly to buffer without assembly
                                                                                                                                                                               tarOut.write(testData, 0, recordSize);
                                                                                                                                                                               
                                                                                                                                                                               // Verify exactly one record was written
                                                                                                                                                                               verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                                                                                               
                                                                                                                                                                               // Verify state
                                                                                                                                                                               assertEquals(recordSize, currBytesField.getLong(tarOut));
                                                                                                                                                                               assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                               
                                                                                                                                                                               // Second write - 0 bytes (edge case)
                                                                                                                                                                               tarOut.write(testData, 0, 0);
                                                                                                                                                                               
                                                                                                                                                                               // Verify no additional writes occurred
                                                                                                                                                                               verifyNoMoreInteractions(mockOut);
                                                                                                                                                                               
                                                                                                                                                                               // Verify state remains unchanged
                                                                                                                                                                               assertEquals(recordSize, currBytesField.getLong(tarOut));
                                                                                                                                                                               assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                                                                           }

    @Test
                                                                                                                                                              public void testWriteExactlyRecordSize() throws Exception {
                                                                                                                                                                  // Setup
                                                                                                                                                                  int recordSize = 512; // Typical tar record size
                                                                                                                                                                  ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                  
                                                                                                                                                                  // Create stream with known record size
                                                                                                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos, recordSize, recordSize);
                                                                                                                                                                  
                                                                                                                                                                  // Set up current entry
                                                                                                                                                                  tarOut.putArchiveEntry(new TarArchiveEntry("test.txt"));
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set private currSize field
                                                                                                                                                                  Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                                                                                  currSizeField.setAccessible(true);
                                                                                                                                                                  currSizeField.set(tarOut, recordSize * 2L); // Allow writing
                                                                                                                                                                  
                                                                                                                                                                  // Prepare test data - exactly one record size
                                                                                                                                                                  byte[] testData = new byte[recordSize];
                                                                                                                                                                  java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                                  
                                                                                                                                                                  // Get the original buffer to verify writes
                                                                                                                                                                  Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                                  bufferField.setAccessible(true);
                                                                                                                                                                  Object originalBuffer = bufferField.get(tarOut);
                                                                                                                                                                  
                                                                                                                                                                  // Get the counting output stream to verify bytes written
                                                                                                                                                                  Field outField = TarArchiveOutputStream.class.getDeclaredField("out");
                                                                                                                                                                  outField.setAccessible(true);
                                                                                                                                                                  CountingOutputStream countingOut = (CountingOutputStream) outField.get(tarOut);
                                                                                                                                                                  long initialBytes = countingOut.getBytesWritten();
                                                                                                                                                                  
                                                                                                                                                                  // Test - write exactly record size
                                                                                                                                                                  tarOut.write(testData, 0, recordSize);
                                                                                                                                                                  
                                                                                                                                                                  // Verify bytes were written
                                                                                                                                                                  assertEquals(recordSize, countingOut.getBytesWritten() - initialBytes);
                                                                                                                                                                  
                                                                                                                                                                  // Verify assembly buffer remains empty using reflection
                                                                                                                                                                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                                  assemLenField.setAccessible(true);
                                                                                                                                                                  assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                                                  
                                                                                                                                                                  // Cleanup
                                                                                                                                                                  tarOut.closeArchiveEntry();
                                                                                                                                                                  tarOut.close();
                                                                                                                                                              }

    @Test
                                                                                                                                                     public void testWriteMultipleCompleteRecords() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                         // Setup
                                                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                         // Create real TarBuffer instead of mocking since it's not public
                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to get the buffer field
                                                                                                                                                         Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                                         bufferField.setAccessible(true);
                                                                                                                                                         Object buffer = bufferField.get(tarOut);
                                                                                                                                                         
                                                                                                                                                         // Set record size to known value (512 is default)
                                                                                                                                                         Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                         recordBufField.setAccessible(true);
                                                                                                                                                         byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                         int recordSize = recordBuf.length;
                                                                                                                                                         
                                                                                                                                                         // Create test data that spans exactly 2 complete records
                                                                                                                                                         byte[] testData = new byte[recordSize * 2];
                                                                                                                                                         java.util.Arrays.fill(testData, (byte)1);
                                                                                                                                                         
                                                                                                                                                         // Set initial state
                                                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                                                         assemLenField.set(tarOut, 0);
                                                                                                                                                         
                                                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                                                         currBytesField.set(tarOut, 0L);
                                                                                                                                                         
                                                                                                                                                         // Execute
                                                                                                                                                         tarOut.write(testData, 0, testData.length);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         // Should write exactly 2 complete records
                                                                                                                                                         // We can't verify mock buffer calls since we're using real buffer
                                                                                                                                                         // Instead verify the bytes written count
                                                                                                                                                         assertEquals(recordSize * 2, currBytesField.get(tarOut));
                                                                                                                                                     }

    @Test
                                                                                                                                            public void testWriteWithZeroAssemLenShouldNotEnterAssemblyBlock1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                                // Setup
                                                                                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                
                                                                                                                                                // Set assemLen to 0
                                                                                                                                                Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                                assemLenField.setAccessible(true);
                                                                                                                                                assemLenField.set(tarOut, 0);
                                                                                                                                                
                                                                                                                                                // Get recordBuf for test data size
                                                                                                                                                Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                                recordBufField.setAccessible(true);
                                                                                                                                                byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                                
                                                                                                                                                // Test data - enough to trigger record writing
                                                                                                                                                byte[] testData = new byte[recordBuf.length * 2];
                                                                                                                                                int offset = 0;
                                                                                                                                                int length = testData.length;
                                                                                                                                                
                                                                                                                                                // Execute
                                                                                                                                                tarOut.write(testData, offset, length);
                                                                                                                                                
                                                                                                                                                // Verify - should write to output stream directly when assemLen is 0
                                                                                                                                                // Since we can't verify TarBuffer, we verify the underlying OutputStream instead
                                                                                                                                                verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                
                                                                                                                                                // Verify assemLen remains 0
                                                                                                                                                assertEquals(0, assemLenField.get(tarOut));
                                                                                                                                            }

    @Test
                                                                                                                                   public void testWrite_WhenAssembledPlusNewDataExactlyFillsRecord_ShouldWriteRecord() throws Exception {
                                                                                                                                       // Setup
                                                                                                                                       OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                       // Create real TarBuffer instead of mocking since it's not public
                                                                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                       
                                                                                                                                       // Use reflection to get the buffer and set up test conditions
                                                                                                                                       Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                       bufferField.setAccessible(true);
                                                                                                                                       Object buffer = bufferField.get(tarOut);
                                                                                                                                       
                                                                                                                                       Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                       recordBufField.setAccessible(true);
                                                                                                                                       byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                                                       int recordSize = recordBuf.length;
                                                                                                                                       
                                                                                                                                       Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                       assemLenField.setAccessible(true);
                                                                                                                                       assemLenField.set(tarOut, 1); // Set some assembled data
                                                                                                                                       
                                                                                                                                       Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                       assemBufField.setAccessible(true);
                                                                                                                                       byte[] assemBuf = (byte[]) assemBufField.get(tarOut);
                                                                                                                                       assemBuf[0] = (byte) 0xFF; // Set some dummy data
                                                                                                                                       
                                                                                                                                       // Test data that will make assemLen + numToWrite exactly equal recordSize
                                                                                                                                       byte[] testData = new byte[recordSize - 1];
                                                                                                                                       for (int i = 0; i < testData.length; i++) {
                                                                                                                                           testData[i] = (byte) 0x01;
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Get initial count of bytes written to the output stream
                                                                                                                                       Field outField = TarArchiveOutputStream.class.getDeclaredField("out");
                                                                                                                                       outField.setAccessible(true);
                                                                                                                                       CountingOutputStream countingOut = (CountingOutputStream) outField.get(tarOut);
                                                                                                                                       long initialBytesWritten = countingOut.getBytesWritten();
                                                                                                                                       
                                                                                                                                       // Execute
                                                                                                                                       tarOut.write(testData, 0, testData.length);
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       // Instead of verifying buffer.writeRecord(), verify that bytes were written to the output stream
                                                                                                                                       long bytesWrittenAfter = countingOut.getBytesWritten();
                                                                                                                                       assertTrue("Should have written at least one record", bytesWrittenAfter > initialBytesWritten);
                                                                                                                                       
                                                                                                                                       // Additional verification of state changes
                                                                                                                                       assertEquals(0, assemLenField.get(tarOut)); // Should be 0 after write
                                                                                                                                   }

    @Test
                                                                                                                          public void testWriteWithAssemblyBufferFillingRecord() throws IOException {
                                                                                                                              // Setup test data
                                                                                                                              int recordSize = 512; // Default record size
                                                                                                                              byte[] wBuf = new byte[recordSize * 2]; // Enough data to test with
                                                                                                                              int wOffset = 0;
                                                                                                                              int initialNumToWrite = 300; // Will fill the record when combined with assembly
                                                                                                                              
                                                                                                                              // Set up assembly buffer with some existing data
                                                                                                                              int initialAssemLen = recordSize - 100; // 412 bytes already in assembly
                                                                                                                              byte[] assemBuf = new byte[recordSize];
                                                                                                                              
                                                                                                                              // Create test instance with real buffer
                                                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                                                              TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                              
                                                                                                                              // Use reflection to set private fields for testing
                                                                                                                              try {
                                                                                                                                  Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                                                  bufferField.setAccessible(true);
                                                                                                                                  Object realBuffer = bufferField.get(tarOut);
                                                                                                                                  
                                                                                                                                  Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                                                                                  assemBufField.setAccessible(true);
                                                                                                                                  assemBufField.set(tarOut, assemBuf);
                                                                                                                                  
                                                                                                                                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                  assemLenField.setAccessible(true);
                                                                                                                                  assemLenField.set(tarOut, initialAssemLen);
                                                                                                                                  
                                                                                                                                  Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                                                  recordBufField.setAccessible(true);
                                                                                                                                  recordBufField.set(tarOut, new byte[recordSize]);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Execute test
                                                                                                                              tarOut.write(wBuf, wOffset, initialNumToWrite);
                                                                                                                              
                                                                                                                              // Verify results
                                                                                                                              // After processing, numToWrite should be reduced by the amount written (aLen = 100)
                                                                                                                              // In original: 300 - 100 = 200 remaining
                                                                                                                              // In mutant: 300 + 100 = 400 remaining (wrong)
                                                                                                                              
                                                                                                                              // Verify buffer.writeRecord was called once (for the full record)
                                                                                                                              // We can't verify the real buffer's writeRecord directly, so we verify the output stream was written to
                                                                                                                              verify(mockOut, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                              
                                                                                                                              // Check assembly buffer was reset
                                                                                                                              try {
                                                                                                                                  Field finalAssemLen = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                                  finalAssemLen.setAccessible(true);
                                                                                                                                  assertEquals(0, finalAssemLen.get(tarOut));
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to verify assembly length: " + e.getMessage());
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Check currBytes was updated correctly
                                                                                                                              try {
                                                                                                                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                                  currBytesField.setAccessible(true);
                                                                                                                                  assertEquals(recordSize, currBytesField.get(tarOut));
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Failed to verify current bytes: " + e.getMessage());
                                                                                                                              }
                                                                                                                          }

    @Test
                                                                                                                     public void testWriteWithExactRecordSizeShouldNotLoopWhenZero() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                         // Setup
                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                         
                                                                                                                         // Set up test data that will result in numToWrite becoming exactly 0
                                                                                                                         byte[] testData = new byte[tarOut.getRecordSize() * 2]; // Exactly 2 full records
                                                                                                                         int recordSize = tarOut.getRecordSize();
                                                                                                                         
                                                                                                                         // Initialize entry
                                                                                                                         ArchiveEntry mockEntry = mock(ArchiveEntry.class);
                                                                                                                         when(mockEntry.getSize()).thenReturn((long)testData.length);
                                                                                                                         tarOut.putArchiveEntry(mockEntry);
                                                                                                                         
                                                                                                                         // Get private fields using reflection
                                                                                                                         Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                                         assemLenField.setAccessible(true);
                                                                                                                         Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                                         currBytesField.setAccessible(true);
                                                                                                                         
                                                                                                                         // Verify initial state
                                                                                                                         assertEquals(0, tarOut.getCount());
                                                                                                                         assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                         
                                                                                                                         // Execute - write exactly two full records
                                                                                                                         tarOut.write(testData, 0, testData.length);
                                                                                                                         
                                                                                                                         // Verify behavior
                                                                                                                         // Should write exactly 2 records (no more, no less)
                                                                                                                         verify(mockOut, times(2)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                                         
                                                                                                                         // Verify final state
                                                                                                                         assertEquals(2, tarOut.getCount());
                                                                                                                         assertEquals(0, assemLenField.getInt(tarOut));
                                                                                                                         assertEquals(testData.length, currBytesField.getLong(tarOut));
                                                                                                                         
                                                                                                                         // Clean up
                                                                                                                         tarOut.closeArchiveEntry();
                                                                                                                     }

    @Test
                                                                                                    public void testWriteWhenNumToWriteEqualsRecordSize() throws Exception {
                                                                                                        // Setup
                                                                                                        OutputStream mockOut = mock(OutputStream.class);
                                                                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                        
                                                                                                        // Get the real buffer instance through reflection
                                                                                                        Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                        bufferField.setAccessible(true);
                                                                                                        Object buffer = bufferField.get(tarOut);
                                                                                                        
                                                                                                        // Spy on the real buffer instead of mocking
                                                                                                        Object spyBuffer = spy(buffer);
                                                                                                        bufferField.set(tarOut, spyBuffer);
                                                                                                        
                                                                                                        // Set recordBuf size to known value (default is 512)
                                                                                                        Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                        recordBufField.setAccessible(true);
                                                                                                        byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                                                        int recordSize = recordBuf.length;
                                                                                                        
                                                                                                        // Prepare test data that exactly matches record size
                                                                                                        byte[] testData = new byte[recordSize];
                                                                                                        java.util.Arrays.fill(testData, (byte)1);
                                                                                                        
                                                                                                        // Test
                                                                                                        tarOut.write(testData, 0, recordSize);
                                                                                                        
                                                                                                        // Verify
                                                                                                        // Instead of verifying the TarBuffer directly, verify that the output stream was written to
                                                                                                        // We know that when numToWrite equals recordSize, it should write directly to the output
                                                                                                        verify(mockOut).write(any(byte[].class), eq(0), eq(recordSize));
                                                                                                        
                                                                                                        // Check assembly buffer wasn't used
                                                                                                        Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                                        assemLenField.setAccessible(true);
                                                                                                        assertEquals(0, assemLenField.get(tarOut));
                                                                                                        
                                                                                                        // Check bytes written
                                                                                                        Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                                                        currBytesField.setAccessible(true);
                                                                                                        assertEquals(recordSize, currBytesField.get(tarOut));
                                                                                                    }

    @Test
                                                                                               public void testWriteHandlesCompleteRecordsCorrectly() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                   // Setup
                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                   // Create a real TarBuffer instead of mocking since it's not public
                                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                   
                                                                                                   // Use reflection to get the buffer field since we can't mock it directly
                                                                                                   Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                                   bufferField.setAccessible(true);
                                                                                                   Object buffer = bufferField.get(tarOut);
                                                                                                   
                                                                                                   // Set up test data - need enough to trigger complete record writing
                                                                                                   byte[] recordBuf = new byte[512]; // default record size
                                                                                                   Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                                                   recordBufField.setAccessible(true);
                                                                                                   recordBufField.set(tarOut, recordBuf);
                                                                                                   
                                                                                                   byte[] testData = new byte[1024]; // 2 complete records
                                                                                                   java.util.Arrays.fill(testData, (byte)1);
                                                                                                   int initialOffset = 0;
                                                                                                   
                                                                                                   // Set current entry details
                                                                                                   Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                                                   currSizeField.setAccessible(true);
                                                                                                   currSizeField.set(tarOut, 2048L); // Enough space
                                                                                                   
                                                                                                   // Execute
                                                                                                   tarOut.write(testData, initialOffset, testData.length);
                                                                                                   
                                                                                                   // Verify - the key assertion that catches the mutant
                                                                                                   // After writing 1024 bytes (2 records), offset should be 1024
                                                                                                   Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                                                                                   wOffsetField.setAccessible(true);
                                                                                                   int finalOffset = (int)wOffsetField.get(tarOut);
                                                                                                   
                                                                                                   assertEquals("Write offset should advance by 1024 bytes", 
                                                                                                               testData.length, 
                                                                                                               finalOffset - initialOffset);
                                                                                                   
                                                                                                   // Verify buffer writes through reflection since we can't mock TarBuffer
                                                                                                   Field bufferWriteCountField = buffer.getClass().getDeclaredField("currRecIdx");
                                                                                                   bufferWriteCountField.setAccessible(true);
                                                                                                   int writeCount = (int)bufferWriteCountField.get(buffer);
                                                                                                   assertEquals("Should have written 2 records", 2, writeCount);
                                                                                               }

    @Test
                                                                                  public void testWriteWithZeroAssemLenShouldNotExecuteAssemblyLogic() throws Exception {
                                                                                      // Setup
                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                      TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                      
                                                                                      // Use reflection to get the actual buffer instance
                                                                                      Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                                      bufferField.setAccessible(true);
                                                                                      Object buffer = bufferField.get(tarOut);
                                                                                      
                                                                                      // Create a spy on the buffer using Mockito's spy functionality
                                                                                      Object spyBuffer = spy(buffer);
                                                                                      bufferField.set(tarOut, spyBuffer);
                                                                                      
                                                                                      // Set assemLen to 0
                                                                                      Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                                      assemLenField.setAccessible(true);
                                                                                      assemLenField.set(tarOut, 0);  // Critical: assemLen = 0
                                                                                      
                                                                                      // Test data - small write that shouldn't trigger assembly
                                                                                      byte[] testData = new byte[100];
                                                                                      int offset = 0;
                                                                                      int length = 100;
                                                                                      
                                                                                      // Execute
                                                                                      tarOut.write(testData, offset, length);
                                                                                      
                                                                                      // Verify - buffer.writeRecord should NOT be called when assemLen == 0
                                                                                      // Instead of trying to verify the reflected method, we can verify that the underlying output stream wasn't written to
                                                                                      verify(mockOut, never()).write(any(byte[].class), anyInt(), anyInt());
                                                                                      
                                                                                      // Verify assemLen was updated correctly (original behavior)
                                                                                      assertEquals(100, assemLenField.get(tarOut));
                                                                                  }

    @Test
                                                                         public void testWrite_AssemblyBufferFullRecord() throws Exception {
                                                                             // Setup
                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                             
                                                                             // Use reflection to access private fields
                                                                             Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                             recordBufField.setAccessible(true);
                                                                             byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                                             int recordSize = recordBuf.length;
                                                                             
                                                                             Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                             assemLenField.setAccessible(true);
                                                                             int initialAssemLen = 100;
                                                                             assemLenField.set(tarOut, initialAssemLen);
                                                                             
                                                                             // Calculate numToWrite to exactly fill the record
                                                                             int numToWrite = recordSize - initialAssemLen;
                                                                             
                                                                             // Prepare test data
                                                                             byte[] testData = new byte[numToWrite];
                                                                             java.util.Arrays.fill(testData, (byte)1);
                                                                             
                                                                             // Execute
                                                                             tarOut.write(testData, 0, numToWrite);
                                                                             
                                                                             // Verify
                                                                             verify(mockOut, times(1)).write(any(byte[].class), eq(0), eq(recordSize));
                                                                             assertEquals(0, assemLenField.get(tarOut)); // Assembly buffer should be empty
                                                                             
                                                                             Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                             currBytesField.setAccessible(true);
                                                                             assertEquals(recordSize, currBytesField.get(tarOut)); // Bytes written should increase
                                                                         }

    @Test
                                                                    public void testWriteWithPartialAssemblyBuffer() throws Exception {
                                                                        // Setup test data
                                                                        int recordSize = 512; // Default tar record size
                                                                        byte[] inputData = new byte[recordSize * 2]; // Enough data to trigger the condition
                                                                        
                                                                        // Create partially filled assembly buffer
                                                                        int initialAssemLen = recordSize / 2;
                                                                        byte[] assemBufContent = new byte[initialAssemLen];
                                                                        java.util.Arrays.fill(assemBufContent, (byte)1);
                                                                        
                                                                        // Create test instance
                                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new java.io.ByteArrayOutputStream());
                                                                        
                                                                        // Use reflection to set private fields since we need specific initial state
                                                                        java.lang.reflect.Field assemBufField = TarArchiveOutputStream.class.getDeclaredField("assemBuf");
                                                                        assemBufField.setAccessible(true);
                                                                        assemBufField.set(tarOut, new byte[recordSize]);
                                                                        
                                                                        java.lang.reflect.Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                        assemLenField.setAccessible(true);
                                                                        assemLenField.set(tarOut, initialAssemLen);
                                                                        
                                                                        java.lang.reflect.Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                                        recordBufField.setAccessible(true);
                                                                        recordBufField.set(tarOut, new byte[recordSize]);
                                                                        
                                                                        // Mock the buffer to verify writes
                                                                        java.lang.reflect.Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                        bufferField.setAccessible(true);
                                                                        Object originalBuffer = bufferField.get(tarOut);
                                                                        
                                                                        // Set other required fields
                                                                        java.lang.reflect.Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                        currSizeField.setAccessible(true);
                                                                        currSizeField.set(tarOut, (long)inputData.length * 2); // Plenty of space
                                                                        
                                                                        // Call the method - this should trigger the buffer-full condition
                                                                        java.lang.reflect.Method writeMethod = TarArchiveOutputStream.class.getDeclaredMethod("write", byte[].class, int.class, int.class);
                                                                        writeMethod.setAccessible(true);
                                                                        writeMethod.invoke(tarOut, inputData, 0, inputData.length);
                                                                        
                                                                        // Verify the remaining bytes to write (indirectly through wOffset)
                                                                        // The correct wOffset should be (recordSize - initialAssemLen)
                                                                        java.lang.reflect.Field wOffsetField = TarArchiveOutputStream.class.getDeclaredField("wOffset");
                                                                        wOffsetField.setAccessible(true);
                                                                        int actualWOffset = (int)wOffsetField.get(tarOut);
                                                                        assertEquals(recordSize - initialAssemLen, actualWOffset);
                                                                        
                                                                        // Verify assembly buffer was cleared
                                                                        int actualAssemLen = (int)assemLenField.get(tarOut);
                                                                        assertEquals(0, actualAssemLen);
                                                                    }

    @Test
                                                               public void testWriteWithExactRecordSizeShouldNotLoopWhenZero1() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                   // Setup
                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                   
                                                                   // Get the buffer field through reflection
                                                                   Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                                   bufferField.setAccessible(true);
                                                                   Object buffer = bufferField.get(tarOut);
                                                                   
                                                                   // Mock the buffer's behavior
                                                                   Field bufferOutField = buffer.getClass().getDeclaredField("out");
                                                                   bufferOutField.setAccessible(true);
                                                                   OutputStream bufferOut = (OutputStream) bufferOutField.get(buffer);
                                                                   OutputStream spyBufferOut = spy(bufferOut);
                                                                   bufferOutField.set(buffer, spyBufferOut);
                                                                   
                                                                   // Set up test data - exactly one record size
                                                                   int recordSize = 512;
                                                                   byte[] testData = new byte[recordSize];
                                                                   for (int i = 0; i < recordSize; i++) {
                                                                       testData[i] = (byte)(i % 256);
                                                                   }
                                                                   
                                                                   // Set initial state using reflection
                                                                   Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                                                                   currSizeField.setAccessible(true);
                                                                   currSizeField.set(tarOut, recordSize * 2); // Enough space
                                                                   
                                                                   Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                                   assemLenField.setAccessible(true);
                                                                   assemLenField.set(tarOut, 0); // Empty assembly buffer
                                                                   
                                                                   // Execute
                                                                   tarOut.write(testData, 0, recordSize);
                                                                   
                                                                   // Verify behavior - should write exactly one record
                                                                   verify(spyBufferOut, times(1)).write(testData, 0, recordSize);
                                                                   
                                                                   // Verify state using reflection
                                                                   Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                                   currBytesField.setAccessible(true);
                                                                   assertEquals("Should consume all bytes", recordSize, currBytesField.get(tarOut));
                                                                   
                                                                   assertEquals("Assembly buffer should remain empty", 0, assemLenField.get(tarOut));
                                                                   
                                                                   // The key verification - with mutant (>=0), it would try to write again
                                                                   // with numToWrite=0, which we verify doesn't happen
                                                                   verifyNoMoreInteractions(spyBufferOut);
                                                               }

    @Test
                                              public void testWriteWhenNumToWriteEqualsRecordSize1() throws Exception {
                                                  // Setup
                                                  OutputStream mockOut = mock(OutputStream.class);
                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                  
                                                  // Use reflection to get the buffer field and make it accessible
                                                  Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                                                  bufferField.setAccessible(true);
                                                  Object mockBuffer = mock(bufferField.getType()); // Create mock without exposing TarBuffer
                                                  
                                                  // Inject mock buffer
                                                  bufferField.set(tarOut, mockBuffer);
                                                  
                                                  Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                                                  recordBufField.setAccessible(true);
                                                  byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                                                  int recordSize = recordBuf.length;
                                                  
                                                  // Set up test data where numToWrite exactly equals record size
                                                  byte[] testData = new byte[recordSize];
                                                  java.util.Arrays.fill(testData, (byte) 1);
                                                  
                                                  // Mock the writeRecord method
                                                  Method writeRecordMethod = mockBuffer.getClass().getMethod("writeRecord", byte[].class, int.class);
                                                  when(writeRecordMethod.invoke(mockBuffer, testData, 0)).thenReturn(null);
                                                  
                                                  // Execute
                                                  tarOut.write(testData, 0, recordSize);
                                                  
                                                  // Verify
                                                  // Verify writeRecord was called on the mock buffer
                                                  verify(mockBuffer, times(1)).getClass().getMethod("writeRecord", byte[].class, int.class)
                                                      .invoke(eq(mockBuffer), eq(testData), eq(0));
                                                  
                                                  Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                                                  assemLenField.setAccessible(true);
                                                  int assemLen = (int) assemLenField.get(tarOut);
                                                  assertEquals(0, assemLen); // Should be 0 for original behavior
                                                  
                                                  Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                                                  currBytesField.setAccessible(true);
                                                  long currBytes = (long) currBytesField.get(tarOut);
                                                  assertEquals(recordSize, currBytes); // Should increment by record size
                                              }

    @Test
             public void testWriteMultipleCompleteRecords1() throws IOException, NoSuchFieldException, IllegalAccessException, NoSuchMethodException {
                 // Setup
                 OutputStream mockOut = mock(OutputStream.class);
                 TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                 
                 // Get the buffer field through reflection
                 Field bufferField = TarArchiveOutputStream.class.getDeclaredField("buffer");
                 bufferField.setAccessible(true);
                 Object realBuffer = bufferField.get(tarOut);
                 
                 // Create a spy of the buffer
                 Object spyBuffer = spy(realBuffer);
                 bufferField.set(tarOut, spyBuffer);
                 
                 Field recordBufField = TarArchiveOutputStream.class.getDeclaredField("recordBuf");
                 recordBufField.setAccessible(true);
                 byte[] recordBuf = (byte[]) recordBufField.get(tarOut);
                 int recordSize = recordBuf.length;
                 
                 // Test data - write 3 complete records
                 byte[] testData = new byte[3 * recordSize];
                 for (int i = 0; i < testData.length; i++) {
                     testData[i] = (byte)1;
                 }
                 
                 // Set initial conditions
                 Field currSizeField = TarArchiveOutputStream.class.getDeclaredField("currSize");
                 currSizeField.setAccessible(true);
                 currSizeField.set(tarOut, 4L * recordSize); // Enough space
                 
                 // Execute
                 tarOut.write(testData, 0, testData.length);
                 
                 // Verify
                 // Should write 3 complete records
                 // Get the writeRecord method through reflection
                 Method writeRecordMethod = realBuffer.getClass().getDeclaredMethod("writeRecord", byte[].class, int.class);
                 writeRecordMethod.setAccessible(true);
                 
                 // Verify using method invocation without casting to TarBuffer
                 verify(spyBuffer, times(3)).getClass().getDeclaredMethod("writeRecord", byte[].class, int.class);
                 
                 // Check currBytes was incremented correctly
                 Field currBytesField = TarArchiveOutputStream.class.getDeclaredField("currBytes");
                 currBytesField.setAccessible(true);
                 assertEquals(3 * recordSize, currBytesField.getLong(tarOut));
                 
                 // Check assemLen should be 0 since we wrote complete records
                 Field assemLenField = TarArchiveOutputStream.class.getDeclaredField("assemLen");
                 assemLenField.setAccessible(true);
                 assertEquals(0, assemLenField.getInt(tarOut));
             }

    @Test
    public void testWriteUpdatesOffsetCorrectly() throws IOException, NoSuchFieldException, IllegalAccessException {
        // Setup
        OutputStream mockOut = mock(OutputStream.class);
        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
        
        // Set up test data - need enough to trigger full record writes
        int recordSize = tarOut.getRecordSize();
        byte[] data = new byte[recordSize * 2]; // Enough for two full records
        java.util.Arrays.fill(data, (byte)1); // Fill with test pattern
        
        // Set current entry parameters using reflection since they're private
        Field currSizeField = tarOut.getClass().getDeclaredField("currSize");
        currSizeField.setAccessible(true);
        currSizeField.set(tarOut, data.length);
        
        Field currBytesField = tarOut.getClass().getDeclaredField("currBytes");
        currBytesField.setAccessible(true);
        currBytesField.set(tarOut, 0L);
        
        Field assemLenField = tarOut.getClass().getDeclaredField("assemLen");
        assemLenField.setAccessible(true);
        assemLenField.set(tarOut, 0);
        
        // Execute
        tarOut.write(data, 0, data.length);
        
        // Verify offset was updated correctly
        // After writing two full records, offset should be at end of data
        // If mutant is present (wOffset -= num), offset would be negative
        Field wOffsetField = tarOut.getClass().getDeclaredField("wOffset");
        wOffsetField.setAccessible(true);
        int finalOffset = wOffsetField.getInt(tarOut);
        
        assertEquals("Write offset should be at end of data", 
                    data.length, finalOffset);
        
        // Verify correct data was written (indirect test of offset)
        verify(mockOut, times(2)).write(any(byte[].class), eq(0), eq(recordSize));
    }


}
