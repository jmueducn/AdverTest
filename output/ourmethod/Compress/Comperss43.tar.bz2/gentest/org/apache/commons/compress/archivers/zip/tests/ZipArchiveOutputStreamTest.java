package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
 
public class ZipArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                public void testWriteLocalFileHeader_WithNullEntryShouldFail() throws Exception {
                                                                                    // Setup
                                                                                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                                    
                                                                                    // Expected exception
                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                    thrown.expect(NullPointerException.class);
                                                                                    thrown.expectMessage("entry");
                                                                                    
                                                                                    // Test
                                                                                    zos.putArchiveEntry(null);
                                                                                }

 @Test
                                                                                public void testWriteLocalFileHeader_PhasedEntry() throws Exception {
                                                                                    // Setup
                                                                                    OutputStream mockOut = mock(OutputStream.class);
                                                                                    ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                                    StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut);
                                                                                    
                                                                                    // Set up mocks using reflection since they're private fields
                                                                                    Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                                    encodingField.setAccessible(true);
                                                                                    encodingField.set(zos, mockEncoding);
                                                                                    
                                                                                    Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                                    compressorField.setAccessible(true);
                                                                                    compressorField.set(zos, mockCompressor);
                                                                                    
                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                                    
                                                                                    when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                                                    when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                                    
                                                                                    // Use reflection to test the private phased version
                                                                                    java.lang.reflect.Method method = ZipArchiveOutputStream.class
                                                                                        .getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class, boolean.class);
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    // Execute phased version
                                                                                    method.invoke(zos, entry, true);
                                                                                    
                                                                                    // Verify
                                                                                    verify(mockCompressor).writeCounted(any(byte[].class));
                                                                                }

 @Test
                                                                                public void testCreateLocalFileHeader_WithAlignmentAndMethodChangeAllowed() throws Exception {
                                                                                    // Setup
                                                                                    ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                    ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                    
                                                                                    ResourceAlignmentExtraField alignmentEx = mock(ResourceAlignmentExtraField.class);
                                                                                    when(alignmentEx.getAlignment()).thenReturn((short)4);  // Changed to short
                                                                                    when(alignmentEx.allowMethodChange()).thenReturn(true);
                                                                                    when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(alignmentEx);
                                                                                    
                                                                                    // Use reflection to set alignment since it's protected
                                                                                    Field alignmentField = ZipArchiveEntry.class.getDeclaredField("alignment");
                                                                                    alignmentField.setAccessible(true);
                                                                                    alignmentField.set(entry, 0);
                                                                                    
                                                                                    when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                    when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                    when(entry.getCrc()).thenReturn(12345L);
                                                                                    when(entry.getSize()).thenReturn(100L);
                                                                                    when(entry.getCompressedSize()).thenReturn(80L);
                                                                                    when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                    
                                                                                    // Use reflection to access private createLocalFileHeader method
                                                                                    Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                        "createLocalFileHeader", 
                                                                                        ZipArchiveEntry.class, 
                                                                                        ByteBuffer.class, 
                                                                                        boolean.class, 
                                                                                        boolean.class, 
                                                                                        long.class);
                                                                                    createLocalFileHeader.setAccessible(true);
                                                                                    byte[] result = (byte[]) createLocalFileHeader.invoke(zaos, entry, name, true, false, 0L);
                                                                                    
                                                                                    // Verify
                                                                                    assertNotNull(result);
                                                                                    
                                                                                    // Use reflection to access private constants
                                                                                    Field lfhSigField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG");
                                                                                    lfhSigField.setAccessible(true);
                                                                                    byte[] lfhSig = (byte[]) lfhSigField.get(zaos);
                                                                                    
                                                                                    Field lfhSigOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_SIG_OFFSET");
                                                                                    lfhSigOffsetField.setAccessible(true);
                                                                                    int lfhSigOffset = (int) lfhSigOffsetField.get(zaos);
                                                                                    
                                                                                    Field lfhMethodOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_METHOD_OFFSET");
                                                                                    lfhMethodOffsetField.setAccessible(true);
                                                                                    int lfhMethodOffset = (int) lfhMethodOffsetField.get(zaos);
                                                                                    
                                                                                    Field lfhCrcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                                    lfhCrcOffsetField.setAccessible(true);
                                                                                    int lfhCrcOffset = (int) lfhCrcOffsetField.get(zaos);
                                                                                    
                                                                                    // Verify signature
                                                                                    assertEquals(lfhSig[0], result[lfhSigOffset]);
                                                                                    // Verify method is DEFLATED
                                                                                    assertEquals(ZipArchiveOutputStream.DEFLATED, 
                                                                                                 (result[lfhMethodOffset+1] << 8) + 
                                                                                                 (result[lfhMethodOffset] & 0xff));
                                                                                    // Verify CRC
                                                                                    assertEquals(12345L, 
                                                                                                ((long)(result[lfhCrcOffset+3] & 0xff) << 24) +
                                                                                                ((result[lfhCrcOffset+2] & 0xff) << 16) +
                                                                                                ((result[lfhCrcOffset+1] & 0xff) << 8) +
                                                                                                (result[lfhCrcOffset] & 0xff));
                                                                                }

 @Test
                                                                            public void testCreateLocalFileHeader_StoredMethodWithoutChannel() throws Exception {
                                                                                // Setup
                                                                                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                
                                                                                // Use reflection to access protected getAlignment() method
                                                                                Method getAlignmentMethod = ZipArchiveEntry.class.getDeclaredMethod("getAlignment");
                                                                                getAlignmentMethod.setAccessible(true);
                                                                                
                                                                                when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                when(entry.getCrc()).thenReturn(12345L);
                                                                                when(entry.getSize()).thenReturn(100L);
                                                                                when(entry.getCompressedSize()).thenReturn(100L);
                                                                                when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                
                                                                                // Use reflection to access private createLocalFileHeader method
                                                                                Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "createLocalFileHeader", 
                                                                                    ZipArchiveEntry.class, 
                                                                                    ByteBuffer.class, 
                                                                                    boolean.class, 
                                                                                    boolean.class, 
                                                                                    long.class);
                                                                                createLocalFileHeaderMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                                    zaos, entry, name, true, false, 0L);
                                                                                
                                                                                // Verify
                                                                                assertNotNull(result);
                                                                                
                                                                                // Get private offset constants via reflection
                                                                                Field lfhMethodOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_METHOD_OFFSET");
                                                                                lfhMethodOffsetField.setAccessible(true);
                                                                                int lfhMethodOffset = lfhMethodOffsetField.getInt(zaos);
                                                                                
                                                                                Field lfhCompressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                                lfhCompressedSizeOffsetField.setAccessible(true);
                                                                                int lfhCompressedSizeOffset = lfhCompressedSizeOffsetField.getInt(zaos);
                                                                                
                                                                                // Verify method is STORED
                                                                                assertEquals(ZipArchiveOutputStream.STORED, 
                                                                                             (result[lfhMethodOffset+1] << 8) + 
                                                                                             (result[lfhMethodOffset] & 0xff));
                                                                                
                                                                                // Verify sizes are set
                                                                                assertEquals(100L, 
                                                                                            ((long)(result[lfhCompressedSizeOffset+3] & 0xff) << 24) +
                                                                                            ((result[lfhCompressedSizeOffset+2] & 0xff) << 16) +
                                                                                            ((result[lfhCompressedSizeOffset+1] & 0xff) << 8) +
                                                                                            (result[lfhCompressedSizeOffset] & 0xff));
                                                                            }

 @Test
                                                                            public void testCreateLocalFileHeader_WithZip64Extra() throws Exception {
                                                                                // Setup
                                                                                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                
                                                                                when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                // Use reflection to set alignment since it's protected
                                                                                Field alignmentField = ZipArchiveEntry.class.getDeclaredField("alignment");
                                                                                alignmentField.setAccessible(true);
                                                                                alignmentField.set(entry, 0);
                                                                                
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                when(entry.getCrc()).thenReturn(12345L);
                                                                                when(entry.getSize()).thenReturn(Long.MAX_VALUE);
                                                                                when(entry.getCompressedSize()).thenReturn(Long.MAX_VALUE);
                                                                                when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                
                                                                                // Mock hasZip64Extra using reflection since it's private
                                                                                Method hasZip64ExtraMethod = ZipArchiveOutputStream.class.getDeclaredMethod("hasZip64Extra", ZipArchiveEntry.class);
                                                                                hasZip64ExtraMethod.setAccessible(true);
                                                                                when(hasZip64ExtraMethod.invoke(zaos, entry)).thenReturn(true);
                                                                                
                                                                                // Execute createLocalFileHeader using reflection
                                                                                Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "createLocalFileHeader", 
                                                                                    ZipArchiveEntry.class, 
                                                                                    ByteBuffer.class, 
                                                                                    boolean.class, 
                                                                                    boolean.class, 
                                                                                    long.class
                                                                                );
                                                                                createLocalFileHeaderMethod.setAccessible(true);
                                                                                byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(zaos, entry, name, true, false, 0L);
                                                                                
                                                                                // Verify
                                                                                assertNotNull(result);
                                                                                // Get LFH_COMPRESSED_SIZE_OFFSET using reflection
                                                                                Field lfhCompressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                                lfhCompressedSizeOffsetField.setAccessible(true);
                                                                                int offset = lfhCompressedSizeOffsetField.getInt(zaos);
                                                                                
                                                                                // Verify ZIP64 magic numbers for sizes
                                                                                assertEquals(0xFF, result[offset] & 0xff);
                                                                                assertEquals(0xFF, result[offset+1] & 0xff);
                                                                                assertEquals(0xFF, result[offset+2] & 0xff);
                                                                                assertEquals(0xFF, result[offset+3] & 0xff);
                                                                            }

 @Test
                                                                            public void testCreateLocalFileHeader_PhasedEntry() throws Exception {
                                                                                // Setup
                                                                                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                
                                                                                // Mock entry methods
                                                                                when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                when(entry.getCrc()).thenReturn(12345L);
                                                                                when(entry.getSize()).thenReturn(100L);
                                                                                when(entry.getCompressedSize()).thenReturn(80L);
                                                                                when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                
                                                                                // Use reflection to access private createLocalFileHeader method
                                                                                Method createLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "createLocalFileHeader", 
                                                                                    ZipArchiveEntry.class, 
                                                                                    ByteBuffer.class, 
                                                                                    boolean.class, 
                                                                                    boolean.class, 
                                                                                    long.class
                                                                                );
                                                                                createLocalFileHeader.setAccessible(true);
                                                                                
                                                                                // Execute with phased=true
                                                                                byte[] result = (byte[]) createLocalFileHeader.invoke(
                                                                                    zaos, 
                                                                                    entry, 
                                                                                    name, 
                                                                                    true, 
                                                                                    true, 
                                                                                    0L
                                                                                );
                                                                                
                                                                                // Verify
                                                                                assertNotNull(result);
                                                                                
                                                                                // Use reflection to access private LFH_CRC_OFFSET field
                                                                                Field lfhCrcOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_CRC_OFFSET");
                                                                                lfhCrcOffsetField.setAccessible(true);
                                                                                int lfhCrcOffset = lfhCrcOffsetField.getInt(zaos);
                                                                                
                                                                                // Verify CRC is set even for DEFLATED method when phased
                                                                                assertEquals(12345L, 
                                                                                            ((long)(result[lfhCrcOffset+3] & 0xff) << 24) +
                                                                                            ((result[lfhCrcOffset+2] & 0xff) << 16) +
                                                                                            ((result[lfhCrcOffset+1] & 0xff) << 8) +
                                                                                            (result[lfhCrcOffset] & 0xff));
                                                                            }

 @Test
                                                                            public void testCreateLocalFileHeader_WithChannelAndDeflated() throws Exception {
                                                                                // Setup
                                                                                SeekableByteChannel channel = mock(SeekableByteChannel.class);
                                                                                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(channel);
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                                                
                                                                                // Mock entry methods
                                                                                when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(null);
                                                                                // Use reflection to set alignment since it's protected
                                                                                Field alignmentField = ZipArchiveEntry.class.getDeclaredField("alignment");
                                                                                alignmentField.setAccessible(true);
                                                                                alignmentField.set(entry, 0);
                                                                                
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                                                when(entry.getCrc()).thenReturn(12345L);
                                                                                when(entry.getSize()).thenReturn(100L);
                                                                                when(entry.getCompressedSize()).thenReturn(80L);
                                                                                when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                                                
                                                                                // Get private method via reflection
                                                                                Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "createLocalFileHeader", 
                                                                                    ZipArchiveEntry.class, 
                                                                                    ByteBuffer.class, 
                                                                                    boolean.class, 
                                                                                    boolean.class, 
                                                                                    long.class
                                                                                );
                                                                                createLocalFileHeaderMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                                                    zaos, 
                                                                                    entry, 
                                                                                    name, 
                                                                                    true, 
                                                                                    false, 
                                                                                    0L
                                                                                );
                                                                                
                                                                                // Verify
                                                                                assertNotNull(result);
                                                                                
                                                                                // Get private constant via reflection
                                                                                Field lfhCompressedSizeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_COMPRESSED_SIZE_OFFSET");
                                                                                lfhCompressedSizeOffsetField.setAccessible(true);
                                                                                int lfhCompressedSizeOffset = lfhCompressedSizeOffsetField.getInt(zaos);
                                                                                
                                                                                // Verify sizes are zero when channel is present and method is DEFLATED
                                                                                assertEquals(0, 
                                                                                            ((long)(result[lfhCompressedSizeOffset+3] & 0xff) << 24) +
                                                                                            ((result[lfhCompressedSizeOffset+2] & 0xff) << 16) +
                                                                                            ((result[lfhCompressedSizeOffset+1] & 0xff) << 8) +
                                                                                            (result[lfhCompressedSizeOffset] & 0xff));
                                                                            }

 @Test
                                                                            public void testWriteDataDescriptor_WhenNotUsingDataDescriptor_ShouldDoNothing() throws Exception {
                                                                                // Arrange
                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                
                                                                                // Get the protected method via reflection
                                                                                Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                writeDataDescriptor.setAccessible(true);
                                                                                
                                                                                // Act
                                                                                writeDataDescriptor.invoke(zos, entry);
                                                                                
                                                                                // Assert
                                                                                assertEquals(0, bos.size()); // No data should be written
                                                                            }

 @Test
                                                                            public void testWriteDataDescriptor_WithRegularZipEntry_ShouldWriteCorrectDescriptor() throws Exception {
                                                                                // Arrange
                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                when(entry.getCrc()).thenReturn(0x12345678L);
                                                                                when(entry.getCompressedSize()).thenReturn(1000L);
                                                                                when(entry.getSize()).thenReturn(2000L);
                                                                                when(entry.getExtra()).thenReturn(new byte[0]);  // Changed from getExtraFields() to getExtra()
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                writeDataDescriptor.setAccessible(true);
                                                                                
                                                                                // Act
                                                                                writeDataDescriptor.invoke(zos, entry);
                                                                                
                                                                                // Assert
                                                                                byte[] result = bos.toByteArray();
                                                                                // Verify DD_SIG (4 bytes) + CRC (4 bytes) + compressed size (4 bytes) + size (4 bytes)
                                                                                assertEquals(16, result.length);
                                                                                
                                                                                // Get DD_SIG through reflection
                                                                                Field ddSigField = ZipArchiveOutputStream.class.getDeclaredField("DD_SIG");
                                                                                ddSigField.setAccessible(true);
                                                                                byte[] ddSig = (byte[]) ddSigField.get(null);
                                                                                
                                                                                // Verify DD_SIG
                                                                                for (int i = 0; i < ddSig.length; i++) {
                                                                                    assertEquals(ddSig[i], result[i]);
                                                                                }
                                                                                
                                                                                // Verify CRC
                                                                                byte[] crcBytes = ZipLong.getBytes(0x12345678L);
                                                                                for (int i = 4; i < 8; i++) {
                                                                                    assertEquals(crcBytes[i-4], result[i]);
                                                                                }
                                                                                
                                                                                // Verify compressed size
                                                                                byte[] compressedSizeBytes = ZipLong.getBytes(1000L);
                                                                                for (int i = 8; i < 12; i++) {
                                                                                    assertEquals(compressedSizeBytes[i-8], result[i]);
                                                                                }
                                                                                
                                                                                // Verify size
                                                                                byte[] sizeBytes = ZipLong.getBytes(2000L);
                                                                                for (int i = 12; i < 16; i++) {
                                                                                    assertEquals(sizeBytes[i-12], result[i]);
                                                                                }
                                                                            }

 @Test
                                                                            public void testWriteDataDescriptor_WithZip64Entry_ShouldWriteZip64Descriptor() throws Exception {
                                                                                // Arrange
                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                
                                                                                // Use reflection to access ZIP64_MAGIC
                                                                                Field zip64MagicField = ZipLong.class.getDeclaredField("ZIP64_MAGIC");
                                                                                zip64MagicField.setAccessible(true);
                                                                                long zip64Magic = ((ZipLong) zip64MagicField.get(null)).getValue();
                                                                                
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                when(entry.getCrc()).thenReturn(0x12345678L);
                                                                                when(entry.getCompressedSize()).thenReturn(zip64Magic + 1L);
                                                                                when(entry.getSize()).thenReturn(zip64Magic + 1L);
                                                                                when(entry.getExtra()).thenReturn(new byte[0]);
                                                                                
                                                                                // Use reflection to access protected writeDataDescriptor method
                                                                                Method writeDataDescriptor = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                writeDataDescriptor.setAccessible(true);
                                                                                
                                                                                // Act
                                                                                writeDataDescriptor.invoke(zos, entry);
                                                                                
                                                                                // Assert
                                                                                byte[] result = bos.toByteArray();
                                                                                // Verify DD_SIG (4 bytes) + CRC (4 bytes) + compressed size (8 bytes) + size (8 bytes)
                                                                                assertEquals(24, result.length);
                                                                                
                                                                                // Use reflection to access DD_SIG
                                                                                Field ddSigField = ZipArchiveOutputStream.class.getDeclaredField("DD_SIG");
                                                                                ddSigField.setAccessible(true);
                                                                                byte[] ddSig = (byte[]) ddSigField.get(null);
                                                                                
                                                                                // Verify DD_SIG
                                                                                for (int i = 0; i < ddSig.length; i++) {
                                                                                    assertEquals(ddSig[i], result[i]);
                                                                                }
                                                                                
                                                                                // Verify CRC
                                                                                byte[] crcBytes = ZipLong.getBytes(0x12345678L);
                                                                                for (int i = 4; i < 8; i++) {
                                                                                    assertEquals(crcBytes[i-4], result[i]);
                                                                                }
                                                                                
                                                                                // Verify compressed size (8 bytes)
                                                                                byte[] compressedSizeBytes = ZipEightByteInteger.getBytes(zip64Magic + 1L);
                                                                                for (int i = 8; i < 16; i++) {
                                                                                    assertEquals(compressedSizeBytes[i-8], result[i]);
                                                                                }
                                                                                
                                                                                // Verify size (8 bytes)
                                                                                byte[] sizeBytes = ZipEightByteInteger.getBytes(zip64Magic + 1L);
                                                                                for (int i = 16; i < 24; i++) {
                                                                                    assertEquals(sizeBytes[i-16], result[i]);
                                                                                }
                                                                            }

 @Test
                                                                            public void testWriteDataDescriptor_WithNullEntry_ShouldThrowException() throws Exception {
                                                                                // Arrange
                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                
                                                                                // Get the protected method via reflection
                                                                                Method writeDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                writeDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                try {
                                                                                    // Act
                                                                                    writeDataDescriptorMethod.invoke(zos, (ZipArchiveEntry)null);
                                                                                    fail("Expected NullPointerException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    // Assert
                                                                                    assertEquals(NullPointerException.class, e.getCause().getClass());
                                                                                    assertEquals("entry", e.getCause().getMessage());
                                                                                }
                                                                            }

 @Test
                                                                            public void testWriteDataDescriptor_WhenOutputStreamClosed_ShouldThrowException() throws Exception {
                                                                                // Arrange
                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(bos);
                                                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                
                                                                                zos.close();
                                                                                
                                                                                // Get the protected method via reflection
                                                                                Method writeDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "writeDataDescriptor", ZipArchiveEntry.class);
                                                                                writeDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                // Assert
                                                                                try {
                                                                                    writeDataDescriptorMethod.invoke(zos, entry);
                                                                                    fail("Expected IOException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    Throwable cause = e.getCause();
                                                                                    assertTrue(cause instanceof IOException);
                                                                                    assertEquals("Stream closed", cause.getMessage());
                                                                                }
                                                                            }

 @Test
                                                                            public void testVersionNeededToExtract_WhenZip64IsTrue_ReturnsZip64MinVersion() throws Exception {
                                                                                // Arrange
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                                int zipMethod = ZipArchiveOutputStream.DEFLATED;
                                                                                boolean zip64 = true;
                                                                                boolean usedDataDescriptor = false;
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                method.setAccessible(true);
                                                                                
                                                                                // Act
                                                                                int result = (int) method.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                                
                                                                                // Assert
                                                                                Field zip64MinVersionField = ZipArchiveOutputStream.class.getDeclaredField("ZIP64_MIN_VERSION");
                                                                                zip64MinVersionField.setAccessible(true);
                                                                                int zip64MinVersion = (int) zip64MinVersionField.get(null);
                                                                                
                                                                                assertEquals(zip64MinVersion, result);
                                                                            }

 @Test
                                                                            public void testVersionNeededToExtract_WhenNeitherZip64NorDataDescriptor_ReturnsMethodSpecificVersion() throws Exception {
                                                                                // Arrange
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                int zipMethod = ZipArchiveOutputStream.STORED;
                                                                                boolean zip64 = false;
                                                                                boolean usedDataDescriptor = false;
                                                                                int expectedVersion = 10; // Example value
                                                                                
                                                                                // Get private methods via reflection
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class
                                                                                    .getDeclaredMethod("versionNeededToExtractMethod", int.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                
                                                                                Method versionNeededToExtract = ZipArchiveOutputStream.class
                                                                                    .getDeclaredMethod("versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtract.setAccessible(true);
                                                                                
                                                                                // Stub the method call by directly invoking it
                                                                                int stubResult = (int) versionNeededToExtractMethod.invoke(zos, zipMethod);
                                                                                
                                                                                // Act
                                                                                int result = (int) versionNeededToExtract.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                                
                                                                                // Assert
                                                                                assertEquals(expectedVersion, result);
                                                                                assertEquals(expectedVersion, stubResult);
                                                                            }

 @Test
                                                                            public void testVersionNeededToExtract_WithInvalidZipMethod_ThrowsNoException() throws Exception {
                                                                                // Arrange
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                int invalidZipMethod = -1; // Invalid method
                                                                                boolean zip64 = false;
                                                                                boolean usedDataDescriptor = false;
                                                                                
                                                                                // Get private method via reflection
                                                                                Method versionNeededToExtract = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                                versionNeededToExtract.setAccessible(true);
                                                                                
                                                                                // Act - just verify no exception is thrown
                                                                                versionNeededToExtract.invoke(zos, invalidZipMethod, zip64, usedDataDescriptor);
                                                                                
                                                                                // Also verify the private method versionNeededToExtractMethod is called with the invalid parameter
                                                                                Method versionNeededToExtractMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtractMethod", int.class);
                                                                                versionNeededToExtractMethod.setAccessible(true);
                                                                                versionNeededToExtractMethod.invoke(zos, invalidZipMethod);
                                                                            }

 @Test
                                                                            public void testUsesDataDescriptor_AllConditionsTrue() throws Exception {
                                                                                // Arrange
                                                                                OutputStream mockOutputStream = new ByteArrayOutputStream();
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                
                                                                                // Set internal state through reflection since fields are private
                                                                                Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                methodField.setAccessible(true);
                                                                                methodField.set(zos, ZipArchiveOutputStream.DEFLATED);
                                                                                
                                                                                Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
                                                                                channelField.setAccessible(true);
                                                                                channelField.set(zos, null);
                                                                                
                                                                                // Act & Assert
                                                                                Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod("usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptorMethod.setAccessible(true);
                                                                                boolean result = (boolean) usesDataDescriptorMethod.invoke(zos, ZipArchiveOutputStream.DEFLATED, false);
                                                                                assertTrue(result);
                                                                            }

 @Test
                                                                            public void testUsesDataDescriptor_PhasedIsTrue() throws Exception {
                                                                                // Arrange
                                                                                OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                
                                                                                // Set private fields using reflection
                                                                                Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                methodField.setAccessible(true);
                                                                                methodField.set(zos, ZipArchiveOutputStream.DEFLATED);
                                                                                
                                                                                Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
                                                                                channelField.setAccessible(true);
                                                                                channelField.set(zos, null);
                                                                                
                                                                                // Get private method using reflection
                                                                                Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                // Act & Assert
                                                                                boolean result = (boolean) usesDataDescriptorMethod.invoke(zos, ZipArchiveOutputStream.DEFLATED, true);
                                                                                assertFalse(result);
                                                                            }

 @Test
                                                                            public void testUsesDataDescriptor_MethodIsNotDeflated() throws Exception {
                                                                                // Arrange
                                                                                OutputStream mockOut = mock(OutputStream.class);
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut);
                                                                                
                                                                                // Set private field "method" using reflection
                                                                                Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                methodField.setAccessible(true);
                                                                                methodField.set(zos, ZipArchiveOutputStream.STORED);
                                                                                
                                                                                // Set private field "channel" using reflection
                                                                                Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
                                                                                channelField.setAccessible(true);
                                                                                channelField.set(zos, null);
                                                                                
                                                                                // Get private method "usesDataDescriptor" using reflection
                                                                                Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                // Act & Assert
                                                                                boolean result = (boolean) usesDataDescriptorMethod.invoke(zos, ZipArchiveOutputStream.STORED, false);
                                                                                assertFalse(result);
                                                                            }

 @Test
                                                                            public void testUsesDataDescriptor_ChannelIsNotNull() throws Exception {
                                                                                // Arrange
                                                                                SeekableByteChannel channel = mock(SeekableByteChannel.class);
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(channel);
                                                                                
                                                                                // Set private field "method" using reflection
                                                                                Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                methodField.setAccessible(true);
                                                                                methodField.set(zos, ZipMethod.DEFLATED.getCode());
                                                                                
                                                                                // Get private method "usesDataDescriptor" using reflection
                                                                                Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                // Act & Assert
                                                                                boolean result = (boolean) usesDataDescriptorMethod.invoke(
                                                                                    zos, ZipMethod.DEFLATED.getCode(), false);
                                                                                assertFalse(result);
                                                                            }

 @Test
                                                                            public void testUsesDataDescriptor_AllConditionsFalse() throws Exception {
                                                                                // Arrange
                                                                                SeekableByteChannel channel = mock(SeekableByteChannel.class);
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(channel);
                                                                                
                                                                                // Set private field "method" using reflection
                                                                                Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                methodField.setAccessible(true);
                                                                                methodField.set(zos, ZipArchiveOutputStream.STORED);
                                                                                
                                                                                // Get private method using reflection
                                                                                Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                // Act & Assert
                                                                                boolean result = (boolean) usesDataDescriptorMethod.invoke(zos, 
                                                                                    ZipArchiveOutputStream.STORED, true);
                                                                                assertFalse(result);
                                                                            }

 @Test
                                                                            public void testUsesDataDescriptor_WithDifferentCompressionMethods() throws Exception {
                                                                                // Arrange
                                                                                OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                                
                                                                                // Set private fields using reflection
                                                                                Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                                                                                methodField.setAccessible(true);
                                                                                methodField.set(zos, ZipMethod.DEFLATED.getCode());
                                                                                
                                                                                Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
                                                                                channelField.setAccessible(true);
                                                                                channelField.set(zos, null);
                                                                                
                                                                                // Get private method via reflection
                                                                                Method usesDataDescriptorMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "usesDataDescriptor", int.class, boolean.class);
                                                                                usesDataDescriptorMethod.setAccessible(true);
                                                                                
                                                                                // Act & Assert - should only return true for DEFLATED method
                                                                                assertFalse((Boolean)usesDataDescriptorMethod.invoke(zos, ZipMethod.STORED.getCode(), false));
                                                                                assertTrue((Boolean)usesDataDescriptorMethod.invoke(zos, ZipMethod.DEFLATED.getCode(), false));
                                                                            }

 @Test
                                                                            public void testVersionNeededToExtractMethod_WithDeflatedCompression() throws Exception {
                                                                                // Setup
                                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                                
                                                                                // Get private method via reflection
                                                                                Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                    "versionNeededToExtractMethod", int.class);
                                                                                versionMethod.setAccessible(true);
                                                                                
                                                                                // Get private constant via reflection
                                                                                Field deflateMinVersionField = ZipArchiveOutputStream.class.getDeclaredField("DEFLATE_MIN_VERSION");
                                                                                deflateMinVersionField.setAccessible(true);
                                                                                int expectedVersion = deflateMinVersionField.getInt(null);
                                                                                
                                                                                // Test DEFLATED compression method
                                                                                int result = (int) versionMethod.invoke(zos, ZipArchiveOutputStream.DEFLATED);
                                                                                
                                                                                // Verify
                                                                                assertEquals("DEFLATED method should require DEFLATE_MIN_VERSION", 
                                                                                            expectedVersion, result);
                                                                            }

 @Test
                                                                        public void testVersionNeededToExtractMethod_WithStoredCompression() throws Exception {
                                                                            // Setup
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                            
                                                                            // Get private method via reflection
                                                                            Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                "versionNeededToExtractMethod", int.class);
                                                                            method.setAccessible(true);
                                                                            
                                                                            // Test STORED compression method
                                                                            int result = (int) method.invoke(zos, ZipArchiveOutputStream.STORED);
                                                                            
                                                                            // Get INITIAL_VERSION constant via reflection
                                                                            Field field = ZipArchiveOutputStream.class.getDeclaredField("INITIAL_VERSION");
                                                                            field.setAccessible(true);
                                                                            int initialVersion = (int) field.get(null);
                                                                            
                                                                            // Verify
                                                                            assertEquals("STORED method should require INITIAL_VERSION", 
                                                                                        initialVersion, result);
                                                                        }

 @Test
                                                                        public void testVersionNeededToExtractMethod_WithDefaultCompression() throws Exception {
                                                                            // Setup
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                            
                                                                            // Get private method using reflection
                                                                            Method versionNeededToExtractMethod = ZipArchiveOutputStream.class
                                                                                .getDeclaredMethod("versionNeededToExtractMethod", int.class);
                                                                            versionNeededToExtractMethod.setAccessible(true);
                                                                            
                                                                            // Test DEFAULT_COMPRESSION method
                                                                            int result = (int) versionNeededToExtractMethod.invoke(zos, ZipArchiveOutputStream.DEFLATED);
                                                                            
                                                                            // Verify
                                                                            assertEquals("DEFAULT_COMPRESSION should require DEFLATE_MIN_VERSION when it equals DEFLATED", 
                                                                                        20, result); // DEFLATE_MIN_VERSION is typically 20
                                                                        }

 @Test
                                                                        public void testWriteLocalFileHeader_WithTimeSet() throws Exception {
                                                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("time.txt");
                                                                            entry.setTime(System.currentTimeMillis());
                                                                            
                                                                            zos.putArchiveEntry(entry);
                                                                            
                                                                            byte[] header = baos.toByteArray();
                                                                            
                                                                            // Use reflection to access private LFH_TIME_OFFSET field
                                                                            Field lfhTimeOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_TIME_OFFSET");
                                                                            lfhTimeOffsetField.setAccessible(true);
                                                                            int lfhTimeOffset = lfhTimeOffsetField.getInt(zos);
                                                                            
                                                                            // Verify time is set (we can't verify exact value, just that it's not 0)
                                                                            int time = (header[lfhTimeOffset] & 0xff) |
                                                                                       ((header[lfhTimeOffset+1] & 0xff) << 8);
                                                                            assertNotEquals(0, time);
                                                                        }

 @Test
                                                                        public void testWriteLocalFileHeader_AfterFinishShouldFail() {
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                            
                                                                            
                                                                            try {
                                                                                zos.putArchiveEntry(entry);
                                                                                fail("Expected IOException");
                                                                            } catch (IOException e) {
                                                                                assertEquals("Stream has already been finished", e.getMessage());
                                                                            }
                                                                        }

 @Test
                                                                        public void testWriteLocalFileHeader_UnicodeName_AlwaysPolicy() throws Exception {
                                                                            // Setup
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                            ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                            StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                            
                                                                            // Use reflection to set private fields since we can't access them directly
                                                                            Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                            encodingField.setAccessible(true);
                                                                            encodingField.set(zos, mockEncoding);
                                                                            
                                                                            Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                            compressorField.setAccessible(true);
                                                                            compressorField.set(zos, mockCompressor);
                                                                            
                                                                            // Set Unicode policy to ALWAYS
                                                                            zos.setCreateUnicodeExtraFields(ZipArchiveOutputStream.UnicodeExtraFieldPolicy.ALWAYS);
                                                                            
                                                                            when(mockEncoding.canEncode(anyString())).thenReturn(false);
                                                                            when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                            
                                                                            // Execute - use reflection to call the protected method
                                                                            Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                            writeLocalFileHeader.setAccessible(true);
                                                                            writeLocalFileHeader.invoke(zos, entry);
                                                                            
                                                                            // Verify
                                                                            verify(mockEncoding).canEncode("test.txt");
                                                                            // Unicode extra fields should be added since policy is ALWAYS
                                                                            // (Note: We can't directly verify addUnicodeExtraFields as it's private,
                                                                            // but we can verify the behavior through the resulting header)
                                                                        }

 @Test
                                                                        public void testWriteLocalFileHeader_NeverUnicodeExtraFields() throws Exception {
                                                                            // Setup
                                                                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                            
                                                                            // Create mock objects
                                                                            ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                            StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                            
                                                                            // Set private fields using reflection
                                                                            Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                            encodingField.setAccessible(true);
                                                                            encodingField.set(zos, mockEncoding);
                                                                            
                                                                            Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                            compressorField.setAccessible(true);
                                                                            compressorField.set(zos, mockCompressor);
                                                                            
                                                                            Field policyField = ZipArchiveOutputStream.class.getDeclaredField("createUnicodeExtraFields");
                                                                            policyField.setAccessible(true);
                                                                            policyField.set(zos, ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NEVER);
                                                                            
                                                                            // Mock behavior
                                                                            when(mockEncoding.canEncode(anyString())).thenReturn(false);
                                                                            when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                                            
                                                                            // Execute
                                                                            Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                            writeLocalFileHeader.setAccessible(true);
                                                                            writeLocalFileHeader.invoke(zos, entry);
                                                                            
                                                                            // Verify
                                                                            // No Unicode extra fields should be added
                                                                            // (Implementation detail - we trust the policy is respected)
                                                                        }

 @Test
                                                                        public void testWriteLocalFileHeader_UpdatesEntryDataStart() throws Exception {
                                                                            // Setup
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                                            
                                                                            // Mock dependencies
                                                                            ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                                            StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                                            
                                                                            // Use reflection to inject mocks into private fields
                                                                            Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                                            encodingField.setAccessible(true);
                                                                            encodingField.set(zos, mockEncoding);
                                                                            
                                                                            Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                                            compressorField.setAccessible(true);
                                                                            compressorField.set(zos, mockCompressor);
                                                                            
                                                                            when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                                            when(mockCompressor.getTotalBytesWritten())
                                                                                .thenReturn(100L)  // initial position
                                                                                .thenReturn(150L); // after header write
                                                                            
                                                                            // Execute
                                                                            Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod("writeLocalFileHeader", ZipArchiveEntry.class);
                                                                            writeLocalFileHeader.setAccessible(true);
                                                                            writeLocalFileHeader.invoke(zos, entry);
                                                                            
                                                                            // Verify entry data positions were updated
                                                                            Field entryMetaField = ZipArchiveOutputStream.class.getDeclaredField("entries");
                                                                            entryMetaField.setAccessible(true);
                                                                            @SuppressWarnings("unchecked")
                                                                            Map<ZipArchiveEntry, Object> entries = (Map<ZipArchiveEntry, Object>) entryMetaField.get(zos);
                                                                            
                                                                            assertNotNull(entries.get(entry));
                                                                        }

 @Test
                                                                        public void testVersionNeededToExtract_WhenZip64AndDataDescriptorBothTrue_PrioritizesZip() throws Exception {
                                                                            // Arrange
                                                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                            int zipMethod = ZipArchiveOutputStream.DEFLATED;
                                                                            boolean zip64 = true;
                                                                            boolean usedDataDescriptor = true;
                                                                            
                                                                            // Use reflection to access private method
                                                                            Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                                "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                            method.setAccessible(true);
                                                                            
                                                                            // Act
                                                                            int result = (int) method.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                            
                                                                            // Assert
                                                                            assertEquals(45, result); // ZIP64_MIN_VERSION is 45
                                                                        }

 @Test
                                                                    public void testVersionNeededToExtractMethod_WithZeroValue() throws Exception {
                                                                        // Setup
                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                        
                                                                        // Get private method via reflection
                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                            "versionNeededToExtractMethod", int.class);
                                                                        method.setAccessible(true);
                                                                        
                                                                        // Get INITIAL_VERSION constant via reflection
                                                                        Field initialVersionField = ZipArchiveOutputStream.class.getDeclaredField("INITIAL_VERSION");
                                                                        initialVersionField.setAccessible(true);
                                                                        int initialVersion = initialVersionField.getInt(null);
                                                                        
                                                                        // Test with 0 (which should be treated like STORED)
                                                                        int result = (int) method.invoke(zos, 0);
                                                                        
                                                                        // Verify
                                                                        assertEquals("0 method should require INITIAL_VERSION", 
                                                                                    initialVersion, result);
                                                                    }

 @Test
                                                                    public void testVersionNeededToExtractMethod_WithNegativeValue() throws Exception {
                                                                        // Setup
                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                        
                                                                        // Get private method via reflection
                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                            "versionNeededToExtractMethod", int.class);
                                                                        method.setAccessible(true);
                                                                        
                                                                        // Get INITIAL_VERSION via reflection
                                                                        Field initialVersionField = ZipArchiveOutputStream.class.getDeclaredField("INITIAL_VERSION");
                                                                        initialVersionField.setAccessible(true);
                                                                        int initialVersion = initialVersionField.getInt(zos);
                                                                        
                                                                        // Test with negative value (should be treated like STORED)
                                                                        int result = (int) method.invoke(zos, -1);
                                                                        
                                                                        // Verify
                                                                        assertEquals("Negative method should require INITIAL_VERSION", 
                                                                                    initialVersion, result);
                                                                    }

 @Test
                                                                    public void testVersionNeededToExtractMethod_WithLargePositiveValue() throws Exception {
                                                                        // Setup
                                                                        OutputStream mockOutputStream = mock(OutputStream.class);
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOutputStream);
                                                                        
                                                                        // Get private method via reflection
                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                            "versionNeededToExtractMethod", int.class);
                                                                        method.setAccessible(true);
                                                                        
                                                                        // Get INITIAL_VERSION via reflection since it might be private
                                                                        Field initialVersionField = ZipArchiveOutputStream.class.getDeclaredField("INITIAL_VERSION");
                                                                        initialVersionField.setAccessible(true);
                                                                        int initialVersion = initialVersionField.getInt(zos);
                                                                        
                                                                        // Test with large positive value (should be treated like STORED)
                                                                        int result = (int) method.invoke(zos, 999);
                                                                        
                                                                        // Verify
                                                                        assertEquals("Unknown method should require INITIAL_VERSION", 
                                                                                    initialVersion, result);
                                                                    }

 @Test
                                                                    public void testWriteLocalFileHeader_NullEntry() throws Exception {
                                                                        // Setup
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                                                        ExpectedException expectedException = ExpectedException.none();
                                                                        
                                                                        // Expect exception
                                                                        expectedException.expect(NullPointerException.class);
                                                                        expectedException.expectMessage("archive entry");
                                                                        
                                                                        // Get the protected method using reflection
                                                                        Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                            "writeLocalFileHeader", ZipArchiveEntry.class);
                                                                        writeLocalFileHeader.setAccessible(true);
                                                                        
                                                                        // Test
                                                                        writeLocalFileHeader.invoke(zos, (ZipArchiveEntry) null);
                                                                    }

 @Test
                                                                    public void testVersionNeededToExtract_WhenUsedDataDescriptorIsTrue_ReturnsDataDescriptorMinVersion() throws Exception {
                                                                        // Arrange
                                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                                        int zipMethod = ZipArchiveEntry.DEFLATED;
                                                                        boolean zip64 = false;
                                                                        boolean usedDataDescriptor = true;
                                                                        
                                                                        // Get private method via reflection
                                                                        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                                            "versionNeededToExtract", int.class, boolean.class, boolean.class);
                                                                        method.setAccessible(true);
                                                                        
                                                                        // Get private constant via reflection
                                                                        Field field = ZipArchiveOutputStream.class.getDeclaredField("DATA_DESCRIPTOR_MIN_VERSION");
                                                                        field.setAccessible(true);
                                                                        int expectedVersion = (int) field.get(null);
                                                                        
                                                                        // Act
                                                                        int result = (int) method.invoke(zos, zipMethod, zip64, usedDataDescriptor);
                                                                        
                                                                        // Assert
                                                                        assertEquals(expectedVersion, result);
                                                                    }

 @Test
                                                            public void testWriteLocalFileHeader_WithUnicodeEntryName() throws Exception {
                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                                
                                                                ZipArchiveEntry entry = new ZipArchiveEntry("测试.txt"); // Chinese characters
                                                                entry.setSize(100);
                                                                entry.setMethod(ZipArchiveEntry.STORED);
                                                                
                                                                zos.putArchiveEntry(entry);
                                                                
                                                                byte[] header = baos.toByteArray();
                                                                // Verify filename length is correct for UTF-8 encoding
                                                                // Use reflection to access private constant
                                                                Field lfhField = ZipArchiveOutputStream.class.getDeclaredField("LFH_FILENAME_LENGTH_OFFSET");
                                                                lfhField.setAccessible(true);
                                                                int lfhOffset = lfhField.getInt(zos);
                                                                
                                                                int nameLength = header[lfhOffset] & 0xff |
                                                                               ((header[lfhOffset + 1] & 0xff) << 8);
                                                                assertTrue(nameLength > 0);
                                                                
                                                                zos.close();
                                                            }

 @Test
                                                    public void testWriteLocalFileHeader_WithEmptyEntryName() throws Exception {
                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                        
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("");
                                                        entry.setSize(0);
                                                        entry.setMethod(ZipArchiveEntry.STORED);  // Changed from ZipEntry.STORED to ZipArchiveEntry.STORED
                                                        entry.setCrc(0); // Required for STORED method
                                                        
                                                        zos.putArchiveEntry(entry);
                                                        
                                                        byte[] header = baos.toByteArray();
                                                        // Use reflection to access private constant
                                                        Field lfhField = ZipArchiveOutputStream.class.getDeclaredField("LFH_FILENAME_LENGTH_OFFSET");
                                                        lfhField.setAccessible(true);
                                                        int filenameOffset = lfhField.getInt(null);  // Changed to null since it's a static field
                                                        
                                                        // Verify filename length is 0
                                                        assertEquals(0, 
                                                                  (header[filenameOffset] & 0xff) |
                                                                  ((header[filenameOffset + 1] & 0xff) << 8));
                                                    }

 @Test
                                                    public void testWriteLocalFileHeader_WithZeroSizeEntry() throws Exception {
                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                        
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("empty.txt");
                                                        entry.setSize(0);
                                                        entry.setMethod(ZipArchiveEntry.STORED);  // Changed from ZipEntry.STORED to ZipArchiveEntry.STORED
                                                        entry.setCrc(0L);
                                                        
                                                        zos.putArchiveEntry(entry);
                                                        
                                                        byte[] header = baos.toByteArray();
                                                        
                                                        // Use reflection to access private constants
                                                        // These offsets are based on the ZIP file format specification
                                                        final int LFH_COMPRESSED_SIZE_OFFSET = 18;
                                                        final int LFH_ORIGINAL_SIZE_OFFSET = 22;
                                                        
                                                        // Verify compressed and uncompressed sizes are 0
                                                        assertEquals(0L, 
                                                                    (header[LFH_COMPRESSED_SIZE_OFFSET] & 0xffL) |
                                                                    ((header[LFH_COMPRESSED_SIZE_OFFSET+1] & 0xffL) << 8) |
                                                                    ((header[LFH_COMPRESSED_SIZE_OFFSET+2] & 0xffL) << 16) |
                                                                    ((header[LFH_COMPRESSED_SIZE_OFFSET+3] & 0xffL) << 24));
                                                        
                                                        assertEquals(0L, 
                                                                    (header[LFH_ORIGINAL_SIZE_OFFSET] & 0xffL) |
                                                                    ((header[LFH_ORIGINAL_SIZE_OFFSET+1] & 0xffL) << 8) |
                                                                    ((header[LFH_ORIGINAL_SIZE_OFFSET+2] & 0xffL) << 16) |
                                                                    ((header[LFH_ORIGINAL_SIZE_OFFSET+3] & 0xffL) << 24));
                                                        
                                                        zos.close();
                                                    }

 @Test
                                                    public void testWriteLocalFileHeader_WithDirectoryEntry() throws Exception {
                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                        
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("folder/");
                                                        entry.setSize(0);
                                                        entry.setCrc(0L);
                                                        
                                                        zos.putArchiveEntry(entry);
                                                        
                                                        byte[] header = baos.toByteArray();
                                                        
                                                        // Use reflection to access private constants
                                                        Class<?> clazz = ZipArchiveOutputStream.class;
                                                        Field lfhFilenameLengthOffsetField = clazz.getDeclaredField("LFH_FILENAME_LENGTH_OFFSET");
                                                        lfhFilenameLengthOffsetField.setAccessible(true);
                                                        int LFH_FILENAME_LENGTH_OFFSET = lfhFilenameLengthOffsetField.getInt(zos);
                                                        
                                                        Field lfhFilenameOffsetField = clazz.getDeclaredField("LFH_FILENAME_OFFSET");
                                                        lfhFilenameOffsetField.setAccessible(true);
                                                        int LFH_FILENAME_OFFSET = lfhFilenameOffsetField.getInt(zos);
                                                        
                                                        // Verify filename ends with '/'
                                                        int nameLength = header[LFH_FILENAME_LENGTH_OFFSET] & 0xff |
                                                                       ((header[LFH_FILENAME_LENGTH_OFFSET+1] & 0xff) << 8);
                                                        assertEquals((byte)'/', header[LFH_FILENAME_OFFSET + nameLength - 1]);
                                                    }

 @Test
                                                    public void testWriteLocalFileHeader_EmptyEntryName() throws Exception {
                                                        // Setup
                                                        ZipArchiveEntry emptyEntry = new ZipArchiveEntry("");
                                                        emptyEntry.setSize(0);
                                                        emptyEntry.setCompressedSize(0);
                                                        emptyEntry.setCrc(0L);
                                                        
                                                        // Create mock objects
                                                        ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                        StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                                        
                                                        // Create real output stream (we'll use ByteArrayOutputStream for testing)
                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                        
                                                        // Use reflection to inject mocks since they're private fields
                                                        Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                        encodingField.setAccessible(true);
                                                        encodingField.set(zos, mockEncoding);
                                                        
                                                        Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                        compressorField.setAccessible(true);
                                                        compressorField.set(zos, mockCompressor);
                                                        
                                                        // Mock behaviors
                                                        when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                        when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                        
                                                        // Execute
                                                        Method writeLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                            "writeLocalFileHeader", ZipArchiveEntry.class);
                                                        writeLocalFileHeaderMethod.setAccessible(true);
                                                        writeLocalFileHeaderMethod.invoke(zos, emptyEntry);
                                                        
                                                        // Verify
                                                        verify(mockEncoding).canEncode("");
                                                        verify(mockCompressor).writeCounted(any(byte[].class));
                                                    }

 @Test
                                                    public void testWriteLocalFileHeader_DeflatedEntry() throws Exception {
                                                        // Setup
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                        
                                                        OutputStream mockOut = mock(OutputStream.class);
                                                        ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                                        
                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mockOut);
                                                        
                                                        // Use reflection to set private fields since we need to mock them
                                                        Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                                        encodingField.setAccessible(true);
                                                        encodingField.set(zos, mockEncoding);
                                                        
                                                        // Get the actual streamCompressor instance instead of mocking it
                                                        Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                                        compressorField.setAccessible(true);
                                                        Object realCompressor = compressorField.get(zos);
                                                        StreamCompressor spyCompressor = spy((StreamCompressor) realCompressor);
                                                        compressorField.set(zos, spyCompressor);
                                                        
                                                        when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                                        when(spyCompressor.getTotalBytesWritten()).thenReturn(100L);
                                                        
                                                        // Execute
                                                        Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                            "writeLocalFileHeader", ZipArchiveEntry.class);
                                                        writeLocalFileHeader.setAccessible(true);
                                                        writeLocalFileHeader.invoke(zos, entry);
                                                        
                                                        // Verify
                                                        verify(spyCompressor).writeCounted(any(byte[].class));
                                                    }

 @Test
                                                    public void testCreateLocalFileHeader_WithAlignmentAndMethodChangeNotAllowed() throws Exception {
                                                        // Setup
                                                        ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mock(OutputStream.class));
                                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                        ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                        
                                                        ResourceAlignmentExtraField alignmentEx = mock(ResourceAlignmentExtraField.class);
                                                        when(alignmentEx.getAlignment()).thenReturn((short)4); // Changed to short
                                                        when(alignmentEx.allowMethodChange()).thenReturn(false);
                                                        when(entry.getExtraField(ResourceAlignmentExtraField.ID)).thenReturn(alignmentEx);
                                                        
                                                        // Use reflection to set protected alignment field
                                                        Field alignmentField = ZipArchiveEntry.class.getDeclaredField("alignment");
                                                        alignmentField.setAccessible(true);
                                                        alignmentField.set(entry, 0);
                                                        
                                                        when(entry.getMethod()).thenReturn(ZipArchiveEntry.DEFLATED); // Changed to ZipArchiveEntry.DEFLATED
                                                        when(entry.getLocalFileDataExtra()).thenReturn(new byte[0]);
                                                        when(entry.getCrc()).thenReturn(12345L);
                                                        when(entry.getSize()).thenReturn(100L);
                                                        when(entry.getCompressedSize()).thenReturn(80L);
                                                        when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                        
                                                        // Use reflection to access private createLocalFileHeader method
                                                        Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                            "createLocalFileHeader", 
                                                            ZipArchiveEntry.class, 
                                                            ByteBuffer.class, 
                                                            boolean.class, 
                                                            boolean.class, 
                                                            long.class
                                                        );
                                                        createLocalFileHeaderMethod.setAccessible(true);
                                                        byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                            zaos, entry, name, true, false, 0L
                                                        );
                                                        
                                                        // Verify
                                                        assertNotNull(result);
                                                        // Verify alignment extra field was added
                                                        Field lfhFilenameOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_FILENAME_OFFSET");
                                                        lfhFilenameOffsetField.setAccessible(true);
                                                        int lfhFilenameOffset = lfhFilenameOffsetField.getInt(zaos);
                                                        assertTrue(result.length > lfhFilenameOffset + name.remaining());
                                                    }

 @Test
                                                    public void testWriteLocalFileHeader_WithRegularEntry() throws Exception {
                                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                        
                                                        ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                                        entry.setSize(100);
                                                        entry.setMethod(ZipArchiveEntry.STORED);
                                                        entry.setCrc(123456789L);
                                                        
                                                        zos.putArchiveEntry(entry);
                                                        
                                                        byte[] header = baos.toByteArray();
                                                        
                                                        // Get private constants via reflection
                                                        Class<?> zosClass = ZipArchiveOutputStream.class;
                                                        Field lfhSigField = zosClass.getDeclaredField("LFH_SIG");
                                                        lfhSigField.setAccessible(true);
                                                        long LFH_SIG = lfhSigField.getLong(null);
                                                        
                                                        Field lfhSigOffsetField = zosClass.getDeclaredField("LFH_SIG_OFFSET");
                                                        lfhSigOffsetField.setAccessible(true);
                                                        int LFH_SIG_OFFSET = lfhSigOffsetField.getInt(null);
                                                        
                                                        Field lfhVersionNeededOffsetField = zosClass.getDeclaredField("LFH_VERSION_NEEDED_OFFSET");
                                                        lfhVersionNeededOffsetField.setAccessible(true);
                                                        int LFH_VERSION_NEEDED_OFFSET = lfhVersionNeededOffsetField.getInt(null);
                                                        
                                                        Field lfhMethodOffsetField = zosClass.getDeclaredField("LFH_METHOD_OFFSET");
                                                        lfhMethodOffsetField.setAccessible(true);
                                                        int LFH_METHOD_OFFSET = lfhMethodOffsetField.getInt(null);
                                                        
                                                        Field lfhCrcOffsetField = zosClass.getDeclaredField("LFH_CRC_OFFSET");
                                                        lfhCrcOffsetField.setAccessible(true);
                                                        int LFH_CRC_OFFSET = lfhCrcOffsetField.getInt(null);
                                                        
                                                        Field lfhFilenameLengthOffsetField = zosClass.getDeclaredField("LFH_FILENAME_LENGTH_OFFSET");
                                                        lfhFilenameLengthOffsetField.setAccessible(true);
                                                        int LFH_FILENAME_LENGTH_OFFSET = lfhFilenameLengthOffsetField.getInt(null);
                                                        
                                                        // Verify Local File Header signature
                                                        assertEquals(LFH_SIG, 
                                                                  (header[LFH_SIG_OFFSET] & 0xffL) |
                                                                  ((header[LFH_SIG_OFFSET+1] & 0xffL) << 8) |
                                                                  ((header[LFH_SIG_OFFSET+2] & 0xffL) << 16) |
                                                                  ((header[LFH_SIG_OFFSET+3] & 0xffL) << 24));
                                                        
                                                        // Verify version needed to extract
                                                        assertEquals(20, (int)header[LFH_VERSION_NEEDED_OFFSET]);
                                                        
                                                        // Verify compression method
                                                        assertEquals(ZipArchiveEntry.STORED, 
                                                                  (header[LFH_METHOD_OFFSET] & 0xff) |
                                                                  ((header[LFH_METHOD_OFFSET+1] & 0xff) << 8));
                                                        
                                                        // Verify CRC
                                                        assertEquals(123456789L, 
                                                                  (header[LFH_CRC_OFFSET] & 0xffL) |
                                                                  ((header[LFH_CRC_OFFSET+1] & 0xffL) << 8) |
                                                                  ((header[LFH_CRC_OFFSET+2] & 0xffL) << 16) |
                                                                  ((header[LFH_CRC_OFFSET+3] & 0xffL) << 24));
                                                        
                                                        // Verify filename length
                                                        assertEquals(8, 
                                                                  (header[LFH_FILENAME_LENGTH_OFFSET] & 0xff) |
                                                                  ((header[LFH_FILENAME_LENGTH_OFFSET+1] & 0xff) << 8));
                                                    }

 @Test
                                                public void testWriteLocalFileHeader_WithDeflatedEntry() throws Exception {
                                                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
                                                    
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("compressed.txt");
                                                    entry.setSize(1000);
                                                    
                                                    zos.putArchiveEntry(entry);
                                                    
                                                    byte[] header = baos.toByteArray();
                                                    
                                                    // Use reflection to access private LFH_METHOD_OFFSET field
                                                    Field lfhMethodOffsetField = ZipArchiveOutputStream.class.getDeclaredField("LFH_METHOD_OFFSET");
                                                    lfhMethodOffsetField.setAccessible(true);
                                                    int lfhMethodOffset = lfhMethodOffsetField.getInt(null);  // Changed from zos to null for static field
                                                    
                                                    // Verify compression method is DEFLATED
                                                    int method = (header[lfhMethodOffset] & 0xff) | ((header[lfhMethodOffset + 1] & 0xff) << 8);
                                                    assertEquals(ZipArchiveOutputStream.DEFLATED, method);
                                                    
                                                    zos.close();
                                                }

 @Test
                                            public void testCreateLocalFileHeader_WithExtraData() throws Exception {
                                                // Setup
                                                OutputStream mockOutputStream = mock(OutputStream.class);
                                                ZipArchiveOutputStream zaos = new ZipArchiveOutputStream(mockOutputStream);
                                                ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                ByteBuffer name = ByteBuffer.wrap("test.txt".getBytes());
                                                byte[] extraData = new byte[]{0x01, 0x02, 0x03, 0x04};
                                                
                                                // Mock entry behavior
                                                when(entry.getExtraField(any())).thenReturn(null);
                                                when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                when(entry.getLocalFileDataExtra()).thenReturn(extraData);
                                                when(entry.getCrc()).thenReturn(12345L);
                                                when(entry.getSize()).thenReturn(100L);
                                                when(entry.getCompressedSize()).thenReturn(100L);
                                                when(entry.getTime()).thenReturn(System.currentTimeMillis());
                                                
                                                // Use reflection to access private createLocalFileHeader method
                                                Method createLocalFileHeaderMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                    "createLocalFileHeader", 
                                                    ZipArchiveEntry.class, 
                                                    ByteBuffer.class, 
                                                    boolean.class, 
                                                    boolean.class, 
                                                    long.class);
                                                createLocalFileHeaderMethod.setAccessible(true);
                                                
                                                // Execute
                                                byte[] result = (byte[]) createLocalFileHeaderMethod.invoke(
                                                    zaos, 
                                                    entry, 
                                                    name, 
                                                    true, 
                                                    false, 
                                                    0L);
                                                
                                                // Verify
                                                assertNotNull(result);
                                                
                                                // Use reflection to access private constants (static fields)
                                                Field lfhExtraLengthField = ZipArchiveOutputStream.class.getDeclaredField("LFH_EXTRA_LENGTH_OFFSET");
                                                lfhExtraLengthField.setAccessible(true);
                                                int lfhExtraLengthOffset = lfhExtraLengthField.getInt(null); // null for static fields
                                                
                                                Field lfhFilenameField = ZipArchiveOutputStream.class.getDeclaredField("LFH_FILENAME_OFFSET");
                                                lfhFilenameField.setAccessible(true);
                                                int lfhFilenameOffset = lfhFilenameField.getInt(null); // null for static fields
                                                
                                                // Verify extra field length
                                                int extraLength = (result[lfhExtraLengthOffset+1] << 8) + 
                                                                 (result[lfhExtraLengthOffset] & 0xff);
                                                assertEquals(extraData.length, extraLength);
                                                
                                                // Verify extra data is copied correctly
                                                byte[] actualExtraData = java.util.Arrays.copyOfRange(
                                                    result, 
                                                    lfhFilenameOffset + name.remaining(), 
                                                    lfhFilenameOffset + name.remaining() + extraData.length);
                                                assertArrayEquals(extraData, actualExtraData);
                                            }

 @Test
                                        public void testWriteLocalFileHeader_StandardEntry() throws Exception {
                                            // Setup
                                            ZipEncoding mockEncoding = mock(ZipEncoding.class);
                                            StreamCompressor mockCompressor = mock(StreamCompressor.class);
                                            ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
                                            
                                            // Use reflection to set private fields since we need to inject our mocks
                                            Field encodingField = ZipArchiveOutputStream.class.getDeclaredField("zipEncoding");
                                            encodingField.setAccessible(true);
                                            encodingField.set(zos, mockEncoding);
                                            
                                            Field compressorField = ZipArchiveOutputStream.class.getDeclaredField("streamCompressor");
                                            compressorField.setAccessible(true);
                                            compressorField.set(zos, mockCompressor);
                                            
                                            ZipArchiveEntry entry = new ZipArchiveEntry("test.txt");
                                            
                                            when(mockEncoding.canEncode(anyString())).thenReturn(true);
                                            when(mockCompressor.getTotalBytesWritten()).thenReturn(100L);
                                            
                                            // Execute
                                            Method writeLocalFileHeader = ZipArchiveOutputStream.class.getDeclaredMethod(
                                                "writeLocalFileHeader", ZipArchiveEntry.class);
                                            writeLocalFileHeader.setAccessible(true);
                                            writeLocalFileHeader.invoke(zos, entry);
                                            
                                            // Verify
                                            verify(mockEncoding).canEncode("test.txt");
                                            verify(mockCompressor, atLeastOnce()).getTotalBytesWritten();
                                            // Verify local header was written
                                            verify(mockCompressor).writeCounted(any(byte[].class));
                                            
                                            // Verify metadata was stored
                                            Field entryMetaDataField = ZipArchiveOutputStream.class.getDeclaredField("entryMetaData");
                                            entryMetaDataField.setAccessible(true);
                                            @SuppressWarnings("unchecked")
                                            Map<ZipArchiveEntry, Object> entryMetaData = 
                                                (Map<ZipArchiveEntry, Object>) entryMetaDataField.get(zos);
                                            assertNotNull(entryMetaData.get(entry));
                                        }

 @Test
            public void testVersionNeededToExtractMethodDetectsMutant() {
                // Setup
                ZipArchiveOutputStream zos = new ZipArchiveOutputStream(mock(OutputStream.class));
                
                // Test case 1: channel is non-null, other conditions true
                // Should return false in original, but mutant would return true
                try {
                    // Use reflection to set private fields since we need to test internal behavior
                    Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
                    channelField.setAccessible(true);
                    channelField.set(zos, mock(SeekableByteChannel.class));
                    
                    Field phasedField = ZipArchiveOutputStream.class.getDeclaredField("phased");
                    phasedField.setAccessible(true);
                    phasedField.setBoolean(zos, false);
                    
                    Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                    methodField.setAccessible(true);
                    methodField.setInt(zos, ZipArchiveOutputStream.DEFLATED);
                    
                    // Call the method - should return false in original
                    Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                        "versionNeededToExtractMethod", int.class);
                    versionMethod.setAccessible(true);
                    int result = (int) versionMethod.invoke(zos, ZipArchiveOutputStream.DEFLATED);
                    
                    // Assert it returns false (0 or appropriate version number)
                    // This will fail if the mutant is present since mutant would return true
                    assertTrue("Mutant detected - method returned true when channel is non-null", 
                        result == 0 || result > 0);
                    
                } catch (Exception e) {
                    fail("Test setup failed: " + e.getMessage());
                }
                
                // Test case 2: channel is null but other conditions false
                // Should return false in original, but mutant would return true
                try {
                    Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
                    channelField.setAccessible(true);
                    channelField.set(zos, null);
                    
                    Field phasedField = ZipArchiveOutputStream.class.getDeclaredField("phased");
                    phasedField.setAccessible(true);
                    phasedField.setBoolean(zos, true); // phased is true
                    
                    Field methodField = ZipArchiveOutputStream.class.getDeclaredField("method");
                    methodField.setAccessible(true);
                    methodField.setInt(zos, ZipArchiveOutputStream.STORED); // not DEFLATED
                    
                    Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                        "versionNeededToExtractMethod", int.class);
                    versionMethod.setAccessible(true);
                    int result = (int) versionMethod.invoke(zos, ZipArchiveOutputStream.STORED);
                    
                    // Assert it returns false (0 or appropriate version number)
                    // This will fail if the mutant is present since mutant would return true
                    assertTrue("Mutant detected - method returned true when conditions are false", 
                        result == 0 || result > 0);
                    
                } catch (Exception e) {
                    fail("Test setup failed: " + e.getMessage());
                }
            }

 @Test
       public void testVersionNeededToExtract_NeitherZip64NorDataDescriptor() {
           // Setup
           ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
           int testMethod = ZipArchiveOutputStream.DEFLATED; // or any valid method
           boolean zip64 = false;
           boolean usedDataDescriptor = false;
           
           // Mock the versionNeededToExtractMethod to return a known value
           // We'll use reflection to get the actual value since we can't mock private methods
           int expectedVersion;
           try {
               Method versionMethod = ZipArchiveOutputStream.class.getDeclaredMethod(
                   "versionNeededToExtractMethod", int.class);
               versionMethod.setAccessible(true);
               expectedVersion = (int) versionMethod.invoke(zos, testMethod);
           } catch (Exception e) {
               throw new RuntimeException("Failed to get versionNeededToExtractMethod value", e);
           }
           
           // Test - use reflection to call private method
           try {
               Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                   "versionNeededToExtract", int.class, boolean.class, boolean.class);
               method.setAccessible(true);
               int result = (int) method.invoke(zos, testMethod, zip64, usedDataDescriptor);
               
               // Assert
               assertEquals("Should return version based on zip method when neither zip64 nor data descriptor is used",
                          expectedVersion, result);
           } catch (Exception e) {
               fail("Failed to invoke versionNeededToExtract method");
           }
       }

 @Test
      public void testVersionNeededToExtract_RegularCase_ShouldCallVersionMethod() {
          // Setup
          ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
          
          // Test with STORED method (should return specific version)
          int storedMethod = ZipArchiveOutputStream.STORED;
          int expectedStoredVersion = 10; // example value - would normally come from versionNeededToExtractMethod
          
          // Mock the versionNeededToExtractMethod to return known value
          // (Note: In real test, you might need to use reflection to mock this private method,
          // or test through a public method that calls this private method)
          try {
              Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
                  "versionNeededToExtractMethod", int.class);
              method.setAccessible(true);
              
              // When neither zip64 nor data descriptor is used
              int result = (int) method.invoke(zos, storedMethod);
              
              // Verify it returns the method-specific version, not INITIAL_VERSION
              assertEquals("Should return method-specific version for STORED method",
                          expectedStoredVersion, result);
              
              // Test with DEFLATED method
              int deflatedMethod = ZipArchiveOutputStream.DEFLATED;
              int expectedDeflatedVersion = 20; // example value
              result = (int) method.invoke(zos, deflatedMethod);
              
              assertEquals("Should return method-specific version for DEFLATED method",
                          expectedDeflatedVersion, result);
          } catch (Exception e) {
              fail("Test failed due to reflection exception: " + e.getMessage());
          }
      }

 @Test
     public void testVersionNeededToExtractMethod_DetectsMutant() throws Exception {
         // Create a ZipArchiveOutputStream with null channel (OutputStream constructor)
         ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
         
         // Use reflection to access private method
         Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
             "versionNeededToExtractMethod", int.class);
         method.setAccessible(true);
         
         // Test case that would fail with the mutant
         // phased = true, zipMethod = DEFLATED, channel = null
         // Original: false (since phased is true)
         // Mutant: true (because zipMethod is DEFLATED and channel is null)
         boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED);
         
         // Assert false - this will catch the mutant which would return true
         assertFalse("Mutant detected - should return false when phased is true", result);
         
         // Additional test case for original behavior verification
         // phased = false, zipMethod = DEFLATED, channel = null
         // Should return true in both original and mutant
         // Need to set phased to false - this would require reflection to modify the phased state
         // This is just for completeness, main mutant detection is above
     }

 @Test
    public void testVersionNeededToExtractMethod_DetectsMutant1() throws Exception {
        // Setup test conditions that will expose the mutant
        boolean phased = false;
        int zipMethod = ZipArchiveOutputStream.DEFLATED;
        SeekableByteChannel channel = mock(SeekableByteChannel.class);
        
        // Create instance with non-null channel
        ZipArchiveOutputStream zos = new ZipArchiveOutputStream(channel);
        
        // Use reflection to access private method since it's not public
        Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
            "versionNeededToExtractMethod", int.class);
        method.setAccessible(true);
        
        // Test the behavior - should be false in original (all conditions not met)
        // but mutant will return true because channel is non-null
        boolean result = (boolean) method.invoke(zos, zipMethod);
        
        // Assert original behavior (should be false)
        assertFalse("Mutant detected - method returned true when channel is non-null", result);
        
        // Clean up
        method.setAccessible(false);
    }

 @Test
   public void testVersionNeededToExtractMethod() throws Exception {
       // Create test object - using constructor that sets channel to null
       ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
       
       // Mock the private method using reflection since we can't access it directly
       Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
           "versionNeededToExtractMethod", int.class);
       method.setAccessible(true);
       
       // Test case 1: Conditions should return false (phased=true)
       boolean result1 = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED);
       assertFalse("Should return false when phased is true", result1);
       
       // Test case 2: Conditions should return false (wrong method)
       boolean result2 = (boolean) method.invoke(zos, ZipArchiveOutputStream.STORED);
       assertFalse("Should return false when method is not DEFLATED", result2);
       
       // Test case 3: Conditions should return false (channel not null)
       // Create output stream with non-null channel
       SeekableByteChannel channel = mock(SeekableByteChannel.class);
       ZipArchiveOutputStream zosWithChannel = new ZipArchiveOutputStream(channel);
       boolean result3 = (boolean) method.invoke(zosWithChannel, ZipArchiveOutputStream.DEFLATED);
       assertFalse("Should return false when channel is not null", result3);
       
       // Test case 4: Conditions should return true (all conditions met)
       // Need to set phased to false - this would require additional reflection
       // to manipulate the internal state since phased is a parameter to the calling method
       // This case is more complex to test directly
   }

 @Test
  public void testVersionNeededToExtractMethod_DetectsMutant2() throws Exception {
      // Setup test conditions where:
      // - phased is true (!phased is false)
      // - zipMethod is DEFLATED
      // - channel is null
      // Original would return false, mutant would return true
      
      // Create instance with null channel (using OutputStream constructor)
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
      
      // Use reflection to access private method and set private fields
      Method method = ZipArchiveOutputStream.class.getDeclaredMethod(
          "versionNeededToExtractMethod", int.class);
      method.setAccessible(true);
      
      // Set zipMethod to DEFLATED
      Field zipMethodField = ZipArchiveOutputStream.class.getDeclaredField("method");
      zipMethodField.setAccessible(true);
      zipMethodField.set(zos, ZipArchiveOutputStream.DEFLATED);
      
      // Set phased to true (simulate phased state)
      // Note: Since 'phased' is a parameter in other methods but not a field,
      // we'll test through a method that uses it
      
      // Test with phased=true (should return false in original, true in mutant)
      boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED);
      
      // Original would return false (!false && true && true) -> false
      // Mutant would return true (!false || (true && true)) -> true
      assertFalse("Mutant detected - should return false when phased is true", result);
      
      // Clean up
      zos.close();
  }

 @Test
  public void testVersionNeededToExtractMethod_DetectsMutantThroughAPI() throws Exception {
      // This tests the behavior through the putArchiveEntry method which uses versionNeededToExtractMethod
      
      // Setup
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ZipArchiveOutputStream zos = new ZipArchiveOutputStream(baos);
      
      // Create an entry with DEFLATED method
      ZipArchiveEntry entry = new ZipArchiveEntry("test");
      entry.setMethod(ZipArchiveOutputStream.DEFLATED);
      
      // The actual test - when phased is true (through closeCopiedEntry)
      // This should behave differently in original vs mutant
      zos.putArchiveEntry(entry);
      
      // If the mutant is present, it might affect the version needed to extract
      // We can verify by checking if the version was set correctly in the entry
      
      // In original code, version should be based on DEFLATED method
      // In mutant code, it might be different when phased=true
      assertEquals("Wrong version needed to extract", 
          ZipArchiveOutputStream.DEFLATED, 
          entry.getMethod());
      
      zos.closeArchiveEntry();
      zos.close();
  }

 @Test
 public void testVersionNeededToExtractMethod1() {
     // Setup
     ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
     
     // Test case 1: channel is null (should pass in mutant but fail in original)
     // This is the key case to detect the mutant
     try {
         Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
         channelField.setAccessible(true);
         channelField.set(zos, null);
         
         Field zipMethodField = ZipArchiveOutputStream.class.getDeclaredField("method");
         zipMethodField.setAccessible(true);
         zipMethodField.set(zos, ZipArchiveOutputStream.STORED); // Not DEFLATED
         
         Method method = ZipArchiveOutputStream.class.getDeclaredMethod("versionNeededToExtractMethod", int.class);
         method.setAccessible(true);
         
         // Should be false in original (since zipMethod != DEFLATED), 
         // but mutant would return true because channel is null
         boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.STORED);
         assertFalse("Method should return false when channel is null but zipMethod is not DEFLATED", result);
     } catch (Exception e) {
         fail("Reflection failed: " + e.getMessage());
     }
     
     // Test case 2: All conditions true (should pass in both)
     try {
         Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
         channelField.setAccessible(true);
         channelField.set(zos, null);
         
         Field zipMethodField = ZipArchiveOutputStream.class.getDeclaredField("method");
         zipMethodField.setAccessible(true);
         zipMethodField.set(zos, ZipArchiveOutputStream.DEFLATED);
         
         Method method = ZipArchiveOutputStream.class.getDeclaredMethod("versionNeededToExtractMethod", int.class);
         method.setAccessible(true);
         
         boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.DEFLATED);
         assertTrue("Method should return true when all conditions are met", result);
     } catch (Exception e) {
         fail("Reflection failed: " + e.getMessage());
     }
     
     // Test case 3: All conditions false (should fail in both)
     try {
         SeekableByteChannel channel = mock(SeekableByteChannel.class);
         Field channelField = ZipArchiveOutputStream.class.getDeclaredField("channel");
         channelField.setAccessible(true);
         channelField.set(zos, channel);
         
         Field zipMethodField = ZipArchiveOutputStream.class.getDeclaredField("method");
         zipMethodField.setAccessible(true);
         zipMethodField.set(zos, ZipArchiveOutputStream.STORED);
         
         Method method = ZipArchiveOutputStream.class.getDeclaredMethod("versionNeededToExtractMethod", int.class);
         method.setAccessible(true);
         
         boolean result = (boolean) method.invoke(zos, ZipArchiveOutputStream.STORED);
         assertFalse("Method should return false when all conditions are false", result);
     } catch (Exception e) {
         fail("Reflection failed: " + e.getMessage());
     }
 }

}
