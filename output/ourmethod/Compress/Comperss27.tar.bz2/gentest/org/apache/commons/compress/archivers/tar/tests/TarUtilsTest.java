package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                   public void testParseOctal_ValidOctalNumber() {
                                                       byte[] buffer = {' ', '1', '2', '3', '4', ' ', ' '};
                                                       long result = TarUtils.parseOctal(buffer, 0, 7);
                                                       assertEquals(668, result); // 1234 in octal is 668 in decimal
                                                   }

 @Test
                                                   public void testParseOctal_LeadingZeros() {
                                                       byte[] buffer = {'0', '0', '7', '5', '4'};
                                                       long result = TarUtils.parseOctal(buffer, 0, 5);
                                                       assertEquals(0L, result); // Leading zero should return 0
                                                   }

 @Test
                                                   public void testParseOctal_LeadingAndTrailingSpaces() {
                                                       byte[] buffer = {' ', ' ', '6', '4', ' ', ' ', ' '};
                                                       long result = TarUtils.parseOctal(buffer, 0, 7);
                                                       assertEquals(52, result); // 64 in octal is 52 in decimal
                                                   }

 @Test
                                                   public void testParseOctal_TrailingNulls() {
                                                       byte[] buffer = {'1', '2', '0', 0, 0};
                                                       long result = TarUtils.parseOctal(buffer, 0, 5);
                                                       assertEquals(10, result); // 120 in octal is 80 in decimal, but trailing nulls trimmed to 12
                                                   }

 @Test
                                                   public void testParseOctal_MinimumLength() {
                                                       byte[] buffer = {'1', '2'};
                                                       long result = TarUtils.parseOctal(buffer, 0, 2);
                                                       assertEquals(10, result); // 12 in octal is 10 in decimal
                                                   }

 @Test
                                                   public void testParseOctal_OffsetParameter() {
                                                       byte[] buffer = {'x', 'x', '1', '7', '5', 'x', 'x'};
                                                       long result = TarUtils.parseOctal(buffer, 2, 3);
                                                       assertEquals(13, result); // 175 in octal is 125 in decimal, but we're only parsing 3 digits starting at offset 2
                                                   }

 @Test
                                                   public void testParseOctal_MaximumOctalValue() {
                                                       byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7'};
                                                       long result = TarUtils.parseOctal(buffer, 0, 12);
                                                       assertEquals(Long.parseLong("777777777777", 8), result);
                                                   }

 @Test
                                                   public void testParseOctal_MixedSpacesAndDigits() {
                                                       byte[] buffer = {' ', '1', ' ', '5', ' ', ' '};
                                                       long result = TarUtils.parseOctal(buffer, 0, 6);
                                                       assertEquals(13, result); // "1 5" becomes "15" in octal which is 13 in decimal
                                                   }

 @Test
                                           public void testParseOctal_InvalidLength() {
                                               org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                               byte[] buffer = {'1'};
                                               expectedException.expect(IllegalArgumentException.class);
                                               expectedException.expectMessage("Length 1 must be at least 2");
                                               TarUtils.parseOctal(buffer, 0, 1);
                                           }

 @Test
                                           public void testParseOctal_InvalidOctalDigit() {
                                               org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                               byte[] buffer = {'1', '2', '8', '4'}; // '8' is invalid in octal
                                               expectedException.expect(IllegalArgumentException.class);
                                               expectedException.expectMessage("Invalid octal digit");
                                               TarUtils.parseOctal(buffer, 0, 4);
                                           }

 @Test
                                           public void testParseOctal_AllSpaces() {
                                               org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                               byte[] buffer = {' ', ' ', ' ', ' '};
                                               expectedException.expect(IllegalArgumentException.class);
                                               expectedException.expectMessage("Invalid octal digit");
                                               TarUtils.parseOctal(buffer, 0, 4);
                                           }

 @Test
                                           public void testParseOctal_EmptyAfterTrimming() {
                                               byte[] buffer = {' ', 0, 0, ' '};
                                               ExpectedException expectedException = ExpectedException.none();
                                               expectedException.expect(IllegalArgumentException.class);
                                               TarUtils.parseOctal(buffer, 0, 4);
                                           }

 @Test
   public void testParseOctalWithMultipleDigits() {
       // Arrange
       byte[] buffer = {' ', ' ', '1', '2', '3', '4', ' ', ' '}; // "  1234  " 
       int offset = 0;
       int length = buffer.length;
       
       // Act
       long result = TarUtils.parseOctal(buffer, offset, length);
       
       // Assert
       assertEquals(668L, result); // 1234 in octal is 668 in decimal
   }

 @Test
  public void testParseOctal_FirstByteZero_ReturnsZero() {
      // Arrange
      byte[] buffer = new byte[]{0, '1', '2', '3'}; // First byte is 0
      int offset = 0;
      int length = 4;
      
      // Act
      long result = TarUtils.parseOctal(buffer, offset, length);
      
      // Assert
      assertEquals("Should return 0 when first byte is 0", 0L, result);
  }

 @Test
 public void testParseOctalWithLeadingZero() {
     // Arrange
     byte[] buffer = new byte[]{0, '1', '2', '3'}; // First byte is 0
     int offset = 0;
     int length = 4;
     
     // Act
     long result = TarUtils.parseOctal(buffer, offset, length);
     
     // Assert - should return 0 for leading zero, mutant would return -1
     assertEquals("Method should return 0 when first byte is 0", 0L, result);
     
     // Additional test case with multiple leading zeros
     byte[] buffer2 = new byte[]{0, 0, '1', '2'};
     long result2 = TarUtils.parseOctal(buffer2, offset, length);
     assertEquals("Method should return 0 when first byte is 0 regardless of following bytes", 
                 0L, result2);
     
     // Test with just two zeros (minimum length case)
     byte[] buffer3 = new byte[]{0, 0};
     long result3 = TarUtils.parseOctal(buffer3, offset, 2);
     assertEquals("Method should return 0 for minimal length case with leading zero",
                 0L, result3);
 }

}
