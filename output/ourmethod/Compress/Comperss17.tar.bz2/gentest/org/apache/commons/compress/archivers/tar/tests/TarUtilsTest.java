package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testParseOctal_ValidNumber() {
                                                    byte[] buffer = {' ', '1', '2', '3', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 6);
                                                    assertEquals(83L, result); // 123 in octal is 83 in decimal
                                                }

    @Test
                                                public void testParseOctal_LeadingZeroReturnsZero() {
                                                    byte[] buffer = {'0', '1', '2', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 5);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctal_AllSpacesReturnsZero() {
                                                    byte[] buffer = {' ', ' ', ' ', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 5);
                                                    assertEquals(0L, result);
                                                }

    @Test
                                                public void testParseOctal_MaxValidOctalDigits() {
                                                    byte[] buffer = {'7', '7', '7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 12);
                                                    assertEquals(1073741823L, result); // 7777777777 in octal
                                                }

    @Test
                                                public void testParseOctal_WithOffset() {
                                                    byte[] buffer = {'x', 'x', '1', '2', '3', ' ', 0, 'x'};
                                                    long result = TarUtils.parseOctal(buffer, 2, 5);
                                                    assertEquals(83L, result);
                                                }

    @Test
                                                public void testParseOctal_MultipleTrailingSpaces() {
                                                    byte[] buffer = {'1', '2', ' ', ' ', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 6);
                                                    assertEquals(10L, result); // 12 in octal is 10 in decimal
                                                }

    @Test
                                                public void testParseOctal_MultipleLeadingSpaces() {
                                                    byte[] buffer = {' ', ' ', '1', '2', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 6);
                                                    assertEquals(10L, result);
                                                }

    @Test
                                                public void testParseOctal_SingleDigit() {
                                                    byte[] buffer = {'5', ' ', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 3);
                                                    assertEquals(5L, result);
                                                }

    @Test
                                                public void testParseOctal_NullTerminated() {
                                                    byte[] buffer = {'1', '2', '3', 0};
                                                    long result = TarUtils.parseOctal(buffer, 0, 4);
                                                    assertEquals(83L, result);
                                                }

    @Test
                                                public void testParseOctal_SpaceTerminated() {
                                                    byte[] buffer = {'1', '2', '3', ' '};
                                                    long result = TarUtils.parseOctal(buffer, 0, 4);
                                                    assertEquals(83L, result);
                                                }

    @Test
                                        public void testParseOctal_NoTrailingSpaceOrNull() {
                                            byte[] buffer = {'1', '2', '3'};
                                            try {
                                                TarUtils.parseOctal(buffer, 0, 3);
                                                fail("Expected IllegalArgumentException");
                                            } catch (IllegalArgumentException e) {
                                                assertEquals("Invalid byte 51 at offset 2", e.getMessage());
                                            }
                                        }

    @Test
                                        public void testParseOctal_EmptyBuffer() {
                                            byte[] buffer = {};
                                            try {
                                                TarUtils.parseOctal(buffer, 0, 0);
                                                fail("Expected IllegalArgumentException");
                                            } catch (IllegalArgumentException e) {
                                                assertEquals("Length 0 must be at least 2", e.getMessage());
                                            }
                                        }

    @Test
                                        public void testParseOctal_InvalidNegativeDigit() {
                                            byte[] buffer = {'1', '-', '2', ' ', 0};
                                            try {
                                                TarUtils.parseOctal(buffer, 0, 5);
                                                fail("Expected IllegalArgumentException");
                                            } catch (IllegalArgumentException e) {
                                                assertEquals("Invalid byte 45 at offset 1", e.getMessage());
                                            }
                                        }

    @Test
                                    public void testParseOctal_InvalidTrailingCharacter() {
                                        byte[] buffer = {'1', '2', '3', 'x'};
                                        try {
                                            TarUtils.parseOctal(buffer, 0, 4);
                                            fail("Expected IllegalArgumentException to be thrown");
                                        } catch (IllegalArgumentException e) {
                                            assertEquals("Invalid byte 120 at offset 3", e.getMessage());
                                        }
                                    }

    @Test
                                    public void testParseOctal_InvalidDigit() {
                                        byte[] buffer = {'1', '2', '8', ' ', 0};
                                        try {
                                            TarUtils.parseOctal(buffer, 0, 5);
                                            fail("Expected IllegalArgumentException");
                                        } catch (IllegalArgumentException e) {
                                            assertEquals("Invalid byte 56 at offset 2", e.getMessage());
                                            throw e;
                                        }
                                    }

    @Test
                                    public void testParseOctal_LengthTooShort() {
                                        byte[] buffer = {'1', 0};
                                        try {
                                            TarUtils.parseOctal(buffer, 0, 1);
                                            fail("Expected IllegalArgumentException");
                                        } catch (IllegalArgumentException e) {
                                            assertEquals("Length 1 must be at least 2", e.getMessage());
                                        }
                                    }


}
