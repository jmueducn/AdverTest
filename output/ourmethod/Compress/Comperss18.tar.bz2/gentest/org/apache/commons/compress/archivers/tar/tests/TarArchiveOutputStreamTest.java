package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.CountingOutputStream;
 
public class TarArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                                                                                                                                                     public void testWritePaxHeaders_WithNonAsciiCharacters() throws Exception {
                                                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         String entryName = "résumé.txt";
                                                                                                                                                                                                                                                                                                         Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                         headers.put("path", "test/日本語");
                                                                                                                                                                                                                                                                                                         headers.put("size", "1234");
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Use reflection to access private method
                                                                                                                                                                                                                                                                                                         Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                             "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                         writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                                                                                                         writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Verify UTF-8 encoding was handled correctly by checking the output
                                                                                                                                                                                                                                                                                                         byte[] output = baos.toByteArray();
                                                                                                                                                                                                                                                                                                         String outputString = new String(output, "UTF-8");
                                                                                                                                                                                                                                                                                                         assertTrue(outputString.contains("日本語"));
                                                                                                                                                                                                                                                                                                         assertTrue(outputString.contains("résumé.txt"));
                                                                                                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                                                                                                     public void testWritePaxHeaders_WithEmptyHeaders() throws Exception {
                                                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         String entryName = "empty.txt";
                                                                                                                                                                                                                                                                                                         Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Get the private method via reflection
                                                                                                                                                                                                                                                                                                         Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                             "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                         writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                                                                                                         writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Verify that some data was written (PAX headers always write something)
                                                                                                                                                                                                                                                                                                         assertTrue(baos.size() > 0);
                                                                                                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                                                                                                     public void testWritePaxHeaders_WithSpecialCharactersInHeaders() throws Exception {
                                                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         String entryName = "special.txt";
                                                                                                                                                                                                                                                                                                         Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                         headers.put("key=with=equals", "value\nwith\nnewlines");
                                                                                                                                                                                                                                                                                                         headers.put("key with spaces", "value with spaces");
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Use reflection to access private method
                                                                                                                                                                                                                                                                                                         Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                             "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                         writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                                                                                                         writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Verify by checking the output stream content
                                                                                                                                                                                                                                                                                                         String output = baos.toString("UTF-8");
                                                                                                                                                                                                                                                                                                         assertTrue("Should contain escaped equals", 
                                                                                                                                                                                                                                                                                                             output.contains("key=with=equals=value\\nwith\\nnewlines"));
                                                                                                                                                                                                                                                                                                         assertTrue("Should contain spaces",
                                                                                                                                                                                                                                                                                                             output.contains("key with spaces=value with spaces"));
                                                                                                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                                                                                                     public void testWritePaxHeaders_WhenOutputStreamThrowsIOException() throws Exception {
                                                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                                                         OutputStream throwingStream = mock(OutputStream.class);
                                                                                                                                                                                                                                                                                                         doThrow(new IOException("Test exception")).when(throwingStream).write(any(byte[].class));
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(throwingStream);
                                                                                                                                                                                                                                                                                                         Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                         headers.put("test", "value");
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Use try-catch block for JUnit 4 exception testing
                                                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                                                                                                                                                                             Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                 "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                             writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                                             writePaxHeaders.invoke(tarOut, "test.txt", headers);
                                                                                                                                                                                                                                                                                                             fail("Expected IOException to be thrown");
                                                                                                                                                                                                                                                                                                         } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                                                             // Check if the cause is IOException with expected message
                                                                                                                                                                                                                                                                                                             assertTrue(e.getCause() instanceof IOException);
                                                                                                                                                                                                                                                                                                             assertEquals("Test exception", e.getCause().getMessage());
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                                                                                                     public void testWritePaxHeaders_WithVeryLongHeaderValues() throws Exception {
                                                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                                                         ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         String entryName = "longheaders.txt";
                                                                                                                                                                                                                                                                                                         Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                         StringBuilder sb = new StringBuilder();
                                                                                                                                                                                                                                                                                                         for (int i = 0; i < 1000; i++) {
                                                                                                                                                                                                                                                                                                             sb.append("x");
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                         String longValue = sb.toString();
                                                                                                                                                                                                                                                                                                         headers.put("longkey", longValue);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Use reflection to access private method
                                                                                                                                                                                                                                                                                                         Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                             "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                         writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                                                                                                                         writePaxHeadersMethod.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Verify length calculation was correct
                                                                                                                                                                                                                                                                                                         // Need to verify the actual output written to baos since we can't mock the stream
                                                                                                                                                                                                                                                                                                         byte[] output = baos.toByteArray();
                                                                                                                                                                                                                                                                                                         String content = new String(output, "UTF-8");
                                                                                                                                                                                                                                                                                                         String expectedLineStart = (longValue.length() + 10) + " longkey="; // approximate
                                                                                                                                                                                                                                                                                                         assertTrue("Should contain expected line start", content.contains(expectedLineStart));
                                                                                                                                                                                                                                                                                                         assertTrue("Should end with long value", content.endsWith(longValue + "\n"));
                                                                                                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                                                                                                 public void testWritePaxHeaders_WithNormalEntryNameAndHeaders() throws Exception {
                                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     String entryName = "testfile.txt";
                                                                                                                                                                                                                                                                                                     Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                     headers.put("path", "test/path");
                                                                                                                                                                                                                                                                                                     headers.put("size", "1234");
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Use reflection to access private method
                                                                                                                                                                                                                                                                                                     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                     writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                                     writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Verify the entry name was properly constructed
                                                                                                                                                                                                                                                                                                     String expectedName = "./PaxHeaders.X/testfile.txt";
                                                                                                                                                                                                                                                                                                     // Since we're not mocking, we need to verify the actual output
                                                                                                                                                                                                                                                                                                     byte[] output = baos.toByteArray();
                                                                                                                                                                                                                                                                                                     assertTrue(output.length > 0);  // Verify data was written
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Verify entry was properly closed by checking if we can write more data
                                                                                                                                                                                                                                                                                                     // This is a more reliable way than checking internal buffer state
                                                                                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                                                                                         tarOut.putArchiveEntry(new TarArchiveEntry("another_entry"));
                                                                                                                                                                                                                                                                                                         tarOut.closeArchiveEntry();
                                                                                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                                                                                         fail("Stream should still be writable after pax headers");
                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                                                                                                                                 public void testWritePaxHeaders_WithLongEntryName() throws Exception {
                                                                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Define NAMELEN constant (standard tar header name length is 100 bytes)
                                                                                                                                                                                                                                                                                                     final int NAMELEN = 100;
                                                                                                                                                                                                                                                                                                     // Create a name longer than NAMELEN
                                                                                                                                                                                                                                                                                                     String longName = new String(new char[NAMELEN + 10]).replace('\0', 'a');
                                                                                                                                                                                                                                                                                                     Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                                                                     headers.put("path", "test/path");
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Use reflection to access private method
                                                                                                                                                                                                                                                                                                     Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                                                                     writePaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                                                                     writePaxHeadersMethod.invoke(tarOut, longName, headers);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Verify name was truncated
                                                                                                                                                                                                                                                                                                     assertTrue(longName.length() > NAMELEN);
                                                                                                                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                                                                                 public void testWritePaxHeaders_WithEntryNameEndingWithSlash() throws Exception {
                                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                                     ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     String entryName = "directory/";
                                                                                                                                                                                                                                                     Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                                                     headers.put("path", "test/path");
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Use reflection to access private method
                                                                                                                                                                                                                                                     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                                                     writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                                     writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     // Verify trailing slashes were removed
                                                                                                                                                                                                                                                     // Create a new output stream and spy for verification
                                                                                                                                                                                                                                                     ByteArrayOutputStream verifyBaos = new ByteArrayOutputStream();
                                                                                                                                                                                                                                                     TarArchiveOutputStream verifyOut = new TarArchiveOutputStream(verifyBaos);
                                                                                                                                                                                                                                                     TarArchiveOutputStream spyOut = spy(verifyOut);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     writePaxHeaders.invoke(spyOut, entryName, headers);
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     verify(spyOut).putArchiveEntry(argThat(
                                                                                                                                                                                                                                                         new org.mockito.ArgumentMatcher<TarArchiveEntry>() {
                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                             public boolean matches(Object argument) {
                                                                                                                                                                                                                                                                 return !((TarArchiveEntry)argument).getName().endsWith("/");
                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                         }));
                                                                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                                            public void testWritePaxHeaders_ShouldUseProvidedEntryName() throws Exception {
                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                String testEntryName = "testEntry";
                                                                                                                                                                                                                Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                headers.put("key1", "value1");
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Mock dependencies
                                                                                                                                                                                                                OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                                                                                                TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Spy on the instance
                                                                                                                                                                                                                TarArchiveOutputStream spyTarOutput = spy(tarOutput);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Use reflection to mock private stripTo7Bits method
                                                                                                                                                                                                                Method stripTo7BitsMethod = TarArchiveOutputStream.class.getDeclaredMethod("stripTo7Bits", String.class);
                                                                                                                                                                                                                stripTo7BitsMethod.setAccessible(true);
                                                                                                                                                                                                                when(stripTo7BitsMethod.invoke(spyTarOutput, testEntryName)).thenReturn("strippedName");
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Setup mock output stream to capture written data
                                                                                                                                                                                                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                                                                                                                                                                                                doAnswer(invocation -> {
                                                                                                                                                                                                                    byte[] data = (byte[]) invocation.getArguments()[0];
                                                                                                                                                                                                                    int offset = (int) invocation.getArguments()[1];
                                                                                                                                                                                                                    int length = (int) invocation.getArguments()[2];
                                                                                                                                                                                                                    bos.write(data, offset, length);
                                                                                                                                                                                                                    return null;
                                                                                                                                                                                                                }).when(mockOutputStream).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                    "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                                writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                                writePaxHeaders.invoke(spyTarOutput, testEntryName, headers);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                // Verify the output stream was written to
                                                                                                                                                                                                                verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                                                                                
                                                                                                                                                                                                                String writtenData = bos.toString("UTF-8");
                                                                                                                                                                                                                assertTrue("Written data should contain processed entry name", 
                                                                                                                                                                                                                    writtenData.contains("strippedName"));
                                                                                                                                                                                                            }

 @Test
                                                                                                                                                                                                       public void testWritePaxHeaders_RemovesTrailingSlashes() throws Exception {
                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                           String entryName = "testEntry////";
                                                                                                                                                                                                           Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                           headers.put("key1", "value1");
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Mock dependencies
                                                                                                                                                                                                           OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Use reflection to access private method since it's package-private
                                                                                                                                                                                                           Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                                               "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                                           writePaxHeaders.setAccessible(true);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Capture the created TarArchiveEntry name
                                                                                                                                                                                                           final String[] capturedName = new String[1];
                                                                                                                                                                                                           TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                                                                                                           doAnswer(invocation -> {
                                                                                                                                                                                                               TarArchiveEntry entry = (TarArchiveEntry) invocation.getArguments()[0];
                                                                                                                                                                                                               capturedName[0] = entry.getName();
                                                                                                                                                                                                               return null;
                                                                                                                                                                                                           }).when(spyTarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                           writePaxHeaders.invoke(spyTarOut, entryName, headers);
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                           assertFalse("Name should not end with slash", capturedName[0].endsWith("/"));
                                                                                                                                                                                                           assertTrue("Name should start with PaxHeaders prefix", 
                                                                                                                                                                                                               capturedName[0].startsWith("./PaxHeaders.X/"));
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Additional verification for the mutant case
                                                                                                                                                                                                           // If the mutant was present, the name would still have trailing slashes
                                                                                                                                                                                                           // So we explicitly check that all trailing slashes were removed
                                                                                                                                                                                                           String expectedName = "./PaxHeaders.X/" + entryName.replaceAll("/+$", "");
                                                                                                                                                                                                           if (expectedName.length() >= TarConstants.NAMELEN) {
                                                                                                                                                                                                               expectedName = expectedName.substring(0, TarConstants.NAMELEN - 1);
                                                                                                                                                                                                           }
                                                                                                                                                                                                           assertEquals("Name should have all trailing slashes removed", 
                                                                                                                                                                                                               expectedName, capturedName[0]);
                                                                                                                                                                                                       }

 @Test
                                                                                                                                                                                      public void testWritePaxHeaders_RemovesTrailingSlash() throws Exception {
                                                                                                                                                                                          // Setup
                                                                                                                                                                                          String entryName = "testEntry/";
                                                                                                                                                                                          Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                          headers.put("key1", "value1");
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock dependencies
                                                                                                                                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                          TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to test private method
                                                                                                                                                                                          Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                              "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                          writePaxHeaders.setAccessible(true);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create a spy to verify the created entry
                                                                                                                                                                                          TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                                                                                          doAnswer(invocation -> {
                                                                                                                                                                                              Object[] args = invocation.getArguments();
                                                                                                                                                                                              TarArchiveEntry entry = (TarArchiveEntry) args[0];
                                                                                                                                                                                              String createdName = entry.getName();
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify the trailing slash was removed (original behavior)
                                                                                                                                                                                              // The mutant would remove the first character instead
                                                                                                                                                                                              assertFalse("Name should not end with slash", createdName.endsWith("/"));
                                                                                                                                                                                              assertTrue("Name should start with './PaxHeaders.X/'", 
                                                                                                                                                                                                  createdName.startsWith("./PaxHeaders.X/"));
                                                                                                                                                                                              assertEquals("Name should have trailing slash removed",
                                                                                                                                                                                                  "./PaxHeaders.X/testEntry", createdName);
                                                                                                                                                                                              return null;
                                                                                                                                                                                          }).when(spyTarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                                                                                                                          
                                                                                                                                                                                          // Execute
                                                                                                                                                                                          writePaxHeaders.invoke(spyTarOut, entryName, headers);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify the entry was processed
                                                                                                                                                                                          verify(spyTarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                                                                                                                          verify(mockOut, atLeastOnce()).write(any(byte[].class));
                                                                                                                                                                                      }

 @Test
                                                                                                                                                                                 public void testWritePaxHeadersTrailingSlashRemoval() throws Exception {
                                                                                                                                                                                     // Setup
                                                                                                                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                     headers.put("key", "value");
                                                                                                                                                                                     
                                                                                                                                                                                     // Get the private writePaxHeaders method using reflection
                                                                                                                                                                                     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                                                                                                                     writePaxHeaders.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Test case 1: Single trailing slash
                                                                                                                                                                                     String entryName1 = "file/";
                                                                                                                                                                                     writePaxHeaders.invoke(tarOut, entryName1, headers);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify the name passed to TarArchiveEntry would be "./PaxHeaders.X/file"
                                                                                                                                                                                     // Since we can't directly access the created entry, we'll verify the behavior through mocks
                                                                                                                                                                                     // The key assertion is that only one slash was removed, not two
                                                                                                                                                                                     verify(mockOut, atLeastOnce()).write(any(byte[].class));
                                                                                                                                                                                     
                                                                                                                                                                                     // Test case 2: Multiple trailing slashes (should remove one at a time in loop)
                                                                                                                                                                                     String entryName2 = "file///";
                                                                                                                                                                                     writePaxHeaders.invoke(tarOut, entryName2, headers);
                                                                                                                                                                                     verify(mockOut, atLeast(2)).write(any(byte[].class));
                                                                                                                                                                                     
                                                                                                                                                                                     // Test case 3: Very short name with slash
                                                                                                                                                                                     String entryName3 = "a/";
                                                                                                                                                                                     writePaxHeaders.invoke(tarOut, entryName3, headers);
                                                                                                                                                                                     verify(mockOut, atLeast(3)).write(any(byte[].class));
                                                                                                                                                                                     
                                                                                                                                                                                     // Test case 4: Edge case - single character with slash
                                                                                                                                                                                     String entryName4 = "/";
                                                                                                                                                                                     writePaxHeaders.invoke(tarOut, entryName4, headers);
                                                                                                                                                                                     verify(mockOut, atLeast(4)).write(any(byte[].class));
                                                                                                                                                                                     
                                                                                                                                                                                     // The mutant would fail these tests because:
                                                                                                                                                                                     // 1. For "file/", it would try to remove 2 chars (would throw exception or remove "e/")
                                                                                                                                                                                     // 2. For "a/", it would try to remove 2 chars (would throw exception)
                                                                                                                                                                                     // 3. For "/", it would try to remove 2 chars (would throw StringIndexOutOfBoundsException)
                                                                                                                                                                                 }

 @Test
                                                                                                                                                                    public void testWritePaxHeaders_ShouldIncludePaxHeadersPrefix() throws Exception {
                                                                                                                                                                        // Arrange
                                                                                                                                                                        String entryName = "testEntry";
                                                                                                                                                                        java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
                                                                                                                                                                        headers.put("key1", "value1");
                                                                                                                                                                        
                                                                                                                                                                        // Mock dependencies
                                                                                                                                                                        java.io.ByteArrayOutputStream mockOutputStream = new java.io.ByteArrayOutputStream();
                                                                                                                                                                        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarOutput = 
                                                                                                                                                                            new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(mockOutputStream);
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to test private method
                                                                                                                                                                        java.lang.reflect.Method writePaxHeaders = 
                                                                                                                                                                            org.apache.commons.compress.archivers.tar.TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                                                "writePaxHeaders", String.class, java.util.Map.class);
                                                                                                                                                                        writePaxHeaders.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Act
                                                                                                                                                                        writePaxHeaders.invoke(tarOutput, entryName, headers);
                                                                                                                                                                        
                                                                                                                                                                        // Assert - verify the entry name starts with correct prefix
                                                                                                                                                                        // Since we can't verify the mock, we'll check the actual output stream content
                                                                                                                                                                        String output = mockOutputStream.toString("UTF-8");
                                                                                                                                                                        org.junit.Assert.assertTrue("Entry name should start with PaxHeaders prefix", 
                                                                                                                                                                                   output.contains("./PaxHeaders.X/"));
                                                                                                                                                                        
                                                                                                                                                                        // Clean up
                                                                                                                                                                        writePaxHeaders.setAccessible(false);
                                                                                                                                                                    }

 @Test
                                                                                                                                                   public void testWritePaxHeadersWithMaxLengthName() throws Exception {
                                                                                                                                                       // Define required classes for reflection
                                                                                                                                                       Class<?> tarArchiveEntryClass = Class.forName("org.apache.commons.compress.archivers.tar.TarArchiveEntry");
                                                                                                                                                       Class<?> tarConstantsClass = Class.forName("org.apache.commons.compress.archivers.tar.TarConstants");
                                                                                                                                                       
                                                                                                                                                       // Get NAMELEN constant via reflection
                                                                                                                                                       Field nameLenField = tarConstantsClass.getField("NAMELEN");
                                                                                                                                                       int NAMELEN = nameLenField.getInt(null);
                                                                                                                                                       
                                                                                                                                                       // Setup
                                                                                                                                                       java.io.OutputStream mockOut = mock(java.io.OutputStream.class);
                                                                                                                                                       org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarOut = 
                                                                                                                                                           new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(mockOut);
                                                                                                                                                       
                                                                                                                                                       // Create an entry name that will be exactly NAMELEN after prefix
                                                                                                                                                       // "./PaxHeaders.X/" is 14 chars, so we need NAMELEN-14 chars
                                                                                                                                                       StringBuilder sb = new StringBuilder();
                                                                                                                                                       for (int i = 0; i < NAMELEN - 14; i++) {
                                                                                                                                                           sb.append("a");
                                                                                                                                                       }
                                                                                                                                                       String longName = sb.toString();
                                                                                                                                                       java.util.Map<String, String> headers = new java.util.HashMap<>();
                                                                                                                                                       headers.put("key", "value");
                                                                                                                                                       
                                                                                                                                                       // Spy on the TarArchiveOutputStream to verify the entry creation
                                                                                                                                                       org.apache.commons.compress.archivers.tar.TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                                                       doNothing().when(spyTarOut).putArchiveEntry(any(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class));
                                                                                                                                                       doNothing().when(spyTarOut).write(any(byte[].class));
                                                                                                                                                       doNothing().when(spyTarOut).closeArchiveEntry();
                                                                                                                                                       
                                                                                                                                                       // Use reflection to access the package-private method
                                                                                                                                                       java.lang.reflect.Method writePaxHeaders = org.apache.commons.compress.archivers.tar.TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                                           "writePaxHeaders", String.class, Map.class);
                                                                                                                                                       writePaxHeaders.setAccessible(true);
                                                                                                                                                       writePaxHeaders.invoke(spyTarOut, longName, headers);
                                                                                                                                                       
                                                                                                                                                       // Verify the entry name length is NAMELEN-1 (original behavior)
                                                                                                                                                       org.mockito.ArgumentCaptor<org.apache.commons.compress.archivers.tar.TarArchiveEntry> entryCaptor = 
                                                                                                                                                           org.mockito.ArgumentCaptor.forClass(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class);
                                                                                                                                                       verify(spyTarOut).putArchiveEntry(entryCaptor.capture());
                                                                                                                                                       
                                                                                                                                                       org.apache.commons.compress.archivers.tar.TarArchiveEntry createdEntry = entryCaptor.getValue();
                                                                                                                                                       assertEquals(NAMELEN - 1, createdEntry.getName().length());
                                                                                                                                                       
                                                                                                                                                       // Also verify the name doesn't end with slash
                                                                                                                                                       assertFalse(createdEntry.getName().endsWith("/"));
                                                                                                                                                   }

 @Test
                                                                                                                                              public void testWritePaxHeaders_ShouldStripNonAsciiCharactersFromEntryName() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  String entryName = "téstFîle"; // Contains non-ASCII characters
                                                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                                                  headers.put("key", "value");
                                                                                                                                                  
                                                                                                                                                  // Create output stream
                                                                                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new ByteArrayOutputStream());
                                                                                                                                                  
                                                                                                                                                  // Use reflection to test private stripTo7Bits method
                                                                                                                                                  Method stripTo7Bits = TarArchiveOutputStream.class.getDeclaredMethod("stripTo7Bits", String.class);
                                                                                                                                                  stripTo7Bits.setAccessible(true);
                                                                                                                                                  String strippedName = (String) stripTo7Bits.invoke(tarOut, entryName);
                                                                                                                                                  assertEquals("testFile", strippedName);
                                                                                                                                                  
                                                                                                                                                  // Use reflection to call package-private writePaxHeaders method
                                                                                                                                                  Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod("writePaxHeaders", String.class, Map.class);
                                                                                                                                                  writePaxHeaders.setAccessible(true);
                                                                                                                                                  writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                                                  
                                                                                                                                                  // Verify the created entry name only contains ASCII characters
                                                                                                                                                  Field entriesField = TarArchiveOutputStream.class.getDeclaredField("entries");
                                                                                                                                                  entriesField.setAccessible(true);
                                                                                                                                                  List<TarArchiveEntry> entries = (List<TarArchiveEntry>) entriesField.get(tarOut);
                                                                                                                                                  String createdName = entries.get(0).getName();
                                                                                                                                                  
                                                                                                                                                  assertTrue("Entry name should only contain ASCII characters",
                                                                                                                                                             createdName.matches("^[\\x00-\\x7F]*$"));
                                                                                                                                                  
                                                                                                                                                  // Verify the name starts with the correct prefix
                                                                                                                                                  assertTrue(createdName.startsWith("./PaxHeaders.X/"));
                                                                                                                                                  
                                                                                                                                                  // Verify the name doesn't contain the original non-ASCII characters
                                                                                                                                                  assertFalse(createdName.contains("téstFîle"));
                                                                                                                                              }

 @Test
                                                                                                                                     public void testWritePaxHeaders_RemovesTrailingSlashes1() throws Exception {
                                                                                                                                         // Setup
                                                                                                                                         String entryName = "testEntry/"; // Note trailing slash
                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                         headers.put("key1", "value1");
                                                                                                                                         
                                                                                                                                         // Mock dependencies
                                                                                                                                         OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                         TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                                         
                                                                                                                                         // Use reflection to test private method
                                                                                                                                         Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                             "writePaxHeaders", String.class, Map.class);
                                                                                                                                         writePaxHeaders.setAccessible(true);
                                                                                                                                         
                                                                                                                                         // Capture the created TarArchiveEntry name
                                                                                                                                         final String[] capturedName = new String[1];
                                                                                                                                         TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                                         doAnswer(invocation -> {
                                                                                                                                             TarArchiveEntry entry = (TarArchiveEntry) invocation.getArguments()[0];
                                                                                                                                             capturedName[0] = entry.getName();
                                                                                                                                             return null;
                                                                                                                                         }).when(spyTarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                                                                         
                                                                                                                                         // Execute
                                                                                                                                         writePaxHeaders.invoke(spyTarOut, entryName, headers);
                                                                                                                                         
                                                                                                                                         // Verify
                                                                                                                                         assertFalse("Name should not end with slash", capturedName[0].endsWith("/"));
                                                                                                                                         assertTrue("Name should start with PaxHeaders prefix", 
                                                                                                                                             capturedName[0].startsWith("./PaxHeaders.X/"));
                                                                                                                                         
                                                                                                                                         // Additional verification for the specific case
                                                                                                                                         assertEquals("Name should have trailing slash removed", 
                                                                                                                                             "./PaxHeaders.X/testEntry", capturedName[0]);
                                                                                                                                     }

 @Test
                                                                                                                        public void testWritePaxHeadersWithMultipleTrailingSlashes() throws Exception {
                                                                                                                            // Setup
                                                                                                                            String entryName = "testEntry///"; // Multiple trailing slashes
                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                            headers.put("key", "value");
                                                                                                                            
                                                                                                                            // Mock dependencies
                                                                                                                            OutputStream mockOut = mock(OutputStream.class);
                                                                                                                            TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                            
                                                                                                                            // Use reflection to access private method since it's package-private
                                                                                                                            Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                                "writePaxHeaders", String.class, Map.class);
                                                                                                                            writePaxHeaders.setAccessible(true);
                                                                                                                            
                                                                                                                            // Create a spy to verify the entry creation
                                                                                                                            TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                                                            doAnswer(invocation -> {
                                                                                                                                Object[] args = invocation.getArguments();
                                                                                                                                File file = (File) args[0];
                                                                                                                                String name = (String) args[1];
                                                                                                                                assertEquals("./PaxHeaders.X/testEntry", name);
                                                                                                                                return null;
                                                                                                                            }).when(spyTarOut).createArchiveEntry(any(File.class), anyString());
                                                                                                                            
                                                                                                                            // Execute
                                                                                                                            writePaxHeaders.invoke(spyTarOut, entryName, headers);
                                                                                                                            
                                                                                                                            // Verify
                                                                                                                            verify(mockOut, atLeastOnce()).write(any(byte[].class));
                                                                                                                        }

 @Test
                                                                                                               public void testWritePaxHeadersRemovesTrailingSlashes() throws Exception {
                                                                                                                   // Setup
                                                                                                                   String entryName = "testEntry//"; // Ends with two slashes
                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                   headers.put("key", "value");
                                                                                                                   
                                                                                                                   // Mock dependencies
                                                                                                                   OutputStream mockOut = mock(OutputStream.class);
                                                                                                                   TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                                   
                                                                                                                   // Use reflection to access private method
                                                                                                                   Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                                       "writePaxHeaders", String.class, Map.class);
                                                                                                                   writePaxHeaders.setAccessible(true);
                                                                                                                   
                                                                                                                   // Capture the written bytes
                                                                                                                   ByteArrayOutputStream capturedBytes = new ByteArrayOutputStream();
                                                                                                                   doAnswer(invocation -> {
                                                                                                                       byte[] bytes = (byte[]) invocation.getArguments()[0];
                                                                                                                       capturedBytes.write(bytes);
                                                                                                                       return null;
                                                                                                                   }).when(mockOut).write(any(byte[].class));
                                                                                                                   
                                                                                                                   // Execute
                                                                                                                   writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                                   
                                                                                                                   // Verify the mock was called
                                                                                                                   verify(mockOut, atLeastOnce()).write(any(byte[].class));
                                                                                                                   
                                                                                                                   // Convert captured bytes to string for verification
                                                                                                                   String writtenData = capturedBytes.toString("UTF-8");
                                                                                                                   
                                                                                                                   // Verify the name starts with "./PaxHeaders.X/" 
                                                                                                                   assertTrue(writtenData.contains("./PaxHeaders.X/"));
                                                                                                                   
                                                                                                                   // Verify trailing slashes are removed
                                                                                                                   assertFalse(writtenData.contains("testEntry//"));
                                                                                                                   assertTrue(writtenData.contains("testEntry"));
                                                                                                               }

 @Test
                                                                                                      public void testWritePaxHeadersWithTwoTrailingSlashes() throws Exception {
                                                                                                          // Setup
                                                                                                          OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                          TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(mockOutputStream);
                                                                                                          String entryName = "testEntry//"; // Note two trailing slashes
                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                          headers.put("key1", "value1");
                                                                                                          
                                                                                                          // Expected behavior: should remove only one slash, leaving one
                                                                                                          String expectedName = "./PaxHeaders.X/testEntry/";
                                                                                                          
                                                                                                          // Get the private writePaxHeaders method using reflection
                                                                                                          Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                              "writePaxHeaders", String.class, Map.class);
                                                                                                          writePaxHeadersMethod.setAccessible(true);
                                                                                                          
                                                                                                          // Execute
                                                                                                          writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                                                                          
                                                                                                          // Verify the created TarArchiveEntry name
                                                                                                          // Since we can't directly access the created entry, we'll verify the mock interactions
                                                                                                          // The test will fail if the mutant removes two slashes (resulting in "./PaxHeaders.X/testEntry")
                                                                                                          // or throws StringIndexOutOfBoundsException
                                                                                                          
                                                                                                          // Alternative verification - we can check if the output was written (no exception thrown)
                                                                                                          // and the mock was interacted with (since we can't directly check the entry name)
                                                                                                          verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
                                                                                                      }

 @Test
                                                                                                      public void testWritePaxHeadersWithSingleTrailingSlashMutant() throws Exception {
                                                                                                          // This test expects the mutant to fail when there's only one slash
                                                                                                          // because it tries to remove two characters
                                                                                                          String entryName = "testEntry/"; // Single trailing slash
                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                          headers.put("key1", "value1");
                                                                                                          
                                                                                                          // Create a TarArchiveOutputStream instance
                                                                                                          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                                                                          TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(byteArrayOutputStream);
                                                                                                          
                                                                                                          // Get the private writePaxHeaders method using reflection
                                                                                                          Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                              "writePaxHeaders", String.class, Map.class);
                                                                                                          writePaxHeadersMethod.setAccessible(true);
                                                                                                          
                                                                                                          // With the mutant, this should throw StringIndexOutOfBoundsException
                                                                                                          // because it tries to do substring(0, length-2) when length-2 would be negative
                                                                                                          try {
                                                                                                              writePaxHeadersMethod.invoke(tarOutput, entryName, headers);
                                                                                                              fail("Expected StringIndexOutOfBoundsException to be thrown");
                                                                                                          } catch (InvocationTargetException e) {
                                                                                                              assertTrue(e.getCause() instanceof StringIndexOutOfBoundsException);
                                                                                                          }
                                                                                                      }

 @Test
                                                                                                 public void testWritePaxHeadersWithExactLengthName() throws Exception {
                                                                                                     // Setup
                                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                                     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                                     Map<String, String> headers = new HashMap<String, String>();
                                                                                                     headers.put("key", "value");
                                                                                                     
                                                                                                     // Create a name that's exactly NAMELEN characters long
                                                                                                     int nameLen = TarConstants.NAMELEN;
                                                                                                     StringBuilder sb = new StringBuilder();
                                                                                                     sb.append("./PaxHeaders.X/");
                                                                                                     // Fill remaining space with 'a's
                                                                                                     while (sb.length() < nameLen) {
                                                                                                         sb.append("a");
                                                                                                     }
                                                                                                     String entryName = sb.toString();
                                                                                                     
                                                                                                     // Use reflection to access private writePaxHeaders method
                                                                                                     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                         "writePaxHeaders", String.class, Map.class);
                                                                                                     writePaxHeaders.setAccessible(true);
                                                                                                     writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                     
                                                                                                     // Verify - should not be truncated in original code
                                                                                                     // We can verify this by checking the mock interactions
                                                                                                     verify(tarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                                     
                                                                                                     // Also verify the data was written
                                                                                                     verify(tarOut).write(any(byte[].class));
                                                                                                     verify(tarOut).closeArchiveEntry();
                                                                                                 }

 @Test
                                                                                            public void testWritePaxHeaders_ShouldStartWithPaxHeadersPrefix() throws Exception {
                                                                                                // Arrange
                                                                                                String entryName = "testEntry";
                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                headers.put("key", "value");
                                                                                                
                                                                                                // Mock the output stream to capture written data
                                                                                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                                TarArchiveOutputStream tarOut = new TarArchiveOutputStream(baos);
                                                                                                
                                                                                                // Use reflection to access private method since it's package-private
                                                                                                Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                                    "writePaxHeaders", String.class, Map.class);
                                                                                                writePaxHeaders.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                                tarOut.finish();
                                                                                                
                                                                                                // Assert
                                                                                                byte[] data = baos.toByteArray();
                                                                                                // The first 100 bytes should contain the header with PaxHeaders prefix
                                                                                                String header = new String(data, 0, Math.min(100, data.length), "UTF-8");
                                                                                                assertTrue("Header name should start with PaxHeaders prefix", 
                                                                                                           header.contains("./PaxHeaders.X/"));
                                                                                                
                                                                                                // Verify the exact name construction
                                                                                                String expectedPrefix = "./PaxHeaders.X/" + entryName;
                                                                                                // The name appears twice in the header - once in the ustar header and once in the PAX header
                                                                                                assertTrue("Header should contain properly constructed name",
                                                                                                           header.contains(expectedPrefix) || 
                                                                                                           new String(data, "UTF-8").contains(expectedPrefix));
                                                                                            }

 @Test
                                                                                   public void testWritePaxHeadersIncludesEntryNameInPath() throws Exception {
                                                                                       // Setup
                                                                                       String testEntryName = "testEntry";
                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                       headers.put("key", "value");
                                                                                       
                                                                                       // Mock dependencies
                                                                                       TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new ByteArrayOutputStream());
                                                                                       TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                                       
                                                                                       // Capture the created TarArchiveEntry
                                                                                       final TarArchiveEntry[] capturedEntry = new TarArchiveEntry[1];
                                                                                       doAnswer(invocation -> {
                                                                                           capturedEntry[0] = (TarArchiveEntry) invocation.getArguments()[0];
                                                                                           return null;
                                                                                       }).when(spyTarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                       
                                                                                       // Use reflection to access the package-private writePaxHeaders method
                                                                                       Method writePaxHeadersMethod = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                           "writePaxHeaders", String.class, Map.class);
                                                                                       writePaxHeadersMethod.setAccessible(true);
                                                                                       writePaxHeadersMethod.invoke(spyTarOut, testEntryName, headers);
                                                                                       
                                                                                       // Verify
                                                                                       assertNotNull("TarArchiveEntry should be created", capturedEntry[0]);
                                                                                       String entryName = capturedEntry[0].getName();
                                                                                       assertTrue("Entry name should contain original entry name", 
                                                                                                  entryName.contains(testEntryName));
                                                                                   }

 @Test
                                                                              public void testWritePaxHeadersWithMultipleSlashes() throws Exception {
                                                                                  // Setup
                                                                                  String entryName = "dir/file//"; // Note multiple slashes at end
                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                  headers.put("key", "value");
                                                                                  
                                                                                  // Mock dependencies
                                                                                  OutputStream mockOut = mock(OutputStream.class);
                                                                                  TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                                  
                                                                                  // Capture the created entry
                                                                                  final TarArchiveEntry[] capturedEntry = new TarArchiveEntry[1];
                                                                                  doAnswer(invocation -> {
                                                                                      capturedEntry[0] = (TarArchiveEntry) invocation.getArguments()[0];
                                                                                      return null;
                                                                                  }).when(tarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                                  
                                                                                  // Get writePaxHeaders method via reflection
                                                                                  Method writePaxHeaders = TarArchiveOutputStream.class
                                                                                      .getDeclaredMethod("writePaxHeaders", String.class, Map.class);
                                                                                  writePaxHeaders.setAccessible(true);
                                                                                  
                                                                                  // Call method
                                                                                  writePaxHeaders.invoke(tarOut, entryName, headers);
                                                                                  
                                                                                  // Verify
                                                                                  assertNotNull(capturedEntry[0]);
                                                                                  String resultName = capturedEntry[0].getName();
                                                                                  
                                                                                  // Original behavior would keep one slash before the trailing ones
                                                                                  // Mutant would remove all slashes
                                                                                  assertTrue("Name should preserve non-trailing slashes", 
                                                                                             resultName.contains("dir/file"));
                                                                                  assertFalse("Name should not end with slash", 
                                                                                              resultName.endsWith("/"));
                                                                                  
                                                                                  // Additional verification for the case with slashes in middle
                                                                                  String midSlashEntry = "dir/sub/file///";
                                                                                  writePaxHeaders.invoke(tarOut, midSlashEntry, headers);
                                                                                  assertNotNull(capturedEntry[0]);
                                                                                  String midResult = capturedEntry[0].getName();
                                                                                  assertTrue("Intermediate slashes should be preserved",
                                                                                             midResult.contains("dir/sub/file"));
                                                                                  assertFalse("Trailing slashes should be removed",
                                                                                              midResult.endsWith("/"));
                                                                              }

 @Test
                                                                         public void testWritePaxHeadersShouldRemoveTrailingSlashes() throws Exception {
                                                                             // Setup
                                                                             String entryName = "testEntry/"; // Note trailing slash
                                                                             Map<String, String> headers = new HashMap<>();
                                                                             headers.put("key", "value");
                                                                             
                                                                             // Mock dependencies
                                                                             OutputStream mockOut = mock(OutputStream.class);
                                                                             TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                             
                                                                             // Use reflection to test private method
                                                                             Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                                 "writePaxHeaders", String.class, Map.class);
                                                                             writePaxHeaders.setAccessible(true);
                                                                             
                                                                             // Capture the created TarArchiveEntry
                                                                             final TarArchiveEntry[] capturedEntry = new TarArchiveEntry[1];
                                                                             TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                             doAnswer(invocation -> {
                                                                                 capturedEntry[0] = (TarArchiveEntry) invocation.getArguments()[0];
                                                                                 return null;
                                                                             }).when(spyTarOut).putArchiveEntry(any(TarArchiveEntry.class));
                                                                             
                                                                             // Execute
                                                                             writePaxHeaders.invoke(spyTarOut, entryName, headers);
                                                                             
                                                                             // Verify
                                                                             assertNotNull("TarArchiveEntry should be created", capturedEntry[0]);
                                                                             String resultName = capturedEntry[0].getName();
                                                                             assertFalse("Name should not end with slash", 
                                                                                        resultName.endsWith("/"));
                                                                             assertTrue("Name should start with PaxHeaders prefix", 
                                                                                        resultName.startsWith("./PaxHeaders.X/"));
                                                                             assertTrue("Original entry name should be preserved (minus slashes)",
                                                                                        resultName.contains("testEntry"));
                                                                         }

 @Test
                                                                    public void testWritePaxHeadersTrailingSlashRemoval1() throws Exception {
                                                                        // Setup
                                                                        String entryName = "testEntry/"; // Ends with slash
                                                                        Map<String, String> headers = new HashMap<>();
                                                                        headers.put("key", "value");
                                                                        
                                                                        // Mock dependencies
                                                                        OutputStream mockOut = mock(OutputStream.class);
                                                                        TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                                                                        
                                                                        // Use reflection to test private method
                                                                        Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                                                                            "writePaxHeaders", String.class, Map.class);
                                                                        writePaxHeaders.setAccessible(true);
                                                                        
                                                                        // Create a spy to intercept entry creation
                                                                        TarArchiveOutputStream spyTarOut = spy(tarOut);
                                                                        doAnswer(invocation -> {
                                                                            TarArchiveEntry entry = (TarArchiveEntry) invocation.callRealMethod();
                                                                            // Verify the name processing
                                                                            String expectedName = "./PaxHeaders.X/testEntry"; // Should remove trailing slash
                                                                            assertEquals("Name should have trailing slash removed but keep prefix", 
                                                                                         expectedName, entry.getName());
                                                                            return entry;
                                                                        }).when(spyTarOut).createArchiveEntry(any(File.class), anyString());
                                                                        
                                                                        // Execute
                                                                        writePaxHeaders.invoke(spyTarOut, entryName, headers);
                                                                        
                                                                        // Verify the entry name processing
                                                                        verify(mockOut, atLeastOnce()).write(any(byte[].class));
                                                                    }

 @Test
                           public void testWritePaxHeadersWithNameLengthExactlyAtLimit() throws Exception {
                               // Setup
                               java.io.OutputStream mockOut = mock(java.io.OutputStream.class);
                               org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarOut = 
                                   new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(mockOut);
                               
                               // Create a name that's exactly at NAMELEN limit
                               int nameLen = org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN;
                               String longName = new String(new char[nameLen - "./PaxHeaders.X/".length()]).replace('\0', 'a');
                               java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
                               headers.put("key", "value");
                               
                               // Spy on the tarOut to verify the entry name length
                               org.apache.commons.compress.archivers.tar.TarArchiveOutputStream spyTarOut = 
                                   spy(tarOut);
                               doNothing().when(spyTarOut).putArchiveEntry(
                                   any(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class));
                               doNothing().when(spyTarOut).write(
                                   any(byte[].class));
                               doNothing().when(spyTarOut).closeArchiveEntry();
                               
                               // Use reflection to access private writePaxHeaders method
                               java.lang.reflect.Method writePaxHeaders = 
                                   org.apache.commons.compress.archivers.tar.TarArchiveOutputStream.class.getDeclaredMethod(
                                       "writePaxHeaders", String.class, java.util.Map.class);
                               writePaxHeaders.setAccessible(true);
                               writePaxHeaders.invoke(spyTarOut, longName, headers);
                               
                               // Verify
                               org.mockito.ArgumentCaptor<org.apache.commons.compress.archivers.tar.TarArchiveEntry> entryCaptor = 
                                   org.mockito.ArgumentCaptor.forClass(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class);
                               verify(spyTarOut).putArchiveEntry(entryCaptor.capture());
                               
                               // Original should truncate to NAMELEN-1, mutant won't truncate
                               // So we assert the name is truncated (length should be NAMELEN-1)
                               assertEquals(
                                   org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN - 1, 
                                   entryCaptor.getValue().getName().length());
                               
                               // Also verify the name doesn't end with '/'
                               assertFalse(entryCaptor.getValue().getName().endsWith("/"));
                           }

 @Test
                       public void testWritePaxHeadersWithShortNameShouldNotTruncate() throws Exception {
                           // Setup
                           OutputStream mockOut = mock(OutputStream.class);
                           TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
                           
                           // Use reflection to access private method writePaxHeaders
                           Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
                               "writePaxHeaders", String.class, Map.class);
                           writePaxHeaders.setAccessible(true);
                           
                           // Create test data - name is shorter than NAMELEN
                           String shortName = "short";
                           Map<String, String> headers = new HashMap<>();
                           headers.put("key", "value");
                           
                           // Mock the stripTo7Bits method to return the same string
                           Method stripTo7Bits = TarArchiveOutputStream.class.getDeclaredMethod(
                               "stripTo7Bits", String.class);
                           stripTo7Bits.setAccessible(true);
                           when(stripTo7Bits.invoke(tarOut, anyString())).thenAnswer(i -> i.getArguments()[0]);
                           
                           // Mock the putArchiveEntry method to capture the entry name
                           final String[] capturedName = new String[1];
                           doAnswer(invocation -> {
                               TarArchiveEntry entry = (TarArchiveEntry) invocation.getArguments()[0];
                               capturedName[0] = entry.getName();
                               return null;
                           }).when(tarOut).putArchiveEntry(any(TarArchiveEntry.class));
                           
                           // Execute
                           writePaxHeaders.invoke(tarOut, shortName, headers);
                           
                           // Verify - name should not be truncated (original behavior)
                           // Mutated version would truncate by 1 character
                           String expectedName = "./PaxHeaders.X/" + shortName;
                           assertEquals("Name should not be truncated when shorter than NAMELEN", 
                               expectedName, capturedName[0]);
                       }

 @Test
     public void testWritePaxHeadersWithLongName() throws Exception {
         // Setup
         java.io.OutputStream mockOut = mock(java.io.OutputStream.class);
         org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarOut = 
             spy(new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(mockOut));
         java.util.Map<String, String> headers = new java.util.HashMap<String, String>();
         headers.put("key", "value");
         
         // Create a name that's definitely longer than NAMELEN
         StringBuilder longName = new StringBuilder();
         for (int i = 0; i < org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN + 10; i++) {
             longName.append("a");
         }
         String entryName = longName.toString();
         
         // Capture the name used in putArchiveEntry
         org.mockito.ArgumentCaptor<org.apache.commons.compress.archivers.tar.TarArchiveEntry> entryCaptor = 
             org.mockito.ArgumentCaptor.forClass(org.apache.commons.compress.archivers.tar.TarArchiveEntry.class);
         doNothing().when(mockOut).write(any(byte[].class));
         
         // Use reflection to access package-private method
         java.lang.reflect.Method writePaxHeaders = org.apache.commons.compress.archivers.tar.TarArchiveOutputStream.class.getDeclaredMethod(
             "writePaxHeaders", String.class, java.util.Map.class);
         writePaxHeaders.setAccessible(true);
         
         // Execute
         writePaxHeaders.invoke(tarOut, entryName, headers);
         
         // Verify
         verify(tarOut).putArchiveEntry(entryCaptor.capture());
         org.apache.commons.compress.archivers.tar.TarArchiveEntry entry = entryCaptor.getValue();
         
         // Original behavior: name should be truncated to NAMELEN-1
         // Mutant would make it 1 character
         assertTrue("Name should be properly truncated", 
                    entry.getName().length() == org.apache.commons.compress.archivers.tar.TarConstants.NAMELEN - 1);
         
         // Also verify it starts with correct prefix
         assertTrue("Name should start with PaxHeaders prefix",
                    entry.getName().startsWith("./PaxHeaders.X/"));
         
         // Verify it doesn't end with slash
         assertFalse("Name should not end with slash",
                     entry.getName().endsWith("/"));
     }

 @Test
 public void testWritePaxHeadersWithMultipleSlashes1() throws Exception {
     // Setup
     String entryName = "path/to/file//"; // Note multiple trailing slashes and internal slash
     Map<String, String> headers = new HashMap<>();
     headers.put("key", "value");
     
     // Mock dependencies
     OutputStream mockOut = mock(OutputStream.class);
     TarArchiveOutputStream tarOut = new TarArchiveOutputStream(mockOut);
     
     // Capture the created entry
     final TarArchiveEntry[] capturedEntry = new TarArchiveEntry[1];
     doAnswer(invocation -> {
         capturedEntry[0] = (TarArchiveEntry) invocation.getArguments()[0];
         return null;
     }).when(mockOut).write(any(byte[].class));
     
     // Call method
     Method writePaxHeaders = TarArchiveOutputStream.class.getDeclaredMethod(
         "writePaxHeaders", String.class, Map.class);
     writePaxHeaders.setAccessible(true);
     writePaxHeaders.invoke(tarOut, entryName, headers);
     
     // Verify
     String resultName = capturedEntry[0].getName();
     // Should preserve internal slashes but remove trailing ones
     assertTrue("Should preserve internal slashes", resultName.contains("/"));
     assertFalse("Should remove all trailing slashes", resultName.endsWith("/"));
     // Verify the exact expected name (original behavior would be "./PaxHeaders.X/path/to/file")
     assertEquals("./PaxHeaders.X/path/to/file", resultName);
 }

}
