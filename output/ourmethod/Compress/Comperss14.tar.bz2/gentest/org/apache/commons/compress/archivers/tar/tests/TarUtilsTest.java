package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                      public void testParseOctal_ValidOctalNumber() {
                          byte[] buffer = {' ', '1', '2', '3', ' ', 0};
                          long result = TarUtils.parseOctal(buffer, 0, 6);
                          assertEquals(83L, result); // 123 in octal is 83 in decimal
                      }

 @Test
                      public void testParseOctal_LeadingZeroReturnsZero() {
                          byte[] buffer = {'0', '1', '2', ' ', 0};
                          long result = TarUtils.parseOctal(buffer, 0, 5);
                          assertEquals(0L, result);
                      }

 @Test
                      public void testParseOctal_MultipleLeadingSpaces() {
                          byte[] buffer = {' ', ' ', '7', '5', ' ', 0};
                          long result = TarUtils.parseOctal(buffer, 0, 6);
                          assertEquals(61L, result); // 75 in octal is 61 in decimal
                      }

 @Test
                      public void testParseOctal_MultipleTrailingSpaces() {
                          byte[] buffer = {'1', '0', ' ', ' ', 0};
                          long result = TarUtils.parseOctal(buffer, 0, 5);
                          assertEquals(8L, result); // 10 in octal is 8 in decimal
                      }

 @Test
                      public void testParseOctal_OnlySpacesAndZero() {
                          byte[] buffer = {' ', ' ', '0', ' ', 0};
                          long result = TarUtils.parseOctal(buffer, 0, 5);
                          assertEquals(0L, result);
                      }

 @Test
                      public void testParseOctal_MaximumValidOctal() {
                          byte[] buffer = {'1', '7', '7', '7', '7', '7', '7', '7', '7', ' ', 0};
                          long result = TarUtils.parseOctal(buffer, 0, 11);
                          assertEquals(2147483647L, result); // 17777777777 in octal is 2147483647 in decimal
                      }

 @Test
                      public void testParseOctal_WithOffset() {
                          byte[] buffer = {'x', 'x', '1', '2', '4', ' ', 0, 'x'};
                          long result = TarUtils.parseOctal(buffer, 2, 5);
                          assertEquals(84L, result); // 124 in octal is 84 in decimal
                      }

 @Test
              public void testParseOctal_InvalidTrailingCharacter() {
                  byte[] buffer = {'1', '2', 'x', 0};
                  ExpectedException exceptionRule = ExpectedException.none();
                  exceptionRule.expect(IllegalArgumentException.class);
                  TarUtils.parseOctal(buffer, 0, 4);
              }

 @Test
              public void testParseOctal_InvalidOctalDigit() {
                  byte[] buffer = {'1', '2', '8', ' ', 0};
                  ExpectedException exceptionRule = ExpectedException.none();
                  exceptionRule.expect(IllegalArgumentException.class);
                  TarUtils.parseOctal(buffer, 0, 5);
              }

 @Test
              public void testParseOctal_EmptyAfterTrimming() {
                  byte[] buffer = {' ', ' ', 0};
                  ExpectedException exceptionRule = ExpectedException.none();
                  exceptionRule.expect(IllegalArgumentException.class);
                  TarUtils.parseOctal(buffer, 0, 3);
              }

 @Test(expected = IllegalArgumentException.class)
          public void testParseOctal_InvalidLength() {
              byte[] buffer = {'1', 0};
              TarUtils.parseOctal(buffer, 0, 1);
          }

 @Test
          public void testParseOctal_SingleSpaceBeforeNull() {
              byte[] buffer = new byte[] {' ', 0};
              TarUtils.parseOctal(buffer, 0, 2);
          }

 @Test
          public void testParseOctalWithLength1ShouldThrowException() {
              byte[] buffer = {'1', '2', '3'}; // Content doesn't matter for this test
              int offset = 0;
              int length = 1;
              
              thrown.expect(IllegalArgumentException.class);
              thrown.expectMessage("Length 1 must be at least 2");
              
              TarUtils.parseOctal(buffer, offset, length);
          }

 @Test
     public void testParseOctalLengthExactlyTwoShouldPass() {
         // Arrange
         byte[] buffer = new byte[]{'1', '2'}; // Valid octal "12" with length=2
         int offset = 0;
         int length = 2;
         
         try {
             // Act
             long result = TarUtils.parseOctal(buffer, offset, length);
             
             // Assert
             // If we get here, the test passes (original behavior)
             assertEquals(10L, result); // "12" in octal is 10 in decimal
         } catch (IllegalArgumentException e) {
             // If we catch exception, check if it's from the mutant
             if (e.getMessage().contains("greater than 2")) {
                 fail("Mutant detected: Method incorrectly rejects length=2 input");
             } else {
                 fail("Unexpected exception: " + e.getMessage());
             }
         }
     }

 @Test
    public void testParseOctalWithLength3ShouldPass() {
        // Arrange
        byte[] buffer = {' ', '1', '2', '3', ' '}; // Valid octal with length 3 (after trimming)
        int offset = 0;
        int length = 3;
        
        try {
            // Act
            long result = TarUtils.parseOctal(buffer, offset, length);
            
            // Assert
            // If we get here, the test passes (original behavior)
            // The mutant would throw an exception
            assertTrue(true); // Explicit pass
        } catch (IllegalArgumentException e) {
            // Verify it's not the mutated exception
            if (e.getMessage().contains("must be exactly 2")) {
                fail("Mutant detected: Method incorrectly requires length to be exactly 2");
            }
            // If it's a different exception, let it fail normally
            throw e;
        }
    }

 @Test(expected = IllegalArgumentException.class)
    public void testParseOctalWithLength1ShouldFail() {
        // Arrange
        byte[] buffer = {'1'};
        int offset = 0;
        int length = 1;
        
        // Act
        TarUtils.parseOctal(buffer, offset, length);
        
        // Assert - handled by expected exception
    }

 @Test
    public void testParseOctalWithLength1VerifyMessage() {
        // Arrange
        byte[] buffer = {'1'};
        int offset = 0;
        int length = 1;
        
        try {
            // Act
            TarUtils.parseOctal(buffer, offset, length);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Assert
            assertTrue("Exception message should mention 'at least 2'", 
                      e.getMessage().contains("must be at least 2"));
            assertFalse("Mutant message detected", 
                       e.getMessage().contains("must be exactly 2"));
        }
    }

 @Test
   public void testParseOctalWithLeadingZero() {
       // Setup test data
       byte[] buffer = {0, '1', '2', ' '}; // buffer starts with 0
       int offset = 0;
       int length = 4;
       
       // Expected behavior: should return 0L immediately when first byte is 0
       long result = TarUtils.parseOctal(buffer, offset, length);
       
       // Assertion that will catch the mutant
       assertEquals("Should return 0 when buffer starts with 0", 0L, result);
       
       // Additional verification that mutant behavior would fail
       // Mutant would process the buffer and return octal value of "12" (10 in decimal)
       assertNotEquals("Mutant would return wrong value", 10L, result);
   }

 @Test
  public void testParseOctalWithLeadingZeroShouldReturnZero() {
      // Arrange
      byte[] buffer = {0, '1', '2', ' ', 0}; // Starts with 0, valid octal "12"
      int offset = 0;
      int length = buffer.length;
      
      // Act
      long result = TarUtils.parseOctal(buffer, offset, length);
      
      // Assert
      assertEquals("Should return 0L when buffer starts with 0", 0L, result);
  }

 @Test
 public void testParseOctalWithLeadingZeroReturnsZero() {
     // Arrange
     byte[] buffer = {0, '1', '2', ' '}; // First byte is 0
     int offset = 0;
     int length = 4;
     
     // Act
     long result = TarUtils.parseOctal(buffer, offset, length);
     
     // Assert
     assertEquals("Method should return 0 when first byte is 0", 0L, result);
 }

}
