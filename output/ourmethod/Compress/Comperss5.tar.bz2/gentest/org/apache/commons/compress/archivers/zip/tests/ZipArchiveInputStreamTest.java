package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
 
public class ZipArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                          public void testRead_WhenFinishedOrCurrentNull_ReturnsNegativeOne() throws Exception {
                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                              Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                                              
                                                                                                                                                                              // Set inflater to finished state
                                                                                                                                                                              when(mockInflater.finished()).thenReturn(true);
                                                                                                                                                                              // Use reflection to set private field if needed, or find another way to set state
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(-1, zais.read(new byte[10], 0, 5));
                                                                                                                                                                              
                                                                                                                                                                              // Test with current = null
                                                                                                                                                                              zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                                              // Set current to null (again might need reflection)
                                                                                                                                                                              assertEquals(-1, zais.read(new byte[10], 0, 5));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_WithStoredMethod_ReadsCorrectly() throws Exception {
                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                                              when(mockEntry.getSize()).thenReturn(100L);
                                                                                                                                                                              
                                                                                                                                                                              // Setup the stream to return some test data
                                                                                                                                                                              when(mockInputStream.read(any(byte[].class))).thenReturn(10);
                                                                                                                                                                              
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                                              // Need to set current entry and other internal state (might require reflection)
                                                                                                                                                                              
                                                                                                                                                                              byte[] buffer = new byte[20];
                                                                                                                                                                              int read = zais.read(buffer, 0, 10);
                                                                                                                                                                              assertEquals(10, read);
                                                                                                                                                                              // Verify CRC was updated
                                                                                                                                                                              // Verify readBytesOfEntry was incremented
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_WithStoredMethod_WhenReadBytesExceedSize_ReturnsNegativeOne() throws Exception {
                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                                                                                                              when(mockEntry.getSize()).thenReturn(10L);
                                                                                                                                                                              
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                                              // Set readBytesOfEntry to 10 (equal to size)
                                                                                                                                                                              // Set current entry
                                                                                                                                                                              
                                                                                                                                                                              assertEquals(-1, zais.read(new byte[10], 0, 5));
                                                                                                                                                                          }

 @Test
                                                                                                                                                                          public void testRead_WithDeflatedMethod_HandlesNeedsInput() throws Exception {
                                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                              Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                                              when(mockInflater.needsInput()).thenReturn(true);
                                                                                                                                                                              when(mockInputStream.read(any(byte[].class))).thenReturn(10);
                                                                                                                                                                              
                                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                                              // Set inflater to mockInflater
                                                                                                                                                                              // Set current entry with non-STORED method
                                                                                                                                                                              
                                                                                                                                                                              byte[] buffer = new byte[20];
                                                                                                                                                                              when(mockInflater.inflate(buffer, 0, 10)).thenReturn(5);
                                                                                                                                                                              
                                                                                                                                                                              int read = zais.read(buffer, 0, 10);
                                                                                                                                                                              assertEquals(5, read);
                                                                                                                                                                              // Verify fill() was called
                                                                                                                                                                              // Verify CRC was updated
                                                                                                                                                                          }

 @Test
                                                                                                                                                                  public void testRead_WhenStreamClosed_ThrowsIOException() throws Exception {
                                                                                                                                                                      // Setup
                                                                                                                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                                      zais.close(); // This should set closed = true
                                                                                                                                                                      
                                                                                                                                                                      // Exception verification
                                                                                                                                                                      ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                      expectedException.expect(IOException.class);
                                                                                                                                                                      expectedException.expectMessage("The stream is closed");
                                                                                                                                                                      
                                                                                                                                                                      // Test
                                                                                                                                                                      zais.read(new byte[10], 0, 5);
                                                                                                                                                                  }

 @Test
                                                                                                                                                          public void testRead_WithInvalidBufferParameters_ThrowsArrayIndexOutOfBounds() throws Exception {
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                              
                                                                                                                                                              expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                              
                                                                                                                                                              // Test various invalid buffer scenarios
                                                                                                                                                              zais.read(new byte[10], -1, 5);  // negative start
                                                                                                                                                              zais.read(new byte[10], 0, -1);  // negative length
                                                                                                                                                              zais.read(new byte[10], 15, 5);  // start beyond buffer length
                                                                                                                                                              zais.read(new byte[10], 5, 10);  // length exceeds buffer capacity
                                                                                                                                                          }

 @Test
                                                                                                                                                          public void testRead_WithDeflatedMethod_WhenTruncated_ThrowsIOException() throws Exception {
                                                                                                                                                              // Setup
                                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                              Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                              when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                              when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                                              when(mockInflater.finished()).thenReturn(false);
                                                                                                                                                              
                                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set private fields
                                                                                                                                                              Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inflater");
                                                                                                                                                              inflaterField.setAccessible(true);
                                                                                                                                                              inflaterField.set(zais, mockInflater);
                                                                                                                                                              
                                                                                                                                                              Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                              currentEntryField.setAccessible(true);
                                                                                                                                                              currentEntryField.set(zais, new ZipArchiveEntry("test"));
                                                                                                                                                              
                                                                                                                                                              Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                              lengthOfLastReadField.setAccessible(true);
                                                                                                                                                              lengthOfLastReadField.set(zais, -1);
                                                                                                                                                              
                                                                                                                                                              // Test
                                                                                                                                                              try {
                                                                                                                                                                  zais.read(new byte[10], 0, 5);
                                                                                                                                                                  fail("Expected IOException");
                                                                                                                                                              } catch (IOException e) {
                                                                                                                                                                  assertEquals("Truncated ZIP file", e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

 @Test
                                                                                                                                                      public void testRead_WithDeflatedMethod_ThrowsZipExceptionOnDataFormatError() throws Exception {
                                                                                                                                                          // Setup mocks
                                                                                                                                                          InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                          Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                          when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                          
                                                                                                                                                          DataFormatException formatException = new DataFormatException("Invalid data");
                                                                                                                                                          when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                              .thenThrow(formatException);
                                                                                                                                                          
                                                                                                                                                          // Create instance and set up private fields using reflection
                                                                                                                                                          ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                          
                                                                                                                                                          // Set inflater to mockInflater
                                                                                                                                                          Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inflater");
                                                                                                                                                          inflaterField.setAccessible(true);
                                                                                                                                                          inflaterField.set(zais, mockInflater);
                                                                                                                                                          
                                                                                                                                                          // Set current entry to indicate DEFLATED method
                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                                          entry.setMethod(8); // 8 is the value of ZipEntry.DEFLATED
                                                                                                                                                          Field currentEntryField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                          currentEntryField.setAccessible(true);
                                                                                                                                                          currentEntryField.set(zais, entry);
                                                                                                                                                          
                                                                                                                                                          // Set up expected exception
                                                                                                                                                          try {
                                                                                                                                                              zais.read(new byte[10], 0, 5);
                                                                                                                                                              fail("Expected ZipException to be thrown");
                                                                                                                                                          } catch (ZipException e) {
                                                                                                                                                              assertEquals("Invalid data", e.getMessage());
                                                                                                                                                          }
                                                                                                                                                      }

 @Test(expected = RuntimeException.class)
                                                                                                                                                 public void testRead_NonDataFormatExceptionPropagates() throws Exception {
                                                                                                                                                     // Setup
                                                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                                                     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                                                                     
                                                                                                                                                     // Set state to reach inflation code path
                                                                                                                                                     ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                                     entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                     
                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                     currentField.setAccessible(true);
                                                                                                                                                     currentField.set(zis, entry);
                                                                                                                                                     
                                                                                                                                                     Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                     closedField.setAccessible(true);
                                                                                                                                                     closedField.set(zis, false);
                                                                                                                                                     
                                                                                                                                                     Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                                     lengthField.setAccessible(true);
                                                                                                                                                     lengthField.set(zis, 1); // Needs input
                                                                                                                                                     
                                                                                                                                                     // Mock inflater to throw non-DataFormatException
                                                                                                                                                     Inflater mockInf = mock(Inflater.class);
                                                                                                                                                     when(mockInf.needsInput()).thenReturn(false);
                                                                                                                                                     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                         .thenThrow(new RuntimeException("Test exception"));
                                                                                                                                                     
                                                                                                                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                     infField.setAccessible(true);
                                                                                                                                                     infField.set(zis, mockInf);
                                                                                                                                                     
                                                                                                                                                     // Prepare valid buffer
                                                                                                                                                     byte[] buffer = new byte[10];
                                                                                                                                                     
                                                                                                                                                     // This should throw - mutant would catch the exception
                                                                                                                                                     zis.read(buffer, 0, 10);
                                                                                                                                                 }

 @Test(expected = ZipException.class)
                                                                                                                                             public void testRead_ThrowsZipExceptionWithOriginalMessageWhenDataFormatExceptionOccurs() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                 Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                 ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                 
                                                                                                                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to inject our mock inflater since it's final private
                                                                                                                                                 Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                 inflaterField.setAccessible(true);
                                                                                                                                                 inflaterField.set(zais, mockInflater);
                                                                                                                                                 
                                                                                                                                                 // Set current entry to non-stored method to reach inflation path
                                                                                                                                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                 currentField.setAccessible(true);
                                                                                                                                                 currentField.set(zais, mockEntry);
                                                                                                                                                 when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                 
                                                                                                                                                 // Setup buffer conditions to pass initial checks
                                                                                                                                                 byte[] buffer = new byte[10];
                                                                                                                                                 int start = 0;
                                                                                                                                                 int length = 5;
                                                                                                                                                 
                                                                                                                                                 // Make inflater throw DataFormatException with specific message
                                                                                                                                                 String errorMessage = "Test data format error";
                                                                                                                                                 when(mockInflater.needsInput()).thenReturn(true);
                                                                                                                                                 doThrow(new DataFormatException(errorMessage))
                                                                                                                                                     .when(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                 
                                                                                                                                                 // Exercise and verify
                                                                                                                                                 try {
                                                                                                                                                     zais.read(buffer, start, length);
                                                                                                                                                     fail("Expected ZipException to be thrown");
                                                                                                                                                 } catch (ZipException e) {
                                                                                                                                                     // Verify the exception contains the original error message
                                                                                                                                                     assertTrue("Exception message should contain original error", 
                                                                                                                                                               e.getMessage().contains(errorMessage));
                                                                                                                                                     throw e;
                                                                                                                                                 }
                                                                                                                                             }

 @Test(expected = ZipException.class)
                                                                                                                                            public void testRead_ThrowsZipExceptionOnDataFormatError() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                Inflater mockInflater = mock(Inflater.class);
                                                                                                                                                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                                
                                                                                                                                                // Create test instance using reflection since constructor may need adjustment
                                                                                                                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                                
                                                                                                                                                // Set up required state
                                                                                                                                                Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                infField.setAccessible(true);
                                                                                                                                                infField.set(zais, mockInflater);
                                                                                                                                                
                                                                                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                currentField.setAccessible(true);
                                                                                                                                                currentField.set(zais, mockEntry);
                                                                                                                                                
                                                                                                                                                Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                closedField.setAccessible(true);
                                                                                                                                                closedField.set(zais, false);
                                                                                                                                                
                                                                                                                                                when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                                when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                                
                                                                                                                                                // Make inflate throw DataFormatException
                                                                                                                                                doThrow(new DataFormatException("test error"))
                                                                                                                                                    .when(mockInflater).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                                                                                
                                                                                                                                                // Test - should throw ZipException (original) or IOException (mutant)
                                                                                                                                                byte[] buffer = new byte[10];
                                                                                                                                                zais.read(buffer, 0, 10);
                                                                                                                                            }

 @Test
                                                                                                                                          public void testReadThrowsZipExceptionOnDataFormatError() throws IOException {
                                                                                                                                              // Setup
                                                                                                                                              byte[] buffer = new byte[1024];
                                                                                                                                              int start = 0;
                                                                                                                                              int length = 100;
                                                                                                                                              
                                                                                                                                              // Mock dependencies
                                                                                                                                              InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                              Inflater mockInflater = mock(Inflater.class);
                                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                              
                                                                                                                                              // Create test instance
                                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                              
                                                                                                                                              // Use reflection to set private fields for testing
                                                                                                                                              // This is necessary because we need to control the internal state
                                                                                                                                              try {
                                                                                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                                  infField.setAccessible(true);
                                                                                                                                                  infField.set(zais, mockInflater);
                                                                                                                                                  
                                                                                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                                  currentField.setAccessible(true);
                                                                                                                                                  currentField.set(zais, mockEntry);
                                                                                                                                                  
                                                                                                                                                  Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                                  closedField.setAccessible(true);
                                                                                                                                                  closedField.set(zais, false);
                                                                                                                                              } catch (Exception e) {
                                                                                                                                                  throw new RuntimeException("Failed to set up test", e);
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Configure mocks
                                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                              when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                              try {
                                                                                                                                                  when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                                                      .thenThrow(new DataFormatException("Test data format error"));
                                                                                                                                              } catch (DataFormatException e) {
                                                                                                                                                  throw new RuntimeException(e);
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Expect ZipException to be thrown (original behavior)
                                                                                                                                              thrown.expect(ZipException.class);
                                                                                                                                              thrown.expectMessage("Test data format error");
                                                                                                                                              
                                                                                                                                              // Execute
                                                                                                                                              zais.read(buffer, start, length);
                                                                                                                                          }

 @Test
                                                                                                                                      public void testReadWithNegativeInflateResult() throws Exception {
                                                                                                                                          // Setup
                                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                                          Inflater mockInf = mock(Inflater.class);
                                                                                                                                          ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                          CRC32 mockCrc = mock(CRC32.class);
                                                                                                                                          
                                                                                                                                          // Create test instance using reflection since constructor is complex
                                                                                                                                          ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                          
                                                                                                                                          // Set internal state via reflection
                                                                                                                                          Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                          infField.setAccessible(true);
                                                                                                                                          infField.set(zais, mockInf);
                                                                                                                                          
                                                                                                                                          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                          currentField.setAccessible(true);
                                                                                                                                          currentField.set(zais, mockEntry);
                                                                                                                                          
                                                                                                                                          Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                                          crcField.setAccessible(true);
                                                                                                                                          crcField.set(zais, mockCrc);
                                                                                                                                          
                                                                                                                                          // Configure mocks
                                                                                                                                          when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                          when(mockInf.needsInput()).thenReturn(false);
                                                                                                                                          
                                                                                                                                          // Make inflate return a negative value to simulate error
                                                                                                                                          when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                          
                                                                                                                                          // Test
                                                                                                                                          byte[] buffer = new byte[10];
                                                                                                                                          try {
                                                                                                                                              zais.read(buffer, 0, 10);
                                                                                                                                              fail("Expected IOException not thrown");
                                                                                                                                          } catch (IOException e) {
                                                                                                                                              // Verify correct exception is thrown for negative inflate result
                                                                                                                                              assertTrue(e.getMessage().contains("Truncated ZIP file") || 
                                                                                                                                                        e.getMessage().contains("invalid inflate result"));
                                                                                                                                          }
                                                                                                                                          
                                                                                                                                          // Verify crc was not updated for error case
                                                                                                                                          verify(mockCrc, never()).update(any(byte[].class), anyInt(), anyInt());
                                                                                                                                      }

 @Test
                                                                                                                                    public void testRead_CompressedEntry_ZeroInflate_NotFinished() throws Exception {
                                                                                                                                        // Setup
                                                                                                                                        ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                        byte[] buffer = new byte[1024];
                                                                                                                                        
                                                                                                                                        // Mock current entry as compressed (not STORED)
                                                                                                                                        ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                                                        when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                        
                                                                                                                                        // Use reflection to set current entry since it's private
                                                                                                                                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                        currentField.setAccessible(true);
                                                                                                                                        currentField.set(zis, entry);
                                                                                                                                        
                                                                                                                                        // Mock inflater behavior
                                                                                                                                        Inflater inf = mock(Inflater.class);
                                                                                                                                        when(inf.finished()).thenReturn(false); // Inflation not finished
                                                                                                                                        when(inf.needsInput()).thenReturn(false);
                                                                                                                                        when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0); // inflate returns 0
                                                                                                                                        
                                                                                                                                        // Use reflection to inject mock inflater since it's final
                                                                                                                                        Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                        infField.setAccessible(true);
                                                                                                                                        infField.set(zis, inf);
                                                                                                                                        
                                                                                                                                        // Set lengthOfLastRead to positive value (not truncated)
                                                                                                                                        Field lolrField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                        lolrField.setAccessible(true);
                                                                                                                                        lolrField.set(zis, 100);
                                                                                                                                        
                                                                                                                                        // Test - original should continue processing (would throw exception if buffer empty)
                                                                                                                                        // Mutant would incorrectly return -1 or throw exception
                                                                                                                                        try {
                                                                                                                                            int result = zis.read(buffer, 0, 100);
                                                                                                                                            // If we get here, mutant was caught (original continues processing)
                                                                                                                                            // Verify inflate was called
                                                                                                                                            verify(inf).inflate(buffer, 0, 100);
                                                                                                                                        } catch (IOException e) {
                                                                                                                                            // Original might throw if buffer empty, but mutant would throw for wrong reason
                                                                                                                                            assertFalse(e.getMessage().equals("Truncated ZIP file"));
                                                                                                                                        }
                                                                                                                                    }

 @Test
                                                                                                                                public void testReadWithNonZeroInflateShouldNotCheckFinished() throws Exception {
                                                                                                                                    // Setup
                                                                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                                                                    Inflater mockInf = mock(Inflater.class);
                                                                                                                                    ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                    CRC32 mockCrc = mock(CRC32.class);
                                                                                                                                    
                                                                                                                                    // Create test instance using reflection since constructor is complex
                                                                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                    
                                                                                                                                    // Set up internal state via reflection
                                                                                                                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                    infField.setAccessible(true);
                                                                                                                                    infField.set(zais, mockInf);
                                                                                                                                    
                                                                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                    currentField.setAccessible(true);
                                                                                                                                    currentField.set(zais, mockEntry);
                                                                                                                                    
                                                                                                                                    Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                                    crcField.setAccessible(true);
                                                                                                                                    crcField.set(zais, mockCrc);
                                                                                                                                    
                                                                                                                                    Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                    closedField.setAccessible(true);
                                                                                                                                    closedField.set(zais, false);
                                                                                                                                    
                                                                                                                                    // Mock behavior
                                                                                                                                    when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                    when(mockInf.needsInput()).thenReturn(false);
                                                                                                                                    when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(10); // non-zero return
                                                                                                                                    
                                                                                                                                    // Test
                                                                                                                                    byte[] buffer = new byte[100];
                                                                                                                                    int result = zais.read(buffer, 0, 100);
                                                                                                                                    
                                                                                                                                    // Verify
                                                                                                                                    assertEquals(10, result); // Should return the inflated bytes
                                                                                                                                    verify(mockInf, never()).finished(); // Should not check finished state
                                                                                                                                    verify(mockCrc).update(buffer, 0, 10); // Should update CRC
                                                                                                                                    
                                                                                                                                    // This will fail on the mutant because mutant will always check finished()
                                                                                                                                    // even when we have a successful read (returning 10)
                                                                                                                                }

 @Test
                                                                                                                               public void testReadShouldNotReturnMinusOneWhenInflaterNotFinishedButReadReturnsMinusOne() throws Exception {
                                                                                                                                   // Setup
                                                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                   Inflater mockInflater = mock(Inflater.class);
                                                                                                                                   ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                   
                                                                                                                                   // Create test instance using reflection since constructor initializes these fields
                                                                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                                   
                                                                                                                                   // Set up mocks
                                                                                                                                   when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                   when(mockInflater.finished()).thenReturn(false);
                                                                                                                                   when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                                   
                                                                                                                                   // Use reflection to set private fields
                                                                                                                                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                   infField.setAccessible(true);
                                                                                                                                   infField.set(zais, mockInflater);
                                                                                                                                   
                                                                                                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                   currentField.setAccessible(true);
                                                                                                                                   currentField.set(zais, mockEntry);
                                                                                                                                   
                                                                                                                                   Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                   closedField.setAccessible(true);
                                                                                                                                   closedField.set(zais, false);
                                                                                                                                   
                                                                                                                                   // Mock inflate to return -1 while inflater is not finished
                                                                                                                                   when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                                                                                                                                   
                                                                                                                                   // Test buffer
                                                                                                                                   byte[] buffer = new byte[10];
                                                                                                                                   
                                                                                                                                   // Test - should not return -1 just because inflate returned -1
                                                                                                                                   int result = zais.read(buffer, 0, 10);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertNotEquals("Should not return -1 when inflater is not finished", -1, result);
                                                                                                                                   verify(mockInflater).inflate(eq(buffer), eq(0), eq(10));
                                                                                                                               }

 @Test
                                                                                                                              public void testRead_ReturnsMinusOneWhenInflaterFinished() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                                                  Inflater mockInf = mock(Inflater.class);
                                                                                                                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                                  
                                                                                                                                  // Create real ZipArchiveInputStream with mocked dependencies
                                                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                                  
                                                                                                                                  // Use reflection to inject our mock inflater since it's final
                                                                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                                  infField.setAccessible(true);
                                                                                                                                  infField.set(zais, mockInf);
                                                                                                                                  
                                                                                                                                  // Set current entry
                                                                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                  currentField.setAccessible(true);
                                                                                                                                  currentField.set(zais, mockEntry);
                                                                                                                                  
                                                                                                                                  // Setup mock behavior
                                                                                                                                  when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                                  when(mockInf.finished()).thenReturn(true);  // Critical for this test
                                                                                                                                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                                  
                                                                                                                                  // Prepare buffer
                                                                                                                                  byte[] buffer = new byte[1024];
                                                                                                                                  
                                                                                                                                  // Test - should return -1 when inflater is finished
                                                                                                                                  int result = zais.read(buffer, 0, 100);
                                                                                                                                  
                                                                                                                                  // Verify
                                                                                                                                  assertEquals("Should return -1 when inflater is finished", -1, result);
                                                                                                                                  
                                                                                                                                  // Verify inflater.finished() was checked (would fail with mutant)
                                                                                                                                  verify(mockInf).finished();
                                                                                                                              }

 @Test
                                                                                                                             public void testReadStoredEntryWhenAllBytesRead() throws Exception {
                                                                                                                                 // Setup
                                                                                                                                 InputStream mockInput = mock(InputStream.class);
                                                                                                                                 ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                                                 
                                                                                                                                 // Create a stored entry
                                                                                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                 entry.setMethod(ZipArchiveOutputStream.STORED);
                                                                                                                                 entry.setSize(100); // Set size to 100 bytes
                                                                                                                                 
                                                                                                                                 // Use reflection to set private fields since we can't access them directly
                                                                                                                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                 currentField.setAccessible(true);
                                                                                                                                 currentField.set(zis, entry);
                                                                                                                                 
                                                                                                                                 Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                 readBytesField.setAccessible(true);
                                                                                                                                 readBytesField.set(zis, 100); // All bytes read
                                                                                                                                 
                                                                                                                                 Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 closedField.set(zis, false);
                                                                                                                                 
                                                                                                                                 // Test
                                                                                                                                 byte[] buffer = new byte[10];
                                                                                                                                 int result = zis.read(buffer, 0, 10);
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 assertEquals("Should return -1 when all bytes of stored entry are read", -1, result);
                                                                                                                             }

 @Test
                                                                                                                            public void testReadStoredMethodWhenEntryFullyRead() throws Exception {
                                                                                                                                // Setup
                                                                                                                                InputStream mockInput = mock(InputStream.class);
                                                                                                                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                                                
                                                                                                                                // Create a stored entry with size 100
                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                entry.setMethod(ZipArchiveOutputStream.STORED);
                                                                                                                                entry.setSize(100);
                                                                                                                                entry.setCompressedSize(100);
                                                                                                                                
                                                                                                                                // Use reflection to set private fields since we can't access them directly
                                                                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                                currentField.setAccessible(true);
                                                                                                                                currentField.set(zis, entry);
                                                                                                                                
                                                                                                                                Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                                                                readBytesField.setAccessible(true);
                                                                                                                                readBytesField.set(zis, 100); // Fully read
                                                                                                                                
                                                                                                                                Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                                lengthOfLastReadField.setAccessible(true);
                                                                                                                                lengthOfLastReadField.set(zis, 10); // Some previous read value
                                                                                                                                
                                                                                                                                // Test buffer
                                                                                                                                byte[] buffer = new byte[1024];
                                                                                                                                
                                                                                                                                // Test - should return -1 when fully read
                                                                                                                                int result = zis.read(buffer, 0, 10);
                                                                                                                                
                                                                                                                                // Verify
                                                                                                                                assertEquals("Should return -1 when entry is fully read", -1, result);
                                                                                                                                
                                                                                                                                // Clean up
                                                                                                                                currentField.setAccessible(false);
                                                                                                                                readBytesField.setAccessible(false);
                                                                                                                                lengthOfLastReadField.setAccessible(false);
                                                                                                                            }

 @Test
                                                                                                                           public void testRead_DeflatedCompressionWithZeroLengthReadShouldNotThrow() throws Exception {
                                                                                                                               // Setup
                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                               Inflater mockInf = mock(Inflater.class);
                                                                                                                               ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                               CRC32 mockCrc = mock(CRC32.class);
                                                                                                                               
                                                                                                                               // Create test instance using reflection to inject mocks
                                                                                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                               infField.setAccessible(true);
                                                                                                                               infField.set(zais, mockInf);
                                                                                                                               
                                                                                                                               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                               crcField.setAccessible(true);
                                                                                                                               crcField.set(zais, mockCrc);
                                                                                                                               
                                                                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                               currentField.setAccessible(true);
                                                                                                                               currentField.set(zais, mockEntry);
                                                                                                                               
                                                                                                                               Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                               lengthOfLastReadField.setAccessible(true);
                                                                                                                               lengthOfLastReadField.set(zais, 0); // Critical: set to 0
                                                                                                                               
                                                                                                                               // Mock behavior
                                                                                                                               when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                               when(mockInf.finished()).thenReturn(false);
                                                                                                                               when(mockInf.needsInput()).thenReturn(false);
                                                                                                                               
                                                                                                                               // Test - should NOT throw exception with lengthOfLastRead = 0
                                                                                                                               byte[] buffer = new byte[10];
                                                                                                                               int result = zais.read(buffer, 0, 10);
                                                                                                                               
                                                                                                                               // Verify
                                                                                                                               assertEquals(-1, result); // Expected to return -1, not throw exception
                                                                                                                               verify(mockInf).inflate(buffer, 0, 10);
                                                                                                                               verify(mockCrc, never()).update(any(byte[].class), anyInt(), anyInt());
                                                                                                                           }

 @Test
                                                                                                                          public void testRead_ShouldNotThrowWhenReadZeroButStreamNotFinished() throws Exception {
                                                                                                                              // Setup
                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                              Inflater mockInf = mock(Inflater.class);
                                                                                                                              ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                              CRC32 mockCrc = mock(CRC32.class);
                                                                                                                              
                                                                                                                              // Create test instance using reflection to inject mocks
                                                                                                                              ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                                                                                              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                              infField.setAccessible(true);
                                                                                                                              infField.set(zais, mockInf);
                                                                                                                              
                                                                                                                              Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                              crcField.setAccessible(true);
                                                                                                                              crcField.set(zais, mockCrc);
                                                                                                                              
                                                                                                                              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                              currentField.setAccessible(true);
                                                                                                                              currentField.set(zais, mockEntry);
                                                                                                                              
                                                                                                                              Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                              lengthOfLastReadField.setAccessible(true);
                                                                                                                              lengthOfLastReadField.set(zais, 1); // Set to non-negative value
                                                                                                                              
                                                                                                                              // Mock behavior
                                                                                                                              when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                              when(mockInf.needsInput()).thenReturn(false);
                                                                                                                              when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                              when(mockInf.finished()).thenReturn(false);
                                                                                                                              
                                                                                                                              // Test - should not throw exception in original code
                                                                                                                              byte[] buffer = new byte[10];
                                                                                                                              int result = zais.read(buffer, 0, 10);
                                                                                                                              
                                                                                                                              // Verify
                                                                                                                              assertEquals(-1, result); // Expected behavior when read returns 0 but stream isn't finished
                                                                                                                              // If mutant is present, it would throw IOException instead
                                                                                                                          }

 @Test(expected = IOException.class)
                                                                                                                         public void testRead_ThrowsCorrectTruncatedZipException() throws Exception {
                                                                                                                             // Setup mock objects
                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                             Inflater mockInflater = mock(Inflater.class);
                                                                                                                             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                             
                                                                                                                             // Create test instance using reflection to inject mocks
                                                                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                             
                                                                                                                             // Set internal state using reflection
                                                                                                                             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                             infField.setAccessible(true);
                                                                                                                             infField.set(zais, mockInflater);
                                                                                                                             
                                                                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                             currentField.setAccessible(true);
                                                                                                                             currentField.set(zais, mockEntry);
                                                                                                                             
                                                                                                                             Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                             lengthOfLastReadField.setAccessible(true);
                                                                                                                             lengthOfLastReadField.set(zais, -1);
                                                                                                                             
                                                                                                                             // Mock behavior
                                                                                                                             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                             when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                             when(mockInflater.finished()).thenReturn(false);
                                                                                                                             
                                                                                                                             // Prepare test buffer
                                                                                                                             byte[] buffer = new byte[1024];
                                                                                                                             
                                                                                                                             try {
                                                                                                                                 zais.read(buffer, 0, 1024);
                                                                                                                             } catch (IOException e) {
                                                                                                                                 // Verify exception message
                                                                                                                                 assertEquals("Truncated ZIP file", e.getMessage());
                                                                                                                                 throw e;
                                                                                                                             }
                                                                                                                         }

 @Test(expected = IOException.class)
                                                                                                                        public void testRead_ThrowsIOExceptionWhenZipFileTruncated() throws Exception {
                                                                                                                            // Setup
                                                                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                                                                            Inflater mockInflater = mock(Inflater.class);
                                                                                                                            ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                            
                                                                                                                            // Create instance using reflection since constructor may be private
                                                                                                                            ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                                                            
                                                                                                                            // Set up mock behaviors using reflection to access private fields
                                                                                                                            Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                            infField.setAccessible(true);
                                                                                                                            infField.set(zais, mockInflater);
                                                                                                                            
                                                                                                                            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                            currentField.setAccessible(true);
                                                                                                                            currentField.set(zais, mockEntry);
                                                                                                                            
                                                                                                                            Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                            lengthOfLastReadField.setAccessible(true);
                                                                                                                            lengthOfLastReadField.set(zais, -1);
                                                                                                                            
                                                                                                                            // Mock behaviors
                                                                                                                            when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                            when(mockInflater.finished()).thenReturn(false);
                                                                                                                            when(mockInflater.needsInput()).thenReturn(false);
                                                                                                                            when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                            
                                                                                                                            // Test - should throw IOException with "Truncated ZIP file" message
                                                                                                                            byte[] buffer = new byte[1024];
                                                                                                                            zais.read(buffer, 0, 1024);
                                                                                                                            
                                                                                                                            // If we get here, the test fails (expected exception not thrown)
                                                                                                                            fail("Expected IOException for truncated ZIP file");
                                                                                                                        }

 @Test
                                                                                                                      public void testRead_DetectsTruncatedZipFile() throws Exception {
                                                                                                                          // Setup
                                                                                                                          InputStream mockInput = mock(InputStream.class);
                                                                                                                          Inflater mockInf = mock(Inflater.class);
                                                                                                                          ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                          CRC32 mockCrc = mock(CRC32.class);
                                                                                                                          
                                                                                                                          // Create test instance using reflection to inject mocks
                                                                                                                          ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                                          
                                                                                                                          // Set internal state via reflection
                                                                                                                          Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                          infField.setAccessible(true);
                                                                                                                          infField.set(zais, mockInf);
                                                                                                                          
                                                                                                                          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                          currentField.setAccessible(true);
                                                                                                                          currentField.set(zais, mockEntry);
                                                                                                                          
                                                                                                                          Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                          crcField.setAccessible(true);
                                                                                                                          crcField.set(zais, mockCrc);
                                                                                                                          
                                                                                                                          Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                                          lengthOfLastReadField.setAccessible(true);
                                                                                                                          lengthOfLastReadField.set(zais, -1);
                                                                                                                          
                                                                                                                          // Mock behavior
                                                                                                                          when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                          when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                                                          when(mockInf.finished()).thenReturn(false);
                                                                                                                          
                                                                                                                          // Test - should throw IOException for truncated file
                                                                                                                          byte[] buffer = new byte[1024];
                                                                                                                          try {
                                                                                                                              zais.read(buffer, 0, 1024);
                                                                                                                              fail("Expected IOException for truncated ZIP file");
                                                                                                                          } catch (IOException e) {
                                                                                                                              // Expected exception
                                                                                                                          }
                                                                                                                      }

 @Test
                                                                                                                  public void testReadUpdatesCrcWithCorrectByteCount() throws Exception {
                                                                                                                      // Setup test data
                                                                                                                      byte[] buffer = new byte[100];
                                                                                                                      int start = 0;
                                                                                                                      int length = 50;
                                                                                                                      int expectedRead = 25; // non-zero value to test CRC update
                                                                                                                      
                                                                                                                      // Mock dependencies
                                                                                                                      ZipArchiveInputStream zis = new ZipArchiveInputStream(mock(InputStream.class));
                                                                                                                      Inflater inf = mock(Inflater.class);
                                                                                                                      CRC32 crc = mock(CRC32.class);
                                                                                                                      
                                                                                                                      // Use reflection to set private fields since we need to test behavior
                                                                                                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                      infField.setAccessible(true);
                                                                                                                      infField.set(zis, inf);
                                                                                                                      
                                                                                                                      Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                      crcField.setAccessible(true);
                                                                                                                      crcField.set(zis, crc);
                                                                                                                      
                                                                                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                      currentField.setAccessible(true);
                                                                                                                      currentField.set(zis, new ZipArchiveEntry("test"));
                                                                                                                      
                                                                                                                      // Mock behavior
                                                                                                                      when(inf.finished()).thenReturn(false);
                                                                                                                      when(inf.needsInput()).thenReturn(true);
                                                                                                                      when(inf.inflate(buffer, start, length)).thenReturn(expectedRead);
                                                                                                                      
                                                                                                                      // Execute
                                                                                                                      int actualRead = zis.read(buffer, start, length);
                                                                                                                      
                                                                                                                      // Verify
                                                                                                                      assertEquals("Should return correct number of bytes read", expectedRead, actualRead);
                                                                                                                      verify(crc).update(buffer, start, expectedRead); // This will fail if mutant is present
                                                                                                                      
                                                                                                                      // Clean up reflection access
                                                                                                                      infField.setAccessible(false);
                                                                                                                      crcField.setAccessible(false);
                                                                                                                      currentField.setAccessible(false);
                                                                                                                  }

 @Test
                                                                                                                 public void testReadUpdatesCrcWithCorrectLength() throws Exception {
                                                                                                                     // Setup
                                                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                                                     Inflater mockInf = mock(Inflater.class);
                                                                                                                     CRC32 mockCrc = mock(CRC32.class);
                                                                                                                     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                                     
                                                                                                                     // Create test instance using reflection to inject mocks
                                                                                                                     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                                     infField.setAccessible(true);
                                                                                                                     infField.set(zis, mockInf);
                                                                                                                     
                                                                                                                     Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                                     crcField.setAccessible(true);
                                                                                                                     crcField.set(zis, mockCrc);
                                                                                                                     
                                                                                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                                     currentField.setAccessible(true);
                                                                                                                     currentField.set(zis, mockEntry);
                                                                                                                     
                                                                                                                     // Configure mocks
                                                                                                                     when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                                     when(mockInf.needsInput()).thenReturn(false);
                                                                                                                     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                         .thenReturn(5); // return 5 bytes read
                                                                                                                     
                                                                                                                     // Test buffer - larger than bytes read
                                                                                                                     byte[] buffer = new byte[10];
                                                                                                                     int bytesRead = zis.read(buffer, 0, 10);
                                                                                                                     
                                                                                                                     // Verify
                                                                                                                     assertEquals(5, bytesRead);
                                                                                                                     // Verify CRC was updated with correct length (5), not buffer length (10)
                                                                                                                     verify(mockCrc).update(buffer, 0, 5);
                                                                                                                     
                                                                                                                     // Clean up
                                                                                                                     infField.setAccessible(false);
                                                                                                                     crcField.setAccessible(false);
                                                                                                                     currentField.setAccessible(false);
                                                                                                                 }

 @Test
                                                                                                           public void testReadUpdatesCrcForDeflatedEntry() throws Exception {
                                                                                                               // Setup
                                                                                                               byte[] testData = "Test data for CRC check".getBytes();
                                                                                                               byte[] buffer = new byte[1024];
                                                                                                               
                                                                                                               // Mock the input stream to return test data
                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                               when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                   byte[] buf = (byte[]) invocation.getArguments()[0];
                                                                                                                   System.arraycopy(testData, 0, buf, 0, testData.length);
                                                                                                                   return testData.length;
                                                                                                               });
                                                                                                               
                                                                                                               // Create ZIP input stream with our mock
                                                                                                               ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                               
                                                                                                               // Mock the inflater to return test data length
                                                                                                               Inflater mockInf = mock(Inflater.class);
                                                                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                                   .thenReturn(testData.length);
                                                                                                               when(mockInf.finished()).thenReturn(false);
                                                                                                               when(mockInf.needsInput()).thenReturn(false);
                                                                                                               
                                                                                                               // Use reflection to inject our mock inflater
                                                                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                               infField.setAccessible(true);
                                                                                                               infField.set(zis, mockInf);
                                                                                                               
                                                                                                               // Create a mock entry with DEFLATED compression
                                                                                                               ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                                               when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                                               
                                                                                                               // Inject the entry into the stream
                                                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                               currentField.setAccessible(true);
                                                                                                               currentField.set(zis, entry);
                                                                                                               
                                                                                                               // Get the CRC object to verify it gets updated
                                                                                                               Field crcField = zis.getClass().getDeclaredField("crc");
                                                                                                               crcField.setAccessible(true);
                                                                                                               CRC32 crc = (CRC32) crcField.get(zis);
                                                                                                               long initialCrc = crc.getValue();
                                                                                                               
                                                                                                               // Test
                                                                                                               int read = zis.read(buffer, 0, buffer.length);
                                                                                                               
                                                                                                               // Verify
                                                                                                               assertEquals(testData.length, read);
                                                                                                               assertNotEquals("CRC should be updated", initialCrc, crc.getValue());
                                                                                                               
                                                                                                               // Clean up
                                                                                                               zis.close();
                                                                                                           }

 @Test
                                                                                                  public void testReadDeflatedEntryReturnsActualBytesRead() throws Exception {
                                                                                                      // Setup test data
                                                                                                      byte[] testData = "test data".getBytes();
                                                                                                      byte[] buffer = new byte[1024];
                                                                                                      
                                                                                                      // Mock dependencies
                                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                                      Inflater mockInf = mock(Inflater.class);
                                                                                                      ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                      entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                      
                                                                                                      // Create test instance using reflection to inject mocks
                                                                                                      ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                      
                                                                                                      // Set private fields
                                                                                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                      infField.setAccessible(true);
                                                                                                      infField.set(zis, mockInf);
                                                                                                      
                                                                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                      currentField.setAccessible(true);
                                                                                                      currentField.set(zis, entry);
                                                                                                      
                                                                                                      Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                      closedField.setAccessible(true);
                                                                                                      closedField.set(zis, false);
                                                                                                      
                                                                                                      // Mock behavior
                                                                                                      when(mockInf.finished()).thenReturn(false);
                                                                                                      when(mockInf.needsInput()).thenReturn(false);
                                                                                                      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                          .thenAnswer(invocation -> {
                                                                                                              Object[] args = invocation.getArguments();
                                                                                                              byte[] dest = (byte[]) args[0];
                                                                                                              int offset = (int) args[1];
                                                                                                              System.arraycopy(testData, 0, dest, offset, testData.length);
                                                                                                              return testData.length;
                                                                                                          });
                                                                                                      
                                                                                                      // Test
                                                                                                      int bytesRead = zis.read(buffer, 0, buffer.length);
                                                                                                      
                                                                                                      // Verify
                                                                                                      assertEquals("Should return actual bytes read", testData.length, bytesRead);
                                                                                                      byte[] actualData = new byte[testData.length];
                                                                                                      System.arraycopy(buffer, 0, actualData, 0, testData.length);
                                                                                                      assertArrayEquals("Buffer should contain test data", testData, actualData);
                                                                                                  }

 @Test
                                                                                              public void testReadCompressedEntryReturnsActualBytesRead() throws Exception {
                                                                                                  // Setup
                                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                                  Inflater mockInf = mock(Inflater.class);
                                                                                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                                  CRC32 mockCrc = mock(CRC32.class);
                                                                                                  
                                                                                                  // Create test instance using reflection since constructor is complex
                                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                                  
                                                                                                  // Set private fields via reflection
                                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                  infField.setAccessible(true);
                                                                                                  infField.set(zais, mockInf);
                                                                                                  
                                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                  currentField.setAccessible(true);
                                                                                                  currentField.set(zais, mockEntry);
                                                                                                  
                                                                                                  Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                                  crcField.setAccessible(true);
                                                                                                  crcField.set(zais, mockCrc);
                                                                                                  
                                                                                                  Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                                  closedField.setAccessible(true);
                                                                                                  closedField.set(zais, false);
                                                                                                  
                                                                                                  // Mock behavior
                                                                                                  when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED); // Not STORED
                                                                                                  when(mockInf.finished()).thenReturn(false);
                                                                                                  when(mockInf.needsInput()).thenReturn(false);
                                                                                                  
                                                                                                  // Simulate successful inflation of 5 bytes
                                                                                                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                      .thenReturn(5);
                                                                                                  
                                                                                                  // Test
                                                                                                  byte[] buffer = new byte[10];
                                                                                                  int result = zais.read(buffer, 0, 10);
                                                                                                  
                                                                                                  // Verify
                                                                                                  assertEquals("Should return actual bytes read (5)", 5, result);
                                                                                                  
                                                                                                  // Verify CRC was updated
                                                                                                  verify(mockCrc).update(buffer, 0, 5);
                                                                                              }

 @Test
                                                                                            public void testReadCompressedEntryReturnsReadCountNotStartPosition() throws Exception {
                                                                                                // Setup
                                                                                                InputStream mockInput = mock(InputStream.class);
                                                                                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                                
                                                                                                // Create a compressed entry scenario
                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                                
                                                                                                // Use reflection to set private current field
                                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                                currentField.setAccessible(true);
                                                                                                currentField.set(zis, entry);
                                                                                                
                                                                                                // Mock inflater behavior
                                                                                                Inflater inf = mock(Inflater.class);
                                                                                                when(inf.finished()).thenReturn(false);
                                                                                                when(inf.needsInput()).thenReturn(true).thenReturn(false);
                                                                                                when(inf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                                    .thenReturn(5); // return 5 bytes inflated
                                                                                                
                                                                                                // Use reflection to set private inf field
                                                                                                Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                                infField.setAccessible(true);
                                                                                                infField.set(zis, inf);
                                                                                                
                                                                                                // Use reflection to set private lengthOfLastRead field
                                                                                                Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                                                lengthField.setAccessible(true);
                                                                                                lengthField.set(zis, 10);
                                                                                                
                                                                                                // Test buffer
                                                                                                byte[] buffer = new byte[100];
                                                                                                int startPos = 20;
                                                                                                int length = 30;
                                                                                                
                                                                                                // Execute
                                                                                                int result = zis.read(buffer, startPos, length);
                                                                                                
                                                                                                // Verify
                                                                                                // The key assertion - should return inflated bytes (5), not start position (20)
                                                                                                assertEquals(5, result);
                                                                                                
                                                                                                // Additional verifications
                                                                                                verify(inf).inflate(buffer, startPos, length);
                                                                                                verify(inf, times(2)).needsInput();
                                                                                            }

 @Test
                                                                                       public void testRead_ThrowsZipExceptionWithOriginalMessage_WhenDataFormatExceptionOccurs() throws Exception {
                                                                                           // Setup
                                                                                           InputStream mockInput = mock(InputStream.class);
                                                                                           ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                           
                                                                                           // Mock current entry as not STORED to reach inflation path
                                                                                           ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                                           when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                           
                                                                                           // Use reflection to set current entry since it's private
                                                                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                           currentField.setAccessible(true);
                                                                                           currentField.set(zis, entry);
                                                                                           
                                                                                           // Mock inflater to throw DataFormatException
                                                                                           Inflater mockInf = mock(Inflater.class);
                                                                                           when(mockInf.needsInput()).thenReturn(true);
                                                                                           doThrow(new DataFormatException("Test error message")).when(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                           
                                                                                           // Use reflection to inject mock inflater since it's final
                                                                                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                           infField.setAccessible(true);
                                                                                           infField.set(zis, mockInf);
                                                                                           
                                                                                           // Prepare valid buffer
                                                                                           byte[] buffer = new byte[10];
                                                                                           
                                                                                           try {
                                                                                               // Act - should throw ZipException
                                                                                               zis.read(buffer, 0, 10);
                                                                                               fail("Expected ZipException to be thrown");
                                                                                           } catch (ZipException e) {
                                                                                               // Verify exception contains original message
                                                                                               assertEquals("Test error message", e.getMessage());
                                                                                               throw e;
                                                                                           }
                                                                                       }

 @Test(expected = ZipException.class)
                                                                                   public void testRead_ThrowsZipExceptionOnDataFormatError1() throws Exception {
                                                                                       // Setup
                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                       Inflater mockInf = mock(Inflater.class);
                                                                                       ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                       
                                                                                       // Create instance using reflection to inject mocks
                                                                                       ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                       
                                                                                       // Set required internal state
                                                                                       Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                       infField.setAccessible(true);
                                                                                       infField.set(zis, mockInf);
                                                                                       
                                                                                       Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                       currentField.setAccessible(true);
                                                                                       currentField.set(zis, mockEntry);
                                                                                       
                                                                                       Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                       closedField.setAccessible(true);
                                                                                       closedField.set(zis, false);
                                                                                       
                                                                                       // Mock behavior
                                                                                       when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                       when(mockInf.needsInput()).thenReturn(false);
                                                                                       doThrow(new DataFormatException("test")).when(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                       
                                                                                       // Test - should throw ZipException
                                                                                       byte[] buffer = new byte[10];
                                                                                       zis.read(buffer, 0, 10);
                                                                                       
                                                                                       // If we get here, test fails (expected exception not thrown)
                                                                                       fail("Expected ZipException to be thrown");
                                                                                   }

 @Test(expected = ZipException.class)
                                                                                  public void testRead_ThrowsZipExceptionOnDataFormatError2() throws Exception {
                                                                                      // Setup
                                                                                      InputStream mockInput = mock(InputStream.class);
                                                                                      ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                                      
                                                                                      // Mock the inflater to throw DataFormatException
                                                                                      Inflater mockInf = mock(Inflater.class);
                                                                                      when(mockInf.needsInput()).thenReturn(true);
                                                                                      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                          .thenThrow(new DataFormatException("Invalid data format"));
                                                                                      
                                                                                      // Use reflection to inject mock inflater since it's final
                                                                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                      infField.setAccessible(true);
                                                                                      infField.set(zis, mockInf);
                                                                                      
                                                                                      // Set necessary internal state
                                                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                      currentField.setAccessible(true);
                                                                                      currentField.set(zis, new ZipArchiveEntry("test"));
                                                                                      
                                                                                      Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                      closedField.setAccessible(true);
                                                                                      closedField.set(zis, false);
                                                                                      
                                                                                      // Create test buffer
                                                                                      byte[] buffer = new byte[1024];
                                                                                      
                                                                                      // This should throw ZipException (original) or RuntimeException (mutant)
                                                                                      zis.read(buffer, 0, 1024);
                                                                                  }

 @Test
                                                                                 public void testReadWithNegativeInflateResult1() throws Exception {
                                                                                     // Setup
                                                                                     InputStream mockInput = mock(InputStream.class);
                                                                                     Inflater mockInf = mock(Inflater.class);
                                                                                     ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                     entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                     
                                                                                     // Create test instance using reflection to inject mocks
                                                                                     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                     
                                                                                     // Set internal state using reflection
                                                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                     infField.setAccessible(true);
                                                                                     infField.set(zais, mockInf);
                                                                                     
                                                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                     currentField.setAccessible(true);
                                                                                     currentField.set(zais, entry);
                                                                                     
                                                                                     Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                     bufField.setAccessible(true);
                                                                                     bufField.set(zais, new byte[1024]);
                                                                                     
                                                                                     // Mock behavior
                                                                                     when(mockInf.needsInput()).thenReturn(true);
                                                                                     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                                                         .thenReturn(-1); // Simulate error case
                                                                                     
                                                                                     // Test buffer
                                                                                     byte[] buffer = new byte[1024];
                                                                                     
                                                                                     try {
                                                                                         // This should throw IOException for original code, but mutant would treat -1 same as 0
                                                                                         zais.read(buffer, 0, 100);
                                                                                         fail("Expected IOException not thrown");
                                                                                     } catch (IOException e) {
                                                                                         // Original code should throw IOException for negative inflate result
                                                                                         assertEquals("Truncated ZIP file", e.getMessage());
                                                                                     }
                                                                                     
                                                                                     // Verify interactions
                                                                                     verify(mockInf).needsInput();
                                                                                     verify(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                 }

 @Test
                                                                                public void testReadWithZeroInflateResult() throws Exception {
                                                                                    // Setup
                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                    Inflater mockInf = mock(Inflater.class);
                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                    entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                                                    
                                                                                    // Create test instance using reflection to inject mocks
                                                                                    ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                    
                                                                                    // Set internal state
                                                                                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                    infField.setAccessible(true);
                                                                                    infField.set(zais, mockInf);
                                                                                    
                                                                                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                    currentField.setAccessible(true);
                                                                                    currentField.set(zais, entry);
                                                                                    
                                                                                    Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
                                                                                    bufField.setAccessible(true);
                                                                                    bufField.set(zais, new byte[1024]);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(mockInf.needsInput()).thenReturn(true);
                                                                                    when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                    when(mockInf.finished()).thenReturn(true);
                                                                                    
                                                                                    // Test buffer
                                                                                    byte[] buffer = new byte[1024];
                                                                                    
                                                                                    // Test - should return -1 when inflate returns 0 and finished
                                                                                    int result = zais.read(buffer, 0, 1024);
                                                                                    
                                                                                    // Verify - this will catch the mutant
                                                                                    assertEquals(-1, result);
                                                                                    
                                                                                    // Verify inflate was called
                                                                                    verify(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                                                                                    verify(mockInf).finished();
                                                                                }

 @Test
                                                                               public void testRead_NonZeroInflate_ShouldReturnBytesRead() throws Exception {
                                                                                   // Setup
                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                   Inflater mockInf = mock(Inflater.class);
                                                                                   CRC32 mockCrc = mock(CRC32.class);
                                                                                   ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                   
                                                                                   ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                   
                                                                                   // Use reflection to inject mocks since fields are private
                                                                                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                   infField.setAccessible(true);
                                                                                   infField.set(zais, mockInf);
                                                                                   
                                                                                   Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                   crcField.setAccessible(true);
                                                                                   crcField.set(zais, mockCrc);
                                                                                   
                                                                                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                   currentField.setAccessible(true);
                                                                                   currentField.set(zais, mockEntry);
                                                                                   
                                                                                   Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                   closedField.setAccessible(true);
                                                                                   closedField.set(zais, false);
                                                                                   
                                                                                   // Configure mocks
                                                                                   when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                   when(mockInf.needsInput()).thenReturn(false);
                                                                                   when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // return 5 bytes
                                                                                   
                                                                                   // Test
                                                                                   byte[] buffer = new byte[10];
                                                                                   int result = zais.read(buffer, 0, 10);
                                                                                   
                                                                                   // Verify
                                                                                   assertEquals(5, result); // Should return the 5 bytes read
                                                                                   verify(mockCrc).update(buffer, 0, 5); // Should update CRC with the 5 bytes
                                                                                   
                                                                                   // Clean up
                                                                                   infField.setAccessible(false);
                                                                                   crcField.setAccessible(false);
                                                                                   currentField.setAccessible(false);
                                                                                   closedField.setAccessible(false);
                                                                               }

 @Test
                                                                              public void testRead_DeflatedEntry_ShouldNotReturnNegativeOneWhenInflaterNotFinished() throws Exception {
                                                                                  // Setup
                                                                                  InputStream mockInput = mock(InputStream.class);
                                                                                  Inflater mockInf = mock(Inflater.class);
                                                                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                  CRC32 mockCrc = mock(CRC32.class);
                                                                                  
                                                                                  // Create test instance using reflection since constructor is complex
                                                                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                                  
                                                                                  // Set internal state via reflection
                                                                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                  infField.setAccessible(true);
                                                                                  infField.set(zais, mockInf);
                                                                                  
                                                                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                  currentField.setAccessible(true);
                                                                                  currentField.set(zais, mockEntry);
                                                                                  
                                                                                  Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                  crcField.setAccessible(true);
                                                                                  crcField.set(zais, mockCrc);
                                                                                  
                                                                                  Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                  closedField.setAccessible(true);
                                                                                  closedField.set(zais, false);
                                                                                  
                                                                                  // Mock behavior
                                                                                  when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                  when(mockInf.finished()).thenReturn(false);
                                                                                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // return 5 bytes read
                                                                                  
                                                                                  // Test
                                                                                  byte[] buffer = new byte[10];
                                                                                  int result = zais.read(buffer, 0, 10);
                                                                                  
                                                                                  // Verify
                                                                                  assertEquals("Should return number of bytes read (5)", 5, result);
                                                                                  verify(mockInf).inflate(buffer, 0, 10);
                                                                                  verify(mockCrc).update(buffer, 0, 5);
                                                                                  
                                                                                  // This test would fail with the mutant since it would see read=5 and return -1 incorrectly
                                                                              }

 @Test
                                                                             public void testRead_ShouldReturnMinusOneWhenInflaterFinished() throws Exception {
                                                                                 // Setup
                                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                                 Inflater mockInflater = mock(Inflater.class);
                                                                                 ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                                 CRC32 mockCrc = mock(CRC32.class);
                                                                                 
                                                                                 // Create test instance using reflection to inject mocks
                                                                                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                                 
                                                                                 // Set private fields
                                                                                 Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                                 infField.setAccessible(true);
                                                                                 infField.set(zais, mockInflater);
                                                                                 
                                                                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                 currentField.setAccessible(true);
                                                                                 currentField.set(zais, mockEntry);
                                                                                 
                                                                                 Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                                 crcField.setAccessible(true);
                                                                                 crcField.set(zais, mockCrc);
                                                                                 
                                                                                 Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                 closedField.setAccessible(true);
                                                                                 closedField.set(zais, false);
                                                                                 
                                                                                 // Mock behavior
                                                                                 when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                                 when(mockInflater.finished()).thenReturn(true);
                                                                                 when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                                 
                                                                                 // Test
                                                                                 byte[] buffer = new byte[10];
                                                                                 int result = zais.read(buffer, 0, 10);
                                                                                 
                                                                                 // Verify
                                                                                 assertEquals("Should return -1 when inflater is finished", -1, result);
                                                                                 
                                                                                 // Clean up (if needed)
                                                                                 infField.setAccessible(false);
                                                                                 currentField.setAccessible(false);
                                                                                 crcField.setAccessible(false);
                                                                                 closedField.setAccessible(false);
                                                                             }

 @Test
                                                                            public void testRead_StoredEntry_WhenReadBytesExceedEntrySize_ShouldReturnMinusOne() throws Exception {
                                                                                // Setup
                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                ZipArchiveEntry storedEntry = mock(ZipArchiveEntry.class);
                                                                                when(storedEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                                                                                when(storedEntry.getSize()).thenReturn(100L); // Entry size 100 bytes
                                                                                
                                                                                ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInputStream);
                                                                                
                                                                                // Use reflection to set private fields since we need to test internal state
                                                                                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                                currentField.setAccessible(true);
                                                                                currentField.set(zis, storedEntry);
                                                                                
                                                                                Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                                readBytesField.setAccessible(true);
                                                                                readBytesField.set(zis, 100); // Already read all bytes
                                                                                
                                                                                Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                                closedField.setAccessible(true);
                                                                                closedField.set(zis, false);
                                                                                
                                                                                // Test buffer
                                                                                byte[] buffer = new byte[1024];
                                                                                
                                                                                // Execute
                                                                                int result = zis.read(buffer, 0, 100);
                                                                                
                                                                                // Verify
                                                                                assertEquals("Should return -1 when readBytesOfEntry >= entry size", -1, result);
                                                                                
                                                                                // Clean up reflection access
                                                                                currentField.setAccessible(false);
                                                                                readBytesField.setAccessible(false);
                                                                                closedField.setAccessible(false);
                                                                            }

 @Test
                                                                           public void testReadStoredEntryWhenAllBytesRead1() throws Exception {
                                                                               // Setup
                                                                               InputStream mockInput = mock(InputStream.class);
                                                                               ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                                               
                                                                               // Create a stored entry with size 100
                                                                               ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                               entry.setMethod(ZipArchiveOutputStream.STORED);
                                                                               entry.setSize(100);
                                                                               entry.setCompressedSize(100);
                                                                               
                                                                               // Use reflection to set private fields since we need to simulate partial read state
                                                                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                               currentField.setAccessible(true);
                                                                               currentField.set(zis, entry);
                                                                               
                                                                               Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                                                                               readBytesField.setAccessible(true);
                                                                               readBytesField.set(zis, 100); // Simulate having read all bytes
                                                                               
                                                                               // Prepare buffer
                                                                               byte[] buffer = new byte[1024];
                                                                               
                                                                               // Test - should return -1 when all bytes read
                                                                               int result = zis.read(buffer, 0, 100);
                                                                               
                                                                               // Verify
                                                                               assertEquals("Should return -1 when all bytes of stored entry are read", -1, result);
                                                                               
                                                                               // Clean up reflection access
                                                                               currentField.setAccessible(false);
                                                                               readBytesField.setAccessible(false);
                                                                           }

 @Test
                                                                         public void testRead_DeflatedEntryWithZeroLengthRead_ShouldNotThrowException() throws Exception {
                                                                             // Setup
                                                                             ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                             
                                                                             // Use reflection to set private fields
                                                                             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                             currentField.setAccessible(true);
                                                                             ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                             entry.setMethod(ZipArchiveOutputStream.DEFLATED); // Not STORED
                                                                             currentField.set(zais, entry);
                                                                             
                                                                             Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                                                             closedField.setAccessible(true);
                                                                             closedField.set(zais, false);
                                                                             
                                                                             Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                             lengthOfLastReadField.setAccessible(true);
                                                                             lengthOfLastReadField.set(zais, 0); // Critical value - should not trigger exception
                                                                             
                                                                             // Mock inflater to return 0 (needs more input)
                                                                             Inflater inf = mock(Inflater.class);
                                                                             when(inf.finished()).thenReturn(false);
                                                                             when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                             when(inf.needsInput()).thenReturn(true);
                                                                             
                                                                             // Use reflection to inject mock inflater since it's final
                                                                             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                             infField.setAccessible(true);
                                                                             infField.set(zais, inf);
                                                                             
                                                                             // Test
                                                                             byte[] buffer = new byte[10];
                                                                             int result = zais.read(buffer, 0, 10);
                                                                             
                                                                             // Verify
                                                                             assertEquals(-1, result); // Should return -1, not throw exception
                                                                             verify(inf).inflate(buffer, 0, 10);
                                                                         }

 @Test
                                                                     public void testRead_ShouldNotThrowWhenInflateReturnsZeroButStreamNotFinished() throws Exception {
                                                                         // Setup
                                                                         InputStream mockInput = mock(InputStream.class);
                                                                         Inflater mockInf = mock(Inflater.class);
                                                                         ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                         CRC32 mockCrc = mock(CRC32.class);
                                                                         
                                                                         // Create test instance using reflection to inject mocks
                                                                         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                                         Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                         infField.setAccessible(true);
                                                                         infField.set(zais, mockInf);
                                                                         
                                                                         Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                         currentField.setAccessible(true);
                                                                         currentField.set(zais, mockEntry);
                                                                         
                                                                         Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                         crcField.setAccessible(true);
                                                                         crcField.set(zais, mockCrc);
                                                                         
                                                                         Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                         lengthOfLastReadField.setAccessible(true);
                                                                         lengthOfLastReadField.set(zais, 10); // Not -1
                                                                         
                                                                         // Mock behavior
                                                                         when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                         when(mockInf.needsInput()).thenReturn(true);
                                                                         when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                         when(mockInf.finished()).thenReturn(false);
                                                                         
                                                                         // Test - should not throw exception
                                                                         byte[] buffer = new byte[100];
                                                                         int result = zais.read(buffer, 0, 100);
                                                                         
                                                                         // Verify
                                                                         assertEquals(-1, result); // Expected behavior when inflate returns 0 but not finished
                                                                         verify(mockInf).inflate(buffer, 0, 100);
                                                                         verify(mockCrc, never()).update(any(byte[].class), anyInt(), anyInt());
                                                                     }

 @Test(expected = IOException.class)
                                                                    public void testRead_ThrowsIOExceptionWithCorrectMessage_WhenZipFileIsTruncated() throws Exception {
                                                                        // Setup
                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                        Inflater mockInflater = mock(Inflater.class);
                                                                        ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                        
                                                                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                        
                                                                        // Use reflection to set private fields since we need to control test conditions
                                                                        Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                        infField.setAccessible(true);
                                                                        infField.set(zais, mockInflater);
                                                                        
                                                                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                        currentField.setAccessible(true);
                                                                        currentField.set(zais, mockEntry);
                                                                        
                                                                        Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                        lengthOfLastReadField.setAccessible(true);
                                                                        lengthOfLastReadField.set(zais, -1);
                                                                        
                                                                        // Mock behavior
                                                                        when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                        when(mockInflater.needsInput()).thenReturn(false);
                                                                        when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                        when(mockInflater.finished()).thenReturn(false);
                                                                        
                                                                        // Test
                                                                        try {
                                                                            zais.read(new byte[1024], 0, 1024);
                                                                            fail("Expected IOException to be thrown");
                                                                        } catch (IOException e) {
                                                                            assertEquals("Truncated ZIP file", e.getMessage());
                                                                            throw e;
                                                                        }
                                                                    }

 @Test(expected = IOException.class)
                                                                   public void testRead_ThrowsIOExceptionWhenTruncatedZipFile() throws Exception {
                                                                       // Setup
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       Inflater mockInflater = mock(Inflater.class);
                                                                       ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                                       
                                                                       // Create instance using reflection since constructor may need adjustment
                                                                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                                                       
                                                                       // Set internal state using reflection
                                                                       Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                       infField.setAccessible(true);
                                                                       infField.set(zais, mockInflater);
                                                                       
                                                                       Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                       currentField.setAccessible(true);
                                                                       currentField.set(zais, mockEntry);
                                                                       
                                                                       Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                       lengthOfLastReadField.setAccessible(true);
                                                                       lengthOfLastReadField.set(zais, -1);
                                                                       
                                                                       // Mock behavior
                                                                       when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                       when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                                                                       when(mockInflater.finished()).thenReturn(false);
                                                                       
                                                                       // Trigger the test - should throw IOException
                                                                       byte[] buffer = new byte[1024];
                                                                       zais.read(buffer, 0, buffer.length);
                                                                       
                                                                       // If we get here, the test failed (no exception thrown)
                                                                       fail("Expected IOException for truncated ZIP file");
                                                                   }

 @Test(expected = IOException.class)
                                                                  public void testRead_ThrowsIOExceptionWhenTruncatedZipFile1() throws Exception {
                                                                      // Setup test data
                                                                      byte[] buffer = new byte[1024];
                                                                      int start = 0;
                                                                      int length = 512;
                                                                      
                                                                      // Create mock objects
                                                                      ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                      Inflater inf = mock(Inflater.class);
                                                                      InputStream in = mock(InputStream.class);
                                                                      CRC32 crc = mock(CRC32.class);
                                                                      
                                                                      // Create instance and set internal state through reflection
                                                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(in);
                                                                      
                                                                      // Set internal fields
                                                                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                      currentField.setAccessible(true);
                                                                      currentField.set(zais, entry);
                                                                      
                                                                      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                      infField.setAccessible(true);
                                                                      infField.set(zais, inf);
                                                                      
                                                                      Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                      crcField.setAccessible(true);
                                                                      crcField.set(zais, crc);
                                                                      
                                                                      Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                                      lengthOfLastReadField.setAccessible(true);
                                                                      lengthOfLastReadField.set(zais, -1);
                                                                      
                                                                      // Mock behavior
                                                                      when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                      when(inf.inflate(buffer, start, length)).thenReturn(0);
                                                                      when(inf.finished()).thenReturn(false);
                                                                      
                                                                      // Execute test - should throw IOException for truncated file
                                                                      zais.read(buffer, start, length);
                                                                      
                                                                      // Verify interactions
                                                                      verify(inf).inflate(buffer, start, length);
                                                                      verify(inf).finished();
                                                                  }

 @Test
                                                                public void testReadUpdatesCrcWithCorrectBufferPosition() throws Exception {
                                                                    // Setup test data with start > 0
                                                                    byte[] testBuffer = new byte[100];
                                                                    java.util.Arrays.fill(testBuffer, (byte)1); // Fill with known values
                                                                    int start = 10;
                                                                    int length = 20;
                                                                    
                                                                    // Mock dependencies
                                                                    ZipArchiveInputStream zis = new ZipArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
                                                                    ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                                                                    when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                                    
                                                                    // Use reflection to set private fields since we need to test internal behavior
                                                                    java.lang.reflect.Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                                    currentField.setAccessible(true);
                                                                    currentField.set(zis, entry);
                                                                    
                                                                    java.lang.reflect.Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                                    infField.setAccessible(true);
                                                                    java.util.zip.Inflater inf = mock(java.util.zip.Inflater.class);
                                                                    when(inf.needsInput()).thenReturn(true);
                                                                    when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(length);
                                                                    infField.set(zis, inf);
                                                                    
                                                                    java.lang.reflect.Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                                    crcField.setAccessible(true);
                                                                    java.util.zip.CRC32 crc = mock(java.util.zip.CRC32.class);
                                                                    crcField.set(zis, crc);
                                                                    
                                                                    // Execute the read operation
                                                                    zis.read(testBuffer, start, length);
                                                                    
                                                                    // Verify CRC was updated with correct buffer positions
                                                                    verify(crc).update(testBuffer, start, length);
                                                                    
                                                                    // Additional verification to ensure test would fail with mutant
                                                                    verify(crc, never()).update(testBuffer, 0, length);
                                                                }

 @Test
                                                           public void testReadUpdatesCrcWithCorrectLength1() throws Exception {
                                                               // Arrange
                                                               byte[] buffer = new byte[100];
                                                               int testReadLength = 42;
                                                               
                                                               // Create mock objects
                                                               Inflater mockInf = mock(Inflater.class);
                                                               InputStream mockIn = mock(InputStream.class);
                                                               CRC32 mockCrc = mock(CRC32.class);
                                                               
                                                               // Create the object under test
                                                               ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                               
                                                               // Use reflection to inject the mock dependencies
                                                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                               infField.setAccessible(true);
                                                               infField.set(zais, mockInf);
                                                               
                                                               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                               crcField.setAccessible(true);
                                                               crcField.set(zais, mockCrc);
                                                               
                                                               // Mock inflater to return some bytes
                                                               when(mockInf.needsInput()).thenReturn(true);
                                                               when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(testReadLength);
                                                               when(mockIn.read(any(byte[].class))).thenReturn(100); // some dummy value
                                                               
                                                               // Act
                                                               int result = zais.read(buffer, 0, buffer.length);
                                                               
                                                               // Assert
                                                               assertEquals(testReadLength, result);
                                                               // Verify CRC was updated with the actual read length, not 0
                                                               verify(mockCrc).update(buffer, 0, testReadLength);
                                                           }

 @Test
                                                       public void testReadUpdatesCrcWithCorrectLength2() throws Exception {
                                                           // Setup test data - buffer larger than what we'll read
                                                           byte[] buffer = new byte[100];
                                                           int start = 0;
                                                           int length = 50; // will read less than buffer length
                                                           
                                                           // Mock dependencies
                                                           InputStream mockIn = mock(InputStream.class);
                                                           Inflater mockInf = mock(Inflater.class);
                                                           ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                                           CRC32 mockCrc = mock(CRC32.class);
                                                           
                                                           // Create test instance using reflection to inject mocks
                                                           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockIn);
                                                           
                                                           // Set up internal state
                                                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                           infField.setAccessible(true);
                                                           infField.set(zais, mockInf);
                                                           
                                                           Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                           crcField.setAccessible(true);
                                                           crcField.set(zais, mockCrc);
                                                           
                                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                           currentField.setAccessible(true);
                                                           currentField.set(zais, mockEntry);
                                                           
                                                           // Configure mocks
                                                           when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                                           when(mockInf.inflate(buffer, start, length)).thenReturn(30); // return less than length
                                                           
                                                           // Execute
                                                           int result = zais.read(buffer, start, length);
                                                           
                                                           // Verify
                                                           assertEquals(30, result);
                                                           // Verify CRC was updated with actual read bytes (30), not buffer length (100)
                                                           verify(mockCrc).update(buffer, start, 30);
                                                           verify(mockCrc, never()).update(buffer, start, buffer.length);
                                                       }

 @Test
                                                 public void testReadUpdatesCrcChecksum() throws Exception {
                                                     // Setup test data
                                                     byte[] testData = "Test data for CRC check".getBytes();
                                                     byte[] buffer = new byte[testData.length];
                                                     
                                                     // Mock dependencies
                                                     InputStream mockInput = mock(InputStream.class);
                                                     when(mockInput.read(any(byte[].class))).thenAnswer(invocation -> {
                                                         byte[] buf = (byte[]) invocation.getArguments()[0];
                                                         System.arraycopy(testData, 0, buf, 0, testData.length);
                                                         return testData.length;
                                                     });
                                                     
                                                     ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                     entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                                                     entry.setSize(testData.length);
                                                     
                                                     // Create stream
                                                     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                                     
                                                     // Use reflection to access private fields
                                                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                                     currentField.setAccessible(true);
                                                     currentField.set(zis, entry);
                                                     
                                                     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                     infField.setAccessible(true);
                                                     infField.set(zis, new Inflater());
                                                     
                                                     Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                                                     lengthField.setAccessible(true);
                                                     lengthField.set(zis, testData.length);
                                                     
                                                     Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                                     crcField.setAccessible(true);
                                                     CRC32 crc = (CRC32) crcField.get(zis);
                                                     
                                                     // Get initial CRC value
                                                     long initialCrc = crc.getValue();
                                                     
                                                     // Perform read operation
                                                     int bytesRead = zis.read(buffer, 0, buffer.length);
                                                     
                                                     // Verify results
                                                     assertEquals(testData.length, bytesRead);
                                                     assertArrayEquals(testData, buffer);
                                                     
                                                     // This is the key assertion that will catch the mutant
                                                     assertNotEquals("CRC checksum should be updated after read", 
                                                                    initialCrc, crc.getValue());
                                                     
                                                     // Clean up
                                                     zis.close();
                                                 }

 @Test
                                            public void testReadReturnsActualBytesReadForDeflatedEntry() throws Exception {
                                                // Arrange
                                                byte[] testData = "test data".getBytes();
                                                byte[] buffer = new byte[1024];
                                                
                                                // Create mock inflater
                                                Inflater mockInf = mock(Inflater.class);
                                                
                                                // Create ZipArchiveInputStream with mock input stream
                                                InputStream mockInput = new ByteArrayInputStream(testData);
                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                                
                                                // Use reflection to inject mock inflater since it's likely a private field
                                                Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                inflaterField.setAccessible(true);
                                                inflaterField.set(zais, mockInf);
                                                
                                                // Mock the inflater to return 4 bytes
                                                when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                    .thenReturn(4);
                                                when(mockInf.finished()).thenReturn(false);
                                                
                                                // Act
                                                int bytesRead = zais.read(buffer, 0, buffer.length);
                                                
                                                // Assert
                                                assertEquals("Should return actual bytes read (4)", 4, bytesRead);
                                                
                                                // Verify the mutant would fail this test by returning 0 instead
                                            }

 @Test
                                            public void testReadReturnsMinusOneWhenFinished() throws Exception {
                                                // Arrange
                                                byte[] buffer = new byte[1024];
                                                InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                ZipArchiveInputStream zais = new ZipArchiveInputStream(inputStream);
                                                
                                                // Get the inflater field using reflection since it's likely private
                                                Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                                inflaterField.setAccessible(true);
                                                Inflater mockInf = mock(Inflater.class);
                                                inflaterField.set(zais, mockInf);
                                                
                                                // Mock the inflater to indicate finished
                                                when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                                    .thenReturn(0);
                                                when(mockInf.finished()).thenReturn(true);
                                                
                                                // Act
                                                int bytesRead = zais.read(buffer, 0, buffer.length);
                                                
                                                // Assert
                                                assertEquals("Should return -1 when finished", -1, bytesRead);
                                            }

 @Test
                                       public void testReadCompressedEntryReturnsReadBytesNotStartPosition() throws Exception {
                                           // Setup
                                           InputStream mockIn = mock(InputStream.class);
                                           Inflater mockInf = mock(Inflater.class);
                                           ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                           CRC32 mockCrc = mock(CRC32.class);
                                           
                                           // Create test instance using reflection since constructor is complex
                                           ZipArchiveInputStream zis = new ZipArchiveInputStream(mockIn);
                                           
                                           // Set internal state via reflection
                                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                           infField.setAccessible(true);
                                           infField.set(zis, mockInf);
                                           
                                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                           currentField.setAccessible(true);
                                           currentField.set(zis, mockEntry);
                                           
                                           Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                           closedField.setAccessible(true);
                                           closedField.set(zis, false);
                                           
                                           Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                                           crcField.setAccessible(true);
                                           crcField.set(zis, mockCrc);
                                           
                                           // Mock behavior
                                           when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                           when(mockInf.finished()).thenReturn(false);
                                           when(mockInf.needsInput()).thenReturn(false);
                                           
                                           // Setup test buffer and expected read value
                                           byte[] testBuffer = new byte[100];
                                           int expectedRead = 42; // arbitrary test value
                                           when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                               .thenReturn(expectedRead);
                                           
                                           // Test - should return inflated bytes count (42), not start position (10)
                                           int startPos = 10;
                                           int length = 50;
                                           int actualRead = zis.read(testBuffer, startPos, length);
                                           
                                           // Verify - this will catch the mutant which would return startPos (10)
                                           assertEquals("Should return number of bytes read, not start position", 
                                                       expectedRead, actualRead);
                                           
                                           // Verify CRC was updated
                                           verify(mockCrc).update(testBuffer, startPos, expectedRead);
                                       }

 @Test(expected = RuntimeException.class)
                                  public void testReadShouldNotCatchRuntimeException() throws Exception {
                                      // Arrange
                                      byte[] testBuffer = new byte[10];
                                      Inflater mockInf = mock(Inflater.class);
                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                      
                                      // Use reflection to set the private inflater field
                                      Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                      inflaterField.setAccessible(true);
                                      inflaterField.set(zais, mockInf);
                                      
                                      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                          .thenThrow(new RuntimeException("Test exception"));
                                      
                                      // Act & Assert - expecting RuntimeException to propagate
                                      zais.read(testBuffer, 0, 10);
                                  }

 @Test
                                  public void testReadShouldConvertDataFormatException() throws Exception {
                                      // Arrange
                                      InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                                      byte[] testBuffer = new byte[10];
                                      
                                      // Mock inflater using reflection since it's likely a private field
                                      Field inflaterField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                      inflaterField.setAccessible(true);
                                      Inflater mockInf = mock(Inflater.class);
                                      inflaterField.set(zais, mockInf);
                                      
                                      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                          .thenThrow(new DataFormatException("Test exception"));
                                      
                                      try {
                                          // Act
                                          zais.read(testBuffer, 0, 10);
                                          fail("Expected ZipException");
                                      } catch (ZipException e) {
                                          // Assert
                                          assertTrue(e.getMessage().contains("Test exception"));
                                      }
                                  }

 @Test(expected = ZipException.class)
                              public void testRead_ThrowsZipExceptionWithOriginalMessage_WhenDataFormatExceptionOccurs1() throws Exception {
                                  // Arrange
                                  InputStream mockInputStream = mock(InputStream.class);
                                  Inflater mockInflater = mock(Inflater.class);
                                  ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                                  
                                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                                  
                                  // Use reflection to set private fields since we need to control test conditions
                                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                  infField.setAccessible(true);
                                  infField.set(zais, mockInflater);
                                  
                                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                  currentField.setAccessible(true);
                                  currentField.set(zais, mockEntry);
                                  
                                  Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                  closedField.setAccessible(true);
                                  closedField.set(zais, false);
                                  
                                  // Set up mock behavior
                                  when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                                  when(mockInflater.needsInput()).thenReturn(false);
                                  
                                  // This will trigger the DataFormatException path
                                  String errorMessage = "Invalid compression data";
                                  when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                                      .thenThrow(new DataFormatException(errorMessage));
                                  
                                  byte[] buffer = new byte[1024];
                                  
                                  try {
                                      // Act
                                      zais.read(buffer, 0, buffer.length);
                                  } catch (ZipException e) {
                                      // Assert
                                      assertEquals("Exception message should contain original error", 
                                                  errorMessage, e.getMessage());
                                      throw e;
                                  }
                              }

 @Test(expected = ZipException.class)
                             public void testRead_ThrowsZipExceptionOnDataFormatError3() throws Exception {
                                 // Setup
                                 InputStream mockInput = mock(InputStream.class);
                                 ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                                 
                                 // Mock the inflater to throw DataFormatException
                                 Inflater mockInf = mock(Inflater.class);
                                 when(mockInf.needsInput()).thenReturn(true);
                                 when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
                                     .thenThrow(new DataFormatException("Invalid data format"));
                                 
                                 // Use reflection to inject mock inflater since it's final
                                 Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                                 infField.setAccessible(true);
                                 infField.set(zis, mockInf);
                                 
                                 // Set up other required internal state
                                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                                 currentField.setAccessible(true);
                                 currentField.set(zis, new ZipArchiveEntry("test"));
                                 
                                 Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                                 closedField.setAccessible(true);
                                 closedField.set(zis, false);
                                 
                                 // Create test buffer
                                 byte[] buffer = new byte[1024];
                                 
                                 // This should throw ZipException (original) or IOException (mutant)
                                 zis.read(buffer, 0, 1024);
                             }

 @Test
                           public void testRead_ThrowsZipExceptionOnDataFormatError4() throws Exception {
                               // Setup
                               InputStream mockInput = mock(InputStream.class);
                               ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                               
                               // Mock current entry to be non-STORED method
                               ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                               when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                               
                               // Use reflection to set current entry since it's private
                               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                               currentField.setAccessible(true);
                               currentField.set(zis, mockEntry);
                               
                               // Mock inflater to throw DataFormatException
                               Inflater mockInf = mock(Inflater.class);
                               when(mockInf.finished()).thenReturn(false);
                               when(mockInf.needsInput()).thenReturn(true);
                               doThrow(new DataFormatException("test")).when(mockInf).inflate(any(byte[].class), anyInt(), anyInt());
                               
                               // Use reflection to inject mock inflater since it's final
                               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                               infField.setAccessible(true);
                               infField.set(zis, mockInf);
                               
                               // Prepare valid buffer
                               byte[] buffer = new byte[10];
                               
                               // Act - should throw ZipException
                               zis.read(buffer, 0, 10);
                           }

 @Test
                       public void testReadWithNegativeInflateResult2() throws Exception {
                           // Setup
                           InputStream mockInput = mock(InputStream.class);
                           Inflater mockInf = mock(Inflater.class);
                           ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                           CRC32 mockCrc = mock(CRC32.class);
                           
                           // Create test instance using reflection since constructor is complex
                           ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                           
                           // Set private fields using reflection
                           Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                           infField.setAccessible(true);
                           infField.set(zais, mockInf);
                           
                           Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                           crcField.setAccessible(true);
                           crcField.set(zais, mockCrc);
                           
                           Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                           currentField.setAccessible(true);
                           currentField.set(zais, mockEntry);
                           
                           Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                           lengthOfLastReadField.setAccessible(true);
                           lengthOfLastReadField.set(zais, 1); // Not -1 initially
                           
                           // Mock behavior
                           when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                           when(mockInf.needsInput()).thenReturn(false);
                           when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                           
                           // Test
                           byte[] buffer = new byte[10];
                           int result = zais.read(buffer, 0, 10);
                           
                           // Verify
                           assertEquals("Should return -1 for negative inflate result", -1, result);
                           verify(mockCrc, never()).update(any(byte[].class), anyInt(), anyInt());
                       }

 @Test
                      public void testReadWithZeroInflateResult1() throws Exception {
                          // Setup
                          InputStream mockInput = mock(InputStream.class);
                          Inflater mockInf = mock(Inflater.class);
                          ZipArchiveEntry entry = new ZipArchiveEntry("test");
                          entry.setMethod(ZipArchiveOutputStream.DEFLATED);
                          
                          // Create test instance using reflection to inject mocks
                          ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                          Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                          infField.setAccessible(true);
                          infField.set(zais, mockInf);
                          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                          currentField.setAccessible(true);
                          currentField.set(zais, entry);
                          
                          // Test buffer
                          byte[] buffer = new byte[10];
                          
                          // Case 1: inflation finished (should return -1)
                          when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                          when(mockInf.finished()).thenReturn(true);
                          assertEquals(-1, zais.read(buffer, 0, 10));
                          
                          // Case 2: truncated input (should throw IOException)
                          when(mockInf.finished()).thenReturn(false);
                          Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                          lengthField.setAccessible(true);
                          lengthField.set(zais, -1);
                          try {
                              zais.read(buffer, 0, 10);
                              fail("Expected IOException for truncated input");
                          } catch (IOException e) {
                              assertEquals("Truncated ZIP file", e.getMessage());
                          }
                          
                          // Verify interactions
                          verify(mockInf, atLeastOnce()).inflate(buffer, 0, 10);
                      }

 @Test
                     public void testReadWithNonZeroInflateShouldNotReturnMinusOne() throws Exception {
                         // Setup
                         InputStream mockInputStream = mock(InputStream.class);
                         Inflater mockInflater = mock(Inflater.class);
                         ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                         CRC32 mockCrc = mock(CRC32.class);
                         
                         // Create test instance using reflection to inject mocks
                         ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                         Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                         infField.setAccessible(true);
                         infField.set(zais, mockInflater);
                         
                         Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                         currentField.setAccessible(true);
                         currentField.set(zais, mockEntry);
                         
                         Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
                         crcField.setAccessible(true);
                         crcField.set(zais, mockCrc);
                         
                         Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                         closedField.setAccessible(true);
                         closedField.set(zais, false);
                         
                         // Configure mocks
                         when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                         when(mockInflater.finished()).thenReturn(false);
                         when(mockInflater.needsInput()).thenReturn(false);
                         
                         // Simulate inflate returning 5 bytes
                         when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt()))
                             .thenReturn(5);
                         
                         // Test
                         byte[] buffer = new byte[10];
                         int result = zais.read(buffer, 0, 10);
                         
                         // Verify
                         assertEquals("Should return the number of bytes read", 5, result);
                         verify(mockCrc).update(buffer, 0, 5);
                         
                         // The mutant would incorrectly return -1 or throw exception here
                         // Original code should properly return the 5 bytes read
                     }

 @Test
                    public void testRead_ShouldNotReturnNegativeOneWhenInflaterNotFinished() throws Exception {
                        // Setup
                        InputStream mockInputStream = mock(InputStream.class);
                        Inflater mockInflater = mock(Inflater.class);
                        ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                        
                        // Create test instance using reflection since constructor is complex
                        ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                        
                        // Set up internal state via reflection
                        Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                        infField.setAccessible(true);
                        infField.set(zais, mockInflater);
                        
                        Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                        currentField.setAccessible(true);
                        currentField.set(zais, mockEntry);
                        
                        Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                        closedField.setAccessible(true);
                        closedField.set(zais, false);
                        
                        // Mock behavior
                        when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                        when(mockInflater.finished()).thenReturn(false);
                        when(mockInflater.needsInput()).thenReturn(false);
                        
                        // This is the key part - mock inflate to return -1
                        when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(-1);
                        
                        // Test
                        byte[] buffer = new byte[10];
                        int result = zais.read(buffer, 0, 10);
                        
                        // Verify
                        // Original would throw IOException, mutant would return -1
                        // We expect either normal behavior or exception, but not -1
                        assertNotEquals("Method should not return -1 when inflater returns -1 but isn't finished", 
                                       -1, result);
                        
                        // Alternative verification that would catch the mutant:
                        try {
                            zais.read(buffer, 0, 10);
                            fail("Should have thrown IOException when inflate returns -1");
                        } catch (IOException e) {
                            // Expected behavior
                            assertTrue(e.getMessage().contains("Truncated ZIP file"));
                        }
                    }

 @Test
                   public void testReadReturnsMinusOneWhenInflaterFinished() throws Exception {
                       // Setup
                       InputStream mockInput = mock(InputStream.class);
                       Inflater mockInf = mock(Inflater.class);
                       ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                       
                       // Create test instance using reflection to inject mocks
                       ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                       
                       // Set up mocks and internal state
                       when(mockInf.finished()).thenReturn(true);  // Critical for this test
                       when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                       
                       // Use reflection to set private fields
                       Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                       infField.setAccessible(true);
                       infField.set(zais, mockInf);
                       
                       Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                       currentField.setAccessible(true);
                       currentField.set(zais, mockEntry);
                       
                       Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                       closedField.setAccessible(true);
                       closedField.set(zais, false);
                       
                       // Test buffer
                       byte[] buffer = new byte[10];
                       
                       // Execute and verify
                       int result = zais.read(buffer, 0, 10);
                       
                       // Original should return -1 when inflater is finished
                       // Mutant would continue execution and potentially return wrong value
                       assertEquals("Should return -1 when inflater is finished", -1, result);
                       
                       // Verify inflater.finished() was called (wouldn't be in mutant)
                       verify(mockInf).finished();
                   }

 @Test
                  public void testReadStoredEntry_WhenAllBytesRead_ShouldReturnMinusOne() throws Exception {
                      // Setup
                      InputStream mockInputStream = mock(InputStream.class);
                      ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                      
                      ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                      
                      // Use reflection to set private fields since we need to test internal state
                      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                      currentField.setAccessible(true);
                      currentField.set(zais, mockEntry);
                      
                      Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                      readBytesField.setAccessible(true);
                      readBytesField.set(zais, 100); // Already read all bytes
                      
                      Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                      closedField.setAccessible(true);
                      closedField.set(zais, false);
                      
                      // Configure mocks
                      when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.STORED);
                      when(mockEntry.getSize()).thenReturn(100L); // csize = 100
                      
                      byte[] buffer = new byte[10];
                      
                      // Test - should return -1 when all bytes read
                      int result = zais.read(buffer, 0, 10);
                      
                      // Verify
                      assertEquals("Should return -1 when all bytes of STORED entry are read", -1, result);
                      
                      // Clean up reflection access
                      currentField.setAccessible(false);
                      readBytesField.setAccessible(false);
                      closedField.setAccessible(false);
                  }

 @Test
                 public void testReadStoredMethodWhenEntryFullyRead1() throws Exception {
                     // Setup
                     InputStream mockInput = mock(InputStream.class);
                     ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
                     
                     // Create a stored entry with size 100
                     ZipArchiveEntry entry = new ZipArchiveEntry("test");
                     entry.setMethod(ZipArchiveOutputStream.STORED);
                     entry.setSize(100);
                     entry.setCompressedSize(100);
                     
                     // Use reflection to set private fields since we can't access them directly
                     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                     currentField.setAccessible(true);
                     currentField.set(zis, entry);
                     
                     Field readBytesField = ZipArchiveInputStream.class.getDeclaredField("readBytesOfEntry");
                     readBytesField.setAccessible(true);
                     readBytesField.set(zis, 100); // Fully read
                     
                     Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                     closedField.setAccessible(true);
                     closedField.set(zis, false);
                     
                     // Prepare buffer
                     byte[] buffer = new byte[10];
                     
                     // Test - should return -1 when fully read
                     int result = zis.read(buffer, 0, 10);
                     
                     // Verify
                     assertEquals("Should return -1 when entry is fully read", -1, result);
                     
                     // Clean up
                     currentField.setAccessible(false);
                     readBytesField.setAccessible(false);
                     closedField.setAccessible(false);
                 }

 @Test
                public void testRead_ShouldNotThrowExceptionWhenLengthOfLastReadIsZero() throws Exception {
                    // Setup
                    ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                    
                    // Mock necessary internal state
                    Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                    infField.setAccessible(true);
                    Inflater inf = mock(Inflater.class);
                    infField.set(zais, inf);
                    
                    Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                    currentField.setAccessible(true);
                    currentField.set(zais, new ZipArchiveEntry("test"));
                    
                    Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                    lengthOfLastReadField.setAccessible(true);
                    lengthOfLastReadField.set(zais, 0); // Critical value for this test
                    
                    // Mock inflater behavior
                    when(inf.finished()).thenReturn(false);
                    when(inf.needsInput()).thenReturn(false);
                    when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                    
                    // Test
                    byte[] buffer = new byte[10];
                    int result = zais.read(buffer, 0, 10);
                    
                    // Verify
                    assertEquals(-1, result); // Should return -1, not throw exception
                    
                    // Additional verification that no exception was thrown
                    verify(inf, times(1)).inflate(any(byte[].class), anyInt(), anyInt());
                }

 @Test
               public void testRead_DeflatedEntry_NoProgressButNotEOF_ShouldNotThrow() throws Exception {
                   // Setup
                   ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                   byte[] buffer = new byte[1024];
                   
                   // Mock current entry as DEFLATED (not STORED)
                   ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
                   when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                   
                   // Set field values using reflection
                   Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                   currentField.setAccessible(true);
                   currentField.set(zis, entry);
                   
                   Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                   infField.setAccessible(true);
                   Inflater inf = (Inflater) infField.get(zis);
                   
                   // Mock inflater behavior: not finished, but returns 0 bytes
                   Field needsInputField = Inflater.class.getDeclaredField("needInput");
                   needsInputField.setAccessible(true);
                   needsInputField.set(inf, false);
                   
                   Field finishedField = Inflater.class.getDeclaredField("finished");
                   finishedField.setAccessible(true);
                   finishedField.set(inf, false);
                   
                   // Set lengthOfLastRead to 0 (not -1)
                   Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                   lengthField.setAccessible(true);
                   lengthField.set(zis, 0);
                   
                   // Test - should not throw exception with original code
                   int result = zis.read(buffer, 0, 1024);
                   
                   // Verify
                   assertEquals(-1, result); // Expected to return -1, not throw exception
                   
                   // Clean up
                   zis.close();
               }

 @Test(expected = IOException.class)
              public void testRead_ThrowsIOExceptionWithCorrectMessageWhenZipFileIsTruncated() throws Exception {
                  // Setup
                  InputStream mockInputStream = mock(InputStream.class);
                  ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                  
                  // Mock the inflater to return 0 (no progress) and not be finished
                  Inflater mockInf = mock(Inflater.class);
                  when(mockInf.finished()).thenReturn(false);
                  when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                  
                  // Set lengthOfLastRead to -1 to simulate truncated file
                  Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                  infField.setAccessible(true);
                  infField.set(zais, mockInf);
                  
                  Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                  lengthField.setAccessible(true);
                  lengthField.set(zais, -1);
                  
                  // Set current entry to non-null
                  Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                  currentField.setAccessible(true);
                  currentField.set(zais, new ZipArchiveEntry("test"));
                  
                  // Set closed to false
                  Field closedField = ZipArchiveInputStream.class.getDeclaredField("closed");
                  closedField.setAccessible(true);
                  closedField.set(zais, false);
                  
                  // Test
                  try {
                      zais.read(new byte[10], 0, 10);
                  } catch (IOException e) {
                      // Verify exception message
                      assertEquals("Truncated ZIP file", e.getMessage());
                      throw e;
                  }
              }

 @Test(expected = IOException.class)
             public void testRead_ThrowsIOExceptionWhenTruncatedZipFile2() throws Exception {
                 // Setup
                 InputStream mockInputStream = mock(InputStream.class);
                 Inflater mockInflater = mock(Inflater.class);
                 ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                 
                 ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInputStream);
                 
                 // Use reflection to set private fields since we need to control test conditions
                 Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                 infField.setAccessible(true);
                 infField.set(zais, mockInflater);
                 
                 Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                 currentField.setAccessible(true);
                 currentField.set(zais, mockEntry);
                 
                 Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                 lengthOfLastReadField.setAccessible(true);
                 lengthOfLastReadField.set(zais, -1);
                 
                 // Mock behavior
                 when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                 when(mockInflater.finished()).thenReturn(false);
                 when(mockInflater.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                 
                 // Test - should throw IOException with specific message
                 try {
                     zais.read(new byte[1024], 0, 1024);
                     fail("Expected IOException to be thrown");
                 } catch (IOException e) {
                     assertEquals("Truncated ZIP file", e.getMessage());
                     throw e; // rethrow for @Test expected
                 }
             }

 @Test(expected = IOException.class)
            public void testRead_ThrowsOnTruncatedZipFile() throws Exception {
                // Setup
                InputStream mockInput = mock(InputStream.class);
                Inflater mockInf = mock(Inflater.class);
                ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
                
                // Create test instance using reflection to inject mocks
                ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
                
                // Set internal state via reflection
                Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
                infField.setAccessible(true);
                infField.set(zais, mockInf);
                
                Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
                currentField.setAccessible(true);
                currentField.set(zais, mockEntry);
                
                Field lengthOfLastReadField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
                lengthOfLastReadField.setAccessible(true);
                lengthOfLastReadField.set(zais, -1);
                
                // Mock behavior
                when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
                when(mockInf.needsInput()).thenReturn(false);
                when(mockInf.finished()).thenReturn(false);
                when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(0);
                
                // Test - should throw IOException for truncated file
                byte[] buffer = new byte[1024];
                zais.read(buffer, 0, buffer.length);
                
                // Verify mock interactions
                verify(mockInf).inflate(eq(buffer), eq(0), eq(buffer.length));
            }

 @Test
           public void testReadUpdatesCrcWithCorrectBufferPosition1() throws Exception {
               // Setup test data with non-zero start position
               byte[] testData = {1, 2, 3, 4, 5, 6, 7, 8};
               byte[] buffer = new byte[10];
               int start = 3;
               int length = 4;
               
               // Mock dependencies
               ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(testData));
               ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
               when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
               
               // Use reflection to set private fields since we need to test internal behavior
               Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
               currentField.setAccessible(true);
               currentField.set(zis, entry);
               
               Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
               infField.setAccessible(true);
               Inflater inf = mock(Inflater.class);
               when(inf.needsInput()).thenReturn(true);
               when(inf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(length);
               infField.set(zis, inf);
               
               Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
               crcField.setAccessible(true);
               CRC32 crc = mock(CRC32.class);
               crcField.set(zis, crc);
               
               // Execute read operation
               zis.read(buffer, start, length);
               
               // Verify CRC was updated with correct buffer position
               verify(crc).update(buffer, start, length);
               
               // Clean up
               currentField.setAccessible(false);
               infField.setAccessible(false);
               crcField.setAccessible(false);
           }

 @Test
          public void testReadUpdatesCrcWithCorrectByteCount1() throws Exception {
              // Setup test data
              byte[] buffer = new byte[10];
              int start = 0;
              int length = 5;
              
              // Mock dependencies
              ZipArchiveInputStream zis = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
              ZipArchiveEntry entry = mock(ZipArchiveEntry.class);
              Inflater inf = mock(Inflater.class);
              CRC32 crc = mock(CRC32.class);
              
              // Set mock behaviors using reflection since fields are private
              Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
              currentField.setAccessible(true);
              currentField.set(zis, entry);
              
              Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
              infField.setAccessible(true);
              infField.set(zis, inf);
              
              Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
              crcField.setAccessible(true);
              crcField.set(zis, crc);
              
              // Configure mocks
              when(entry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
              when(inf.inflate(buffer, start, length)).thenReturn(3); // simulate reading 3 bytes
              
              // Execute
              int result = zis.read(buffer, start, length);
              
              // Verify
              assertEquals(3, result); // verify correct read count
              verify(crc).update(buffer, start, 3); // verify CRC updated with actual read count
              // This will fail on mutant which would use 0 instead of 3
          }

 @Test
         public void testReadUpdatesCrcWithCorrectLength3() throws Exception {
             // Setup
             InputStream mockIn = mock(InputStream.class);
             Inflater mockInf = mock(Inflater.class);
             ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
             CRC32 mockCrc = mock(CRC32.class);
             
             // Create test instance using reflection to inject mocks
             ZipArchiveInputStream zis = new ZipArchiveInputStream(mockIn);
             Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
             infField.setAccessible(true);
             infField.set(zis, mockInf);
             
             Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
             crcField.setAccessible(true);
             crcField.set(zis, mockCrc);
             
             Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
             currentField.setAccessible(true);
             currentField.set(zis, mockEntry);
             
             // Configure mocks
             when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
             when(mockInf.needsInput()).thenReturn(true);
             when(mockInf.inflate(any(byte[].class), anyInt(), anyInt())).thenReturn(5); // return 5 bytes read
             
             // Test buffer - larger than read amount
             byte[] buffer = new byte[10];
             int start = 0;
             int length = 10;
             
             // Execute
             int result = zis.read(buffer, start, length);
             
             // Verify
             assertEquals(5, result); // verify correct bytes read
             // Verify CRC was updated with exactly the read bytes (5), not buffer length (10)
             verify(mockCrc).update(buffer, start, 5);
             
             // Clean up
             infField.setAccessible(false);
             crcField.setAccessible(false);
             currentField.setAccessible(false);
         }

 @Test
        public void testReadUpdatesCrcForCompressedEntry() throws Exception {
            // Setup
            InputStream mockInput = mock(InputStream.class);
            when(mockInput.read(any(byte[].class))).thenReturn(10); // Simulate reading 10 bytes
            
            ZipArchiveEntry entry = new ZipArchiveEntry("test");
            entry.setMethod(ZipArchiveOutputStream.DEFLATED); // Compressed entry
            
            ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
            
            // Use reflection to set private fields since we need to control test conditions
            Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
            currentField.setAccessible(true);
            currentField.set(zis, entry);
            
            Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
            crcField.setAccessible(true);
            CRC32 crc = (CRC32) crcField.get(zis);
            
            long initialCrcValue = crc.getValue();
            
            // Test
            byte[] buffer = new byte[100];
            int bytesRead = zis.read(buffer, 0, 20);
            
            // Verify
            assertEquals(10, bytesRead); // Verify we read expected bytes
            assertTrue(crc.getValue() != initialCrcValue); // CRC should be updated
            
            // Additional verification that CRC was updated with correct data
            // We can't verify exact value since it depends on mock input data
            // But we can verify it changed from initial value
        }

 @Test
      public void testReadDeflatedEntryReturnsActualBytesRead1() throws Exception {
          // Setup
          InputStream mockInput = mock(InputStream.class);
          ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
          
          // Set up a DEFLATED entry
          ZipArchiveEntry entry = new ZipArchiveEntry("test");
          entry.setMethod(ZipArchiveOutputStream.DEFLATED);
          
          // Use reflection to set private current field
          Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
          currentField.setAccessible(true);
          currentField.set(zis, entry);
          
          // Configure mocks
          when(mockInput.read(any(byte[].class))).thenReturn(10); // Simulate reading some data
          Inflater mockInf = mock(Inflater.class);
          
          // Use reflection to set private inf field
          Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
          infField.setAccessible(true);
          infField.set(zis, mockInf);
          
          when(mockInf.needsInput()).thenReturn(false);
          when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
              .thenReturn(5); // Simulate inflating 5 bytes
          
          // Use reflection to get private crc field for verification
          Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
          crcField.setAccessible(true);
          CRC32 mockCrc = mock(CRC32.class);
          crcField.set(zis, mockCrc);
          
          // Test buffer
          byte[] buffer = new byte[100];
          
          // Execute
          int bytesRead = zis.read(buffer, 0, 100);
          
          // Verify
          assertEquals("Should return actual bytes inflated", 5, bytesRead);
          
          // Verify CRC was updated
          verify(mockCrc).update(buffer, 0, 5);
      }

 @Test
  public void testReadWithDeflatedCompressionReturnsActualBytesRead() throws Exception {
      // Setup
      InputStream mockInput = mock(InputStream.class);
      Inflater mockInf = mock(Inflater.class);
      ZipArchiveEntry entry = new ZipArchiveEntry("test");
      entry.setMethod(ZipArchiveOutputStream.DEFLATED);
      
      // Create instance using reflection to inject mocks
      ZipArchiveInputStream zis = new ZipArchiveInputStream(mockInput);
      
      // Set private fields
      Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
      infField.setAccessible(true);
      infField.set(zis, mockInf);
      
      Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
      currentField.setAccessible(true);
      currentField.set(zis, entry);
      
      Field bufField = ZipArchiveInputStream.class.getDeclaredField("buf");
      bufField.setAccessible(true);
      bufField.set(zis, new byte[1024]);
      
      // Mock behavior
      when(mockInf.needsInput()).thenReturn(false);
      when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
          .thenReturn(5); // simulate reading 5 bytes
      
      // Test buffer
      byte[] buffer = new byte[10];
      
      // Execute
      int result = zis.read(buffer, 0, 10);
      
      // Verify
      assertEquals("Should return actual bytes read (5)", 5, result);
      
      // Clean up
      infField.setAccessible(false);
      currentField.setAccessible(false);
      bufField.setAccessible(false);
  }

 @Test
 public void testReadReturnsActualBytesReadNotStartPosition() throws Exception {
     // Setup
     InputStream mockInput = mock(InputStream.class);
     Inflater mockInf = mock(Inflater.class);
     ZipArchiveEntry mockEntry = mock(ZipArchiveEntry.class);
     CRC32 mockCrc = mock(CRC32.class);
     
     // Create test instance using reflection to inject mocks
     ZipArchiveInputStream zais = new ZipArchiveInputStream(mockInput);
     Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
     infField.setAccessible(true);
     infField.set(zais, mockInf);
     
     Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
     currentField.setAccessible(true);
     currentField.set(zais, mockEntry);
     
     Field crcField = ZipArchiveInputStream.class.getDeclaredField("crc");
     crcField.setAccessible(true);
     crcField.set(zais, mockCrc);
     
     // Configure mocks
     when(mockEntry.getMethod()).thenReturn(ZipArchiveOutputStream.DEFLATED);
     when(mockInf.needsInput()).thenReturn(false);
     
     // We want to test when inflate returns 5 bytes
     int expectedBytesRead = 5;
     when(mockInf.inflate(any(byte[].class), anyInt(), anyInt()))
         .thenReturn(expectedBytesRead);
     
     // Test parameters where start != expectedBytesRead
     byte[] buffer = new byte[100];
     int start = 10;
     int length = 20;
     
     // Execute
     int result = zais.read(buffer, start, length);
     
     // Verify
     // This assertion will catch the mutant since mutant returns start (10)
     // while original returns expectedBytesRead (5)
     assertEquals("Should return actual bytes read", expectedBytesRead, result);
     
     // Verify interactions
     verify(mockInf).inflate(buffer, start, length);
     verify(mockCrc).update(buffer, start, expectedBytesRead);
 }

}
