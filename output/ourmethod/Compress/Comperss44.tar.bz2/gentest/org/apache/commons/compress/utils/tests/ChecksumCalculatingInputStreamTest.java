package gentest.org.apache.commons.compress.utils.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Checksum;
 
public class ChecksumCalculatingInputStreamTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

       @Test
                                                                        public void testConstructor_NullChecksumThrowsException() {
                                                                            // Arrange
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            
                                                                            // Expect exception
                                                                            thrown.expect(NullPointerException.class);
                                                                            thrown.expectMessage("Parameter checksum must not be null");
                                                                            
                                                                            // Act
                                                                            new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                        }

 @Test
                                                                        public void testConstructor_NullInputStreamThrowsException() {
                                                                            // Arrange
                                                                            Checksum mockChecksum = mock(Checksum.class);
                                                                            
                                                                            // Expect exception
                                                                            thrown.expect(NullPointerException.class);
                                                                            thrown.expectMessage("Parameter in must not be null");
                                                                            
                                                                            // Act
                                                                            new ChecksumCalculatingInputStream(mockChecksum, null);
                                                                        }

 @Test
                                                                        public void testConstructor_ValidParametersInitializesFields() {
                                                                            // Arrange
                                                                            Checksum mockChecksum = mock(Checksum.class);
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            
                                                                            // Act
                                                                            ChecksumCalculatingInputStream stream = 
                                                                                new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                            
                                                                            // Assert - Verify fields are set through reflection or other means
                                                                            // Since fields are private, we'll test their effect through other methods
                                                                            // This test mainly verifies no exception is thrown with valid parameters
                                                                        }

 @Test
                                                                        public void testConstructor_ValidParametersDoesNotThrow() {
                                                                            // Arrange
                                                                            Checksum mockChecksum = mock(Checksum.class);
                                                                            InputStream mockInputStream = mock(InputStream.class);
                                                                            
                                                                            // Act (no exception expected)
                                                                            new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                            
                                                                            // No assertion needed - test passes if no exception is thrown
                                                                        }

 @Test
                                                                    public void testConstructorShouldThrowWhenChecksumIsNull() {
                                                                        // Prepare test data
                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                        Checksum nullChecksum = null;
                                                                
                                                                        // Expect exception
                                                                        thrown.expect(NullPointerException.class);
                                                                        thrown.expectMessage("Parameter checksum must not be null");
                                                                
                                                                        // Execute test - this should throw for original code but not for mutated code
                                                                        new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                                    }

 @Test
                                                                    public void testConstructorShouldThrowWhenInputStreamIsNull() {
                                                                        // Prepare test data
                                                                        Checksum mockChecksum = mock(Checksum.class);
                                                                        InputStream nullInputStream = null;
                                                                
                                                                        // Expect exception
                                                                        thrown.expect(NullPointerException.class);
                                                                        thrown.expectMessage("Parameter in must not be null");
                                                                
                                                                        // Execute test
                                                                        new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                    }

 @Test
                                                                    public void testConstructorShouldNotThrowWhenParametersAreValid() {
                                                                        // Prepare test data
                                                                        Checksum mockChecksum = mock(Checksum.class);
                                                                        InputStream mockInputStream = mock(InputStream.class);
                                                                
                                                                        // Execute test - should not throw any exception
                                                                        new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                    }

 @Test
                                                                   public void testConstructorWithValidParametersShouldNotThrowException() {
                                                                       // Prepare non-null mock objects
                                                                       Checksum mockChecksum = mock(Checksum.class);
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       
                                                                       try {
                                                                           // This should not throw an exception with original code
                                                                           // but will throw with the mutant (if (true))
                                                                           new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                           
                                                                           // If we get here, the test passes (original behavior)
                                                                       } catch (NullPointerException e) {
                                                                           // If we get here, the mutant is detected
                                                                           fail("Constructor threw NullPointerException with valid non-null parameters");
                                                                       }
                                                                   }

 @Test(expected = NullPointerException.class)
                                                                   public void testConstructorWithNullChecksumShouldThrowException() {
                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                       new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                   }

 @Test(expected = NullPointerException.class)
                                                                   public void testConstructorWithNullInputStreamShouldThrowException() {
                                                                       Checksum mockChecksum = mock(Checksum.class);
                                                                       new ChecksumCalculatingInputStream(mockChecksum, null);
                                                                   }

 @Test
                                                                  public void testConstructor_ShouldThrowNullPointerException_WhenChecksumIsNull() {
                                                                      // Prepare test data
                                                                      InputStream mockInputStream = mock(InputStream.class);
                                                                      Checksum nullChecksum = null;
                                                                      
                                                                      // Expect exception
                                                                      thrown.expect(NullPointerException.class);
                                                                      thrown.expectMessage("Parameter checksum must not be null");
                                                                      
                                                                      // Test - this should throw NPE with original code
                                                                      // but will pass with the mutant (false instead of null check)
                                                                      new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                                  }

 @Test
                                                                  public void testConstructor_ShouldThrowNullPointerException_WhenInputStreamIsNull() {
                                                                      // Prepare test data
                                                                      Checksum mockChecksum = mock(Checksum.class);
                                                                      InputStream nullInputStream = null;
                                                                      
                                                                      // Expect exception
                                                                      thrown.expect(NullPointerException.class);
                                                                      thrown.expectMessage("Parameter in must not be null");
                                                                      
                                                                      // Test
                                                                      new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                  }

 @Test(expected = NullPointerException.class)
                                                                 public void testConstructor_WhenChecksumIsNull_ShouldThrowNullPointerException() {
                                                                     // Arrange
                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                     
                                                                     // Act - should throw NullPointerException
                                                                     new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                 }

 @Test
                                                                 public void testConstructor_WhenChecksumIsNull_ShouldThrowExceptionWithCorrectMessage() {
                                                                     // Arrange
                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                     String expectedMessage = "Parameter checksum must not be null";
                                                                     
                                                                     try {
                                                                         // Act
                                                                         new ChecksumCalculatingInputStream(null, mockInputStream);
                                                                         fail("Expected exception was not thrown");
                                                                     } catch (NullPointerException e) {
                                                                         // Assert
                                                                         assertEquals(expectedMessage, e.getMessage());
                                                                     } catch (Exception e) {
                                                                         fail("Unexpected exception type thrown: " + e.getClass());
                                                                     }
                                                                 }

 @Test(expected = NullPointerException.class)
                                                            public void testConstructor_ShouldThrowNPE_WhenInputStreamIsNull() {
                                                                // Arrange
                                                                Checksum mockChecksum = mock(Checksum.class);
                                                                InputStream nullInputStream = null;
                                                                
                                                                // Act - should throw NullPointerException
                                                                new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                                
                                                                // Assertion is handled by the @Test expected exception
                                                            }

 @Test
                                                               public void testConstructorWithValidInputStreamShouldNotThrowException() {
                                                                   // Arrange
                                                                   Checksum mockChecksum = mock(Checksum.class);
                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                   
                                                                   // Act & Assert
                                                                   try {
                                                                       ChecksumCalculatingInputStream stream = 
                                                                           new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                       // If we get here, constructor worked as expected
                                                                       assertNotNull(stream);
                                                                   } catch (NullPointerException e) {
                                                                       fail("Constructor threw NullPointerException with valid InputStream");
                                                                   }
                                                               }

 @Test
                                                              public void testConstructor_ShouldThrowWhenInputStreamIsNull() {
                                                                  // Setup
                                                                  Checksum mockChecksum = mock(Checksum.class);
                                                                  InputStream nullInputStream = null;
                                                          
                                                                  // Expect exception
                                                                  thrown.expect(NullPointerException.class);
                                                                  thrown.expectMessage("Parameter in must not be null");
                                                          
                                                                  // Test - this should throw for original code but not for mutated code
                                                                  new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                              }

 @Test
                                                              public void testConstructor_ShouldThrowWhenChecksumIsNull() {
                                                                  // Setup
                                                                  Checksum nullChecksum = null;
                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                          
                                                                  // Expect exception
                                                                  thrown.expect(NullPointerException.class);
                                                                  thrown.expectMessage("Parameter checksum must not be null");
                                                          
                                                                  // Test
                                                                  new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                              }

 @Test
                                                              public void testConstructor_ShouldInitializeFieldsWhenParametersValid() {
                                                                  // Setup
                                                                  Checksum mockChecksum = mock(Checksum.class);
                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                          
                                                                  // Test
                                                                  ChecksumCalculatingInputStream stream = 
                                                                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                          
                                                                  // Verify fields are set (using reflection since fields are private)
                                                                  // Note: In real tests, you might want to verify through behavior rather than reflection
                                                                  try {
                                                                      java.lang.reflect.Field checksumField = 
                                                                          ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                                      checksumField.setAccessible(true);
                                                                      assertEquals(mockChecksum, checksumField.get(stream));
                                                          
                                                                      java.lang.reflect.Field inField = 
                                                                          ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                                      inField.setAccessible(true);
                                                                      assertEquals(mockInputStream, inField.get(stream));
                                                                  } catch (Exception e) {
                                                                      fail("Reflection failed: " + e.getMessage());
                                                                  }
                                                              }

 @Test
                                                             public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull() {
                                                                 // Arrange
                                                                 Checksum mockChecksum = mock(Checksum.class);
                                                                 InputStream nullInputStream = null;
                                                                 
                                                                 // Expect NullPointerException with specific message
                                                                 thrown.expect(NullPointerException.class);
                                                                 thrown.expectMessage("Parameter in must not be null");
                                                                 
                                                                 // Act - this should throw the expected exception
                                                                 new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                             }

 @Test
                                                             public void testConstructorShouldThrowNullPointerExceptionWhenChecksumIsNull() {
                                                                 // Arrange
                                                                 Checksum nullChecksum = null;
                                                                 InputStream mockInputStream = mock(InputStream.class);
                                                                 
                                                                 // Expect NullPointerException with specific message
                                                                 thrown.expect(NullPointerException.class);
                                                                 thrown.expectMessage("Parameter checksum must not be null");
                                                                 
                                                                 // Act - this should throw the expected exception
                                                                 new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                             }

 @Test
                                                            public void testConstructorSetsChecksumFieldCorrectly() throws Exception {
                                                                // Prepare test data
                                                                Checksum mockChecksum = mock(Checksum.class);
                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                
                                                                // Create instance - this is where the mutation would occur
                                                                ChecksumCalculatingInputStream stream = 
                                                                    new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                                
                                                                // Verify the checksum field was set correctly
                                                                // We'll use reflection to access the private field since it's final
                                                                try {
                                                                    java.lang.reflect.Field checksumField = 
                                                                        ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                                    checksumField.setAccessible(true);
                                                                    Checksum actualChecksum = (Checksum) checksumField.get(stream);
                                                                    
                                                                    // This assertion will fail if the mutant is present
                                                                    assertSame("Checksum field should be set to the provided checksum object",
                                                                             mockChecksum, actualChecksum);
                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                    fail("Failed to access checksum field for verification: " + e.getMessage());
                                                                }
                                                            }

 @Test
                                                      public void testConstructorSetsInputStreamFieldCorrectly() throws Exception {
                                                          // Arrange
                                                          InputStream mockInputStream = mock(InputStream.class);
                                                          Checksum mockChecksum = mock(Checksum.class);
                                                          
                                                          // Act - create instance with valid parameters
                                                          ChecksumCalculatingInputStream stream = 
                                                              new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                          
                                                          // Assert - verify fields were set correctly
                                                          // This will catch the mutant that sets in=null
                                                          Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                          inField.setAccessible(true);
                                                          assertSame("InputStream field should be set to provided input stream",
                                                                   mockInputStream, inField.get(stream));
                                                          
                                                          Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                          checksumField.setAccessible(true);
                                                          assertSame("Checksum field should be set to provided checksum",
                                                                   mockChecksum, checksumField.get(stream));
                                                      }

 @Test
                                                      public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull() {
                                                          // Prepare test data
                                                          InputStream mockInputStream = mock(InputStream.class);
                                                          
                                                          // Set expectation
                                                          thrown.expect(NullPointerException.class);
                                                          thrown.expectMessage("Parameter checksum must not be null");
                                                          
                                                          // Execute test - should throw exception
                                                          new ChecksumCalculatingInputStream(null, mockInputStream);
                                                      }

 @Test
                                                      public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull() {
                                                          // Prepare test data
                                                          Checksum mockChecksum = mock(Checksum.class);
                                                          
                                                          // Set expectation
                                                          thrown.expect(NullPointerException.class);
                                                          thrown.expectMessage("Parameter in must not be null");
                                                          
                                                          // Execute test - should throw exception
                                                          new ChecksumCalculatingInputStream(mockChecksum, null);
                                                      }

 @Test
                                                      public void testConstructorInitializesFieldsWhenParametersAreValid() {
                                                          // Prepare test data
                                                          Checksum mockChecksum = mock(Checksum.class);
                                                          InputStream mockInputStream = mock(InputStream.class);
                                                          
                                                          // Execute test
                                                          ChecksumCalculatingInputStream stream = 
                                                              new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                          
                                                          // Verify fields are set (using reflection if needed)
                                                          // Note: Since fields are private final, we might need reflection to verify
                                                          // or test through other methods that use these fields
                                                      }

 @Test
                                                     public void testConstructor_NullChecksum_ThrowsExceptionWithMessage() {
                                                         // Arrange
                                                         InputStream mockInputStream = mock(InputStream.class);
                                                         Checksum nullChecksum = null;
                                                         String expectedMessage = "Parameter checksum must not be null";
                                                         
                                                         try {
                                                             // Act
                                                             new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                             fail("Expected NullPointerException to be thrown");
                                                         } catch (NullPointerException e) {
                                                             // Assert
                                                             assertEquals("Exception message should match expected", 
                                                                         expectedMessage, 
                                                                         e.getMessage());
                                                         }
                                                     }

 @Test
                                                     public void testConstructor_NullInputStream_ThrowsExceptionWithMessage() {
                                                         // Arrange
                                                         Checksum mockChecksum = mock(Checksum.class);
                                                         InputStream nullInputStream = null;
                                                         String expectedMessage = "Parameter in must not be null";
                                                         
                                                         try {
                                                             // Act
                                                             new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                             fail("Expected NullPointerException to be thrown");
                                                         } catch (NullPointerException e) {
                                                             // Assert
                                                             assertEquals("Exception message should match expected", 
                                                                         expectedMessage, 
                                                                         e.getMessage());
                                                         }
                                                     }

 @Test
                                                    public void testConstructorThrowsNullPointerExceptionWithCorrectMessageWhenInIsNull() {
                                                        // Setup
                                                        Checksum mockChecksum = mock(Checksum.class);
                                                        InputStream nullIn = null;
                                                        
                                                        // Expect exception with specific message
                                                        thrown.expect(NullPointerException.class);
                                                        thrown.expectMessage("Parameter in must not be null");
                                                        
                                                        // Test
                                                        new ChecksumCalculatingInputStream(mockChecksum, nullIn);
                                                    }

 @Test
                                                    public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull1() {
                                                        // Setup
                                                        Checksum nullChecksum = null;
                                                        InputStream mockIn = mock(InputStream.class);
                                                        
                                                        // Expect exception with specific message
                                                        thrown.expect(NullPointerException.class);
                                                        thrown.expectMessage("Parameter checksum must not be null");
                                                        
                                                        // Test
                                                        new ChecksumCalculatingInputStream(nullChecksum, mockIn);
                                                    }

 @Test
                                                   public void testConstructorWithValidParameters() throws Exception {
                                                       // Prepare mock objects
                                                       Checksum mockChecksum = mock(Checksum.class);
                                                       InputStream mockInputStream = mock(InputStream.class);
                                                       
                                                       // This test will fail with the mutant because the constructor will throw NPE
                                                       // even with valid parameters due to "|| true" in the condition
                                                       try {
                                                           ChecksumCalculatingInputStream stream = 
                                                               new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                           
                                                           // Verify fields were properly set
                                                           // Need to use reflection to verify since fields are private
                                                           java.lang.reflect.Field checksumField = 
                                                               ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                                           checksumField.setAccessible(true);
                                                           assertEquals(mockChecksum, checksumField.get(stream));
                                                           
                                                           java.lang.reflect.Field inField = 
                                                               ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                                           inField.setAccessible(true);
                                                           assertEquals(mockInputStream, inField.get(stream));
                                                           
                                                       } catch (NullPointerException e) {
                                                           fail("Constructor threw NullPointerException with valid parameters - mutant detected");
                                                       }
                                                   }

 @Test
                                                  public void testConstructorShouldThrowWhenInputStreamIsNull1() {
                                                      // Prepare test data
                                                      Checksum mockChecksum = mock(Checksum.class);
                                                      InputStream nullInputStream = null;
                                              
                                                      // Set expectation
                                                      thrown.expect(NullPointerException.class);
                                                      thrown.expectMessage("Parameter in must not be null");
                                              
                                                      // Execute test
                                                      new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                                  }

 @Test
                                                  public void testConstructorShouldThrowWhenChecksumIsNull1() {
                                                      // Prepare test data
                                                      Checksum nullChecksum = null;
                                                      InputStream mockInputStream = mock(InputStream.class);
                                              
                                                      // Set expectation
                                                      thrown.expect(NullPointerException.class);
                                                      thrown.expectMessage("Parameter checksum must not be null");
                                              
                                                      // Execute test
                                                      new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                  }

 @Test
                                                 public void testConstructorShouldThrowWhenChecksumIsNull2() {
                                                     // Prepare test data
                                                     Checksum nullChecksum = null;
                                                     InputStream mockInputStream = mock(InputStream.class);
                                                     
                                                     // Expect exception
                                                     thrown.expect(NullPointerException.class);
                                                     thrown.expectMessage("Parameter checksum must not be null");
                                                     
                                                     // Execute test - this should throw in original code
                                                     // But mutant would NOT throw here
                                                     new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                                 }

 @Test
                                                 public void testConstructorShouldNotThrowWhenChecksumIsValid() {
                                                     // Prepare test data
                                                     Checksum mockChecksum = mock(Checksum.class);
                                                     InputStream mockInputStream = mock(InputStream.class);
                                                     
                                                     // Execute test - this should NOT throw in original code
                                                     // But mutant WOULD throw here
                                                     new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                     
                                                     // If we get here, test passes for original code
                                                 }

 @Test
                                                public void testConstructorWithValidParametersShouldNotThrowException1() {
                                                    // Prepare test data - valid non-null parameters
                                                    Checksum mockChecksum = mock(Checksum.class);
                                                    InputStream mockInputStream = mock(InputStream.class);
                                                    
                                                    try {
                                                        // Attempt to create the object - should not throw exception
                                                        ChecksumCalculatingInputStream stream = 
                                                            new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                        
                                                        // If we get here, the test passes (original behavior)
                                                        assertNotNull(stream);
                                                    } catch (NullPointerException e) {
                                                        // If we get here, the mutant is detected
                                                        fail("Constructor threw NullPointerException with valid parameters");
                                                    }
                                                }

 @Test(expected = NullPointerException.class)
                                               public void testConstructor_ShouldThrowNPE_WhenChecksumIsNull() {
                                                   // Arrange
                                                   Checksum nullChecksum = null;
                                                   InputStream mockInputStream = mock(InputStream.class);
                                                   
                                                   // Act - should throw NullPointerException
                                                   new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                               }

 @Test(expected = NullPointerException.class)
                                               public void testConstructor_ShouldThrowNPE_WhenInputStreamIsNull1() {
                                                   // Arrange
                                                   Checksum mockChecksum = mock(Checksum.class);
                                                   InputStream nullInputStream = null;
                                                   
                                                   // Act - should throw NullPointerException
                                                   new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                               }

 @Test
                                               public void testConstructor_ShouldInitializeFields_WhenParametersAreValid() {
                                                   // Arrange
                                                   Checksum mockChecksum = mock(Checksum.class);
                                                   InputStream mockInputStream = mock(InputStream.class);
                                                   
                                                   // Act
                                                   ChecksumCalculatingInputStream stream = 
                                                       new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                   
                                                   // Assert - verify fields are properly set
                                                   // Note: Since fields are private, we might need reflection or test through other methods
                                                   // For this example, we'll assume there are getters or we can test behavior
                                                   // through other methods that use these fields
                                                   assertEquals(mockChecksum, stream.getValue()); // Assuming getValue() returns checksum
                                               }

 @Test(expected = NullPointerException.class)
                                              public void testConstructor_ShouldThrowWhenInputStreamIsNull1() {
                                                  // This test will fail on the mutant because the condition is reversed
                                                  Checksum checksum = mock(Checksum.class);
                                                  InputStream nullStream = null;
                                                  new ChecksumCalculatingInputStream(checksum, nullStream);
                                              }

 @Test
                                              public void testConstructor_ShouldNotThrowWhenInputStreamIsNotNull() {
                                                  // This test passes for both original and mutant
                                                  Checksum checksum = mock(Checksum.class);
                                                  InputStream stream = mock(InputStream.class);
                                                  ChecksumCalculatingInputStream instance = 
                                                      new ChecksumCalculatingInputStream(checksum, stream);
                                                  assertNotNull(instance);
                                              }

 @Test(expected = NullPointerException.class)
                                              public void testConstructor_ShouldThrowWhenChecksumIsNull1() {
                                                  // Additional test for the other parameter
                                                  InputStream stream = mock(InputStream.class);
                                                  new ChecksumCalculatingInputStream(null, stream);
                                              }

 @Test
                                             public void testConstructorWithNonNullInputStreamShouldNotThrowException() {
                                                 // Arrange
                                                 Checksum mockChecksum = mock(Checksum.class);
                                                 InputStream mockInputStream = mock(InputStream.class);
                                                 
                                                 // Act & Assert
                                                 try {
                                                     ChecksumCalculatingInputStream stream = 
                                                         new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                                     // If we get here, test passes (no exception thrown)
                                                     assertNotNull(stream);
                                                 } catch (NullPointerException e) {
                                                     fail("Constructor threw NullPointerException with non-null InputStream");
                                                 }
                                             }

 @Test
                                            public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull1() {
                                                // Prepare test data
                                                Checksum mockChecksum = mock(Checksum.class);
                                                InputStream nullInputStream = null;
                                        
                                                // Set expectation
                                                thrown.expect(NullPointerException.class);
                                                thrown.expectMessage("Parameter in must not be null");
                                        
                                                // Execute test
                                                new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                            }

 @Test
                                           public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull2() {
                                               // Arrange
                                               Checksum mockChecksum = mock(Checksum.class);
                                               InputStream nullInputStream = null;
                                               
                                               // Expect
                                               thrown.expect(NullPointerException.class);
                                               thrown.expectMessage("Parameter in must not be null");
                                               
                                               // Act
                                               new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                           }

 @Test
                                           public void testConstructorShouldThrowNullPointerExceptionWhenChecksumIsNull1() {
                                               // Arrange
                                               Checksum nullChecksum = null;
                                               InputStream mockInputStream = mock(InputStream.class);
                                               
                                               // Expect
                                               thrown.expect(NullPointerException.class);
                                               thrown.expectMessage("Parameter checksum must not be null");
                                               
                                               // Act
                                               new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                           }

 @Test
                                          public void testConstructorSetsChecksumFieldCorrectly1() throws Exception {
                                              // Create mock objects
                                              Checksum mockChecksum = mock(Checksum.class);
                                              InputStream mockInputStream = mock(InputStream.class);
                                              
                                              // Set up mock behavior
                                              when(mockChecksum.getValue()).thenReturn(123L);
                                              
                                              // Create instance and test
                                              ChecksumCalculatingInputStream stream = 
                                                  new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                              
                                              // Verify checksum field was set properly by calling getValue()
                                              // This would fail with the mutant since checksum field would be null
                                              assertEquals(123L, stream.getValue());
                                              
                                              // Additional verification that the field was set correctly
                                              // (Alternative approach if getValue() isn't available)
                                              // Note: This requires reflection which isn't ideal but can be used if needed
                                              /*
                                              Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                              checksumField.setAccessible(true);
                                              assertSame(mockChecksum, checksumField.get(stream));
                                              */
                                          }

 @Test
                                         public void testConstructorSetsInputStreamFieldCorrectly1() throws Exception {
                                             // Prepare test data
                                             Checksum mockChecksum = mock(Checksum.class);
                                             InputStream mockInputStream = mock(InputStream.class);
                                             
                                             // Create instance
                                             ChecksumCalculatingInputStream stream = 
                                                 new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                             
                                             // Use reflection to verify the private field was set correctly
                                             Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                             inField.setAccessible(true);
                                             InputStream actualIn = (InputStream) inField.get(stream);
                                             
                                             // Assert that the field was set to the provided input stream (not null)
                                             assertSame("InputStream field should be set to the provided input stream", 
                                                       mockInputStream, actualIn);
                                             
                                             // Also verify the checksum field was set correctly
                                             Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                             checksumField.setAccessible(true);
                                             Checksum actualChecksum = (Checksum) checksumField.get(stream);
                                             assertSame(mockChecksum, actualChecksum);
                                         }

 @Test(expected = NullPointerException.class)
                                        public void testConstructor_ShouldThrowWhenChecksumIsNull2() {
                                            InputStream mockInputStream = mock(InputStream.class);
                                            new ChecksumCalculatingInputStream(null, mockInputStream);
                                        }

 @Test(expected = NullPointerException.class)
                                        public void testConstructor_ShouldThrowWhenInputStreamIsNull2() {
                                            Checksum mockChecksum = mock(Checksum.class);
                                            new ChecksumCalculatingInputStream(mockChecksum, null);
                                        }

 @Test
                                   public void testConstructor_ShouldInitializeFieldsWhenParamsAreValid() throws Exception {
                                       InputStream mockInputStream = mock(InputStream.class);
                                       Checksum mockChecksum = mock(Checksum.class);
                                       
                                       ChecksumCalculatingInputStream stream = 
                                           new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                       
                                       // Use reflection to access private fields
                                       Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                                       checksumField.setAccessible(true);
                                       Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                                       inField.setAccessible(true);
                                       
                                       // Verify fields were properly initialized
                                       assertSame(mockChecksum, checksumField.get(stream));
                                       assertSame(mockInputStream, inField.get(stream));
                                   }

 @Test
                                   public void testConstructorThrowsNullPointerExceptionWithMessageWhenChecksumIsNull() {
                                       // Arrange
                                       Checksum nullChecksum = null;
                                       InputStream mockInputStream = mock(InputStream.class);
                                       
                                       // Set expectation for exception
                                       thrown.expect(NullPointerException.class);
                                       thrown.expectMessage("Parameter checksum must not be null");
                                       
                                       // Act
                                       new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                                   }

 @Test
                                   public void testConstructorThrowsNullPointerExceptionWithMessageWhenInputStreamIsNull() {
                                       // Arrange
                                       Checksum mockChecksum = mock(Checksum.class);
                                       InputStream nullInputStream = null;
                                       
                                       // Set expectation for exception
                                       thrown.expect(NullPointerException.class);
                                       thrown.expectMessage("Parameter in must not be null");
                                       
                                       // Act
                                       new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                                   }

 @Test
                             public void testConstructor_WhenInputStreamIsNull_ShouldThrowNullPointerExceptionWithSpecificMessage() {
                                 // Arrange
                                 Checksum mockChecksum = mock(Checksum.class);
                                 InputStream nullInputStream = null;
                                 
                                 // Set up exception rule
                                 ExpectedException exceptionRule = ExpectedException.none();
                                 exceptionRule.expect(NullPointerException.class);
                                 exceptionRule.expectMessage("Parameter in must not be null");
                                 
                                 // Act - this should throw the exception
                                 new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                             }

 @Test
                             public void testConstructor_WhenChecksumIsNull_ShouldThrowNullPointerExceptionWithSpecificMessage() {
                                 // Arrange
                                 Checksum nullChecksum = null;
                                 InputStream mockInputStream = mock(InputStream.class);
                                 
                                 // Set expectation for exception with specific message
                                 ExpectedException exceptionRule = ExpectedException.none();
                                 exceptionRule.expect(NullPointerException.class);
                                 exceptionRule.expectMessage("Parameter checksum must not be null");
                                 
                                 // Act - this should throw the exception
                                 new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                             }

 @Test
                             public void testConstructorWithNonNullChecksumShouldNotThrowException() {
                                 // Prepare test data
                                 Checksum mockChecksum = mock(Checksum.class);
                                 InputStream mockInputStream = mock(InputStream.class);
                                 
                                 // This should not throw an exception with original code
                                 // With mutated code, it will throw NullPointerException
                                 try {
                                     new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                 } catch (NullPointerException e) {
                                     fail("Constructor threw NullPointerException with non-null checksum");
                                 }
                             }

 @Test(expected = NullPointerException.class)
                             public void testConstructorWithNullChecksumShouldThrowException1() {
                                 // Prepare test data
                                 InputStream mockInputStream = mock(InputStream.class);
                                 
                                 // This should throw NullPointerException in both original and mutated code
                                 new ChecksumCalculatingInputStream(null, mockInputStream);
                             }

 @Test(expected = NullPointerException.class)
                             public void testConstructorWithNullInputStreamShouldThrowException1() {
                                 // Prepare test data
                                 Checksum mockChecksum = mock(Checksum.class);
                                 
                                 // This should throw NullPointerException in both original and mutated code
                                 new ChecksumCalculatingInputStream(mockChecksum, null);
                             }

 @Test(expected = NullPointerException.class)
                            public void testConstructor_ShouldThrowWhenInputStreamIsNull3() {
                                // Prepare test data
                                Checksum validChecksum = mock(Checksum.class);
                                InputStream nullInputStream = null;
                                
                                // This should throw NullPointerException for original code
                                // Mutated version would not throw and the test would fail
                                new ChecksumCalculatingInputStream(validChecksum, nullInputStream);
                            }

 @Test
                            public void testConstructor_ShouldNotThrowWhenParametersAreValid() {
                                // Prepare test data
                                Checksum validChecksum = mock(Checksum.class);
                                InputStream validInputStream = mock(InputStream.class);
                                
                                // This should work fine for both original and mutated code
                                ChecksumCalculatingInputStream stream = 
                                    new ChecksumCalculatingInputStream(validChecksum, validInputStream);
                                
                                assertNotNull(stream);
                            }

 @Test(expected = NullPointerException.class)
                            public void testConstructor_ShouldThrowWhenChecksumIsNull3() {
                                // Prepare test data
                                Checksum nullChecksum = null;
                                InputStream validInputStream = mock(InputStream.class);
                                
                                // This should throw NullPointerException for checksum null check
                                new ChecksumCalculatingInputStream(nullChecksum, validInputStream);
                            }

 @Test
                           public void testConstructorShouldThrowWhenChecksumIsNull3() {
                               // Setup
                               InputStream mockInputStream = mock(InputStream.class);
                               
                               // Expect exception
                               thrown.expect(NullPointerException.class);
                               thrown.expectMessage("Parameter checksum must not be null");
                               
                               // Test - this should throw in original, but mutant would not throw
                               new ChecksumCalculatingInputStream(null, mockInputStream);
                           }

 @Test
                           public void testConstructorShouldNotThrowWhenChecksumIsNotNull() {
                               // Setup
                               InputStream mockInputStream = mock(InputStream.class);
                               Checksum mockChecksum = mock(Checksum.class);
                               
                               // Test - this should not throw in original, but mutant would throw
                               new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                               
                               // No exception expected - if we get here, test passes for original
                           }

 @Test
                           public void testConstructorShouldThrowWhenInputStreamIsNull2() {
                               // Setup
                               Checksum mockChecksum = mock(Checksum.class);
                               
                               // Expect exception
                               thrown.expect(NullPointerException.class);
                               thrown.expectMessage("Parameter in must not be null");
                               
                               // Test
                               new ChecksumCalculatingInputStream(mockChecksum, null);
                           }

 @Test(expected = NullPointerException.class)
                          public void testConstructorWithNullChecksum() {
                              InputStream mockInputStream = mock(InputStream.class);
                              new ChecksumCalculatingInputStream(null, mockInputStream);
                          }

 @Test(expected = NullPointerException.class)
                          public void testConstructorWithNullInputStream() {
                              Checksum mockChecksum = mock(Checksum.class);
                              new ChecksumCalculatingInputStream(mockChecksum, null);
                          }

 @Test
                          public void testConstructorWithValidParameters1() {
                              // This test will detect the mutant since the mutated version would throw exception
                              Checksum mockChecksum = mock(Checksum.class);
                              InputStream mockInputStream = mock(InputStream.class);
                              
                              // Should not throw exception with valid parameters
                              ChecksumCalculatingInputStream stream = 
                                  new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                                  
                              // Verify fields were set correctly
                              assertEquals(mockChecksum, stream.getValue()); // Assuming getValue() returns checksum
                              // Note: Since 'in' is private, we might need reflection to verify it,
                              // or we can test it indirectly through read() operations
                          }

 @Test
                         public void testConstructorShouldThrowNullPointerExceptionWhenChecksumIsNull2() {
                             // Prepare test data
                             Checksum nullChecksum = null;
                             InputStream mockInputStream = mock(InputStream.class);
                             
                             // Expect exception
                             thrown.expect(NullPointerException.class);
                             thrown.expectMessage("Parameter checksum must not be null");
                             
                             // Execute test - should throw exception
                             new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                         }

 @Test
                         public void testConstructorShouldThrowNullPointerExceptionWhenInputStreamIsNull3() {
                             // Prepare test data
                             Checksum mockChecksum = mock(Checksum.class);
                             InputStream nullInputStream = null;
                             
                             // Expect exception
                             thrown.expect(NullPointerException.class);
                             thrown.expectMessage("Parameter in must not be null");
                             
                             // Execute test - should throw exception
                             new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                         }

 @Test
                        public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull2() {
                            // Arrange
                            InputStream mockInputStream = mock(InputStream.class);
                            
                            // Set expectation for exact exception type and message
                            thrown.expect(NullPointerException.class);
                            thrown.expectMessage("Parameter checksum must not be null");
                            
                            // Act - this should throw NullPointerException
                            new ChecksumCalculatingInputStream(null, mockInputStream);
                        }

 @Test
                        public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull1() {
                            // Arrange
                            Checksum mockChecksum = mock(Checksum.class);
                            
                            // Set expectation for exact exception type and message
                            thrown.expect(NullPointerException.class);
                            thrown.expectMessage("Parameter in must not be null");
                            
                            // Act - this should throw NullPointerException
                            new ChecksumCalculatingInputStream(mockChecksum, null);
                        }

 @Test
                       public void testConstructorShouldThrowWhenInputStreamIsNull3() {
                           // Setup
                           Checksum mockChecksum = mock(Checksum.class);
                           InputStream nullInputStream = null;
                           
                           // Expect exception
                           thrown.expect(NullPointerException.class);
                           thrown.expectMessage("Parameter in must not be null");
                           
                           // Test - this should throw in original code but not in mutated code
                           new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                       }

 @Test
                       public void testConstructorShouldNotThrowWhenInputStreamIsValid() {
                           // Setup
                           Checksum mockChecksum = mock(Checksum.class);
                           InputStream mockInputStream = mock(InputStream.class);
                           
                           // Test - this should NOT throw in original code but WOULD throw in mutated code
                           new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                           
                           // If we get here, test passes for original code
                           // Mutated code would have thrown exception above
                       }

 @Test
                 public void testConstructorWithValidParametersShouldNotThrowException2() {
                     // Prepare test data
                     Checksum mockChecksum = mock(Checksum.class);
                     InputStream mockInputStream = mock(InputStream.class);
                     
                     try {
                         // This should not throw an exception in original code
                         // But will throw exception in mutated code
                         ChecksumCalculatingInputStream stream = 
                             new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                         
                         // Verify fields were set correctly using reflection
                         Field checksumField = ChecksumCalculatingInputStream.class.getDeclaredField("checksum");
                         checksumField.setAccessible(true);
                         assertSame(mockChecksum, checksumField.get(stream));
                         
                         Field inField = ChecksumCalculatingInputStream.class.getDeclaredField("in");
                         inField.setAccessible(true);
                         assertSame(mockInputStream, inField.get(stream));
                     } catch (NullPointerException e) {
                         fail("Constructor threw NullPointerException with valid non-null parameters");
                     } catch (NoSuchFieldException | IllegalAccessException e) {
                         fail("Failed to access private fields for verification: " + e.getMessage());
                     }
                 }

 @Test
                 public void testConstructorThrowsNullPointerExceptionWhenInputStreamIsNull2() {
                     // Setup
                     Checksum mockChecksum = mock(Checksum.class);
                     InputStream nullInputStream = null;
             
                     // Expect exception
                     thrown.expect(NullPointerException.class);
                     thrown.expectMessage("Parameter in must not be null");
             
                     // Exercise
                     new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                 }

 @Test
                 public void testConstructorThrowsNullPointerExceptionWhenChecksumIsNull3() {
                     // Setup
                     Checksum nullChecksum = null;
                     InputStream mockInputStream = mock(InputStream.class);
             
                     // Expect exception
                     thrown.expect(NullPointerException.class);
                     thrown.expectMessage("Parameter checksum must not be null");
             
                     // Exercise
                     new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                 }

 @Test
                public void testConstructor_WhenInIsNull_ShouldThrowNullPointerException() {
                    // Arrange
                    Checksum mockChecksum = mock(Checksum.class);
                    InputStream nullInputStream = null;
                    
                    // Set expectation for exact exception type and message
                    thrown.expect(NullPointerException.class);
                    thrown.expectMessage("Parameter in must not be null");
                    
                    // Act - this should throw the expected exception
                    new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                }

 @Test
               public void testConstructorSetsChecksumFieldCorrectly2() throws Exception {
                   // Prepare test data
                   Checksum mockChecksum = mock(Checksum.class);
                   InputStream mockInputStream = mock(InputStream.class);
                   
                   // Create instance - this is where the mutation would occur
                   ChecksumCalculatingInputStream stream = 
                       new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                   
                   // Verify the checksum field was set properly by calling getValue()
                   // which presumably uses the checksum field
                   stream.getValue();
                   
                   // If the mutation is present (checksum set to null), this would throw NPE
                   // Verify the checksum was actually used by checking interactions
                   verify(mockChecksum).getValue();
               }

 @Test
              public void testConstructorSetsInputStreamFieldCorrectly2() throws Exception {
                  // Prepare test data
                  Checksum mockChecksum = mock(Checksum.class);
                  InputStream mockInputStream = mock(InputStream.class);
                  
                  // Configure mock behavior
                  when(mockInputStream.read()).thenReturn(42); // Return some dummy value
                  
                  // Create instance - this is what we're testing
                  ChecksumCalculatingInputStream stream = 
                      new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
                  
                  // Test that the field was set correctly by attempting to use it
                  // If the mutant is present, this will throw NullPointerException
                  int result = stream.read();
                  
                  // Verify the read operation worked (indirectly verifies 'in' was set properly)
                  assertEquals(42, result);
                  
                  // Additional verification that the mock was actually used
                  verify(mockInputStream).read();
              }

 @Test(expected = NullPointerException.class)
             public void testConstructorThrowsNPEWhenChecksumIsNull() {
                 InputStream mockInputStream = mock(InputStream.class);
                 new ChecksumCalculatingInputStream(null, mockInputStream);
             }

 @Test
             public void testConstructorDoesNotThrowWhenChecksumIsNotNull() {
                 InputStream mockInputStream = mock(InputStream.class);
                 Checksum mockChecksum = mock(Checksum.class);
                 // Should not throw any exception
                 new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
             }

 @Test(expected = NullPointerException.class)
             public void testConstructorThrowsNPEWhenInputStreamIsNull() {
                 Checksum mockChecksum = mock(Checksum.class);
                 new ChecksumCalculatingInputStream(mockChecksum, null);
             }

 @Test
             public void testConstructorDoesNotThrowWhenBothParametersAreValid() {
                 InputStream mockInputStream = mock(InputStream.class);
                 Checksum mockChecksum = mock(Checksum.class);
                 // Should not throw any exception
                 new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
             }

 @Test(expected = NullPointerException.class)
            public void testConstructorWithNullChecksumShouldThrowWithMessage() {
                // Arrange
                Checksum nullChecksum = null;
                InputStream mockInputStream = mock(InputStream.class);
                
                try {
                    // Act
                    new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
                    fail("Expected NullPointerException to be thrown");
                } catch (NullPointerException e) {
                    // Assert
                    assertEquals("Exception message should match expected", 
                                 "Parameter checksum must not be null", 
                                 e.getMessage());
                    throw e; // rethrow to satisfy expected exception
                }
            }

 @Test(expected = NullPointerException.class)
           public void testConstructorWithNullInputStreamShouldThrowWithMessage() {
               // Arrange
               Checksum mockChecksum = mock(Checksum.class);
               InputStream nullInputStream = null;
               String expectedMessage = "Parameter in must not be null";
               
               try {
                   // Act
                   new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
                   fail("Expected NullPointerException to be thrown");
               } catch (NullPointerException e) {
                   // Assert
                   assertEquals("Exception message should match expected", 
                                expectedMessage, e.getMessage());
                   throw e; // rethrow for the @Test expected verification
               }
           }

 @Test
     public void testConstructorWithValidParametersShouldNotThrowException3() {
         // Prepare valid non-null parameters
         java.util.zip.CRC32 checksum = new java.util.zip.CRC32();
         java.io.InputStream inputStream = new java.io.ByteArrayInputStream(new byte[0]);
         
         // This should not throw an exception with original code
         // But will throw NPE with mutated code
         new org.apache.commons.compress.utils.ChecksumCalculatingInputStream(checksum, inputStream);
         
         // If we reach here, test passes (original behavior)
         // Mutant would have thrown exception before this point
     }

 @Test
     public void testConstructorShouldThrowWhenInputStreamIsNull4() {
         // Prepare test data
         Checksum mockChecksum = mock(Checksum.class);
         InputStream nullInputStream = null;
 
         // Expect exception
         thrown.expect(NullPointerException.class);
         thrown.expectMessage("Parameter in must not be null");
 
         // Execute test
         new ChecksumCalculatingInputStream(mockChecksum, nullInputStream);
     }

 @Test
     public void testConstructorShouldThrowWhenChecksumIsNull4() {
         // Prepare test data
         Checksum nullChecksum = null;
         InputStream mockInputStream = mock(InputStream.class);
 
         // Expect exception
         thrown.expect(NullPointerException.class);
         thrown.expectMessage("Parameter checksum must not be null");
 
         // Execute test
         new ChecksumCalculatingInputStream(nullChecksum, mockInputStream);
     }

 @Test
     public void testConstructorShouldNotThrowWhenBothParametersAreValid() {
         // Prepare test data
         Checksum mockChecksum = mock(Checksum.class);
         InputStream mockInputStream = mock(InputStream.class);
 
         // Execute test - should not throw any exception
         new ChecksumCalculatingInputStream(mockChecksum, mockInputStream);
     }

}
