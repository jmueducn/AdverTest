package gentest.org.apache.commons.compress.archivers.zip.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
 
public class ZipArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                      public void testSetName_EmptyName() throws Exception {
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          setNameMethod.invoke(entry, "");
                                                                                                                                                                                                          assertEquals("", entry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_FatPlatform_NoBackslashes() {
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use constructor with name parameter
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access protected setName method
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                                                                              setNameMethod.invoke(spyEntry, "test/file");
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to invoke setName method: " + e.getMessage());
                                                                                                                                                                                                          }
                                                                                                                                                                                                          
                                                                                                                                                                                                          assertEquals("test/file", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_FatPlatform_WithBackslashes() {
                                                                                                                                                                                                          // Use the protected constructor since we're testing in the same package
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to call the protected setName method
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                                                                              setNameMethod.invoke(spyEntry, "test\\\\file");
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to invoke setName method: " + e.getMessage());
                                                                                                                                                                                                          }
                                                                                                                                                                                                          
                                                                                                                                                                                                          assertEquals("test/file", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_FatPlatform_MultipleBackslashes() throws Exception {
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to call the protected setName method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          setNameMethod.invoke(spyEntry, "test\\\\\\\\file\\\\path");
                                                                                                                                                                                                          
                                                                                                                                                                                                          assertEquals("test//file/path", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_UnixPlatform_WithBackslashes() throws Exception {
                                                                                                                                                                                                          // Create entry with a dummy name first since protected constructor can't be accessed
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_UNIX
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access protected setName method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          setNameMethod.invoke(spyEntry, "test\\\\file");
                                                                                                                                                                                                          
                                                                                                                                                                                                          assertEquals("test\\\\file", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_FatPlatform_WithForwardSlash() {
                                                                                                                                                                                                          // Create entry with a dummy name first since no-arg constructor is protected
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use protected setName method through reflection
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                                                                              setNameMethod.invoke(spyEntry, "test/file");
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to invoke setName method: " + e.getMessage());
                                                                                                                                                                                                          }
                                                                                                                                                                                                          
                                                                                                                                                                                                          assertEquals("test/file", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_ContainsBothSlashTypes() throws Exception {
                                                                                                                                                                                                          // Create entry with a dummy name first since we can't use protected constructor
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Access the protected setName method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          setNameMethod.invoke(spyEntry, "test\\\\file/path");
                                                                                                                                                                                                          
                                                                                                                                                                                                          assertEquals("test/file/path", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_EdgeCase_OnlyForwardSlash() {
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                                                                                          // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                          ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                          when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access protected setName method
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                                                                              setNameMethod.invoke(spyEntry, "/");
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to invoke setName method: " + e.getMessage());
                                                                                                                                                                                                          }
                                                                                                                                                                                                          assertEquals("/", spyEntry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithValidNameAndRawName() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          String name = "testFile.txt";
                                                                                                                                                                                                          // Using reflection to access protected constructor
                                                                                                                                                                                                          Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                                                                          ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                                                          byte[] rawName = name.getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Using reflection to access protected setName(String, byte[]) method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, name, rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Name should be set correctly", name, entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Raw name should be set correctly", rawName, entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithNullName() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          // Use reflection to access protected constructor
                                                                                                                                                                                                          Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                                                                          ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                                                          byte[] rawName = "test".getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access protected setName(String, byte[]) method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, null, rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertNull("Name should be null", entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Raw name should still be set", rawName, entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithNullRawName() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                                                                                                          String name = "testFile.txt";
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get protected setName method via reflection
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                                                                                              "setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, name, null);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Name should be set correctly", name, entry.getName());
                                                                                                                                                                                                          assertNull("Raw name should be null", entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithEmptyName() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                                                                                                          byte[] rawName = new byte[0];
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get protected setName method via reflection
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                                                                                              "setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, "", rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Name should be empty string", "", entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Raw name should be empty array", rawName, entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithNonAsciiCharacters() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          String name = "测试文件.txt";
                                                                                                                                                                                                          byte[] rawName = name.getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Create instance using reflection since default constructor is protected
                                                                                                                                                                                                          Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                                                                          ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get and make setName method accessible
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, name, rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Name with non-ASCII characters should be preserved", name, entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Raw name should preserve non-ASCII bytes", rawName, entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithVeryLongName() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("temp"); // Using public constructor
                                                                                                                                                                                                          StringBuilder longNameBuilder = new StringBuilder();
                                                                                                                                                                                                          for (int i = 0; i < 1000; i++) {
                                                                                                                                                                                                              longNameBuilder.append("a");
                                                                                                                                                                                                          }
                                                                                                                                                                                                          String longName = longNameBuilder.toString();
                                                                                                                                                                                                          byte[] rawName = longName.getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access protected setName(String, byte[]) method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                                                                                              "setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, longName, rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Very long name should be preserved", longName, entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Very long raw name should be preserved", rawName, entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithDirectoryName() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("temp"); // Using public constructor
                                                                                                                                                                                                          String name = "directory/";
                                                                                                                                                                                                          byte[] rawName = name.getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access protected setName(String, byte[]) method
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          setNameMethod.invoke(entry, name, rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Directory name should be preserved", name, entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Directory raw name should be preserved", rawName, entry.getRawName());
                                                                                                                                                                                                          assertTrue("Entry should be recognized as directory", entry.isDirectory());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithDifferentPlatforms() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("initial");
                                                                                                                                                                                                          String name = "file.txt";
                                                                                                                                                                                                          byte[] rawName = name.getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get protected methods via reflection
                                                                                                                                                                                                          Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                                          setPlatform.setAccessible(true);
                                                                                                                                                                                                          Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                          setName.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute and verify for FAT platform
                                                                                                                                                                                                          setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                          setName.invoke(entry, name, rawName);
                                                                                                                                                                                                          assertEquals("Name should be preserved on FAT platform", name, entry.getName());
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute and verify for UNIX platform
                                                                                                                                                                                                          setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                                                                                                          setName.invoke(entry, name, rawName);
                                                                                                                                                                                                          assertEquals("Name should be preserved on UNIX platform", name, entry.getName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithRawNameOnly() throws Exception {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                                                                          ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                                                          byte[] rawName = "rawOnly".getBytes();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          setNameMethod.invoke(entry, null, rawName);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertNull("Name should be null", entry.getName());
                                                                                                                                                                                                          assertArrayEquals("Raw name should be set", rawName, entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testSetName_WithNameOnly() {
                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                                                                                                                                                                                          String name = "nameOnly";
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                          try {
                                                                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                                                                              setNameMethod.invoke(entry, name, null);
                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                              fail("Failed to invoke protected setName method");
                                                                                                                                                                                                          }
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                          assertEquals("Name should be set", name, entry.getName());
                                                                                                                                                                                                          assertNull("Raw name should be null", entry.getRawName());
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                  public void testSetName_NullName() throws Exception {
                                                                                                                                                                                                      ZipArchiveEntry entry = new ZipArchiveEntry("test");
                                                                                                                                                                                                      try {
                                                                                                                                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                          setNameMethod.setAccessible(true);
                                                                                                                                                                                                          setNameMethod.invoke(entry, (String)null);
                                                                                                                                                                                                          fail("Expected NullPointerException");
                                                                                                                                                                                                      } catch (InvocationTargetException e) {
                                                                                                                                                                                                          if (e.getCause() instanceof NullPointerException) {
                                                                                                                                                                                                              // Expected behavior
                                                                                                                                                                                                          } else {
                                                                                                                                                                                                              throw e;
                                                                                                                                                                                                          }
                                                                                                                                                                                                      }
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                  public void testSetName_LongPathWithMixedSlashes() throws Exception {
                                                                                                                                                                                                      // Create entry with a dummy name first since no-arg constructor is protected
                                                                                                                                                                                                      ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                      ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                      when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                      
                                                                                                                                                                                                      String complexPath = "this\\\\\\\\is\\\\\\\\a\\\\\\\\very\\\\\\\\long\\\\\\\\path/with/mixed\\\\\\\\slashes";
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Use reflection to call the protected setName method
                                                                                                                                                                                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                      setNameMethod.setAccessible(true);
                                                                                                                                                                                                      setNameMethod.invoke(spyEntry, complexPath);
                                                                                                                                                                                                      
                                                                                                                                                                                                      assertEquals("this/is/a/very/long/path/with/mixed/slashes", spyEntry.getName());
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                  public void testSetName_EdgeCase_OnlyBackslash() throws Exception {
                                                                                                                                                                                                      // Create entry with a dummy name first since no-arg constructor is protected
                                                                                                                                                                                                      ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                                      // Mock getPlatform to return PLATFORM_FAT
                                                                                                                                                                                                      ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                      when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Use reflection to access protected setName method
                                                                                                                                                                                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                      setNameMethod.setAccessible(true);
                                                                                                                                                                                                      
                                                                                                                                                                                                      // Test the edge case with only backslash
                                                                                                                                                                                                      setNameMethod.invoke(spyEntry, "\\\\");
                                                                                                                                                                                                      assertEquals("/", spyEntry.getName());
                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                             public void testSetName_BackslashReplacementPlatformCondition() throws Exception {
                                                                                                                                                                                                 // Setup - use reflection to access protected constructor
                                                                                                                                                                                                 Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                                                                 ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Get protected methods
                                                                                                                                                                                                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                                 setPlatform.setAccessible(true);
                                                                                                                                                                                                 Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                 setName.setAccessible(true);
                                                                                                                                                                                                 Method getName = ZipArchiveEntry.class.getMethod("getName");
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Case 1: Platform is FAT - should replace backslashes in original, shouldn't in mutant
                                                                                                                                                                                                 setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                 String nameWithBackslashes = "path\\\\to\\\\file";
                                                                                                                                                                                                 setName.invoke(entry, nameWithBackslashes);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify backslashes were replaced (original behavior)
                                                                                                                                                                                                 assertEquals("path/to/file", getName.invoke(entry));
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Case 2: Platform is not FAT - shouldn't replace backslashes in original, should in mutant
                                                                                                                                                                                                 setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX); // any non-FAT platform
                                                                                                                                                                                                 setName.invoke(entry, nameWithBackslashes);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify backslashes were NOT replaced (original behavior)
                                                                                                                                                                                                 assertEquals(nameWithBackslashes, getName.invoke(entry));
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                             public void testSetNameWithRawNamePlatformComparison() throws Exception {
                                                                                                                                                                                                 // Create test data
                                                                                                                                                                                                 String testName = "test.txt";
                                                                                                                                                                                                 byte[] testRawName = new byte[]{1, 2, 3};
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Get protected methods via reflection
                                                                                                                                                                                                 Method setNameWithRawName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                                                 setNameWithRawName.setAccessible(true);
                                                                                                                                                                                                 Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                                 setPlatformMethod.setAccessible(true);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Test case 1: Platform is FAT - should set rawName in original, not in mutant
                                                                                                                                                                                                 ZipArchiveEntry entryFat = new ZipArchiveEntry(testName);
                                                                                                                                                                                                 setPlatformMethod.invoke(entryFat, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                                 setNameWithRawName.invoke(entryFat, testName, testRawName);
                                                                                                                                                                                                 assertArrayEquals("rawName should be set when platform is FAT", 
                                                                                                                                                                                                                  testRawName, entryFat.getRawName());
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Test case 2: Platform is not FAT - should not set rawName in original, should in mutant
                                                                                                                                                                                                 ZipArchiveEntry entryUnix = new ZipArchiveEntry(testName);
                                                                                                                                                                                                 setPlatformMethod.invoke(entryUnix, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                                                                                                 setNameWithRawName.invoke(entryUnix, testName, testRawName);
                                                                                                                                                                                                 assertNull("rawName should not be set when platform is not FAT", 
                                                                                                                                                                                                           entryUnix.getRawName());
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                        public void testSetNameWithBackslashAndNoForwardSlash() {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                                                                                                                                            try {
                                                                                                                                                                                                // Use reflection to access protected setPlatform method
                                                                                                                                                                                                Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                                setPlatformMethod.setAccessible(true);
                                                                                                                                                                                                setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to set platform via reflection");
                                                                                                                                                                                            }
                                                                                                                                                                                            String inputName = "path\\\\to\\\\file";
                                                                                                                                                                                            
                                                                                                                                                                                            // Test
                                                                                                                                                                                            try {
                                                                                                                                                                                                // Use reflection to access protected setName method
                                                                                                                                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                setNameMethod.setAccessible(true);
                                                                                                                                                                                                setNameMethod.invoke(entry, inputName);
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to set name via reflection");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify
                                                                                                                                                                                            // Original should replace backslashes with forward slashes
                                                                                                                                                                                            // Mutant would leave it unchanged since it has no forward slash
                                                                                                                                                                                            assertEquals("path/to/file", entry.getName());
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testSetNameWithBothSlashes() {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                                                                                                                                            try {
                                                                                                                                                                                                // Use reflection to access protected setPlatform method
                                                                                                                                                                                                Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                                setPlatformMethod.setAccessible(true);
                                                                                                                                                                                                setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to set platform via reflection");
                                                                                                                                                                                            }
                                                                                                                                                                                            String inputName = "path/to\\\\file";
                                                                                                                                                                                            
                                                                                                                                                                                            // Test
                                                                                                                                                                                            try {
                                                                                                                                                                                                // Use reflection to access protected setName method
                                                                                                                                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                                setNameMethod.setAccessible(true);
                                                                                                                                                                                                setNameMethod.invoke(entry, inputName);
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to set name via reflection");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify
                                                                                                                                                                                            // Original should leave it unchanged (contains forward slash)
                                                                                                                                                                                            // Mutant would replace backslashes with forward slashes
                                                                                                                                                                                            assertEquals("path/to\\\\file", entry.getName());
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testSetNameWithSlash() {
                                                                                                                                                                                            // Create test objects using available constructor
                                                                                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                                                                                                                                                                            String nameWithSlash = "path/to/file";
                                                                                                                                                                                            String nameWithoutSlash = "file";
                                                                                                                                                                                            byte[] rawName = new byte[0];
                                                                                                                                                                                            
                                                                                                                                                                                            try {
                                                                                                                                                                                                // Get protected setName method via reflection
                                                                                                                                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                                                                                    "setName", String.class, byte[].class);
                                                                                                                                                                                                setNameMethod.setAccessible(true);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test with name containing slash - should be allowed
                                                                                                                                                                                                setNameMethod.invoke(entry, nameWithSlash, rawName);
                                                                                                                                                                                                assertEquals("Name with slash should be set", nameWithSlash, entry.getName());
                                                                                                                                                                                                assertSame("Raw name should be set", rawName, entry.getRawName());
                                                                                                                                                                                                
                                                                                                                                                                                                // Test with name not containing slash - should also be allowed
                                                                                                                                                                                                setNameMethod.invoke(entry, nameWithoutSlash, rawName);
                                                                                                                                                                                                assertEquals("Name without slash should be set", nameWithoutSlash, entry.getName());
                                                                                                                                                                                                assertSame("Raw name should be set", rawName, entry.getRawName());
                                                                                                                                                                                                
                                                                                                                                                                                                // The mutant would fail the second assertion because it would reject names without slashes
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                            }
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                   public void testSetNameWithBothSlashesShouldConvertBackslashes() throws Exception {
                                                                                                                                                                                       // Setup - use reflection to access protected constructor and methods
                                                                                                                                                                                       Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                                                                       ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                                       
                                                                                                                                                                                       // Set platform using reflection
                                                                                                                                                                                       Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                       setPlatformMethod.setAccessible(true);
                                                                                                                                                                                       setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                                       
                                                                                                                                                                                       String testName = "path\\\\with/both\\\\slashes";
                                                                                                                                                                                       
                                                                                                                                                                                       // Execute - use reflection to call protected setName method
                                                                                                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                       setNameMethod.setAccessible(true);
                                                                                                                                                                                       setNameMethod.invoke(entry, testName);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify - original would convert all backslashes to forward slashes
                                                                                                                                                                                       // Mutant would leave the name unchanged
                                                                                                                                                                                       assertEquals("Original should convert all backslashes to forward slashes",
                                                                                                                                                                                                   "path/with/both/slashes", entry.getName());
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testSetNameWithSlashes() throws Exception {
                                                                                                                                                                                       // Create test entry using a constructor that exists
                                                                                                                                                                                       ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                       
                                                                                                                                                                                       // Get the protected setName(String, byte[]) method via reflection
                                                                                                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                                                                           "setName", String.class, byte[].class);
                                                                                                                                                                                       setNameMethod.setAccessible(true);
                                                                                                                                                                                       
                                                                                                                                                                                       // Test with forward slash - should be rejected by original but allowed by mutant
                                                                                                                                                                                       try {
                                                                                                                                                                                           setNameMethod.invoke(entry, "test/name", "test/name".getBytes());
                                                                                                                                                                                           // If we get here, the mutant survived (wrong behavior)
                                                                                                                                                                                           fail("Should have thrown IllegalArgumentException for name with forward slash");
                                                                                                                                                                                       } catch (InvocationTargetException e) {
                                                                                                                                                                                           if (!(e.getCause() instanceof IllegalArgumentException)) {
                                                                                                                                                                                               fail("Expected IllegalArgumentException but got " + e.getCause().getClass());
                                                                                                                                                                                           }
                                                                                                                                                                                           // Expected behavior for original code
                                                                                                                                                                                       }
                                                                                                                                                                                       
                                                                                                                                                                                       // Test with backslash - may be rejected by mutant but allowed by original
                                                                                                                                                                                       try {
                                                                                                                                                                                           setNameMethod.invoke(entry, "test\\name", "test\\name".getBytes());
                                                                                                                                                                                           // This might pass for original but fail for mutant
                                                                                                                                                                                           // We need to verify the name was actually set
                                                                                                                                                                                           assertEquals("test\\name", entry.getName());
                                                                                                                                                                                       } catch (InvocationTargetException e) {
                                                                                                                                                                                           // If we get here, the mutant is catching backslashes (wrong behavior)
                                                                                                                                                                                           fail("Should not throw IllegalArgumentException for name with backslash");
                                                                                                                                                                                       }
                                                                                                                                                                                       
                                                                                                                                                                                       // Test with no slashes - should be allowed by both
                                                                                                                                                                                       setNameMethod.invoke(entry, "normalname", "normalname".getBytes());
                                                                                                                                                                                       assertEquals("normalname", entry.getName());
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                              public void testSetName_ConvertsBackslashesToForwardSlashesOnFatPlatform() throws Exception {
                                                                                                                                                                                  // Arrange
                                                                                                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                                                                                                                                  // Use reflection to access protected setPlatform method
                                                                                                                                                                                  Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                                  setPlatformMethod.setAccessible(true);
                                                                                                                                                                                  setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT); // Set platform to FAT
                                                                                                                                                                                  
                                                                                                                                                                                  String inputName = "path\\\\to\\\\file.txt"; // Contains backslashes
                                                                                                                                                                                  
                                                                                                                                                                                  // Act
                                                                                                                                                                                  // Use reflection to access protected setName method
                                                                                                                                                                                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                                  setNameMethod.setAccessible(true);
                                                                                                                                                                                  setNameMethod.invoke(entry, inputName);
                                                                                                                                                                                  
                                                                                                                                                                                  // Assert
                                                                                                                                                                                  String expectedName = "path/to/file.txt"; // Should convert \\ to /
                                                                                                                                                                                  assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                                                                                                                                                              expectedName, 
                                                                                                                                                                                              entry.getName());
                                                                                                                                                                              }

    @Test
                                                                                                                                                                              public void testSetNameWithDifferentPathSeparators() throws Exception {
                                                                                                                                                                                  // Create test object using accessible constructor
                                                                                                                                                                                  ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                                  
                                                                                                                                                                                  // Get the protected setName method via reflection
                                                                                                                                                                                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                                                                      "setName", String.class, byte[].class);
                                                                                                                                                                                  setNameMethod.setAccessible(true);
                                                                                                                                                                                  
                                                                                                                                                                                  // Test case with backslashes (Windows-style path)
                                                                                                                                                                                  String windowsPath = "dir\\\\subdir\\\\file.txt";
                                                                                                                                                                                  byte[] rawName1 = new byte[]{1, 2, 3};
                                                                                                                                                                                  setNameMethod.invoke(entry, windowsPath, rawName1);
                                                                                                                                                                                  assertEquals("Backslashes should be converted to forward slashes", 
                                                                                                                                                                                      "dir/subdir/file.txt", entry.getName());
                                                                                                                                                                                  assertArrayEquals("rawName should be set as-is", 
                                                                                                                                                                                      rawName1, entry.getRawName());
                                                                                                                                                                                  
                                                                                                                                                                                  // Test case with forward slashes (Unix-style path)
                                                                                                                                                                                  String unixPath = "dir/subdir/file.txt";
                                                                                                                                                                                  byte[] rawName2 = new byte[]{4, 5, 6};
                                                                                                                                                                                  setNameMethod.invoke(entry, unixPath, rawName2);
                                                                                                                                                                                  assertEquals("Forward slashes should remain unchanged", 
                                                                                                                                                                                      unixPath, entry.getName());
                                                                                                                                                                                  assertArrayEquals("rawName should be set as-is", 
                                                                                                                                                                                      rawName2, entry.getRawName());
                                                                                                                                                                                  
                                                                                                                                                                                  // Test case with mixed slashes
                                                                                                                                                                                  String mixedPath = "dir\\\\subdir/file.txt";
                                                                                                                                                                                  byte[] rawName3 = new byte[]{7, 8, 9};
                                                                                                                                                                                  setNameMethod.invoke(entry, mixedPath, rawName3);
                                                                                                                                                                                  assertEquals("All backslashes should be converted to forward slashes", 
                                                                                                                                                                                      "dir/subdir/file.txt", entry.getName());
                                                                                                                                                                                  assertArrayEquals("rawName should be set as-is", 
                                                                                                                                                                                      rawName3, entry.getRawName());
                                                                                                                                                                                  
                                                                                                                                                                                  // Test case with no slashes
                                                                                                                                                                                  String noSlashes = "filename.txt";
                                                                                                                                                                                  byte[] rawName4 = new byte[]{10, 11, 12};
                                                                                                                                                                                  setNameMethod.invoke(entry, noSlashes, rawName4);
                                                                                                                                                                                  assertEquals("Name without slashes should remain unchanged", 
                                                                                                                                                                                      noSlashes, entry.getName());
                                                                                                                                                                                  assertArrayEquals("rawName should be set as-is", 
                                                                                                                                                                                      rawName4, entry.getRawName());
                                                                                                                                                                              }

    @Test
                                                                                                                                                                         public void testSetNameShouldReplaceBackslashesWithForwardSlashesOnFatPlatform() throws Exception {
                                                                                                                                                                             // Setup
                                                                                                                                                                             ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                                                                                                                             // Use reflection to access protected setPlatform method
                                                                                                                                                                             Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                             setPlatformMethod.setAccessible(true);
                                                                                                                                                                             setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                             String inputName = "folder\\\\subfolder\\\\file.txt";
                                                                                                                                                                             
                                                                                                                                                                             // Execute
                                                                                                                                                                             // Use reflection to access protected setName method
                                                                                                                                                                             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                             setNameMethod.setAccessible(true);
                                                                                                                                                                             setNameMethod.invoke(entry, inputName);
                                                                                                                                                                             
                                                                                                                                                                             // Verify
                                                                                                                                                                             String expected = "folder/subfolder/file.txt";
                                                                                                                                                                             String actual = entry.getName();
                                                                                                                                                                             assertEquals("Backslashes should be replaced with forward slashes on FAT platform", 
                                                                                                                                                                                          expected, actual);
                                                                                                                                                                         }

    @Test
                                                                                                                                                                         public void testSetNameWithBackslashes() throws Exception {
                                                                                                                                                                             // Setup
                                                                                                                                                                             // Use reflection to access protected constructor
                                                                                                                                                                             Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                                             ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                             
                                                                                                                                                                             String inputName = "path\\\\to\\\\file.txt";
                                                                                                                                                                             byte[] rawName = new byte[]{'p','a','t','h','\\','t','o','\\','f','i','l','e','.','t','x','t'};
                                                                                                                                                                             
                                                                                                                                                                             // Use reflection to access protected setName(String, byte[]) method
                                                                                                                                                                             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                             setNameMethod.setAccessible(true);
                                                                                                                                                                             
                                                                                                                                                                             // Execute
                                                                                                                                                                             setNameMethod.invoke(entry, inputName, rawName);
                                                                                                                                                                             
                                                                                                                                                                             // Verify
                                                                                                                                                                             // Original should convert \\ to / in name but keep rawName unchanged
                                                                                                                                                                             assertEquals("path/to/file.txt", entry.getName());
                                                                                                                                                                             assertArrayEquals(rawName, entry.getRawName());
                                                                                                                                                                             
                                                                                                                                                                             // Additional verification that platform is set correctly
                                                                                                                                                                             assertEquals(ZipArchiveEntry.PLATFORM_UNIX, entry.getPlatform());
                                                                                                                                                                         }

    @Test
                                                                                                                                                                    public void testSetName_ShouldReplaceBackslashesWithForwardSlashesOnFatPlatform() throws Exception {
                                                                                                                                                                        // Setup
                                                                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected setPlatform method
                                                                                                                                                                        Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                        setPlatformMethod.setAccessible(true);
                                                                                                                                                                        setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                        
                                                                                                                                                                        String inputName = "path\\\\to\\\\file.txt";
                                                                                                                                                                        String expectedName = "path/to/file.txt";
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access protected setName method
                                                                                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                        setNameMethod.setAccessible(true);
                                                                                                                                                                        setNameMethod.invoke(entry, inputName);
                                                                                                                                                                        
                                                                                                                                                                        // Verify
                                                                                                                                                                        assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                                                                                                                                                    expectedName, 
                                                                                                                                                                                    entry.getName());
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testSetNameWithBackslashes1() throws Exception {
                                                                                                                                                                        // Create a new ZipArchiveEntry using reflection to access protected constructor
                                                                                                                                                                        Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                        ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                        
                                                                                                                                                                        // Test string with backslashes
                                                                                                                                                                        String inputName = "path\\\\to\\\\file.txt";
                                                                                                                                                                        byte[] rawName = new byte[0];
                                                                                                                                                                        
                                                                                                                                                                        // Call the protected method under test using reflection
                                                                                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                        setNameMethod.setAccessible(true);
                                                                                                                                                                        setNameMethod.invoke(entry, inputName, rawName);
                                                                                                                                                                        
                                                                                                                                                                        // Verify the name has backslashes replaced with forward slashes
                                                                                                                                                                        assertEquals("Path separators should be normalized to forward slashes", 
                                                                                                                                                                                     "path/to/file.txt", entry.getName());
                                                                                                                                                                        
                                                                                                                                                                        // Verify rawName was set correctly using reflection to access getRawName()
                                                                                                                                                                        Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                                                                                                                                                        getRawNameMethod.setAccessible(true);
                                                                                                                                                                        byte[] actualRawName = (byte[]) getRawNameMethod.invoke(entry);
                                                                                                                                                                        assertSame("Raw name should be set as provided", rawName, actualRawName);
                                                                                                                                                                    }

    @Test
                                                                                                                                                               public void testSetNameShouldReplaceBackslashesOnFatPlatform() throws Exception {
                                                                                                                                                                   // Setup - using the protected constructor via reflection
                                                                                                                                                                   Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                                                   ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                   
                                                                                                                                                                   // Set platform to FAT using reflection since setPlatform is protected
                                                                                                                                                                   Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                   setPlatformMethod.setAccessible(true);
                                                                                                                                                                   setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                   
                                                                                                                                                                   // Test input with backslashes
                                                                                                                                                                   String inputName = "folder\\\\subfolder\\\\file.txt";
                                                                                                                                                                   
                                                                                                                                                                   // Execute - using reflection since setName is protected
                                                                                                                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                   setNameMethod.setAccessible(true);
                                                                                                                                                                   setNameMethod.invoke(entry, inputName);
                                                                                                                                                                   
                                                                                                                                                                   // Verify
                                                                                                                                                                   // Original should replace backslashes with forward slashes
                                                                                                                                                                   // Mutant will keep backslashes
                                                                                                                                                                   assertEquals("folder/subfolder/file.txt", entry.getName());
                                                                                                                                                                   
                                                                                                                                                                   // Additional verification that the raw name is set properly
                                                                                                                                                                   assertNotNull(entry.getRawName());
                                                                                                                                                               }

    @Test
                                                                                                                                                               public void testSetNameShouldReplaceBackslashesOnFatPlatform1() throws Exception {
                                                                                                                                                                   // Setup
                                                                                                                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                                   // Set platform to FAT using reflection since setPlatform is protected
                                                                                                                                                                   Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                   setPlatformMethod.setAccessible(true);
                                                                                                                                                                   setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                   
                                                                                                                                                                   // Get the protected setName method
                                                                                                                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                                   setNameMethod.setAccessible(true);
                                                                                                                                                                   
                                                                                                                                                                   // Test input with backslashes
                                                                                                                                                                   String inputName = "folder\\\\subfolder\\\\file.txt";
                                                                                                                                                                   String expectedName = "folder/subfolder/file.txt";
                                                                                                                                                                   
                                                                                                                                                                   // Execute
                                                                                                                                                                   setNameMethod.invoke(entry, inputName);
                                                                                                                                                                   
                                                                                                                                                                   // Verify
                                                                                                                                                                   assertEquals(expectedName, entry.getName());
                                                                                                                                                               }

    @Test
                                                                                                                                                               public void testSetNameWithRawNameShouldSetRawNameWhenPlatformIsFAT() throws Exception {
                                                                                                                                                                   // Setup
                                                                                                                                                                   // Use protected constructor via reflection
                                                                                                                                                                   Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                                                   ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                                   
                                                                                                                                                                   // Use reflection to set platform since setPlatform is protected
                                                                                                                                                                   Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                                   setPlatformMethod.setAccessible(true);
                                                                                                                                                                   setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                                   
                                                                                                                                                                   String name = "test.txt";
                                                                                                                                                                   byte[] rawName = new byte[]{'t', 'e', 's', 't', '.', 't', 'x', 't'};
                                                                                                                                                                   
                                                                                                                                                                   // Execute
                                                                                                                                                                   // Use reflection to call protected setName(String, byte[]) method
                                                                                                                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                                   setNameMethod.setAccessible(true);
                                                                                                                                                                   setNameMethod.invoke(entry, name, rawName);
                                                                                                                                                                   
                                                                                                                                                                   // Verify
                                                                                                                                                                   assertArrayEquals("rawName should be set when platform is FAT", 
                                                                                                                                                                                    rawName, 
                                                                                                                                                                                    entry.getRawName());
                                                                                                                                                               }

    @Test
                                                                                                                                                          public void testSetNameShouldNotReplaceBackslashesWhenPlatformIsNotFat() throws Exception {
                                                                                                                                                              // Create a real ZipArchiveEntry instance using reflection to access protected constructor
                                                                                                                                                              Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                              constructor.setAccessible(true);
                                                                                                                                                              ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                                              
                                                                                                                                                              // Set platform to UNIX (not FAT) using reflection since setPlatform is protected
                                                                                                                                                              Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                              setPlatformMethod.setAccessible(true);
                                                                                                                                                              int PLATFORM_UNIX = 3; // Assuming this is the value for UNIX platform
                                                                                                                                                              setPlatformMethod.invoke(entry, PLATFORM_UNIX);
                                                                                                                                                              
                                                                                                                                                              // Test name with backslashes
                                                                                                                                                              String nameWithBackslashes = "path\\\\to\\\\file";
                                                                                                                                                              
                                                                                                                                                              // Call the setName method using reflection since it's protected
                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                              setNameMethod.invoke(entry, nameWithBackslashes);
                                                                                                                                                              
                                                                                                                                                              // Verify the name wasn't modified (backslashes not replaced)
                                                                                                                                                              assertEquals("Name with backslashes should remain unchanged when platform is not FAT", 
                                                                                                                                                                          nameWithBackslashes, entry.getName());
                                                                                                                                                          }

    @Test
                                                                                                                                                          public void testSetNameWithRawName_NonFatPlatform_ShouldNotSetRawName() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using constructor with name parameter
                                                                                                                                                              String testName = "test.txt";
                                                                                                                                                              byte[] testRawName = new byte[]{'t', 'e', 's', 't'};
                                                                                                                                                              
                                                                                                                                                              // Use reflection to set platform since it's protected
                                                                                                                                                              Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                              setPlatformMethod.setAccessible(true);
                                                                                                                                                              setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                                                                              
                                                                                                                                                              // Act - use reflection to call protected setName method
                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                              setNameMethod.invoke(entry, testName, testRawName);
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertNull("rawName should not be set when platform is not FAT", entry.getRawName());
                                                                                                                                                              assertEquals("name should be set", testName, entry.getName());
                                                                                                                                                          }

    @Test
                                                                                                                                                          public void testSetNameWithRawName_FatPlatform_ShouldSetRawName() throws Exception {
                                                                                                                                                              // Arrange
                                                                                                                                                              ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                                                              String testName = "test.txt";
                                                                                                                                                              byte[] testRawName = new byte[]{'t', 'e', 's', 't'};
                                                                                                                                                              
                                                                                                                                                              // Use reflection to access protected methods
                                                                                                                                                              Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                              setPlatformMethod.setAccessible(true);
                                                                                                                                                              setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                              
                                                                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                              setNameMethod.setAccessible(true);
                                                                                                                                                              
                                                                                                                                                              // Act
                                                                                                                                                              setNameMethod.invoke(entry, testName, testRawName);
                                                                                                                                                              
                                                                                                                                                              // Assert
                                                                                                                                                              assertArrayEquals("rawName should be set when platform is FAT", 
                                                                                                                                                                               testRawName, entry.getRawName());
                                                                                                                                                              assertEquals("name should be set", testName, entry.getName());
                                                                                                                                                          }

    @Test
                                                                                                                                                     public void testSetNameWithSlashShouldNotSetRawName() {
                                                                                                                                                         // Create test objects using protected constructor via reflection
                                                                                                                                                         ZipArchiveEntry entry;
                                                                                                                                                         try {
                                                                                                                                                             Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                             entry = constructor.newInstance();
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         String nameWithSlash = "test/name";
                                                                                                                                                         byte[] rawName = new byte[]{1, 2, 3};
                                                                                                                                                         
                                                                                                                                                         // Call the protected method via reflection
                                                                                                                                                         try {
                                                                                                                                                             Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                             setNameMethod.setAccessible(true);
                                                                                                                                                             setNameMethod.invoke(entry, nameWithSlash, rawName);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             throw new RuntimeException("Failed to invoke setName method", e);
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         // Verify behavior - original would not set rawName for names with "/"
                                                                                                                                                         assertNull("rawName should not be set when name contains '/'", 
                                                                                                                                                                   entry.getRawName());
                                                                                                                                                         
                                                                                                                                                         // Additional verification that name was set properly
                                                                                                                                                         assertEquals("Name should still be set", nameWithSlash, entry.getName());
                                                                                                                                                     }

    @Test
                                                                                                                                                 public void testSetNameShouldReplaceBackslashesWhenNoForwardSlashPresent() {
                                                                                                                                                     // Setup
                                                                                                                                                     ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                                     try {
                                                                                                                                                         // Use reflection to access protected setPlatform method
                                                                                                                                                         Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                         setPlatformMethod.setAccessible(true);
                                                                                                                                                         setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to access protected setName method
                                                                                                                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                         setNameMethod.setAccessible(true);
                                                                                                                                                         
                                                                                                                                                         String inputName = "path\\\\\\\\to\\\\\\\\file";
                                                                                                                                                         
                                                                                                                                                         // Execute
                                                                                                                                                         setNameMethod.invoke(entry, inputName);
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         String expected = "path/to/file";
                                                                                                                                                         String actual = entry.getName();
                                                                                                                                                         assertEquals("Backslashes should be replaced when no forward slash present", 
                                                                                                                                                                     expected, actual);
                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                         fail("Failed to set name via reflection: " + e.getMessage());
                                                                                                                                                     }
                                                                                                                                                 }

    @Test
                                                                                                                                            public void testSetName_ShouldNotReplaceBackslashesWhenForwardSlashesExist() {
                                                                                                                                                // Setup
                                                                                                                                                ZipArchiveEntry entry = new ZipArchiveEntry("dummyName");
                                                                                                                                                
                                                                                                                                                // Use reflection to access protected setPlatform method
                                                                                                                                                try {
                                                                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to set platform via reflection: " + e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                String inputName = "path\\\\with/mixed/slashes";
                                                                                                                                                
                                                                                                                                                // Execute - use reflection to access protected setName method
                                                                                                                                                try {
                                                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                                                    setNameMethod.invoke(entry, inputName);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to set name via reflection: " + e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Verify
                                                                                                                                                // Original behavior: Should keep original name since forward slashes exist
                                                                                                                                                // Mutated behavior: Would replace backslashes even with forward slashes
                                                                                                                                                assertEquals("Original name should be kept when forward slashes exist", 
                                                                                                                                                            inputName, entry.getName());
                                                                                                                                            }

    @Test
                                                                                                                                            public void testSetNameWithSlashShouldNotSetRawName1() {
                                                                                                                                                // Create a test entry using the protected constructor via reflection
                                                                                                                                                ZipArchiveEntry entry;
                                                                                                                                                try {
                                                                                                                                                    Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                    entry = constructor.newInstance();
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Prepare test data with slash in name
                                                                                                                                                String nameWithSlash = "test/name";
                                                                                                                                                byte[] rawName = new byte[]{1, 2, 3};
                                                                                                                                                
                                                                                                                                                // Call the protected method via reflection
                                                                                                                                                try {
                                                                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                                    setNameMethod.setAccessible(true);
                                                                                                                                                    setNameMethod.invoke(entry, nameWithSlash, rawName);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    throw new RuntimeException("Failed to invoke setName method", e);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Verify rawName was NOT set (original behavior)
                                                                                                                                                // The mutant would set rawName while original wouldn't
                                                                                                                                                assertNull("rawName should not be set when name contains '/'", 
                                                                                                                                                          entry.getRawName());
                                                                                                                                                
                                                                                                                                                // Also verify name field was set (both versions should do this)
                                                                                                                                                assertEquals("Name should be set regardless of content",
                                                                                                                                                           nameWithSlash, entry.getName());
                                                                                                                                            }

    @Test
                                                                                                                                       public void testSetName_ShouldReplaceBackslashesOnFatPlatform() throws Exception {
                                                                                                                                           // Setup - using protected constructor
                                                                                                                                           Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                           ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                           
                                                                                                                                           // Use reflection to set platform to FAT since setPlatform is protected
                                                                                                                                           Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                                                                                                                           platformField.setAccessible(true);
                                                                                                                                           platformField.set(entry, 0); // PLATFORM_FAT is typically 0
                                                                                                                                           
                                                                                                                                           String inputName = "folder\\\\subfolder\\\\file.txt";
                                                                                                                                           String expectedName = "folder/subfolder/file.txt";
                                                                                                                                           
                                                                                                                                           // Execute - using protected setName method
                                                                                                                                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                           setNameMethod.setAccessible(true);
                                                                                                                                           setNameMethod.invoke(entry, inputName);
                                                                                                                                           
                                                                                                                                           // Verify
                                                                                                                                           assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                                                                                                                       expectedName, entry.getName());
                                                                                                                                       }

    @Test
                                                                                                                                       public void testSetNameShouldReplaceBackslashesWithForwardSlashes() throws Exception {
                                                                                                                                           // Arrange
                                                                                                                                           ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                                           String inputName = "path\\\\to\\\\file.txt";
                                                                                                                                           byte[] rawName = new byte[0];
                                                                                                                                           
                                                                                                                                           // Get the protected setName method via reflection
                                                                                                                                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                               "setName", String.class, byte[].class);
                                                                                                                                           setNameMethod.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Act
                                                                                                                                           setNameMethod.invoke(entry, inputName, rawName);
                                                                                                                                           
                                                                                                                                           // Assert
                                                                                                                                           // Original behavior should convert backslashes to forward slashes
                                                                                                                                           assertEquals("path/to/file.txt", entry.getName());
                                                                                                                                           // Also verify rawName was set correctly
                                                                                                                                           assertSame(rawName, entry.getRawName());
                                                                                                                                       }

    @Test
                                                                                                                                       public void testSetNameWithNoBackslashesRemainsUnchanged() {
                                                                                                                                           // Arrange
                                                                                                                                           ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                                           String inputName = "path/to/file.txt";
                                                                                                                                           byte[] rawName = new byte[0];
                                                                                                                                           
                                                                                                                                           // Act - Need to use reflection to access protected method
                                                                                                                                           try {
                                                                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                               setNameMethod.setAccessible(true);
                                                                                                                                               setNameMethod.invoke(entry, inputName, rawName);
                                                                                                                                           } catch (Exception e) {
                                                                                                                                               fail("Failed to invoke protected setName method: " + e.getMessage());
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           // Assert
                                                                                                                                           assertEquals(inputName, entry.getName());
                                                                                                                                           assertSame(rawName, entry.getRawName());
                                                                                                                                       }

    @Test
                                                                                                                                       public void testSetNameWithMultipleBackslashes() throws Exception {
                                                                                                                                           // Arrange
                                                                                                                                           ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                                           String inputName = "path\\\\\\\\to\\\\\\\\file.txt";
                                                                                                                                           byte[] rawName = new byte[0];
                                                                                                                                           
                                                                                                                                           // Use reflection to access protected setName(String, byte[]) method
                                                                                                                                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                               "setName", String.class, byte[].class);
                                                                                                                                           setNameMethod.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Act
                                                                                                                                           setNameMethod.invoke(entry, inputName, rawName);
                                                                                                                                           
                                                                                                                                           // Assert
                                                                                                                                           assertEquals("path//to//file.txt", entry.getName());
                                                                                                                                           assertSame(rawName, entry.getRawName());
                                                                                                                                       }

    @Test
                                                                                                                                  public void testSetName_ShouldConvertBackslashesOnlyWhenPlatformIsFAT() throws Exception {
                                                                                                                                      // Setup - use public constructor with a dummy name
                                                                                                                                      ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                                      
                                                                                                                                      // Get protected methods via reflection
                                                                                                                                      Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                      setPlatformMethod.setAccessible(true);
                                                                                                                                      
                                                                                                                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                      setNameMethod.setAccessible(true);
                                                                                                                                      
                                                                                                                                      // Get platform constants via reflection
                                                                                                                                      Field platformFatField = ZipArchiveEntry.class.getDeclaredField("PLATFORM_FAT");
                                                                                                                                      platformFatField.setAccessible(true);
                                                                                                                                      int PLATFORM_FAT = platformFatField.getInt(null);
                                                                                                                                      
                                                                                                                                      Field platformUnixField = ZipArchiveEntry.class.getDeclaredField("PLATFORM_UNIX");
                                                                                                                                      platformUnixField.setAccessible(true);
                                                                                                                                      int PLATFORM_UNIX = platformUnixField.getInt(null);
                                                                                                                                      
                                                                                                                                      // Case 1: Platform is FAT (should convert backslashes)
                                                                                                                                      setPlatformMethod.invoke(entry, PLATFORM_FAT);
                                                                                                                                      String nameWithBackslashes = "path\\\\to\\\\file";
                                                                                                                                      setNameMethod.invoke(entry, nameWithBackslashes);
                                                                                                                                      assertEquals("path/to/file", entry.getName());
                                                                                                                                      
                                                                                                                                      // Case 2: Platform is 0 (should NOT convert backslashes in original)
                                                                                                                                      setPlatformMethod.invoke(entry, 0);
                                                                                                                                      setNameMethod.invoke(entry, nameWithBackslashes);
                                                                                                                                      assertEquals("path\\\\to\\\\file", entry.getName());
                                                                                                                                      
                                                                                                                                      // Case 3: Platform is UNIX (should NOT convert backslashes)
                                                                                                                                      setPlatformMethod.invoke(entry, PLATFORM_UNIX);
                                                                                                                                      setNameMethod.invoke(entry, nameWithBackslashes);
                                                                                                                                      assertEquals("path\\\\to\\\\file", entry.getName());
                                                                                                                                  }

    @Test
                                                                                                                                  public void testSetNameWithRawNameWhenPlatformIsFAT() throws Exception {
                                                                                                                                      // Create a real ZipArchiveEntry using reflection to access protected constructor
                                                                                                                                      Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                      constructor.setAccessible(true);
                                                                                                                                      ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                      
                                                                                                                                      // Set up the platform to be FAT using reflection
                                                                                                                                      Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                      setPlatformMethod.setAccessible(true);
                                                                                                                                      setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                      
                                                                                                                                      // Prepare test data
                                                                                                                                      String name = "test.txt";
                                                                                                                                      byte[] rawName = new byte[]{'t', 'e', 's', 't', '.', 't', 'x', 't'};
                                                                                                                                      
                                                                                                                                      // Call the method under test using reflection
                                                                                                                                      Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                      setNameMethod.setAccessible(true);
                                                                                                                                      setNameMethod.invoke(entry, name, rawName);
                                                                                                                                      
                                                                                                                                      // Verify rawName was set (would fail with mutant)
                                                                                                                                      assertArrayEquals(rawName, entry.getRawName());
                                                                                                                                      
                                                                                                                                      // Also verify name was set
                                                                                                                                      assertEquals(name, entry.getName());
                                                                                                                                  }

    @Test
                                                                                                                             public void testSetName_ShouldConvertBackslashesWhenPlatformIsFAT() {
                                                                                                                                 // Setup
                                                                                                                                 ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                                                                                 // Use reflection to set platform since setPlatform is protected
                                                                                                                                 try {
                                                                                                                                     Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                     setPlatform.setAccessible(true);
                                                                                                                                     setPlatform.invoke(entry, 0); // PLATFORM_FAT is typically 0
                                                                                                                                 } catch (Exception e) {
                                                                                                                                     fail("Failed to set platform via reflection");
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 String inputName = "path\\\\to\\\\file";
                                                                                                                                 String expectedName = "path/to/file";
                                                                                                                                 
                                                                                                                                 // Execute
                                                                                                                                 try {
                                                                                                                                     Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                                     setName.setAccessible(true);
                                                                                                                                     setName.invoke(entry, inputName);
                                                                                                                                 } catch (Exception e) {
                                                                                                                                     fail("Failed to invoke setName via reflection");
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                                                                                                             expectedName, entry.getName());
                                                                                                                             }

    @Test
                                                                                                                             public void testSetNameWithPlatformFat() throws Exception {
                                                                                                                                 // Create a test instance using the protected constructor via reflection
                                                                                                                                 Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                 ZipArchiveEntry entry = constructor.newInstance();
                                                                                                                                 
                                                                                                                                 // Set platform to FAT (using reflection since setPlatform is protected)
                                                                                                                                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                                                 setPlatform.setAccessible(true);
                                                                                                                                 setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                                 
                                                                                                                                 // Test data
                                                                                                                                 String testName = "test.txt";
                                                                                                                                 byte[] testRawName = testName.getBytes();
                                                                                                                                 
                                                                                                                                 // Call the protected method under test using reflection
                                                                                                                                 Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                 setName.setAccessible(true);
                                                                                                                                 setName.invoke(entry, testName, testRawName);
                                                                                                                                 
                                                                                                                                 // Verify the rawName was set (this would fail with the mutant)
                                                                                                                                 assertArrayEquals("Raw name should be set when platform is FAT", 
                                                                                                                                                  testRawName, entry.getRawName());
                                                                                                                                 
                                                                                                                                 // Also verify the name field was set
                                                                                                                                 assertEquals("Name should be set", testName, entry.getName());
                                                                                                                             }

    @Test
                                                                                                                        public void testSetNameWithSlashAtStartShouldBeRejected() {
                                                                                                                            // Use reflection to access protected constructor
                                                                                                                            ZipArchiveEntry entry;
                                                                                                                            try {
                                                                                                                                Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                                constructor.setAccessible(true);
                                                                                                                                entry = constructor.newInstance();
                                                                                                                            } catch (Exception e) {
                                                                                                                                throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
                                                                                                                            }
                                                                                                                            
                                                                                                                            String nameWithSlashAtStart = "/path/to/file";
                                                                                                                            byte[] rawName = new byte[0];
                                                                                                                            
                                                                                                                            // Use reflection to access protected setName method
                                                                                                                            try {
                                                                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                setNameMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // This should throw an exception in original code but pass in mutated code
                                                                                                                                try {
                                                                                                                                    setNameMethod.invoke(entry, nameWithSlashAtStart, rawName);
                                                                                                                                    // If we get here, the mutant survived (bad)
                                                                                                                                    fail("Expected IllegalArgumentException for name starting with '/'");
                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                    // Check if the cause is IllegalArgumentException
                                                                                                                                    if (e.getCause() instanceof IllegalArgumentException) {
                                                                                                                                        // This is expected behavior for original code
                                                                                                                                        assertTrue(true);
                                                                                                                                    } else {
                                                                                                                                        throw e;
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            } catch (Exception e) {
                                                                                                                                throw new RuntimeException("Failed to invoke setName method", e);
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                        public void testSetNameWithSlashNotAtStartShouldBeRejected() {
                                                                                                                            // Create entry with a dummy name since no-arg constructor is protected
                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                            String nameWithSlashInside = "path/to/file";
                                                                                                                            byte[] rawName = new byte[0];
                                                                                                                            
                                                                                                                            try {
                                                                                                                                // Use reflection to access protected setName(String, byte[]) method
                                                                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                                                    "setName", String.class, byte[].class);
                                                                                                                                setNameMethod.setAccessible(true);
                                                                                                                                setNameMethod.invoke(entry, nameWithSlashInside, rawName);
                                                                                                                                fail("Expected IllegalArgumentException for name containing '/'");
                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                assertTrue(true);
                                                                                                                            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                                                                                                fail("Failed to access setName method via reflection: " + e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                        public void testSetNameWithoutSlashesShouldBeAccepted() {
                                                                                                                            ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                                                                                                            String validName = "validFileName";
                                                                                                                            byte[] rawName = new byte[0];
                                                                                                                            
                                                                                                                            // Use reflection to access protected setName(String, byte[]) method
                                                                                                                            try {
                                                                                                                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                                setNameMethod.setAccessible(true);
                                                                                                                                setNameMethod.invoke(entry, validName, rawName);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to invoke protected setName method via reflection");
                                                                                                                            }
                                                                                                                            
                                                                                                                            assertEquals(validName, entry.getName());
                                                                                                                            assertArrayEquals(rawName, entry.getRawName());
                                                                                                                        }

    @Test
                                                                                                                    public void testSetNameWithBackslashesAndNoForwardSlash() {
                                                                                                                        // This should be modified in original but not in mutant
                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                                                        String input = "path\\\\\\\\to\\\\\\\\file";
                                                                                                                        String expectedOriginal = "path/to/file";
                                                                                                                        String expectedMutant = input; // No change in mutant
                                                                                                                        
                                                                                                                        // Use reflection to access protected setName method
                                                                                                                        try {
                                                                                                                            Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                            setNameMethod.setAccessible(true);
                                                                                                                            setNameMethod.invoke(entry, input);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to invoke setName method via reflection: " + e.getMessage());
                                                                                                                        }
                                                                                                                        
                                                                                                                        // This assertion will fail for the mutant, detecting it
                                                                                                                        assertEquals("Backslashes should be replaced when no forward slash exists", 
                                                                                                                                    expectedOriginal, entry.getName());
                                                                                                                    }

    @Test
                                                                                                                    public void testSetNameWithBackslashesAndNonStartingForwardSlash() throws Exception {
                                                                                                                        // Create a new ZipArchiveEntry instance
                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("testEntry");
                                                                                                                        
                                                                                                                        // This should be modified in original but not in mutant
                                                                                                                        String input = "path\\\\\\\\to/file";
                                                                                                                        String expectedOriginal = "path/to/file";
                                                                                                                        String expectedMutant = input; // No change in mutant
                                                                                                                        
                                                                                                                        // Use reflection to access protected setName method
                                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                        setNameMethod.setAccessible(true);
                                                                                                                        setNameMethod.invoke(entry, input);
                                                                                                                        
                                                                                                                        // This assertion will fail for the mutant, detecting it
                                                                                                                        assertEquals("Backslashes should be replaced when forward slash not at start", 
                                                                                                                                    expectedOriginal, entry.getName());
                                                                                                                    }

    @Test
                                                                                                                    public void testSetNameWithStartingForwardSlash() throws Exception {
                                                                                                                        // Shouldn't be modified in either original or mutant
                                                                                                                        String input = "/path/to/file";
                                                                                                                        ZipArchiveEntry entry = new ZipArchiveEntry(input);
                                                                                                                        
                                                                                                                        // Use reflection to access protected setName method
                                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                        setNameMethod.setAccessible(true);
                                                                                                                        setNameMethod.invoke(entry, input);
                                                                                                                        
                                                                                                                        assertEquals("Name should remain unchanged when starts with forward slash",
                                                                                                                                    input, entry.getName());
                                                                                                                    }

    @Test
                                                                                                               public void testSetNameWithMixedSlashesShouldConvertAllToForwardSlashes() {
                                                                                                                   // Setup - using protected constructor
                                                                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                   // Mock getPlatform to return PLATFORM_FAT
                                                                                                                   ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                   when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                   
                                                                                                                   // Test input with both types of slashes
                                                                                                                   String inputName = "path\\\\to\\\\file/with/mixed/slashes";
                                                                                                                   String expected = "path/to/file/with/mixed/slashes";
                                                                                                                   
                                                                                                                   // Execute - using protected setName method through reflection
                                                                                                                   try {
                                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                       setNameMethod.setAccessible(true);
                                                                                                                       setNameMethod.invoke(spyEntry, inputName);
                                                                                                                   } catch (Exception e) {
                                                                                                                       fail("Failed to invoke setName method: " + e.getMessage());
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Verify
                                                                                                                   assertEquals("All backslashes should be converted to forward slashes", 
                                                                                                                               expected, spyEntry.getName());
                                                                                                               }

    @Test
                                                                                                               public void testSetNameWithOnlyForwardSlashesShouldNotBeModified() {
                                                                                                                   // Setup - use protected constructor via reflection
                                                                                                                   ZipArchiveEntry entry;
                                                                                                                   try {
                                                                                                                       Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                                       constructor.setAccessible(true);
                                                                                                                       entry = constructor.newInstance();
                                                                                                                   } catch (Exception e) {
                                                                                                                       throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Mock getPlatform to return PLATFORM_FAT
                                                                                                                   ZipArchiveEntry spyEntry = spy(entry);
                                                                                                                   when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                                                   
                                                                                                                   // Test input with only forward slashes
                                                                                                                   String inputName = "path/to/file/with/forward/slashes";
                                                                                                                   
                                                                                                                   // Execute - use protected setName method via reflection
                                                                                                                   try {
                                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                                       setNameMethod.setAccessible(true);
                                                                                                                       setNameMethod.invoke(spyEntry, inputName);
                                                                                                                   } catch (Exception e) {
                                                                                                                       throw new RuntimeException("Failed to invoke setName method", e);
                                                                                                                   }
                                                                                                                   
                                                                                                                   // Verify
                                                                                                                   assertEquals("Forward slashes should remain unchanged",
                                                                                                                               inputName, spyEntry.getName());
                                                                                                               }

    @Test
                                                                                                               public void testSetNameWithPathSeparators() throws Exception {
                                                                                                                   // Test with forward slash - should be rejected by original but accepted by mutant
                                                                                                                   try {
                                                                                                                       ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                       setNameMethod.setAccessible(true);
                                                                                                                       setNameMethod.invoke(entry, "invalid/unix/path", null);
                                                                                                                       fail("Should have thrown IllegalArgumentException for forward slash");
                                                                                                                   } catch (InvocationTargetException e) {
                                                                                                                       if (!(e.getCause() instanceof IllegalArgumentException)) {
                                                                                                                           fail("Expected IllegalArgumentException but got " + e.getCause().getClass().getName());
                                                                                                                       }
                                                                                                                       // Expected behavior for original
                                                                                                                   }
                                                                                                               
                                                                                                                   // Test with backslash - should be accepted by original but rejected by mutant
                                                                                                                   try {
                                                                                                                       ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                       setNameMethod.setAccessible(true);
                                                                                                                       setNameMethod.invoke(entry, "valid\\\\windows\\\\path", null);
                                                                                                                       // If we get here, original behavior is correct
                                                                                                                       assertEquals("valid\\\\windows\\\\path", entry.getName());
                                                                                                                   } catch (InvocationTargetException e) {
                                                                                                                       fail("Should not throw exception for backslash in original");
                                                                                                                   }
                                                                                                               
                                                                                                                   // Test with no separators - should be accepted by both
                                                                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                                   setNameMethod.setAccessible(true);
                                                                                                                   setNameMethod.invoke(entry, "normalName", null);
                                                                                                                   assertEquals("normalName", entry.getName());
                                                                                                               }

    @Test
                                                                                                          public void testSetName_ConvertsBackslashesToForwardSlashesOnFatPlatform1() throws Exception {
                                                                                                              // Setup
                                                                                                              // Using protected constructor via reflection
                                                                                                              Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                              constructor.setAccessible(true);
                                                                                                              ZipArchiveEntry entry = constructor.newInstance();
                                                                                                              
                                                                                                              // Use reflection to set platform to FAT since setPlatform is protected
                                                                                                              Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                                                                                              platformField.setAccessible(true);
                                                                                                              platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                              
                                                                                                              String inputName = "path\\\\to\\\\file.txt";
                                                                                                              String expectedName = "path/to/file.txt";
                                                                                                              
                                                                                                              // Test
                                                                                                              // Using protected setName method via reflection
                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                              setNameMethod.setAccessible(true);
                                                                                                              setNameMethod.invoke(entry, inputName);
                                                                                                              
                                                                                                              // Verify
                                                                                                              assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                                                                                          expectedName, 
                                                                                                                          entry.getName());
                                                                                                          }

    @Test
                                                                                                          public void testSetNameWithDifferentPathSeparators1() throws Exception {
                                                                                                              // Create test cases with different path separator combinations
                                                                                                              String unixPath = "path/to/file.txt";
                                                                                                              String windowsPath = "path\\\\to\\\\file.txt";
                                                                                                              String mixedPath = "path/to\\\\file.txt";
                                                                                                              
                                                                                                              // Expected results should all use forward slashes
                                                                                                              String expectedUnix = "path/to/file.txt";
                                                                                                              String expectedWindows = "path/to/file.txt";
                                                                                                              String expectedMixed = "path/to/file.txt";
                                                                                                              
                                                                                                              // Get the protected setName method via reflection
                                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                              setNameMethod.setAccessible(true);
                                                                                                              
                                                                                                              // Test with Unix-style path
                                                                                                              ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                                                                              setNameMethod.invoke(entry1, unixPath, null);
                                                                                                              assertEquals("Unix path should remain unchanged", 
                                                                                                                          expectedUnix, entry1.getName());
                                                                                                              
                                                                                                              // Test with Windows-style path
                                                                                                              ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                                                                              setNameMethod.invoke(entry2, windowsPath, null);
                                                                                                              assertEquals("Windows path should convert to forward slashes", 
                                                                                                                          expectedWindows, entry2.getName());
                                                                                                              
                                                                                                              // Test with mixed path
                                                                                                              ZipArchiveEntry entry3 = new ZipArchiveEntry("");
                                                                                                              setNameMethod.invoke(entry3, mixedPath, null);
                                                                                                              assertEquals("Mixed path should convert to forward slashes", 
                                                                                                                          expectedMixed, entry3.getName());
                                                                                                              
                                                                                                              // Additional test with just backslash
                                                                                                              ZipArchiveEntry entry4 = new ZipArchiveEntry("");
                                                                                                              setNameMethod.invoke(entry4, "\\\\", null);
                                                                                                              assertEquals("Single backslash should convert to forward slash", 
                                                                                                                          "/", entry4.getName());
                                                                                                          }

    @Test
                                                                                                     public void testSetNameShouldConvertBackslashesToForwardSlashesOnFatPlatform() throws Exception {
                                                                                                         // Setup - using protected constructor
                                                                                                         ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                                         
                                                                                                         // Use reflection to set platform to FAT since setPlatform is protected
                                                                                                         Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                                                                                         platformField.setAccessible(true);
                                                                                                         platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                         
                                                                                                         // Test input with backslashes
                                                                                                         String inputName = "path\\\\to\\\\file.txt";
                                                                                                         
                                                                                                         // Execute - using protected setName method
                                                                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                         setNameMethod.setAccessible(true);
                                                                                                         setNameMethod.invoke(entry, inputName);
                                                                                                         
                                                                                                         // Verify
                                                                                                         String expected = "path/to/file.txt";
                                                                                                         String actual = entry.getName();
                                                                                                         assertEquals("Backslashes should be converted to forward slashes on FAT platform", 
                                                                                                                     expected, actual);
                                                                                                         
                                                                                                         // Additional verification that no conversion happens when platform isn't FAT
                                                                                                         platformField.set(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                                                         setNameMethod.invoke(entry, inputName);
                                                                                                         assertEquals("Backslashes should remain unchanged on non-FAT platform",
                                                                                                                     inputName, entry.getName());
                                                                                                     }

    @Test
                                                                                                     public void testSetNameWithBackslashes2() throws Exception {
                                                                                                         // Setup
                                                                                                         // Use reflection to access protected constructor
                                                                                                         Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                         constructor.setAccessible(true);
                                                                                                         ZipArchiveEntry entry = constructor.newInstance();
                                                                                                         
                                                                                                         String inputName = "path\\\\to\\\\file.txt";
                                                                                                         byte[] rawName = new byte[]{'p','a','t','h','\\','t','o','\\','f','i','l','e','.','t','x','t'};
                                                                                                         
                                                                                                         // Execute
                                                                                                         // Use reflection to access protected setName(String, byte[]) method
                                                                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                         setNameMethod.setAccessible(true);
                                                                                                         setNameMethod.invoke(entry, inputName, rawName);
                                                                                                         
                                                                                                         // Verify
                                                                                                         // Original would convert backslashes to forward slashes in name field
                                                                                                         // Mutant would keep backslashes unchanged
                                                                                                         assertEquals("path/to/file.txt", entry.getName());
                                                                                                         
                                                                                                         // Also verify rawName is set correctly
                                                                                                         Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                                                                                         byte[] actualRawName = (byte[]) getRawNameMethod.invoke(entry);
                                                                                                         assertArrayEquals(rawName, actualRawName);
                                                                                                         
                                                                                                         // Additional check to ensure the name field was actually set
                                                                                                         assertNotNull(entry.getName());
                                                                                                     }

    @Test
                                                                                                public void testSetName_ShouldReplaceBackslashesWithForwardSlashesOnFATPlatform() throws Exception {
                                                                                                    // Setup - use reflection to access protected constructor
                                                                                                    Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                    constructor.setAccessible(true);
                                                                                                    ZipArchiveEntry entry = constructor.newInstance();
                                                                                                    
                                                                                                    // Mock platform to FAT using reflection
                                                                                                    Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                                    setPlatformMethod.setAccessible(true);
                                                                                                    setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                                    
                                                                                                    String inputName = "folder\\\\subfolder\\\\file.txt";
                                                                                                    String expectedName = "folder/subfolder/file.txt";
                                                                                                    
                                                                                                    // Execute - use reflection to access protected setName method
                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                                    setNameMethod.setAccessible(true);
                                                                                                    setNameMethod.invoke(entry, inputName);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertEquals("Backslashes should be replaced with forward slashes", 
                                                                                                                expectedName, entry.getName());
                                                                                                }

    @Test
                                                                                                public void testSetNameWithBackslashes3() {
                                                                                                    // Setup
                                                                                                    // Using reflection to access protected constructor
                                                                                                    ZipArchiveEntry entry;
                                                                                                    try {
                                                                                                        Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                                        constructor.setAccessible(true);
                                                                                                        entry = constructor.newInstance();
                                                                                                    } catch (Exception e) {
                                                                                                        throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
                                                                                                    }
                                                                                                    
                                                                                                    String windowsPath = "dir\\\\subdir\\\\file.txt";
                                                                                                    byte[] rawName = new byte[0]; // dummy raw name
                                                                                                    
                                                                                                    // Execute
                                                                                                    // Using reflection to access protected setName(String, byte[]) method
                                                                                                    try {
                                                                                                        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                                        setNameMethod.setAccessible(true);
                                                                                                        setNameMethod.invoke(entry, windowsPath, rawName);
                                                                                                    } catch (Exception e) {
                                                                                                        throw new RuntimeException("Failed to invoke setName method", e);
                                                                                                    }
                                                                                                    
                                                                                                    // Verify
                                                                                                    String storedName = entry.getName();
                                                                                                    // Original behavior: backslashes become forward slashes
                                                                                                    // Mutant behavior: backslashes become spaces
                                                                                                    assertEquals("Path separator should be converted to forward slash", 
                                                                                                                "dir/subdir/file.txt", storedName);
                                                                                                    
                                                                                                    // Additional verification that rawName was set
                                                                                                    assertSame("Raw name should be set", rawName, entry.getRawName());
                                                                                                }

    @Test
                                                                                                public void testSetNameWithMixedSlashes() throws Exception {
                                                                                                    // Setup
                                                                                                    ZipArchiveEntry entry = new ZipArchiveEntry("temp"); // Using public constructor
                                                                                                    String mixedPath = "dir\\\\subdir/file.txt"; // mixed separators
                                                                                                    byte[] rawName = new byte[0];
                                                                                                    
                                                                                                    // Use reflection to access protected setName(String, byte[]) method
                                                                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                        "setName", String.class, byte[].class);
                                                                                                    setNameMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Execute
                                                                                                    setNameMethod.invoke(entry, mixedPath, rawName);
                                                                                                    
                                                                                                    // Verify
                                                                                                    String storedName = entry.getName();
                                                                                                    // Only backslashes should be converted, forward slashes stay
                                                                                                    assertEquals("Only backslashes should be converted", 
                                                                                                                "dir/subdir/file.txt", storedName);
                                                                                                }

    @Test
                                                                                           public void testSetNameShouldReplaceBackslashesOnFatPlatform2() throws Exception {
                                                                                               // Setup
                                                                                               ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using constructor with name parameter
                                                                                               // Set platform to FAT using reflection since setPlatform is protected
                                                                                               Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                               setPlatformMethod.setAccessible(true);
                                                                                               setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                               String inputName = "folder\\\\file.txt";
                                                                                               
                                                                                               // Execute
                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                               setNameMethod.setAccessible(true);
                                                                                               setNameMethod.invoke(entry, inputName);
                                                                                               
                                                                                               // Verify
                                                                                               // Original would replace backslash, mutant wouldn't
                                                                                               assertEquals("folder/file.txt", entry.getName());
                                                                                               
                                                                                               // Additional verification that raw name is set
                                                                                               Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                                                                               getRawNameMethod.setAccessible(true);
                                                                                               assertNotNull(getRawNameMethod.invoke(entry));
                                                                                           }

    @Test
                                                                                           public void testSetNameShouldReplaceBackslashesOnFatPlatform3() throws Exception {
                                                                                               // Setup
                                                                                               ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                                               // Set platform to FAT
                                                                                               Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                                                                               platformField.setAccessible(true);
                                                                                               platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                               
                                                                                               String inputName = "folder\\\\file.txt";
                                                                                               
                                                                                               // Execute - use reflection to call protected setName method
                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                               setNameMethod.setAccessible(true);
                                                                                               setNameMethod.invoke(entry, inputName);
                                                                                               
                                                                                               // Verify - use reflection to check the name field
                                                                                               Field nameField = ZipArchiveEntry.class.getDeclaredField("name");
                                                                                               nameField.setAccessible(true);
                                                                                               assertEquals("folder/file.txt", nameField.get(entry));
                                                                                           }

    @Test
                                                                                           public void testSetNameWithPlatformFAT() throws Exception {
                                                                                               // Setup - use the protected no-arg constructor via reflection
                                                                                               Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                               constructor.setAccessible(true);
                                                                                               ZipArchiveEntry entry = constructor.newInstance();
                                                                                               
                                                                                               String testName = "test.txt";
                                                                                               byte[] testRawName = testName.getBytes();
                                                                                               
                                                                                               // Set platform to FAT using reflection
                                                                                               Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                                               setPlatformMethod.setAccessible(true);
                                                                                               setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                               
                                                                                               // Call setName method using reflection
                                                                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                                               setNameMethod.setAccessible(true);
                                                                                               setNameMethod.invoke(entry, testName, testRawName);
                                                                                               
                                                                                               // Verify behavior
                                                                                               Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                                                                               byte[] rawName = (byte[]) getRawNameMethod.invoke(entry);
                                                                                               assertNotNull("rawName should be set", rawName);
                                                                                               assertArrayEquals(testRawName, rawName);
                                                                                           }

    @Test
                                                                                      public void testSetNameWithBothSlashesShouldReplaceBackslashes() throws Exception {
                                                                                          // Setup - using protected constructor via reflection
                                                                                          Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                                          constructor.setAccessible(true);
                                                                                          ZipArchiveEntry entry = constructor.newInstance();
                                                                                          
                                                                                          // Use reflection to set platform to FAT since setPlatform is protected
                                                                                          Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                                                                          platformField.setAccessible(true);
                                                                                          platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                                          
                                                                                          String inputName = "path\\\\with/both\\\\slashes";
                                                                                          String expectedName = "path/with/both/slashes";
                                                                                          
                                                                                          // Execute - using protected setName method via reflection
                                                                                          Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                          setNameMethod.setAccessible(true);
                                                                                          setNameMethod.invoke(entry, inputName);
                                                                                          
                                                                                          // Verify
                                                                                          assertEquals("Backslashes should be replaced when name contains forward slashes",
                                                                                                      expectedName, entry.getName());
                                                                                      }

    @Test
                                                                                      public void testSetNameWithSlashShouldNotSetRawName2() {
                                                                                          // Setup
                                                                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                          String nameWithSlash = "invalid/name";
                                                                                          byte[] rawName = new byte[]{1, 2, 3};
                                                                                          
                                                                                          // Use reflection to access protected setName(String, byte[]) method
                                                                                          try {
                                                                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                                  "setName", String.class, byte[].class);
                                                                                              setNameMethod.setAccessible(true);
                                                                                              
                                                                                              // Execute
                                                                                              setNameMethod.invoke(entry, nameWithSlash, rawName);
                                                                                              
                                                                                              // Verify
                                                                                              assertNull("rawName should not be set when name contains '/'", 
                                                                                                       entry.getRawName());
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to access protected method: " + e.getMessage());
                                                                                          }
                                                                                      }

    @Test
                                                                                 public void testSetNameWithBackslashes4() throws Exception {
                                                                                     // Setup
                                                                                     ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                                                     String windowsPath = "folder\\\\subfolder\\\\file.txt";
                                                                                     byte[] rawName = new byte[0];
                                                                                     
                                                                                     // Use reflection to access protected setName(String, byte[]) method
                                                                                     Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                                         "setName", String.class, byte[].class);
                                                                                     setNameMethod.setAccessible(true);
                                                                                     
                                                                                     // Execute
                                                                                     setNameMethod.invoke(entry, windowsPath, rawName);
                                                                                     
                                                                                     // Verify
                                                                                     String storedName = entry.getName();
                                                                                     assertEquals("Backslashes should be converted to forward slashes", 
                                                                                                 "folder/subfolder/file.txt", storedName);
                                                                                     assertArrayEquals("rawName should be stored unchanged", 
                                                                                                      rawName, entry.getRawName());
                                                                                 }

    @Test
                                                                             public void testSetNameShouldReplaceBackslashesOnFatPlatform4() throws Exception {
                                                                                 // Setup - using protected constructor
                                                                                 ZipArchiveEntry entry = new ZipArchiveEntry() {};
                                                                                 
                                                                                 // Mock platform to return FAT
                                                                                 ZipArchiveEntry spyEntry = spy(entry);
                                                                                 when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                                                                                 
                                                                                 // Test input with backslashes
                                                                                 String inputName = "path\\\\\\\\to\\\\\\\\file.txt";
                                                                                 String expectedName = "path/to/file.txt";
                                                                                 
                                                                                 // Execute - using protected setName method
                                                                                 try {
                                                                                     Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                                     setNameMethod.setAccessible(true);
                                                                                     setNameMethod.invoke(spyEntry, inputName);
                                                                                 } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                                                     fail("Reflection failed: " + e.getMessage());
                                                                                 }
                                                                                 
                                                                                 // Verify
                                                                                 assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                                                             expectedName, spyEntry.getName());
                                                                             }

    @Test
                                                                        public void testSetNameWithRawNameWhenPlatformIsFAT1() throws Exception {
                                                                            // Create a ZipArchiveEntry using reflection to access protected constructor
                                                                            Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                            constructor.setAccessible(true);
                                                                            ZipArchiveEntry entry = constructor.newInstance();
                                                                            
                                                                            // Set platform using reflection
                                                                            Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                            setPlatform.setAccessible(true);
                                                                            setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                            
                                                                            // Prepare test data
                                                                            String name = "test.txt";
                                                                            byte[] rawName = new byte[]{'t', 'e', 's', 't', '.', 't', 'x', 't'};
                                                                            
                                                                            // Call setName using reflection
                                                                            Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                            setName.setAccessible(true);
                                                                            setName.invoke(entry, name, rawName);
                                                                            
                                                                            // Verify the rawName was set correctly
                                                                            assertArrayEquals(rawName, entry.getRawName());
                                                                            
                                                                            // Verify the name was processed correctly
                                                                            assertEquals(name, entry.getName());
                                                                        }

    @Test
                                                                    public void testSetName_PlatformCheck() throws Exception {
                                                                        // Setup test data
                                                                        String nameWithBackslashes = "dir\\\\\\\\file.txt";
                                                                        ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                        
                                                                        // Use reflection to access protected methods
                                                                        Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                        setPlatform.setAccessible(true);
                                                                        Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                        setName.setAccessible(true);
                                                                        
                                                                        // Case 1: Platform is PLATFORM_FAT - should replace backslashes
                                                                        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                        setName.invoke(entry, nameWithBackslashes);
                                                                        assertEquals("dir/file.txt", entry.getName());
                                                                        
                                                                        // Case 2: Platform is 0 - should NOT replace backslashes (mutant would fail here)
                                                                        setPlatform.invoke(entry, 0);
                                                                        setName.invoke(entry, nameWithBackslashes);
                                                                        assertEquals(nameWithBackslashes, entry.getName());
                                                                        
                                                                        // Case 3: Platform is something else (UNIX) - should NOT replace
                                                                        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                                                        setName.invoke(entry, nameWithBackslashes);
                                                                        assertEquals(nameWithBackslashes, entry.getName());
                                                                        
                                                                        // Case 4: Null name - should not throw exception
                                                                        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                        setName.invoke(entry, (String)null);
                                                                        assertNull(entry.getName());
                                                                        
                                                                        // Case 5: Name with forward slashes - should not modify
                                                                        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                        String nameWithForwardSlashes = "dir/file.txt";
                                                                        setName.invoke(entry, nameWithForwardSlashes);
                                                                        assertEquals(nameWithForwardSlashes, entry.getName());
                                                                    }

    @Test
                                                               public void testSetName_ShouldConvertBackslashesWhenPlatformIsFAT1() {
                                                                   // Setup
                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                                                   String inputName = "path\\to\\file";
                                                                   
                                                                   // Use reflection to access protected setPlatform method
                                                                   try {
                                                                       Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                       setPlatformMethod.setAccessible(true);
                                                                       setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set platform via reflection: " + e.getMessage());
                                                                   }
                                                                   
                                                                   // Use reflection to access protected setName method
                                                                   try {
                                                                       Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                       setNameMethod.setAccessible(true);
                                                                       setNameMethod.invoke(entry, inputName);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set name via reflection: " + e.getMessage());
                                                                   }
                                                                   
                                                                   // Verify
                                                                   assertEquals("path/to/file", entry.getName());
                                                                   assertNotNull(entry.getRawName());
                                                               }

    @Test
                                                               public void testSetNameWithPlatformFAT1() throws Exception {
                                                                   // Create a ZipArchiveEntry instance with valid constructor
                                                                   ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                                   
                                                                   // Use reflection to access protected setPlatform method
                                                                   Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                   setPlatformMethod.setAccessible(true);
                                                                   setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                   
                                                                   // Prepare test data
                                                                   String name = "test.txt";
                                                                   byte[] rawName = new byte[]{'t', 'e', 's', 't', '.', 't', 'x', 't'};
                                                                   
                                                                   // Use reflection to access protected setName method
                                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                   setNameMethod.setAccessible(true);
                                                                   setNameMethod.invoke(entry, name, rawName);
                                                                   
                                                                   // Verify rawName was set (original behavior)
                                                                   // Mutant would fail this assertion because condition getPlatform() == -1 would be false
                                                                   assertArrayEquals(rawName, entry.getRawName());
                                                                   
                                                                   // Also verify name was set
                                                                   assertEquals(name, entry.getName());
                                                               }

    @Test
                                                          public void testSetNameWithForwardSlashInMiddle() {
                                                              // Setup - using reflection to access protected constructor and methods
                                                              try {
                                                                  Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                  constructor.setAccessible(true);
                                                                  ZipArchiveEntry entry = constructor.newInstance();
                                                                  
                                                                  Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                  setPlatform.setAccessible(true);
                                                                  setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                  
                                                                  // Test case where "/" is in middle of name - should be modified in original
                                                                  String nameWithSlashInMiddle = "path\\\\to\\\\file/name";
                                                                  String expected = "path/to/file/name";
                                                                  
                                                                  // Execute
                                                                  Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                  setName.setAccessible(true);
                                                                  setName.invoke(entry, nameWithSlashInMiddle);
                                                                  
                                                                  // Verify
                                                                  // Original would replace all backslashes since "/" is not at start
                                                                  // Mutant would NOT replace backslashes since "/" is not at start (index != 0)
                                                                  Method getName = ZipArchiveEntry.class.getMethod("getName");
                                                                  String actualName = (String) getName.invoke(entry);
                                                                  assertEquals("Backslashes should be replaced when / is not at start", 
                                                                              expected, actualName);
                                                              } catch (Exception e) {
                                                                  fail("Test failed due to reflection error: " + e.getMessage());
                                                              }
                                                          }

    @Test
                                                          public void testSetNameWithForwardSlashAtStart() {
                                                              // Setup - using reflection to access protected constructor and methods
                                                              try {
                                                                  Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                                  constructor.setAccessible(true);
                                                                  ZipArchiveEntry entry = constructor.newInstance();
                                                                  
                                                                  Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                                  setPlatform.setAccessible(true);
                                                                  setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                                  
                                                                  // Test case where "/" is at start - should be modified in mutant
                                                                  String nameWithSlashAtStart = "/path\\\\to\\\\file";
                                                                  String expectedOriginal = "/path\\\\to\\\\file"; // Original wouldn't modify
                                                                  String expectedMutant = "/path/to/file";     // Mutant would modify
                                                                  
                                                                  // Execute
                                                                  Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                                  setName.setAccessible(true);
                                                                  setName.invoke(entry, nameWithSlashAtStart);
                                                                  
                                                                  // Verify
                                                                  // Original would NOT replace backslashes since "/" is present (even at start)
                                                                  // Mutant would replace backslashes since "/" is at start (index == 0)
                                                                  assertNotEquals("Backslashes should not be replaced when / is present (original behavior)",
                                                                                expectedMutant, entry.getName());
                                                              } catch (Exception e) {
                                                                  fail("Failed to test due to reflection error: " + e.getMessage());
                                                              }
                                                          }

    @Test
                                                          public void testSetNameWithSlashInMiddleShouldBeRejected() {
                                                              // Create entry with a dummy name since no-arg constructor is protected
                                                              ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                                              String nameWithSlashInMiddle = "dir/subdir/file";
                                                              byte[] rawName = new byte[0];
                                                              
                                                              // Use reflection to access protected setName(String, byte[]) method
                                                              try {
                                                                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                      "setName", String.class, byte[].class);
                                                                  setNameMethod.setAccessible(true);
                                                                  
                                                                  // This should fail for the original (rejects any '/')
                                                                  // but pass for the mutant (only rejects starting with '/')
                                                                  try {
                                                                      setNameMethod.invoke(entry, nameWithSlashInMiddle, rawName);
                                                                      // If we get here, the mutant survived
                                                                      fail("Should have thrown IllegalArgumentException for name with '/' in middle");
                                                                  } catch (InvocationTargetException e) {
                                                                      // Expected behavior for original code
                                                                      assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                                      assertTrue(e.getCause().getMessage().contains("invalid entry name"));
                                                                  }
                                                              } catch (Exception e) {
                                                                  fail("Reflection failed: " + e.getMessage());
                                                              }
                                                          }

    @Test
                                                          public void testSetNameWithSlashAtStartShouldBeRejected1() {
                                                              ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available public constructor
                                                              String nameWithSlashAtStart = "/file";
                                                              byte[] rawName = new byte[0];
                                                              
                                                              try {
                                                                  // Using reflection to access protected method
                                                                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                                      "setName", String.class, byte[].class);
                                                                  setNameMethod.setAccessible(true);
                                                                  setNameMethod.invoke(entry, nameWithSlashAtStart, rawName);
                                                                  fail("Should have thrown IllegalArgumentException for name starting with '/'");
                                                              } catch (IllegalArgumentException e) {
                                                                  // Both original and mutant should reject this
                                                                  assertTrue(e.getMessage().contains("invalid entry name"));
                                                              } catch (Exception e) {
                                                                  fail("Unexpected exception: " + e.getClass().getName());
                                                              }
                                                          }

    @Test
                                                          public void testSetNameWithoutSlashShouldBeAccepted() {
                                                              ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                                              String validName = "file.txt";
                                                              byte[] rawName = new byte[0];
                                                              
                                                              // Using reflection to access protected setName(String, byte[]) method
                                                              try {
                                                                  Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                                  setNameMethod.setAccessible(true);
                                                                  setNameMethod.invoke(entry, validName, rawName);
                                                              } catch (Exception e) {
                                                                  fail("Failed to invoke protected setName method: " + e.getMessage());
                                                              }
                                                              
                                                              assertEquals(validName, entry.getName());
                                                              assertArrayEquals(rawName, entry.getRawName());
                                                          }

    @Test
                                                     public void testSetNameWithBackslashesOnFatPlatform() throws Exception {
                                                         // Setup - use reflection to access protected constructor and methods
                                                         Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                         constructor.setAccessible(true);
                                                         ZipArchiveEntry entry = constructor.newInstance();
                                                         
                                                         // Use reflection to call protected setPlatform method
                                                         Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                         setPlatformMethod.setAccessible(true);
                                                         setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                         
                                                         // Use reflection to call protected setName method
                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                         setNameMethod.setAccessible(true);
                                                         
                                                         // Test case that catches the mutant
                                                         String nameWithBackslashes = "path\\\\to\\\\file";
                                                         setNameMethod.invoke(entry, nameWithBackslashes);
                                                         
                                                         // Verify the backslashes were converted to forward slashes
                                                         assertEquals("path/to/file", entry.getName());
                                                         
                                                         // Additional test case with mixed slashes
                                                         String nameWithMixedSlashes = "path\\\\to/file";
                                                         setNameMethod.invoke(entry, nameWithMixedSlashes);
                                                         
                                                         // Original would convert backslashes, mutant wouldn't
                                                         assertEquals("path/to/file", entry.getName());
                                                         
                                                         // Test case with only forward slashes
                                                         String nameWithForwardSlashes = "path/to/file";
                                                         setNameMethod.invoke(entry, nameWithForwardSlashes);
                                                         
                                                         // Original would leave unchanged, mutant would try to convert (but no backslashes exist)
                                                         assertEquals("path/to/file", entry.getName());
                                                     }

    @Test
                                                     public void testSetNameWithDifferentPathSeparators2() throws Exception {
                                                         // Create test entry using protected constructor via reflection
                                                         Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                                         constructor.setAccessible(true);
                                                         ZipArchiveEntry entry = constructor.newInstance();
                                                         
                                                         // Get protected setName(String, byte[]) method via reflection
                                                         Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                         setNameMethod.setAccessible(true);
                                                         
                                                         // Test with forward slash - should be rejected by original but accepted by mutant
                                                         String unixPath = "path/to/file.txt";
                                                         setNameMethod.invoke(entry, unixPath, unixPath.getBytes());
                                                         assertNotEquals("Original should modify rawName for path with forward slashes", 
                                                                        unixPath, new String(entry.getRawName()));
                                                         
                                                         // Test with backslash - should be rejected by mutant but accepted by original
                                                         String windowsPath = "path\\\\to\\\\file.txt";
                                                         setNameMethod.invoke(entry, windowsPath, windowsPath.getBytes());
                                                         assertNotEquals("Mutant should modify rawName for path with backslashes",
                                                                        windowsPath, new String(entry.getRawName()));
                                                         
                                                         // Test with no separators - should be accepted by both
                                                         String simpleName = "filename.txt";
                                                         setNameMethod.invoke(entry, simpleName, simpleName.getBytes());
                                                         assertEquals("Both should accept names without separators",
                                                                    simpleName, new String(entry.getRawName()));
                                                     }

    @Test
                                                public void testSetName_ConvertsBackslashesToForwardSlashesOnWindowsPlatform() throws Exception {
                                                    // Setup
                                                    ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Use available constructor
                                                    // Mock platform to be Windows (PLATFORM_FAT) using reflection
                                                    try {
                                                        Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                                        setPlatform.setAccessible(true);
                                                        setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                                    } catch (Exception e) {
                                                        fail("Failed to set platform via reflection: " + e.getMessage());
                                                    }
                                                    String windowsPath = "folder\\\\subfolder\\\\file.txt";
                                                    
                                                    // Test
                                                    try {
                                                        Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                                        setName.setAccessible(true);
                                                        setName.invoke(entry, windowsPath);
                                                    } catch (Exception e) {
                                                        fail("Failed to set name via reflection: " + e.getMessage());
                                                    }
                                                    
                                                    // Verify
                                                    String expected = "folder/subfolder/file.txt";
                                                    assertEquals("Backslashes should be converted to forward slashes on Windows platform",
                                                                expected, entry.getName());
                                                }

    @Test
                                                public void testSetNameWithPathSeparators1() throws Exception {
                                                    // Create test cases with different path separator combinations
                                                    String inputWithBackslashes = "dir\\\\subdir\\\\file.txt";
                                                    String inputWithForwardSlashes = "dir/subdir/file.txt";
                                                    String inputWithMixedSlashes = "dir\\\\subdir/file.txt";
                                                    byte[] dummyRawName = new byte[0];
                                                    
                                                    // Get the protected setName(String, byte[]) method via reflection
                                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                                    setNameMethod.setAccessible(true);
                                                    
                                                    // Test with backslashes - should convert to forward slashes
                                                    ZipArchiveEntry entry1 = new ZipArchiveEntry("");
                                                    setNameMethod.invoke(entry1, inputWithBackslashes, dummyRawName);
                                                    assertEquals("Backslashes should be converted to forward slashes",
                                                                "dir/subdir/file.txt", entry1.getName());
                                                    
                                                    // Test with forward slashes - should remain unchanged
                                                    ZipArchiveEntry entry2 = new ZipArchiveEntry("");
                                                    setNameMethod.invoke(entry2, inputWithForwardSlashes, dummyRawName);
                                                    assertEquals("Forward slashes should remain unchanged",
                                                                "dir/subdir/file.txt", entry2.getName());
                                                    
                                                    // Test with mixed slashes - all should become forward slashes
                                                    ZipArchiveEntry entry3 = new ZipArchiveEntry("");
                                                    setNameMethod.invoke(entry3, inputWithMixedSlashes, dummyRawName);
                                                    assertEquals("Mixed slashes should all become forward slashes",
                                                                "dir/subdir/file.txt", entry3.getName());
                                                }

    @Test
                                           public void testSetName_ShouldConvertBackslashesToForwardSlashesOnFatPlatform() throws Exception {
                                               // Setup - using the protected constructor via reflection
                                               Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                               constructor.setAccessible(true);
                                               ZipArchiveEntry entry = constructor.newInstance();
                                               
                                               // Set platform to FAT (using reflection since setPlatform is protected)
                                               Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                               platformField.setAccessible(true);
                                               platformField.set(entry, 0); // PLATFORM_FAT is 0
                                               
                                               // Test input with backslashes
                                               String inputName = "folder\\\\subfolder\\\\file.txt";
                                               String expectedName = "folder/subfolder/file.txt";
                                               
                                               // Execute - using protected setName method via reflection
                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                               setNameMethod.setAccessible(true);
                                               setNameMethod.invoke(entry, inputName);
                                               
                                               // Verify
                                               assertEquals("Backslashes should be converted to forward slashes on FAT platform",
                                                           expectedName, 
                                                           entry.getName());
                                           }

    @Test
                                           public void testSetNameWithBackslashes5() {
                                               // Setup
                                               ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                               String inputWithBackslashes = "path\\\\to\\\\file.txt";
                                               String expectedConvertedName = "path/to/file.txt";
                                               byte[] rawName = new byte[0];
                                               
                                               // Use reflection to access protected setName(String, byte[]) method
                                               try {
                                                   Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                       "setName", String.class, byte[].class);
                                                   setNameMethod.setAccessible(true);
                                                   
                                                   // Execute
                                                   setNameMethod.invoke(entry, inputWithBackslashes, rawName);
                                                   
                                                   // Verify
                                                   assertEquals("Backslashes should be converted to forward slashes",
                                                              expectedConvertedName, 
                                                              entry.getName());
                                                   
                                                   // Additional verification that rawName was set correctly
                                                   Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                                   getRawNameMethod.setAccessible(true);
                                                   byte[] actualRawName = (byte[]) getRawNameMethod.invoke(entry);
                                                   assertSame("Raw name should be set as provided",
                                                             rawName,
                                                             actualRawName);
                                               } catch (Exception e) {
                                                   fail("Reflection failed: " + e.getMessage());
                                               }
                                           }

    @Test
                                           public void testSetNameWithoutBackslashes() throws Exception {
                                               // Setup
                                               ZipArchiveEntry entry = new ZipArchiveEntry("initialName");
                                               String inputWithoutBackslashes = "path/to/file.txt";
                                               byte[] rawName = new byte[0];
                                               
                                               // Use reflection to access protected setName(String, byte[]) method
                                               Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                   "setName", String.class, byte[].class);
                                               setNameMethod.setAccessible(true);
                                               
                                               // Execute
                                               setNameMethod.invoke(entry, inputWithoutBackslashes, rawName);
                                               
                                               // Verify
                                               assertEquals("Name without backslashes should remain unchanged",
                                                           inputWithoutBackslashes, 
                                                           entry.getName());
                                               assertSame("Raw name should be set as provided",
                                                         rawName,
                                                         entry.getRawName());
                                           }

    @Test
                                      public void testSetNameShouldReplaceBackslashesWithForwardSlashesOnFatPlatform1() {
                                          // Setup
                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using available constructor
                                          
                                          try {
                                              // Use reflection to set platform since setPlatform is protected
                                              Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                              setPlatformMethod.setAccessible(true);
                                              setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                              
                                              // Test input with backslashes
                                              String inputName = "path\\\\to\\\\file.txt";
                                              String expectedName = "path/to/file.txt";
                                              
                                              // Execute
                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                              setNameMethod.setAccessible(true);
                                              setNameMethod.invoke(entry, inputName);
                                              
                                              // Verify
                                              assertEquals("Backslashes should be replaced with forward slashes", 
                                                          expectedName, 
                                                          entry.getName());
                                          } catch (Exception e) {
                                              fail("Exception occurred during test: " + e.getMessage());
                                          }
                                      }

    @Test
                                      public void testSetNameWithBackslashes6() {
                                          // Setup
                                          ZipArchiveEntry entry = new ZipArchiveEntry("dummy"); // Using public constructor
                                          String inputName = "path\\\\to\\\\file.txt";
                                          byte[] rawName = new byte[0];
                                          
                                          // Use reflection to access protected setName(String, byte[]) method
                                          try {
                                              Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod(
                                                  "setName", String.class, byte[].class);
                                              setNameMethod.setAccessible(true);
                                              setNameMethod.invoke(entry, inputName, rawName);
                                          } catch (Exception e) {
                                              fail("Failed to invoke protected setName method: " + e.getMessage());
                                          }
                                          
                                          // Verify
                                          String expectedName = "path/to/file.txt";  // What original code should produce
                                          String actualName = entry.getName();
                                          
                                          // This will fail on mutant since mutant would produce "path to file.txt"
                                          assertEquals("Backslashes should be converted to forward slashes", 
                                                       expectedName, 
                                                       actualName);
                                          
                                          // Also verify rawName was set correctly
                                          try {
                                              Method getRawNameMethod = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                              getRawNameMethod.setAccessible(true);
                                              byte[] actualRawName = (byte[]) getRawNameMethod.invoke(entry);
                                              assertSame("Raw name should be set as provided", 
                                                         rawName, 
                                                         actualRawName);
                                          } catch (Exception e) {
                                              fail("Failed to verify raw name: " + e.getMessage());
                                          }
                                      }

    @Test
                                 public void testSetName_ShouldReplaceBackslashesOnFatPlatform1() throws Exception {
                                     // Setup
                                     // Using protected constructor via reflection since default constructor is protected
                                     Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                     constructor.setAccessible(true);
                                     ZipArchiveEntry entry = constructor.newInstance();
                                     
                                     // Use reflection to set platform to FAT since setPlatform is protected
                                     Field platformField = ZipArchiveEntry.class.getDeclaredField("platform");
                                     platformField.setAccessible(true);
                                     platformField.set(entry, ZipArchiveEntry.PLATFORM_FAT);
                                     
                                     String inputName = "path\\\\to\\\\file";
                                     String expectedName = "path/to/file";
                                     
                                     // Test
                                     // Using reflection to call protected setName method
                                     Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                     setNameMethod.setAccessible(true);
                                     setNameMethod.invoke(entry, inputName);
                                     
                                     // Verify
                                     assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                                 expectedName, entry.getName());
                                 }

    @Test
                                 public void testSetNameWithRawNameShouldHandlePlatformFatCorrectly() throws Exception {
                                     // Create test objects
                                     ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                                     String testName = "test.txt";
                                     byte[] testRawName = new byte[]{'t', 'e', 's', 't'};
                                     
                                     // Get protected methods via reflection
                                     Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                     setPlatform.setAccessible(true);
                                     Method setNameWithRaw = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                     setNameWithRaw.setAccessible(true);
                                     Method getRawName = ZipArchiveEntry.class.getDeclaredMethod("getRawName");
                                     getRawName.setAccessible(true);
                                     
                                     // Test case 1: name not null and platform is FAT
                                     setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                     setNameWithRaw.invoke(entry, testName, testRawName);
                                     assertArrayEquals("Raw name should be set when platform is FAT", 
                                                      testRawName, (byte[])getRawName.invoke(entry));
                                     
                                     // Test case 2: name not null and platform is not FAT
                                     setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                                     setNameWithRaw.invoke(entry, testName, testRawName);
                                     assertArrayEquals("Raw name should still be set regardless of platform", 
                                                      testRawName, (byte[])getRawName.invoke(entry));
                                     
                                     // Test case 3: name is null
                                     setNameWithRaw.invoke(entry, null, testRawName);
                                     assertArrayEquals("Raw name should be set even when name is null", 
                                                      testRawName, (byte[])getRawName.invoke(entry));
                                 }

    @Test
                            public void testSetNameWithMixedSlashesShouldNotReplaceWhenContainsForwardSlash() throws Exception {
                                // Setup - use protected constructor via reflection
                                Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                constructor.setAccessible(true);
                                ZipArchiveEntry entry = constructor.newInstance();
                                
                                // Mock platform to be FAT using reflection since setPlatform is protected
                                Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                                setPlatformMethod.setAccessible(true);
                                setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                                
                                // Test input with both slashes
                                String inputName = "path\\\\with/mixed/slashes";
                                
                                // Execute - use reflection for setName since it's protected
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, inputName);
                                
                                // Verify - should not replace backslashes when forward slashes present
                                assertEquals("Original should keep backslashes when forward slashes present",
                                            inputName, entry.getName());
                            }

    @Test
                            public void testSetNameWithSlashShouldNotSetRawName3() {
                                // Create test objects using protected constructor via reflection
                                ZipArchiveEntry entry;
                                try {
                                    Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                    constructor.setAccessible(true);
                                    entry = constructor.newInstance();
                                } catch (Exception e) {
                                    throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
                                }
                                
                                String nameWithSlash = "test/name";
                                byte[] rawName = new byte[]{1, 2, 3};
                                
                                // Call the protected method via reflection
                                try {
                                    Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                    setNameMethod.setAccessible(true);
                                    setNameMethod.invoke(entry, nameWithSlash, rawName);
                                } catch (Exception e) {
                                    throw new RuntimeException("Failed to invoke setName method", e);
                                }
                                
                                // Verify behavior
                                assertNull("rawName should not be set when name contains '/'", entry.getRawName());
                                
                                // Also verify name was set correctly
                                assertEquals("Name should be set correctly", nameWithSlash, entry.getName());
                            }

    @Test
                            public void testSetNameWithoutSlashShouldSetRawName() throws Exception {
                                // Create test objects using reflection to access protected constructor
                                Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                                constructor.setAccessible(true);
                                ZipArchiveEntry entry = constructor.newInstance();
                                
                                String nameWithoutSlash = "testname";
                                byte[] rawName = new byte[]{1, 2, 3};
                                
                                // Call the protected method using reflection
                                Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                                setNameMethod.setAccessible(true);
                                setNameMethod.invoke(entry, nameWithoutSlash, rawName);
                                
                                // Verify behavior
                                assertArrayEquals("rawName should be set when name doesn't contain '/'", 
                                                 rawName, entry.getRawName());
                                assertEquals("Name should be set correctly", nameWithoutSlash, entry.getName());
                            }

    @Test
                       public void testSetName_ShouldReplaceBackslashesOnFatPlatform2() throws Exception {
                           // Setup
                           // Using reflection to access protected constructor
                           Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                           constructor.setAccessible(true);
                           ZipArchiveEntry entry = constructor.newInstance();
                           
                           // Use reflection to set platform to FAT since setPlatform is protected
                           Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                           setPlatformMethod.setAccessible(true);
                           setPlatformMethod.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                           
                           String inputName = "path\\\\to\\\\file";
                           String expectedName = "path/to/file";
                           
                           // Execute
                           // Using reflection to call protected setName method
                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                           setNameMethod.setAccessible(true);
                           setNameMethod.invoke(entry, inputName);
                           
                           // Verify
                           assertEquals("Backslashes should be replaced with forward slashes on FAT platform",
                                       expectedName, entry.getName());
                       }

    @Test
                       public void testSetNameWithBackslashes7() throws Exception {
                           // Create test object using protected constructor via reflection
                           Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                           constructor.setAccessible(true);
                           ZipArchiveEntry entry = constructor.newInstance();
                           
                           // Test with name containing backslashes
                           String inputName = "path\\\\to\\\\file.txt";
                           byte[] rawName = new byte[0];
                           
                           // Call the protected method via reflection
                           Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                           setNameMethod.setAccessible(true);
                           setNameMethod.invoke(entry, inputName, rawName);
                           
                           // Verify the name was properly normalized (backslashes replaced)
                           assertEquals("path/to/file.txt", entry.getName());
                           
                           // Verify rawName was set correctly
                           assertArrayEquals(rawName, entry.getRawName());
                           
                           // Test with name without backslashes
                           String simpleName = "simple.txt";
                           setNameMethod.invoke(entry, simpleName, rawName);
                           assertEquals(simpleName, entry.getName());
                           
                           // Test with empty string
                           setNameMethod.invoke(entry, "", rawName);
                           assertEquals("", entry.getName());
                           
                           // Test with null name (should throw exception)
                           try {
                               setNameMethod.invoke(entry, new Object[]{null, rawName});
                               fail("Expected NullPointerException");
                           } catch (InvocationTargetException e) {
                               assertTrue(e.getCause() instanceof NullPointerException);
                           }
                       }

    @Test
                  public void testSetName_ShouldConvertBackslashesOnlyOnFATPlatform() throws Exception {
                      // Setup test data
                      String inputName = "path\\\\to\\\\file";
                      String expectedName = "path/to/file";
                      
                      // Create instance using available constructor and set platform to FAT
                      ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                      
                      // Use reflection to access protected setPlatform method
                      Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                      setPlatform.setAccessible(true);
                      setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                      
                      // Use reflection to access protected setName method
                      Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                      setName.setAccessible(true);
                      setName.invoke(entry, inputName);
                      
                      // Verify the name was converted
                      assertEquals("Backslashes should be converted on FAT platform", 
                                   expectedName, entry.getName());
                      
                      // Additional test case where platform is 0 but not FAT
                      ZipArchiveEntry entry2 = new ZipArchiveEntry("dummy");
                      setPlatform.invoke(entry2, 0); // Set platform to 0 (not FAT)
                      setName.invoke(entry2, inputName);
                      
                      // Verify the name was NOT converted
                      assertEquals("Backslashes should not be converted on non-FAT platform", 
                                   inputName, entry2.getName());
                  }

    @Test
                  public void testSetNameWithRawNamePlatformComparison1() throws Exception {
                      // Create test objects using reflection to access protected constructor
                      Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                      constructor.setAccessible(true);
                      ZipArchiveEntry entry = constructor.newInstance();
                      
                      // Get protected methods
                      Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                      Method setNameWithRaw = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                      setPlatform.setAccessible(true);
                      setNameWithRaw.setAccessible(true);
                      
                      // Test case 1: Platform is PLATFORM_FAT (should pass original condition)
                      setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                      byte[] rawName1 = new byte[]{1, 2, 3};
                      setNameWithRaw.invoke(entry, "test1", rawName1);
                      assertArrayEquals(rawName1, entry.getRawName());
                      
                      // Test case 2: Platform is 0 but not PLATFORM_FAT (should fail mutant)
                      // First, ensure PLATFORM_FAT is not actually 0
                      assertNotEquals(0, ZipArchiveEntry.PLATFORM_FAT);
                      
                      // Now test with platform set to 0
                      setPlatform.invoke(entry, 0);
                      byte[] rawName2 = new byte[]{4, 5, 6};
                      setNameWithRaw.invoke(entry, "test2", rawName2);
                      assertNull(entry.getRawName());
                      
                      // Test case 3: Platform is neither (UNIX case)
                      setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                      byte[] rawName3 = new byte[]{7, 8, 9};
                      setNameWithRaw.invoke(entry, "test3", rawName3);
                      assertNull(entry.getRawName());
                  }

    @Test
             public void testSetNameWithForwardSlashes() {
                 // Create entry with a dummy name first since no-arg constructor is protected
                 ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
                 
                 // Mock platform to FAT
                 ZipArchiveEntry spyEntry = spy(entry);
                 when(spyEntry.getPlatform()).thenReturn(ZipArchiveEntry.PLATFORM_FAT);
                 
                 String testName = "path/to/file";
                 // Use reflection to access protected setName method
                 try {
                     Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                     setNameMethod.setAccessible(true);
                     setNameMethod.invoke(spyEntry, testName);
                 } catch (Exception e) {
                     fail("Failed to invoke setName method via reflection");
                 }
                 
                 assertEquals(testName, spyEntry.getName()); // Should remain unchanged
             }

    @Test
             public void testSetNameWithPlatformFAT2() throws Exception {
                 // Setup - use reflection to access protected constructor
                 Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                 constructor.setAccessible(true);
                 ZipArchiveEntry entry = constructor.newInstance();
                 
                 // Use reflection to access protected setPlatform method
                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                 setPlatform.setAccessible(true);
                 setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
                 
                 String testName = "test.txt";
                 byte[] testRawName = new byte[]{'t', 'e', 's', 't'};
                 
                 // Use reflection to access protected setName method
                 Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                 setName.setAccessible(true);
                 setName.invoke(entry, testName, testRawName);
                 
                 // Verify
                 assertEquals("Name should be set", testName, entry.getName());
                 assertArrayEquals("Raw name should be set", testRawName, entry.getRawName());
                 
                 // Additional verification that platform check was properly handled
                 // In original code, the platform check should have passed (PLATFORM_FAT)
                 // In mutated code, it would fail (PLATFORM_FAT != -1)
                 // So any behavior dependent on that check would differ
             }

    @Test
             public void testSetNameWithPlatformNotFAT() throws Exception {
                 // Setup - platform not FAT
                 // Use reflection to access protected constructor
                 Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
                 constructor.setAccessible(true);
                 ZipArchiveEntry entry = constructor.newInstance();
                 
                 // Use reflection to set platform
                 Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                 setPlatform.setAccessible(true);
                 setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_UNIX);
                 
                 String testName = "test.txt";
                 byte[] testRawName = new byte[]{'t', 'e', 's', 't'};
                 
                 // Use reflection to call setName
                 Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
                 setName.setAccessible(true);
                 setName.invoke(entry, testName, testRawName);
                 
                 // Verify behavior when platform is not FAT
                 assertEquals("Name should be set", testName, entry.getName());
                 assertArrayEquals("Raw name should be set", testRawName, entry.getRawName());
             }

    @Test
         public void testSetNameShouldConvertBackslashesOnlyOnFatPlatform() {
             // Create test entry with a dummy name since no-arg constructor is protected
             ZipArchiveEntry entry = new ZipArchiveEntry("dummy");
             
             // Mock platform to return FAT (original condition)
             ZipArchiveEntry spyEntry = spy(entry);
             try {
                 Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                 setPlatformMethod.setAccessible(true);
                 setPlatformMethod.invoke(spyEntry, ZipArchiveEntry.PLATFORM_FAT);
             } catch (Exception e) {
                 fail("Failed to set platform via reflection");
             }
             
             // Test with backslashes when platform is FAT (should convert)
             String testName = "path\\\\\\\\to\\\\\\\\file";
             try {
                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                 setNameMethod.setAccessible(true);
                 setNameMethod.invoke(spyEntry, testName);
             } catch (Exception e) {
                 fail("Failed to set name via reflection");
             }
             assertEquals("path/to/file", spyEntry.getName());
             
             // Mock platform to return UNIX (should not convert)
             try {
                 Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                 setPlatformMethod.setAccessible(true);
                 setPlatformMethod.invoke(spyEntry, ZipArchiveEntry.PLATFORM_UNIX);
             } catch (Exception e) {
                 fail("Failed to set platform via reflection");
             }
             try {
                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                 setNameMethod.setAccessible(true);
                 setNameMethod.invoke(spyEntry, testName);
             } catch (Exception e) {
                 fail("Failed to set name via reflection");
             }
             assertEquals(testName, spyEntry.getName()); // Should remain unchanged
             
             // Test with mutation condition (platform = -1)
             try {
                 Method setPlatformMethod = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
                 setPlatformMethod.setAccessible(true);
                 setPlatformMethod.invoke(spyEntry, -1);
             } catch (Exception e) {
                 fail("Failed to set platform via reflection");
             }
             try {
                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                 setNameMethod.setAccessible(true);
                 setNameMethod.invoke(spyEntry, testName);
             } catch (Exception e) {
                 fail("Failed to set name via reflection");
             }
             assertEquals(testName, spyEntry.getName()); // Should remain unchanged
         }

    @Test
         public void testSetNameWithNull() {
             ZipArchiveEntry entry = new ZipArchiveEntry("dummyName");
             try {
                 Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
                 setNameMethod.setAccessible(true);
                 setNameMethod.invoke(entry, (String)null);
                 fail("Expected NullPointerException");
             } catch (NullPointerException e) {
                 // Expected behavior
             } catch (Exception e) {
                 fail("Unexpected exception: " + e.getClass().getName());
             }
         }

    @Test
    public void testSetNameWithSlashNotAtStartShouldReplaceBackslashes() {
        // Setup - use protected constructor via reflection
        ZipArchiveEntry entry;
        try {
            Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            entry = constructor.newInstance();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create ZipArchiveEntry instance", e);
        }
        
        // Mock platform to be FAT - use reflection to access protected method
        try {
            Method setPlatform = ZipArchiveEntry.class.getDeclaredMethod("setPlatform", int.class);
            setPlatform.setAccessible(true);
            setPlatform.invoke(entry, ZipArchiveEntry.PLATFORM_FAT);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set platform", e);
        }
        
        // Test case: name contains "/" but not at start, and contains backslashes
        String nameWithSlash = "path\\\\to\\\\file/name";
        String expected = "path/to/file/name"; // backslashes should be replaced
        
        // Execute - use reflection to access protected setName method
        try {
            Method setName = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class);
            setName.setAccessible(true);
            setName.invoke(entry, nameWithSlash);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set name", e);
        }
        
        // Verify
        assertEquals("Backslashes should be replaced when / exists but not at start", 
                    expected, entry.getName());
        
        // Additional verification that the raw name is set correctly
        assertNotNull(entry.getRawName());
    }

    @Test
    public void testSetNameWithSlashes1() throws Exception {
        // Use reflection to access protected constructor
        Constructor<ZipArchiveEntry> constructor = ZipArchiveEntry.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        ZipArchiveEntry entry = constructor.newInstance();
        byte[] dummyRawName = new byte[0];
        
        // Use reflection to access protected setName(String, byte[]) method
        Method setNameMethod = ZipArchiveEntry.class.getDeclaredMethod("setName", String.class, byte[].class);
        setNameMethod.setAccessible(true);
        
        // Test name without slash - should be accepted by both
        setNameMethod.invoke(entry, "validName", dummyRawName);
        assertEquals("validName", entry.getName());
        
        // Test name starting with slash - should be rejected by both
        try {
            setNameMethod.invoke(entry, "/invalidName", dummyRawName);
            fail("Should have thrown IllegalArgumentException for name starting with /");
        } catch (InvocationTargetException e) {
            assertTrue(e.getCause() instanceof IllegalArgumentException);
        }
        
        // Test name with slash in middle - this is the key test for the mutant
        // Original would reject, mutant would accept
        try {
            setNameMethod.invoke(entry, "invalid/Name", dummyRawName);
            fail("Should have thrown IllegalArgumentException for name containing /");
        } catch (InvocationTargetException e) {
            assertTrue(e.getCause() instanceof IllegalArgumentException);
        }
    }


}
