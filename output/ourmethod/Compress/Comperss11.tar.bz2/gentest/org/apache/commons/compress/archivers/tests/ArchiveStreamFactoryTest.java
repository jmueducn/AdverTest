package gentest.org.apache.commons.compress.archivers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
 
public class ArchiveStreamFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                           public void testCreateArchiveInputStream_ArType() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInput);
                                                                                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_ZipType() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                                                                                                                                               assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_TarType() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInput);
                                                                                                                                                               assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_JarType() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput);
                                                                                                                                                               assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_CpioType() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInput);
                                                                                                                                                               assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_DumpType() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInput);
                                                                                                                                                               assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_CaseInsensitive() throws Exception {
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result1 = factory.createArchiveInputStream("ar", mockInput);
                                                                                                                                                               assertTrue(result1 instanceof ArArchiveInputStream);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result2 = factory.createArchiveInputStream("ZIP", mockInput);
                                                                                                                                                               assertTrue(result2 instanceof ZipArchiveInputStream);
                                                                                                                                                               
                                                                                                                                                               ArchiveInputStream result3 = factory.createArchiveInputStream("tAr", mockInput);
                                                                                                                                                               assertTrue(result3 instanceof TarArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_ZipFormat() throws Exception {
                                                                                                                                                               // ZIP signature: 50 4B 03 04
                                                                                                                                                               byte[] zipSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                               InputStream input = new ByteArrayInputStream(zipSignature);
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof ZipArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_JarFormat() throws Exception {
                                                                                                                                                               // JAR is also a ZIP format but detected separately
                                                                                                                                                               byte[] jarSignature = new byte[] {0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 0, 0, 0, 0, 0};
                                                                                                                                                               InputStream input = new ByteArrayInputStream(jarSignature);
                                                                                                                                                       
                                                                                                                                                               // Mock the static matches method
                                                                                                                                                               when(JarArchiveInputStream.matches(jarSignature, jarSignature.length)).thenReturn(true);
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof JarArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_ArFormat() throws Exception {
                                                                                                                                                               // AR signature: "!<arch>"
                                                                                                                                                               byte[] arSignature = "!<arch>\n".getBytes();
                                                                                                                                                               InputStream input = new ByteArrayInputStream(arSignature);
                                                                                                                                                       
                                                                                                                                                               // Mock the static matches method
                                                                                                                                                               when(ArArchiveInputStream.matches(arSignature, arSignature.length)).thenReturn(true);
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof ArArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_CpioFormat() throws Exception {
                                                                                                                                                               // CPIO signature: "070707", "070701", or "070702"
                                                                                                                                                               byte[] cpioSignature = "070707".getBytes();
                                                                                                                                                               InputStream input = new ByteArrayInputStream(cpioSignature);
                                                                                                                                                       
                                                                                                                                                               // Mock the static matches method
                                                                                                                                                               when(CpioArchiveInputStream.matches(cpioSignature, cpioSignature.length)).thenReturn(true);
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof CpioArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_DumpFormat() throws Exception {
                                                                                                                                                               // DUMP signature: starts with "DUMP"
                                                                                                                                                               byte[] dumpSignature = new byte[32];
                                                                                                                                                               System.arraycopy("DUMP".getBytes(), 0, dumpSignature, 0, 4);
                                                                                                                                                               InputStream input = new ByteArrayInputStream(dumpSignature);
                                                                                                                                                       
                                                                                                                                                               // Mock the static matches method
                                                                                                                                                               when(DumpArchiveInputStream.matches(dumpSignature, dumpSignature.length)).thenReturn(true);
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof DumpArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_TarFormat() throws Exception {
                                                                                                                                                               // TAR signature: first 257 bytes contain "ustar"
                                                                                                                                                               byte[] tarSignature = new byte[512];
                                                                                                                                                               System.arraycopy("ustar".getBytes(), 0, tarSignature, 257, 5);
                                                                                                                                                               InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                       
                                                                                                                                                               // Mock the static matches method
                                                                                                                                                               when(TarArchiveInputStream.matches(tarSignature, tarSignature.length)).thenReturn(true);
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                           public void testCreateArchiveInputStream_TarFormatFallbackDetection() throws Exception {
                                                                                                                                                               // Create a valid TAR header but without the ustar signature
                                                                                                                                                               byte[] tarSignature = new byte[512];
                                                                                                                                                               // Fill with data that would pass the fallback detection
                                                                                                                                                               InputStream input = new ByteArrayInputStream(tarSignature);
                                                                                                                                                       
                                                                                                                                                               // Mock the static matches to return false for initial check
                                                                                                                                                               when(TarArchiveInputStream.matches(tarSignature, tarSignature.length)).thenReturn(false);
                                                                                                                                                       
                                                                                                                                                               // Mock the fallback detection to succeed
                                                                                                                                                               TarArchiveInputStream mockTais = mock(TarArchiveInputStream.class);
                                                                                                                                                               when(mockTais.getNextEntry()).thenReturn(null); // Simulate successful read
                                                                                                                                                       
                                                                                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                               ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                                       
                                                                                                                                                               assertTrue(result instanceof TarArchiveInputStream);
                                                                                                                                                           }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_NullInputStream() throws Exception {
                                                                                                                                                       try {
                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                           factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                                                           fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                                                           assertEquals("InputStream must not be null.", e.getMessage());
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_InvalidType() throws Exception {
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                                       try {
                                                                                                                                                           factory.createArchiveInputStream("invalid", mockInput);
                                                                                                                                                           fail("Expected ArchiveException");
                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                           assertEquals("Archiver: invalid not found.", e.getMessage());
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_EmptyStringType() throws Exception {
                                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                       expectedException.expect(ArchiveException.class);
                                                                                                                                                       expectedException.expectMessage("Archiver:  not found.");
                                                                                                                                                       
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       InputStream mockInput = mock(InputStream.class);
                                                                                                                                                       factory.createArchiveInputStream("", mockInput);
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_NullStream() throws Exception {
                                                                                                                                                       try {
                                                                                                                                                           ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                           factory.createArchiveInputStream((InputStream) null);
                                                                                                                                                           fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                                                           assertEquals("Stream must not be null.", e.getMessage());
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_UnsupportedMark() throws Exception {
                                                                                                                                                       InputStream input = mock(InputStream.class);
                                                                                                                                                       when(input.markSupported()).thenReturn(false);
                                                                                                                                                   
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       try {
                                                                                                                                                           factory.createArchiveInputStream(input);
                                                                                                                                                           fail("Expected IllegalArgumentException");
                                                                                                                                                       } catch (IllegalArgumentException e) {
                                                                                                                                                           assertEquals("Mark is not supported.", e.getMessage());
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                                   public void testCreateArchiveInputStream_UnknownFormat() {
                                                                                                                                                       byte[] unknownSignature = new byte[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
                                                                                                                                                       InputStream input = new ByteArrayInputStream(unknownSignature);
                                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                       
                                                                                                                                                       try {
                                                                                                                                                           factory.createArchiveInputStream(input);
                                                                                                                                                           fail("Expected ArchiveException to be thrown");
                                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                                           assertEquals("No Archiver found for the stream signature", e.getMessage());
                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                           fail("Unexpected exception type thrown");
                                                                                                                                                       }
                                                                                                                                                   }

 @Test
                                                                                                                                               public void testCreateArchiveInputStream_NullArchiverName() throws Exception {
                                                                                                                                                   ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                   
                                                                                                                                                   expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                   expectedException.expectMessage("Archivername must not be null.");
                                                                                                                                                   
                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                                                                                   factory.createArchiveInputStream(null, mockInput);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testCreateArchiveInputStream_IOException() throws Exception {
                                                                                                                                                   ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                   
                                                                                                                                                   expectedException.expect(ArchiveException.class);
                                                                                                                                                   expectedException.expectMessage("Could not use reset and mark operations.");
                                                                                                                                                
                                                                                                                                                   InputStream input = mock(InputStream.class);
                                                                                                                                                   when(input.markSupported()).thenReturn(true);
                                                                                                                                                   doNothing().when(input).mark(anyInt());
                                                                                                                                                   when(input.read(any(byte[].class))).thenThrow(new IOException("Test IO Exception"));
                                                                                                                                                
                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                   factory.createArchiveInputStream(input);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testCreateArchiveInputStream_PropagatesError() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   String archiverName = ArchiveStreamFactory.ZIP;
                                                                                                                                                   InputStream mockInput = mock(InputStream.class);
                                                                                                                                                   
                                                                                                                                                   // Make the mock throw an Error when read
                                                                                                                                                   when(mockInput.read()).thenThrow(new OutOfMemoryError("Test Error"));
                                                                                                                                           
                                                                                                                                                   // Expect the Error to be thrown
                                                                                                                                                   thrown.expect(OutOfMemoryError.class);
                                                                                                                                                   thrown.expectMessage("Test Error");
                                                                                                                                           
                                                                                                                                                   // Test
                                                                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                                   factory.createArchiveInputStream(archiverName, mockInput);
                                                                                                                                                   
                                                                                                                                                   // Verify interaction
                                                                                                                                                   verify(mockInput).read();
                                                                                                                                               }

 @Test
                                                                                                                                          public void testCreateArchiveInputStream_ShouldNotCatchErrorDuringTarDetection() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                              
                                                                                                                                              // Create rule for expected exception
                                                                                                                                              ExpectedException expectedException = ExpectedException.none();
                                                                                                                                              
                                                                                                                                              // Create a mock input stream that will throw an Error during TAR detection
                                                                                                                                              InputStream mockIn = mock(InputStream.class);
                                                                                                                                              when(mockIn.markSupported()).thenReturn(true);
                                                                                                                                              
                                                                                                                                              // First signature read (non-TAR case)
                                                                                                                                              when(mockIn.read(any(byte[].class))).thenReturn(12);
                                                                                                                                              
                                                                                                                                              // Setup for TAR detection path
                                                                                                                                              byte[] tarheader = new byte[512];
                                                                                                                                              when(mockIn.read(tarheader)).thenAnswer(invocation -> {
                                                                                                                                                  // Simulate an Error during TAR processing
                                                                                                                                                  throw new OutOfMemoryError("Simulated error during TAR detection");
                                                                                                                                              });
                                                                                                                                              
                                                                                                                                              // Expectation - Error should propagate
                                                                                                                                              expectedException.expect(OutOfMemoryError.class);
                                                                                                                                              expectedException.expectMessage("Simulated error during TAR detection");
                                                                                                                                              
                                                                                                                                              // Test
                                                                                                                                              factory.createArchiveInputStream(mockIn);
                                                                                                                                          }

 @Test
                                                                                                                                          public void testCreateArchiveInputStreamForTar() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                              InputStream mockInput = mock(InputStream.class);
                                                                                                                                              
                                                                                                                                              // Test exact match
                                                                                                                                              String tarName = ArchiveStreamFactory.TAR;
                                                                                                                                              assertTrue(factory.createArchiveInputStream(tarName, mockInput) instanceof TarArchiveInputStream);
                                                                                                                                              
                                                                                                                                              // Test case variations
                                                                                                                                              assertTrue(factory.createArchiveInputStream("tar", mockInput) instanceof TarArchiveInputStream);
                                                                                                                                              assertTrue(factory.createArchiveInputStream("Tar", mockInput) instanceof TarArchiveInputStream);
                                                                                                                                              assertTrue(factory.createArchiveInputStream("TAR", mockInput) instanceof TarArchiveInputStream);
                                                                                                                                              
                                                                                                                                              // Test with leading/trailing whitespace (though method may not trim)
                                                                                                                                              try {
                                                                                                                                                  factory.createArchiveInputStream(" TAR ", mockInput);
                                                                                                                                                  fail("Expected ArchiveException for invalid TAR name with whitespace");
                                                                                                                                              } catch (ArchiveException e) {
                                                                                                                                                  // Expected
                                                                                                                                              }
                                                                                                                                              
                                                                                                                                              // Test with similar but invalid names
                                                                                                                                              try {
                                                                                                                                                  factory.createArchiveInputStream("TARX", mockInput);
                                                                                                                                                  fail("Expected ArchiveException for invalid archive name");
                                                                                                                                              } catch (ArchiveException e) {
                                                                                                                                                  // Expected
                                                                                                                                              }
                                                                                                                                          }

 @Test
                                                                                                                                          public void testCreateArchiveInputStream_TarAutodetectionSuccess() throws Exception {
                                                                                                                                              // Setup
                                                                                                                                              InputStream input = mock(InputStream.class);
                                                                                                                                              byte[] fakeSignature = new byte[12]; // Doesn't match TAR
                                                                                                                                              byte[] tarHeader = new byte[512]; // Valid TAR header
                                                                                                                                              
                                                                                                                                              // Mock behavior
                                                                                                                                              when(input.markSupported()).thenReturn(true);
                                                                                                                                              when(input.read(any(byte[].class))).thenAnswer(invocation -> {
                                                                                                                                                  byte[] buf = invocation.getArgumentAt(0, byte[].class);
                                                                                                                                                  if (buf.length == 12) {
                                                                                                                                                      System.arraycopy(fakeSignature, 0, buf, 0, 12);
                                                                                                                                                      return 12;
                                                                                                                                                  } else if (buf.length == 512) {
                                                                                                                                                      // Create a valid TAR header
                                                                                                                                                      System.arraycopy(new byte[512], 0, buf, 0, 512);
                                                                                                                                                      buf[257] = 'u'; // TAR signature
                                                                                                                                                      buf[258] = 's';
                                                                                                                                                      buf[259] = 't';
                                                                                                                                                      buf[260] = 'a';
                                                                                                                                                      buf[261] = 'r';
                                                                                                                                                      return 512;
                                                                                                                                                  }
                                                                                                                                                  return -1;
                                                                                                                                              });
                                                                                                                                              
                                                                                                                                              // Test
                                                                                                                                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                              ArchiveInputStream result = factory.createArchiveInputStream(input);
                                                                                                                                              
                                                                                                                                              // Verify
                                                                                                                                              assertNotNull("Should return a stream for valid TAR", result);
                                                                                                                                              assertTrue("Should return TarArchiveInputStream", 
                                                                                                                                                  result instanceof TarArchiveInputStream);
                                                                                                                                              
                                                                                                                                              // Verify mock interactions
                                                                                                                                              verify(input, atLeastOnce()).mark(anyInt());
                                                                                                                                              verify(input, atLeastOnce()).reset();
                                                                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                         public void testCreateArchiveInputStream_NullArchiverName1() throws Exception {
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             InputStream mockInput = mock(InputStream.class);
                                                                                                                                             factory.createArchiveInputStream(null, mockInput);
                                                                                                                                         }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                         public void testCreateArchiveInputStream_NullInputStream1() throws Exception {
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, null);
                                                                                                                                         }

 @Test(expected = ArchiveException.class)
                                                                                                                                         public void testCreateArchiveInputStream_UnsupportedArchiveType() throws Exception {
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             InputStream mockInput = mock(InputStream.class);
                                                                                                                                             factory.createArchiveInputStream("UNSUPPORTED_FORMAT", mockInput);
                                                                                                                                         }

 @Test
                                                                                                                                         public void testCreateArchiveInputStream_SupportedTypes() throws Exception {
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             InputStream mockInput = mock(InputStream.class);
                                                                                                                                             
                                                                                                                                             assertNotNull(factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInput));
                                                                                                                                             assertNotNull(factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput));
                                                                                                                                             assertNotNull(factory.createArchiveInputStream(ArchiveStreamFactory.TAR, mockInput));
                                                                                                                                             assertNotNull(factory.createArchiveInputStream(ArchiveStreamFactory.JAR, mockInput));
                                                                                                                                             assertNotNull(factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, mockInput));
                                                                                                                                             assertNotNull(factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, mockInput));
                                                                                                                                         }

 @Test
                                                                                                                                         public void testCreateArchiveInputStream_TarDetectionExceptionIsIgnored() throws Exception {
                                                                                                                                             // Setup
                                                                                                                                             InputStream input = mock(InputStream.class);
                                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                             
                                                                                                                                             // Configure input stream behavior
                                                                                                                                             when(input.markSupported()).thenReturn(true);
                                                                                                                                             
                                                                                                                                             // First signature read (12 bytes)
                                                                                                                                             byte[] signature = new byte[12];
                                                                                                                                             when(input.read(signature)).thenReturn(512); // Return 512 to trigger TAR detection
                                                                                                                                             
                                                                                                                                             // Second signature read (32 bytes) - not a dump
                                                                                                                                             byte[] dumpsig = new byte[32];
                                                                                                                                             when(input.read(dumpsig)).thenReturn(32);
                                                                                                                                             
                                                                                                                                             // Tar header read (512 bytes)
                                                                                                                                             byte[] tarheader = new byte[512];
                                                                                                                                             when(input.read(tarheader)).thenReturn(512);
                                                                                                                                             
                                                                                                                                             // Make TarArchiveInputStream throw exception when created
                                                                                                                                             when(TarArchiveInputStream.matches(tarheader, 512)).thenReturn(false);
                                                                                                                                             
                                                                                                                                             // Expect ArchiveException since no format matched
                                                                                                                                             thrown.expect(ArchiveException.class);
                                                                                                                                             thrown.expectMessage("No Archiver found for the stream signature");
                                                                                                                                             
                                                                                                                                             // Test
                                                                                                                                             factory.createArchiveInputStream(input);
                                                                                                                                             
                                                                                                                                             // Verify that reset was called (shows execution continued past the exception)
                                                                                                                                             verify(input, atLeastOnce()).reset();
                                                                                                                                         }

 @Test
                                                                                                                                        public void testCreateArchiveInputStream_NullArchiverName2() throws Exception {
                                                                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                            InputStream input = mock(InputStream.class);
                                                                                                                                            
                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                            thrown.expectMessage("Archivername must not be null.");
                                                                                                                                            
                                                                                                                                            factory.createArchiveInputStream(null, input);
                                                                                                                                        }

 @Test
                                                                                                                                        public void testCreateArchiveInputStream_NullInputStream2() throws Exception {
                                                                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                            
                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                            thrown.expectMessage("InputStream must not be null.");
                                                                                                                                            
                                                                                                                                            factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, null);
                                                                                                                                        }

 @Test
                                                                                                                                        public void testCreateArchiveInputStream_UnknownArchiver() throws Exception {
                                                                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                            InputStream input = mock(InputStream.class);
                                                                                                                                            
                                                                                                                                            thrown.expect(ArchiveException.class);
                                                                                                                                            thrown.expectMessage("Archiver: UNKNOWN not found.");
                                                                                                                                            
                                                                                                                                            factory.createArchiveInputStream("UNKNOWN", input);
                                                                                                                                        }

 @Test
                                                                                                                                        public void testCreateArchiveInputStream_ValidArchivers() throws Exception {
                                                                                                                                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                            InputStream input = mock(InputStream.class);
                                                                                                                                            
                                                                                                                                            // Test all supported archiver types
                                                                                                                                            ArchiveInputStream arStream = factory.createArchiveInputStream(ArchiveStreamFactory.AR, input);
                                                                                                                                            assertTrue(arStream instanceof ArArchiveInputStream);
                                                                                                                                            
                                                                                                                                            ArchiveInputStream zipStream = factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, input);
                                                                                                                                            assertTrue(zipStream instanceof ZipArchiveInputStream);
                                                                                                                                            
                                                                                                                                            ArchiveInputStream tarStream = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, input);
                                                                                                                                            assertTrue(tarStream instanceof TarArchiveInputStream);
                                                                                                                                            
                                                                                                                                            ArchiveInputStream jarStream = factory.createArchiveInputStream(ArchiveStreamFactory.JAR, input);
                                                                                                                                            assertTrue(jarStream instanceof JarArchiveInputStream);
                                                                                                                                            
                                                                                                                                            ArchiveInputStream cpioStream = factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, input);
                                                                                                                                            assertTrue(cpioStream instanceof CpioArchiveInputStream);
                                                                                                                                            
                                                                                                                                            ArchiveInputStream dumpStream = factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, input);
                                                                                                                                            assertTrue(dumpStream instanceof DumpArchiveInputStream);
                                                                                                                                        }

 @Test
                                                                                                                                   public void testCreateArchiveInputStream_TarDetectionException_SilentlyIgnored() throws Exception {
                                                                                                                                       // Arrange
                                                                                                                                       InputStream in = mock(InputStream.class);
                                                                                                                                       byte[] signature = new byte[12];
                                                                                                                                       byte[] tarheader = new byte[512];
                                                                                                                                       
                                                                                                                                       // Mock the stream behavior
                                                                                                                                       when(in.markSupported()).thenReturn(true);
                                                                                                                                       when(in.read(signature)).thenReturn(signature.length);
                                                                                                                                       when(in.read(tarheader)).thenReturn(tarheader.length);
                                                                                                                                       
                                                                                                                                       // Make sure none of the archive types match
                                                                                                                                       when(ZipArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                                                                                                                                       when(JarArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                                                                                                                                       when(ArArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                                                                                                                                       when(CpioArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                                                                                                                                       when(DumpArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                                                                                                                                       when(TarArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                                                                                                                                       
                                                                                                                                       // Act & Assert
                                                                                                                                       try {
                                                                                                                                           new ArchiveStreamFactory().createArchiveInputStream(in);
                                                                                                                                           fail("Expected ArchiveException");
                                                                                                                                       } catch (ArchiveException e) {
                                                                                                                                           // Verify the exception message indicates no archiver found
                                                                                                                                           assertEquals("No Archiver found for the stream signature", e.getMessage());
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Verify the mocked interactions
                                                                                                                                       verify(in, times(2)).mark(anyInt());
                                                                                                                                       verify(in, times(2)).reset();
                                                                                                                                   }

 @Test
                                                                                                                                   public void testCreateArchiveInputStream_PropagatesNonIOException() throws Exception {
                                                                                                                                       // Setup
                                                                                                                                       String archiverName = ArchiveStreamFactory.ZIP; // valid archiver name
                                                                                                                                       InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                       
                                                                                                                                       // Make the mock throw a RuntimeException when any method is called
                                                                                                                                       when(mockInputStream.read()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                       
                                                                                                                                       // Expect the exception to be thrown
                                                                                                                                       thrown.expect(RuntimeException.class);
                                                                                                                                       thrown.expectMessage("Test exception");
                                                                                                                                       
                                                                                                                                       // Execute
                                                                                                                                       ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                       factory.createArchiveInputStream(archiverName, mockInputStream);
                                                                                                                                       
                                                                                                                                       // Verification - if we get here, the test fails (exception should have been thrown)
                                                                                                                                       // The mock interaction verification happens automatically
                                                                                                                                   }

 @Test
                                                                                                                              public void testCreateArchiveInputStream_NonIOExceptionShouldNotBeCaught() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  
                                                                                                                                  // Configure mock to throw RuntimeException during mark operation
                                                                                                                                  doThrow(new RuntimeException("Test exception")).when(mockInputStream).mark(anyInt());
                                                                                                                                  
                                                                                                                                  // Declare expected exception rule
                                                                                                                                  ExpectedException expectedException = ExpectedException.none();
                                                                                                                                  expectedException.expect(RuntimeException.class);
                                                                                                                                  expectedException.expectMessage("Test exception");
                                                                                                                                  
                                                                                                                                  // Execute
                                                                                                                                  factory.createArchiveInputStream(mockInputStream);
                                                                                                                              }

 @Test
                                                                                                                              public void testCreateArchiveInputStream_IOExceptionShouldBeCaught() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  
                                                                                                                                  // Configure mock to throw IOException during mark operation
                                                                                                                                  doThrow(new IOException("IO error")).when(mockInputStream).mark(anyInt());
                                                                                                                                  
                                                                                                                                  // Expect the IOException to be wrapped in ArchiveException
                                                                                                                                  ExpectedException expectedException = ExpectedException.none();
                                                                                                                                  expectedException.expect(ArchiveException.class);
                                                                                                                                  expectedException.expectMessage("Could not use reset and mark operations.");
                                                                                                                                  
                                                                                                                                  // Execute
                                                                                                                                  factory.createArchiveInputStream(mockInputStream);
                                                                                                                              }

 @Test
                                                                                                                              public void testCreateArchiveInputStreamWithValidArchiverReturnsCorrectStream() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                  
                                                                                                                                  // Act and Assert
                                                                                                                                  assertTrue(factory.createArchiveInputStream(ArchiveStreamFactory.AR, inputStream) instanceof ArArchiveInputStream);
                                                                                                                                  assertTrue(factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, inputStream) instanceof ZipArchiveInputStream);
                                                                                                                                  assertTrue(factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream) instanceof TarArchiveInputStream);
                                                                                                                                  assertTrue(factory.createArchiveInputStream(ArchiveStreamFactory.JAR, inputStream) instanceof JarArchiveInputStream);
                                                                                                                                  assertTrue(factory.createArchiveInputStream(ArchiveStreamFactory.CPIO, inputStream) instanceof CpioArchiveInputStream);
                                                                                                                                  assertTrue(factory.createArchiveInputStream(ArchiveStreamFactory.DUMP, inputStream) instanceof DumpArchiveInputStream);
                                                                                                                              }

 @Test
                                                                                                                              public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowWithCorrectMessage() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                  when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                                                  doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                                                                                                                                  
                                                                                                                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                                  
                                                                                                                                  // Set expectation for exception type and message
                                                                                                                                  thrown.expect(ArchiveException.class);
                                                                                                                                  thrown.expectMessage("Could not use reset and mark operations.");
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  factory.createArchiveInputStream(mockInputStream);
                                                                                                                              }

 @Test
                                                                                                                         public void testCreateArchiveInputStreamWithUnknownArchiverThrowsCorrectExceptionMessage() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                             InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                             String unknownArchiver = "UNKNOWN";
                                                                                                                             String expectedMessage = "Archiver: " + unknownArchiver + " not found.";
                                                                                                                             
                                                                                                                             try {
                                                                                                                                 // Act
                                                                                                                                 factory.createArchiveInputStream(unknownArchiver, inputStream);
                                                                                                                                 fail("Expected ArchiveException to be thrown");
                                                                                                                             } catch (ArchiveException e) {
                                                                                                                                 // Assert
                                                                                                                                 assertEquals(expectedMessage, e.getMessage());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testCreateArchiveInputStreamWithNullArchiverNameThrowsException() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                             InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                             
                                                                                                                             // Setup expected exception
                                                                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                                                                             expectedException.expect(IllegalArgumentException.class);
                                                                                                                             expectedException.expectMessage("Archivername must not be null.");
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             factory.createArchiveInputStream(null, inputStream);
                                                                                                                         }

 @Test
                                                                                                                         public void testCreateArchiveInputStreamWithNullInputStreamThrowsException() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                             
                                                                                                                             // Define expected exception rule
                                                                                                                             org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                                                                                             expectedException.expect(IllegalArgumentException.class);
                                                                                                                             expectedException.expectMessage("InputStream must not be null.");
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                                                                                                         }

 @Test
                                                                                                                         public void testCreateArchiveInputStreamWithUnknownArchiverShouldThrowExceptionWithCause() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                                             InputStream in = new ByteArrayInputStream(new byte[0]);
                                                                                                                             String unknownArchiver = "UNKNOWN_FORMAT";
                                                                                                                             
                                                                                                                             // Act & Assert
                                                                                                                             try {
                                                                                                                                 factory.createArchiveInputStream(unknownArchiver, in);
                                                                                                                                 fail("Expected ArchiveException to be thrown");
                                                                                                                             } catch (ArchiveException e) {
                                                                                                                                 // Verify exception message contains archiver name
                                                                                                                                 assertTrue(e.getMessage().contains(unknownArchiver));
                                                                                                                                 // Verify exception has a cause (this will fail for the mutant)
                                                                                                                                 assertNotNull("Exception should have a cause", e.getCause());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                public void testCreateArchiveInputStream_IOExceptionShouldIncludeCause() throws Exception {
                                                                                                    // Arrange
                                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                                    when(mockInput.markSupported()).thenReturn(true);
                                                                                                    // Make mark() throw IOException to trigger the exception path
                                                                                                    doThrow(new IOException("Test IO Error")).when(mockInput).mark(anyInt());
                                                                                                    
                                                                                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                    
                                                                                                    // Set up ExpectedException rule
                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                    thrown.expect(ArchiveException.class);
                                                                                                    thrown.expectMessage("Could not use reset and mark operations");
                                                                                                    thrown.expectCause(org.hamcrest.CoreMatchers.isA(IOException.class));
                                                                                                    
                                                                                                    // Act
                                                                                                    factory.createArchiveInputStream(mockInput);
                                                                                                    
                                                                                                    // Assert - handled by ExpectedException rule
                                                                                                }

 @Test
                                                                                                public void testCreateArchiveInputStreamWithUnknownArchiverThrowsArchiveException() throws Exception {
                                                                                                    // Arrange
                                                                                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                    InputStream mockInputStream = mock(InputStream.class);
                                                                                                    String unknownArchiver = "UNKNOWN_FORMAT";
                                                                                                    
                                                                                                    // Set expectation for exception type and message
                                                                                                    thrown.expect(ArchiveException.class);
                                                                                                    thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                                                                                    
                                                                                                    // Act
                                                                                                    factory.createArchiveInputStream(unknownArchiver, mockInputStream);
                                                                                                    
                                                                                                    // Assertion is handled by the ExpectedException rule
                                                                                                }

 @Test(expected = ArchiveException.class)
                                                                                            public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowArchiveException() throws Exception {
                                                                                                // Arrange
                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                when(mockInputStream.markSupported()).thenReturn(true);
                                                                                                doThrow(new IOException("mark failed")).when(mockInputStream).mark(anyInt());
                                                                                                
                                                                                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                
                                                                                                // Act
                                                                                                factory.createArchiveInputStream(mockInputStream);
                                                                                                
                                                                                                // Assert - expected exception is declared in annotation
                                                                                                // Test will fail if RuntimeException is thrown instead of ArchiveException
                                                                                            }

 @Test
                                                                                               public void testCreateArchiveInputStreamWithUnknownFormat() throws Exception {
                                                                                                   // Arrange
                                                                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                                   InputStream mockInputStream = mock(InputStream.class);
                                                                                                   String unknownFormat = "UNKNOWN_FORMAT";
                                                                                                   
                                                                                                   try {
                                                                                                       // Act
                                                                                                       factory.createArchiveInputStream(unknownFormat, mockInputStream);
                                                                                                       fail("Expected ArchiveException to be thrown");
                                                                                                   } catch (ArchiveException e) {
                                                                                                       // Assert
                                                                                                       // Original would expect: assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                       // For mutant detection, we expect the message to not match the original fixed string
                                                                                                       assertNotEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                       // Additional assertion to ensure it's the right type of exception
                                                                                                       assertTrue(e.getMessage().contains(unknownFormat));
                                                                                                   }
                                                                                               }

 @Test(expected = ArchiveException.class)
                                                                                           public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowWithFixedMessage() throws Exception {
                                                                                               // Arrange
                                                                                               InputStream mockInput = mock(InputStream.class);
                                                                                               when(mockInput.markSupported()).thenReturn(true);
                                                                                               doThrow(new IOException("Simulated IO error")).when(mockInput).mark(anyInt());
                                                                                               
                                                                                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                               
                                                                                               try {
                                                                                                   // Act
                                                                                                   factory.createArchiveInputStream(mockInput);
                                                                                                   fail("Expected ArchiveException to be thrown");
                                                                                               } catch (ArchiveException e) {
                                                                                                   // Assert
                                                                                                   assertEquals("Could not use reset and mark operations.", e.getMessage());
                                                                                                   assertNotNull(e.getCause());
                                                                                                   assertEquals("Simulated IO error", e.getCause().getMessage());
                                                                                                   throw e;
                                                                                               }
                                                                                           }

 @Test
                                                                                     public void testCreateArchiveInputStream_NonIOExceptionDuringTarDetection() throws Exception {
                                                                                         // Create expected exception rule
                                                                                         ExpectedException expectedException = ExpectedException.none();
                                                                                         
                                                                                         // Create a mock InputStream that will pass initial checks
                                                                                         InputStream in = mock(InputStream.class);
                                                                                         when(in.markSupported()).thenReturn(true);
                                                                                         
                                                                                         // Setup the stream to return enough bytes for TAR detection
                                                                                         byte[] fakeData = new byte[512];
                                                                                         when(in.read(any(byte[].class))).thenReturn(fakeData.length);
                                                                                         
                                                                                         // Mock TarArchiveInputStream to throw IllegalArgumentException when reading entries
                                                                                         TarArchiveInputStream mockTarStream = mock(TarArchiveInputStream.class);
                                                                                         when(mockTarStream.getNextEntry()).thenThrow(new IllegalArgumentException("Invalid TAR header"));
                                                                                         
                                                                                         // Create a spy of the factory to intercept archive stream creation
                                                                                         ArchiveStreamFactory factory = spy(new ArchiveStreamFactory());
                                                                                         
                                                                                         // Mock the internal behavior to return our mock TarArchiveInputStream
                                                                                         doReturn(mockTarStream).when(factory).createArchiveInputStream("tar", in);
                                                                                         
                                                                                         // Expect the exception
                                                                                         expectedException.expect(IllegalArgumentException.class);
                                                                                         expectedException.expectMessage("Invalid TAR header");
                                                                                         
                                                                                         // Call the method - this should throw the exception
                                                                                         factory.createArchiveInputStream(in);
                                                                                     }

 @Test
                                                                                 public void testCreateArchiveInputStream_PropagatesRuntimeException() throws Exception {
                                                                                     // Setup
                                                                                     String archiverName = "zip"; // Use any valid archiver name
                                                                                     InputStream mockInput = new InputStream() {
                                                                                         @Override
                                                                                         public int read() throws IOException {
                                                                                             throw new RuntimeException("Test exception");
                                                                                         }
                                                                                     };
                                                                                     
                                                                                     // Execute and verify exception
                                                                                     try {
                                                                                         ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                         factory.createArchiveInputStream(archiverName, mockInput);
                                                                                         fail("Expected RuntimeException to be thrown");
                                                                                     } catch (RuntimeException e) {
                                                                                         assertEquals("Test exception", e.getMessage());
                                                                                     }
                                                                                 }

 @Test
                                                                                 public void testCreateArchiveInputStream_PropagatesError1() throws Exception {
                                                                                     // Arrange
                                                                                     InputStream mockIn = mock(InputStream.class);
                                                                                     when(mockIn.read()).thenThrow(new OutOfMemoryError("Test Error"));
                                                                                     
                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                     
                                                                                     // Expect
                                                                                     thrown.expect(OutOfMemoryError.class);
                                                                                     thrown.expectMessage("Test Error");
                                                                                     
                                                                                     // Act
                                                                                     factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockIn);
                                                                                     
                                                                                     // Assert - handled by ExpectedException rule
                                                                                 }

 @Test
                                                                                 public void testCreateArchiveInputStream_ShouldPropagateErrorDuringTarDetection() throws Exception {
                                                                                     // Setup
                                                                                     InputStream input = mock(InputStream.class);
                                                                                     byte[] signature = new byte[12];
                                                                                     byte[] tarheader = new byte[512];
                                                                                     
                                                                                     // Configure mock behavior
                                                                                     when(input.markSupported()).thenReturn(true);
                                                                                     when(input.read(signature)).thenReturn(12); // Not any known format
                                                                                     when(input.read(tarheader)).thenThrow(new AssertionError("Simulated Error"));
                                                                                     
                                                                                     // Expect the Error to propagate
                                                                                     thrown.expect(AssertionError.class);
                                                                                     thrown.expectMessage("Simulated Error");
                                                                                     
                                                                                     // Execute
                                                                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                     factory.createArchiveInputStream(input);
                                                                                 }

 @Test
                                                                                public void testCreateArchiveInputStream_PropagatesConstructorException() throws Exception {
                                                                                    // Arrange
                                                                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                                                    InputStream mockInput = mock(InputStream.class);
                                                                                    
                                                                                    // Simulate constructor throwing an exception
                                                                                    when(mockInput.read()).thenThrow(new IOException("Test exception"));
                                                                                    
                                                                                    thrown.expect(ArchiveException.class);
                                                                                    thrown.expectMessage("Archiver: ar not found.");
                                                                                    
                                                                                    // Act
                                                                                    try {
                                                                                        factory.createArchiveInputStream(ArchiveStreamFactory.AR, mockInput);
                                                                                    } catch (Exception e) {
                                                                                        // Verify the exception was caught and not swallowed
                                                                                        verify(mockInput).read(); // Verify interaction with mock
                                                                                        throw e;
                                                                                    }
                                                                                }

 @Test
                                               public void testCreateArchiveInputStream_HandlesTarExceptionGracefully() throws Exception {
                                                   // Arrange
                                                   InputStream in = mock(InputStream.class);
                                                   when(in.markSupported()).thenReturn(true);
                                                   
                                                   // First 12 bytes (for initial signature check)
                                                   byte[] fakeSignature = new byte[12];
                                                   when(in.read(any(byte[].class)))
                                                       .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                                                           @Override
                                                           public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                                                               byte[] buf = (byte[]) invocation.getArguments()[0];
                                                               System.arraycopy(fakeSignature, 0, buf, 0, Math.min(fakeSignature.length, buf.length));
                                                               return buf.length;
                                                           }
                                                       });
                                                   
                                                   // When checking for TAR (512 bytes)
                                                   byte[] tarHeader = new byte[512];
                                                   when(in.read(tarHeader)).thenReturn(512);
                                                   
                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                   
                                                   // Act and Assert
                                                   try {
                                                       factory.createArchiveInputStream(in);
                                                       fail("Expected ArchiveException");
                                                   } catch (ArchiveException e) {
                                                       // Expected - no archiver found
                                                       assertTrue(e.getMessage().contains("No Archiver found"));
                                                   }
                                                   
                                                   // Verify mark/reset were called appropriately
                                                   verify(in, atLeastOnce()).mark(anyInt());
                                                   verify(in, atLeastOnce()).reset();
                                               }

 @Test
                                               public void testCreateArchiveInputStreamForTar1() throws Exception {
                                                   // Setup
                                                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                                   InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                   
                                                   // Test exact match
                                                   Object result1 = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
                                                   assertTrue("Should return TarArchiveInputStream for exact TAR match", 
                                                             result1 instanceof TarArchiveInputStream);
                                                   
                                                   // Test case-insensitive match
                                                   Object result2 = factory.createArchiveInputStream("tar", inputStream);
                                                   assertTrue("Should return TarArchiveInputStream for lowercase 'tar'", 
                                                             result2 instanceof TarArchiveInputStream);
                                                   
                                                   Object result3 = factory.createArchiveInputStream("TaR", inputStream);
                                                   assertTrue("Should return TarArchiveInputStream for mixed case 'TaR'", 
                                                             result3 instanceof TarArchiveInputStream);
                                                   
                                                   // Test near-miss that shouldn't match
                                                   try {
                                                       factory.createArchiveInputStream("TARX", inputStream);
                                                       fail("Should throw ArchiveException for invalid TAR variant");
                                                   } catch (ArchiveException e) {
                                                       // Expected
                                                   }
                                                   
                                                   try {
                                                       factory.createArchiveInputStream("TAR ", inputStream);
                                                       fail("Should throw ArchiveException for TAR with trailing space");
                                                   } catch (ArchiveException e) {
                                                       // Expected
                                                   }
                                               }

 @Test
                                      public void testCreateArchiveInputStream_InvalidTarSignature_ThrowsArchiveException() throws Exception {
                                          // Arrange
                                          InputStream in = mock(InputStream.class);
                                          
                                          // Mock behavior for initial checks
                                          when(in.markSupported()).thenReturn(true);
                                          
                                          // First signature check (12 bytes)
                                          byte[] fakeSignature = new byte[12];
                                          when(in.read(any(byte[].class))).thenAnswer(invocation -> {
                                              byte[] buf = (byte[]) invocation.getArguments()[0];
                                              System.arraycopy(fakeSignature, 0, buf, 0, Math.min(fakeSignature.length, buf.length));
                                              return fakeSignature.length;
                                          });
                                          
                                          // Mock behavior for TAR check (512 bytes)
                                          byte[] fakeTarHeader = new byte[512];
                                          // Make it look like a TAR initially
                                          fakeTarHeader[257] = 'u';
                                          fakeTarHeader[258] = 's';
                                          fakeTarHeader[259] = 't';
                                          fakeTarHeader[260] = 'a';
                                          fakeTarHeader[261] = 'r';
                                          
                                          when(in.read(any(byte[].class))).thenAnswer(invocation -> {
                                              byte[] buf = (byte[]) invocation.getArguments()[0];
                                              System.arraycopy(fakeTarHeader, 0, buf, 0, fakeTarHeader.length);
                                              return fakeTarHeader.length;
                                          });
                                          
                                          // Mock behavior to throw exception during actual TAR processing
                                          when(in.read(any(byte[].class), anyInt(), anyInt())).thenThrow(new IOException("Invalid TAR format"));
                                          
                                          // Act
                                          new ArchiveStreamFactory().createArchiveInputStream(in);
                                      }

 @Test
                                      public void testCreateArchiveInputStreamWithInvalidArchiverName() throws Exception {
                                          // Prepare test data
                                          String invalidArchiverName = "INVALID_FORMAT";
                                          InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                          
                                          // Set expectation for exception
                                          thrown.expect(ArchiveException.class);
                                          thrown.expectMessage("Archiver: " + invalidArchiverName + " not found.");
                                          
                                          // Create instance and call method
                                          ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                          factory.createArchiveInputStream(invalidArchiverName, inputStream);
                                      }

 @Test
                                 public void testCreateArchiveInputStream_InvalidTarWithLongSignature_ThrowsArchiveException() throws Exception {
                                     // Arrange
                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                     
                                     // Create mock input stream that:
                                     // 1. Returns a signature length >= 512
                                     // 2. Fails TarArchiveInputStream detection
                                     InputStream mockIn = mock(InputStream.class);
                                     when(mockIn.markSupported()).thenReturn(true);
                                     
                                     // First signature check (12 bytes)
                                     byte[] fakeSignature = new byte[12];
                                     when(mockIn.read(fakeSignature)).thenReturn(fakeSignature.length);
                                     
                                     // Second signature check (32 bytes)
                                     byte[] dumpsig = new byte[32];
                                     when(mockIn.read(dumpsig)).thenReturn(dumpsig.length);
                                     
                                     // Tar signature check (512 bytes)
                                     byte[] tarheader = new byte[512];
                                     when(mockIn.read(tarheader)).thenReturn(tarheader.length); // returns 512
                                     
                                     // Setup expectation
                                     ExpectedException expectedException = ExpectedException.none();
                                     expectedException.expect(ArchiveException.class);
                                     expectedException.expectMessage("No Archiver found for the stream signature");
                                     
                                     // Act
                                     factory.createArchiveInputStream(mockIn);
                                     
                                     // Assert - handled by ExpectedException rule
                                 }

 @Test
                                 public void testCreateArchiveInputStream_PropagatesNonIOException1() throws Exception {
                                     // Arrange
                                     ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                     InputStream mockInput = mock(InputStream.class);
                                     
                                     // Mock the input stream to throw a RuntimeException when used
                                     when(mockInput.read()).thenThrow(new RuntimeException("Test exception"));
                                     
                                     // Expect the RuntimeException to be thrown
                                     thrown.expect(RuntimeException.class);
                                     thrown.expectMessage("Test exception");
                                     
                                     // Act
                                     factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, mockInput);
                                     
                                     // Assert - handled by ExpectedException rule
                                 }

 @Test(expected = RuntimeException.class)
                             public void testCreateArchiveInputStream_ShouldPropagateNonIOException() throws Exception {
                                 // Arrange
                                 InputStream mockInputStream = mock(InputStream.class);
                                 when(mockInputStream.markSupported()).thenReturn(true);
                                 
                                 // Simulate IOException during first mark operation
                                 doThrow(new RuntimeException("Test exception")).when(mockInputStream).mark(anyInt());
                                 
                                 // Act
                                 new ArchiveStreamFactory().createArchiveInputStream(mockInputStream);
                                 
                                 // Assert - expecting the RuntimeException to propagate (test will pass if it does)
                                 // If mutant is present, it would catch the RuntimeException and throw ArchiveException instead
                             }

 @Test
                                public void testCreateArchiveInputStreamWithUnknownArchiverThrowsCorrectException() throws Exception {
                                    // Arrange
                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                    String unknownArchiver = "UNKNOWN";
                                    InputStream in = new ByteArrayInputStream(new byte[0]);
                                    
                                    // Set expectation for exception type and message
                                    thrown.expect(ArchiveException.class);
                                    thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                    
                                    // Act
                                    factory.createArchiveInputStream(unknownArchiver, in);
                                }

 @Test
                                public void testCreateArchiveInputStreamWithNullArchiverNameThrowsException1() throws Exception {
                                    // Arrange
                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                    InputStream in = new ByteArrayInputStream(new byte[0]);
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("Archivername must not be null.");
                                    
                                    // Act
                                    factory.createArchiveInputStream(null, in);
                                }

 @Test
                                public void testCreateArchiveInputStreamWithNullInputStreamThrowsException1() throws Exception {
                                    // Arrange
                                    ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                    
                                    thrown.expect(IllegalArgumentException.class);
                                    thrown.expectMessage("InputStream must not be null.");
                                    
                                    // Act
                                    factory.createArchiveInputStream(ArchiveStreamFactory.AR, null);
                                }

 @Test(expected = ArchiveException.class)
                            public void testCreateArchiveInputStream_IOExceptionDuringMarkReset_VerifiesExceptionMessage() throws Exception {
                                // Arrange
                                InputStream mockInputStream = mock(InputStream.class);
                                when(mockInputStream.markSupported()).thenReturn(true);
                                doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                                
                                ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                
                                // Act
                                try {
                                    factory.createArchiveInputStream(mockInputStream);
                                    fail("Expected ArchiveException to be thrown");
                                } catch (ArchiveException e) {
                                    // Assert
                                    assertEquals("Could not use reset and mark operations.", e.getMessage());
                                    throw e;
                                }
                            }

 @Test(expected = ArchiveException.class)
                           public void testCreateArchiveInputStreamWithUnknownArchiverShouldThrowArchiveException() throws Exception {
                               // Arrange
                               String unknownArchiver = "UNKNOWN_FORMAT";
                               InputStream mockInputStream = mock(InputStream.class);
                               
                               // Act
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               factory.createArchiveInputStream(unknownArchiver, mockInputStream);
                               
                               // Assert - The expected exception annotation will handle the verification
                           }

 @Test(expected = ArchiveException.class)
                           public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowArchiveException1() throws Exception {
                               // Arrange
                               InputStream mockInputStream = mock(InputStream.class);
                               when(mockInputStream.markSupported()).thenReturn(true);
                               doThrow(new IOException("mark failed")).when(mockInputStream).mark(anyInt());
                               
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               
                               // Act & Assert
                               factory.createArchiveInputStream(mockInputStream);
                           }

 @Test
                              public void testCreateArchiveInputStreamWithUnknownArchiverThrowsCorrectException1() throws Exception {
                                  // Setup
                                  ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                  InputStream inputStream = mock(InputStream.class);
                                  String unknownArchiver = "UNKNOWN";
                                  
                                  // Expect exception with exact message
                                  thrown.expect(ArchiveException.class);
                                  thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                  
                                  // Test
                                  factory.createArchiveInputStream(unknownArchiver, inputStream);
                              }

 @Test(expected = ArchiveException.class)
                          public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowWithFixedMessage1() throws Exception {
                              // Arrange
                              InputStream mockInputStream = mock(InputStream.class);
                              when(mockInputStream.markSupported()).thenReturn(true);
                              doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
                              
                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                              
                              try {
                                  // Act
                                  factory.createArchiveInputStream(mockInputStream);
                              } catch (ArchiveException e) {
                                  // Assert
                                  assertEquals("Could not use reset and mark operations.", e.getMessage());
                                  throw e;
                              }
                          }

 @Test
                             public void testCreateArchiveInputStream_PropagatesError2() throws Exception {
                                 // Setup
                                 String archiverName = ArchiveStreamFactory.AR; // valid archiver name
                                 InputStream in = mock(InputStream.class);
                                 
                                 // Make the input stream throw an Error when read
                                 when(in.read(any(byte[].class))).thenThrow(new OutOfMemoryError("Test Error"));
                         
                                 // Expect the Error to propagate
                                 thrown.expect(OutOfMemoryError.class);
                                 thrown.expectMessage("Test Error");
                         
                                 // Test
                                 ArchiveStreamFactory factory = new ArchiveStreamFactory();
                                 factory.createArchiveInputStream(archiverName, in);
                                 
                                 // The mutant would catch the Error and possibly wrap it,
                                 // while original code lets it propagate
                             }

 @Test(expected = Error.class)
                         public void testCreateArchiveInputStream_ThrowsErrorDuringTarDetection() throws Exception {
                             // Arrange
                             InputStream in = mock(InputStream.class);
                             byte[] signature = new byte[12];
                             byte[] tarheader = new byte[512];
                             
                             // Mock the initial signature read to pass first checks but not match any format
                             when(in.read(signature)).thenReturn(signature.length);
                             when(in.read(tarheader)).thenThrow(new AssertionError("Test Error"));
                             
                             // Mock markSupported and mark operations
                             when(in.markSupported()).thenReturn(true);
                             doNothing().when(in).mark(anyInt());
                             doNothing().when(in).reset();
                             
                             // Act & Assert
                             // This should throw the Error in original code, but would be caught in mutant
                             new ArchiveStreamFactory().createArchiveInputStream(in);
                         }

 @Test
                            public void testCreateArchiveInputStream_NullArchiverName3() throws Exception {
                                // Setup
                                InputStream inputStream = mock(InputStream.class);
                                
                                // Expect exception
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("Archivername must not be null.");
                                
                                // Test
                                new ArchiveStreamFactory().createArchiveInputStream(null, inputStream);
                            }

 @Test
                            public void testCreateArchiveInputStream_NullInputStream3() throws Exception {
                                // Setup
                                String archiverName = ArchiveStreamFactory.ZIP;
                                
                                // Expect exception
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("InputStream must not be null.");
                                
                                // Test
                                new ArchiveStreamFactory().createArchiveInputStream(archiverName, null);
                            }

 @Test
                            public void testCreateArchiveInputStream_UnknownArchiver1() throws Exception {
                                // Setup
                                String unknownArchiver = "UNKNOWN";
                                InputStream inputStream = mock(InputStream.class);
                                
                                // Expect exception
                                thrown.expect(ArchiveException.class);
                                thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
                                
                                // Test
                                new ArchiveStreamFactory().createArchiveInputStream(unknownArchiver, inputStream);
                            }

 @Test
                            public void testCreateArchiveInputStream_ValidArchiver() throws Exception {
                                // Setup
                                String archiverName = ArchiveStreamFactory.ZIP;
                                InputStream inputStream = mock(InputStream.class);
                                
                                // Test
                                ArchiveInputStream result = new ArchiveStreamFactory()
                                    .createArchiveInputStream(archiverName, inputStream);
                                
                                // Verify
                                assertNotNull(result);
                                assertTrue(result instanceof ZipArchiveInputStream);
                            }

 @Test
                        public void testCreateArchiveInputStream_HandlesTarDetectionException() throws Exception {
                            // Create a mock InputStream that:
                            // 1. Supports mark operations
                            // 2. Returns a signature length >= 512
                            // 3. Throws IOException when TarArchiveInputStream reads entries
                            InputStream mockIn = mock(InputStream.class);
                            when(mockIn.markSupported()).thenReturn(true);
                            
                            // First read (12-byte signature)
                            when(mockIn.read(any(byte[].class))).thenReturn(512);
                            
                            // Mock behavior for Tar detection
                            // This will cause the TarArchiveInputStream to throw an exception
                            InputStream throwingStream = new InputStream() {
                                @Override
                                public int read() throws IOException {
                                    throw new IOException("Test exception");
                                }
                            };
                            
                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                            
                            try {
                                factory.createArchiveInputStream(mockIn);
                                fail("Expected ArchiveException");
                            } catch (ArchiveException e) {
                                // Verify we get the expected "No Archiver found" exception
                                assertEquals("No Archiver found for the stream signature", e.getMessage());
                            }
                            
                            // Verify mark/reset interactions
                            verify(mockIn, atLeastOnce()).mark(anyInt());
                            verify(mockIn, atLeastOnce()).reset();
                        }

 @Test
                           public void testCreateArchiveInputStream_TarCase() throws Exception {
                               // Setup
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               InputStream inputStream = mock(InputStream.class);
                               
                               // Test exact match
                               ArchiveInputStream result = factory.createArchiveInputStream(ArchiveStreamFactory.TAR, inputStream);
                               assertTrue(result instanceof TarArchiveInputStream);
                               
                               // Test case-insensitive match
                               result = factory.createArchiveInputStream("tar", inputStream);
                               assertTrue(result instanceof TarArchiveInputStream);
                               
                               result = factory.createArchiveInputStream("TaR", inputStream);
                               assertTrue(result instanceof TarArchiveInputStream);
                               
                               // Verify input stream is passed through
                               TarArchiveInputStream tarStream = (TarArchiveInputStream) result;
                               // TarArchiveInputStream doesn't expose the underlying stream directly,
                               // but we can verify it's not null as a basic check
                               assertNotNull(tarStream);
                           }

 @Test
                           public void testCreateArchiveInputStream_TarCaseWithNullInput() throws Exception {
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               thrown.expect(IllegalArgumentException.class);
                               thrown.expectMessage("InputStream must not be null.");
                               factory.createArchiveInputStream(ArchiveStreamFactory.TAR, null);
                           }

 @Test
                           public void testCreateArchiveInputStream_TarCaseWithNullArchiver() throws Exception {
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               InputStream inputStream = mock(InputStream.class);
                               thrown.expect(IllegalArgumentException.class);
                               thrown.expectMessage("Archivername must not be null.");
                               factory.createArchiveInputStream(null, inputStream);
                           }

 @Test
                           public void testCreateArchiveInputStream_TarAutodetection() throws Exception {
                               // Setup mock InputStream
                               InputStream mockIn = mock(InputStream.class);
                               
                               // First signature read (12 bytes) - doesn't match any format
                               when(mockIn.markSupported()).thenReturn(true);
                               byte[] fakeSignature = new byte[12];
                               when(mockIn.read(fakeSignature)).thenReturn(12);
                               
                               // Dump signature read (32 bytes) - doesn't match
                               byte[] fakeDumpSig = new byte[32];
                               when(mockIn.read(fakeDumpSig)).thenReturn(32);
                               
                               // Tar header read (512 bytes) - valid TAR
                               byte[] validTarHeader = new byte[512];
                               // Create a valid tar header
                               System.arraycopy("ustar".getBytes(), 0, validTarHeader, 257, 5);
                               when(mockIn.read(validTarHeader)).thenReturn(512);
                               
                               // Mock mark/reset behavior
                               doNothing().when(mockIn).mark(anyInt());
                               doNothing().when(mockIn).reset();
                               
                               // Test
                               ArchiveStreamFactory factory = new ArchiveStreamFactory();
                               ArchiveInputStream result = factory.createArchiveInputStream(mockIn);
                               
                               // Verify
                               assertNotNull("Should return a stream for valid TAR", result);
                               assertTrue("Should return TarArchiveInputStream", 
                                         result instanceof TarArchiveInputStream);
                               
                               // Verify interactions
                               verify(mockIn, atLeastOnce()).mark(anyInt());
                               verify(mockIn, atLeastOnce()).reset();
                           }

 @Test
                          public void testCreateArchiveInputStream_TarCase1() throws Exception {
                              // Prepare test data
                              String archiverName = ArchiveStreamFactory.TAR; // Use the constant
                              InputStream in = mock(InputStream.class);
                              
                              // Call the method
                              ArchiveStreamFactory factory = new ArchiveStreamFactory();
                              ArchiveInputStream result = factory.createArchiveInputStream(archiverName, in);
                              
                              // Verify the result
                              assertNotNull("Result should not be null", result);
                              assertTrue("Should return TarArchiveInputStream for TAR case", 
                                        result instanceof TarArchiveInputStream);
                              
                              // Verify the input stream was properly passed
                              // This is implementation specific, but we can at least verify the stream was used
                              verify(in, never()).close(); // Ensure the stream wasn't closed
                          }

 @Test(expected = ArchiveException.class)
                      public void testCreateArchiveInputStream_InvalidTarData_ThrowsArchiveException() throws Exception {
                          // Arrange
                          InputStream mockInput = mock(InputStream.class);
                          
                          // Setup mock to:
                          // 1. Support mark operations
                          // 2. Return signature length >= 512 (triggering TAR detection)
                          // 3. Return invalid TAR header data that will fail detection
                          when(mockInput.markSupported()).thenReturn(true);
                          
                          // First signature check (12 bytes)
                          byte[] fakeSignature = new byte[12];
                          when(mockInput.read(any(byte[].class))).thenReturn(fakeSignature.length);
                          
                          // Dump signature check (32 bytes)
                          byte[] fakeDumpSig = new byte[32];
                          when(mockInput.read(any(byte[].class))).thenReturn(fakeDumpSig.length);
                          
                          // Tar header check (512 bytes)
                          byte[] invalidTarHeader = new byte[512];
                          when(mockInput.read(any(byte[].class))).thenReturn(invalidTarHeader.length);
                          
                          // Make TarArchiveInputStream.matches return false
                          when(TarArchiveInputStream.matches(any(byte[].class), anyInt())).thenReturn(false);
                          
                          // Act
                          new ArchiveStreamFactory().createArchiveInputStream(mockInput);
                          
                          // Assert - should throw ArchiveException (expected in annotation)
                      }

 @Test
                         public void testCreateArchiveInputStreamWithMixedCaseArchiverName() throws Exception {
                             // Prepare test data
                             String mixedCaseArchiverName = "zIp";  // Mixed case version of ZIP
                             InputStream in = new ByteArrayInputStream(new byte[0]);
                             
                             // Set expectation
                             thrown.expect(ArchiveException.class);
                             thrown.expectMessage("Archiver: " + mixedCaseArchiverName + " not found.");
                             
                             // Execute test
                             ArchiveStreamFactory factory = new ArchiveStreamFactory();
                             factory.createArchiveInputStream(mixedCaseArchiverName, in);
                             
                             // If we get here, the test fails because exception wasn't thrown
                             fail("Expected ArchiveException for mixed case archiver name");
                         }

 @Test
                    public void testCreateArchiveInputStream_ShouldIgnoreTarVerificationException() throws Exception {
                        // Setup
                        InputStream mockInput = mock(InputStream.class);
                        
                        // Mock initial signature read (not matching any format)
                        byte[] signature = new byte[12];
                        when(mockInput.markSupported()).thenReturn(true);
                        when(mockInput.read(signature)).thenReturn(signature.length);
                        
                        // Mock dump signature read (not matching)
                        byte[] dumpsig = new byte[32];
                        when(mockInput.read(dumpsig)).thenReturn(dumpsig.length);
                        
                        // Mock tar header read (length >= 512 to trigger special case)
                        byte[] tarheader = new byte[512];
                        when(mockInput.read(tarheader)).thenReturn(tarheader.length);
                        
                        // Mock behavior that will cause exception in TAR verification
                        doThrow(new IOException("mark failed")).when(mockInput).mark(anyInt());
                        
                        // Expect ArchiveException since no format matched
                        try {
                            ArchiveStreamFactory factory = new ArchiveStreamFactory();
                            factory.createArchiveInputStream(mockInput);
                            fail("Expected ArchiveException");
                        } catch (ArchiveException e) {
                            assertEquals("No Archiver found for the stream signature", e.getMessage());
                        }
                        
                        // Verify the mock interactions
                        verify(mockInput, atLeastOnce()).mark(anyInt());
                        verify(mockInput, atLeastOnce()).reset();
                    }

 @Test
               public void testCreateArchiveInputStreamShouldNotCatchRuntimeException() throws Exception {
                   // Setup
                   String archiverName = ArchiveStreamFactory.ZIP; // Using a valid archiver name
                   InputStream mockInputStream = mock(InputStream.class);
                   
                   // Configure the mock to throw RuntimeException when used
                   when(mockInputStream.read(any(byte[].class))).thenThrow(new RuntimeException("Test exception"));
                   
                   // Initialize ExpectedException rule
                   ExpectedException expectedException = ExpectedException.none();
                   // Expect the RuntimeException to propagate
                   expectedException.expect(RuntimeException.class);
                   expectedException.expectMessage("Test exception");
                   
                   // Execute
                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                   factory.createArchiveInputStream(archiverName, mockInputStream);
                   
                   // Verification
                   verify(mockInputStream).read(any(byte[].class));
               }

 @Test
               public void testCreateArchiveInputStream_ShouldNotCatchRuntimeException() throws Exception {
                   // Arrange
                   InputStream mockInputStream = mock(InputStream.class);
                   when(mockInputStream.markSupported()).thenReturn(true);
                   // Simulate RuntimeException during read operation
                   when(mockInputStream.read(any(byte[].class))).thenThrow(new RuntimeException("Test exception"));
                   
                   ArchiveStreamFactory factory = new ArchiveStreamFactory();
                   
                   // Setup expected exception rule
                   ExpectedException expectedException = ExpectedException.none();
                   expectedException.expect(RuntimeException.class);
                   expectedException.expectMessage("Test exception");
                   
                   // Act
                   factory.createArchiveInputStream(mockInputStream);
                   
                   // Assert - handled by expectedException rule
               }

 @Test(expected = ArchiveException.class)
           public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowWithCorrectMessage1() throws Exception {
               // Arrange
               InputStream mockInputStream = mock(InputStream.class);
               when(mockInputStream.markSupported()).thenReturn(true);
               doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
               
               ArchiveStreamFactory factory = new ArchiveStreamFactory();
               
               // Act
               try {
                   factory.createArchiveInputStream(mockInputStream);
               } catch (ArchiveException e) {
                   // Assert
                   assertEquals("Could not use reset and mark operations.", e.getMessage());
                   throw e;
               }
           }

 @Test
          public void testCreateArchiveInputStreamWithUnknownArchiverThrowsCorrectExceptionMessage1() throws Exception {
              // Arrange
              ArchiveStreamFactory factory = new ArchiveStreamFactory();
              String unknownArchiver = "UNKNOWN";
              InputStream inputStream = new ByteArrayInputStream(new byte[0]);
              
              // Set expectation for exception type and message
              ExpectedException expectedException = ExpectedException.none();
              expectedException.expect(ArchiveException.class);
              expectedException.expectMessage("Archiver: " + unknownArchiver + " not found.");
              
              // Act
              factory.createArchiveInputStream(unknownArchiver, inputStream);
          }

 @Test
          public void testCreateArchiveInputStreamWithUnknownFormatThrowsArchiveException() throws Exception {
              // Arrange
              ArchiveStreamFactory factory = new ArchiveStreamFactory();
              InputStream inputStream = mock(InputStream.class);
              String unknownArchiver = "UNKNOWN_FORMAT";
              
              // Expect ArchiveException, not RuntimeException
              thrown.expect(ArchiveException.class);
              thrown.expectMessage("Archiver: " + unknownArchiver + " not found.");
              
              // Act
              factory.createArchiveInputStream(unknownArchiver, inputStream);
          }

 @Test
          public void testCreateArchiveInputStreamWithNullArchiverNameThrowsIllegalArgumentException() throws Exception {
              // Arrange
              ArchiveStreamFactory factory = new ArchiveStreamFactory();
              InputStream inputStream = mock(InputStream.class);
              
              thrown.expect(IllegalArgumentException.class);
              thrown.expectMessage("Archivername must not be null.");
              
              // Act
              factory.createArchiveInputStream(null, inputStream);
          }

 @Test
          public void testCreateArchiveInputStreamWithNullInputStreamThrowsIllegalArgumentException() throws Exception {
              // Arrange
              ArchiveStreamFactory factory = new ArchiveStreamFactory();
              
              thrown.expect(IllegalArgumentException.class);
              thrown.expectMessage("InputStream must not be null.");
              
              // Act
              factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, null);
          }

 @Test
     public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowArchiveException2() throws Exception {
         // Arrange
         InputStream mockInputStream = mock(InputStream.class);
         when(mockInputStream.markSupported()).thenReturn(true);
         doThrow(new IOException("mark failed")).when(mockInputStream).mark(anyInt());
         
         ArchiveStreamFactory factory = new ArchiveStreamFactory();
         
         // Expect ArchiveException to be thrown
         ExpectedException expectedException = ExpectedException.none();
         expectedException.expect(ArchiveException.class);
         expectedException.expectMessage("Could not use reset and mark operations.");
         
         // Act
         factory.createArchiveInputStream(mockInputStream);
     }

 @Test
     public void testCreateArchiveInputStream_ShouldThrowArchiveExceptionWithFixedMessageWhenMarkResetFails() throws Exception {
         // Arrange
         ArchiveStreamFactory factory = new ArchiveStreamFactory();
         InputStream inputStream = mock(InputStream.class);
         when(inputStream.markSupported()).thenReturn(true);
         doThrow(new IOException("Mark/reset failed")).when(inputStream).mark(anyInt());
         
         // Expect the specific exception with the original fixed message
         thrown.expect(ArchiveException.class);
         thrown.expectMessage("Could not use reset and mark operations.");
         
         // Act
         factory.createArchiveInputStream(ArchiveStreamFactory.ZIP, inputStream);
         
         // Assert - handled by ExpectedException rule
     }

 @Test(expected = ArchiveException.class)
 public void testCreateArchiveInputStream_IOExceptionDuringMark_ShouldThrowWithFixedMessage2() throws Exception {
     // Arrange
     InputStream mockInputStream = mock(InputStream.class);
     when(mockInputStream.markSupported()).thenReturn(true);
     doThrow(new IOException("Simulated IO error")).when(mockInputStream).mark(anyInt());
     
     ArchiveStreamFactory factory = new ArchiveStreamFactory();
     
     try {
         // Act
         factory.createArchiveInputStream(mockInputStream);
     } catch (ArchiveException e) {
         // Assert
         assertEquals("Could not use reset and mark operations.", e.getMessage());
         throw e;
     }
 }

}
