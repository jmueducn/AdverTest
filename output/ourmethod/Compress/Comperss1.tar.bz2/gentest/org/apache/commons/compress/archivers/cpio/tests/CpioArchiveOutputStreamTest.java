package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
 
public class CpioArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                      public void testCloseWhenAlreadyClosedShouldNotCallFinishOrSuperClose() throws Exception {
                                                                                                                                                          // Arrange
                                                                                                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                                          
                                                                                                                                                          // Set up the stream to be already closed
                                                                                                                                                          stream.close();  // First close to set closed=true
                                                                                                                                                          
                                                                                                                                                          // Spy on the stream to verify method calls
                                                                                                                                                          CpioArchiveOutputStream spyStream = spy(stream);
                                                                                                                                                          doNothing().when(spyStream).finish();
                                                                                                                                                          // Mock the parent close behavior without casting
                                                                                                                                                          doCallRealMethod().when(spyStream).close();
                                                                                                                                                          
                                                                                                                                                          // Act
                                                                                                                                                          spyStream.close();  // Second close attempt
                                                                                                                                                          
                                                                                                                                                          // Assert
                                                                                                                                                          // Verify finish() was not called because stream was already closed
                                                                                                                                                          verify(spyStream, never()).finish();
                                                                                                                                                          // Verify the output stream wasn't closed again
                                                                                                                                                          verify(mockOut, never()).close();
                                                                                                                                                          
                                                                                                                                                          // Additional verification that closed remains true using reflection
                                                                                                                                                          Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                                          closedField.setAccessible(true);
                                                                                                                                                          assertTrue((boolean) closedField.get(spyStream));
                                                                                                                                                      }

    @Test
                                                                                                                                                      public void testCloseWhenNotClosedShouldExecuteCloseOperations() throws Exception {
                                                                                                                                                          // Arrange
                                                                                                                                                          OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                                          
                                                                                                                                                          // Use reflection to set closed=false since it's private
                                                                                                                                                          // (In real code, you might have a test helper method for this)
                                                                                                                                                          java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                                          closedField.setAccessible(true);
                                                                                                                                                          closedField.set(stream, false);
                                                                                                                                                          
                                                                                                                                                          // Mock the finish method to verify it's called
                                                                                                                                                          CpioArchiveOutputStream spyStream = spy(stream);
                                                                                                                                                          doNothing().when(spyStream).finish();
                                                                                                                                                          
                                                                                                                                                          // Act
                                                                                                                                                          spyStream.close();
                                                                                                                                                          
                                                                                                                                                          // Assert
                                                                                                                                                          // Verify finish() was called
                                                                                                                                                          verify(spyStream).finish();
                                                                                                                                                          // Verify parent close was called (through the mock OutputStream)
                                                                                                                                                          verify(mockOut).close();
                                                                                                                                                          // Verify closed flag is now true
                                                                                                                                                          assertTrue((boolean) closedField.get(spyStream));
                                                                                                                                                      }

    @Test
                                                                                                                                                  public void testCloseCallsFinish() throws Exception {
                                                                                                                                                      // Setup
                                                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to set closed=false since it's private
                                                                                                                                                      // This is necessary to ensure the if block executes
                                                                                                                                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                                      closedField.setAccessible(true);
                                                                                                                                                      closedField.set(stream, false);
                                                                                                                                                      
                                                                                                                                                      // Create a spy to verify finish() is called
                                                                                                                                                      CpioArchiveOutputStream spyStream = spy(stream);
                                                                                                                                                      
                                                                                                                                                      // Execute
                                                                                                                                                      spyStream.close();
                                                                                                                                                      
                                                                                                                                                      // Verify finish() was called exactly once
                                                                                                                                                      verify(spyStream, times(1)).finish();
                                                                                                                                                      
                                                                                                                                                      // Also verify closed flag is set to true
                                                                                                                                                      assertTrue((boolean) closedField.get(spyStream));
                                                                                                                                                  }

    @Test
                                                                                                                          public void testCloseCallsFinishExactlyOnce() throws Exception {
                                                                                                                              // Create a real output stream (we'll use a mock)
                                                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                                                              
                                                                                                                              // Create a spy of the CpioArchiveOutputStream to verify finish() calls
                                                                                                                              CpioArchiveOutputStream stream = spy(new CpioArchiveOutputStream(mockOut));
                                                                                                                              
                                                                                                                              // Use reflection to make ensureOpen() accessible
                                                                                                                              Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                              ensureOpenMethod.setAccessible(true);
                                                                                                                              
                                                                                                                              // Mock the finish method to verify it's called
                                                                                                                              doNothing().when(stream).finish();
                                                                                                                              
                                                                                                                              // Call the close method
                                                                                                                              stream.close();
                                                                                                                              
                                                                                                                              // Verify finish() was called exactly once
                                                                                                                              verify(stream, times(1)).finish();
                                                                                                                              
                                                                                                                              // Verify parent close was called
                                                                                                                              verify(mockOut).close();
                                                                                                                          }

    @Test
                                                                                                                  public void testCloseShouldCallSuperClose() throws Exception {
                                                                                                                      // Arrange
                                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                      
                                                                                                                      // Spy on the FilterOutputStream (parent class) which wraps mockOut
                                                                                                                      FilterOutputStream spyParent = spy(new FilterOutputStream(mockOut));
                                                                                                                      
                                                                                                                      // Use reflection to access and modify private 'out' field
                                                                                                                      Field outField = FilterOutputStream.class.getDeclaredField("out");
                                                                                                                      outField.setAccessible(true);
                                                                                                                      outField.set(stream, spyParent);
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      stream.close();
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      // Verify parent's close() was called exactly once
                                                                                                                      verify(spyParent).close();
                                                                                                                      
                                                                                                                      // Use reflection to access private 'closed' field
                                                                                                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                      closedField.setAccessible(true);
                                                                                                                      boolean closed = (boolean) closedField.get(stream);
                                                                                                                      assertTrue(closed);
                                                                                                                  }

    @Test
                                                                                                          public void testCloseShouldCallSuperCloseExactlyOnce() throws Exception {
                                                                                                              // Arrange
                                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                                              FilterOutputStream spyFilterOut = spy(new FilterOutputStream(mockOut));
                                                                                                              CpioArchiveOutputStream stream = new CpioArchiveOutputStream(spyFilterOut);
                                                                                                              
                                                                                                              // Ensure the stream is in a state where it can be closed
                                                                                                              stream.finish(); // Assuming finish() prepares for closing
                                                                                                              
                                                                                                              // Use reflection to access and modify the private closed field
                                                                                                              Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                              closedField.setAccessible(true);
                                                                                                              closedField.setBoolean(stream, false); // Make sure it's not already closed
                                                                                                              
                                                                                                              // Act
                                                                                                              stream.close();
                                                                                                              
                                                                                                              // Assert
                                                                                                              // Verify super.close() was called exactly once
                                                                                                              verify(spyFilterOut, times(1)).close();
                                                                                                              
                                                                                                              // Additional state assertions using reflection
                                                                                                              assertTrue(closedField.getBoolean(stream)); // Should be marked as closed
                                                                                                          }

    @Test
                                                                                                          public void testCloseOnlyExecutesOnceWhenCalledMultipleTimes() throws Exception {
                                                                                                              // Setup
                                                                                                              OutputStream mockOut = mock(OutputStream.class);
                                                                                                              CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                              
                                                                                                              // First close
                                                                                                              stream.close();
                                                                                                              
                                                                                                              // Reset mock to track subsequent calls
                                                                                                              reset(mockOut);
                                                                                                              
                                                                                                              // Second close
                                                                                                              stream.close();
                                                                                                              
                                                                                                              // Verify parent close() wasn't called again
                                                                                                              verify(mockOut, never()).close();
                                                                                                          }

    @Test
                                                                                                  public void testCloseSetsClosedFlagToTrue() throws Exception {
                                                                                                      // Setup
                                                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                      
                                                                                                      // Get the closed field via reflection
                                                                                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                      closedField.setAccessible(true);
                                                                                                      
                                                                                                      // Verify initial state
                                                                                                      assertFalse((boolean) closedField.get(stream)); // Should start as not closed
                                                                                                      
                                                                                                      // Execute
                                                                                                      stream.close();
                                                                                                      
                                                                                                      // Verify - this is what catches the mutant
                                                                                                      assertTrue("Stream should be marked as closed after close()", 
                                                                                                                (boolean) closedField.get(stream));
                                                                                                      
                                                                                                      // Additional verification that operations were performed
                                                                                                      verify(mockOut).close();
                                                                                                  }

    @Test
                                                                                          public void testCloseSetsClosedFlag() throws Exception {
                                                                                              // Arrange
                                                                                              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                              CpioArchiveOutputStream out = new CpioArchiveOutputStream(byteOut);
                                                                                              
                                                                                              // Use reflection to access the closed field
                                                                                              Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                              closedField.setAccessible(true);
                                                                                              
                                                                                              // Pre-condition check
                                                                                              assertFalse("Stream should initially be open", closedField.getBoolean(out));
                                                                                              
                                                                                              // Act
                                                                                              out.close();
                                                                                              
                                                                                              // Assert
                                                                                              assertTrue("Stream should be marked as closed after close()", closedField.getBoolean(out));
                                                                                          }

    @Test
                                                                                  public void testCloseSetsClosedFlagAndIdempotent() throws Exception {
                                                                                      // Setup
                                                                                      ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                                                                      CpioArchiveOutputStream caos = new CpioArchiveOutputStream(baos);
                                                                                      
                                                                                      // Use reflection to access the private 'closed' field
                                                                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                      closedField.setAccessible(true);
                                                                                      
                                                                                      // Verify initial state (should be open)
                                                                                      assertFalse(closedField.getBoolean(caos));
                                                                                      
                                                                                      // First close
                                                                                      caos.close();
                                                                                      assertTrue("After first close(), closed should be true", closedField.getBoolean(caos));
                                                                                      
                                                                                      // Second close - should remain true (idempotent)
                                                                                      caos.close();
                                                                                      assertTrue("After second close(), closed should remain true", closedField.getBoolean(caos));
                                                                                  }

    @Test
                                                                          public void testClosePropagatesFinishException() throws Exception {
                                                                              // Create a partial mock of the class
                                                                              CpioArchiveOutputStream mockStream = mock(CpioArchiveOutputStream.class);
                                                                              
                                                                              // Configure the mock behavior
                                                                              doCallRealMethod().when(mockStream).close();
                                                                              doThrow(new IOException("Simulated finish error")).when(mockStream).finish();
                                                                              
                                                                              // Set up expectation for original behavior
                                                                              thrown.expect(IOException.class);
                                                                              thrown.expectMessage("Simulated finish error");
                                                                              
                                                                              // Use reflection to set closed to false so the close logic executes
                                                                              Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                              closedField.setAccessible(true);
                                                                              closedField.set(mockStream, false);
                                                                              
                                                                              // Execute the test
                                                                              mockStream.close();
                                                                              
                                                                              // Verify finish was called (would fail if exception was swallowed)
                                                                              verify(mockStream).finish();
                                                                          }

    @Test
                                                                  public void testClosePropagatesExceptionFromSuperClose() throws Exception {
                                                                      // Arrange
                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                      
                                                                      // Make super.close() throw an exception
                                                                      FilterOutputStream mockFilterOut = mock(FilterOutputStream.class);
                                                                      doThrow(new IOException("Close failed")).when(mockFilterOut).close();
                                                                      
                                                                      // Use reflection to inject our mock FilterOutputStream
                                                                      Field outField = CpioArchiveOutputStream.class.getDeclaredField("out");
                                                                      outField.setAccessible(true);
                                                                      outField.set(stream, mockFilterOut);
                                                                  
                                                                      // Act
                                                                      try {
                                                                          stream.close();
                                                                          fail("Expected IOException to be thrown");
                                                                      } catch (IOException e) {
                                                                          // Assert
                                                                          assertEquals("Close failed", e.getMessage());
                                                                      }
                                                                  }

    @Test
                                                                  public void testCloseSetsClosedFlagEvenWhenSuperCloseFails() throws Exception {
                                                                      // Arrange
                                                                      OutputStream mockOut = mock(OutputStream.class);
                                                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                      FilterOutputStream mockFilterOut = mock(FilterOutputStream.class);
                                                                      doThrow(new IOException("Close failed")).when(mockFilterOut).close();
                                                                      
                                                                      Field outField = CpioArchiveOutputStream.class.getDeclaredField("out");
                                                                      outField.setAccessible(true);
                                                                      outField.set(stream, mockFilterOut);
                                                                  
                                                                      try {
                                                                          // Act
                                                                          stream.close();
                                                                      } catch (IOException e) {
                                                                          // Expected for original code
                                                                      }
                                                                  
                                                                      // Assert
                                                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                      closedField.setAccessible(true);
                                                                      boolean closed = (boolean) closedField.get(stream);
                                                                      assertTrue("closed flag should be set even if super.close() fails", closed);
                                                                  }

    @Test
                                                             public void testCloseCallsFinish1() throws Exception {
                                                                 // Arrange
                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                 
                                                                 // Use reflection to set private fields
                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                 closedField.setAccessible(true);
                                                                 closedField.setBoolean(stream, false);
                                                                 
                                                                 Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
                                                                 finishedField.setAccessible(true);
                                                                 finishedField.setBoolean(stream, false);
                                                                 
                                                                 // Act
                                                                 stream.close();
                                                                 
                                                                 // Assert
                                                                 // Verify finish() was called by checking finished flag is true
                                                                 assertTrue("Stream should be marked as finished after close", finishedField.getBoolean(stream));
                                                                 // Verify parent close was called
                                                                 verify(mockOut).close();
                                                                 // Verify closed flag is set
                                                                 assertTrue("Stream should be marked as closed", closedField.getBoolean(stream));
                                                             }

    @Test
                                                        public void testCloseShouldCallFinishExactlyOnce() throws Exception {
                                                            // Create a partial mock of CpioArchiveOutputStream to spy on finish()
                                                            CpioArchiveOutputStream stream = new CpioArchiveOutputStream(new ByteArrayOutputStream());
                                                            CpioArchiveOutputStream spyStream = spy(stream);
                                                            
                                                            // Use reflection to access and modify the private closed field
                                                            Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                            closedField.setAccessible(true);
                                                            
                                                            // Set initial state
                                                            closedField.setBoolean(spyStream, false);
                                                            
                                                            // Call the method under test
                                                            spyStream.close();
                                                            
                                                            // Verify finish() was called exactly once
                                                            verify(spyStream, times(1)).finish();
                                                            
                                                            // Additional assertions to ensure full behavior
                                                            assertTrue(closedField.getBoolean(spyStream));
                                                        }

    @Test
                                                   public void testCloseShouldCallSuperClose1() throws Exception {
                                                       // Arrange
                                                       OutputStream mockOut = mock(OutputStream.class);
                                                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                       
                                                       // Use reflection to access and modify the private 'closed' field
                                                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                       closedField.setAccessible(true);
                                                       closedField.setBoolean(stream, false); // Ensure stream is not closed initially
                                                       
                                                       // Act
                                                       stream.close();
                                                       
                                                       // Assert
                                                       // Verify parent stream's close was called (through FilterOutputStream)
                                                       verify(mockOut).close();
                                                       assertTrue((boolean) closedField.get(stream)); // Verify closed flag was set
                                                   }

    @Test
                                                   public void testCloseWhenAlreadyClosed() throws Exception {
                                                       // Arrange
                                                       OutputStream mockOut = mock(OutputStream.class);
                                                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                       
                                                       // Use reflection to set the private closed field to true
                                                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                       closedField.setAccessible(true);
                                                       closedField.setBoolean(stream, true);
                                                       
                                                       // Act
                                                       stream.close();
                                                       
                                                       // Assert
                                                       // Verify parent stream's close was NOT called
                                                       verify(mockOut, never()).close();
                                                   }

    @Test
                                              public void testCloseShouldCallSuperCloseExactlyOnce1() throws Exception {
                                                  // Arrange
                                                  OutputStream mockOut = mock(OutputStream.class);
                                                  FilterOutputStream spyFilterOut = spy(new FilterOutputStream(mockOut));
                                                  
                                                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(spyFilterOut) {
                                                      @Override
                                                      public void finish() {
                                                          // Do nothing for test
                                                      }
                                                  };
                                                  
                                                  // Use reflection to access and modify the private closed field
                                                  Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                  closedField.setAccessible(true);
                                                  closedField.setBoolean(stream, false);  // Ensure stream is not closed initially
                                                  
                                                  // Act
                                                  stream.close();
                                                  
                                                  // Assert
                                                  verify(spyFilterOut, times(1)).close();  // Should fail if mutant exists
                                                  assertTrue(closedField.getBoolean(stream));
                                              }

    @Test
                                         public void testCloseSetsClosedFlagAndIsIdempotent() throws Exception {
                                             // Setup
                                             OutputStream mockOut = mock(OutputStream.class);
                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                             
                                             // Get the closed field via reflection
                                             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                             closedField.setAccessible(true);
                                             
                                             // First close - should set closed to true (both original and mutant)
                                             stream.close();
                                             assertTrue("Stream should be closed after first close()", (boolean) closedField.get(stream));
                                             
                                             // Second close - original keeps closed=true, mutant toggles to false
                                             stream.close();
                                             assertTrue("Stream should remain closed after second close()", (boolean) closedField.get(stream));
                                             
                                             // Verify finish() and super.close() were called exactly once (not called again on second close)
                                             verify(stream, times(1)).finish();
                                             verify(mockOut, times(1)).close();
                                         }

    @Test
                                         public void testClosePropagatesFinishException1() throws Exception {
                                             // Setup
                                             OutputStream mockOut = mock(OutputStream.class);
                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                             
                                             // Make finish() throw an exception
                                             doThrow(new IOException("Test exception")).when(stream).finish();
                                             
                                             // Expect the exception to be thrown
                                             thrown.expect(IOException.class);
                                             thrown.expectMessage("Test exception");
                                             
                                             // Execute
                                             stream.close();
                                             
                                             // Verify that super.close() was not called since finish() failed
                                             verify(mockOut, never()).close();
                                             
                                             // Verify closed flag is still false (though this might not be accessible)
                                             // Note: If closed is private, we might need reflection to verify this
                                         }

    @Test(expected = IOException.class)
                                   public void testClosePropagatesExceptionFromSuperClose1() throws Exception {
                                       // Arrange
                                       OutputStream mockOut = mock(OutputStream.class);
                                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                       
                                       doThrow(new IOException("Test exception")).when(mockOut).close();
                                       
                                       // Act
                                       stream.close();
                                       
                                       // Assert - expecting exception to be thrown
                                       // Also verify closed flag is still false since close failed
                                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                       closedField.setAccessible(true);
                                       boolean closed = closedField.getBoolean(stream);
                                       assertFalse(closed);
                                   }

    @Test
                                   public void testCloseSetsClosedFlagWhenSuccessful() throws Exception {
                                       // Arrange
                                       OutputStream mockOut = mock(OutputStream.class);
                                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                       doNothing().when(mockOut).close();
                                       
                                       // Act
                                       stream.close();
                                       
                                       // Assert - need to use reflection to check the private closed field
                                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                       closedField.setAccessible(true);
                                       boolean closed = (boolean) closedField.get(stream);
                                       assertTrue(closed);
                                   }

    @Test
                              public void testCloseCallsFinishBeforeClosing() throws Exception {
                                  // Create a real output stream (we'll use a mock)
                                  OutputStream mockOut = mock(OutputStream.class);
                                  
                                  // Create the test subject with a mock output stream
                                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                  
                                  // Spy on the stream to verify finish() is called
                                  CpioArchiveOutputStream spyStream = spy(stream);
                                  
                                  // Get the closed field using reflection
                                  Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                  closedField.setAccessible(true);
                                  
                                  // Ensure the stream isn't already closed
                                  closedField.setBoolean(spyStream, false);
                                  
                                  // Call the close method
                                  spyStream.close();
                                  
                                  // Verify finish() was called exactly once before close
                                  verify(spyStream, times(1)).finish();
                                  
                                  // Verify the stream is now marked as closed
                                  assertTrue(closedField.getBoolean(spyStream));
                                  
                                  // Verify parent close was called
                                  verify(mockOut).close();
                              }

    @Test
                         public void testCloseShouldCallFinishExactlyOnce1() throws Exception {
                             // Create a partial mock of CpioArchiveOutputStream
                             OutputStream mockOut = mock(OutputStream.class);
                             CpioArchiveOutputStream stream = spy(new CpioArchiveOutputStream(mockOut));
                             
                             // Use reflection to access and modify the private closed field
                             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                             closedField.setAccessible(true);
                             closedField.setBoolean(stream, false);
                             
                             // Mock the finish method to track calls
                             doNothing().when(stream).finish();
                             
                             // Call the method under test
                             stream.close();
                             
                             // Verify finish was called exactly once
                             verify(stream, times(1)).finish();
                             
                             // Verify parent close was called
                             verify(mockOut).close();
                             
                             // Verify closed flag was set using reflection
                             assertTrue(closedField.getBoolean(stream));
                         }

    @Test
                    public void testCloseShouldCallSuperCloseWhenNotAlreadyClosed() throws IOException, NoSuchFieldException, IllegalAccessException {
                        // Arrange
                        OutputStream mockOut = mock(OutputStream.class);
                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                        
                        // Use reflection to set the private closed field to false
                        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                        closedField.setAccessible(true);
                        closedField.setBoolean(stream, false); // Ensure stream is not closed initially
                        
                        // Spy on the stream to verify super.close() is called
                        CpioArchiveOutputStream spyStream = spy(stream);
                        doNothing().when(spyStream).finish(); // Mock finish() to do nothing
                        
                        // Act
                        spyStream.close();
                        
                        // Assert
                        verify(spyStream).finish();
                        verify(mockOut).close(); // Verify parent stream was closed
                        
                        // Use reflection to verify closed flag was set
                        assertTrue(closedField.getBoolean(spyStream));
                    }

    @Test
                    public void testCloseShouldNotCallSuperCloseWhenAlreadyClosed() throws IOException, NoSuchFieldException, IllegalAccessException {
                        // Arrange
                        OutputStream mockOut = mock(OutputStream.class);
                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                        
                        // Set closed field to true using reflection
                        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                        closedField.setAccessible(true);
                        closedField.set(stream, true);
                        
                        // Spy on the stream
                        CpioArchiveOutputStream spyStream = spy(stream);
                        
                        // Act
                        spyStream.close();
                        
                        // Assert
                        verify(spyStream, never()).finish();
                        verify(mockOut, never()).close(); // Parent stream should not be closed
                        
                        // Verify closed flag remains true using reflection
                        boolean isClosed = (boolean) closedField.get(spyStream);
                        assertTrue(isClosed);
                    }

    @Test
               public void testCloseShouldCallSuperCloseExactlyOnce2() throws Exception {
                   // Arrange
                   OutputStream mockOut = mock(OutputStream.class);
                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                   
                   // Use reflection to access and modify the private closed field
                   Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                   closedField.setAccessible(true);
                   closedField.setBoolean(stream, false); // Ensure we can test the close path
                   
                   // Act
                   stream.close();
                   
                   // Assert
                   verify(mockOut, times(1)).close(); // Verify parent close called exactly once
                   
                   // Additional state assertions using reflection
                   assertTrue(closedField.getBoolean(stream)); // Verify closed flag is set
               }

    @Test
           public void testCloseSetsClosedFlagAndIsIdempotent1() throws Exception {
               // Setup - create a stream in open state
               OutputStream mockOut = mock(OutputStream.class);
               CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
               
               // Use reflection to set closed=false since it's private
               Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
               closedField.setAccessible(true);
               closedField.set(stream, false);
               
               // First close - should set closed to true
               stream.close();
               assertTrue("Stream should be closed after first close()", 
                   (boolean) closedField.get(stream));
               
               // Second close - should keep closed as true
               stream.close();
               assertTrue("Stream should remain closed after second close()", 
                   (boolean) closedField.get(stream));
               
               // Verify finish() and super.close() were called exactly once
               // (Note: This requires mocking finish() or verifying output stream calls)
           }

    @Test
              public void testCloseShouldNotCallSuperCloseWhenFinishThrowsException() throws Exception {
                  // Arrange
                  OutputStream mockOut = mock(OutputStream.class);
                  CpioArchiveOutputStream spyStream = spy(new CpioArchiveOutputStream(mockOut));
                  
                  // Make finish() throw an exception
                  doThrow(new IOException("Test exception")).when(spyStream).finish();
                  
                  // Act
                  try {
                      spyStream.close();
                  } catch (IOException e) {
                      // Expected in original version
                  }
                  
                  // Assert
                  // Verify super.close() was NOT called (original behavior)
                  verify(spyStream, never()).close(); // This verifies super.close() wasn't called
              }

    @Test
         public void testCloseShouldCallSuperCloseWhenFinishThrowsExceptionInMutatedVersion() throws Exception {
             // Arrange - simulate the mutated version
             OutputStream mockOut = mock(OutputStream.class);
             CpioArchiveOutputStream spyStream = spy(new CpioArchiveOutputStream(mockOut) {
                 @Override
                 public void close() {
                     try {
                         Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                         closedField.setAccessible(true);
                         boolean isClosed = closedField.getBoolean(this);
                         
                         if (!isClosed) {
                             try { 
                                 this.finish(); 
                             } catch (Exception e) {} // Mutated version
                             super.close();
                             closedField.setBoolean(this, true);
                         }
                     } catch (Exception e) {
                         throw new RuntimeException(e);
                     }
                 }
             });
             
             // Make finish() throw an exception
             doThrow(new IOException("Test exception")).when(spyStream).finish();
             
             // Act
             spyStream.close();
             
             // Assert
             // Verify super.close() WAS called (mutated behavior)
             verify(spyStream, times(1)).close(); // This verifies super.close() was called
         }

    @Test
    public void testClosePropagatesExceptionFromSuperClose2() throws Exception {
        // Create a mock OutputStream that throws IOException when closed
        OutputStream mockOut = mock(OutputStream.class);
        doThrow(new IOException("Test exception")).when(mockOut).close();
        
        // Create the test object with our mock stream
        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
        
        // Use reflection to access and modify the private 'closed' field
        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
        closedField.setAccessible(true);
        closedField.setBoolean(stream, false); // Ensure it's not already closed
        
        // Set up expected exception
        try {
            stream.close();
            fail("Expected IOException to be thrown");
        } catch (IOException e) {
            assertEquals("Test exception", e.getMessage());
            
            // Verify the stream was marked as closed despite the exception
            assertTrue(closedField.getBoolean(stream));
        }
    }


}
