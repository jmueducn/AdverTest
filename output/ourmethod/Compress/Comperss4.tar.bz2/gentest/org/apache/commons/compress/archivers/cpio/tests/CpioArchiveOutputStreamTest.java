package gentest.org.apache.commons.compress.archivers.cpio.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.cpio.*;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
 
public class CpioArchiveOutputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                             public void testEnsureOpen_WhenStreamIsClosed_ShouldThrowIOException() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                                 
                                                                                                                                 // Set closed field to true using reflection
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 closedField.set(stream, true);
                                                                                                                                 
                                                                                                                                 // Get ensureOpen method using reflection
                                                                                                                                 Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                                 ensureOpenMethod.setAccessible(true);
                                                                                                                                 
                                                                                                                                 // Expect exception
                                                                                                                                 try {
                                                                                                                                     ensureOpenMethod.invoke(stream);
                                                                                                                                     fail("Expected IOException");
                                                                                                                                 } catch (InvocationTargetException e) {
                                                                                                                                     Throwable cause = e.getCause();
                                                                                                                                     assertEquals(IOException.class, cause.getClass());
                                                                                                                                     assertEquals("Stream closed", cause.getMessage());
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                                             public void testEnsureOpen_WhenNewlyCreated_ShouldNotThrowException() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                                 
                                                                                                                                 // Get the private ensureOpen method
                                                                                                                                 Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                                 ensureOpenMethod.setAccessible(true);
                                                                                                                                 
                                                                                                                                 // Act & Assert - should not throw exception
                                                                                                                                 ensureOpenMethod.invoke(stream);
                                                                                                                             }

    @Test
                                                                                                                             public void testClose_WhenNotClosed_ShouldCloseUnderlyingStream() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 
                                                                                                                                 // Use reflection to access private closed field
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 boolean initialClosedState = (boolean) closedField.get(stream);
                                                                                                                                 assertFalse(initialClosedState); // Verify initial state
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 stream.close();
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 verify(mockOut).close();
                                                                                                                                 boolean finalClosedState = (boolean) closedField.get(stream);
                                                                                                                                 assertTrue(finalClosedState);
                                                                                                                             }

    @Test
                                                                                                                             public void testClose_WhenAlreadyClosed_ShouldNotCloseAgain() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 stream.close(); // First close
                                                                                                                                 reset(mockOut); // Clear previous interactions
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 stream.close(); // Second close attempt
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 verify(mockOut, never()).close(); // Should not try to close again
                                                                                                                                 
                                                                                                                                 // Check closed status using reflection
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 boolean isClosed = closedField.getBoolean(stream);
                                                                                                                                 assertTrue(isClosed); // Should remain closed
                                                                                                                             }

    @Test
                                                                                                                             public void testClose_WhenUnderlyingStreamThrowsException_ShouldStillMarkAsClosed() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 doThrow(new IOException("Test exception")).when(mockOut).close();
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 try {
                                                                                                                                     stream.close();
                                                                                                                                     fail("Expected IOException");
                                                                                                                                 } catch (IOException e) {
                                                                                                                                     // Expected
                                                                                                                                 }
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 boolean closed = closedField.getBoolean(stream);
                                                                                                                                 assertTrue(closed); // Should still be marked as closed
                                                                                                                             }

    @Test
                                                                                                                             public void testClose_AfterFinish_ShouldCloseProperly() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 OutputStream mockOut = mock(OutputStream.class);
                                                                                                                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                                                 stream.finish(); // Mark as finished
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 stream.close();
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 verify(mockOut).close();
                                                                                                                                 
                                                                                                                                 // Use reflection to access private fields
                                                                                                                                 Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                                 closedField.setAccessible(true);
                                                                                                                                 boolean closed = (boolean) closedField.get(stream);
                                                                                                                                 assertTrue(closed);
                                                                                                                                 
                                                                                                                                 Field finishedField = CpioArchiveOutputStream.class.getDeclaredField("finished");
                                                                                                                                 finishedField.setAccessible(true);
                                                                                                                                 boolean finished = (boolean) finishedField.get(stream);
                                                                                                                                 assertTrue(finished);
                                                                                                                             }

    @Test
                                                                                                                         public void testEnsureOpen_WhenStreamIsOpen_ShouldNotThrowException() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                             
                                                                                                                             // Use reflection to set closed field to false
                                                                                                                             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                                             closedField.setAccessible(true);
                                                                                                                             closedField.setBoolean(stream, false);
                                                                                                                             
                                                                                                                             // Use reflection to access ensureOpen method
                                                                                                                             Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                             ensureOpenMethod.setAccessible(true);
                                                                                                                             
                                                                                                                             // Act & Assert - should not throw exception
                                                                                                                             ensureOpenMethod.invoke(stream);
                                                                                                                         }

    @Test
                                                                                                                         public void testEnsureOpen_AfterCloseOperation_ShouldThrowIOException() throws Exception {
                                                                                                                             // Arrange
                                                                                                                             OutputStream mockOutputStream = mock(OutputStream.class);
                                                                                                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOutputStream);
                                                                                                                             
                                                                                                                             // Close the stream (simulating actual close operation)
                                                                                                                             stream.close();
                                                                                                                             
                                                                                                                             // Set up exception expectation
                                                                                                                             ExpectedException expectedException = ExpectedException.none();
                                                                                                                             expectedException.expect(IOException.class);
                                                                                                                             expectedException.expectMessage("Stream closed");
                                                                                                                             
                                                                                                                             // Get private ensureOpen method via reflection
                                                                                                                             Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                             ensureOpenMethod.setAccessible(true);
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             ensureOpenMethod.invoke(stream);
                                                                                                                         }

    @Test
                                                                                                                    public void testEnsureOpenThrowsWhenClosed() throws Exception {
                                                                                                                        // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                                                                                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                                                                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                                        
                                                                                                                        // Set stream to closed state
                                                                                                                        stream.close();
                                                                                                                        
                                                                                                                        // Use reflection to access private method since we can't call it directly
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Method method = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                            method.setAccessible(true);
                                                                                                                            method.invoke(stream);
                                                                                                                            fail("Expected IOException to be thrown");
                                                                                                                        } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                            assertTrue(e.getCause() instanceof IOException);
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testEnsureOpenDoesNotThrowWhenOpen() throws Exception {
                                                                                                                        // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                                                                                        OutputStream out = new ByteArrayOutputStream();
                                                                                                                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                                        
                                                                                                                        // Use reflection to access private method
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Method method = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                            method.setAccessible(true);
                                                                                                                            method.invoke(stream);
                                                                                                                            
                                                                                                                            // If we get here, no exception was thrown (correct behavior)
                                                                                                                            assertTrue(true);
                                                                                                                        } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                            if (e.getCause() instanceof IOException) {
                                                                                                                                fail("Should not throw IOException when stream is open");
                                                                                                                            }
                                                                                                                        } finally {
                                                                                                                            stream.close();
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                               public void testEnsureOpenDoesNotThrowWhenStreamIsOpen() throws Exception {
                                                                                                                   // Set up - create a new stream which is open by default
                                                                                                                   OutputStream out = new ByteArrayOutputStream();
                                                                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                                   
                                                                                                                   try {
                                                                                                                       // Use reflection to access private method for testing
                                                                                                                       java.lang.reflect.Method method = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                       method.setAccessible(true);
                                                                                                                       method.invoke(stream);
                                                                                                                       
                                                                                                                       // If we get here, no exception was thrown - test passes
                                                                                                                   } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                       if (e.getCause() instanceof IOException) {
                                                                                                                           fail("ensureOpen() threw IOException when stream was open");
                                                                                                                       }
                                                                                                                       throw e;
                                                                                                                   } finally {
                                                                                                                       stream.close();
                                                                                                                   }
                                                                                                               }

    @Test(expected = IOException.class)
                                                                                                               public void testEnsureOpenThrowsWhenStreamIsClosed() throws Exception {
                                                                                                                   // Set up stream and close it
                                                                                                                   OutputStream out = new ByteArrayOutputStream();
                                                                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                                   stream.close();
                                                                                                                   
                                                                                                                   // Use reflection to access private method
                                                                                                                   java.lang.reflect.Method method = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                                   method.setAccessible(true);
                                                                                                                   method.invoke(stream);
                                                                                                               }

    @Test(expected = IOException.class)
                                                                                                      public void testEnsureOpenThrowsWhenClosed1() throws Exception {
                                                                                                          // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                                                                          OutputStream out = new ByteArrayOutputStream();
                                                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                          
                                                                                                          // Close the stream (this would normally set closed=true)
                                                                                                          // Since closed is private, we'll use reflection to set it
                                                                                                          try {
                                                                                                              java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                              closedField.setAccessible(true);
                                                                                                              closedField.set(stream, true);
                                                                                                          } catch (Exception e) {
                                                                                                              throw new RuntimeException("Failed to set closed field", e);
                                                                                                          }
                                                                                                          
                                                                                                          // Use reflection to access the private ensureOpen method
                                                                                                          try {
                                                                                                              java.lang.reflect.Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                              ensureOpenMethod.setAccessible(true);
                                                                                                              ensureOpenMethod.invoke(stream);
                                                                                                          } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                              throw (IOException) e.getCause();
                                                                                                          }
                                                                                                      }

    @Test(expected = IOException.class)
                                                                                                      public void testEnsureOpenThrowsWhenClosed2() throws Exception {
                                                                                                          // Create a new output stream (using a dummy OutputStream)
                                                                                                          OutputStream out = new ByteArrayOutputStream();
                                                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                          
                                                                                                          // Close the stream (which should set closed=true)
                                                                                                          stream.close();
                                                                                                          
                                                                                                          // Get the private ensureOpen method via reflection
                                                                                                          Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                          ensureOpen.setAccessible(true);
                                                                                                          
                                                                                                          // Invoke the method which should throw IOException
                                                                                                          ensureOpen.invoke(stream);
                                                                                                      }

    @Test
                                                                                                 public void testEnsureOpenThrowsWhenClosed3() throws Exception {
                                                                                                     // Setup
                                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                                     CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                     
                                                                                                     // Set closed field to true via reflection
                                                                                                     Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                     closedField.setAccessible(true);
                                                                                                     closedField.set(stream, true);
                                                                                                     
                                                                                                     // Test & Verify
                                                                                                     try {
                                                                                                         // Call a public method that would use ensureOpen()
                                                                                                         stream.closeArchiveEntry();
                                                                                                         fail("Expected IOException not thrown");
                                                                                                     } catch (IOException e) {
                                                                                                         assertEquals("Stream closed", e.getMessage());
                                                                                                     }
                                                                                                 }

    @Test
                                                                                                 public void testEnsureOpenDoesNotThrowWhenOpen1() throws Exception {
                                                                                                     // Setup
                                                                                                     OutputStream mockOut = mock(OutputStream.class);
                                                                                                     CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                                                                                     
                                                                                                     // Set closed field to false via reflection (explicit test)
                                                                                                     Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                     closedField.setAccessible(true);
                                                                                                     closedField.set(stream, false);
                                                                                                     
                                                                                                     // Get the private ensureOpen method via reflection
                                                                                                     Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                     ensureOpenMethod.setAccessible(true);
                                                                                                     
                                                                                                     // Test - should not throw
                                                                                                     ensureOpenMethod.invoke(stream);
                                                                                                     
                                                                                                     // No assertion needed - test passes if no exception is thrown
                                                                                                 }

    @Test
                                                                                            public void testEnsureOpenWhenClosed() throws Exception {
                                                                                                // Create a new stream instance for testing
                                                                                                OutputStream out = new ByteArrayOutputStream();
                                                                                                CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                                
                                                                                                // Use reflection to access private method
                                                                                                Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                ensureOpen.setAccessible(true);
                                                                                                
                                                                                                // Set closed to true
                                                                                                Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                closedField.setAccessible(true);
                                                                                                closedField.setBoolean(stream, true);
                                                                                                
                                                                                                try {
                                                                                                    ensureOpen.invoke(stream);
                                                                                                    fail("Expected IOException to be thrown");
                                                                                                } catch (InvocationTargetException e) {
                                                                                                    assertEquals(IOException.class, e.getCause().getClass());
                                                                                                    assertEquals("Stream closed", e.getCause().getMessage());
                                                                                                }
                                                                                            }

    @Test
                                                                                            public void testEnsureOpenWhenNotClosed() throws Exception {
                                                                                                // Create a new output stream (using ByteArrayOutputStream as dummy)
                                                                                                ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
                                                                                                CpioArchiveOutputStream stream = new CpioArchiveOutputStream(byteOut);
                                                                                                
                                                                                                // Use reflection to access private method
                                                                                                Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                                                                ensureOpen.setAccessible(true);
                                                                                                
                                                                                                // Set closed to false (explicitly)
                                                                                                Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                                                closedField.setAccessible(true);
                                                                                                closedField.setBoolean(stream, false);
                                                                                                
                                                                                                // Should not throw exception
                                                                                                ensureOpen.invoke(stream);
                                                                                            }

    @Test
                                                                                       public void testEnsureOpenThrowsCorrectExceptionMessageWhenClosed() throws Exception {
                                                                                           // Arrange
                                                                                           OutputStream out = new ByteArrayOutputStream();
                                                                                           CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                           stream.close(); // This should set closed=true
                                                                                           
                                                                                           try {
                                                                                               // Act - try an operation that would call ensureOpen()
                                                                                               // Using write() as it likely calls ensureOpen()
                                                                                               stream.write(new byte[0], 0, 0);
                                                                                               fail("Expected IOException to be thrown");
                                                                                           } catch (IOException e) {
                                                                                               // Assert
                                                                                               assertEquals("Exception message should match original", 
                                                                                                           "Stream closed", 
                                                                                                           e.getMessage());
                                                                                           }
                                                                                       }

    @Test(expected = IOException.class)
                                                                                  public void testEnsureOpenThrowsIOExceptionWhenClosed() throws Exception {
                                                                                      // Arrange - create and close the stream
                                                                                      OutputStream out = new ByteArrayOutputStream();
                                                                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                      stream.close();
                                                                                      
                                                                                      // Act - try to perform an operation that uses ensureOpen()
                                                                                      // We'll use putArchiveEntry since it's public and likely calls ensureOpen()
                                                                                      stream.putArchiveEntry(null);
                                                                                      
                                                                                      // Assert - handled by expected exception in @Test annotation
                                                                                  }

    @Test
                                                                                  public void testEnsureOpenExceptionMessage() {
                                                                                      try {
                                                                                          // Arrange - create and close the stream
                                                                                          OutputStream out = new ByteArrayOutputStream();
                                                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                                          stream.close();
                                                                                          
                                                                                          // Act - try to perform an operation
                                                                                          stream.putArchiveEntry(null);
                                                                                          fail("Expected IOException to be thrown");
                                                                                      } catch (IOException e) {
                                                                                          // Assert - verify the exception message
                                                                                          assertEquals("Stream closed", e.getMessage());
                                                                                      } catch (RuntimeException e) {
                                                                                          // This will catch the mutant's RuntimeException
                                                                                          fail("Expected IOException but got RuntimeException");
                                                                                      }
                                                                                  }

    @Test
                                                                         public void testEnsureOpenThrowsCorrectMessageWhenClosed() {
                                                                             // Arrange
                                                                             OutputStream out = new ByteArrayOutputStream();
                                                                             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                             try {
                                                                                 stream.close(); // This should set closed = true
                                                                             } catch (IOException e) {
                                                                                 fail("Unexpected IOException during close");
                                                                             }
                                                                             byte[] data = new byte[10];
                                                                             
                                                                             try {
                                                                                 // Act
                                                                                 stream.write(data, 0, data.length);
                                                                                 fail("Expected IOException to be thrown");
                                                                             } catch (IOException e) {
                                                                                 // Assert
                                                                                 assertEquals("Exception message should match original", 
                                                                                             "Stream closed", 
                                                                                             e.getMessage());
                                                                             }
                                                                         }

    @Test
                                                                    public void testEnsureOpenThrowsExceptionWhenClosed() throws Exception {
                                                                        // Create a new output stream (in-memory) for testing
                                                                        OutputStream out = new ByteArrayOutputStream();
                                                                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                        
                                                                        // Set closed state to true using reflection
                                                                        java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                        closedField.setAccessible(true);
                                                                        closedField.set(stream, true);
                                                                        
                                                                        try {
                                                                            // Call a public method that uses ensureOpen()
                                                                            stream.closeArchiveEntry();
                                                                            fail("Expected IOException to be thrown");
                                                                        } catch (IOException e) {
                                                                            // Verify the exception message
                                                                            assertEquals("Stream closed", e.getMessage());
                                                                            throw e;
                                                                        }
                                                                    }

    @Test
                                                                    public void testEnsureOpenThrowsCorrectMessageWhenClosed1() throws Exception {
                                                                        // Initialize the stream and mock objects
                                                                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                                        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                        CpioArchiveEntry mockEntry = mock(CpioArchiveEntry.class);
                                                                        
                                                                        // Close the stream properly which sets closed to true
                                                                        stream.close();
                                                                        
                                                                        try {
                                                                            // Try to perform an operation that requires the stream to be open
                                                                            stream.putArchiveEntry(mockEntry);
                                                                            fail("Expected IOException to be thrown");
                                                                        } catch (IOException e) {
                                                                            // Verify the exception message
                                                                            assertEquals("Stream closed", e.getMessage());
                                                                            throw e;
                                                                        }
                                                                    }

    @Test(expected = IOException.class)
                                                               public void testEnsureOpenThrowsWhenClosed4() throws Exception {
                                                                   // Create a new output stream for testing
                                                                   OutputStream out = new ByteArrayOutputStream();
                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                   
                                                                   // Use reflection to set closed to true since it's private
                                                                   java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                                   closedField.setAccessible(true);
                                                                   closedField.set(stream, true);
                                                                   
                                                                   // This should throw IOException in original, but won't in mutant
                                                                   stream.close(); // This will call ensureOpen() internally
                                                               }

    @Test
                                                               public void testEnsureOpenDoesNotThrowWhenOpen2() throws Exception {
                                                                   // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                                   OutputStream out = new ByteArrayOutputStream();
                                                                   CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                                   
                                                                   try {
                                                                       stream.close(); // This will call ensureOpen() internally
                                                                   } catch (IOException e) {
                                                                       // If we get here with the mutant, the test fails
                                                                       fail("Should not throw exception when stream is open");
                                                                   }
                                                               }

    @Test(expected = IOException.class)
                                                      public void testEnsureOpenThrowsWhenClosed5() throws Exception {
                                                          // Create a new output stream (using a dummy OutputStream)
                                                          OutputStream out = new ByteArrayOutputStream();
                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                          
                                                          // Close the stream to set closed to true
                                                          stream.close();
                                                          
                                                          // Use reflection to access the private ensureOpen method
                                                          Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                          ensureOpen.setAccessible(true);
                                                          ensureOpen.invoke(stream); // Should throw IOException
                                                      }

    @Test
                                                      public void testEnsureOpenDoesNotThrowWhenOpen3() throws Exception {
                                                          // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                          OutputStream out = new ByteArrayOutputStream();
                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                          
                                                          // Use reflection to access the private ensureOpen method
                                                          Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                          ensureOpenMethod.setAccessible(true);
                                                          
                                                          // Invoke the method - should not throw an exception
                                                          ensureOpenMethod.invoke(stream);
                                                      }

    @Test(expected = IOException.class)
                                                      public void testEnsureOpenWithExplicitClosedState() throws Exception {
                                                          // Create a new output stream for testing
                                                          OutputStream out = new ByteArrayOutputStream();
                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                          
                                                          // Use reflection to directly set closed field since it's private
                                                          java.lang.reflect.Field closedField = 
                                                              CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                          closedField.setAccessible(true);
                                                          closedField.set(stream, true);
                                                          
                                                          // Use reflection to access the private ensureOpen method
                                                          java.lang.reflect.Method ensureOpenMethod = 
                                                              CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                          ensureOpenMethod.setAccessible(true);
                                                          ensureOpenMethod.invoke(stream);
                                                      }

    @Test
                                                      public void testEnsureOpenWithExplicitOpenState() throws Exception {
                                                          // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                          ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                          CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                          
                                                          // Use reflection to directly set closed field since it's private
                                                          java.lang.reflect.Field closedField = 
                                                              CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                          closedField.setAccessible(true);
                                                          closedField.set(stream, false);
                                                          
                                                          // Use reflection to access the private ensureOpen method
                                                          java.lang.reflect.Method ensureOpenMethod = 
                                                              CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                          ensureOpenMethod.setAccessible(true);
                                                          ensureOpenMethod.invoke(stream); // Should not throw
                                                      }

    @Test
                                                 public void testEnsureOpenWhenClosedShouldThrowException() throws Exception {
                                                     // Create a new stream instance for testing
                                                     OutputStream out = new ByteArrayOutputStream();
                                                     CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                     
                                                     // Set the closed flag to true
                                                     stream.close();
                                                     
                                                     // Set up expected exception
                                                     ExpectedException thrown = ExpectedException.none();
                                                     thrown.expect(IOException.class);
                                                     thrown.expectMessage("Stream closed");
                                                     
                                                     // Use reflection to access private method for testing
                                                     java.lang.reflect.Method method = 
                                                         CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                     method.setAccessible(true);
                                                     method.invoke(stream);
                                                 }

    @Test
                                                 public void testEnsureOpenWhenNotClosedShouldNotThrowException() throws Exception {
                                                     // Create a new output stream (not closed by default)
                                                     OutputStream out = new ByteArrayOutputStream();
                                                     CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                     
                                                     // Use reflection to access private method
                                                     java.lang.reflect.Method method = 
                                                         CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                     method.setAccessible(true);
                                                     
                                                     // Should not throw exception
                                                     method.invoke(stream);
                                                     
                                                     // If we get here, the test passes
                                                 }

    @Test
                                            public void testEnsureOpenThrowsWhenClosed6() throws Exception {
                                                // Create a new output stream for testing
                                                OutputStream out = new ByteArrayOutputStream();
                                                CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                
                                                // Use reflection to set the private closed field to true
                                                Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                closedField.setAccessible(true);
                                                closedField.set(stream, true);
                                                
                                                // Use reflection to access the private ensureOpen method
                                                Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                ensureOpen.setAccessible(true);
                                                
                                                // This should throw IOException
                                                ensureOpen.invoke(stream);
                                            }

    @Test
                                            public void testEnsureOpenDoesNotThrowWhenOpen4() throws Exception {
                                                // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                                ByteArrayOutputStream out = new ByteArrayOutputStream();
                                                CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                                
                                                // Make sure closed is false (default)
                                                Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                                closedField.setAccessible(true);
                                                assertFalse(closedField.getBoolean(stream));
                                                
                                                // Access the private ensureOpen method
                                                Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                                ensureOpen.setAccessible(true);
                                                
                                                // This should not throw any exception
                                                ensureOpen.invoke(stream);
                                            }

    @Test
                                       public void testEnsureOpenThrowsWhenClosed7() throws Exception {
                                           // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                           OutputStream out = new ByteArrayOutputStream();
                                           CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                           
                                           // Set the closed flag to true through reflection since it's private
                                           java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                           closedField.setAccessible(true);
                                           closedField.set(stream, true);
                                           
                                           // Call ensureOpen through reflection since it's private
                                           java.lang.reflect.Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                           ensureOpenMethod.setAccessible(true);
                                           ensureOpenMethod.invoke(stream);
                                       }

    @Test
                                       public void testEnsureOpenDoesNotThrowWhenOpen5() throws Exception {
                                           // Create a new output stream (using ByteArrayOutputStream as a dummy)
                                           OutputStream out = new ByteArrayOutputStream();
                                           CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                           
                                           // Call ensureOpen through reflection
                                           java.lang.reflect.Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                           ensureOpenMethod.setAccessible(true);
                                           ensureOpenMethod.invoke(stream); // Should not throw
                                           
                                           // Clean up
                                           stream.close();
                                       }

    @Test(expected = IOException.class)
                                  public void testEnsureOpenWhenClosed1() throws Exception {
                                      // Create a new output stream (in-memory)
                                      ByteArrayOutputStream out = new ByteArrayOutputStream();
                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                      
                                      // Use reflection to set the private closed field to true
                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                      closedField.setAccessible(true);
                                      closedField.setBoolean(stream, true);
                                      
                                      // This should throw IOException
                                      Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                      ensureOpen.setAccessible(true);
                                      ensureOpen.invoke(stream);
                                  }

    @Test
                                  public void testEnsureOpenWhenNotClosed1() throws Exception {
                                      // Create a new output stream (we can use ByteArrayOutputStream as a dummy)
                                      OutputStream out = new ByteArrayOutputStream();
                                      CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                      
                                      // Use reflection to set the private closed field to false
                                      Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                      closedField.setAccessible(true);
                                      closedField.setBoolean(stream, false);
                                      
                                      // This should not throw any exception
                                      Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                      ensureOpen.setAccessible(true);
                                      ensureOpen.invoke(stream);
                                      
                                      // If we get here, the test passes
                                      assertTrue(true);
                                  }

    @Test
                             public void testEnsureOpenThrowsWhenClosed8() throws Exception {
                                 // Create a new output stream for testing
                                 OutputStream out = new ByteArrayOutputStream();
                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                                 
                                 // Use reflection to set the private closed field to true
                                 java.lang.reflect.Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                                 closedField.setAccessible(true);
                                 closedField.set(stream, true);
                                 
                                 // Invoke the private method using reflection
                                 java.lang.reflect.Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                 ensureOpenMethod.setAccessible(true);
                                 ensureOpenMethod.invoke(stream);
                             }

    @Test
                             public void testEnsureOpenDoesNotThrowWhenOpen6() throws Exception {
                                 // Create a mock OutputStream
                                 OutputStream mockOut = mock(OutputStream.class);
                                 
                                 // Create the CpioArchiveOutputStream instance
                                 CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOut);
                                 
                                 // Invoke the private method using reflection
                                 java.lang.reflect.Method ensureOpenMethod = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                                 ensureOpenMethod.setAccessible(true);
                                 ensureOpenMethod.invoke(stream); // Should not throw
                                 
                                 // Verify no interaction with the output stream (side effect check)
                                 verifyZeroInteractions(mockOut);
                             }

    @Test
                        public void testEnsureOpenThrowsWhenClosed9() throws Exception {
                            // Create a new output stream (using ByteArrayOutputStream as a dummy)
                            OutputStream out = new ByteArrayOutputStream();
                            CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                            
                            // Use reflection to set the private closed field to true
                            Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                            closedField.setAccessible(true);
                            closedField.setBoolean(stream, true);
                            
                            // Call ensureOpen through reflection since it's private
                            Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                            ensureOpen.setAccessible(true);
                            ensureOpen.invoke(stream);
                        }

    @Test
                        public void testEnsureOpenDoesNotThrowWhenOpen7() throws Exception {
                            // Create a new output stream (in-memory)
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                            
                            // Call ensureOpen through reflection
                            Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                            ensureOpen.setAccessible(true);
                            ensureOpen.invoke(stream); // Should not throw
                            
                            // Clean up
                            stream.close();
                        }

    @Test(expected = IOException.class)
                   public void testEnsureOpenThrowsWhenClosed10() throws Exception {
                       // Create a new output stream (using ByteArrayOutputStream as a dummy)
                       OutputStream out = new ByteArrayOutputStream();
                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                       
                       // Set closed field to true using reflection
                       Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                       closedField.setAccessible(true);
                       closedField.set(stream, true);
                       
                       // This should throw IOException
                       stream.close(); // This will call ensureOpen() internally
                   }

    @Test
                   public void testEnsureOpenDoesNotThrowWhenOpen8() throws Exception {
                       // Create a new output stream (in-memory) for testing
                       ByteArrayOutputStream out = new ByteArrayOutputStream();
                       CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                       
                       try {
                           stream.close(); // This will call ensureOpen() internally
                       } catch (IOException e) {
                           fail("Should not throw exception when stream is open");
                       }
                   }

    @Test
              public void testEnsureOpenWhenClosed2() throws Exception {
                  // Create a new output stream (using ByteArrayOutputStream as a dummy)
                  ByteArrayOutputStream out = new ByteArrayOutputStream();
                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                  
                  // Set closed field to true using reflection
                  Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                  closedField.setAccessible(true);
                  closedField.set(stream, true);
                  
                  // Call ensureOpen through reflection since it's private
                  Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                  ensureOpen.setAccessible(true);
                  ensureOpen.invoke(stream);
              }

    @Test
              public void testEnsureOpenWhenNotClosed2() throws Exception {
                  // Create a new output stream for testing
                  OutputStream out = new ByteArrayOutputStream();
                  CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
                  
                  // Set closed field to false using reflection
                  Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
                  closedField.setAccessible(true);
                  closedField.set(stream, false);
                  
                  // Call ensureOpen through reflection since it's private
                  Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
                  ensureOpen.setAccessible(true);
                  
                  // Should not throw exception
                  ensureOpen.invoke(stream);
              }

    @Test
         public void testEnsureOpenThrowsWhenClosed11() throws Exception {
             // Create a new output stream (we'll use ByteArrayOutputStream as a dummy)
             OutputStream out = new ByteArrayOutputStream();
             CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
             
             // Use reflection to set private closed field to true
             Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
             closedField.setAccessible(true);
             closedField.setBoolean(stream, true);
         
             // Use reflection to invoke private ensureOpen method
             Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
             ensureOpen.setAccessible(true);
             ensureOpen.invoke(stream);
         }

    @Test
    public void testEnsureOpenThrowsWhenClosed12() throws Exception {
        // Create a new output stream to test with
        OutputStream out = new ByteArrayOutputStream();
        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(out);
        
        // Use reflection to set the private closed field to true
        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
        closedField.setAccessible(true);
        closedField.set(stream, true);
    
        // Use reflection to call the private ensureOpen method
        Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
        ensureOpen.setAccessible(true);
        ensureOpen.invoke(stream);
    }

    @Test
    public void testEnsureOpenDoesNotThrowWhenOpen9() throws Exception {
        // Create mock output stream
        OutputStream mockOutput = mock(OutputStream.class);
        
        // Create CpioArchiveOutputStream instance
        CpioArchiveOutputStream stream = new CpioArchiveOutputStream(mockOutput);
        
        // Use reflection to set the private closed field to false
        Field closedField = CpioArchiveOutputStream.class.getDeclaredField("closed");
        closedField.setAccessible(true);
        closedField.set(stream, false);
    
        // Use reflection to call the private ensureOpen method
        Method ensureOpen = CpioArchiveOutputStream.class.getDeclaredMethod("ensureOpen");
        ensureOpen.setAccessible(true);
        ensureOpen.invoke(stream); // Should not throw exception
        
        // Verify the stream is still usable by checking another operation
        // For example, we could verify the output stream wasn't closed
        verify(mockOutput, never()).close();
    }


}
