package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
 
public class TarUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                   public void testParseName_NormalCase() {
                       byte[] buffer = { 'f', 'i', 'l', 'e', '.', 't', 'x', 't', 0 };
                       String result = TarUtils.parseName(buffer, 0, 9);
                       assertEquals("file.txt", result);
                   }

 @Test
                   public void testParseName_EmptyBuffer() {
                       byte[] buffer = {};
                       String result = TarUtils.parseName(buffer, 0, 0);
                       assertEquals("", result);
                   }

 @Test
                   public void testParseName_AllNullBytes() {
                       byte[] buffer = { 0, 0, 0, 0 };
                       String result = TarUtils.parseName(buffer, 0, 4);
                       assertEquals("", result);
                   }

 @Test
                   public void testParseName_WithSignExtension() {
                       byte[] buffer = { (byte)0xFF, (byte)0x80, 'a', 0 };
                       String result = TarUtils.parseName(buffer, 0, 4);
                       assertEquals("\u00FF\u0080a", result);
                   }

 @Test
                   public void testParseName_NullTerminatedEarly() {
                       byte[] buffer = { 'a', 'b', 0, 'c', 'd' };
                       String result = TarUtils.parseName(buffer, 0, 5);
                       assertEquals("ab", result);
                   }

 @Test
                   public void testParseName_NoNullTerminator() {
                       byte[] buffer = { 'a', 'b', 'c', 'd' };
                       String result = TarUtils.parseName(buffer, 0, 4);
                       assertEquals("abcd", result);
                   }

 @Test
                   public void testParseName_WithOffset() {
                       byte[] buffer = { 'x', 'y', 'a', 'b', 'c', 0, 'z' };
                       String result = TarUtils.parseName(buffer, 2, 5);
                       assertEquals("abc", result);
                   }

 @Test
           public void testParseName_InvalidOffsetNegative() {
               byte[] buffer = { 'a', 'b' };
               ExpectedException exceptionRule = ExpectedException.none();
               exceptionRule.expect(ArrayIndexOutOfBoundsException.class);
               TarUtils.parseName(buffer, -1, 2);
           }

 @Test
           public void testParseName_InvalidLengthNegative() {
               byte[] buffer = { 'a', 'b' };
               ExpectedException exceptionRule = ExpectedException.none();
               exceptionRule.expect(ArrayIndexOutOfBoundsException.class);
               TarUtils.parseName(buffer, 0, -1);
           }

 @Test(expected = IllegalArgumentException.class)
       public void testParseName_OffsetPlusLengthExceedsBuffer() {
           byte[] buffer = { 'a', 'b', 'c' };
           TarUtils.parseName(buffer, 1, 3);
       }

 @Test(expected = NullPointerException.class)
       public void testParseName_NullBuffer() {
           TarUtils.parseName(null, 0, 10);
       }

 @Test
   public void testParseNameWithOffsetDetectsMutant() {
       // Setup test data with offset
       byte[] buffer = {
           'a', 'b', 'c', 0,      // Should be skipped due to offset
           'd', 'e', 'f', 'g',     // Should be processed
           'h', 'i', 0, 'j'        // Should stop at the null byte
       };
       int offset = 4;
       int length = 8;  // Would process to index 11 (4+8-1) normally, but mutant would process to 7 (8-1)
       
       // Expected behavior: processes 'd','e','f','g','h','i' (stops at null)
       String expected = "defghi";
       
       // Call method
       String result = TarUtils.parseName(buffer, offset, length);
       
       // Assertions
       assertEquals("Should process correct range of bytes with offset", expected, result);
       
       // Additional check to ensure we're testing the right thing
       // With the mutant, it would only process 'd','e','f','g' (up to index 7)
       assertNotEquals("Mutant would return wrong substring", "defg", result);
   }

 @Test
      public void testParseNameFullIteration() {
          // Setup test data that will exercise the full loop
          byte[] buffer = new byte[]{65, 66, 67, 68, 69}; // 'A' to 'E'
          int offset = 0;
          int length = 5;
          
          // Expected behavior - should iterate exactly 5 times
          String expected = "ABCDE";
          
          // Call the method
          String result = TarUtils.parseName(buffer, offset, length);
          
          // Verify the result
          assertEquals("Should convert all bytes to characters", expected, result);
          
          // Verify length to ensure full iteration
          assertEquals("Should have length equal to input length", 
                       length, result.length());
      }

 @Test
 public void testParseNameWithNullByteInMiddle() {
     // Setup test data with null byte in middle and valid data after
     byte[] buffer = new byte[] {'a', 'b', 0, 'c', 'd'};
     int offset = 0;
     int length = 5;
     
     // Expected behavior: should include 'a', 'b' but skip null and include 'c', 'd'
     String expected = "abcd";
     
     // Call method under test
     String actual = TarUtils.parseName(buffer, offset, length);
     
     // Assertion that will catch the mutant
     assertEquals("Method should process bytes after null byte", expected, actual);
     
     // Additional assertion to verify length
     assertEquals("Result length should be 4 (skipping null)", 4, actual.length());
 }

}
