package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.IOUtils;
 
public class TarArchiveInputStreamTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_PathHeader() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create instance of class under test
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Set up test data
                                                                                                                                                                                                                                                             headers.put("path", "/test/path/file.txt");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set current entry
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInput, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to invoke the private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInput, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify the result
                                                                                                                                                                                                                                                             verify(mockEntry).setName("/test/path/file.txt");
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_LinkPathHeader() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set the current entry and access private method
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                                             headers.put("linkpath", "/symlink/target");
                                                                                                                                                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setLinkName("/symlink/target");
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_GidHeader() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("gid", "1001");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set current entry
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInput, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to call private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInput, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setGroupId(1001L);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_GnameHeader() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("gname", "testgroup");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create instance of class under test
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set current entry
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInput, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to invoke private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInput, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setGroupName("testgroup");
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_UidHeader() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("uid", "1000");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set current entry and invoke private method
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setUserId(1000L);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_UnameHeader() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set the current entry and access private method
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Test
                                                                                                                                                                                                                                                             headers.put("uname", "testuser");
                                                                                                                                                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setUserName("testuser");
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_SizeHeader() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create instance of class under test
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set current entry (since it's protected)
                                                                                                                                                                                                                                                             Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                             setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                             setCurrentEntry.invoke(tarInput, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create headers map
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("size", "1024");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to invoke private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInput, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setSize(1024L);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_MtimeHeader() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream inputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set the current entry field
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(inputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create headers map
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("mtime", "1234567890.123");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(inputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify the mock was called correctly
                                                                                                                                                                                                                                                             verify(mockEntry).setModTime(1234567890123L);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_DevMinorHeader() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set currentEntry field
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currentEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create headers map
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("SCHILY.devminor", "5");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to access private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setDevMinor(5);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_DevMajorHeader() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("SCHILY.devmajor", "1");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             TarArchiveInputStream tarIn = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set currentEntry field
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarIn, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to invoke private method
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarIn, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                             verify(mockEntry).setDevMajor(1);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_UnknownHeader() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                                                                                             headers.put("unknown", "value");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create instance of class under test
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set currentEntry field and invoke private method
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify no interactions with the entry for unknown headers
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setName(any(String.class));
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setLinkName(any(String.class));
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setGroupId(anyLong());
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setGroupName(any(String.class));
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setUserId(anyLong());
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setUserName(any(String.class));
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setSize(anyLong());
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setModTime(anyLong());
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setDevMinor(anyInt());
                                                                                                                                                                                                                                                             verify(mockEntry, never()).setDevMajor(anyInt());
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_MultipleHeaders() throws Exception {
                                                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Set up headers map
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             headers.put("path", "/test/path");
                                                                                                                                                                                                                                                             headers.put("uid", "1000");
                                                                                                                                                                                                                                                             headers.put("gid", "1001");
                                                                                                                                                                                                                                                             headers.put("size", "2048");
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Use reflection to set current entry and invoke private method
                                                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify interactions
                                                                                                                                                                                                                                                             verify(mockEntry).setName("/test/path");
                                                                                                                                                                                                                                                             verify(mockEntry).setUserId(1000L);
                                                                                                                                                                                                                                                             verify(mockEntry).setGroupId(1001L);
                                                                                                                                                                                                                                                             verify(mockEntry).setSize(2048L);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_EmptyHeaders() throws Exception {
                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                                             TarArchiveInputStream tarInput = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Set current entry using reflection
                                                                                                                                                                                                                                                             Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                             setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                                             setCurrentEntry.invoke(tarInput, mockEntry);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Prepare empty headers
                                                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Invoke private method using reflection
                                                                                                                                                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             method.invoke(tarInput, headers);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Verify no interactions with the entry
                                                                                                                                                                                                                                                             verifyZeroInteractions(mockEntry);
                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_NullHeaders() throws Exception {
                                                                                                                                                                                                                                                             // Setup ExpectedException rule
                                                                                                                                                                                                                                                             org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                             expectedException.expect(NullPointerException.class);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Create instance of TarArchiveInputStream
                                                                                                                                                                                                                                                             TarArchiveInputStream tais = new TarArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Get the private method using reflection
                                                                                                                                                                                                                                                             java.lang.reflect.Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                             // Invoke the method with null parameter
                                                                                                                                                                                                                                                             method.invoke(tais, (Map<String, String>)null);
                                                                                                                                                                                                                                                         }

    @Test(expected = NumberFormatException.class)
                                                                                                                                                                                                                                                     public void testApplyPaxHeadersToCurrentEntry_GidHeaderInvalidNumber() throws Exception {
                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                         headers.put("gid", "not-a-number");
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Create instance of the class under test
                                                                                                                                                                                                                                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Get the private method using reflection
                                                                                                                                                                                                                                                         Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                                             "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                         method.setAccessible(true);
                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                         // Invoke the method - should throw NumberFormatException
                                                                                                                                                                                                                                                         method.invoke(tarInput, headers);
                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                public void testApplyPaxHeadersToCurrentEntry_LinkpathWithDifferentStringInstance() throws Exception {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                                    TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                                                                    Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                                    setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                                                                    setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create headers with a different String instance for "linkpath" key
                                                                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                                    String linkpathKey = new String("linkpath"); // Different instance
                                                                                                                                                                                                                                                    String linkpathValue = "testLink";
                                                                                                                                                                                                                                                    headers.put(linkpathKey, linkpathValue);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Mock the entry to verify setLinkName is called
                                                                                                                                                                                                                                                    TarArchiveEntry spyEntry = spy(entry);
                                                                                                                                                                                                                                                    setCurrentEntryMethod.invoke(tarInput, spyEntry);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                                    Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                                    applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                                    applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                                    verify(spyEntry).setLinkName(linkpathValue);
                                                                                                                                                                                                                                                    // Also verify no other important properties were set
                                                                                                                                                                                                                                                    verify(spyEntry, never()).setName(anyString());
                                                                                                                                                                                                                                                    verify(spyEntry, never()).setGroupId(anyLong());
                                                                                                                                                                                                                                                    verify(spyEntry, never()).setUserId(anyLong());
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                       public void testApplyPaxHeadersToCurrentEntryWithNullKey() throws Exception {
                                                                                                                                                                                                                                           // Create mock input stream
                                                                                                                                                                                                                                           InputStream mockInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create TarArchiveInputStream instance
                                                                                                                                                                                                                                           TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInput);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create mock entry and set it as current entry using reflection
                                                                                                                                                                                                                                           TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                           Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                           currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                           currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Prepare headers map with a null key
                                                                                                                                                                                                                                           Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                           headers.put(null, "someValue");  // Null key
                                                                                                                                                                                                                                           headers.put("linkpath", "linkValue");  // Regular key
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Get the private method using reflection
                                                                                                                                                                                                                                           Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                               "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                           applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Call the method - should not throw NullPointerException
                                                                                                                                                                                                                                           applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify the linkpath was still processed correctly
                                                                                                                                                                                                                                           verify(mockEntry).setLinkName("linkValue");
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // No need to verify null key processing as original code ignores it
                                                                                                                                                                                                                                           // The test will fail if NullPointerException is thrown by the mutant
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                  public void testApplyPaxHeadersToCurrentEntry_DetectsLinkpathMutant() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                                      TarArchiveEntry entry = new TarArchiveEntry("testEntry");
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                                                      Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                                      setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                                      setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Create headers with a non-linkpath key that would be affected by the mutant
                                                                                                                                                                                                                                      Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                      String testValue = "shouldNotBeLinkName";
                                                                                                                                                                                                                                      headers.put("gid", testValue); // This comes after linkpath in the if-else chain
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                                      Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                      applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                      applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify link name was NOT set (should be null)
                                                                                                                                                                                                                                      assertNull("Link name should not be set for gid header", entry.getLinkName());
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Also test normal linkpath behavior
                                                                                                                                                                                                                                      String expectedLinkName = "validLink";
                                                                                                                                                                                                                                      headers.clear();
                                                                                                                                                                                                                                      headers.put("linkpath", expectedLinkName);
                                                                                                                                                                                                                                      applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                                                      assertEquals("Link name should be set for linkpath header", 
                                                                                                                                                                                                                                                  expectedLinkName, entry.getLinkName());
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                             public void testApplyPaxHeadersToCurrentEntry_LinkPathShouldSetCorrectValue() throws Exception {
                                                                                                                                                                                                                                 // Prepare test data
                                                                                                                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                                 String expectedLinkName = "test/link/path";
                                                                                                                                                                                                                                 headers.put("linkpath", expectedLinkName);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Create mock objects
                                                                                                                                                                                                                                 InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                                 TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                                 TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Use reflection to set the current entry since it's a protected field
                                                                                                                                                                                                                                 Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                                 currentEntryField.setAccessible(true);
                                                                                                                                                                                                                                 currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Call the method under test
                                                                                                                                                                                                                                 Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                                 method.setAccessible(true);
                                                                                                                                                                                                                                 method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Verify the behavior
                                                                                                                                                                                                                                 verify(mockEntry).setLinkName(expectedLinkName);
                                                                                                                                                                                                                                 // The mutant would set empty string instead, so this verification would fail
                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                         public void testApplyPaxHeadersToCurrentEntry_LinkPathWithEmptyValue() throws Exception {
                                                                                                                                                                                                                             // Prepare test data - empty linkpath value
                                                                                                                                                                                                                             Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                                                                             headers.put("linkpath", "");
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create mock objects
                                                                                                                                                                                                                             TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                             InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Create real TarArchiveInputStream with mock input stream
                                                                                                                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Use reflection to set the current entry since it's protected
                                                                                                                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Use reflection to access the private method
                                                                                                                                                                                                                             Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                             applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Call the method under test
                                                                                                                                                                                                                             applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                                                                                                                                             
                                                                                                                                                                                                                             // Verify the behavior
                                                                                                                                                                                                                             verify(mockEntry).setLinkName("");
                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_ShouldSetLinkNameSeparatelyFromName() throws Exception {
                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("dummy");
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                                        Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                                        setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                                        setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Create headers with both path and linkpath
                                                                                                                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                        String expectedName = "test/path";
                                                                                                                                                                                                                        String expectedLinkName = "test/linkpath";
                                                                                                                                                                                                                        headers.put("path", expectedName);
                                                                                                                                                                                                                        headers.put("linkpath", expectedLinkName);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                                        Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                        applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                                        applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Verify
                                                                                                                                                                                                                        assertEquals("Entry name should be set from 'path' header", 
                                                                                                                                                                                                                            expectedName, entry.getName());
                                                                                                                                                                                                                        assertEquals("Link name should be set from 'linkpath' header", 
                                                                                                                                                                                                                            expectedLinkName, entry.getLinkName());
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Additional check to ensure they're not the same
                                                                                                                                                                                                                        assertNotEquals("Entry name and link name should be different",
                                                                                                                                                                                                                            entry.getName(), entry.getLinkName());
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                               public void testApplyPaxHeadersToCurrentEntry_ShouldSetLinkName_WhenLinkpathHeaderPresent() throws Exception {
                                                                                                                                                                                                                   // Prepare test data and mocks
                                                                                                                                                                                                                   InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                                                   TarArchiveInputStream tarInputStream = new TarArchiveInputStream(inputStream);
                                                                                                                                                                                                                   TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Use reflection to set the currentEntry field since it's protected
                                                                                                                                                                                                                   Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                                                   currentEntryField.setAccessible(true);
                                                                                                                                                                                                                   currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                                   String expectedLinkName = "test/link/path";
                                                                                                                                                                                                                   headers.put("linkpath", expectedLinkName);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Call the method under test
                                                                                                                                                                                                                   Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                                                   method.invoke(tarInputStream, headers);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Verify the link name was set
                                                                                                                                                                                                                   verify(mockEntry).setLinkName(expectedLinkName);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   // Additional verification that no other unexpected interactions occurred
                                                                                                                                                                                                                   verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                          public void testApplyPaxHeadersToCurrentEntry_DetectsGidStringComparisonMutant() throws Exception {
                                                                                                                                                                                                              // Create a new String instance for "gid" to test reference vs value equality
                                                                                                                                                                                                              String gidKey = new String("gid");
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Setup test data
                                                                                                                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                              headers.put(gidKey, "12345");  // Using different String instance
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Mock the current entry
                                                                                                                                                                                                              TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                              TarArchiveInputStream stream = new TarArchiveInputStream(null);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                              Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                              setCurrentEntry.setAccessible(true);
                                                                                                                                                                                                              setCurrentEntry.invoke(stream, currEntry);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                              Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                              applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                                              applyPaxHeaders.invoke(stream, headers);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Verify the group ID was set - this would fail with the mutant
                                                                                                                                                                                                              verify(currEntry).setGroupId(12345L);
                                                                                                                                                                                                              
                                                                                                                                                                                                              // Additional verification that no other setters were called
                                                                                                                                                                                                              verify(currEntry, never()).setName(any());
                                                                                                                                                                                                              verify(currEntry, never()).setLinkName(any());
                                                                                                                                                                                                              verify(currEntry, never()).setGroupName(any());
                                                                                                                                                                                                              verify(currEntry, never()).setUserId(any());
                                                                                                                                                                                                              verify(currEntry, never()).setUserName(any());
                                                                                                                                                                                                              verify(currEntry, never()).setSize(anyLong());
                                                                                                                                                                                                              verify(currEntry, never()).setModTime(anyLong());
                                                                                                                                                                                                              verify(currEntry, never()).setDevMinor(anyInt());
                                                                                                                                                                                                              verify(currEntry, never()).setDevMajor(anyInt());
                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                     public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupId_WhenGidHeaderPresent() throws Exception {
                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                         TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                         TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                             "setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                         setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                         setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Prepare headers with gid
                                                                                                                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                         String expectedGid = "12345";
                                                                                                                                                                                                         headers.put("gid", expectedGid);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Execute
                                                                                                                                                                                                         Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                             "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                         method.setAccessible(true);
                                                                                                                                                                                                         method.invoke(tarInput, headers);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                         assertEquals("Group ID should be set from gid header", 
                                                                                                                                                                                                             Long.parseLong(expectedGid), entry.getGroupId());
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                public void testApplyPaxHeadersToCurrentEntry_GroupIdParsing() throws Exception {
                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                    TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                                    TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                                    Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                                    setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                                                    setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create headers with a non-zero gid value
                                                                                                                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                                    headers.put("gid", "12345");  // Non-zero test value
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                                    Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                                    applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                                                    applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                    verify(mockEntry).setGroupId(12345L);  // Verify correct value was set
                                                                                                                                                                                                    // The mutant would set it to 0 instead, which would fail this verification
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_HandlesLargeGroupId() throws Exception {
                                                                                                                                                                                               // Create mock objects
                                                                                                                                                                                               InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                               
                                                                                                                                                                                               // Create real TarArchiveInputStream with mock input stream
                                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                               
                                                                                                                                                                                               // Use reflection to set the current entry since setCurrentEntry is protected
                                                                                                                                                                                               Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                               currentEntryField.setAccessible(true);
                                                                                                                                                                                               currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                                               
                                                                                                                                                                                               // Prepare test data with group ID larger than Integer.MAX_VALUE
                                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                               long largeGroupId = 2147483648L; // Integer.MAX_VALUE + 1
                                                                                                                                                                                               headers.put("gid", String.valueOf(largeGroupId));
                                                                                                                                                                                               
                                                                                                                                                                                               // Use reflection to call the private method
                                                                                                                                                                                               Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                                   "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                               method.setAccessible(true);
                                                                                                                                                                                               method.invoke(tarInputStream, headers);
                                                                                                                                                                                               
                                                                                                                                                                                               // Verify the group ID was set correctly as a long value
                                                                                                                                                                                               verify(mockEntry).setGroupId(largeGroupId);
                                                                                                                                                                                               
                                                                                                                                                                                               // Additional verification that no other unexpected interactions occurred
                                                                                                                                                                                               verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                      public void testApplyPaxHeadersToCurrentEntry_DetectsGnameMutant() throws Exception {
                                                                                                                                                                                          // Create test data with a "gname" key that's a different String instance
                                                                                                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                          headers.put(new String("gname"), "testgroup"); // Different String instance
                                                                                                                                                                                          
                                                                                                                                                                                          // Create mock entry to verify behavior
                                                                                                                                                                                          TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create test instance
                                                                                                                                                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to access protected setCurrentEntry method
                                                                                                                                                                                          Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                                          setCurrentEntry.setAccessible(true);
                                                                                                                                                                                          setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                                          Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                          applyPaxHeaders.setAccessible(true);
                                                                                                                                                                                          applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify the group name was set (would fail with mutant)
                                                                                                                                                                                          verify(entry).setGroupName("testgroup");
                                                                                                                                                                                          
                                                                                                                                                                                          // Additional verification that no other properties were set
                                                                                                                                                                                          verify(entry, never()).setName(anyString());
                                                                                                                                                                                          verify(entry, never()).setLinkName(anyString());
                                                                                                                                                                                          verify(entry, never()).setGroupId(anyLong());
                                                                                                                                                                                          verify(entry, never()).setUserId(anyLong());
                                                                                                                                                                                          verify(entry, never()).setUserName(anyString());
                                                                                                                                                                                          verify(entry, never()).setSize(anyLong());
                                                                                                                                                                                          verify(entry, never()).setModTime(anyLong());
                                                                                                                                                                                          verify(entry, never()).setDevMinor(anyInt());
                                                                                                                                                                                          verify(entry, never()).setDevMajor(anyInt());
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetGroupNameForNonGnameKey() throws Exception {
                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                     TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                     TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                     
                                                                                                                                                                                     // Set current entry via reflection
                                                                                                                                                                                     Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                     currEntryField.setAccessible(true);
                                                                                                                                                                                     currEntryField.set(tarInputStream, currEntry);
                                                                                                                                                                                     
                                                                                                                                                                                     // Prepare test data - use a key that should NOT set group name
                                                                                                                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                     headers.put("some_other_key", "wrong_group_name");
                                                                                                                                                                                     
                                                                                                                                                                                     // Get the private method via reflection
                                                                                                                                                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                         "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Invoke the method
                                                                                                                                                                                     method.invoke(tarInputStream, headers);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify group name was NOT set (should pass with original code, fail with mutant)
                                                                                                                                                                                     verify(currEntry, never()).setGroupName(anyString());
                                                                                                                                                                                     
                                                                                                                                                                                     // Additional verification that no other unexpected interactions occurred
                                                                                                                                                                                     verifyNoMoreInteractions(currEntry);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameForGnameKey() throws Exception {
                                                                                                                                                                                     // Create mock objects
                                                                                                                                                                                     InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                                                     TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                                     TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                     
                                                                                                                                                                                     // Set current entry using reflection
                                                                                                                                                                                     Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                     currEntryField.setAccessible(true);
                                                                                                                                                                                     currEntryField.set(tarInputStream, currEntry);
                                                                                                                                                                                     
                                                                                                                                                                                     // Prepare test data
                                                                                                                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                     headers.put("gname", "correct_group_name");
                                                                                                                                                                                     
                                                                                                                                                                                     // Get the private method via reflection
                                                                                                                                                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                         "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Invoke the method
                                                                                                                                                                                     method.invoke(tarInputStream, headers);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify group name was set with correct value
                                                                                                                                                                                     verify(currEntry).setGroupName("correct_group_name");
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                             public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameFromHeaders() throws Exception {
                                                                                                                                                                                 // Setup
                                                                                                                                                                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                                 TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to set private currEntry field since there's no setter
                                                                                                                                                                                 Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                                 currEntryField.setAccessible(true);
                                                                                                                                                                                 currEntryField.set(tarInput, mockEntry);
                                                                                                                                                                                 
                                                                                                                                                                                 // Prepare headers with gname
                                                                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                                                                 String expectedGroupName = "testGroup";
                                                                                                                                                                                 headers.put("gname", expectedGroupName);
                                                                                                                                                                                 
                                                                                                                                                                                 // Call method
                                                                                                                                                                                 Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                 method.setAccessible(true);
                                                                                                                                                                                 method.invoke(tarInput, headers);
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify group name was set correctly
                                                                                                                                                                                 verify(mockEntry).setGroupName(expectedGroupName);
                                                                                                                                                                                 
                                                                                                                                                                                 // Clean up
                                                                                                                                                                                 currEntryField.setAccessible(false);
                                                                                                                                                                                 method.setAccessible(false);
                                                                                                                                                                             }

    @Test
                                                                                                                                                                           public void testApplyPaxHeadersToCurrentEntry_DetectsGroupNameMutant() {
                                                                                                                                                                               // Prepare test data
                                                                                                                                                                               String groupName = "testGroup";
                                                                                                                                                                               String userName = "testUser";
                                                                                                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                                                                                                               headers.put("gname", groupName);
                                                                                                                                                                               headers.put("uname", userName);
                                                                                                                                                                               
                                                                                                                                                                               // Create mock objects
                                                                                                                                                                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                               TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to set currentEntry since it's protected
                                                                                                                                                                               try {
                                                                                                                                                                                   Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currentEntry");
                                                                                                                                                                                   currentEntryField.setAccessible(true);
                                                                                                                                                                                   currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Failed to set currentEntry via reflection");
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               // Call the method
                                                                                                                                                                               try {
                                                                                                                                                                                   Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                                       "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                                                   method.invoke(tarInputStream, headers);
                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                   fail("Failed to invoke applyPaxHeadersToCurrentEntry");
                                                                                                                                                                               }
                                                                                                                                                                           
                                                                                                                                                                               // Verify correct behavior
                                                                                                                                                                               verify(mockEntry).setGroupName(groupName);  // This will fail with the mutant
                                                                                                                                                                               verify(mockEntry).setUserName(userName);
                                                                                                                                                                               
                                                                                                                                                                               // Verify no unexpected interactions
                                                                                                                                                                               verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                      public void testApplyPaxHeadersToCurrentEntry_DetectsUidStringComparisonMutant() throws Exception {
                                                                                                                                                                          // Create test data with a "uid" key that's a different String object
                                                                                                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                                                                                                          headers.put(new String("uid"), "1234"); // Force new String instance
                                                                                                                                                                          
                                                                                                                                                                          // Create mock TarArchiveEntry to verify interactions
                                                                                                                                                                          TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                          
                                                                                                                                                                          // Create instance
                                                                                                                                                                          TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to call protected setCurrentEntry method
                                                                                                                                                                          Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                          setCurrentEntryMethod.setAccessible(true);
                                                                                                                                                                          setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                                                          
                                                                                                                                                                          // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                                          Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                          applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                                                          applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                                                          
                                                                                                                                                                          // Verify the uid was set (would fail with mutant)
                                                                                                                                                                          verify(mockEntry).setUserId(1234L);
                                                                                                                                                                          
                                                                                                                                                                          // Also verify no other unexpected interactions
                                                                                                                                                                          verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserId_WhenUidHeaderPresent() throws Exception {
                                                                                                                                                                     // Prepare test data
                                                                                                                                                                     Map<String, String> headers = new HashMap<String, String>();
                                                                                                                                                                     String testUid = "1001";
                                                                                                                                                                     headers.put("uid", testUid);
                                                                                                                                                                     
                                                                                                                                                                     // Create mock objects
                                                                                                                                                                     InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                     TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                     
                                                                                                                                                                     // Create real TarArchiveInputStream with mock input stream
                                                                                                                                                                     TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set the current entry since it's protected
                                                                                                                                                                     Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                     currentEntryField.setAccessible(true);
                                                                                                                                                                     currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                     
                                                                                                                                                                     // Call the method under test
                                                                                                                                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                         "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                                     method.invoke(tarInputStream, headers);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the interaction
                                                                                                                                                                     verify(mockEntry).setUserId(Long.parseLong(testUid));
                                                                                                                                                                     
                                                                                                                                                                     // Also verify no other unexpected interactions
                                                                                                                                                                     verifyNoMoreInteractions(mockEntry);
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testApplyPaxHeadersToCurrentEntry_UserIdShouldBeSetFromHeader() throws Exception {
                                                                                                                                                                // Prepare test data
                                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                                String testUid = "1001"; // Non-zero test value
                                                                                                                                                                headers.put("uid", testUid);
                                                                                                                                                                
                                                                                                                                                                // Create mock objects
                                                                                                                                                                InputStream mockInputStream = mock(InputStream.class);
                                                                                                                                                                TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                
                                                                                                                                                                // Create real TarArchiveInputStream with mock input stream
                                                                                                                                                                TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set the current entry since setCurrentEntry is protected
                                                                                                                                                                Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                    "setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                                setCurrentEntry.setAccessible(true);
                                                                                                                                                                setCurrentEntry.invoke(tarInputStream, mockEntry);
                                                                                                                                                                
                                                                                                                                                                // Call the method under test
                                                                                                                                                                Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                    "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                applyPaxHeaders.setAccessible(true);
                                                                                                                                                                applyPaxHeaders.invoke(tarInputStream, headers);
                                                                                                                                                                
                                                                                                                                                                // Verify the behavior
                                                                                                                                                                verify(mockEntry).setUserId(Long.parseLong(testUid));
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testApplyPaxHeadersToCurrentEntry_UserIdShouldNotBeZeroWhenHeaderPresent() throws Exception {
                                                                                                                                                                // Prepare test data
                                                                                                                                                                Map<String, String> headers = new HashMap<>();
                                                                                                                                                                String testUid = "500"; // Non-zero test value
                                                                                                                                                                headers.put("uid", testUid);
                                                                                                                                                                
                                                                                                                                                                // Create mock objects
                                                                                                                                                                TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                                TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set private fields since we're testing a private method
                                                                                                                                                                Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                                currentEntryField.setAccessible(true);
                                                                                                                                                                currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                                
                                                                                                                                                                // Get the private method to test
                                                                                                                                                                Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                                    "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                                method.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Call the method under test
                                                                                                                                                                method.invoke(tarInputStream, headers);
                                                                                                                                                                
                                                                                                                                                                // Verify the behavior - ensure it's not set to 0
                                                                                                                                                                verify(mockEntry, never()).setUserId(0); // This will fail if mutant is present
                                                                                                                                                                verify(mockEntry).setUserId(eq(Long.parseLong(testUid))); // Positive verification
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testApplyPaxHeadersToCurrentEntry_HandlesLargeUserId() throws Exception {
                                                                                                                                                           // Create mock objects
                                                                                                                                                           InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                           TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                                           TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                                           
                                                                                                                                                           // Use reflection to set the current entry since setCurrentEntry is protected
                                                                                                                                                           Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                                                           currentEntryField.setAccessible(true);
                                                                                                                                                           currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                                                       
                                                                                                                                                           // Prepare test data with a user ID larger than Integer.MAX_VALUE
                                                                                                                                                           Map<String, String> headers = new HashMap<>();
                                                                                                                                                           long largeUserId = Integer.MAX_VALUE + 1L;
                                                                                                                                                           headers.put("uid", String.valueOf(largeUserId));
                                                                                                                                                           
                                                                                                                                                           // Call the method
                                                                                                                                                           Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                               "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                           method.setAccessible(true);
                                                                                                                                                           method.invoke(tarInputStream, headers);
                                                                                                                                                           
                                                                                                                                                           // Verify the correct method was called with the correct value
                                                                                                                                                           verify(mockEntry).setUserId(largeUserId);
                                                                                                                                                           
                                                                                                                                                           // The mutant would either:
                                                                                                                                                           // 1. Throw NumberFormatException (which would fail the test)
                                                                                                                                                           // 2. Call setUserId with a truncated value (which would fail the verify)
                                                                                                                                                       }

    @Test(expected = NumberFormatException.class)
                                                                                                                                                       public void testApplyPaxHeadersToCurrentEntry_InvalidUserId() throws Exception {
                                                                                                                                                           // Test with invalid user ID to ensure proper exception handling
                                                                                                                                                           InputStream dummyInput = new ByteArrayInputStream(new byte[0]);
                                                                                                                                                           TarArchiveInputStream tarInputStream = new TarArchiveInputStream(dummyInput);
                                                                                                                                                           
                                                                                                                                                           Map<String, String> headers = new HashMap<>();
                                                                                                                                                           headers.put("uid", "invalid-number");
                                                                                                                                                           
                                                                                                                                                           // Use reflection to access private method
                                                                                                                                                           Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                                               "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                           method.setAccessible(true);
                                                                                                                                                           method.invoke(tarInputStream, headers);
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testApplyPaxHeadersToCurrentEntry_DetectsUnameStringComparisonMutant() throws Exception {
                                                                                                                                                      // Create test data with "uname" as a different String instance
                                                                                                                                                      Map<String, String> headers = new HashMap<>();
                                                                                                                                                      headers.put(new String("uname"), "testuser"); // Force new String instance
                                                                                                                                                      
                                                                                                                                                      // Create mock TarArchiveEntry to verify behavior
                                                                                                                                                      TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                                                      
                                                                                                                                                      // Create instance of class under test
                                                                                                                                                      TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access protected setCurrentEntry method
                                                                                                                                                      Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                      setCurrentEntry.setAccessible(true);
                                                                                                                                                      setCurrentEntry.invoke(tarInput, currEntry);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                                      Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                      applyPaxHeaders.setAccessible(true);
                                                                                                                                                      applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                      
                                                                                                                                                      // Verify the user name was set (would fail with mutant)
                                                                                                                                                      verify(currEntry).setUserName("testuser");
                                                                                                                                                      
                                                                                                                                                      // Additional verification that no other unexpected interactions occurred
                                                                                                                                                      verifyNoMoreInteractions(currEntry);
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetUserNameForNonUnameKey() throws Exception {
                                                                                                                                                 // Setup
                                                                                                                                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                                 TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                                 
                                                                                                                                                 // Use reflection to call protected setCurrentEntry method
                                                                                                                                                 Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                                 setCurrentEntry.setAccessible(true);
                                                                                                                                                 setCurrentEntry.invoke(tarInput, entry);
                                                                                                                                                 
                                                                                                                                                 // Create headers with a key that would reach the uname condition but isn't "uname"
                                                                                                                                                 Map<String, String> headers = new HashMap<>();
                                                                                                                                                 headers.put("randomKey", "testUser");  // This should NOT set userName
                                                                                                                                                 
                                                                                                                                                 // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                                                                                 Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                                 applyPaxHeaders.setAccessible(true);
                                                                                                                                                 applyPaxHeaders.invoke(tarInput, headers);
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertNull("UserName should not be set for non-uname key", entry.getUserName());
                                                                                                                                                 
                                                                                                                                                 // Additional verification that other properties weren't affected
                                                                                                                                                 assertEquals("test", entry.getName());  // Verify original name unchanged
                                                                                                                                                 assertNull(entry.getLinkName());       // Verify link name not set
                                                                                                                                                 assertEquals(0, entry.getSize());      // Verify size not changed
                                                                                                                                             }

    @Test
                                                                                                                                        public void testApplyPaxHeadersToCurrentEntry_UnameShouldSetCorrectUserName() throws Exception {
                                                                                                                                            // Prepare test data
                                                                                                                                            Map<String, String> headers = new HashMap<>();
                                                                                                                                            String expectedUserName = "testuser";
                                                                                                                                            headers.put("uname", expectedUserName);
                                                                                                                                            
                                                                                                                                            // Create mock objects
                                                                                                                                            InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                                            TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                                            TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                            
                                                                                                                                            // Use reflection to set current entry since setCurrentEntry is protected
                                                                                                                                            Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                            setCurrentEntry.setAccessible(true);
                                                                                                                                            setCurrentEntry.invoke(tarInputStream, mockEntry);
                                                                                                                                            
                                                                                                                                            // Call the method
                                                                                                                                            Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                            applyPaxHeaders.setAccessible(true);
                                                                                                                                            applyPaxHeaders.invoke(tarInputStream, headers);
                                                                                                                                            
                                                                                                                                            // Verify the behavior
                                                                                                                                            verify(mockEntry).setUserName(expectedUserName);
                                                                                                                                        }

    @Test
                                                                                                                                   public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserName_WhenUnameHeaderPresent() throws Exception {
                                                                                                                                       // Setup
                                                                                                                                       TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                                                       TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                                                                       
                                                                                                                                       // Use reflection to access protected setCurrentEntry method
                                                                                                                                       Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                       setCurrentEntryMethod.setAccessible(true);
                                                                                                                                       setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                                                                       
                                                                                                                                       // Prepare headers with uname
                                                                                                                                       Map<String, String> headers = new HashMap<>();
                                                                                                                                       String expectedUserName = "testuser";
                                                                                                                                       headers.put("uname", expectedUserName);
                                                                                                                                       String originalGroupName = "originalgroup";
                                                                                                                                       entry.setGroupName(originalGroupName); // Set initial group name
                                                                                                                                       
                                                                                                                                       // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                       Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                       applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                       applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                       
                                                                                                                                       // Verify
                                                                                                                                       assertEquals("User name should be set from uname header", 
                                                                                                                                                    expectedUserName, entry.getUserName());
                                                                                                                                       assertEquals("Group name should remain unchanged",
                                                                                                                                                    originalGroupName, entry.getGroupName());
                                                                                                                                   }

    @Test
                                                                                                                              public void testApplyPaxHeadersToCurrentEntry_LinkPathWithDifferentStringObject() throws Exception {
                                                                                                                                  // Create test data with a different String object for "linkpath"
                                                                                                                                  Map<String, String> headers = new HashMap<>();
                                                                                                                                  String linkpathKey = new String("linkpath"); // Different object than literal
                                                                                                                                  String expectedLinkName = "testLink";
                                                                                                                                  headers.put(linkpathKey, expectedLinkName);
                                                                                                                                  
                                                                                                                                  // Create mock entry and input stream
                                                                                                                                  TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                                  InputStream mockStream = mock(InputStream.class);
                                                                                                                                  
                                                                                                                                  // Create instance
                                                                                                                                  TarArchiveInputStream tarInput = new TarArchiveInputStream(mockStream);
                                                                                                                                  
                                                                                                                                  // Use reflection to access protected setCurrentEntry method
                                                                                                                                  Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                                  setCurrentEntryMethod.setAccessible(true);
                                                                                                                                  setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                                  
                                                                                                                                  // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                                                  Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                                  applyPaxHeadersMethod.setAccessible(true);
                                                                                                                                  applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                                                  
                                                                                                                                  // Verify the link name was set (would fail with mutant)
                                                                                                                                  verify(mockEntry).setLinkName(expectedLinkName);
                                                                                                                                  
                                                                                                                                  // Also verify no other interactions to ensure we're testing specifically the linkpath case
                                                                                                                                  verifyNoMoreInteractions(mockEntry);
                                                                                                                              }

    @Test
                                                                                                                         public void testApplyPaxHeadersToCurrentEntryWithNullKey1() throws Exception {
                                                                                                                             // Create mock objects
                                                                                                                             InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                             TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                                             TarArchiveEntry mockEntry = new TarArchiveEntry("testEntry");
                                                                                                                             
                                                                                                                             // Use reflection to set private fields since we need to test a private method
                                                                                                                             Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                             currentEntryField.setAccessible(true);
                                                                                                                             currentEntryField.set(tarInputStream, mockEntry);
                                                                                                                             
                                                                                                                             // Prepare test data - map with null key
                                                                                                                             Map<String, String> headers = new HashMap<>();
                                                                                                                             headers.put(null, "someValue");
                                                                                                                             headers.put("linkpath", "testLink"); // Add a valid entry to ensure other processing works
                                                                                                                             
                                                                                                                             // Get the private method we want to test
                                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                             method.setAccessible(true);
                                                                                                                             
                                                                                                                             // Call the method - should not throw NullPointerException
                                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                                             
                                                                                                                             // Verify the linkpath was still processed correctly
                                                                                                                             assertEquals("testLink", mockEntry.getLinkName());
                                                                                                                         }

    @Test
                                                                                                                    public void testApplyPaxHeadersToCurrentEntry_DetectsGidStringComparisonMutant1() {
                                                                                                                        // Create a mock TarArchiveEntry
                                                                                                                        TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                                        
                                                                                                                        // Create a map with a "gid" key that's a different String instance
                                                                                                                        Map<String, String> headers = new HashMap<>();
                                                                                                                        headers.put(new String("gid"), "123"); // Different String instance
                                                                                                                        
                                                                                                                        // Create the test instance
                                                                                                                        TarArchiveInputStream tarInput = new TarArchiveInputStream(null);
                                                                                                                        
                                                                                                                        // Set the current entry using reflection since setCurrentEntry is protected
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Method setEntryMethod = TarArchiveInputStream.class
                                                                                                                                .getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                                            setEntryMethod.setAccessible(true);
                                                                                                                            setEntryMethod.invoke(tarInput, mockEntry);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to set current entry via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Call the method (using reflection since it's private)
                                                                                                                        try {
                                                                                                                            java.lang.reflect.Method method = TarArchiveInputStream.class
                                                                                                                                .getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                            method.setAccessible(true);
                                                                                                                            method.invoke(tarInput, headers);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to invoke method via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Verify the group ID was set (would fail with the mutant)
                                                                                                                        verify(mockEntry).setGroupId(123L);
                                                                                                                    }

    @Test
                                                                                                               public void testApplyPaxHeadersToCurrentEntry_HandlesLargeGroupId1() throws Exception {
                                                                                                                   // Create input stream with dummy data
                                                                                                                   InputStream inputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                                   TarArchiveInputStream tarInputStream = new TarArchiveInputStream(inputStream);
                                                                                                                   
                                                                                                                   // Create mock entry and set it as current entry
                                                                                                                   TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                                   Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                                   currEntryField.setAccessible(true);
                                                                                                                   currEntryField.set(tarInputStream, currEntry);
                                                                                                               
                                                                                                                   // Prepare test data with group ID larger than Integer.MAX_VALUE
                                                                                                                   Map<String, String> headers = new HashMap<>();
                                                                                                                   String largeGid = "3000000000"; // 3 billion > Integer.MAX_VALUE (2147483647)
                                                                                                                   headers.put("gid", largeGid);
                                                                                                                   
                                                                                                                   // Call the method under test
                                                                                                                   Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                                   method.setAccessible(true);
                                                                                                                   method.invoke(tarInputStream, headers);
                                                                                                                   
                                                                                                                   // Verify the group ID was set with the correct long value
                                                                                                                   verify(currEntry).setGroupId(3000000000L);
                                                                                                                   
                                                                                                                   // Additional verification that no other unexpected interactions occurred
                                                                                                                   verifyNoMoreInteractions(currEntry);
                                                                                                               }

    @Test
                                                                                                          public void testApplyPaxHeadersToCurrentEntry_DetectsGnameMutant1() throws Exception {
                                                                                                              // Create test data with a "gname" key that's a different String object
                                                                                                              Map<String, String> headers = new HashMap<>();
                                                                                                              String gnameKey = new String("gname"); // Different object than literal "gname"
                                                                                                              String expectedGroupName = "testgroup";
                                                                                                              headers.put(gnameKey, expectedGroupName);
                                                                                                              
                                                                                                              // Create mock TarArchiveEntry to verify behavior
                                                                                                              TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                              
                                                                                                              // Create instance
                                                                                                              TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                                              
                                                                                                              // Use reflection to access protected setCurrentEntry method
                                                                                                              Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                                              setCurrentEntryMethod.setAccessible(true);
                                                                                                              setCurrentEntryMethod.invoke(tarInput, currEntry);
                                                                                                              
                                                                                                              // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                                                              Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                              applyPaxHeadersMethod.setAccessible(true);
                                                                                                              applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                                              
                                                                                                              // Verify the group name was set - this will fail with the mutant
                                                                                                              verify(currEntry).setGroupName(expectedGroupName);
                                                                                                          }

    @Test
                                                                                                     public void testApplyPaxHeadersToCurrentEntry_GroupNameShouldBeSet() throws Exception {
                                                                                                         // Prepare test data
                                                                                                         String expectedGroupName = "testGroup";
                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                         headers.put("gname", expectedGroupName);
                                                                                                         
                                                                                                         // Create mock objects
                                                                                                         TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                         InputStream inputStream = mock(InputStream.class);
                                                                                                         
                                                                                                         // Create TarArchiveInputStream instance
                                                                                                         TarArchiveInputStream tarInputStream = new TarArchiveInputStream(inputStream);
                                                                                                         
                                                                                                         // Use reflection to set the current entry field
                                                                                                         Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                         currEntryField.setAccessible(true);
                                                                                                         currEntryField.set(tarInputStream, currEntry);
                                                                                                         
                                                                                                         // Call the method (using reflection since it's private)
                                                                                                         try {
                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                             method.setAccessible(true);
                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to invoke applyPaxHeadersToCurrentEntry: " + e.getMessage());
                                                                                                         }
                                                                                                         
                                                                                                         // Verify the group name was set with the correct value
                                                                                                         verify(currEntry).setGroupName(expectedGroupName);
                                                                                                         
                                                                                                         // The mutant would have called setGroupName("") instead,
                                                                                                         // so this verification would fail
                                                                                                     }

    @Test
                                                                                                     public void testApplyPaxHeadersToCurrentEntry_GroupNameShouldNotBeEmpty() throws Exception {
                                                                                                         // Prepare test data
                                                                                                         Map<String, String> headers = new HashMap<>();
                                                                                                         String expectedGroupName = "testGroup";
                                                                                                         headers.put("gname", expectedGroupName);
                                                                                                         
                                                                                                         // Create mock objects
                                                                                                         TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                                                                         InputStream inputStream = mock(InputStream.class);
                                                                                                         TarArchiveInputStream tarInputStream = new TarArchiveInputStream(inputStream);
                                                                                                         
                                                                                                         // Use reflection to set currentEntry field since it's private
                                                                                                         Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                         currEntryField.setAccessible(true);
                                                                                                         currEntryField.set(tarInputStream, currEntry);
                                                                                                         
                                                                                                         // Call the method (using reflection since it's private)
                                                                                                         try {
                                                                                                             Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                                 "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                             method.setAccessible(true);
                                                                                                             method.invoke(tarInputStream, headers);
                                                                                                         } catch (Exception e) {
                                                                                                             fail("Failed to invoke applyPaxHeadersToCurrentEntry: " + e.getMessage());
                                                                                                         }
                                                                                                         
                                                                                                         // Verify the group name was not set to empty string
                                                                                                         verify(currEntry, never()).setGroupName("");
                                                                                                     }

    @Test
                                                                                                public void testApplyPaxHeadersToCurrentEntry_GroupName() throws Exception {
                                                                                                    // Prepare test data
                                                                                                    Map<String, String> headers = new HashMap<>();
                                                                                                    String groupName = "testGroup";
                                                                                                    headers.put("gname", groupName);
                                                                                                    
                                                                                                    // Create mock objects
                                                                                                    InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                                    TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                                    TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                                                    
                                                                                                    // Use reflection to set current entry since it's protected
                                                                                                    Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                                    currentEntryField.setAccessible(true);
                                                                                                    currentEntryField.set(tarInputStream, mockEntry);
                                                                                                    
                                                                                                    // Call the method
                                                                                                    Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                                        "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                                    applyPaxHeadersMethod.setAccessible(true);
                                                                                                    applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                                                                    
                                                                                                    // Verify the correct method was called
                                                                                                    verify(mockEntry).setGroupName(groupName);
                                                                                                    // Ensure setUserName was NOT called with this value
                                                                                                    verify(mockEntry, never()).setUserName(groupName);
                                                                                                }

    @Test
                                                                                           public void testApplyPaxHeadersToCurrentEntry_uidWithDifferentStringObject() throws Exception {
                                                                                               // Setup
                                                                                               TarArchiveInputStream stream = new TarArchiveInputStream(mock(InputStream.class));
                                                                                               TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                               
                                                                                               // Use reflection to call protected setCurrentEntry method
                                                                                               Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                               setCurrentEntryMethod.setAccessible(true);
                                                                                               setCurrentEntryMethod.invoke(stream, entry);
                                                                                               
                                                                                               // Create headers with "uid" as a different String object
                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                               String uidKey = new String("uid"); // Different object than literal "uid"
                                                                                               headers.put(uidKey, "1234");
                                                                                               
                                                                                               // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                               Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                               applyPaxHeadersMethod.setAccessible(true);
                                                                                               applyPaxHeadersMethod.invoke(stream, headers);
                                                                                               
                                                                                               // Verify - original would set userId, mutant would skip
                                                                                               verify(entry).setUserId(1234L);
                                                                                           }

    @Test
                                                                                           public void testApplyPaxHeadersToCurrentEntry_uidWithLiteralString() throws Exception {
                                                                                               // Setup
                                                                                               TarArchiveInputStream stream = new TarArchiveInputStream(mock(InputStream.class));
                                                                                               TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                                               
                                                                                               // Use reflection to call protected setCurrentEntry method
                                                                                               Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                                               setCurrentEntryMethod.setAccessible(true);
                                                                                               setCurrentEntryMethod.invoke(stream, entry);
                                                                                               
                                                                                               // Create headers with literal "uid" string
                                                                                               Map<String, String> headers = new HashMap<>();
                                                                                               headers.put("uid", "5678");
                                                                                               
                                                                                               // Use reflection to call private applyPaxHeadersToCurrentEntry method
                                                                                               Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                               applyPaxHeadersMethod.setAccessible(true);
                                                                                               applyPaxHeadersMethod.invoke(stream, headers);
                                                                                               
                                                                                               // Verify - both original and mutant would work in this case
                                                                                               verify(entry).setUserId(5678L);
                                                                                           }

    @Test
                                                                                      public void testApplyPaxHeadersToCurrentEntry_ShouldSetUserId_WhenUidHeaderPresent1() throws Exception {
                                                                                          // Prepare test data
                                                                                          Map<String, String> headers = new HashMap<>();
                                                                                          String testUid = "1001";
                                                                                          headers.put("uid", testUid);
                                                                                          
                                                                                          // Create mock objects
                                                                                          InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                                                                          TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                                                          TarArchiveEntry mockEntry = new TarArchiveEntry("test");
                                                                                          
                                                                                          // Use reflection to set private fields if needed
                                                                                          Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                                                          currentEntryField.setAccessible(true);
                                                                                          currentEntryField.set(tarInputStream, mockEntry);
                                                                                          
                                                                                          // Call the method under test
                                                                                          Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                                          method.setAccessible(true);
                                                                                          method.invoke(tarInputStream, headers);
                                                                                          
                                                                                          // Verify the behavior
                                                                                          verify(mockEntry).setUserId(Long.parseLong(testUid));
                                                                                      }

    @Test
                                                                                 public void testApplyPaxHeadersToCurrentEntry_UserId() throws Exception {
                                                                                     // Setup
                                                                                     TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                     TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                     
                                                                                     // Use reflection to access protected setCurrentEntry method
                                                                                     Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                         "setCurrentEntry", TarArchiveEntry.class);
                                                                                     setCurrentEntryMethod.setAccessible(true);
                                                                                     setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                     
                                                                                     // Create headers with a non-zero uid value
                                                                                     Map<String, String> headers = new HashMap<>();
                                                                                     headers.put("uid", "1234");  // Non-zero user ID
                                                                                     
                                                                                     // Call method under test
                                                                                     Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                         "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                     method.setAccessible(true);
                                                                                     method.invoke(tarInput, headers);
                                                                                     
                                                                                     // Verify the user ID was set correctly
                                                                                     assertEquals("User ID should be set from header value", 
                                                                                         1234L, entry.getUserId());
                                                                                     
                                                                                     // Additional verification that other fields weren't affected
                                                                                     assertEquals("test", entry.getName());  // Verify default name wasn't changed
                                                                                 }

    @Test
                                                                            public void testApplyPaxHeadersToCurrentEntry_HandlesLargeUid() throws Exception {
                                                                                // Setup
                                                                                TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                                TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                                
                                                                                // Use reflection to access protected setCurrentEntry method
                                                                                Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                    "setCurrentEntry", TarArchiveEntry.class);
                                                                                setCurrentEntryMethod.setAccessible(true);
                                                                                setCurrentEntryMethod.invoke(tarInput, entry);
                                                                                
                                                                                // Create headers with a uid larger than Integer.MAX_VALUE
                                                                                Map<String, String> headers = new HashMap<>();
                                                                                long largeUid = 2147483648L; // Integer.MAX_VALUE + 1
                                                                                headers.put("uid", String.valueOf(largeUid));
                                                                                
                                                                                // Execute
                                                                                Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                                                    "applyPaxHeadersToCurrentEntry", Map.class);
                                                                                applyPaxHeadersMethod.setAccessible(true);
                                                                                applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                                
                                                                                // Verify
                                                                                assertEquals("User ID should handle values larger than Integer.MAX_VALUE", 
                                                                                    largeUid, entry.getUserId());
                                                                                
                                                                                // Cleanup
                                                                                setCurrentEntryMethod.setAccessible(false);
                                                                                applyPaxHeadersMethod.setAccessible(false);
                                                                            }

    @Test
                                                                       public void testApplyPaxHeadersToCurrentEntry_DetectUnameStringComparisonMutant() {
                                                                           // Create test data with a new String instance for "uname" key
                                                                           Map<String, String> headers = new HashMap<>();
                                                                           headers.put(new String("uname"), "testuser"); // Different String instance
                                                                           
                                                                           // Create mock entry to verify behavior
                                                                           TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                           
                                                                           // Create instance
                                                                           TarArchiveInputStream tarInput = new TarArchiveInputStream(null);
                                                                           
                                                                           // Use reflection to set current entry since setCurrentEntry is protected
                                                                           try {
                                                                               java.lang.reflect.Method setCurrentEntryMethod = TarArchiveInputStream.class
                                                                                   .getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                               setCurrentEntryMethod.setAccessible(true);
                                                                               setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                           } catch (Exception e) {
                                                                               fail("Failed to set current entry via reflection: " + e.getMessage());
                                                                           }
                                                                           
                                                                           // Call the method (using reflection since it's private)
                                                                           try {
                                                                               java.lang.reflect.Method method = TarArchiveInputStream.class
                                                                                   .getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                               method.setAccessible(true);
                                                                               method.invoke(tarInput, headers);
                                                                           } catch (Exception e) {
                                                                               fail("Failed to invoke method via reflection: " + e.getMessage());
                                                                           }
                                                                           
                                                                           // Verify the userName was set - this will fail with the mutant
                                                                           verify(mockEntry).setUserName("testuser");
                                                                       }

    @Test
                                                                  public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetUserNameForNonUnameKey1() throws Exception {
                                                                      // Setup
                                                                      TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                      TarArchiveEntry entry = new TarArchiveEntry("test");
                                                                      
                                                                      // Use reflection to access protected setCurrentEntry method
                                                                      Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                      setCurrentEntry.setAccessible(true);
                                                                      setCurrentEntry.invoke(tarInput, entry);
                                                                      
                                                                      // Create headers with a key that should NOT set user name
                                                                      Map<String, String> headers = new HashMap<>();
                                                                      headers.put("someOtherKey", "wrongUserName");
                                                                      
                                                                      // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                      Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                      applyPaxHeaders.setAccessible(true);
                                                                      applyPaxHeaders.invoke(tarInput, headers);
                                                                      
                                                                      // Verify
                                                                      // Original behavior: userName should remain null since key wasn't "uname"
                                                                      // Mutant behavior: userName would be set to "wrongUserName" because condition is always true
                                                                      assertNull("UserName should not be set for non-uname keys", entry.getUserName());
                                                                      
                                                                      // Additional verification that other properties weren't affected
                                                                      assertEquals("test", entry.getName());
                                                                      assertNull(entry.getLinkName());
                                                                      assertEquals(0, entry.getGroupId());
                                                                      assertNull(entry.getGroupName());
                                                                      assertEquals(0, entry.getUserId());
                                                                      assertEquals(0, entry.getSize());
                                                                      assertEquals(0, entry.getModTime());
                                                                      assertEquals(0, entry.getDevMinor());
                                                                      assertEquals(0, entry.getDevMajor());
                                                                  }

    @Test
                                                             public void testApplyPaxHeadersToCurrentEntry_ShouldHandleDifferentStringInstanceForLinkpath() throws Exception {
                                                                 // Create test data with a different String instance for "linkpath"
                                                                 Map<String, String> headers = new HashMap<>();
                                                                 String linkpathKey = new String("linkpath"); // Different instance
                                                                 String linkpathValue = "testLink";
                                                                 headers.put(linkpathKey, linkpathValue);
                                                                 
                                                                 // Create mock entry
                                                                 TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                                 
                                                                 // Create instance
                                                                 TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                                                 
                                                                 // Use reflection to access protected setCurrentEntry method
                                                                 Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                                 setCurrentEntryMethod.setAccessible(true);
                                                                 setCurrentEntryMethod.invoke(tarInput, mockEntry);
                                                                 
                                                                 // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                                 Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                                 applyPaxHeadersMethod.setAccessible(true);
                                                                 applyPaxHeadersMethod.invoke(tarInput, headers);
                                                                 
                                                                 // Verify the link name was set - this would fail with the mutant
                                                                 verify(mockEntry).setLinkName(linkpathValue);
                                                             }

    @Test
                                                        public void testApplyPaxHeadersToCurrentEntry_DetectsGidStringComparisonMutant2() throws Exception {
                                                            // Create a new String object with same content as "gid" but different reference
                                                            String gidKey = new String("gid");
                                                            
                                                            // Create test headers with the special gid key
                                                            Map<String, String> headers = new HashMap<>();
                                                            headers.put(gidKey, "12345");  // Using our special key
                                                            
                                                            // Mock the current entry
                                                            TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                                                            
                                                            // Create instance
                                                            TarArchiveInputStream stream = new TarArchiveInputStream(mock(InputStream.class));
                                                            
                                                            // Use reflection to access protected setCurrentEntry method
                                                            Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                                                            setCurrentEntryMethod.setAccessible(true);
                                                            setCurrentEntryMethod.invoke(stream, currEntry);
                                                            
                                                            // Use reflection to access private applyPaxHeadersToCurrentEntry method
                                                            Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                                            applyPaxHeadersMethod.setAccessible(true);
                                                            applyPaxHeadersMethod.invoke(stream, headers);
                                                            
                                                            // Verify the group ID was set - this will fail for the mutant
                                                            verify(currEntry).setGroupId(12345L);
                                                            
                                                            // Additional verification that no other unexpected interactions occurred
                                                            verifyNoMoreInteractions(currEntry);
                                                        }

    @Test
                                               public void testApplyPaxHeadersToCurrentEntry_HandlesLargeGid() throws Exception {
                                                   // Create mock objects
                                                   InputStream mockInputStream = mock(InputStream.class);
                                                   TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                                   
                                                   // Create real TarArchiveInputStream with mock input stream
                                                   TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                                   
                                                   // Use reflection to set the current entry since setCurrentEntry is protected
                                                   Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                                   currentEntryField.setAccessible(true);
                                                   currentEntryField.set(tarInputStream, mockEntry);
                                                   
                                                   // Prepare test data with gid larger than Integer.MAX_VALUE
                                                   Map<String, String> headers = new HashMap<>();
                                                   long largeGid = 2147483648L; // Integer.MAX_VALUE + 1
                                                   headers.put("gid", String.valueOf(largeGid));
                                                   
                                                   // Use reflection to access the private method
                                                   Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                                       "applyPaxHeadersToCurrentEntry", Map.class);
                                                   applyPaxHeadersMethod.setAccessible(true);
                                                   
                                                   // Call the method via reflection
                                                   applyPaxHeadersMethod.invoke(tarInputStream, headers);
                                                   
                                                   // Verify the entry's group ID was set with the correct long value
                                                   verify(mockEntry).setGroupId(largeGid);
                                                   
                                                   // Additional verification that no other unexpected interactions occurred
                                                   verifyNoMoreInteractions(mockEntry);
                                               }

    @Test
                                          public void testApplyPaxHeadersToCurrentEntry_DetectsGnameMutant2() throws Exception {
                                              // Initialize required objects
                                              InputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
                                              TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                              TarArchiveEntry currEntry = new TarArchiveEntry("testEntry");
                                              
                                              // Use reflection to set the current entry field
                                              Field currEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                              currEntryField.setAccessible(true);
                                              currEntryField.set(tarInputStream, currEntry);
                                              
                                              // Prepare test data with a different String object for "gname"
                                              Map<String, String> headers = new HashMap<>();
                                              String gnameKey = new String("gname"); // Different object, same content
                                              String groupName = "testgroup";
                                              headers.put(gnameKey, groupName);
                                              
                                              // Get the private method via reflection
                                              Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                                  "applyPaxHeadersToCurrentEntry", Map.class);
                                              method.setAccessible(true);
                                              
                                              // Execute the method
                                              method.invoke(tarInputStream, headers);
                                              
                                              // Verify the behavior - should call setGroupName with the test value
                                              assertEquals(groupName, currEntry.getGroupName());
                                              
                                              // Also verify no other headers were processed (since we only had gname)
                                              // This is implicit in the assertEquals above since we're not testing other fields
                                          }

    @Test
                                     public void testApplyPaxHeadersToCurrentEntry_GroupNameShouldBeSet1() throws Exception {
                                         // Setup
                                         TarArchiveInputStream stream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                                         TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                         
                                         // Use reflection to access protected setCurrentEntry method
                                         Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                             "setCurrentEntry", TarArchiveEntry.class);
                                         setCurrentEntryMethod.setAccessible(true);
                                         setCurrentEntryMethod.invoke(stream, mockEntry);
                                         
                                         Map<String, String> headers = new HashMap<>();
                                         String expectedGroupName = "testGroup";
                                         headers.put("gname", expectedGroupName);
                                         
                                         // Execute
                                         // Using reflection to access private method since it's not public
                                         Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                             "applyPaxHeadersToCurrentEntry", Map.class);
                                         method.setAccessible(true);
                                         method.invoke(stream, headers);
                                         
                                         // Verify
                                         verify(mockEntry).setGroupName(expectedGroupName);  // This will fail if mutant is present
                                     }

    @Test
                                public void testApplyPaxHeadersToCurrentEntry_ShouldSetGroupNameWhenGnameHeaderPresent() throws Exception {
                                    // Prepare test data
                                    Map<String, String> headers = new HashMap<>();
                                    String expectedGroupName = "testGroup";
                                    headers.put("gname", expectedGroupName);
                                    
                                    // Create mock objects
                                    InputStream mockInputStream = mock(InputStream.class);
                                    TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                                    TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                                    
                                    // Use reflection to set the currentEntry field since it's protected
                                    Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                                    currentEntryField.setAccessible(true);
                                    currentEntryField.set(tarInputStream, mockEntry);
                                    
                                    // Call the method under test
                                    Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                                    method.setAccessible(true);
                                    method.invoke(tarInputStream, headers);
                                    
                                    // Verify the correct method was called with expected value
                                    verify(mockEntry).setGroupName(expectedGroupName);
                                    // Ensure setUserName was NOT called with this value (to catch the mutant)
                                    verify(mockEntry, never()).setUserName(expectedGroupName);
                                }

    @Test
                           public void testApplyPaxHeadersToCurrentEntry_DetectsUidStringComparisonMutant1() {
                               // Create test data with "uid" key that's a different string instance
                               Map<String, String> headers = new HashMap<>();
                               headers.put(new String("uid"), "123"); // Force new string instance
                               
                               // Create mock entry to verify interactions
                               TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                               
                               // Create test instance
                               TarArchiveInputStream tarInput = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
                               
                               // Set current entry using reflection since it's protected
                               try {
                                   Method setCurrentEntryMethod = TarArchiveInputStream.class.getDeclaredMethod(
                                       "setCurrentEntry", TarArchiveEntry.class);
                                   setCurrentEntryMethod.setAccessible(true);
                                   setCurrentEntryMethod.invoke(tarInput, mockEntry);
                               } catch (Exception e) {
                                   fail("Failed to set current entry via reflection: " + e.getMessage());
                               }
                               
                               // Call the method (using reflection since it's private)
                               try {
                                   Method method = TarArchiveInputStream.class.getDeclaredMethod(
                                       "applyPaxHeadersToCurrentEntry", Map.class);
                                   method.setAccessible(true);
                                   method.invoke(tarInput, headers);
                               } catch (Exception e) {
                                   fail("Failed to invoke method via reflection: " + e.getMessage());
                               }
                               
                               // Verify the userId was set (would fail with == comparison)
                               verify(mockEntry).setUserId(123L);
                               
                               // Also verify no other unexpected interactions
                               verifyNoMoreInteractions(mockEntry);
                           }

    @Test(expected = NumberFormatException.class)
                           public void testMutantFailsWithLargeUserId() {
                               // This test simulates the mutant behavior and expects it to fail
                               // Normally we wouldn't include this in production tests,
                               // but it demonstrates how the mutant would behave
                               
                               // Prepare test data with a user ID exceeding Integer.MAX_VALUE
                               Map<String, String> headers = new HashMap<>();
                               long largeUserId = Integer.MAX_VALUE + 1L;
                               headers.put("uid", String.valueOf(largeUserId));
                               
                               // Simulate the mutant behavior
                               try {
                                   // This is what the mutant would do
                                   Integer.parseInt(String.valueOf(largeUserId));
                                   fail("Mutant should have thrown NumberFormatException");
                               } catch (NumberFormatException e) {
                                   // This is expected for the mutant
                                   throw e;
                               }
                           }

    @Test
                  public void testApplyPaxHeadersToCurrentEntry_HandlesLargeUserId1() throws Exception {
                      // Create mock objects
                      InputStream mockInputStream = mock(InputStream.class);
                      TarArchiveEntry mockEntry = mock(TarArchiveEntry.class);
                      
                      // Create real tarInputStream and inject mock entry using reflection
                      TarArchiveInputStream tarInputStream = new TarArchiveInputStream(mockInputStream);
                      Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
                      currentEntryField.setAccessible(true);
                      currentEntryField.set(tarInputStream, mockEntry);
                      
                      // Prepare test data with a user ID exceeding Integer.MAX_VALUE
                      Map<String, String> headers = new HashMap<String, String>();
                      long largeUserId = Integer.MAX_VALUE + 1L;
                      headers.put("uid", String.valueOf(largeUserId));
                      
                      // Get the private method using reflection and invoke it
                      Method applyPaxHeadersMethod = TarArchiveInputStream.class.getDeclaredMethod(
                          "applyPaxHeadersToCurrentEntry", Map.class);
                      applyPaxHeadersMethod.setAccessible(true);
                      applyPaxHeadersMethod.invoke(tarInputStream, headers);
                      
                      // Verify the correct behavior:
                      // Original code should call setUserId with the long value
                      // Mutant would throw NumberFormatException
                      verify(mockEntry).setUserId(largeUserId);
                      
                      // Also verify no other unexpected interactions
                      verifyNoMoreInteractions(mockEntry);
                  }

    @Test
             public void testApplyPaxHeadersToCurrentEntry_DetectsUnameStringComparisonMutant1() throws Exception {
                 // Create test data with a "uname" key that's a different String object
                 Map<String, String> headers = new HashMap<>();
                 headers.put(new String("uname"), "testuser"); // Different String object
                 
                 // Mock the current entry
                 TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
                 
                 // Create instance
                 TarArchiveInputStream tarInput = new TarArchiveInputStream(mock(InputStream.class));
                 
                 // Use reflection to access protected setCurrentEntry method
                 Method setCurrentEntry = TarArchiveInputStream.class.getDeclaredMethod("setCurrentEntry", TarArchiveEntry.class);
                 setCurrentEntry.setAccessible(true);
                 setCurrentEntry.invoke(tarInput, currEntry);
                 
                 // Use reflection to access private applyPaxHeadersToCurrentEntry method
                 Method applyPaxHeaders = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
                 applyPaxHeaders.setAccessible(true);
                 applyPaxHeaders.invoke(tarInput, headers);
                 
                 // Verify the userName was set - this will fail with the mutant
                 verify(currEntry).setUserName("testuser");
             }

    @Test
    public void testApplyPaxHeadersToCurrentEntry_ShouldNotSetUserNameForNonUnameKeys() {
        // Arrange
        Map<String, String> headers = new HashMap<>();
        headers.put("some_random_key", "should_not_be_username");
        headers.put("uname", "correct_username");
        
        TarArchiveInputStream tarInputStream = new TarArchiveInputStream(new ByteArrayInputStream(new byte[0]));
        TarArchiveEntry currEntry = mock(TarArchiveEntry.class);
        
        // Use reflection to set the currentEntry field since it's protected
        try {
            Field currentEntryField = TarArchiveInputStream.class.getDeclaredField("currEntry");
            currentEntryField.setAccessible(true);
            currentEntryField.set(tarInputStream, currEntry);
        } catch (Exception e) {
            fail("Failed to set current entry via reflection");
        }
        
        // Act - Use reflection to access the private method
        try {
            Method method = TarArchiveInputStream.class.getDeclaredMethod("applyPaxHeadersToCurrentEntry", Map.class);
            method.setAccessible(true);
            method.invoke(tarInputStream, headers);
        } catch (Exception e) {
            fail("Failed to invoke applyPaxHeadersToCurrentEntry via reflection");
        }
        
        // Assert
        // Verify that setUserName was called exactly once with the correct value
        verify(currEntry, times(1)).setUserName("correct_username");
        // Verify that setUserName was never called with the random key's value
        verify(currEntry, never()).setUserName("should_not_be_username");
        
        // Additional verification that other set methods weren't affected
        verify(currEntry, never()).setName(anyString());
        verify(currEntry, never()).setLinkName(anyString());
        verify(currEntry, never()).setGroupId(anyLong());
        verify(currEntry, never()).setGroupName(anyString());
        verify(currEntry, never()).setUserId(anyLong());
        verify(currEntry, never()).setSize(anyLong());
        verify(currEntry, never()).setModTime(anyLong());
        verify(currEntry, never()).setDevMinor(anyInt());
        verify(currEntry, never()).setDevMajor(anyInt());
    }


}
