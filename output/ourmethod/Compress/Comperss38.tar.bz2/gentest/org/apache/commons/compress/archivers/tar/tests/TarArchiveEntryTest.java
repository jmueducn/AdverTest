package gentest.org.apache.commons.compress.archivers.tar.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.tar.*;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.utils.ArchiveUtils;
 
public class TarArchiveEntryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                            public void testIsDirectory_FileIsDirectory() {
                                                                                                                File mockFile = mock(File.class);
                                                                                                                when(mockFile.isDirectory()).thenReturn(true);
                                                                                                                
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testDir/");
                                                                                                                assertTrue(entry.isDirectory());
                                                                                                                
                                                                                                                verify(mockFile).isDirectory();
                                                                                                            }

 @Test
                                                                                                            public void testIsDirectory_FileIsNotDirectory() {
                                                                                                                File mockFile = mock(File.class);
                                                                                                                when(mockFile.isDirectory()).thenReturn(false);
                                                                                                                
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry(mockFile, "testFile");
                                                                                                                assertFalse(entry.isDirectory());
                                                                                                                
                                                                                                                verify(mockFile).isDirectory();
                                                                                                            }

 @Test
                                                                                                            public void testIsDirectory_NameEndsWithSlash() {
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                                                                                                // Mock isPaxHeader and isGlobalPaxHeader to return false
                                                                                                                when(entry.isPaxHeader()).thenReturn(false);
                                                                                                                when(entry.isGlobalPaxHeader()).thenReturn(false);
                                                                                                                
                                                                                                                assertTrue(entry.isDirectory());
                                                                                                            }

 @Test
                                                                                                            public void testIsDirectory_NameEndsWithSlashButPaxHeader() {
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                                                                                                // Mock isPaxHeader to return true
                                                                                                                when(entry.isPaxHeader()).thenReturn(true);
                                                                                                                
                                                                                                                assertFalse(entry.isDirectory());
                                                                                                            }

 @Test
                                                                                                            public void testIsDirectory_NoneOfConditionsMet() {
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry("testFile");
                                                                                                                // Mock isPaxHeader and isGlobalPaxHeader to return false
                                                                                                                when(entry.isPaxHeader()).thenReturn(false);
                                                                                                                when(entry.isGlobalPaxHeader()).thenReturn(false);
                                                                                                                
                                                                                                                assertFalse(entry.isDirectory());
                                                                                                            }

 @Test
                                                                                                            public void testConstructorWithDirectoryFile() {
                                                                                                                File mockDir = mock(File.class);
                                                                                                                when(mockDir.isDirectory()).thenReturn(true);
                                                                                                                when(mockDir.getPath()).thenReturn("testDir");
                                                                                                                when(mockDir.lastModified()).thenReturn(System.currentTimeMillis());
                                                                                                                
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry(mockDir);
                                                                                                                assertTrue(entry.isDirectory());
                                                                                                            }

 @Test
                                                                                                            public void testConstructorWithNonDirectoryFile() {
                                                                                                                File mockFile = mock(File.class);
                                                                                                                when(mockFile.isDirectory()).thenReturn(false);
                                                                                                                when(mockFile.getPath()).thenReturn("testFile");
                                                                                                                when(mockFile.length()).thenReturn(1024L);
                                                                                                                when(mockFile.lastModified()).thenReturn(System.currentTimeMillis());
                                                                                                                
                                                                                                                TarArchiveEntry entry = new TarArchiveEntry(mockFile);
                                                                                                                assertFalse(entry.isDirectory());
                                                                                                            }

 @Test
                                                                                                    public void testIsDirectory_LinkFlagIsDir() {
                                                                                                        TarArchiveEntry entry = new TarArchiveEntry("testDir/");
                                                                                                        // Define LF_DIR constant value (typically 53 for directories in tar format)
                                                                                                        final byte LF_DIR = 53;
                                                                                                        
                                                                                                        // Use reflection to set private field since there's no setter
                                                                                                        try {
                                                                                                            java.lang.reflect.Field field = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                                                                            field.setAccessible(true);
                                                                                                            field.set(entry, LF_DIR);
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to set linkFlag via reflection");
                                                                                                        }
                                                                                                        
                                                                                                        assertTrue(entry.isDirectory());
                                                                                                    }

 @Test
                                                                                           public void testIsDirectoryWithLinkFlag() {
                                                                                               // Define link flag constants since they're not directly accessible
                                                                                               byte LF_DIR = 5;      // Directory type flag
                                                                                               byte LF_NORMAL = 0;   // Normal file type flag
                                                                                               byte LF_LINK = 1;     // Hard link type flag
                                                                                               byte LF_SYMLINK = 2;  // Symbolic link type flag
                                                                                               
                                                                                               // Create entry with LF_DIR - should return true in original
                                                                                               TarArchiveEntry dirEntry = new TarArchiveEntry("testEntry", LF_DIR);
                                                                                               assertTrue("Entry with LF_DIR should be directory", dirEntry.isDirectory());
                                                                                               
                                                                                               // Create entry with LF_NORMAL - should return false in original
                                                                                               TarArchiveEntry normalEntry = new TarArchiveEntry("testEntry", LF_NORMAL);
                                                                                               assertFalse("Entry with LF_NORMAL should not be directory", normalEntry.isDirectory());
                                                                                               
                                                                                               // Create entry with LF_LINK - should return false in original
                                                                                               TarArchiveEntry linkEntry = new TarArchiveEntry("testEntry", LF_LINK);
                                                                                               assertFalse("Entry with LF_LINK should not be directory", linkEntry.isDirectory());
                                                                                               
                                                                                               // Create entry with LF_SYMLINK - should return false in original
                                                                                               TarArchiveEntry symlinkEntry = new TarArchiveEntry("testEntry", LF_SYMLINK);
                                                                                               assertFalse("Entry with LF_SYMLINK should not be directory", symlinkEntry.isDirectory());
                                                                                           }

 @Test
                                                                                  public void testIsDirectoryWithNonDirLinkFlagShouldReturnFalse() {
                                                                                      // Create entry with non-directory link flag
                                                                                      byte nonDirLinkFlag = (byte) '0'; // '0' represents LF_NORMAL in TarConstants
                                                                                      String name = "testFile";
                                                                                      TarArchiveEntry entry = new TarArchiveEntry(name, nonDirLinkFlag);
                                                                                      
                                                                                      // Ensure conditions:
                                                                                      // - file is null (default in this constructor)
                                                                                      // - name doesn't end with "/"
                                                                                      assertNull("File should be null", entry.getFile());
                                                                                      assertFalse("Name should not end with /", entry.getName().endsWith("/"));
                                                                                      
                                                                                      // Verify isDirectory returns false for non-directory link flag
                                                                                      assertFalse("Should return false for non-directory link flag", 
                                                                                                 entry.isDirectory());
                                                                                  }

 @Test
                                                                             public void testIsDirectoryWithLinkFlagDir() {
                                                                                 // Define directory link flag (byte value for directory in tar format)
                                                                                 byte LF_DIR = 53;
                                                                                 
                                                                                 // Create entry with directory link flag and null file
                                                                                 TarArchiveEntry entry = new TarArchiveEntry("testEntry", LF_DIR);
                                                                                 
                                                                                 // Set name to not end with "/" to ensure we test the linkFlag path
                                                                                 entry.setName("testEntry");
                                                                                 
                                                                                 // Original behavior should return true, mutant will return false
                                                                                 assertTrue("Entry with LF_DIR should be recognized as directory", 
                                                                                            entry.isDirectory());
                                                                             }

 @Test
                                                                             public void testIsDirectoryWhenLinkFlagIsDir() {
                                                                                 // Create entry with null file and directory link flag
                                                                                 TarArchiveEntry entry = new TarArchiveEntry("testEntry", TarArchiveEntry.LF_DIR);
                                                                                 
                                                                                 // Mock getName() to return name without trailing slash
                                                                                 TarArchiveEntry spyEntry = spy(entry);
                                                                                 when(spyEntry.getName()).thenReturn("testEntry");
                                                                                 when(spyEntry.isPaxHeader()).thenReturn(false);
                                                                                 when(spyEntry.isGlobalPaxHeader()).thenReturn(false);
                                                                                 
                                                                                 // Verify isDirectory returns true for directory link flag
                                                                                 assertTrue("Should return true for directory link flag", spyEntry.isDirectory());
                                                                             }

 @Test
                                                                   public void testIsDirectoryWithLinkFlagLF_DIRShouldReturnTrue() {
                                                                       // Setup
                                                                       byte LF_DIR = 5; // This is the standard value for directory type in tar format
                                                                       TarArchiveEntry entry = new TarArchiveEntry("testEntry", LF_DIR);
                                                                       
                                                                       // Mock getName() to return a name without trailing slash
                                                                       TarArchiveEntry spyEntry = spy(entry);
                                                                       when(spyEntry.getName()).thenReturn("testName");
                                                                       when(spyEntry.isPaxHeader()).thenReturn(false);
                                                                       when(spyEntry.isGlobalPaxHeader()).thenReturn(false);
                                                                       
                                                                       // Test - should return true immediately for original, would recurse for mutant
                                                                       boolean result = spyEntry.isDirectory();
                                                                       
                                                                       // Verify
                                                                       assertTrue("Should return true for LF_DIR linkFlag", result);
                                                                       
                                                                       // Additional verification that we didn't recurse
                                                                       verify(spyEntry, times(1)).isDirectory();
                                                                       verify(spyEntry, times(1)).getName();
                                                                       verify(spyEntry, times(1)).isPaxHeader();
                                                                       verify(spyEntry, times(1)).isGlobalPaxHeader();
                                                                   }

 @Test
                                                               public void testIsDirectoryWithTrailingSlashAndNotPaxHeader() throws Exception {
                                                                   // Setup
                                                                   TarArchiveEntry entry = new TarArchiveEntry("testdir/");
                                                                   
                                                                   // Mock the behavior of isPaxHeader() and isGlobalPaxHeader()
                                                                   // Since we can't directly mock these methods (they're not virtual), 
                                                                   // we'll need to create an entry that we know will return false for these
                                                                   
                                                                   // For this test case, we need:
                                                                   // - file = null (handled by string constructor)
                                                                   // - linkFlag != LF_DIR (handled by string constructor for directory names)
                                                                   // - name ends with "/" (handled by constructor)
                                                                   // - isPaxHeader() returns false (default behavior)
                                                                   // - isGlobalPaxHeader() returns false (default behavior)
                                                                   
                                                                   // Verify the behavior
                                                                   assertTrue("Entry with trailing slash should be recognized as directory", 
                                                                              entry.isDirectory());
                                                                   
                                                                   // Additional verification that it's not a Pax header
                                                                   assertFalse("Should not be Pax header by default", entry.isPaxHeader());
                                                                   assertFalse("Should not be global Pax header by default", entry.isGlobalPaxHeader());
                                                                   
                                                                   // This test will fail if the mutant is present because:
                                                                   // Original: !isPaxHeader() && ... -> returns true
                                                                   // Mutant: isPaxHeader() && ... -> returns false
                                                               }

 @Test
                                                              public void testIsDirectoryWithSlashAndGlobalPaxHeader() throws Exception {
                                                                  // Setup
                                                                  TarArchiveEntry entry = new TarArchiveEntry("test/");
                                                                  
                                                                  // Mock the behavior of isPaxHeader and isGlobalPaxHeader
                                                                  // Using reflection since we can't mock these directly
                                                                  Field isGlobalPaxHeaderField = TarArchiveEntry.class.getDeclaredField("isExtended");
                                                                  isGlobalPaxHeaderField.setAccessible(true);
                                                                  isGlobalPaxHeaderField.set(entry, true); // Set isGlobalPaxHeader to true
                                                                  
                                                                  Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                                  linkFlagField.setAccessible(true);
                                                                  linkFlagField.set(entry, (byte) 0); // Set linkFlag to something other than LF_DIR
                                                                  
                                                                  // The original should return true (name ends with "/" and neither is pax header)
                                                                  // The mutant will return false because isGlobalPaxHeader is true (making !isGlobalPaxHeader false)
                                                                  // but with OR condition, the whole expression could be false
                                                                  
                                                                  // Verify
                                                                  assertTrue("Should return true for directory ending with / when not pax headers", 
                                                                             entry.isDirectory());
                                                              }

 @Test
                                                             public void testIsDirectoryWithGlobalPaxHeaderAndTrailingSlash() throws Exception {
                                                                 // Setup test case that will expose the mutant
                                                                 TarArchiveEntry entry = new TarArchiveEntry("test/");
                                                                 
                                                                 // Mock the behavior of isPaxHeader and isGlobalPaxHeader
                                                                 // Using reflection since we can't mock the class under test
                                                                 Field isGlobalPaxHeaderField = TarArchiveEntry.class.getDeclaredField("paxGNUSparse");
                                                                 isGlobalPaxHeaderField.setAccessible(true);
                                                                 isGlobalPaxHeaderField.set(entry, true); // Simulate isGlobalPaxHeader() returning true
                                                                 
                                                                 Field isPaxHeaderField = TarArchiveEntry.class.getDeclaredField("isExtended");
                                                                 isPaxHeaderField.setAccessible(true);
                                                                 isPaxHeaderField.set(entry, false); // Simulate isPaxHeader() returning false
                                                                 
                                                                 // Set linkFlag to something other than LF_DIR
                                                                 Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                                 linkFlagField.setAccessible(true);
                                                                 linkFlagField.set(entry, (byte) 0); // LF_NORMAL
                                                                 
                                                                 // The original should return false in this case because isGlobalPaxHeader is true
                                                                 // The mutant would return true
                                                                 assertFalse("Should return false when isGlobalPaxHeader is true and name ends with /", 
                                                                            entry.isDirectory());
                                                             }

 @Test
                                                             public void testIsDirectoryWithGlobalPaxHeaderAndTrailingSlash1() throws Exception {
                                                                 // Create partial mock of TarArchiveEntry
                                                                 TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                                                 
                                                                 // Setup mock behavior
                                                                 when(entry.isDirectory()).thenCallRealMethod();
                                                                 when(entry.isPaxHeader()).thenReturn(false);
                                                                 when(entry.isGlobalPaxHeader()).thenReturn(true);
                                                                 when(entry.getName()).thenReturn("test/");
                                                                 when(entry.getFile()).thenReturn(null);
                                                                 
                                                                 // Set linkFlag to non-directory
                                                                 Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                                 linkFlagField.setAccessible(true);
                                                                 linkFlagField.set(entry, (byte) 0); // LF_NORMAL
                                                                 
                                                                 // Verify behavior
                                                                 assertFalse(entry.isDirectory());
                                                             }

 @Test
                                                           public void testIsDirectoryWithPaxHeaderAndSlashShouldReturnFalse() throws Exception {
                                                               // Setup
                                                               TarArchiveEntry entry = new TarArchiveEntry("test/");
                                                               
                                                               // Mock the Pax header methods to return true
                                                               when(entry.isPaxHeader()).thenReturn(true);
                                                               when(entry.isGlobalPaxHeader()).thenReturn(false);
                                                               
                                                               // Set the name to end with slash
                                                               when(entry.getName()).thenReturn("test/");
                                                               
                                                               // Define LF_NORMAL constant (value from TarConstants)
                                                               byte LF_NORMAL = 0;
                                                               
                                                               // Set linkFlag to not be a directory using reflection
                                                               Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                               linkFlagField.setAccessible(true);
                                                               linkFlagField.set(entry, LF_NORMAL);
                                                               
                                                               // Test - should return false because even though name ends with slash, it's a Pax header
                                                               assertFalse(entry.isDirectory());
                                                               
                                                               // Verify the mutation would have returned true incorrectly
                                                               // (This comment is just for explanation, not part of the test)
                                                           }

 @Test
                                                           public void testIsDirectoryWithNonPaxNonGlobalAndSlashReturnsTrue() throws Exception {
                                                               // Define the missing constant
                                                               byte LF_NORMAL = 0;
                                                               
                                                               TarArchiveEntry entry = new TarArchiveEntry("dir/");
                                                               when(entry.isPaxHeader()).thenReturn(false);
                                                               when(entry.isGlobalPaxHeader()).thenReturn(false);
                                                               when(entry.getName()).thenReturn("dir/");
                                                               
                                                               // Use reflection to set the private linkFlag field
                                                               Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                               linkFlagField.setAccessible(true);
                                                               linkFlagField.set(entry, LF_NORMAL);
                                                               
                                                               assertTrue(entry.isDirectory());  // Should be true for original and mutant
                                                           }

 @Test
                                                           public void testIsDirectoryWithNonPaxNonGlobalNoSlashReturnsFalse() throws Exception {
                                                               // Define the missing constant
                                                               byte LF_NORMAL = 0;
                                                               
                                                               TarArchiveEntry entry = new TarArchiveEntry("file");
                                                               when(entry.isPaxHeader()).thenReturn(false);
                                                               when(entry.isGlobalPaxHeader()).thenReturn(false);
                                                               when(entry.getName()).thenReturn("file");
                                                               
                                                               // Use reflection to set the private linkFlag field
                                                               Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                               linkFlagField.setAccessible(true);
                                                               linkFlagField.set(entry, LF_NORMAL);
                                                               
                                                               assertFalse(entry.isDirectory());  // Should be false for original and mutant
                                                           }

 @Test
                                                      public void testIsDirectoryWithNameEndingSlashShouldDetectMutant() {
                                                          // Setup - create entry with name ending in slash
                                                          TarArchiveEntry entry = new TarArchiveEntry("testdir/");
                                                          
                                                          // Set link flag to something other than LF_DIR (using reflection since LF_DIR might be private)
                                                          try {
                                                              Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                              linkFlagField.setAccessible(true);
                                                              linkFlagField.set(entry, (byte) 0); // Using 0 as non-directory flag
                                                          } catch (Exception e) {
                                                              fail("Failed to set linkFlag via reflection: " + e.getMessage());
                                                          }
                                                          
                                                          // The original should return true for directory ending with slash
                                                          // The mutant would return false here
                                                          assertTrue("Entry with name ending in / should be directory", entry.isDirectory());
                                                          
                                                          // Additional test case for name not ending with slash
                                                          TarArchiveEntry nonDirEntry = new TarArchiveEntry("testfile");
                                                          try {
                                                              Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                                              linkFlagField.setAccessible(true);
                                                              linkFlagField.set(nonDirEntry, (byte) 0); // Using 0 as non-directory flag
                                                          } catch (Exception e) {
                                                              fail("Failed to set linkFlag via reflection: " + e.getMessage());
                                                          }
                                                          
                                                          // The original should return false for name not ending with slash
                                                          // The mutant would return true here
                                                          assertFalse("Entry with name not ending in / should not be directory", 
                                                                     nonDirEntry.isDirectory());
                                                      }

 @Test
                                     public void testIsDirectoryWithPaxHeaderAndTrailingSlashShouldReturnFalse() throws Exception {
                                         // Setup - create entry with PAX header type ('x') and trailing slash
                                         TarArchiveEntry entry = new TarArchiveEntry("test/", (byte) 'x');
                                         
                                         // Verify the name ends with "/"
                                         assertTrue(entry.getName().endsWith("/"));
                                         
                                         // Verify it's a PAX header
                                         assertTrue(entry.isPaxHeader());
                                         
                                         // Test - should return false because it's a Pax header despite ending with "/"
                                         assertFalse(entry.isDirectory());
                                         
                                         // This test would fail with the mutant because the mutant ignores isPaxHeader() check
                                         // and would return true when name ends with "/"
                                     }

 @Test
                                 public void testIsDirectoryWithPaxHeaderAndTrailingSlashShouldReturnFalse1() throws Exception {
                                     // Setup - create entry with name and PAX header flag ('x')
                                     TarArchiveEntry entry = new TarArchiveEntry("test/", (byte) 'x');
                                     
                                     // Verify the name ends with "/"
                                     assertTrue(entry.getName().endsWith("/"));
                                     
                                     // Test - should return false because it's a Pax header despite ending with "/"
                                     assertFalse(entry.isDirectory());
                                     
                                     // This test would fail with the mutant because the mutant ignores isPaxHeader() check
                                     // and would return true when name ends with "/"
                                 }

 @Test
                            public void testIsDirectoryWithGlobalPaxHeaderAndTrailingSlash2() throws Exception {
                                // Setup
                                String name = "test/";
                                byte linkFlag = (byte) '0'; // LF_NORMAL is typically '0' for regular files in tar
                                
                                // Create entry with name ending in "/" and mock it to be a global Pax header
                                TarArchiveEntry entry = new TarArchiveEntry(name, linkFlag);
                                
                                // Mock the isGlobalPaxHeader() to return true
                                // Since we can't directly mock the method, we'll use reflection to set up the state
                                Field nameField = TarArchiveEntry.class.getDeclaredField("name");
                                nameField.setAccessible(true);
                                nameField.set(entry, name);
                                
                                // Using reflection to mock these methods isn't straightforward, so we'll create
                                // a subclass that overrides these methods for testing
                                TarArchiveEntry testEntry = new TarArchiveEntry(name, linkFlag) {
                                    @Override
                                    public boolean isPaxHeader() {
                                        return false;
                                    }
                                    
                                    @Override
                                    public boolean isGlobalPaxHeader() {
                                        return true;
                                    }
                                };
                                
                                // Test - should return false because it's a global Pax header
                                assertFalse(testEntry.isDirectory());
                                
                                // With the mutant, this would return true because the global Pax check is bypassed
                            }

 @Test
                            public void testIsDirectoryWithGlobalPaxHeaderAndTrailingSlash3() throws Exception {
                                // Setup
                                String name = "test/";
                                byte linkFlag = (byte) '0'; // LF_NORMAL is '0' in TarArchiveEntry
                                
                                // Create a partial mock of TarArchiveEntry
                                TarArchiveEntry entry = mock(TarArchiveEntry.class);
                                
                                // Setup the mock behavior
                                when(entry.isDirectory()).thenCallRealMethod();
                                when(entry.getName()).thenReturn(name);
                                when(entry.isPaxHeader()).thenReturn(false);
                                when(entry.isGlobalPaxHeader()).thenReturn(true);
                                
                                // Set the linkFlag field
                                Field linkFlagField = TarArchiveEntry.class.getDeclaredField("linkFlag");
                                linkFlagField.setAccessible(true);
                                linkFlagField.set(entry, linkFlag);
                                
                                // Set file to null
                                Field fileField = TarArchiveEntry.class.getDeclaredField("file");
                                fileField.setAccessible(true);
                                fileField.set(entry, null);
                                
                                // Test - should return false because it's a global Pax header
                                assertFalse(entry.isDirectory());
                            }

 @Test
                       public void testIsDirectory_NonPaxNonSlashEndingName_ShouldReturnFalse() throws Exception {
                           // Setup
                           TarArchiveEntry entry = new TarArchiveEntry("testEntry", (byte) 0); // Use constructor with linkFlag
                           
                           // Use reflection to set private fields if needed
                           // Set name directly since setName is public
                           entry.setName("testEntry");
                           
                           // Mock behavior for methods that would be called
                           // Since we can't mock a real object, we need to ensure the real implementation
                           // returns the values we want by setting up the object state appropriately
                           
                           // For isPaxHeader() and isGlobalPaxHeader(), these will return false by default
                           // as we're not creating a PAX header entry
                           
                           // Test
                           boolean result = entry.isDirectory();
                           
                           // Verify
                           assertFalse("Should return false for non-directory entry without trailing slash", result);
                       }

 @Test
                  public void testIsDirectoryWhenLinkFlagIsDirAndFileIsNull() {
                      // Setup
                      String entryName = "testDir/";
                      // Define LF_DIR constant (value from TarConstants)
                      byte linkFlag = (byte) '5'; // '5' is the standard value for directory type in tar
                      
                      // Create entry with directory link flag and null file
                      TarArchiveEntry entry = new TarArchiveEntry(entryName, linkFlag);
                      
                      // Force file to be null (since constructor may set it)
                      // Using reflection since file is final private
                      try {
                          Field fileField = TarArchiveEntry.class.getDeclaredField("file");
                          fileField.setAccessible(true);
                          fileField.set(entry, null);
                      } catch (Exception e) {
                          fail("Failed to set file field to null via reflection");
                      }
                      
                      // Test
                      boolean result = entry.isDirectory();
                      
                      // Verify
                      assertTrue("Should return true when linkFlag is LF_DIR regardless of file being null", 
                                result);
                      
                      // Additional check to ensure the mutant would fail
                      // (This is just for demonstration, not needed in actual test)
                      boolean mutantResult = (entry.getFile() != null);
                      assertNotEquals("Test would fail with mutant (returns file null check)", 
                                     mutantResult, result);
                  }

 @Test
             public void testIsDirectoryWithFileObject() throws Exception {
                 // Create a mock File that is a directory
                 File mockDirectory = mock(File.class);
                 when(mockDirectory.isDirectory()).thenReturn(true);
                 when(mockDirectory.getPath()).thenReturn("/test/dir");
                 
                 // Create entry with the mock directory file
                 TarArchiveEntry entry = new TarArchiveEntry(mockDirectory, "testDir");
                 
                 // Ensure other directory-indicating conditions are false
                 entry.setMode(0100000); // Regular file mode
                 entry.setName("testDir"); // Doesn't end with "/"
                 
                 // Original should return true (is directory), mutant would return false
                 assertTrue("Should return true for directory file", entry.isDirectory());
                 
                 // Additional test with non-directory file
                 File mockFile = mock(File.class);
                 when(mockFile.isDirectory()).thenReturn(false);
                 when(mockFile.getPath()).thenReturn("/test/file.txt");
                 
                 TarArchiveEntry fileEntry = new TarArchiveEntry(mockFile, "file.txt");
                 fileEntry.setMode(0100000); // Regular file mode
                 fileEntry.setName("file.txt");
                 
                 // Original should return false (not directory), mutant would return true
                 assertFalse("Should return false for non-directory file", fileEntry.isDirectory());
             }

 @Test
             public void testIsDirectoryWithNonDirectoryFile() throws Exception {
                 // Create a temporary file that is NOT a directory
                 File tempFile = File.createTempFile("test", ".tmp");
                 tempFile.deleteOnExit();
                 
                 // Create TarArchiveEntry with this file
                 TarArchiveEntry entry = new TarArchiveEntry(tempFile);
                 
                 // Verify isDirectory() returns false since tempFile is not a directory
                 // This will fail if the mutant (return true) is present
                 assertFalse("Entry with non-directory file should not be directory", 
                            entry.isDirectory());
                 
                 // Clean up
                 tempFile.delete();
             }

 @Test
            public void testIsDirectoryWithDirectoryFile() throws Exception {
                // Create a mock File that is a directory
                File mockDirectory = mock(File.class);
                when(mockDirectory.isDirectory()).thenReturn(true);
                when(mockDirectory.isFile()).thenReturn(false);
                
                // Create TarArchiveEntry with the mock directory file
                TarArchiveEntry entry = new TarArchiveEntry(mockDirectory, "testDir/");
                
                // Verify isDirectory() returns true (original behavior)
                // This will fail if the mutant (isFile) is present
                assertTrue("Should return true for directory file", entry.isDirectory());
                
                // Verify interactions
                verify(mockDirectory).isDirectory();
            }

 @Test
           public void testIsDirectoryWhenFileIsDirectory() throws Exception {
               // Create a mock File that is a directory
               File mockDirectory = mock(File.class);
               when(mockDirectory.isDirectory()).thenReturn(true);
               
               // Create TarArchiveEntry with the mock directory file
               TarArchiveEntry entry = new TarArchiveEntry(mockDirectory, "testDir/");
               
               // Verify isDirectory() returns true for directory files
               assertTrue("Should return true for directory files", entry.isDirectory());
               
               // Verify interaction with the mock
               verify(mockDirectory).isDirectory();
           }

 @Test
     public void testIsDirectoryWithFile() throws Exception {
         // Create a temporary directory for testing
         java.nio.file.Path tempDirPath = java.nio.file.Files.createTempDirectory("testDir");
         File tempDir = tempDirPath.toFile();
         try {
             // Test case 1: File is a directory
             TarArchiveEntry dirEntry = new TarArchiveEntry(tempDir);
             assertTrue("Should return true for directory", dirEntry.isDirectory());
             
             // Test case 2: File is not a directory
             File tempFile = File.createTempFile("test", ".txt", tempDir);
             TarArchiveEntry fileEntry = new TarArchiveEntry(tempFile);
             assertFalse("Should return false for regular file", fileEntry.isDirectory());
         } finally {
             // Clean up
             File[] files = tempDir.listFiles();
             if (files != null) {
                 for (File f : files) {
                     f.delete();
                 }
             }
             tempDir.delete();
         }
     }

 @Test
 public void testIsDirectoryWithNonDirectoryFile1() throws Exception {
     // Create a temporary file that is not a directory
     File tempFile = File.createTempFile("test", ".tmp");
     tempFile.deleteOnExit();
     
     // Create TarArchiveEntry with this file
     TarArchiveEntry entry = new TarArchiveEntry(tempFile);
     
     // Verify isDirectory returns false since tempFile is not a directory
     // This will fail if mutant returns true unconditionally
     assertFalse("Entry with non-directory file should not be directory", 
                entry.isDirectory());
     
     // Clean up
     tempFile.delete();
 }

}
