package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.annotations.CategoryAnnotation;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.CategoryAnchor;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.SortOrder;
import org.jfree.data.Range;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
 
public class CategoryPlotTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                    public void testGetRangeAxisIndex_AxisPresentInCurrentPlot() {
                                                                                                                                                                                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                                                                        plot.setRangeAxis(0, axis);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        int index = plot.getRangeAxisIndex(axis);
                                                                                                                                                                                                                                        assertEquals(0, index);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                    public void testGetRangeAxisIndex_AxisPresentInParentPlot() {
                                                                                                                                                                                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                        CategoryPlot parentPlot = new CategoryPlot();
                                                                                                                                                                                                                                        parentPlot.setRangeAxis(0, axis);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                        CategoryPlot plot = spy(new CategoryPlot());
                                                                                                                                                                                                                                        doReturn(parentPlot).when(plot).getParent();
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                        int index = plot.getRangeAxisIndex(axis);
                                                                                                                                                                                                                                        assertEquals(0, index);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                    public void testGetRangeAxisIndex_AxisNotPresent() {
                                                                                                                                                                                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                        int index = plot.getRangeAxisIndex(axis);
                                                                                                                                                                                                                                        assertEquals(-1, index);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                public void testGetDomainAxisIndex_NullAxis() {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    CategoryPlot categoryPlot = new CategoryPlot();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                    thrown.expectMessage("Null 'axis' argument.");
                                                                                                                                                                                                                            
                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                    categoryPlot.getDomainAxisIndex(null);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                            public void testGetDomainAxisIndex_AxisInList() {
                                                                                                                                                                                                                                // Create a CategoryPlot instance
                                                                                                                                                                                                                                CategoryPlot categoryPlot = new CategoryPlot();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                                // Create a mock CategoryAxis and set it as the domain axis at index 0
                                                                                                                                                                                                                                CategoryAxis axis1 = new CategoryAxis("Axis 1");
                                                                                                                                                                                                                                categoryPlot.setDomainAxis(0, axis1);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                                // Call the method under test
                                                                                                                                                                                                                                int index = categoryPlot.getDomainAxisIndex(axis1);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                                // Assert that the index of the axis is 0
                                                                                                                                                                                                                                assertEquals(0, index);
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                            public void testGetDomainAxisIndex_AxisNotInList() {
                                                                                                                                                                                                                                // Create a CategoryPlot instance
                                                                                                                                                                                                                                CategoryPlot categoryPlot = new CategoryPlot();
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Create a CategoryAxis instance that is not added to the plot
                                                                                                                                                                                                                                CategoryAxis axis2 = new CategoryAxis("Axis 2");
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Call the method under test
                                                                                                                                                                                                                                int index = categoryPlot.getDomainAxisIndex(axis2);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Assert that the index is -1, indicating the axis is not in the list
                                                                                                                                                                                                                                assertEquals(-1, index);
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testGetRangeAxisIndex_NullAxis() {
                                                                                                                                                                                                                // Create an instance of CategoryPlot
                                                                                                                                                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                                        
                                                                                                                                                                                                                // Set up the ExpectedException rule
                                                                                                                                                                                                                ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                                expectedException.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                expectedException.expectMessage("Null 'axis' argument.");
                                                                                                                                                                                                        
                                                                                                                                                                                                                // Call the method with a null argument to trigger the exception
                                                                                                                                                                                                                expectedException.handleAssertionErrors();
                                                                                                                                                                                                                plot.getRangeAxisIndex(null);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                        public void testGetRangeAxisIndex_NullAxis_ThrowsIllegalArgumentException() {
                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                                    
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                plot.getRangeAxisIndex(null);
                                                                                                                                                                                                                fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                assertEquals("Null 'axis' argument.", e.getMessage());
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                public void testGetRangeAxisIndex_MutantDetection() throws Exception {
                                                                                                                                                                                                    // Step 1: Setup the test data and mock objects
                                                                                                                                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                                    ValueAxis axis = mock(ValueAxis.class); // Mock the ValueAxis object
                                                                                                                                                                                            
                                                                                                                                                                                                    // Use reflection to access the private rangeAxes field
                                                                                                                                                                                                    Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                                                                                                                                                                                    rangeAxesField.setAccessible(true);
                                                                                                                                                                                            
                                                                                                                                                                                                    // Create an ObjectList and add the mocked axis
                                                                                                                                                                                                    ObjectList rangeAxesMock = new ObjectList();
                                                                                                                                                                                                    rangeAxesMock.set(0, axis); // Add the axis to the list
                                                                                                                                                                                            
                                                                                                                                                                                                    // Inject the mocked list into the plot object
                                                                                                                                                                                                    rangeAxesField.set(plot, rangeAxesMock);
                                                                                                                                                                                            
                                                                                                                                                                                                    // Mock the parent plot behavior
                                                                                                                                                                                                    CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                                                                                                                                                                    when(parentPlot.getRangeAxisIndex(axis)).thenReturn(-1); // Simulate parent returning -1
                                                                                                                                                                                                    plot.setParent(parentPlot); // Inject the mocked parent plot into the plot object
                                                                                                                                                                                            
                                                                                                                                                                                                    // Step 2: Test the original method behavior
                                                                                                                                                                                                    int result = plot.getRangeAxisIndex(axis);
                                                                                                                                                                                            
                                                                                                                                                                                                    // Step 3: Assertions to detect the mutant
                                                                                                                                                                                                    // If the mutant is present, the method will incorrectly call the parent plot even when result == 0
                                                                                                                                                                                                    assertEquals("Expected result to be 0 when axis is found in rangeAxes", 0, result);
                                                                                                                                                                                                    verify(parentPlot, times(0)).getRangeAxisIndex(axis); // Ensure parent plot is not called
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                            public void testGetRangeAxisIndex_NullAxis_ThrowsIllegalArgumentException1() {
                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                        
                                                                                                                                                                                                try {
                                                                                                                                                                                                    // Act
                                                                                                                                                                                                    plot.getRangeAxisIndex(null);
                                                                                                                                                                                                    fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                    assertEquals("Null 'axis' argument.", e.getMessage());
                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                    fail("Expected IllegalArgumentException, but got: " + e.getClass().getSimpleName());
                                                                                                                                                                                                }
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testGetRangeAxisIndex_NullAxis_ShouldThrowIllegalArgumentException() {
                                                                                                                                                                                            // Arrange
                                                                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                                    
                                                                                                                                                                                            // Act & Assert
                                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                            thrown.expectMessage("Null 'axis' argument.");
                                                                                                                                                                                            
                                                                                                                                                                                            plot.getRangeAxisIndex(null);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testGetRangeAxisIndexDetectMutant() {
                                                                                                                                                                                    // Step 1: Setup the CategoryPlot instance
                                                                                                                                                                                    CategoryPlot categoryPlot = new CategoryPlot();
                                                                                                                                                                            
                                                                                                                                                                                    // Mock the rangeAxes list to simulate behavior
                                                                                                                                                                                    ObjectList mockRangeAxes = mock(ObjectList.class);
                                                                                                                                                                            
                                                                                                                                                                                    // Use reflection to set the private field 'rangeAxes'
                                                                                                                                                                                    try {
                                                                                                                                                                                        Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                                                                                                                                                                        rangeAxesField.setAccessible(true);
                                                                                                                                                                                        rangeAxesField.set(categoryPlot, mockRangeAxes);
                                                                                                                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                                                                        fail("Reflection failed to set rangeAxes: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                            
                                                                                                                                                                                    // Mock the parent plot
                                                                                                                                                                                    CategoryPlot mockParentPlot = mock(CategoryPlot.class);
                                                                                                                                                                                    when(mockParentPlot.getRangeAxisIndex(any(ValueAxis.class))).thenReturn(-1); // Simulate parent plot behavior
                                                                                                                                                                            
                                                                                                                                                                                    // Mock the getParent method to return the mocked parent plot
                                                                                                                                                                                    CategoryPlot spyPlot = spy(categoryPlot);
                                                                                                                                                                                    doReturn(mockParentPlot).when(spyPlot).getParent();
                                                                                                                                                                            
                                                                                                                                                                                    // Step 2: Define the axis to test
                                                                                                                                                                                    ValueAxis testAxis = mock(ValueAxis.class);
                                                                                                                                                                            
                                                                                                                                                                                    // Case 1: Axis is null (should throw IllegalArgumentException)
                                                                                                                                                                                    try {
                                                                                                                                                                                        spyPlot.getRangeAxisIndex(null);
                                                                                                                                                                                        fail("Expected IllegalArgumentException for null axis");
                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                        assertEquals("Null 'axis' argument.", e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                            
                                                                                                                                                                                    // Case 2: Axis is not in rangeAxes, and parent plot returns -1
                                                                                                                                                                                    when(mockRangeAxes.indexOf(testAxis)).thenReturn(-1); // Simulate axis not found
                                                                                                                                                                                    int result = spyPlot.getRangeAxisIndex(testAxis);
                                                                                                                                                                                    assertEquals(-1, result); // Expected result is -1
                                                                                                                                                                            
                                                                                                                                                                                    // Case 3: Axis is found in rangeAxes
                                                                                                                                                                                    when(mockRangeAxes.indexOf(testAxis)).thenReturn(0); // Simulate axis found at index 0
                                                                                                                                                                                    result = spyPlot.getRangeAxisIndex(testAxis);
                                                                                                                                                                                    assertEquals(0, result); // Expected result is 0
                                                                                                                                                                            
                                                                                                                                                                                    // Case 4: Axis is not in rangeAxes, parent plot returns a valid index
                                                                                                                                                                                    when(mockRangeAxes.indexOf(testAxis)).thenReturn(-1); // Simulate axis not found
                                                                                                                                                                                    when(mockParentPlot.getRangeAxisIndex(testAxis)).thenReturn(2); // Parent plot returns index 2
                                                                                                                                                                                    result = spyPlot.getRangeAxisIndex(testAxis);
                                                                                                                                                                                    assertEquals(2, result); // Expected result is 2
                                                                                                                                                                            
                                                                                                                                                                                    // Case 5: Test mutant behavior (result != 0 instead of result < 0)
                                                                                                                                                                                    // Simulate the mutant condition: result != 0
                                                                                                                                                                                    when(mockRangeAxes.indexOf(testAxis)).thenReturn(0); // Simulate axis found at index 0
                                                                                                                                                                                    result = spyPlot.getRangeAxisIndex(testAxis);
                                                                                                                                                                                    assertEquals(0, result); // Ensure correct behavior for result == 0
                                                                                                                                                                            
                                                                                                                                                                                    when(mockRangeAxes.indexOf(testAxis)).thenReturn(-1); // Simulate axis not found
                                                                                                                                                                                    when(mockParentPlot.getRangeAxisIndex(testAxis)).thenReturn(-1); // Parent plot returns -1
                                                                                                                                                                                    result = spyPlot.getRangeAxisIndex(testAxis);
                                                                                                                                                                                    assertEquals(-1, result); // Ensure correct behavior for result < 0
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testGetRangeAxisIndexWithMutant() throws Exception {
                                                                                                                                                                            // Step 1: Mock dependencies and set up the test environment
                                                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                            ObjectList mockRangeAxes = mock(ObjectList.class);
                                                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                    
                                                                                                                                                                            // Use reflection to set the private field 'rangeAxes'
                                                                                                                                                                            Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                                                                                                                                                            rangeAxesField.setAccessible(true);
                                                                                                                                                                            rangeAxesField.set(plot, mockRangeAxes);
                                                                                                                                                                    
                                                                                                                                                                            // Step 2: Define the behavior of the mock objects
                                                                                                                                                                            // Simulate a list of axes with size 3
                                                                                                                                                                            when(mockRangeAxes.size()).thenReturn(3);
                                                                                                                                                                            when(mockRangeAxes.get(0)).thenReturn(mockAxis);
                                                                                                                                                                            when(mockRangeAxes.get(1)).thenReturn(null);
                                                                                                                                                                            when(mockRangeAxes.get(2)).thenReturn(null);
                                                                                                                                                                    
                                                                                                                                                                            // Step 3: Test the method with a valid axis
                                                                                                                                                                            int index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                                                                            assertEquals("The index of the valid axis should be 0.", 0, index);
                                                                                                                                                                    
                                                                                                                                                                            // Step 4: Test the method with a null axis
                                                                                                                                                                            try {
                                                                                                                                                                                plot.getRangeAxisIndex(null);
                                                                                                                                                                                fail("Expected IllegalArgumentException for null axis.");
                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                assertEquals("Null 'axis' argument.", e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                    
                                                                                                                                                                            // Step 5: Test the method with an axis not in the rangeAxes list
                                                                                                                                                                            ValueAxis anotherAxis = mock(ValueAxis.class);
                                                                                                                                                                            int notFoundIndex = plot.getRangeAxisIndex(anotherAxis);
                                                                                                                                                                            assertEquals("The index of an axis not in the list should be -1.", -1, notFoundIndex);
                                                                                                                                                                    
                                                                                                                                                                            // Step 6: Test edge case to detect the mutant
                                                                                                                                                                            // Simulate the mutant condition where i <= axes.length causes ArrayIndexOutOfBoundsException
                                                                                                                                                                            when(mockRangeAxes.size()).thenReturn(1); // Only one element in the list
                                                                                                                                                                            when(mockRangeAxes.get(0)).thenReturn(mockAxis);
                                                                                                                                                                            when(mockRangeAxes.get(1)).thenThrow(new ArrayIndexOutOfBoundsException());
                                                                                                                                                                    
                                                                                                                                                                            try {
                                                                                                                                                                                plot.getRangeAxisIndex(mockAxis);
                                                                                                                                                                                fail("Expected ArrayIndexOutOfBoundsException due to mutant.");
                                                                                                                                                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                // Exception is expected due to the mutant
                                                                                                                                                                            }
                                                                                                                                                                    
                                                                                                                                                                            // Verify interactions with the mocked object
                                                                                                                                                                            verify(mockRangeAxes, atLeastOnce()).size();
                                                                                                                                                                            verify(mockRangeAxes, atLeastOnce()).get(anyInt());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                public void testGetRangeAxisIndexWithNullAxis() {
                                                                                                                                                                    // Create an instance of CategoryPlot
                                                                                                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                                                                                            
                                                                                                                                                                    // Define the rule for handling exceptions
                                                                                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                    thrown.expectMessage("Null 'axis' argument.");
                                                                                                                                                            
                                                                                                                                                                    // Trigger the method with a null argument
                                                                                                                                                                    thrown.handleAssertionErrors();
                                                                                                                                                                    plot.getRangeAxisIndex(null);
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testGetRangeAxisIndexWithExistingAxis() {
                                                                                                                                                                // Create a mock ValueAxis object
                                                                                                                                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                            
                                                                                                                                                                // Create an instance of CategoryPlot
                                                                                                                                                                CategoryPlot plot = new CategoryPlot();
                                                                                                                                                            
                                                                                                                                                                // Add the mockAxis to the plot's rangeAxes list
                                                                                                                                                                plot.setRangeAxis(0, mockAxis);
                                                                                                                                                            
                                                                                                                                                                // Verify that the index of the mockAxis is returned correctly
                                                                                                                                                                int index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                                                                assertEquals(0, index);
                                                                                                                                                            }

    @Test
                                                                                                                                                                public void testGetRangeAxisIndexWithNonExistingAxis() {
                                                                                                                                                                    // Create an instance of CategoryPlot
                                                                                                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                                                                                            
                                                                                                                                                                    // Create a mock ValueAxis
                                                                                                                                                                    ValueAxis anotherMockAxis = mock(ValueAxis.class);
                                                                                                                                                            
                                                                                                                                                                    // Verify that the index of a non-existing axis returns -1
                                                                                                                                                                    int index = plot.getRangeAxisIndex(anotherMockAxis);
                                                                                                                                                                    assertEquals(-1, index);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetRangeAxisIndexWithParentPlot() {
                                                                                                                                                                    // Create a mock for ValueAxis
                                                                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                            
                                                                                                                                                                    // Create a mock for the parent plot
                                                                                                                                                                    CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                                                                                                                                    
                                                                                                                                                                    // Define the behavior of the mock parent plot
                                                                                                                                                                    when(parentPlot.getRangeAxisIndex(mockAxis)).thenReturn(1);
                                                                                                                                                            
                                                                                                                                                                    // Create an instance of CategoryPlot and set the parent
                                                                                                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                                                                                                    plot.setParent(parentPlot);
                                                                                                                                                            
                                                                                                                                                                    // Verify that the index from the parent plot is returned
                                                                                                                                                                    int index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                                                                    assertEquals(1, index);
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testGetRangeAxisIndex_NullAxis1() {
                                                                                                                                                            // Create an instance of CategoryPlot
                                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                                    
                                                                                                                                                            // Set up the expected exception
                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                            thrown.expectMessage("Null 'axis' argument.");
                                                                                                                                                    
                                                                                                                                                            // Call the method with a null argument
                                                                                                                                                            plot.getRangeAxisIndex(null);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testGetRangeAxisIndex_AxisFoundInParentPlot() {
                                                                                                                                                            // Create mock objects for the test
                                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                                            CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                                                                                                                            ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                    
                                                                                                                                                            // Set up the parent plot and mock behavior
                                                                                                                                                            plot.setParent(parentPlot);
                                                                                                                                                            when(parentPlot.getRangeAxisIndex(axis)).thenReturn(1);
                                                                                                                                                    
                                                                                                                                                            // Call the method under test
                                                                                                                                                            int index = plot.getRangeAxisIndex(axis);
                                                                                                                                                    
                                                                                                                                                            // Verify the result
                                                                                                                                                            assertEquals(1, index);
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testGetRangeAxisIndex_AxisNotFound() {
                                                                                                                                                        // Create a mock for the parent plot
                                                                                                                                                        CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                                                                                                                        
                                                                                                                                                        // Create a mock for the axis
                                                                                                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                        
                                                                                                                                                        // Create an instance of the plot to be tested
                                                                                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                                                                                        
                                                                                                                                                        // Set the parent plot
                                                                                                                                                        plot.setParent(parentPlot);
                                                                                                                                                        
                                                                                                                                                        // Define behavior for the mock parent plot
                                                                                                                                                        when(parentPlot.getRangeAxisIndex(axis)).thenReturn(-1);
                                                                                                                                                        
                                                                                                                                                        // Call the method under test
                                                                                                                                                        int index = plot.getRangeAxisIndex(axis);
                                                                                                                                                        
                                                                                                                                                        // Assert the expected result
                                                                                                                                                        assertEquals(-1, index);
                                                                                                                                                    }

    @Test
                                                                                                                                        public void testGetRangeAxisIndex_AxisFoundInCurrentPlot() {
                                                                                                                                            // Create a CategoryPlot instance
                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                        
                                                                                                                                            // Create a concrete implementation of the ValueAxis class
                                                                                                                                            ValueAxis axis = new org.jfree.chart.axis.NumberAxis("Axis"); // Fully qualify the NumberAxis class to avoid "symbol not found" errors
                                                                                                                                        
                                                                                                                                            // Set the range axis at index 0
                                                                                                                                            plot.setRangeAxis(0, axis);
                                                                                                                                        
                                                                                                                                            // Get the index of the axis
                                                                                                                                            int index = plot.getRangeAxisIndex(axis);
                                                                                                                                        
                                                                                                                                            // Assert that the index is 0
                                                                                                                                            org.junit.Assert.assertEquals(0, index); // Use fully qualified Assert to avoid ambiguity
                                                                                                                                        }

    @Test
                                                                                                                                        public void testGetRangeAxisIndex_DetectSurvivedMutant() {
                                                                                                                                            // Step 1: Create a mock ValueAxis object
                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                    
                                                                                                                                            // Step 2: Create a CategoryPlot instance
                                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                                    
                                                                                                                                            // Step 3: Add the mockAxis to the rangeAxes list at index 0
                                                                                                                                            plot.setRangeAxis(0, mockAxis);
                                                                                                                                    
                                                                                                                                            // Step 4: Test when axis exists in rangeAxes (should return 0)
                                                                                                                                            int result = plot.getRangeAxisIndex(mockAxis);
                                                                                                                                            assertEquals("Expected index 0 when axis exists in rangeAxes", 0, result);
                                                                                                                                    
                                                                                                                                            // Step 5: Test when axis does not exist in rangeAxes (should return -1)
                                                                                                                                            ValueAxis nonExistentAxis = mock(ValueAxis.class);
                                                                                                                                            result = plot.getRangeAxisIndex(nonExistentAxis);
                                                                                                                                            assertEquals("Expected -1 when axis does not exist in rangeAxes", -1, result);
                                                                                                                                    
                                                                                                                                            // Step 6: Test when axis does not exist in rangeAxes but is found in parent plot
                                                                                                                                            CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                                                                                                            when(parentPlot.getRangeAxisIndex(nonExistentAxis)).thenReturn(1); // Mock parent behavior
                                                                                                                                            plot.setParent(parentPlot);
                                                                                                                                    
                                                                                                                                            result = plot.getRangeAxisIndex(nonExistentAxis);
                                                                                                                                            assertEquals("Expected index from parent plot when axis is found in parent", 1, result);
                                                                                                                                    
                                                                                                                                            // Step 7: Test when axis does not exist in rangeAxes and parent plot returns -1
                                                                                                                                            when(parentPlot.getRangeAxisIndex(nonExistentAxis)).thenReturn(-1); // Mock parent behavior
                                                                                                                                            result = plot.getRangeAxisIndex(nonExistentAxis);
                                                                                                                                            assertEquals("Expected -1 when axis is not found in both rangeAxes and parent plot", -1, result);
                                                                                                                                    
                                                                                                                                            // Step 8: Test null axis (should throw IllegalArgumentException)
                                                                                                                                            try {
                                                                                                                                                plot.getRangeAxisIndex(null);
                                                                                                                                                fail("Expected IllegalArgumentException when axis is null");
                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                assertEquals("Null 'axis' argument.", e.getMessage());
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                            public void testGetRangeAxisIndex_MutantDetection1() throws Exception {
                                                                                                                                // Step 1: Set up the rangeAxes list with mock objects
                                                                                                                                // Create a mock CategoryPlot object
                                                                                                                                CategoryPlot categoryPlot = new CategoryPlot();
                                                                                                                            
                                                                                                                                // Use reflection to access the private/protected rangeAxes field
                                                                                                                                Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                                                                                                                rangeAxesField.setAccessible(true);
                                                                                                                            
                                                                                                                                // Create a mock ValueAxis object
                                                                                                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                            
                                                                                                                                // Create and populate the rangeAxes list
                                                                                                                                List<ValueAxis> rangeAxes = new ArrayList<>();
                                                                                                                                rangeAxes.add(mockAxis); // Adding one axis
                                                                                                                                rangeAxes.add(mock(ValueAxis.class)); // Adding another axis
                                                                                                                            
                                                                                                                                // Inject the rangeAxes list into the CategoryPlot object
                                                                                                                                rangeAxesField.set(categoryPlot, rangeAxes);
                                                                                                                            
                                                                                                                                // Step 2: Test the original behavior
                                                                                                                                when(mockAxis.equals(mockAxis)).thenReturn(true); // Mock equality behavior
                                                                                                                                int index = categoryPlot.getRangeAxisIndex(mockAxis);
                                                                                                                                assertEquals(0, index); // Expect the index of the first axis to be returned
                                                                                                                            
                                                                                                                                // Step 3: Test the mutant behavior
                                                                                                                                // The mutant changes the loop condition from `i < axes.length` to `i <= axes.length`
                                                                                                                                // This would result in an ArrayIndexOutOfBoundsException when `i == axes.length`
                                                                                                                                try {
                                                                                                                                    rangeAxes.add(null); // Add a null axis to simulate the mutant behavior
                                                                                                                                    index = categoryPlot.getRangeAxisIndex(mockAxis); // This should throw an exception
                                                                                                                                    fail("Expected ArrayIndexOutOfBoundsException due to mutant behavior");
                                                                                                                                } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                    // Exception is expected, so the mutant is detected
                                                                                                                                    assertTrue(e.getMessage().contains("Index"));
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                        public void testGetRangeAxisIndexFirstElement() {
                                                                                                                            // Create a mock ValueAxis
                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                            
                                                                                                                            // Create a CategoryPlot and set the mockAxis as the first range axis
                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                            plot.setRangeAxis(0, mockAxis);
                                                                                                                            
                                                                                                                            // Test when the axis is the first element in the rangeAxes list
                                                                                                                            int index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                            
                                                                                                                            // Assert that the index of the mockAxis is 0
                                                                                                                            assertEquals("Expected axis to be found at index 0", 0, index);
                                                                                                                        }

    @Test
                                                                                                                        public void testGetRangeAxisIndexNullAxis() {
                                                                                                                            // Arrange: Create an instance of CategoryPlot
                                                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                                                    
                                                                                                                            // Act & Assert: Test when the axis is null, expecting an IllegalArgumentException
                                                                                                                            try {
                                                                                                                                plot.getRangeAxisIndex(null);
                                                                                                                                fail("Expected IllegalArgumentException to be thrown");
                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                // Test passes if IllegalArgumentException is caught
                                                                                                                                assertNotNull("Exception message should not be null", e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                    public void testGetRangeAxisIndexNotFound() {
                                                                                                                        // Define the necessary variables
                                                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                                                        Plot parentPlot = mock(Plot.class);
                                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                    
                                                                                                                        // Set up the parent plot
                                                                                                                        plot.setParent(parentPlot);
                                                                                                                    
                                                                                                                        // Mock behavior for the parent plot
                                                                                                                        when(parentPlot instanceof CategoryPlot).thenReturn(true);
                                                                                                                        CategoryPlot parentCategoryPlot = mock(CategoryPlot.class);
                                                                                                                        when(parentPlot).thenReturn(parentCategoryPlot);
                                                                                                                        when(parentCategoryPlot.getRangeAxisIndex(mockAxis)).thenReturn(1);
                                                                                                                    
                                                                                                                        // Call the method under test
                                                                                                                        int index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                    
                                                                                                                        // Assert the expected result
                                                                                                                        assertEquals("Expected axis to be found at index 1 in the parent plot", 1, index);
                                                                                                                    }

    @Test
                                                                                                                public void testGetRangeAxisIndexWithMutation() {
                                                                                                                    // Create a mock ValueAxis
                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                            
                                                                                                                    // Create a CategoryPlot instance
                                                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                                            
                                                                                                                    // Set up the range axis in the plot
                                                                                                                    plot.setRangeAxis(0, mockAxis, false);
                                                                                                            
                                                                                                                    // Verify that the axis is set correctly
                                                                                                                    int index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                    assertEquals("The index of the range axis should be 0", 0, index);
                                                                                                            
                                                                                                                    // Now, test the mutation by setting the axis with notify = true
                                                                                                                    plot.setRangeAxis(0, mockAxis, true);
                                                                                                            
                                                                                                                    // Verify that the index is still correct
                                                                                                                    index = plot.getRangeAxisIndex(mockAxis);
                                                                                                                    assertEquals("The index of the range axis should still be 0", 0, index);
                                                                                                            
                                                                                                                    // Additional checks can be added to ensure that the notification behavior is as expected
                                                                                                                    // For example, verify that certain methods are called on the mockAxis if applicable
                                                                                                                    verify(mockAxis, atLeastOnce()).setPlot(plot);
                                                                                                                }

    @Test
                                                                                                        public void testGetRangeAxisIndexWithExistingAxis1() {
                                                                                                            // Arrange
                                                                                                            CategoryPlot plot = new CategoryPlot(); // Create an instance of CategoryPlot
                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class); // Mock the ValueAxis object
                                                                                                            plot.setRangeAxis(0, mockAxis); // Set the mocked axis at index 0
                                                                                                    
                                                                                                            // Act
                                                                                                            int index = plot.getRangeAxisIndex(mockAxis); // Get the index of the mocked axis
                                                                                                    
                                                                                                            // Assert
                                                                                                            assertEquals("The index of the existing axis should be 0", 0, index); // Verify the index is 0
                                                                                                        }

    @Test
                                                                                                    public void testGetRangeAxisIndexWithNonExistingAxis1() {
                                                                                                        try {
                                                                                                            // Arrange
                                                                                                            CategoryPlot plot = new CategoryPlot(); // Create an instance of CategoryPlot
                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class); // Mock the ValueAxis
                                                                                                            ValueAxis anotherAxis = mock(ValueAxis.class); // Mock another ValueAxis
                                                                                                            plot.setRangeAxis(0, mockAxis); // Set the mocked axis at index 0
                                                                                                    
                                                                                                            // Act
                                                                                                            int index = plot.getRangeAxisIndex(anotherAxis); // Call the method under test
                                                                                                    
                                                                                                            // Assert
                                                                                                            assertEquals("The index of a non-existing axis should be -1", -1, index);
                                                                                                        } catch (Exception e) {
                                                                                                            e.printStackTrace();
                                                                                                            fail("Test failed due to unexpected exception: " + e.getMessage());
                                                                                                        }
                                                                                                    }

    @Test
                                                                                                    public void testGetRangeAxisIndexWithNullAxis1() {
                                                                                                        // Arrange
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("Null 'axis' argument.");
                                                                                                
                                                                                                        // Create a CategoryPlot instance to test
                                                                                                        CategoryPlot plot = new CategoryPlot();
                                                                                                
                                                                                                        // Act
                                                                                                        plot.getRangeAxisIndex(null);
                                                                                                    }

    @Test
                                                                                            public void testGetRangeAxisIndexWithParentPlot1() {
                                                                                                try {
                                                                                                    // Arrange
                                                                                                    CategoryPlot plot = new CategoryPlot();
                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                    Plot mockParentPlot = mock(Plot.class);
                                                                                            
                                                                                                    // Use reflection to mock the behavior of the parent plot's getRangeAxisIndex method
                                                                                                    java.lang.reflect.Method method = Plot.class.getDeclaredMethod("getRangeAxisIndex", ValueAxis.class);
                                                                                                    method.setAccessible(true);
                                                                                                    when(method.invoke(mockParentPlot, mockAxis)).thenReturn(1);
                                                                                            
                                                                                                    plot.setRangeAxis(0, mockAxis);
                                                                                                    plot.setParent(mockParentPlot);
                                                                                            
                                                                                                    // Act
                                                                                                    int index = plot.getRangeAxisIndex(mockAxis);
                                                                                            
                                                                                                    // Assert
                                                                                                    assertEquals("The index should be found in the parent plot", 1, index);
                                                                                                } catch (Exception e) {
                                                                                                    fail("An exception occurred during the test: " + e.getMessage());
                                                                                                }
                                                                                            }

    @Test
                                                                                        public void testGetRangeAxisIndex_AxisPresentInCurrentPlot1() {
                                                                                            // Create a mock ValueAxis
                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                    
                                                                                            // Create an instance of CategoryPlot
                                                                                            CategoryPlot plot = new CategoryPlot();
                                                                                    
                                                                                            // Setup: Add the axis to the current plot's rangeAxes
                                                                                            plot.setRangeAxis(0, mockAxis);
                                                                                    
                                                                                            // Test: Axis should be found at index 0
                                                                                            int index = plot.getRangeAxisIndex(mockAxis);
                                                                                            assertEquals(0, index);
                                                                                        }

    @Test
                                                                                    public void testGetRangeAxisIndex_AxisPresentInParentPlot1() {
                                                                                        // Define and initialize the necessary variables
                                                                                        CategoryPlot plot = new CategoryPlot(); // Create an instance of CategoryPlot
                                                                                        CategoryPlot mockParentPlot = mock(CategoryPlot.class); // Mock the parent plot
                                                                                        ValueAxis mockAxis = mock(ValueAxis.class); // Mock the axis
                                                                                    
                                                                                        // Setup: Axis is not in the current plot, but in the parent plot
                                                                                        when(mockParentPlot.getRangeAxisIndex(mockAxis)).thenReturn(1); // Mock the behavior of the parent plot
                                                                                        plot.setParent(mockParentPlot); // Set the parent plot
                                                                                    
                                                                                        // Test: Axis should be found at index 1 in the parent plot
                                                                                        int index = plot.getRangeAxisIndex(mockAxis); // Call the method under test
                                                                                        assertEquals(1, index); // Assert that the returned index is as expected
                                                                                    }

    @Test
                                                                            public void testGetRangeAxisIndex_AxisNotPresentAnywhere() {
                                                                                // Create a mock for the parent plot
                                                                                Plot mockParentPlot = mock(Plot.class);
                                                                        
                                                                                // Create a mock for the axis
                                                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                                                        
                                                                                // Create an instance of CategoryPlot
                                                                                CategoryPlot plot = new CategoryPlot();
                                                                        
                                                                                // Setup: Axis is not in the current plot or the parent plot
                                                                                // Since the method getRangeAxisIndex does not exist in Plot, we need to ensure
                                                                                // the test logic is correct. We can assume the parent plot does not affect the result
                                                                                // directly in this test case, and we focus on the CategoryPlot behavior.
                                                                                plot.setParent(mockParentPlot);
                                                                        
                                                                                // Test: Axis should not be found, expect -1
                                                                                int index = plot.getRangeAxisIndex(mockAxis);
                                                                                assertEquals(-1, index);
                                                                            }

    @Test
                                                                    public void testGetRangeAxisIndexDetectMutant1() throws Exception {
                                                                        // Step 1: Setup the CategoryPlot instance and mock dependencies
                                                                        CategoryPlot categoryPlot = new CategoryPlot();
                                                                        ValueAxis axis1 = mock(ValueAxis.class);
                                                                        ValueAxis axis2 = mock(ValueAxis.class);
                                                                        ValueAxis axis3 = mock(ValueAxis.class);
                                                                
                                                                        // Step 2: Configure the rangeAxes list to simulate the original behavior
                                                                        ObjectList rangeAxes = new ObjectList();
                                                                        rangeAxes.set(0, axis1);
                                                                        rangeAxes.set(1, axis2);
                                                                        rangeAxes.set(2, axis3);
                                                                
                                                                        // Use reflection to access the private field 'rangeAxes'
                                                                        Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                                                        rangeAxesField.setAccessible(true);
                                                                        rangeAxesField.set(categoryPlot, rangeAxes);
                                                                
                                                                        // Step 3: Test for the mutant behavior
                                                                        // Original behavior: The loop should iterate over all axes (i < axes.length)
                                                                        // Mutated behavior: The loop skips the last axis (i < axes.length - 1)
                                                                
                                                                        // Case 1: Axis is present at the last index (original should return 2)
                                                                        int resultLastIndex = categoryPlot.getRangeAxisIndex(axis3);
                                                                        assertEquals("Expected index of axis3 to be 2, but mutant skips last axis.", 2, resultLastIndex);
                                                                
                                                                        // Case 2: Axis is not present (should return -1)
                                                                        ValueAxis axisNotPresent = mock(ValueAxis.class);
                                                                        int resultNotPresent = categoryPlot.getRangeAxisIndex(axisNotPresent);
                                                                        assertEquals("Expected index of axisNotPresent to be -1.", -1, resultNotPresent);
                                                                
                                                                        // Case 3: Axis is present at the first index (should return 0)
                                                                        int resultFirstIndex = categoryPlot.getRangeAxisIndex(axis1);
                                                                        assertEquals("Expected index of axis1 to be 0.", 0, resultFirstIndex);
                                                                
                                                                        // Case 4: Axis is present at the middle index (should return 1)
                                                                        int resultMiddleIndex = categoryPlot.getRangeAxisIndex(axis2);
                                                                        assertEquals("Expected index of axis2 to be 1.", 1, resultMiddleIndex);
                                                                    }

    @Test
                                                                public void testGetRangeAxisIndex_MutantDetection2() {
                                                                    // Step 1: Create a mock ValueAxis object
                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                            
                                                                    // Step 2: Create a mock parent CategoryPlot
                                                                    CategoryPlot mockParentPlot = mock(CategoryPlot.class);
                                                            
                                                                    // Step 3: Create a CategoryPlot instance and set up its state
                                                                    CategoryPlot plot = new CategoryPlot();
                                                                    plot.setRangeAxes(new ValueAxis[]{mockAxis}); // Set the range axis
                                                                    plot.setDomainAxes(new CategoryAxis[]{mock(CategoryAxis.class)}); // Set domain axes
                                                                    plot.setDrawSharedDomainAxis(false); // Ensure shared domain axis is false
                                                            
                                                                    // Step 4: Mock the parent plot behavior
                                                                    when(mockParentPlot.getRangeAxisIndex(mockAxis)).thenReturn(1); // Simulate parent behavior
                                                                    plot.setParent(mockParentPlot); // Set the parent plot
                                                            
                                                                    // Step 5: Test the getRangeAxisIndex method
                                                                    int result = plot.getRangeAxisIndex(mockAxis);
                                                            
                                                                    // Step 6: Assertions
                                                                    assertEquals("The index of the range axis should be 0 when found in the current plot.", 0, result);
                                                            
                                                                    // Verify the parent plot is not invoked when the axis is found in the current plot
                                                                    verify(mockParentPlot, never()).getRangeAxisIndex(mockAxis);
                                                            
                                                                    // Step 7: Test the behavior when the axis is not found in the current plot
                                                                    plot.setRangeAxes(new ValueAxis[]{null}); // Clear the range axis
                                                                    result = plot.getRangeAxisIndex(mockAxis);
                                                            
                                                                    // Assertions for parent plot behavior
                                                                    assertEquals("The index of the range axis should be 1 when found in the parent plot.", 1, result);
                                                                    verify(mockParentPlot, times(1)).getRangeAxisIndex(mockAxis);
                                                            
                                                                    // Step 8: Test the mutation specifically
                                                                    // Simulate the mutation by calling setDomainAxis with notify=true
                                                                    CategoryAxis mockDomainAxis = mock(CategoryAxis.class);
                                                                    plot.setDomainAxis(0, mockDomainAxis, true); // Notify=true (mutation scenario)
                                                            
                                                                    // Verify the behavior of the mutation
                                                                    verify(mockDomainAxis, times(1)).addChangeListener(any());
                                                                }

    @Test
                                                        public void testGetRangeAxisIndex_NullAxis_ThrowsException() {
                                                            // Arrange
                                                            CategoryPlot plot = new CategoryPlot();
                                                    
                                                            // Assert
                                                            thrown.expect(IllegalArgumentException.class);
                                                            thrown.expectMessage("Null 'axis' argument.");
                                                    
                                                            // Act
                                                            plot.getRangeAxisIndex((ValueAxis) null);
                                                        }

    @Test
                                                        public void testGetRangeAxisIndex_AxisFoundInRangeAxes() {
                                                            // Create a mock ValueAxis object
                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                    
                                                            // Create a CategoryPlot object
                                                            CategoryPlot plot = new CategoryPlot();
                                                    
                                                            // Set the mockAxis as the range axis at index 0
                                                            plot.setRangeAxis(0, mockAxis);
                                                    
                                                            // Get the index of the mockAxis
                                                            int index = plot.getRangeAxisIndex(mockAxis);
                                                    
                                                            // Assert that the index is 0
                                                            assertEquals(0, index);
                                                        }

    @Test
                                                    public void testGetRangeAxisIndex_AxisFoundInParentPlot1() {
                                                        // Arrange
                                                        // Create mock objects for the required dependencies
                                                        CategoryPlot plot = new CategoryPlot();
                                                        CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                    
                                                        // Set the parent plot
                                                        plot.setParent(parentPlot);
                                                    
                                                        // Mock the behavior of the parent plot's getRangeAxisIndex method
                                                        when(parentPlot.getRangeAxisIndex(mockAxis)).thenReturn(1);
                                                    
                                                        // Act
                                                        int index = plot.getRangeAxisIndex(mockAxis);
                                                    
                                                        // Assert
                                                        assertEquals(1, index);
                                                    }

    @Test
                                                public void testGetRangeAxisIndex_AxisNotFoundInRangeAxes() {
                                                    // Create a mock for the parent plot
                                                    CategoryPlot parentPlot = mock(CategoryPlot.class);
                                                    
                                                    // Create a mock for the axis
                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                    
                                                    // Create an instance of the plot to be tested
                                                    CategoryPlot plot = new CategoryPlot();
                                                    
                                                    // Set the parent plot
                                                    plot.setParent(parentPlot);
                                                    
                                                    // Define behavior for the parent plot's getRangeAxisIndex method
                                                    when(parentPlot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                    
                                                    // Call the method under test
                                                    int index = plot.getRangeAxisIndex(mockAxis);
                                                    
                                                    // Assert that the index is -1, indicating the axis was not found
                                                    assertEquals(-1, index);
                                                }

    @Test
                                                public void testGetRangeAxisIndex_MutantDetection3() {
                                                    // Step 1: Create a mock ValueAxis object
                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                            
                                                    // Step 2: Create a CategoryPlot instance
                                                    CategoryPlot plot = new CategoryPlot();
                                            
                                                    // Step 3: Add the mock axis to the plot's rangeAxes list
                                                    plot.setRangeAxis(0, mockAxis);
                                            
                                                    // Step 4: Verify that the axis is correctly indexed
                                                    int index = plot.getRangeAxisIndex(mockAxis);
                                                    assertEquals("The index of the mock axis should be 0.", 0, index);
                                            
                                                    // Step 5: Test behavior when axis is not found (parent plot scenario)
                                                    ValueAxis nonExistentAxis = mock(ValueAxis.class);
                                                    int nonExistentIndex = plot.getRangeAxisIndex(nonExistentAxis);
                                                    assertEquals("The index of a non-existent axis should be -1.", -1, nonExistentIndex);
                                            
                                                    // Step 6: Verify that notifyListeners is called with the correct PlotChangeEvent
                                                    // Mock the notifyListeners method
                                                    CategoryPlot spyPlot = spy(plot);
                                                    spyPlot.getRangeAxisIndex(mockAxis);
                                            
                                                    // Capture the argument passed to notifyListeners
                                                    verify(spyPlot).notifyListeners(argThat(event -> {
                                                        // Assert that the PlotChangeEvent is created with the correct source (this)
                                                        assertNotNull("The source of the PlotChangeEvent should not be null.", event.getSource());
                                                        assertSame("The source of the PlotChangeEvent should be the plot instance.", spyPlot, event.getSource());
                                                        return true;
                                                    }));
                                                }

    @Test
                                        public void testGetRangeAxisIndex() throws Exception {
                                            // Step 1: Setup the test environment
                                            CategoryPlot plot = new CategoryPlot();
                                            ValueAxis axis1 = mock(ValueAxis.class);
                                            ValueAxis axis2 = mock(ValueAxis.class);
                                    
                                            // Use reflection to access the private rangeAxes field
                                            Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                            rangeAxesField.setAccessible(true);
                                            ObjectList rangeAxes = (ObjectList) rangeAxesField.get(plot);
                                    
                                            // Set the axes in the rangeAxes list
                                            rangeAxes.set(0, axis1);
                                            rangeAxes.set(1, axis2);
                                    
                                            // Step 2: Test case 1 - Axis exists in rangeAxes
                                            int index1 = plot.getRangeAxisIndex(axis1);
                                            assertEquals("Expected index for axis1 is 0", 0, index1);
                                    
                                            int index2 = plot.getRangeAxisIndex(axis2);
                                            assertEquals("Expected index for axis2 is 1", 1, index2);
                                    
                                            // Step 3: Test case 2 - Axis does not exist in rangeAxes
                                            ValueAxis axis3 = mock(ValueAxis.class);
                                            int index3 = plot.getRangeAxisIndex(axis3);
                                            assertEquals("Expected index for axis3 is -1 (not found)", -1, index3);
                                    
                                            // Step 4: Test case 3 - Null axis argument
                                            try {
                                                plot.getRangeAxisIndex(null);
                                                fail("Expected IllegalArgumentException for null axis argument");
                                            } catch (IllegalArgumentException e) {
                                                assertEquals("Null 'axis' argument.", e.getMessage());
                                            }
                                    
                                            // Step 5: Test case 4 - Axis not found in rangeAxes but found in parent plot
                                            CategoryPlot parentPlot = mock(CategoryPlot.class);
                                            when(parentPlot.getRangeAxisIndex(axis3)).thenReturn(2);
                                            when(plot.getParent()).thenReturn(parentPlot);
                                    
                                            int index4 = plot.getRangeAxisIndex(axis3);
                                            assertEquals("Expected index for axis3 is 2 (found in parent plot)", 2, index4);
                                    
                                            // Step 6: Test case 5 - Axis not found in rangeAxes and not found in parent plot
                                            when(parentPlot.getRangeAxisIndex(axis3)).thenReturn(-1);
                                            int index5 = plot.getRangeAxisIndex(axis3);
                                            assertEquals("Expected index for axis3 is -1 (not found anywhere)", -1, index5);
                                        }

    @Test
                                public void testGetRangeAxisIndex_CapturesMutation() throws Exception {
                                    // Step 1: Mock dependencies
                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                    CategoryPlot mockParentPlot = mock(CategoryPlot.class);
                            
                                    // Step 2: Create an instance of CategoryPlot
                                    CategoryPlot plot = new CategoryPlot();
                            
                                    // Step 3: Mock the behavior of the rangeAxes list
                                    ObjectList mockRangeAxes = mock(ObjectList.class);
                                    when(mockRangeAxes.indexOf(mockAxis)).thenReturn(0); // Simulate the axis being at index 0
                            
                                    // Use reflection to set the private rangeAxes field
                                    Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                    rangeAxesField.setAccessible(true);
                                    rangeAxesField.set(plot, mockRangeAxes);
                            
                                    // Step 4: Test case where the axis is found in the rangeAxes list
                                    int result = plot.getRangeAxisIndex(mockAxis);
                                    assertEquals("Expected index 0 when axis is found in rangeAxes", 0, result);
                            
                                    // Step 5: Test case where the axis is not found in the rangeAxes list
                                    when(mockRangeAxes.indexOf(mockAxis)).thenReturn(-1); // Simulate the axis not being found
                                    when(plot.getParent()).thenReturn(mockParentPlot); // Mock parent plot
                                    when(mockParentPlot instanceof CategoryPlot).thenReturn(true); // Simulate parent being a CategoryPlot
                                    when(((CategoryPlot) mockParentPlot).getRangeAxisIndex(mockAxis)).thenReturn(1); // Simulate parent plot returning index 1
                            
                                    result = plot.getRangeAxisIndex(mockAxis);
                                    assertEquals("Expected index 1 when axis is found in parent plot", 1, result);
                            
                                    // Step 6: Test case where the axis is not found in both rangeAxes and parent plot
                                    when(((CategoryPlot) mockParentPlot).getRangeAxisIndex(mockAxis)).thenReturn(-1); // Simulate parent plot not finding the axis
                            
                                    result = plot.getRangeAxisIndex(mockAxis);
                                    assertEquals("Expected index -1 when axis is not found in both rangeAxes and parent plot", -1, result);
                            
                                    // Step 7: Test case for null axis
                                    try {
                                        plot.getRangeAxisIndex(null);
                                        fail("Expected IllegalArgumentException for null axis");
                                    } catch (IllegalArgumentException e) {
                                        assertEquals("Null 'axis' argument.", e.getMessage());
                                    }
                                }

    @Test
                        public void testGetRangeAxisIndex_MutantDetection4() {
                            try {
                                // Step 1: Create a mock for the ValueAxis
                                ValueAxis mockAxis = mock(ValueAxis.class);
                    
                                // Step 2: Create an instance of CategoryPlot
                                CategoryPlot plot = new CategoryPlot();
                    
                                // Step 3: Set up the rangeAxes list with a known size
                                ValueAxis[] rangeAxesArray = new ValueAxis[3]; // Array of size 3
                                rangeAxesArray[0] = mock(ValueAxis.class);
                                rangeAxesArray[1] = mock(ValueAxis.class);
                                rangeAxesArray[2] = mock(ValueAxis.class);
                    
                                // Mock the rangeAxes ObjectList to simulate the behavior of the array
                                ObjectList mockRangeAxes = mock(ObjectList.class);
                                when(mockRangeAxes.size()).thenReturn(rangeAxesArray.length);
                                for (int i = 0; i < rangeAxesArray.length; i++) {
                                    when(mockRangeAxes.get(i)).thenReturn(rangeAxesArray[i]);
                                }
                    
                                // Use reflection to inject the mocked rangeAxes into the plot
                                Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                                rangeAxesField.setAccessible(true);
                                rangeAxesField.set(plot, mockRangeAxes);
                    
                                // Step 4: Test behavior when axis is not found in rangeAxes
                                // This is where the mutant will cause an ArrayIndexOutOfBoundsException
                                try {
                                    plot.getRangeAxisIndex(mockAxis);
                                    fail("Expected ArrayIndexOutOfBoundsException due to mutant.");
                                } catch (ArrayIndexOutOfBoundsException e) {
                                    // Expected exception due to the mutant
                                    assertTrue("Caught the mutant behavior", true);
                                }
                            } catch (Exception e) {
                                fail("Unexpected exception: " + e.getMessage());
                            }
                        }

    @Test
                public void testGetRangeAxisIndex_MutantDetection5() throws Exception {
                    // Step 1: Mock the necessary objects
                    ValueAxis mockAxis1 = mock(ValueAxis.class);
                    ValueAxis mockAxis2 = mock(ValueAxis.class);
            
                    // Step 2: Create a CategoryPlot instance and set up the rangeAxes using reflection
                    CategoryPlot plot = new CategoryPlot();
                    ObjectList rangeAxes = new ObjectList();
                    rangeAxes.set(0, mockAxis1); // Index 0
                    rangeAxes.set(1, mockAxis2); // Index 1
            
                    // Use reflection to set the private field 'rangeAxes'
                    Field rangeAxesField = CategoryPlot.class.getDeclaredField("rangeAxes");
                    rangeAxesField.setAccessible(true);
                    rangeAxesField.set(plot, rangeAxes);
            
                    // Step 3: Test case where the axis is at index 0
                    int resultIndex0 = plot.getRangeAxisIndex(mockAxis1);
                    assertEquals("Expected index 0 for mockAxis1", 0, resultIndex0);
            
                    // Step 4: Test case where the axis is at index 1
                    int resultIndex1 = plot.getRangeAxisIndex(mockAxis2);
                    assertEquals("Expected index 1 for mockAxis2", 1, resultIndex1);
            
                    // Step 5: Test case where the axis is not found
                    ValueAxis mockAxisNotInList = mock(ValueAxis.class);
                    int resultNotFound = plot.getRangeAxisIndex(mockAxisNotInList);
                    assertEquals("Expected -1 for an axis not in the list", -1, resultNotFound);
            
                    // Step 6: Test edge case with null axis
                    try {
                        plot.getRangeAxisIndex(null);
                        fail("Expected IllegalArgumentException for null axis");
                    } catch (IllegalArgumentException e) {
                        assertEquals("Null 'axis' argument.", e.getMessage());
                    }
                }

    @Test
        public void testGetRangeAxisIndex_CaptureMutant() {
            // Arrange: Create a CategoryPlot instance
            CategoryPlot categoryPlot = new CategoryPlot();
    
            // Arrange: Set up the range axes and mock behavior
            ValueAxis[] axes = new ValueAxis[3];
            axes[0] = mock(ValueAxis.class);
            axes[1] = mock(ValueAxis.class);
            axes[2] = mock(ValueAxis.class);
    
            categoryPlot.setRangeAxes(axes);
    
            // Act: Retrieve the index of a specific axis
            int index = categoryPlot.getRangeAxisIndex(axes[1]);
    
            // Assert: Verify the correct index is returned
            assertEquals("The index of the second axis should be 1", 1, index);
    
            // Act: Test edge case for an axis not in the list
            ValueAxis nonExistentAxis = mock(ValueAxis.class);
            int nonExistentIndex = categoryPlot.getRangeAxisIndex(nonExistentAxis);
    
            // Assert: Verify the index for a non-existent axis is -1
            assertEquals("The index of a non-existent axis should be -1", -1, nonExistentIndex);
    
            // Act: Test parent plot behavior
            CategoryPlot parentPlot = mock(CategoryPlot.class);
            when(parentPlot.getRangeAxisIndex(axes[2])).thenReturn(2);
            categoryPlot.setParent(parentPlot);
    
            int parentIndex = categoryPlot.getRangeAxisIndex(axes[2]);
    
            // Assert: Verify the parent plot index is correctly returned
            assertEquals("The index from the parent plot should be 2", 2, parentIndex);
    
            // Additional Assertions: Ensure no mutation-related behavior occurs
            int mutatedIndex = categoryPlot.getRangeAxisIndex(axes[1]);
            assertEquals("The index of the second axis should remain 1", 1, mutatedIndex);
        }


}
