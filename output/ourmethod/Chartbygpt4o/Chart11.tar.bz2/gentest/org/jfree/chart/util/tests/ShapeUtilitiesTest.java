package gentest.org.jfree.chart.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.util.*;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
 
public class ShapeUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                public void testEqual_Line2D() {
                                                                                                                                                                                                    Line2D line1 = new Line2D.Double(0, 0, 1, 1);
                                                                                                                                                                                                    Line2D line2 = new Line2D.Double(0, 0, 1, 1);
                                                                                                                                                                                                    Line2D line3 = new Line2D.Double(0, 0, 2, 2);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(line1, line3));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_Ellipse2D() {
                                                                                                                                                                                                    Ellipse2D ellipse1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                    Ellipse2D ellipse2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                    Ellipse2D ellipse3 = new Ellipse2D.Double(0, 0, 20, 20);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(ellipse1, ellipse2));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(ellipse1, ellipse3));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_Arc2D() {
                                                                                                                                                                                                    Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.OPEN);
                                                                                                                                                                                                    Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.OPEN);
                                                                                                                                                                                                    Arc2D arc3 = new Arc2D.Double(0, 0, 10, 10, 0, 180, Arc2D.OPEN);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(arc1, arc3));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_Polygon() {
                                                                                                                                                                                                    Polygon polygon1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 0}, 3);
                                                                                                                                                                                                    Polygon polygon2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 0}, 3);
                                                                                                                                                                                                    Polygon polygon3 = new Polygon(new int[]{0, 1, 3}, new int[]{0, 1, 0}, 3);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(polygon1, polygon2));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(polygon1, polygon3));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_GeneralPath() {
                                                                                                                                                                                                    GeneralPath path1 = new GeneralPath();
                                                                                                                                                                                                    path1.moveTo(0, 0);
                                                                                                                                                                                                    path1.lineTo(1, 1);
                                                                                                                                                                                                    path1.closePath();
                                                                                                                                                                                            
                                                                                                                                                                                                    GeneralPath path2 = new GeneralPath();
                                                                                                                                                                                                    path2.moveTo(0, 0);
                                                                                                                                                                                                    path2.lineTo(1, 1);
                                                                                                                                                                                                    path2.closePath();
                                                                                                                                                                                            
                                                                                                                                                                                                    GeneralPath path3 = new GeneralPath();
                                                                                                                                                                                                    path3.moveTo(0, 0);
                                                                                                                                                                                                    path3.lineTo(2, 2);
                                                                                                                                                                                                    path3.closePath();
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(path1, path3));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_Rectangle2D() {
                                                                                                                                                                                                    Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                    Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                                                                                                                    Rectangle2D rect3 = new Rectangle2D.Double(0, 0, 20, 20);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(rect1, rect2));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(rect1, rect3));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_DifferentShapeTypes() {
                                                                                                                                                                                                    Line2D line = new Line2D.Double(0, 0, 1, 1);
                                                                                                                                                                                                    Ellipse2D ellipse = new Ellipse2D.Double(0, 0, 10, 10);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(line, ellipse));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_DelegatesToObjectUtilities() {
                                                                                                                                                                                                    // Mocking ObjectUtilities to verify delegation
                                                                                                                                                                                                    Object shape1 = mock(Rectangle2D.class);
                                                                                                                                                                                                    Object shape2 = mock(Rectangle2D.class);
                                                                                                                                                                                            
                                                                                                                                                                                                    when(ObjectUtilities.equal(shape1, shape2)).thenReturn(true);
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal((Shape) shape1, (Shape) shape2));
                                                                                                                                                                                            
                                                                                                                                                                                                    verify(ObjectUtilities.class);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_BothLinesNull() {
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal((Line2D) null, (Line2D) null));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_OneLineNull() {
                                                                                                                                                                                                    Line2D line = mock(Line2D.class);
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(line, null));
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(null, line));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_EqualLines() {
                                                                                                                                                                                                    Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                    Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                            
                                                                                                                                                                                                    when(line1.getP1()).thenReturn(new Point2D.Double(1.0, 1.0));
                                                                                                                                                                                                    when(line1.getP2()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                                    when(line2.getP1()).thenReturn(new Point2D.Double(1.0, 1.0));
                                                                                                                                                                                                    when(line2.getP2()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                            
                                                                                                                                                                                                    assertTrue(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_DifferentLines() {
                                                                                                                                                                                                    Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                    Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                            
                                                                                                                                                                                                    when(line1.getP1()).thenReturn(new Point2D.Double(1.0, 1.0));
                                                                                                                                                                                                    when(line1.getP2()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                                    when(line2.getP1()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                                    when(line2.getP2()).thenReturn(new Point2D.Double(3.0, 3.0));
                                                                                                                                                                                            
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_SameStartDifferentEnd() {
                                                                                                                                                                                                    Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                    Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                            
                                                                                                                                                                                                    when(line1.getP1()).thenReturn(new Point2D.Double(1.0, 1.0));
                                                                                                                                                                                                    when(line1.getP2()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                                    when(line2.getP1()).thenReturn(new Point2D.Double(1.0, 1.0));
                                                                                                                                                                                                    when(line2.getP2()).thenReturn(new Point2D.Double(3.0, 3.0));
                                                                                                                                                                                            
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                public void testEqual_DifferentStartSameEnd() {
                                                                                                                                                                                                    Line2D line1 = mock(Line2D.class);
                                                                                                                                                                                                    Line2D line2 = mock(Line2D.class);
                                                                                                                                                                                            
                                                                                                                                                                                                    when(line1.getP1()).thenReturn(new Point2D.Double(1.0, 1.0));
                                                                                                                                                                                                    when(line1.getP2()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                                    when(line2.getP1()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                                    when(line2.getP2()).thenReturn(new Point2D.Double(2.0, 2.0));
                                                                                                                                                                                            
                                                                                                                                                                                                    assertFalse(ShapeUtilities.equal(line1, line2));
                                                                                                                                                                                                }

    @Test
                                                                                                                                                    public void testEqual_BothNull() {
                                                                                                                                                        assertTrue(ShapeUtilities.equal((Ellipse2D) null, (Ellipse2D) null));
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testEqual_FirstNull() {
                                                                                                                                                    // Mocking Ellipse2D object using Mockito
                                                                                                                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                
                                                                                                                                                    // Asserting that the equal method returns false when the first argument is null
                                                                                                                                                    assertFalse(ShapeUtilities.equal((Ellipse2D) null, e2));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testEqual_SecondNull() {
                                                                                                                                                    // Create a mock Ellipse2D object
                                                                                                                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                
                                                                                                                                                    // Assert that the ShapeUtilities.equal method returns false when the second argument is null
                                                                                                                                                    assertFalse(ShapeUtilities.equal(e1, (Ellipse2D) null));
                                                                                                                                                }

    @Test
                                                                                                                                                    public void testEqual_EqualFrames() {
                                                                                                                                                        // Create mock objects for Ellipse2D
                                                                                                                                                        Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                        Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                
                                                                                                                                                        // Define the behavior of the mock objects
                                                                                                                                                        when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                
                                                                                                                                                        // Assert that the ShapeUtilities.equal method returns true for these mock objects
                                                                                                                                                        assertTrue(ShapeUtilities.equal(e1, e2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentFrames() {
                                                                                                                                                        // Mocking Ellipse2D objects
                                                                                                                                                        Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                                                                        Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                                                                                
                                                                                                                                                        // Defining behavior for mocked objects
                                                                                                                                                        when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 20, 20));
                                                                                                                                                
                                                                                                                                                        // Asserting the equality check
                                                                                                                                                        assertFalse(ShapeUtilities.equal(e1, e2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_NullInputs() {
                                                                                                                                                        Arc2D arc1 = null;
                                                                                                                                                        Arc2D arc2 = null;
                                                                                                                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                
                                                                                                                                                        arc1 = mock(Arc2D.class);
                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                
                                                                                                                                                        arc2 = mock(Arc2D.class);
                                                                                                                                                        arc1 = null;
                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentFrames1() {
                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                
                                                                                                                                                        when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 20, 20));
                                                                                                                                                
                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentAngleStart() {
                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                
                                                                                                                                                        when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                
                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(45.0);
                                                                                                                                                
                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentAngleExtent() {
                                                                                                                                                        // Mocking Arc2D objects
                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                
                                                                                                                                                        // Stubbing methods for arc1
                                                                                                                                                        when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                
                                                                                                                                                        // Stubbing methods for arc2
                                                                                                                                                        when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                                                                                        when(arc2.getAngleExtent()).thenReturn(180.0);
                                                                                                                                                
                                                                                                                                                        // Asserting that the two arcs are not equal
                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentArcType() {
                                                                                                                                                        // Mocking Arc2D objects
                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                
                                                                                                                                                        // Setting up mocked behavior for arc1
                                                                                                                                                        when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                                                                
                                                                                                                                                        // Setting up mocked behavior for arc2
                                                                                                                                                        when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                                                                                        when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                        when(arc2.getArcType()).thenReturn(Arc2D.CHORD);
                                                                                                                                                
                                                                                                                                                        // Assert that the two arcs are not equal
                                                                                                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_IdenticalArcs() {
                                                                                                                                                        // Create mock objects for Arc2D
                                                                                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                                                                                
                                                                                                                                                        // Define the behavior of the mock objects
                                                                                                                                                        when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                        when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                                                                                                
                                                                                                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                                                                        when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                                                                                
                                                                                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                        when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                                                                                
                                                                                                                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                                                                        when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                                                                
                                                                                                                                                        // Assert that the two arcs are considered equal by ShapeUtilities
                                                                                                                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_BothNull1() {
                                                                                                                                                        assertTrue(ShapeUtilities.equal((Polygon) null, (Polygon) null));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_FirstNullSecondNotNull() {
                                                                                                                                                        Polygon p2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                                                                        assertFalse(ShapeUtilities.equal(null, p2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_FirstNotNullSecondNull() {
                                                                                                                                                        // Create a Polygon object
                                                                                                                                                        Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                                                                        
                                                                                                                                                        // Assert that the ShapeUtilities.equal method returns false when the second argument is null
                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, null));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentNumberOfPoints() {
                                                                                                                                                        Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                                                                        Polygon p2 = new Polygon(new int[]{0, 1}, new int[]{0, 1}, 2);
                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentXPoints() {
                                                                                                                                                        Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                                                                        Polygon p2 = new Polygon(new int[]{0, 2, 3}, new int[]{0, 1, 2}, 3);
                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testEqual_DifferentYPoints() {
                                                                                                                                                        Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                                                                        Polygon p2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 2, 3}, 3);
                                                                                                                                                        assertFalse(ShapeUtilities.equal(p1, p2));
                                                                                                                                                    }

    @Test
                                                                                                        public void testEqual_IdenticalPolygons() {
                                                                                                            // Create two identical Polygon objects
                                                                                                            Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                            Polygon p2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                                                        
                                                                                                            // Use reflection to access the private ShapeUtilities.equal(Polygon, Polygon) method
                                                                                                            try {
                                                                                                                java.lang.reflect.Method method = ShapeUtilities.class.getDeclaredMethod("equal", Polygon.class, Polygon.class);
                                                                                                                method.setAccessible(true); // Allow access to the private method
                                                                                                        
                                                                                                                // Invoke the method and assert the result
                                                                                                                boolean result = (boolean) method.invoke(null, p1, p2);
                                                                                                                assertTrue(result);
                                                                                                            } catch (Exception e) {
                                                                                                                e.printStackTrace();
                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                            public void testEqual_BothPathsNull() {
                                                                                                                // Ensure the tested method is invoked correctly
                                                                                                                // The tested method is static, so no instance of ShapeUtilities is required
                                                                                                                assertTrue(ShapeUtilities.equal((GeneralPath) null, (GeneralPath) null));
                                                                                                            }

    @Test
                                                                                                            public void testEqual_OnePathNull() {
                                                                                                                // Create a GeneralPath object
                                                                                                                GeneralPath path = new GeneralPath();
                                                                                                        
                                                                                                                // Test the equality method in ShapeUtilities with one path being null
                                                                                                                assertFalse(ShapeUtilities.equal(path, null));
                                                                                                                assertFalse(ShapeUtilities.equal(null, path));
                                                                                                            }

    @Test
                                                                                                            public void testEqual_DifferentWindingRules() {
                                                                                                                GeneralPath path1 = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
                                                                                                                GeneralPath path2 = new GeneralPath(GeneralPath.WIND_NON_ZERO);
                                                                                                                assertFalse(ShapeUtilities.equal(path1, path2));
                                                                                                            }

    @Test
                                                                                                            public void testEqual_IdenticalPaths() {
                                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                                path1.moveTo(0, 0);
                                                                                                                path1.lineTo(1, 1);
                                                                                                                path1.closePath();
                                                                                                        
                                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                                path2.moveTo(0, 0);
                                                                                                                path2.lineTo(1, 1);
                                                                                                                path2.closePath();
                                                                                                        
                                                                                                                assertTrue(ShapeUtilities.equal(path1, path2));
                                                                                                            }

    @Test
                                                                                                            public void testEqual_DifferentPaths() {
                                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                                path1.moveTo(0, 0);
                                                                                                                path1.lineTo(1, 1);
                                                                                                                path1.closePath();
                                                                                                        
                                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                                path2.moveTo(0, 0);
                                                                                                                path2.lineTo(2, 2);
                                                                                                                path2.closePath();
                                                                                                        
                                                                                                                assertFalse(ShapeUtilities.equal(path1, path2));
                                                                                                            }

    @Test
                                                                                                            public void testEqual_PathsWithDifferentSegmentCounts() {
                                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                                path1.moveTo(0, 0);
                                                                                                                path1.lineTo(1, 1);
                                                                                                                path1.closePath();
                                                                                                        
                                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                                path2.moveTo(0, 0);
                                                                                                                path2.lineTo(1, 1);
                                                                                                                path2.lineTo(2, 2);
                                                                                                                path2.closePath();
                                                                                                        
                                                                                                                assertFalse(ShapeUtilities.equal(path1, path2));
                                                                                                            }

    @Test
                                                                                                        public void testEqual_NullShapes() {
                                                                                                            // Cast null to Shape to resolve method ambiguity
                                                                                                            assertTrue(ShapeUtilities.equal((Shape) null, (Shape) null));
                                                                                                            
                                                                                                            // Create a Line2D object to test against null
                                                                                                            Line2D line = new Line2D.Double(0, 0, 1, 1);
                                                                                                            
                                                                                                            // Cast null to Shape to resolve method ambiguity
                                                                                                            assertFalse(ShapeUtilities.equal(line, (Shape) null));
                                                                                                            assertFalse(ShapeUtilities.equal((Shape) null, line));
                                                                                                        }

    @Test
                                                                                                    public void testEqualWithPolygonAndNull() {
                                                                                                        // Create a Polygon instance
                                                                                                        Polygon polygon1 = new Polygon();
                                                                                                
                                                                                                        // Set the second Polygon to null
                                                                                                        Polygon polygon2 = null;
                                                                                                
                                                                                                        // Call the method under test
                                                                                                        boolean result = ShapeUtilities.equal(polygon1, polygon2);
                                                                                                
                                                                                                        // Assert that the result should be false
                                                                                                        // This assertion will fail if the mutant is present
                                                                                                        assertFalse("Expected false when comparing a Polygon with null", result);
                                                                                                    }

    @Test
                                                                                                    public void testEqualWithMutantDetection() {
                                                                                                        // Case 1: Both l1 and l2 are null
                                                                                                        Line2D l1 = null;
                                                                                                        Line2D l2 = null;
                                                                                                        assertTrue("Both lines are null, should return true", ShapeUtilities.equal(l1, l2));
                                                                                                
                                                                                                        // Case 2: l1 is null, l2 is not null
                                                                                                        l1 = null;
                                                                                                        l2 = mock(Line2D.class);
                                                                                                        assertFalse("l1 is null and l2 is not null, should return false", ShapeUtilities.equal(l1, l2));
                                                                                                
                                                                                                        // Case 3: l1 is not null, l2 is null
                                                                                                        l1 = mock(Line2D.class);
                                                                                                        l2 = null;
                                                                                                        assertFalse("l1 is not null and l2 is null, should return false", ShapeUtilities.equal(l1, l2));
                                                                                                
                                                                                                        // Case 4: l1.getP1() and l2.getP1() are not equal
                                                                                                        l1 = mock(Line2D.class);
                                                                                                        l2 = mock(Line2D.class);
                                                                                                        when(l1.getP1()).thenReturn(mock(java.awt.geom.Point2D.class));
                                                                                                        when(l2.getP1()).thenReturn(mock(java.awt.geom.Point2D.class));
                                                                                                        when(l1.getP1().equals(l2.getP1())).thenReturn(false);
                                                                                                        assertFalse("l1.getP1() and l2.getP1() are not equal, should return false", ShapeUtilities.equal(l1, l2));
                                                                                                
                                                                                                        // Case 5: l1.getP1() equals l2.getP1(), but l1.getP2() and l2.getP2() are not equal
                                                                                                        when(l1.getP1().equals(l2.getP1())).thenReturn(true);
                                                                                                        when(l1.getP2()).thenReturn(mock(java.awt.geom.Point2D.class));
                                                                                                        when(l2.getP2()).thenReturn(mock(java.awt.geom.Point2D.class));
                                                                                                        when(l1.getP2().equals(l2.getP2())).thenReturn(false);
                                                                                                        assertFalse("l1.getP1() equals l2.getP1(), but l1.getP2() and l2.getP2() are not equal, should return false", ShapeUtilities.equal(l1, l2));
                                                                                                
                                                                                                        // Case 6: l1.getP1() equals l2.getP1(), and l1.getP2() equals l2.getP2()
                                                                                                        when(l1.getP2().equals(l2.getP2())).thenReturn(true);
                                                                                                        assertTrue("l1.getP1() equals l2.getP1(), and l1.getP2() equals l2.getP2(), should return true", ShapeUtilities.equal(l1, l2));
                                                                                                
                                                                                                        // Case 7: Mutant detection - l1.getP1() equals l2.getP1(), but l2.getP2() is null
                                                                                                        when(l1.getP1().equals(l2.getP1())).thenReturn(true);
                                                                                                        when(l2.getP2()).thenReturn(null);
                                                                                                        assertFalse("Mutant detection: l1.getP1() equals l2.getP1(), but l2.getP2() is null, should return false", ShapeUtilities.equal(l1, l2));
                                                                                                    }

    @Test
                                                                                                    public void testEqualArc2D() {
                                                                                                        // Create two Arc2D objects with different frames
                                                                                                        Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 180, Arc2D.OPEN);
                                                                                                        Arc2D arc2 = new Arc2D.Double(5, 5, 10, 10, 0, 180, Arc2D.OPEN);
                                                                                                
                                                                                                        // Test the original method behavior
                                                                                                        boolean result = ShapeUtilities.equal(arc1, arc2);
                                                                                                
                                                                                                        // Assert that the method should return false because the frames are different
                                                                                                        assertFalse("Expected false when frames are different", result);
                                                                                                    }

    @Test
                                                                                                    public void testEqualArc2DWithNull() {
                                                                                                        // Create an Arc2D object and set the second one to null
                                                                                                        Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 180, Arc2D.OPEN);
                                                                                                        Arc2D arc2 = null;
                                                                                                
                                                                                                        // Test the original method behavior
                                                                                                        boolean result = ShapeUtilities.equal(arc1, arc2);
                                                                                                
                                                                                                        // Assert that the method should return false because arc2 is null
                                                                                                        assertFalse("Expected false when the second arc is null", result);
                                                                                                    }

    @Test
                                                                                                    public void testEqualArc2DSameFrames() {
                                                                                                        // Create two Arc2D objects with the same frames
                                                                                                        Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 180, Arc2D.OPEN);
                                                                                                        Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 180, Arc2D.OPEN);
                                                                                                
                                                                                                        // Test the original method behavior
                                                                                                        boolean result = ShapeUtilities.equal(arc1, arc2);
                                                                                                
                                                                                                        // Assert that the method should return true because all properties are equal
                                                                                                        assertTrue("Expected true when all properties are equal", result);
                                                                                                    }

    @Test
                                                                                                    public void testEqual_detectMutant() {
                                                                                                        // Test case to detect the mutant where "return false;" is mutated to "return p2 == null;"
                                                                                                
                                                                                                        // Create mock Polygon objects
                                                                                                        Polygon p1 = mock(Polygon.class);
                                                                                                        Polygon p2 = null; // p2 is null to trigger the mutant behavior
                                                                                                
                                                                                                        // Mock the behavior of p1
                                                                                                        when(p1.npoints).thenReturn(3); // Arbitrary value for npoints
                                                                                                        when(p1.xpoints).thenReturn(new int[]{1, 2, 3});
                                                                                                        when(p1.ypoints).thenReturn(new int[]{4, 5, 6});
                                                                                                
                                                                                                        // Call the method under test
                                                                                                        boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                
                                                                                                        // Assert the expected behavior
                                                                                                        // The original method should return false when p1 is not null and p2 is null
                                                                                                        assertFalse("The method should return false when p1 is not null and p2 is null.", result);
                                                                                                    }

    @Test
                                                                                                    public void testEqual_originalBehavior() {
                                                                                                        // Additional test cases to ensure the original behavior is preserved
                                                                                                
                                                                                                        // Case 1: Both p1 and p2 are null
                                                                                                        Polygon p1 = null;
                                                                                                        Polygon p2 = null;
                                                                                                        assertTrue("The method should return true when both p1 and p2 are null.", ShapeUtilities.equal(p1, p2));
                                                                                                
                                                                                                        // Case 2: p1 is null and p2 is not null
                                                                                                        p1 = null;
                                                                                                        p2 = mock(Polygon.class);
                                                                                                        assertFalse("The method should return false when p1 is null and p2 is not null.", ShapeUtilities.equal(p1, p2));
                                                                                                
                                                                                                        // Case 3: p1 and p2 have different npoints
                                                                                                        p1 = mock(Polygon.class);
                                                                                                        p2 = mock(Polygon.class);
                                                                                                        when(p1.npoints).thenReturn(3);
                                                                                                        when(p2.npoints).thenReturn(4); // Different npoints
                                                                                                        assertFalse("The method should return false when p1 and p2 have different npoints.", ShapeUtilities.equal(p1, p2));
                                                                                                
                                                                                                        // Case 4: p1 and p2 have the same npoints but different xpoints
                                                                                                        when(p1.npoints).thenReturn(3);
                                                                                                        when(p2.npoints).thenReturn(3);
                                                                                                        when(p1.xpoints).thenReturn(new int[]{1, 2, 3});
                                                                                                        when(p2.xpoints).thenReturn(new int[]{4, 5, 6}); // Different xpoints
                                                                                                        when(p1.ypoints).thenReturn(new int[]{7, 8, 9});
                                                                                                        when(p2.ypoints).thenReturn(new int[]{7, 8, 9}); // Same ypoints
                                                                                                        assertFalse("The method should return false when p1 and p2 have different xpoints.", ShapeUtilities.equal(p1, p2));
                                                                                                
                                                                                                        // Case 5: p1 and p2 have the same npoints and same xpoints but different ypoints
                                                                                                        when(p1.xpoints).thenReturn(new int[]{1, 2, 3});
                                                                                                        when(p2.xpoints).thenReturn(new int[]{1, 2, 3}); // Same xpoints
                                                                                                        when(p1.ypoints).thenReturn(new int[]{7, 8, 9});
                                                                                                        when(p2.ypoints).thenReturn(new int[]{10, 11, 12}); // Different ypoints
                                                                                                        assertFalse("The method should return false when p1 and p2 have different ypoints.", ShapeUtilities.equal(p1, p2));
                                                                                                
                                                                                                        // Case 6: p1 and p2 are identical
                                                                                                        when(p1.xpoints).thenReturn(new int[]{1, 2, 3});
                                                                                                        when(p2.xpoints).thenReturn(new int[]{1, 2, 3}); // Same xpoints
                                                                                                        when(p1.ypoints).thenReturn(new int[]{7, 8, 9});
                                                                                                        when(p2.ypoints).thenReturn(new int[]{7, 8, 9}); // Same ypoints
                                                                                                        assertTrue("The method should return true when p1 and p2 are identical.", ShapeUtilities.equal(p1, p2));
                                                                                                    }

    @Test
                                                                                                    public void testEqualWithNullSecondPath() {
                                                                                                        // Arrange
                                                                                                        GeneralPath p1 = mock(GeneralPath.class);
                                                                                                        GeneralPath p2 = null;
                                                                                                
                                                                                                        // Mock the behavior of p1
                                                                                                        PathIterator iterator1 = mock(PathIterator.class);
                                                                                                        when(p1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                        when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                        when(iterator1.isDone()).thenReturn(true);
                                                                                                
                                                                                                        // Act
                                                                                                        boolean result = ShapeUtilities.equal(p1, p2);
                                                                                                
                                                                                                        // Assert
                                                                                                        assertFalse("The method should return false when p2 is null and p1 is not null.", result);
                                                                                                    }

    @Test
                                                                                            public void testEqualWithUnequalFrames() {
                                                                                                // Mock two Ellipse2D objects
                                                                                                Ellipse2D e1 = mock(Ellipse2D.class);
                                                                                                Ellipse2D e2 = mock(Ellipse2D.class);
                                                                                            
                                                                                                // Mock the getFrame() method to return different frames
                                                                                                Rectangle2D frame1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                                                                Rectangle2D frame2 = new Rectangle2D.Double(0, 0, 20, 20);
                                                                                                when(e1.getFrame()).thenReturn(frame1);
                                                                                                when(e2.getFrame()).thenReturn(frame2);
                                                                                            
                                                                                                // Call the equal method
                                                                                                boolean result = ShapeUtilities.equal(e1, e2);
                                                                                            
                                                                                                // Assert that the result is false, as the frames are not equal
                                                                                                assertFalse("The frames are not equal, so the method should return false.", result);
                                                                                            }

    @Test
                                                                                            public void testEqualGeneralPathMutation() {
                                                                                                // Create two GeneralPath objects that should be equal
                                                                                                GeneralPath path1 = new GeneralPath();
                                                                                                path1.moveTo(0, 0);
                                                                                                path1.lineTo(1, 1);
                                                                                                path1.closePath();
                                                                                        
                                                                                                GeneralPath path2 = new GeneralPath();
                                                                                                path2.moveTo(0, 0);
                                                                                                path2.lineTo(1, 1);
                                                                                                path2.closePath();
                                                                                        
                                                                                                // Mock the behavior of the equal method for GeneralPath
                                                                                                ShapeUtilities shapeUtilities = mock(ShapeUtilities.class);
                                                                                                when(shapeUtilities.equal(path1, path2)).thenReturn(true);
                                                                                        
                                                                                                // Test that the original method considers them equal
                                                                                                assertTrue(shapeUtilities.equal(path1, path2));
                                                                                        
                                                                                                // Now test the mutated behavior
                                                                                                // The mutation changes the PathIterator, which might affect the equality check
                                                                                                // We need to ensure that the mutation causes the paths to be considered unequal
                                                                                                // if the transformation affects the path in any way.
                                                                                        
                                                                                                // Create a slightly different GeneralPath that should not be equal
                                                                                                GeneralPath path3 = new GeneralPath();
                                                                                                path3.moveTo(0, 0);
                                                                                                path3.lineTo(1, 2); // Different endpoint
                                                                                                path3.closePath();
                                                                                        
                                                                                                // Test that the mutated method does not consider them equal
                                                                                                assertFalse(shapeUtilities.equal(path1, path3));
                                                                                            }

    @Test
                                                                                            public void testEqual_GeneralPath_MutantDetection() {
                                                                                                // Arrange
                                                                                                GeneralPath path1 = mock(GeneralPath.class);
                                                                                                GeneralPath path2 = mock(GeneralPath.class);
                                                                                        
                                                                                                // Mock the behavior of getPathIterator(null) for path1
                                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                                when(path1.getPathIterator(null)).thenReturn(iterator1);
                                                                                        
                                                                                                // Mock the behavior of getPathIterator(null) for path2
                                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                                                when(path2.getPathIterator(null)).thenReturn(iterator2);
                                                                                        
                                                                                                // Mock the behavior of getPathIterator(new AffineTransform()) for path1
                                                                                                PathIterator mutatedIterator1 = mock(PathIterator.class);
                                                                                                when(path1.getPathIterator(any(AffineTransform.class))).thenReturn(mutatedIterator1);
                                                                                        
                                                                                                // Mock the behavior of getPathIterator(new AffineTransform()) for path2
                                                                                                PathIterator mutatedIterator2 = mock(PathIterator.class);
                                                                                                when(path2.getPathIterator(any(AffineTransform.class))).thenReturn(mutatedIterator2);
                                                                                        
                                                                                                // Act
                                                                                                boolean resultOriginal = ShapeUtilities.equal(path1, path2); // This should call the original logic
                                                                                                boolean resultMutated = ShapeUtilities.equal(path1, path2); // This should call the mutated logic
                                                                                        
                                                                                                // Assert
                                                                                                assertTrue("The original logic should return true for equal paths", resultOriginal);
                                                                                                assertFalse("The mutated logic should return false for equal paths", resultMutated);
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_BothNull() {
                                                                                                // Test case where both Arc2D objects are null
                                                                                                assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_FirstNull() {
                                                                                                // Test case where the first Arc2D object is null
                                                                                                Arc2D arc2 = mock(Arc2D.class);
                                                                                                assertFalse(ShapeUtilities.equal((Arc2D) null, arc2));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_SecondNull() {
                                                                                                // Test case where the second Arc2D object is null
                                                                                                Arc2D arc1 = mock(Arc2D.class);
                                                                                                assertFalse(ShapeUtilities.equal(arc1, (Arc2D) null));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_DifferentFrames() {
                                                                                                // Test case where Arc2D objects have different frames
                                                                                                Arc2D arc1 = mock(Arc2D.class);
                                                                                                Arc2D arc2 = mock(Arc2D.class);
                                                                                        
                                                                                                when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 20, 20));
                                                                                        
                                                                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_DifferentAngleStart() {
                                                                                                // Test case where Arc2D objects have different starting angles
                                                                                                Arc2D arc1 = mock(Arc2D.class);
                                                                                                Arc2D arc2 = mock(Arc2D.class);
                                                                                        
                                                                                                when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc2.getAngleStart()).thenReturn(45.0);
                                                                                        
                                                                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_DifferentAngleExtent() {
                                                                                                // Test case where Arc2D objects have different angle extents
                                                                                                Arc2D arc1 = mock(Arc2D.class);
                                                                                                Arc2D arc2 = mock(Arc2D.class);
                                                                                        
                                                                                                when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                when(arc2.getAngleExtent()).thenReturn(180.0);
                                                                                        
                                                                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_DifferentArcType() {
                                                                                                // Test case where Arc2D objects have different arc types
                                                                                                Arc2D arc1 = mock(Arc2D.class);
                                                                                                Arc2D arc2 = mock(Arc2D.class);
                                                                                        
                                                                                                when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                                when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                when(arc2.getArcType()).thenReturn(Arc2D.CHORD);
                                                                                        
                                                                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                                            }

    @Test
                                                                                            public void testEqualArc2D_EqualArcs() {
                                                                                                // Test case where Arc2D objects are equal
                                                                                                Arc2D arc1 = mock(Arc2D.class);
                                                                                                Arc2D arc2 = mock(Arc2D.class);
                                                                                        
                                                                                                when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                                                when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                                when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                                when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                                when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                                when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                        
                                                                                                assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                                            }

    @Test
                                                                                            public void testEqualPolygonWithPathIteratorMutation() {
                                                                                                // Create two identical polygons
                                                                                                Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 0}, 3);
                                                                                                Polygon p2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 0}, 3);
                                                                                        
                                                                                                // Mock the PathIterator to simulate the mutation
                                                                                                PathIterator mockIterator1 = mock(PathIterator.class);
                                                                                                PathIterator mockIterator2 = mock(PathIterator.class);
                                                                                        
                                                                                                // Configure the mock to simulate the behavior of getPathIterator(null) vs getPathIterator(new AffineTransform())
                                                                                                when(p1.getPathIterator(null)).thenReturn(mockIterator1);
                                                                                                when(p1.getPathIterator(new AffineTransform())).thenReturn(mockIterator2);
                                                                                        
                                                                                                // Assume the mockIterator1 and mockIterator2 behave differently
                                                                                                when(mockIterator1.isDone()).thenReturn(true);
                                                                                                when(mockIterator2.isDone()).thenReturn(false);
                                                                                        
                                                                                                // Test the equal method with the mutated behavior
                                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                                        
                                                                                                // Assert that the mutation causes a difference in behavior
                                                                                                assertFalse("The mutation should cause the polygons to be considered not equal", result);
                                                                                            }

    @Test
                                                                                            public void testEqualDetectsMutant() {
                                                                                                // Mocking GeneralPath objects for p1 and p2
                                                                                                GeneralPath p1 = mock(GeneralPath.class);
                                                                                                GeneralPath p2 = mock(GeneralPath.class);
                                                                                        
                                                                                                // Mocking PathIterator objects for p1 and p2
                                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                                        
                                                                                                // Setting up the behavior of p1 and p2
                                                                                                when(p1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                when(p2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                                when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                                                                when(p2.getPathIterator(null)).thenReturn(iterator2);
                                                                                        
                                                                                                // Setting up the behavior of iterator1 and iterator2
                                                                                                when(iterator1.isDone()).thenReturn(false, true); // First call: not done, second call: done
                                                                                                when(iterator2.isDone()).thenReturn(false, true); // First call: not done, second call: done
                                                                                                when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_LINETO);
                                                                                                when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_LINETO);
                                                                                                // Mocking Arrays.equals to return true for the comparison of coordinates
                                                                                                when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                                when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                        
                                                                                                // Call the method under test
                                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                                        
                                                                                                // Assertions
                                                                                                assertTrue("The original method should return true for equal shapes.", result);
                                                                                        
                                                                                                // Verifying that the PathIterator for p1 was obtained with a null AffineTransform
                                                                                                verify(p1).getPathIterator(null);
                                                                                        
                                                                                                // Detecting the mutant
                                                                                                // If the mutant is present, the behavior would differ because of the use of a new AffineTransform.
                                                                                                // To simulate this, we can explicitly check that getPathIterator(null) is called instead of getPathIterator(new AffineTransform()).
                                                                                                verify(p1, never()).getPathIterator(any(AffineTransform.class));
                                                                                            }

    @Test
                                                                                    public void testEqualLine2DWithMutant() {
                                                                                        // Create two Line2D objects that should be equal
                                                                                        Line2D line1 = new Line2D.Double(0, 0, 1, 1);
                                                                                        Line2D line2 = new Line2D.Double(0, 0, 1, 1);
                                                                                    
                                                                                        // Test with the original method logic
                                                                                        // Using the static method from ShapeUtilities class
                                                                                        boolean originalResult = ShapeUtilities.equal(line1, line2);
                                                                                        assertTrue("Original lines should be equal", originalResult);
                                                                                    
                                                                                        // Test with the mutated logic
                                                                                        // Simulate the mutation effect by overriding the behavior using reflection
                                                                                        try {
                                                                                            // Obtain the equal method using reflection
                                                                                            java.lang.reflect.Method equalWithMutationMethod = ShapeUtilities.class.getDeclaredMethod("equal", Line2D.class, Line2D.class);
                                                                                            equalWithMutationMethod.setAccessible(true);
                                                                                    
                                                                                            // Simulate mutation by invoking the method with altered behavior
                                                                                            // (Assume mutation changes the behavior in some way, e.g., comparing PathIterator differently)
                                                                                            boolean mutatedResult = (boolean) equalWithMutationMethod.invoke(null, line1, line2);
                                                                                    
                                                                                            // Assert the mutated result
                                                                                            assertFalse("Mutated lines should not be equal due to PathIterator behavior", mutatedResult);
                                                                                        } catch (Exception e) {
                                                                                            fail("Reflection failed: " + e.getMessage());
                                                                                        }
                                                                                    }

    @Test
                                                                                    public void testEqualGeneralPathMutation1() {
                                                                                        // Create two GeneralPath objects
                                                                                        GeneralPath path1 = new GeneralPath();
                                                                                        path1.moveTo(0, 0);
                                                                                        path1.lineTo(1, 1);
                                                                                
                                                                                        GeneralPath path2 = new GeneralPath();
                                                                                        path2.moveTo(0, 0);
                                                                                        path2.lineTo(1, 1);
                                                                                
                                                                                        // Mock the behavior of the path iterator to simulate the mutation
                                                                                        GeneralPath mockPath2 = mock(GeneralPath.class);
                                                                                        when(mockPath2.getPathIterator(null)).thenReturn(path2.getPathIterator(null));
                                                                                        when(mockPath2.getPathIterator(new AffineTransform())).thenReturn(path2.getPathIterator(new AffineTransform()));
                                                                                
                                                                                        // Test the equality using the original method
                                                                                        boolean resultOriginal = ShapeUtilities.equal(path1, path2);
                                                                                        assertTrue("The paths should be equal using the original method", resultOriginal);
                                                                                
                                                                                        // Test the equality using the mutated method
                                                                                        boolean resultMutated = ShapeUtilities.equal(path1, mockPath2);
                                                                                        assertFalse("The paths should not be equal using the mutated method", resultMutated);
                                                                                    }

    @Test
                                                                                    public void testEqualLine2DWithMutation() {
                                                                                        // Create two identical Line2D objects
                                                                                        Line2D line1 = new Line2D.Double(0, 0, 1, 1);
                                                                                        Line2D line2 = new Line2D.Double(0, 0, 1, 1);
                                                                                
                                                                                        // Assert that the original method should return true for equal lines
                                                                                        assertTrue("Lines should be equal", ShapeUtilities.equal(line1, line2));
                                                                                
                                                                                        // Now, simulate the mutation by applying a transformation to line2
                                                                                        AffineTransform transform = new AffineTransform();
                                                                                        transform.translate(1, 1); // Apply a simple translation
                                                                                
                                                                                        // Create a transformed version of line2
                                                                                        Line2D transformedLine2 = (Line2D) transform.createTransformedShape(line2);
                                                                                
                                                                                        // Assert that the mutated method should return false for transformed lines
                                                                                        // This is where the mutation would cause a failure if not detected
                                                                                        assertFalse("Lines should not be equal after transformation", ShapeUtilities.equal(line1, transformedLine2));
                                                                                    }

    @Test
                                                                                    public void testEqualGeneralPath() {
                                                                                        // Create two identical GeneralPath objects
                                                                                        GeneralPath path1 = new GeneralPath();
                                                                                        path1.moveTo(0, 0);
                                                                                        path1.lineTo(1, 1);
                                                                                        path1.closePath();
                                                                                
                                                                                        GeneralPath path2 = new GeneralPath();
                                                                                        path2.moveTo(0, 0);
                                                                                        path2.lineTo(1, 1);
                                                                                        path2.closePath();
                                                                                
                                                                                        // Test that two identical paths are considered equal
                                                                                        assertTrue("Identical paths should be equal", ShapeUtilities.equal(path1, path2));
                                                                                
                                                                                        // Modify path2 slightly to test inequality
                                                                                        path2.lineTo(2, 2); // Adding an extra line segment
                                                                                
                                                                                        // Test that the paths are no longer equal
                                                                                        assertFalse("Paths with different segments should not be equal", ShapeUtilities.equal(path1, path2));
                                                                                
                                                                                        // Reset path2 to be identical to path1 again
                                                                                        path2 = new GeneralPath();
                                                                                        path2.moveTo(0, 0);
                                                                                        path2.lineTo(1, 1);
                                                                                        path2.closePath();
                                                                                
                                                                                        // Mock the PathIterator to simulate the effect of the mutation
                                                                                        PathIterator mockIterator1 = mock(PathIterator.class);
                                                                                        PathIterator mockIterator2 = mock(PathIterator.class);
                                                                                
                                                                                        when(path1.getPathIterator(null)).thenReturn(mockIterator1);
                                                                                        when(path2.getPathIterator(null)).thenReturn(mockIterator2);
                                                                                
                                                                                        // Ensure that the mock iterators behave identically
                                                                                        when(mockIterator1.isDone()).thenReturn(false, true);
                                                                                        when(mockIterator2.isDone()).thenReturn(false, true);
                                                                                        when(mockIterator1.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                        when(mockIterator2.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                
                                                                                        // Test that the paths are still considered equal with mocked iterators
                                                                                        assertTrue("Identical paths with mocked iterators should be equal", ShapeUtilities.equal(path1, path2));
                                                                                    }

    @Test
                                                                                    public void testEqualArc2DWithMutant() {
                                                                                        // Create two Arc2D objects
                                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                                
                                                                                        // Set up the mock behavior for arc1
                                                                                        when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 100, 100));
                                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                
                                                                                        // Set up the mock behavior for arc2
                                                                                        when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 100, 100));
                                                                                        when(arc2.getAngleStart()).thenReturn(0.0);
                                                                                        when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                                        when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                                                
                                                                                        // Mock the PathIterator behavior
                                                                                        PathIterator pathIterator1 = mock(PathIterator.class);
                                                                                        PathIterator pathIterator2 = mock(PathIterator.class);
                                                                                
                                                                                        when(arc1.getPathIterator(null)).thenReturn(pathIterator1);
                                                                                        when(arc2.getPathIterator(null)).thenReturn(pathIterator2);
                                                                                
                                                                                        // Assume that the path iterators are equal when no AffineTransform is applied
                                                                                        when(pathIterator1.equals(pathIterator2)).thenReturn(true);
                                                                                
                                                                                        // Now test the equal method
                                                                                        boolean result = ShapeUtilities.equal(arc1, arc2);
                                                                                
                                                                                        // Verify that the result is true, as both arcs are equal
                                                                                        assertTrue(result);
                                                                                
                                                                                        // Now simulate the mutant behavior by changing the PathIterator behavior
                                                                                        when(arc2.getPathIterator(any(AffineTransform.class))).thenReturn(mock(PathIterator.class));
                                                                                
                                                                                        // Test the equal method again, expecting it to fail due to the mutant
                                                                                        result = ShapeUtilities.equal(arc1, arc2);
                                                                                
                                                                                        // The result should be false because the mutant changes the behavior
                                                                                        assertFalse(result);
                                                                                    }

    @Test
                                                                                    public void testEqualDetectMutant() {
                                                                                        // Mocking GeneralPath objects
                                                                                        GeneralPath p1 = mock(GeneralPath.class);
                                                                                        GeneralPath p2 = mock(GeneralPath.class);
                                                                                
                                                                                        // Mocking PathIterator objects
                                                                                        PathIterator iterator1 = mock(PathIterator.class);
                                                                                        PathIterator iterator2WithNullTransform = mock(PathIterator.class);
                                                                                        PathIterator iterator2WithAffineTransform = mock(PathIterator.class);
                                                                                
                                                                                        // Mocking behavior for p1 and p2
                                                                                        when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                                                        when(p2.getPathIterator(null)).thenReturn(iterator2WithNullTransform);
                                                                                        when(p2.getPathIterator(any(AffineTransform.class))).thenReturn(iterator2WithAffineTransform);
                                                                                
                                                                                        // Mocking winding rules
                                                                                        when(p1.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                        when(p2.getWindingRule()).thenReturn(PathIterator.WIND_EVEN_ODD);
                                                                                
                                                                                        // Mocking iterator behavior for both iterators
                                                                                        double[] d1 = new double[6];
                                                                                        double[] d2 = new double[6];
                                                                                        when(iterator1.isDone()).thenReturn(false, true); // First call returns false, second call returns true
                                                                                        when(iterator2WithNullTransform.isDone()).thenReturn(false, true); // Same behavior for null transform iterator
                                                                                        when(iterator2WithAffineTransform.isDone()).thenReturn(false, true); // Same behavior for affine transform iterator
                                                                                
                                                                                        when(iterator1.currentSegment(d1)).thenReturn(PathIterator.SEG_MOVETO);
                                                                                        when(iterator2WithNullTransform.currentSegment(d2)).thenReturn(PathIterator.SEG_MOVETO);
                                                                                        when(iterator2WithAffineTransform.currentSegment(d2)).thenReturn(PathIterator.SEG_MOVETO);
                                                                                
                                                                                        when(iterator1.isDone()).thenReturn(true);
                                                                                        when(iterator2WithNullTransform.isDone()).thenReturn(true);
                                                                                        when(iterator2WithAffineTransform.isDone()).thenReturn(true);
                                                                                
                                                                                        // Mocking equality of coordinates
                                                                                        when(Arrays.equals(d1, d2)).thenReturn(true);
                                                                                
                                                                                        // Test case for original behavior (null transform)
                                                                                        boolean resultOriginal = ShapeUtilities.equal(p1, p2);
                                                                                        assertTrue("The original method should return true for identical shapes.", resultOriginal);
                                                                                
                                                                                        // Test case for mutated behavior (AffineTransform)
                                                                                        boolean resultMutated = ShapeUtilities.equal(p1, p2);
                                                                                        assertFalse("The mutated method should return false due to AffineTransform affecting PathIterator.", resultMutated);
                                                                                    }

    @Test
                                                                            public void testEqualGeneralPathMutation2() throws Exception {
                                                                                // Create mock GeneralPath objects
                                                                                GeneralPath p1 = mock(GeneralPath.class);
                                                                                GeneralPath p2 = mock(GeneralPath.class);
                                                                            
                                                                                // Use reflection to set private fields in GeneralPath
                                                                                Field npointsField = GeneralPath.class.getDeclaredField("npoints");
                                                                                npointsField.setAccessible(true);
                                                                                npointsField.set(p1, 3);
                                                                                npointsField.set(p2, 3);
                                                                            
                                                                                Field xpointsField = GeneralPath.class.getDeclaredField("xpoints");
                                                                                xpointsField.setAccessible(true);
                                                                                xpointsField.set(p1, new int[]{0, 1, 2});
                                                                                xpointsField.set(p2, new int[]{0, 1, 2});
                                                                            
                                                                                Field ypointsField = GeneralPath.class.getDeclaredField("ypoints");
                                                                                ypointsField.setAccessible(true);
                                                                                ypointsField.set(p1, new int[]{0, 1, 2});
                                                                                ypointsField.set(p2, new int[]{0, 1, 2});
                                                                            
                                                                                // Set up mock behavior for p1
                                                                                when(p1.getPathIterator(null)).thenReturn(mock(PathIterator.class));
                                                                                when(p1.getPathIterator(new AffineTransform())).thenReturn(mock(PathIterator.class));
                                                                            
                                                                                // Set up mock behavior for p2
                                                                                when(p2.getPathIterator(null)).thenReturn(mock(PathIterator.class));
                                                                                when(p2.getPathIterator(new AffineTransform())).thenReturn(mock(PathIterator.class));
                                                                            
                                                                                // Test the equal method
                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                            
                                                                                // Assert that the result is true, as the paths should be equal
                                                                                assertTrue(result);
                                                                            
                                                                                // Verify that the correct method was called on p2
                                                                                verify(p2).getPathIterator(null); // This should be called, not getPathIterator(new AffineTransform())
                                                                            }

    @Test
                                                                            public void testEqual_Line2D_MutantDetection() {
                                                                                // Arrange
                                                                                Line2D line1 = mock(Line2D.class);
                                                                                Line2D line2 = mock(Line2D.class);
                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                        
                                                                                // Mock behavior of PathIterator for line1
                                                                                when(line1.getPathIterator(null)).thenReturn(iterator1);
                                                                                when(iterator1.isDone()).thenReturn(false); // iterator1 is not done
                                                                        
                                                                                // Mock behavior of PathIterator for line2
                                                                                when(line2.getPathIterator(null)).thenReturn(iterator2);
                                                                                when(iterator2.isDone()).thenReturn(true); // iterator2 is done
                                                                        
                                                                                // Act
                                                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                                        
                                                                                // Assert
                                                                                // The mutant changes the logic to only check iterator2.isDone(), ignoring iterator1.isDone().
                                                                                // This test ensures that both iterators are checked, and the method should return false.
                                                                                assertFalse("The mutant was not detected. Both iterators must be checked.", result);
                                                                            }

    @Test
                                                                            public void testEqualWithDifferentIteratorCompletion() {
                                                                                // Create mock PathIterators
                                                                                PathIterator iterator1 = mock(PathIterator.class);
                                                                                PathIterator iterator2 = mock(PathIterator.class);
                                                                        
                                                                                // Mock behavior for iterator1
                                                                                when(iterator1.isDone()).thenReturn(false, false, true); // Not done at first, done after two calls
                                                                                when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO);
                                                                                when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO);
                                                                                when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_CLOSE);
                                                                                doNothing().when(iterator1).next();
                                                                        
                                                                                // Mock behavior for iterator2
                                                                                when(iterator2.isDone()).thenReturn(false, true); // Done after one call
                                                                                when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                                when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_CLOSE);
                                                                                doNothing().when(iterator2).next();
                                                                        
                                                                                // Create mock GeneralPath objects
                                                                                GeneralPath p1 = mock(GeneralPath.class);
                                                                                GeneralPath p2 = mock(GeneralPath.class);
                                                                        
                                                                                // Mock the getPathIterator method
                                                                                when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                                                when(p2.getPathIterator(null)).thenReturn(iterator2);
                                                                        
                                                                                // Mock the getWindingRule method
                                                                                when(p1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                                when(p2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                        
                                                                                // Test the equal method
                                                                                boolean result = ShapeUtilities.equal(p1, p2);
                                                                        
                                                                                // Assert that the result is false, as the iterators do not complete simultaneously
                                                                                assertFalse("The method should return false when iterators do not complete simultaneously.", result);
                                                                            }

    @Test
                                                                        public void testEqualWithMutant() {
                                                                            // Mock the Ellipse2D objects
                                                                            Ellipse2D e1 = mock(Ellipse2D.class);
                                                                            Ellipse2D e2 = mock(Ellipse2D.class);
                                                                    
                                                                            // Mock the behavior of getFrame() to return different frames
                                                                            when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                            when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                                    
                                                                            // Mock iterators and their isDone() methods
                                                                            // Note: Iterator is not directly used in the provided code, so this part is speculative
                                                                            // and may not be necessary. Removing it unless explicitly required.
                                                                            // Iterator iterator1 = mock(Iterator.class);
                                                                            // Iterator iterator2 = mock(Iterator.class);
                                                                    
                                                                            // Call the method under test
                                                                            boolean result = ShapeUtilities.equal(e1, e2);
                                                                    
                                                                            // Assert that the result is false, which would catch the mutant
                                                                            assertFalse("The test should detect the mutant by returning false", result);
                                                                        }

    @Test
                                                                        public void testEqual_MutantDetection() {
                                                                            // Arrange
                                                                            Polygon p1 = mock(Polygon.class);
                                                                            Polygon p2 = mock(Polygon.class);
                                                                    
                                                                            // Mocking the behavior of the polygons
                                                                            when(p1.npoints).thenReturn(3);
                                                                            when(p2.npoints).thenReturn(3);
                                                                    
                                                                            when(p1.xpoints).thenReturn(new int[]{1, 2, 3});
                                                                            when(p2.xpoints).thenReturn(new int[]{1, 2, 3});
                                                                    
                                                                            when(p1.ypoints).thenReturn(new int[]{4, 5, 6});
                                                                            when(p2.ypoints).thenReturn(new int[]{4, 5, 6});
                                                                    
                                                                            // Simulating the behavior of the iterators
                                                                            // Since IteratorMock is not defined, let's assume we need to simulate this behavior
                                                                            // We will assume that the ShapeUtilities.equal method uses some internal logic
                                                                            // that we need to mock or simulate. For now, we will focus on the test structure.
                                                                    
                                                                            // Act
                                                                            boolean result = ShapeUtilities.equal(p1, p2);
                                                                    
                                                                            // Assert
                                                                            // The original method should return false when iterator1.isDone() is false,
                                                                            // but the mutant will incorrectly return true because it ignores iterator1.isDone().
                                                                            assertFalse("The test should detect the mutant by ensuring iterator1.isDone() is considered.", result);
                                                                        }

    @Test
                                                                    public void testEqualArc2D1() {
                                                                        // Create mock Arc2D objects
                                                                        Arc2D arc1 = mock(Arc2D.class);
                                                                        Arc2D arc2 = mock(Arc2D.class);
                                                                
                                                                        // Test case where both arcs are null
                                                                        assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                                                                
                                                                        // Test case where one arc is null
                                                                        assertFalse(ShapeUtilities.equal(arc1, null));
                                                                        assertFalse(ShapeUtilities.equal(null, arc2));
                                                                
                                                                        // Test case where frames are not equal
                                                                        when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 1, 1));
                                                                        when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(1, 1, 1, 1));
                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        // Test case where angle starts are not equal
                                                                        when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 1, 1));
                                                                        when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 1, 1));
                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                        when(arc2.getAngleStart()).thenReturn(1.0);
                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        // Test case where angle extents are not equal
                                                                        when(arc1.getAngleStart()).thenReturn(0.0);
                                                                        when(arc2.getAngleStart()).thenReturn(0.0);
                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                        when(arc2.getAngleExtent()).thenReturn(180.0);
                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        // Test case where arc types are not equal
                                                                        when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                        when(arc2.getAngleExtent()).thenReturn(90.0);
                                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                        when(arc2.getArcType()).thenReturn(Arc2D.CHORD);
                                                                        assertFalse(ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        // Test case where all properties are equal
                                                                        when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                        when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                                        assertTrue(ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        // Additional test case to capture the mutant
                                                                        // Assuming isDone() is a method that checks if the arc is complete
                                                                        // Since Arc2D does not have an isDone method, we need to remove these tests
                                                                        // or replace them with valid Arc2D methods.
                                                                
                                                                        // The following lines are commented out because Arc2D does not have an isDone method.
                                                                        // Uncomment and modify them if there is a valid method to test.
                                                                        /*
                                                                        when(arc1.isDone()).thenReturn(false);
                                                                        when(arc2.isDone()).thenReturn(true);
                                                                        assertFalse("Mutant should be captured here", ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        when(arc1.isDone()).thenReturn(true);
                                                                        when(arc2.isDone()).thenReturn(false);
                                                                        assertFalse("Mutant should be captured here", ShapeUtilities.equal(arc1, arc2));
                                                                
                                                                        when(arc1.isDone()).thenReturn(true);
                                                                        when(arc2.isDone()).thenReturn(true);
                                                                        assertTrue("Both arcs are done, should be equal", ShapeUtilities.equal(arc1, arc2));
                                                                        */
                                                                    }

    @Test
                                                                public void testEqualWithSurvivedMutant() {
                                                                    // Test case to detect the mutant
                                                                    // Create two Line2D objects that are equal
                                                                    Line2D line1 = new Line2D.Double(0, 0, 1, 1);
                                                                    Line2D line2 = new Line2D.Double(0, 0, 1, 1);
                                                            
                                                                    // Create two Line2D objects that are not equal
                                                                    Line2D line3 = new Line2D.Double(0, 0, 2, 2);
                                                                    Line2D line4 = new Line2D.Double(0, 0, 1, 1);
                                                            
                                                                    // Test equal method for Line2D objects
                                                                    assertTrue("Expected lines to be equal", ShapeUtilities.equal(line1, line2));
                                                                    assertFalse("Expected lines to not be equal", ShapeUtilities.equal(line3, line4));
                                                            
                                                                    // Create two Ellipse2D objects that are equal
                                                                    Ellipse2D ellipse1 = new Ellipse2D.Double(0, 0, 5, 5);
                                                                    Ellipse2D ellipse2 = new Ellipse2D.Double(0, 0, 5, 5);
                                                            
                                                                    // Create two Ellipse2D objects that are not equal
                                                                    Ellipse2D ellipse3 = new Ellipse2D.Double(0, 0, 10, 10);
                                                                    Ellipse2D ellipse4 = new Ellipse2D.Double(0, 0, 5, 5);
                                                            
                                                                    // Test equal method for Ellipse2D objects
                                                                    assertTrue("Expected ellipses to be equal", ShapeUtilities.equal(ellipse1, ellipse2));
                                                                    assertFalse("Expected ellipses to not be equal", ShapeUtilities.equal(ellipse3, ellipse4));
                                                            
                                                                    // Create two Arc2D objects that are equal
                                                                    Arc2D arc1 = new Arc2D.Double(0, 0, 5, 5, 0, 90, Arc2D.OPEN);
                                                                    Arc2D arc2 = new Arc2D.Double(0, 0, 5, 5, 0, 90, Arc2D.OPEN);
                                                            
                                                                    // Create two Arc2D objects that are not equal
                                                                    Arc2D arc3 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.OPEN);
                                                                    Arc2D arc4 = new Arc2D.Double(0, 0, 5, 5, 0, 90, Arc2D.OPEN);
                                                            
                                                                    // Test equal method for Arc2D objects
                                                                    assertTrue("Expected arcs to be equal", ShapeUtilities.equal(arc1, arc2));
                                                                    assertFalse("Expected arcs to not be equal", ShapeUtilities.equal(arc3, arc4));
                                                            
                                                                    // Create two Polygon objects that are equal
                                                                    Polygon polygon1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                    Polygon polygon2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                            
                                                                    // Create two Polygon objects that are not equal
                                                                    Polygon polygon3 = new Polygon(new int[]{0, 1, 3}, new int[]{0, 1, 2}, 3);
                                                                    Polygon polygon4 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                            
                                                                    // Test equal method for Polygon objects
                                                                    assertTrue("Expected polygons to be equal", ShapeUtilities.equal(polygon1, polygon2));
                                                                    assertFalse("Expected polygons to not be equal", ShapeUtilities.equal(polygon3, polygon4));
                                                            
                                                                    // Create two GeneralPath objects that are equal
                                                                    GeneralPath path1 = new GeneralPath();
                                                                    path1.moveTo(0, 0);
                                                                    path1.lineTo(1, 1);
                                                                    path1.closePath();
                                                            
                                                                    GeneralPath path2 = new GeneralPath();
                                                                    path2.moveTo(0, 0);
                                                                    path2.lineTo(1, 1);
                                                                    path2.closePath();
                                                            
                                                                    // Create two GeneralPath objects that are not equal
                                                                    GeneralPath path3 = new GeneralPath();
                                                                    path3.moveTo(0, 0);
                                                                    path3.lineTo(2, 2);
                                                                    path3.closePath();
                                                            
                                                                    GeneralPath path4 = new GeneralPath();
                                                                    path4.moveTo(0, 0);
                                                                    path4.lineTo(1, 1);
                                                                    path4.closePath();
                                                            
                                                                    // Test equal method for GeneralPath objects
                                                                    assertTrue("Expected paths to be equal", ShapeUtilities.equal(path1, path2));
                                                                    assertFalse("Expected paths to not be equal", ShapeUtilities.equal(path3, path4));
                                                            
                                                                    // Test fallback case for ObjectUtilities.equal
                                                                    Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 5, 5);
                                                                    Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 5, 5);
                                                                    Rectangle2D rect3 = new Rectangle2D.Double(0, 0, 10, 10);
                                                            
                                                                    assertTrue("Expected rectangles to be equal", ShapeUtilities.equal(rect1, rect2));
                                                                    assertFalse("Expected rectangles to not be equal", ShapeUtilities.equal(rect1, rect3));
                                                                }

    @Test
                                                                public void testEqual_Line2D_MutantDetection1() {
                                                                    // Arrange: Create mock Line2D objects
                                                                    Line2D line1 = mock(Line2D.class);
                                                                    Line2D line2 = mock(Line2D.class);
                                                            
                                                                    // Mock the behavior of getP1() and getP2() for both lines
                                                                    when(line1.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0));
                                                                    when(line1.getP2()).thenReturn(new java.awt.geom.Point2D.Double(2.0, 2.0));
                                                                    when(line2.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0));
                                                                    when(line2.getP2()).thenReturn(new java.awt.geom.Point2D.Double(2.0, 2.0));
                                                            
                                                                    // Act: Call the equal method
                                                                    boolean result = ShapeUtilities.equal(line1, line2);
                                                            
                                                                    // Assert: Verify the expected behavior
                                                                    assertTrue("The method should return true for equal lines.", result);
                                                            
                                                                    // Additional test to detect the mutant
                                                                    // Modify the behavior of one of the lines to simulate the mutation's effect
                                                                    when(line2.getP2()).thenReturn(new java.awt.geom.Point2D.Double(3.0, 3.0));
                                                                    boolean resultAfterMutation = ShapeUtilities.equal(line1, line2);
                                                            
                                                                    // Assert: The mutated behavior should return false
                                                                    assertFalse("The method should return false for non-equal lines.", resultAfterMutation);
                                                                }

    @Test
                                                                public void testEqualWithNullShapes() {
                                                                    Ellipse2D e1 = null;
                                                                    Ellipse2D e2 = null;
                                                                    assertTrue(ShapeUtilities.equal(e1, e2));
                                                            
                                                                    e1 = new Ellipse2D.Double();
                                                                    assertFalse(ShapeUtilities.equal(e1, e2));
                                                            
                                                                    e2 = new Ellipse2D.Double();
                                                                    assertFalse(ShapeUtilities.equal(null, e2));
                                                                }

    @Test
                                                                public void testEqualWithDifferentFrames() {
                                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                            
                                                                    when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 1, 1));
                                                                    when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 2, 2));
                                                            
                                                                    assertFalse(ShapeUtilities.equal(e1, e2));
                                                                }

    @Test
                                                                public void testEqualWithSameFrames() {
                                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                            
                                                                    Rectangle2D frame = new Rectangle2D.Double(0, 0, 1, 1);
                                                                    when(e1.getFrame()).thenReturn(frame);
                                                                    when(e2.getFrame()).thenReturn(frame);
                                                            
                                                                    assertTrue(ShapeUtilities.equal(e1, e2));
                                                                }

    @Test
                                                                public void testEqualWithBoundaryConditions() {
                                                                    Ellipse2D e1 = mock(Ellipse2D.class);
                                                                    Ellipse2D e2 = mock(Ellipse2D.class);
                                                            
                                                                    // Test with frames that are almost equal but differ slightly
                                                                    when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 1, 1));
                                                                    when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 1.0001, 1.0001));
                                                            
                                                                    assertFalse(ShapeUtilities.equal(e1, e2));
                                                            
                                                                    // Test with frames that are exactly equal
                                                                    when(e1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 1, 1));
                                                                    when(e2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 1, 1));
                                                            
                                                                    assertTrue(ShapeUtilities.equal(e1, e2));
                                                                }

    @Test
                                                                public void testEqualArc2D_MutantDetection() {
                                                                    // Create mock Arc2D objects
                                                                    Arc2D arc1 = mock(Arc2D.class);
                                                                    Arc2D arc2 = mock(Arc2D.class);
                                                            
                                                                    // Set up the mocks to have identical properties
                                                                    when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                                    when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                            
                                                                    when(arc1.getAngleStart()).thenReturn(0.0);
                                                                    when(arc2.getAngleStart()).thenReturn(0.0);
                                                            
                                                                    when(arc1.getAngleExtent()).thenReturn(90.0);
                                                                    when(arc2.getAngleExtent()).thenReturn(90.0);
                                                            
                                                                    when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                                    when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                            
                                                                    // Assuming there are iterators involved, we need to ensure they are "done"
                                                                    // This part is hypothetical as we don't have the actual iterator code
                                                                    // But we assume that the mutation affects the logic that checks iterators
                                                                    // We simulate the scenario where both iterators are done
                                                                    // In reality, you would need to mock or simulate this behavior
                                                            
                                                                    // Call the method under test
                                                                    boolean result = ShapeUtilities.equal(arc1, arc2);
                                                            
                                                                    // Assert that the method should return true, indicating equality
                                                                    // This assertion should fail if the mutant is present
                                                                    assertTrue("The arcs should be considered equal, but the mutant causes false.", result);
                                                                }

    @Test
                                                                public void testEqual_MutantDetection1() {
                                                                    // Mock the GeneralPath objects
                                                                    GeneralPath p1 = mock(GeneralPath.class);
                                                                    GeneralPath p2 = mock(GeneralPath.class);
                                                            
                                                                    // Mock the PathIterator objects
                                                                    PathIterator iterator1 = mock(PathIterator.class);
                                                                    PathIterator iterator2 = mock(PathIterator.class);
                                                            
                                                                    // Mock behavior for p1 and p2 to return their respective iterators
                                                                    when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                                    when(p2.getPathIterator(null)).thenReturn(iterator2);
                                                            
                                                                    // Mock the winding rule to be the same for both shapes
                                                                    when(p1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                                    when(p2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                                                            
                                                                    // Mock the behavior of the iterators
                                                                    // First iteration: both iterators are not done
                                                                    when(iterator1.isDone()).thenReturn(false, true); // First call: false, Second call: true
                                                                    when(iterator2.isDone()).thenReturn(false, true); // First call: false, Second call: true
                                                            
                                                                    // Mock the segments to be the same for both iterators
                                                                    double[] d1 = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0};
                                                                    double[] d2 = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0};
                                                                    when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                                    when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                            
                                                                    // Mock the arrays to be equal
                                                                    when(iterator1.currentSegment(d1)).thenReturn(PathIterator.SEG_MOVETO);
                                                                    when(iterator2.currentSegment(d2)).thenReturn(PathIterator.SEG_MOVETO);
                                                            
                                                                    // Call the method under test
                                                                    boolean result = ShapeUtilities.equal(p1, p2);
                                                            
                                                                    // Verify the expected behavior
                                                                    assertTrue("The method should return true for equal shapes", result);
                                                            
                                                                    // Verify interactions with the mocked objects
                                                                    verify(iterator1, times(2)).isDone(); // Called twice: once before the loop and once during the loop
                                                                    verify(iterator2, times(2)).isDone();
                                                                    verify(iterator1, times(1)).currentSegment(any(double[].class));
                                                                    verify(iterator2, times(1)).currentSegment(any(double[].class));
                                                                    verify(iterator1, times(1)).next();
                                                                    verify(iterator2, times(1)).next();
                                                                }

    @Test
                                                            public void testEqualPolygonSurvivedMutant() {
                                                                // Create two identical polygons
                                                                Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                                Polygon p2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                        
                                                                // Test case where both polygons are identical
                                                                assertTrue("Identical polygons should be equal", ShapeUtilities.equal(p1, p2));
                                                        
                                                                // Create two polygons with different number of points
                                                                Polygon p3 = new Polygon(new int[]{0, 1}, new int[]{0, 1}, 2);
                                                                Polygon p4 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                        
                                                                // Test case where polygons have different number of points
                                                                assertFalse("Polygons with different number of points should not be equal", ShapeUtilities.equal(p3, p4));
                                                        
                                                                // Create two polygons with different xpoints
                                                                Polygon p5 = new Polygon(new int[]{0, 1, 3}, new int[]{0, 1, 2}, 3);
                                                                Polygon p6 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                        
                                                                // Test case where polygons have different xpoints
                                                                assertFalse("Polygons with different xpoints should not be equal", ShapeUtilities.equal(p5, p6));
                                                        
                                                                // Create two polygons with different ypoints
                                                                Polygon p7 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 3}, 3);
                                                                Polygon p8 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
                                                        
                                                                // Test case where polygons have different ypoints
                                                                assertFalse("Polygons with different ypoints should not be equal", ShapeUtilities.equal(p7, p8));
                                                        
                                                                // Test case where both polygons are null
                                                                assertTrue("Both null polygons should be equal", ShapeUtilities.equal((Polygon) null, (Polygon) null));
                                                        
                                                                // Test case where one polygon is null
                                                                assertFalse("Polygon and null should not be equal", ShapeUtilities.equal(p1, null));
                                                                assertFalse("Null and polygon should not be equal", ShapeUtilities.equal(null, p2));
                                                            }

    @Test
                                                        public void testEqual_MutantDetection2() {
                                                            // Test case 1: Both shapes are null
                                                            Shape s1 = null;
                                                            Shape s2 = null;
                                                            assertTrue("Both shapes are null, should return true", ShapeUtilities.equal(s1, s2));
                                                    
                                                            // Test case 2: One shape is null, the other is not
                                                            s1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                            s2 = null;
                                                            assertFalse("One shape is null, the other is not, should return false", ShapeUtilities.equal(s1, s2));
                                                    
                                                            s1 = null;
                                                            s2 = new Rectangle2D.Double(0, 0, 10, 10);
                                                            assertFalse("One shape is null, the other is not, should return false", ShapeUtilities.equal(s1, s2));
                                                    
                                                            // Test case 3: Both shapes are instances of Line2D but not equal
                                                            Line2D line1 = new Line2D.Double(0, 0, 10, 10);
                                                            Line2D line2 = new Line2D.Double(0, 0, 5, 5);
                                                            assertFalse("Line2D shapes are not equal, should return false", ShapeUtilities.equal(line1, line2));
                                                    
                                                            // Test case 4: Both shapes are instances of Line2D and are equal
                                                            line2 = new Line2D.Double(0, 0, 10, 10);
                                                            assertTrue("Line2D shapes are equal, should return true", ShapeUtilities.equal(line1, line2));
                                                    
                                                            // Test case 5: Both shapes are instances of Ellipse2D but not equal
                                                            Ellipse2D ellipse1 = new Ellipse2D.Double(0, 0, 10, 10);
                                                            Ellipse2D ellipse2 = new Ellipse2D.Double(0, 0, 5, 5);
                                                            assertFalse("Ellipse2D shapes are not equal, should return false", ShapeUtilities.equal(ellipse1, ellipse2));
                                                    
                                                            // Test case 6: Both shapes are instances of Ellipse2D and are equal
                                                            ellipse2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                            assertTrue("Ellipse2D shapes are equal, should return true", ShapeUtilities.equal(ellipse1, ellipse2));
                                                    
                                                            // Test case 7: Both shapes are instances of Arc2D but not equal
                                                            Arc2D arc1 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.OPEN);
                                                            Arc2D arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 45, Arc2D.OPEN);
                                                            assertFalse("Arc2D shapes are not equal, should return false", ShapeUtilities.equal(arc1, arc2));
                                                    
                                                            // Test case 8: Both shapes are instances of Arc2D and are equal
                                                            arc2 = new Arc2D.Double(0, 0, 10, 10, 0, 90, Arc2D.OPEN);
                                                            assertTrue("Arc2D shapes are equal, should return true", ShapeUtilities.equal(arc1, arc2));
                                                    
                                                            // Test case 9: Both shapes are instances of Polygon but not equal
                                                            Polygon polygon1 = new Polygon(new int[]{0, 10, 0}, new int[]{0, 0, 10}, 3);
                                                            Polygon polygon2 = new Polygon(new int[]{0, 5, 0}, new int[]{0, 0, 5}, 3);
                                                            assertFalse("Polygon shapes are not equal, should return false", ShapeUtilities.equal(polygon1, polygon2));
                                                    
                                                            // Test case 10: Both shapes are instances of Polygon and are equal
                                                            polygon2 = new Polygon(new int[]{0, 10, 0}, new int[]{0, 0, 10}, 3);
                                                            assertTrue("Polygon shapes are equal, should return true", ShapeUtilities.equal(polygon1, polygon2));
                                                    
                                                            // Test case 11: Both shapes are instances of GeneralPath but not equal
                                                            GeneralPath path1 = new GeneralPath();
                                                            path1.moveTo(0, 0);
                                                            path1.lineTo(10, 10);
                                                            GeneralPath path2 = new GeneralPath();
                                                            path2.moveTo(0, 0);
                                                            path2.lineTo(5, 5);
                                                            assertFalse("GeneralPath shapes are not equal, should return false", ShapeUtilities.equal(path1, path2));
                                                    
                                                            // Test case 12: Both shapes are instances of GeneralPath and are equal
                                                            path2 = new GeneralPath();
                                                            path2.moveTo(0, 0);
                                                            path2.lineTo(10, 10);
                                                            assertTrue("GeneralPath shapes are equal, should return true", ShapeUtilities.equal(path1, path2));
                                                    
                                                            // Test case 13: Shapes are of different types
                                                            s1 = new Rectangle2D.Double(0, 0, 10, 10);
                                                            s2 = new Ellipse2D.Double(0, 0, 10, 10);
                                                            assertFalse("Shapes are of different types, should return false", ShapeUtilities.equal(s1, s2));
                                                        }

    @Test
                                                        public void testEqualArc2DWithNullSecondArgument() {
                                                            // Arrange
                                                            Arc2D a1 = mock(Arc2D.class);
                                                            Arc2D a2 = null; // This is the key part to catch the mutant
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be false, because a2 is null
                                                            assertFalse("Expected false when second Arc2D is null", result);
                                                        }

    @Test
                                                        public void testEqualArc2DWithBothNullArguments() {
                                                            // Arrange
                                                            Arc2D a1 = null;
                                                            Arc2D a2 = null;
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be true, because both are null
                                                            assertTrue("Expected true when both Arc2D are null", result);
                                                        }

    @Test
                                                        public void testEqualArc2DWithDifferentFrames() {
                                                            // Arrange
                                                            Arc2D a1 = mock(Arc2D.class);
                                                            Arc2D a2 = mock(Arc2D.class);
                                                            when(a1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 20, 20)); // Different frame
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be false, because frames are different
                                                            assertFalse("Expected false when Arc2D frames are different", result);
                                                        }

    @Test
                                                        public void testEqualArc2DWithDifferentAngleStart() {
                                                            // Arrange
                                                            Arc2D a1 = mock(Arc2D.class);
                                                            Arc2D a2 = mock(Arc2D.class);
                                                            when(a1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a1.getAngleStart()).thenReturn(0.0);
                                                            when(a2.getAngleStart()).thenReturn(1.0); // Different angle start
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be false, because angle starts are different
                                                            assertFalse("Expected false when Arc2D angle starts are different", result);
                                                        }

    @Test
                                                        public void testEqualArc2DWithDifferentAngleExtent() {
                                                            // Arrange
                                                            Arc2D a1 = mock(Arc2D.class);
                                                            Arc2D a2 = mock(Arc2D.class);
                                                            when(a1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a1.getAngleStart()).thenReturn(0.0);
                                                            when(a2.getAngleStart()).thenReturn(0.0);
                                                            when(a1.getAngleExtent()).thenReturn(90.0);
                                                            when(a2.getAngleExtent()).thenReturn(180.0); // Different angle extent
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be false, because angle extents are different
                                                            assertFalse("Expected false when Arc2D angle extents are different", result);
                                                        }

    @Test
                                                        public void testEqualArc2DWithDifferentArcType() {
                                                            // Arrange
                                                            Arc2D a1 = mock(Arc2D.class);
                                                            Arc2D a2 = mock(Arc2D.class);
                                                            when(a1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a1.getAngleStart()).thenReturn(0.0);
                                                            when(a2.getAngleStart()).thenReturn(0.0);
                                                            when(a1.getAngleExtent()).thenReturn(90.0);
                                                            when(a2.getAngleExtent()).thenReturn(90.0);
                                                            when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                            when(a2.getArcType()).thenReturn(Arc2D.CHORD); // Different arc type
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be false, because arc types are different
                                                            assertFalse("Expected false when Arc2D arc types are different", result);
                                                        }

    @Test
                                                        public void testEqualArc2DWithIdenticalArcs() {
                                                            // Arrange
                                                            Arc2D a1 = mock(Arc2D.class);
                                                            Arc2D a2 = mock(Arc2D.class);
                                                            when(a1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                                            when(a1.getAngleStart()).thenReturn(0.0);
                                                            when(a2.getAngleStart()).thenReturn(0.0);
                                                            when(a1.getAngleExtent()).thenReturn(90.0);
                                                            when(a2.getAngleExtent()).thenReturn(90.0);
                                                            when(a1.getArcType()).thenReturn(Arc2D.OPEN);
                                                            when(a2.getArcType()).thenReturn(Arc2D.OPEN); // Identical arc type
                                                    
                                                            // Act
                                                            boolean result = ShapeUtilities.equal(a1, a2);
                                                    
                                                            // Assert
                                                            // The expected result should be true, because all properties are identical
                                                            assertTrue("Expected true when Arc2D properties are identical", result);
                                                        }

    @Test
                                                        public void testEqual_MutantDetection3() {
                                                            // Test case to detect the mutant: "return false;" mutated to "return p2 == null;"
                                                    
                                                            // Scenario: p1 is not null, p2 is null
                                                            Polygon p1 = mock(Polygon.class); // Mock p1 to simulate a non-null Polygon
                                                            Polygon p2 = null; // p2 is explicitly set to null
                                                    
                                                            // Define behavior for the mocked Polygon (p1)
                                                            when(p1.npoints).thenReturn(5); // Example: p1 has 5 points
                                                            when(p1.xpoints).thenReturn(new int[]{1, 2, 3, 4, 5});
                                                            when(p1.ypoints).thenReturn(new int[]{1, 2, 3, 4, 5});
                                                    
                                                            // Call the method under test
                                                            boolean result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert the expected behavior
                                                            // The original method should return false when p1 is not null and p2 is null
                                                            assertFalse("The method should return false when p1 is not null and p2 is null.", result);
                                                        }

    @Test
                                                        public void testEqual_OriginalBehavior() {
                                                            // Additional test cases to verify the original behavior of the method
                                                    
                                                            // Scenario: Both p1 and p2 are null
                                                            Polygon p1 = null;
                                                            Polygon p2 = null;
                                                    
                                                            // Call the method under test
                                                            boolean result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert the expected behavior
                                                            assertTrue("The method should return true when both p1 and p2 are null.", result);
                                                    
                                                            // Scenario: p1 and p2 are equal
                                                            p1 = mock(Polygon.class);
                                                            p2 = mock(Polygon.class);
                                                    
                                                            // Define behavior for the mocked Polygons
                                                            when(p1.npoints).thenReturn(3);
                                                            when(p2.npoints).thenReturn(3);
                                                            when(p1.xpoints).thenReturn(new int[]{1, 2, 3});
                                                            when(p2.xpoints).thenReturn(new int[]{1, 2, 3});
                                                            when(p1.ypoints).thenReturn(new int[]{4, 5, 6});
                                                            when(p2.ypoints).thenReturn(new int[]{4, 5, 6});
                                                    
                                                            // Call the method under test
                                                            result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert the expected behavior
                                                            assertTrue("The method should return true when p1 and p2 are equal.", result);
                                                    
                                                            // Scenario: p1 and p2 have different npoints
                                                            when(p2.npoints).thenReturn(4); // Change p2's npoints to 4
                                                    
                                                            // Call the method under test
                                                            result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert the expected behavior
                                                            assertFalse("The method should return false when p1 and p2 have different npoints.", result);
                                                    
                                                            // Scenario: p1 and p2 have different xpoints
                                                            when(p2.npoints).thenReturn(3); // Restore p2's npoints to 3
                                                            when(p2.xpoints).thenReturn(new int[]{1, 2, 4}); // Change p2's xpoints
                                                    
                                                            // Call the method under test
                                                            result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert the expected behavior
                                                            assertFalse("The method should return false when p1 and p2 have different xpoints.", result);
                                                    
                                                            // Scenario: p1 and p2 have different ypoints
                                                            when(p2.xpoints).thenReturn(new int[]{1, 2, 3}); // Restore p2's xpoints
                                                            when(p2.ypoints).thenReturn(new int[]{4, 5, 7}); // Change p2's ypoints
                                                    
                                                            // Call the method under test
                                                            result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert the expected behavior
                                                            assertFalse("The method should return false when p1 and p2 have different ypoints.", result);
                                                        }

    @Test
                                                        public void testEqualWithNonNullP1AndNullP() {
                                                            // Create a mock GeneralPath for p1
                                                            GeneralPath p1 = mock(GeneralPath.class);
                                                            
                                                            // p2 is null
                                                            GeneralPath p2 = null;
                                                    
                                                            // Mock the behavior of p1.getPathIterator(null)
                                                            PathIterator iterator1 = mock(PathIterator.class);
                                                            when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                            when(iterator1.isDone()).thenReturn(true); // Assume the path is done immediately
                                                    
                                                            // Call the method under test
                                                            boolean result = ShapeUtilities.equal(p1, p2);
                                                    
                                                            // Assert that the result should be false
                                                            assertFalse("The method should return false when p1 is non-null and p2 is null.", result);
                                                        }

    @Test
                                                    public void testEqualLine2D() {
                                                        // Create mock Line2D objects
                                                        Line2D line1 = mock(Line2D.class);
                                                        Line2D line2 = mock(Line2D.class);
                                                
                                                        // Test case where line1 is null and line2 is null
                                                        assertTrue("Expected true when both lines are null", ShapeUtilities.equal((Line2D) null, (Line2D) null));
                                                
                                                        // Test case where line1 is null and line2 is not null
                                                        assertFalse("Expected false when line1 is null and line2 is not null", ShapeUtilities.equal((Line2D) null, line2));
                                                
                                                        // Test case where line1 is not null and line2 is null
                                                        assertFalse("Expected false when line1 is not null and line2 is null", ShapeUtilities.equal(line1, (Line2D) null));
                                                
                                                        // Test case where both lines are not null and have different P1 points
                                                        when(line1.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line2.getP1()).thenReturn(new Point2D.Double(1, 1));
                                                        when(line1.getP2()).thenReturn(new Point2D.Double(2, 2));
                                                        when(line2.getP2()).thenReturn(new Point2D.Double(2, 2));
                                                        assertFalse("Expected false when lines have different P1 points", ShapeUtilities.equal(line1, line2));
                                                
                                                        // Test case where both lines are not null and have different P2 points
                                                        when(line1.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line2.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line1.getP2()).thenReturn(new Point2D.Double(2, 2));
                                                        when(line2.getP2()).thenReturn(new Point2D.Double(3, 3));
                                                        assertFalse("Expected false when lines have different P2 points", ShapeUtilities.equal(line1, line2));
                                                
                                                        // Test case where both lines are not null and are equal
                                                        when(line1.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line2.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line1.getP2()).thenReturn(new Point2D.Double(2, 2));
                                                        when(line2.getP2()).thenReturn(new Point2D.Double(2, 2));
                                                        assertTrue("Expected true when lines are equal", ShapeUtilities.equal(line1, line2));
                                                
                                                        // Test case to detect the mutant: line1 is not null, line2 is not null, but line2's P2 is null
                                                        when(line1.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line2.getP1()).thenReturn(new Point2D.Double(0, 0));
                                                        when(line1.getP2()).thenReturn(new Point2D.Double(2, 2));
                                                        when(line2.getP2()).thenReturn(null);
                                                        assertFalse("Expected false when line2's P2 is null", ShapeUtilities.equal(line1, line2));
                                                    }

    @Test
                                                    public void testEqualWithGeneralPathMutation() {
                                                        // Arrange
                                                        GeneralPath path1 = mock(GeneralPath.class);
                                                        GeneralPath path2 = mock(GeneralPath.class);
                                                
                                                        // Mock behavior for path1 and path2
                                                        when(path1.getBounds2D()).thenReturn(null); // Mocking getFrame() equivalent behavior
                                                        when(path2.getBounds2D()).thenReturn(null);
                                                
                                                        // Act & Assert
                                                        // Case 1: Both paths are null (should return true)
                                                        assertTrue("Expected true when both paths are null", ShapeUtilities.equal((GeneralPath) null, (GeneralPath) null));
                                                
                                                        // Case 2: One path is null, the other is not (should return false)
                                                        assertFalse("Expected false when one path is null", ShapeUtilities.equal(path1, (GeneralPath) null));
                                                        assertFalse("Expected false when one path is null", ShapeUtilities.equal((GeneralPath) null, path2));
                                                
                                                        // Case 3: Both paths are non-null but have different frames (should return false)
                                                        when(path1.getBounds2D()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                        when(path2.getBounds2D()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 20, 20));
                                                        assertFalse("Expected false when paths have different frames", ShapeUtilities.equal(path1, path2));
                                                
                                                        // Case 4: Both paths are non-null and have the same frame (should return true)
                                                        when(path2.getBounds2D()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                        assertTrue("Expected true when paths have the same frame", ShapeUtilities.equal(path1, path2));
                                                    }

    @Test
                                                public void testEqualWithGeneralPathMutation1() {
                                                    // Create two GeneralPath objects
                                                    GeneralPath path1 = new GeneralPath();
                                                    GeneralPath path2 = new GeneralPath();
                                            
                                                    // Add some points to the paths
                                                    path1.moveTo(0, 0);
                                                    path1.lineTo(1, 1);
                                                    path1.closePath();
                                            
                                                    path2.moveTo(0, 0);
                                                    path2.lineTo(1, 1);
                                                    path2.closePath();
                                            
                                                    // Mock the PathIterator to simulate the mutation
                                                    PathIterator mockIterator1 = mock(PathIterator.class);
                                                    PathIterator mockIterator2 = mock(PathIterator.class);
                                            
                                                    // Set up the mock behavior
                                                    when(path1.getPathIterator(null)).thenReturn(mockIterator1);
                                                    when(path2.getPathIterator(null)).thenReturn(mockIterator2);
                                            
                                                    // Assert that the equal method returns true for identical paths
                                                    assertTrue("Paths should be equal", ShapeUtilities.equal(path1, path2));
                                            
                                                    // Now simulate the mutation by using a new AffineTransform
                                                    when(path1.getPathIterator(new AffineTransform())).thenReturn(mockIterator1);
                                                    when(path2.getPathIterator(new AffineTransform())).thenReturn(mockIterator2);
                                            
                                                    // Assert that the equal method still returns true, indicating the mutation was not detected
                                                    assertTrue("Paths should still be equal even with mutation", ShapeUtilities.equal(path1, path2));
                                            
                                                    // To detect the mutation, we need to ensure that the behavior changes when using AffineTransform
                                                    // This might involve checking the transformation applied to the path
                                                    // For example, if the transformation changes the path, the paths should not be equal
                                                    AffineTransform transform = new AffineTransform();
                                                    transform.scale(2, 2); // Example transformation
                                            
                                                    PathIterator transformedIterator1 = path1.getPathIterator(transform);
                                                    PathIterator transformedIterator2 = path2.getPathIterator(transform);
                                            
                                                    // Compare the transformed iterators
                                                    assertFalse("Paths should not be equal after transformation", transformedIterator1.equals(transformedIterator2));
                                                }

    @Test
                                                public void testEqualGeneralPathMutation3() {
                                                    // Mock the GeneralPath objects
                                                    GeneralPath p1 = mock(GeneralPath.class);
                                                    GeneralPath p2 = mock(GeneralPath.class);
                                            
                                                    // Mock the PathIterator objects
                                                    PathIterator iterator1 = mock(PathIterator.class);
                                                    PathIterator iterator2 = mock(PathIterator.class);
                                            
                                                    // Define the behavior of p1 and p2
                                                    when(p1.getPathIterator(null)).thenReturn(iterator1);
                                                    when(p2.getPathIterator(null)).thenReturn(iterator2);
                                            
                                                    // Define the behavior of the PathIterator objects
                                                    when(iterator1.isDone()).thenReturn(false, true); // First call: not done, second call: done
                                                    when(iterator2.isDone()).thenReturn(false, true); // Same behavior for iterator2
                                                    when(iterator1.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                                    when(iterator2.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO);
                                            
                                                    // Test the equality method
                                                    boolean result = ShapeUtilities.equal(p1, p2);
                                            
                                                    // Assert the expected behavior
                                                    assertTrue("The method should return true for identical paths", result);
                                            
                                                    // Verify interactions to ensure the mutant is detected
                                                    verify(p1).getPathIterator(null); // Ensure the original method behavior is tested
                                                    verify(p2).getPathIterator(null);
                                            
                                                    // Additional test to detect the mutant
                                                    PathIterator mutatedIterator1 = p1.getPathIterator(new AffineTransform());
                                                    assertNotEquals("The mutated behavior should differ from the original", iterator1, mutatedIterator1);
                                                }

    @Test
                                                public void testEqualGeneralPathMutation4() {
                                                    // Create two GeneralPath objects
                                                    GeneralPath path1 = new GeneralPath();
                                                    GeneralPath path2 = new GeneralPath();
                                                    
                                                    // Add the same elements to both paths
                                                    path1.moveTo(0, 0);
                                                    path1.lineTo(1, 1);
                                                    path1.closePath();
                                                    
                                                    path2.moveTo(0, 0);
                                                    path2.lineTo(1, 1);
                                                    path2.closePath();
                                                    
                                                    // Test the original method behavior
                                                    boolean resultOriginal = ShapeUtilities.equal(path1, path2);
                                                    
                                                    // Now, simulate the mutation by manually invoking getPathIterator with a new AffineTransform
                                                    boolean resultWithMutation = path1.getPathIterator(new AffineTransform()).isDone() == path2.getPathIterator(new AffineTransform()).isDone();
                                                    
                                                    // Assert that the original method and the mutated behavior produce different results
                                                    assertNotEquals("The mutation should alter the behavior of the equal method", resultOriginal, resultWithMutation);
                                                }

    @Test
                                                public void testEqualGeneralPathMutation5() {
                                                    // Create two GeneralPath objects
                                                    GeneralPath path1 = new GeneralPath();
                                                    GeneralPath path2 = new GeneralPath();
                                            
                                                    // Add identical shapes to both paths
                                                    path1.moveTo(0, 0);
                                                    path1.lineTo(1, 1);
                                                    path1.closePath();
                                            
                                                    path2.moveTo(0, 0);
                                                    path2.lineTo(1, 1);
                                                    path2.closePath();
                                            
                                                    // Mock the PathIterator behavior to simulate the mutation
                                                    PathIterator mockIterator1 = mock(PathIterator.class);
                                                    PathIterator mockIterator2 = mock(PathIterator.class);
                                            
                                                    // Mock the behavior of getPathIterator(null) and getPathIterator(new AffineTransform())
                                                    when(path1.getPathIterator(null)).thenReturn(mockIterator1);
                                                    when(path2.getPathIterator(null)).thenReturn(mockIterator2);
                                            
                                                    // Simulate the mutation by using getPathIterator(new AffineTransform())
                                                    when(path1.getPathIterator(new AffineTransform())).thenReturn(mockIterator1);
                                                    when(path2.getPathIterator(new AffineTransform())).thenReturn(mockIterator2);
                                            
                                                    // Set up the mock behavior to return different results for the mutated case
                                                    when(mockIterator1.isDone()).thenReturn(false, true);
                                                    when(mockIterator2.isDone()).thenReturn(false, true);
                                            
                                                    when(mockIterator1.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO);
                                                    when(mockIterator2.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO);
                                            
                                                    // Test the equal method
                                                    boolean result = ShapeUtilities.equal(path1, path2);
                                            
                                                    // Assert that the paths are considered equal in the original method
                                                    assertTrue("Paths should be equal when using getPathIterator(null)", result);
                                            
                                                    // Modify the mock to simulate the mutation effect
                                                    when(mockIterator1.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO);
                                                    when(mockIterator2.currentSegment(any(float[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_QUADTO);
                                            
                                                    // Test the equal method again
                                                    result = ShapeUtilities.equal(path1, path2);
                                            
                                                    // Assert that the paths are not equal due to the mutation
                                                    assertFalse("Paths should not be equal when using getPathIterator(new AffineTransform)", result);
                                                }

    @Test
                                                public void testEqualGeneralPath1() {
                                                    // Create two GeneralPath objects that should be equal without transformation
                                                    GeneralPath path1 = new GeneralPath();
                                                    path1.moveTo(0, 0);
                                                    path1.lineTo(1, 1);
                                                    path1.lineTo(2, 0);
                                                    path1.closePath();
                                            
                                                    GeneralPath path2 = new GeneralPath();
                                                    path2.moveTo(0, 0);
                                                    path2.lineTo(1, 1);
                                                    path2.lineTo(2, 0);
                                                    path2.closePath();
                                            
                                                    // Use the equal method to check if they are considered equal
                                                    boolean result = ShapeUtilities.equal(path1, path2);
                                            
                                                    // Assert that they are equal, this should pass if the mutation is not present
                                                    assertTrue("The paths should be equal without transformation", result);
                                            
                                                    // Now, let's create a scenario where the transformation would affect equality
                                                    GeneralPath path3 = new GeneralPath();
                                                    path3.moveTo(0, 0);
                                                    path3.lineTo(1, 1);
                                                    path3.lineTo(2, 0);
                                                    path3.closePath();
                                            
                                                    // Apply a transformation to path3 that should not affect equality if null is used
                                                    // But will affect if a new AffineTransform is used in the mutant
                                                    path3.transform(new AffineTransform());
                                            
                                                    // Check equality again
                                                    boolean resultWithTransform = ShapeUtilities.equal(path1, path3);
                                            
                                                    // Assert that they should still be equal if no transformation is applied
                                                    // This will fail if the mutant is present, as it applies a transformation
                                                    assertTrue("The paths should be equal if no transformation is applied", resultWithTransform);
                                                }

    @Test
                                                public void testEqualWithMutatedPathIterator() {
                                                    // Create two GeneralPath objects
                                                    GeneralPath path1 = new GeneralPath();
                                                    GeneralPath path2 = new GeneralPath();
                                                    
                                                    // Add identical segments to both paths
                                                    path1.moveTo(0, 0);
                                                    path1.lineTo(1, 1);
                                                    path1.lineTo(2, 2);
                                                    
                                                    path2.moveTo(0, 0);
                                                    path2.lineTo(1, 1);
                                                    path2.lineTo(2, 2);
                                                    
                                                    // Mock the PathIterator behavior for both paths
                                                    PathIterator iterator1 = mock(PathIterator.class);
                                                    PathIterator iterator2 = mock(PathIterator.class);
                                                    
                                                    when(iterator1.isDone()).thenReturn(false, false, false, true);
                                                    when(iterator2.isDone()).thenReturn(false, false, false, true);
                                                    
                                                    double[] segment1 = new double[]{0, 0, 1, 1, 2, 2};
                                                    double[] segment2 = new double[]{0, 0, 1, 1, 2, 2};
                                                    
                                                    when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO, PathIterator.SEG_LINETO);
                                                    when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO, PathIterator.SEG_LINETO);
                                                    
                                                    when(iterator1.currentSegment(segment1)).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO, PathIterator.SEG_LINETO);
                                                    when(iterator2.currentSegment(segment2)).thenReturn(PathIterator.SEG_MOVETO, PathIterator.SEG_LINETO, PathIterator.SEG_LINETO);
                                                    
                                                    when(iterator1.isDone()).thenReturn(false, false, false, true);
                                                    when(iterator2.isDone()).thenReturn(false, false, false, true);
                                                    
                                                    // Mock the getPathIterator method to return the mocked iterator
                                                    GeneralPath spyPath1 = spy(path1);
                                                    GeneralPath spyPath2 = spy(path2);
                                                    
                                                    when(spyPath1.getPathIterator(null)).thenReturn(iterator1);
                                                    when(spyPath2.getPathIterator(null)).thenReturn(iterator2);
                                                    
                                                    // Assert that the original method returns true
                                                    assertTrue(ShapeUtilities.equal(spyPath1, spyPath2));
                                                    
                                                    // Test the mutated method
                                                    when(spyPath1.getPathIterator(any(AffineTransform.class))).thenReturn(iterator1);
                                                    
                                                    // Assert that the mutated method returns false due to the transformation
                                                    assertFalse(ShapeUtilities.equal(spyPath1, spyPath2));
                                                }

    @Test
                                            public void testEqual_Line2D_MutantDetection2() {
                                                // Mocking Line2D objects
                                                Line2D line1 = mock(Line2D.class);
                                                Line2D line2 = mock(Line2D.class);
                                        
                                                // Mocking the behavior of getP1() and getP2() for line1
                                                when(line1.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0));
                                                when(line1.getP2()).thenReturn(new java.awt.geom.Point2D.Double(2.0, 2.0));
                                        
                                                // Mocking the behavior of getP1() and getP2() for line2
                                                when(line2.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0));
                                                when(line2.getP2()).thenReturn(new java.awt.geom.Point2D.Double(2.0, 2.0));
                                        
                                                // Test case where both lines are equal
                                                boolean result = ShapeUtilities.equal(line1, line2);
                                                assertTrue("Expected lines to be equal, but they were not.", result);
                                        
                                                // Changing the behavior of line2 to create inequality
                                                when(line2.getP2()).thenReturn(new java.awt.geom.Point2D.Double(3.0, 3.0));
                                        
                                                // Test case where lines are not equal
                                                result = ShapeUtilities.equal(line1, line2);
                                                assertFalse("Expected lines to be unequal, but they were equal.", result);
                                        
                                                // Verifying interactions with mocked objects
                                                verify(line1, times(2)).getP1();
                                                verify(line1, times(2)).getP2();
                                                verify(line2, times(2)).getP1();
                                                verify(line2, times(2)).getP2();
                                            }

    @Test
                                            public void testEqualArc2D2() {
                                                // Create mock Arc2D objects
                                                Arc2D arc1 = mock(Arc2D.class);
                                                Arc2D arc2 = mock(Arc2D.class);
                                        
                                                // Case 1: Both arcs are null
                                                assertTrue(ShapeUtilities.equal((Arc2D) null, (Arc2D) null));
                                        
                                                // Case 2: One arc is null
                                                assertFalse(ShapeUtilities.equal(arc1, null));
                                                assertFalse(ShapeUtilities.equal(null, arc2));
                                        
                                                // Case 3: Different frames
                                                when(arc1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 20, 20));
                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                        
                                                // Case 4: Same frame, different angle start
                                                when(arc2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                                when(arc1.getAngleStart()).thenReturn(0.0);
                                                when(arc2.getAngleStart()).thenReturn(90.0);
                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                        
                                                // Case 5: Same frame and angle start, different angle extent
                                                when(arc2.getAngleStart()).thenReturn(0.0);
                                                when(arc1.getAngleExtent()).thenReturn(180.0);
                                                when(arc2.getAngleExtent()).thenReturn(90.0);
                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                        
                                                // Case 6: Same frame, angle start, and angle extent, different arc type
                                                when(arc2.getAngleExtent()).thenReturn(180.0);
                                                when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                                                when(arc2.getArcType()).thenReturn(Arc2D.CHORD);
                                                assertFalse(ShapeUtilities.equal(arc1, arc2));
                                        
                                                // Case 7: Completely equal arcs
                                                when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                                                assertTrue(ShapeUtilities.equal(arc1, arc2));
                                            }

    @Test
                                            public void testEqualPolygonWithSurvivedMutant() {
                                                // Arrange: Create two Polygon objects with identical properties
                                                Polygon polygon1 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                                Polygon polygon2 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                        
                                                // Act: Call the equal method to compare the two polygons
                                                boolean result = ShapeUtilities.equal(polygon1, polygon2);
                                        
                                                // Assert: Verify that the result is true (original behavior)
                                                assertTrue("Expected polygons to be equal", result);
                                        
                                                // Arrange: Create two Polygon objects with different properties
                                                Polygon polygon3 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 7}, 3);
                                                Polygon polygon4 = new Polygon(new int[]{1, 2, 3}, new int[]{4, 5, 6}, 3);
                                        
                                                // Act: Call the equal method to compare the two polygons
                                                boolean resultDifferent = ShapeUtilities.equal(polygon3, polygon4);
                                        
                                                // Assert: Verify that the result is false (original behavior)
                                                assertFalse("Expected polygons to be unequal", resultDifferent);
                                        
                                                // Edge Case: Compare a polygon with null
                                                Polygon polygon5 = null;
                                        
                                                // Act: Call the equal method with one null polygon
                                                boolean resultNull = ShapeUtilities.equal(polygon5, polygon4);
                                        
                                                // Assert: Verify that the result is false (original behavior)
                                                assertFalse("Expected comparison with null to be false", resultNull);
                                        
                                                // Edge Case: Compare two null polygons
                                                Polygon polygon6 = null;
                                        
                                                // Act: Call the equal method with two null polygons
                                                boolean resultBothNull = ShapeUtilities.equal(polygon5, polygon6);
                                        
                                                // Assert: Verify that the result is true (original behavior)
                                                assertTrue("Expected comparison of two null polygons to be true", resultBothNull);
                                            }

    @Test
                                            public void testEqualWithMutantDetection1() {
                                                // Create mock PathIterator objects
                                                PathIterator iterator1 = mock(PathIterator.class);
                                                PathIterator iterator2 = mock(PathIterator.class);
                                        
                                                // Configure the mocks to simulate the scenario where both iterators are done initially
                                                when(iterator1.isDone()).thenReturn(true);
                                                when(iterator2.isDone()).thenReturn(true);
                                        
                                                // Create mock GeneralPath objects
                                                GeneralPath path1 = mock(GeneralPath.class);
                                                GeneralPath path2 = mock(GeneralPath.class);
                                        
                                                // Configure the mocks to return the mock iterators
                                                when(path1.getPathIterator(null)).thenReturn(iterator1);
                                                when(path2.getPathIterator(null)).thenReturn(iterator2);
                                        
                                                // Configure the mocks to return the same winding rule
                                                when(path1.getWindingRule()).thenReturn(GeneralPath.WIND_NON_ZERO);
                                                when(path2.getWindingRule()).thenReturn(GeneralPath.WIND_NON_ZERO);
                                        
                                                // Test the equal method
                                                boolean result = ShapeUtilities.equal(path1, path2);
                                        
                                                // Assert that the result is true, as both iterators are done initially and should not enter the loop
                                                assertTrue("The method should return true when both iterators are done initially", result);
                                            }

    @Test
                                        public void testEqualWithMutantDetection2() {
                                            // Mocking Line2D objects and their behavior
                                            Line2D line1 = mock(Line2D.class);
                                            Line2D line2 = mock(Line2D.class);
                                    
                                            // Mocking Ellipse2D objects and their behavior
                                            Ellipse2D ellipse1 = mock(Ellipse2D.class);
                                            Ellipse2D ellipse2 = mock(Ellipse2D.class);
                                    
                                            // Mocking Arc2D objects and their behavior
                                            Arc2D arc1 = mock(Arc2D.class);
                                            Arc2D arc2 = mock(Arc2D.class);
                                    
                                            // Mocking Polygon objects and their behavior
                                            Polygon polygon1 = mock(Polygon.class);
                                            Polygon polygon2 = mock(Polygon.class);
                                    
                                            // Mocking GeneralPath objects and their behavior
                                            GeneralPath path1 = mock(GeneralPath.class);
                                            GeneralPath path2 = mock(GeneralPath.class);
                                    
                                            // Test case for Line2D objects
                                            when(ShapeUtilities.equal(line1, line2)).thenReturn(true);
                                            assertTrue("Line2D objects should be equal", ShapeUtilities.equal(line1, line2));
                                    
                                            // Test case for Ellipse2D objects
                                            when(ShapeUtilities.equal(ellipse1, ellipse2)).thenReturn(false);
                                            assertFalse("Ellipse2D objects should not be equal", ShapeUtilities.equal(ellipse1, ellipse2));
                                    
                                            // Test case for Arc2D objects
                                            when(ShapeUtilities.equal(arc1, arc2)).thenReturn(true);
                                            assertTrue("Arc2D objects should be equal", ShapeUtilities.equal(arc1, arc2));
                                    
                                            // Test case for Polygon objects
                                            when(ShapeUtilities.equal(polygon1, polygon2)).thenReturn(false);
                                            assertFalse("Polygon objects should not be equal", ShapeUtilities.equal(polygon1, polygon2));
                                    
                                            // Test case for GeneralPath objects
                                            when(ShapeUtilities.equal(path1, path2)).thenReturn(true);
                                            assertTrue("GeneralPath objects should be equal", ShapeUtilities.equal(path1, path2));
                                    
                                            // Test case for ObjectUtilities.equal fallback
                                            Object shape1 = new Rectangle2D.Double(0, 0, 10, 10);
                                            Object shape2 = new Rectangle2D.Double(0, 0, 10, 10);
                                            ObjectUtilities objectUtilitiesMock = mock(ObjectUtilities.class);
                                            when(objectUtilitiesMock.equal(shape1, shape2)).thenReturn(true);
                                            assertTrue("Fallback ObjectUtilities.equal should return true for equal shapes",
                                                    objectUtilitiesMock.equal(shape1, shape2));
                                    
                                            // Edge case: Null shapes
                                            assertFalse("Null shapes should not be equal", ShapeUtilities.equal((Shape) null, (Shape) null));
                                            assertFalse("One null shape should not be equal to non-null shape", ShapeUtilities.equal((Shape) null, (Shape) shape1));
                                            assertFalse("Non-null shape should not be equal to null shape", ShapeUtilities.equal((Shape) shape1, (Shape) null));
                                        }

    @Test
                                        public void testEqualDetectsMutant1() {
                                            // Create two Ellipse2D objects with the same frame
                                            Ellipse2D e1 = new Ellipse2D.Double(0, 0, 10, 10);
                                            Ellipse2D e2 = new Ellipse2D.Double(0, 0, 10, 10);
                                    
                                            // Call the method under test
                                            boolean result = ShapeUtilities.equal(e1, e2);
                                    
                                            // Assert that the result is true, which is the expected behavior without the mutant
                                            assertTrue("The method should return true when both frames are equal", result);
                                        }

    @Test
                                    public void testEqualWithMutantDetection3() {
                                        // Mocking Line2D objects
                                        Line2D line1 = mock(Line2D.class);
                                        Line2D line2 = mock(Line2D.class);
                                
                                        // Mocking Ellipse2D objects
                                        Ellipse2D ellipse1 = mock(Ellipse2D.class);
                                        Ellipse2D ellipse2 = mock(Ellipse2D.class);
                                
                                        // Mocking Arc2D objects
                                        Arc2D arc1 = mock(Arc2D.class);
                                        Arc2D arc2 = mock(Arc2D.class);
                                
                                        // Mocking Polygon objects
                                        Polygon polygon1 = mock(Polygon.class);
                                        Polygon polygon2 = mock(Polygon.class);
                                
                                        // Mocking GeneralPath objects
                                        GeneralPath path1 = mock(GeneralPath.class);
                                        GeneralPath path2 = mock(GeneralPath.class);
                                
                                        // Test Case 1: Line2D - Mutant Detection
                                        when(line1.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        when(line2.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        assertTrue("Line2D objects should be equal", ShapeUtilities.equal(line1, line2));
                                
                                        // Test Case 2: Ellipse2D - Mutant Detection
                                        when(ellipse1.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        when(ellipse2.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        assertTrue("Ellipse2D objects should be equal", ShapeUtilities.equal(ellipse1, ellipse2));
                                
                                        // Test Case 3: Arc2D - Mutant Detection
                                        when(arc1.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        when(arc2.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        assertTrue("Arc2D objects should be equal", ShapeUtilities.equal(arc1, arc2));
                                
                                        // Test Case 4: Polygon - Mutant Detection
                                        when(polygon1.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        when(polygon2.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        assertTrue("Polygon objects should be equal", ShapeUtilities.equal(polygon1, polygon2));
                                
                                        // Test Case 5: GeneralPath - Mutant Detection
                                        when(path1.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        when(path2.getBounds2D()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                                        assertTrue("GeneralPath objects should be equal", ShapeUtilities.equal(path1, path2));
                                
                                        // Test Case 6: Rectangle2D (Fallback to ObjectUtilities)
                                        Rectangle2D rect1 = new Rectangle2D.Double(0, 0, 10, 10);
                                        Rectangle2D rect2 = new Rectangle2D.Double(0, 0, 10, 10);
                                        assertTrue("Rectangle2D objects should be equal", ShapeUtilities.equal(rect1, rect2));
                                
                                        // Test Case 7: Detecting the Mutant
                                        // Simulating the scenario where the iterators' `isDone()` results differ
                                        GeneralPath mockPath1 = mock(GeneralPath.class);
                                        GeneralPath mockPath2 = mock(GeneralPath.class);
                                
                                        PathIterator iterator1 = mock(PathIterator.class);
                                        PathIterator iterator2 = mock(PathIterator.class);
                                
                                        when(mockPath1.getPathIterator(null)).thenReturn(iterator1);
                                        when(mockPath2.getPathIterator(null)).thenReturn(iterator2);
                                
                                        // Simulating the mutant condition: iterator1.isDone() != iterator2.isDone()
                                        when(iterator1.isDone()).thenReturn(false);
                                        when(iterator2.isDone()).thenReturn(true);
                                
                                        // The original method should return false in this case, but the mutant will return true
                                        boolean result = ShapeUtilities.equal(mockPath1, mockPath2);
                                        assertFalse("Mutant detected: PathIterator states differ but method returned true", result);
                                    }

    @Test
                                    public void testEqual_Line2D_MutantDetection3() {
                                        // Mocking Line2D objects
                                        Line2D line1 = mock(Line2D.class);
                                        Line2D line2 = mock(Line2D.class);
                                
                                        // Mocking the behavior of getP1() and getP2() for both lines
                                        when(line1.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0));
                                        when(line1.getP2()).thenReturn(new java.awt.geom.Point2D.Double(2.0, 2.0));
                                
                                        when(line2.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0));
                                        when(line2.getP2()).thenReturn(new java.awt.geom.Point2D.Double(2.0, 2.0));
                                
                                        // Test case where both lines are equal
                                        assertTrue("Expected lines to be equal", ShapeUtilities.equal(line1, line2));
                                
                                        // Test case where one line is null
                                        assertFalse("Expected lines to not be equal when one is null", ShapeUtilities.equal(line1, null));
                                        assertFalse("Expected lines to not be equal when one is null", ShapeUtilities.equal(null, line2));
                                
                                        // Test case where getP1() differs
                                        when(line2.getP1()).thenReturn(new java.awt.geom.Point2D.Double(3.0, 3.0));
                                        assertFalse("Expected lines to not be equal when getP1() differs", ShapeUtilities.equal(line1, line2));
                                
                                        // Test case where getP2() differs
                                        when(line2.getP1()).thenReturn(new java.awt.geom.Point2D.Double(1.0, 1.0)); // Reset to match line1
                                        when(line2.getP2()).thenReturn(new java.awt.geom.Point2D.Double(3.0, 3.0));
                                        assertFalse("Expected lines to not be equal when getP2() differs", ShapeUtilities.equal(line1, line2));
                                    }

    @Test
                            public void testEqualEllipse2D() {
                                // Create mock Ellipse2D objects
                                Ellipse2D e1 = mock(Ellipse2D.class);
                                Ellipse2D e2 = mock(Ellipse2D.class);
                            
                                // Mock the getFrame method to return different frames
                                when(e1.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                                when(e2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 10, 10));
                            
                                // Use reflection to call the correct overloaded 'equal' method for Ellipse2D
                                try {
                                    // Get the 'equal' method that accepts Ellipse2D objects
                                    java.lang.reflect.Method equalMethod = ShapeUtilities.class.getDeclaredMethod("equal", Ellipse2D.class, Ellipse2D.class);
                            
                                    // Test case where both frames are equal
                                    assertTrue((boolean) equalMethod.invoke(null, e1, e2));
                            
                                    // Change the frame of e2 to make them unequal
                                    when(e2.getFrame()).thenReturn(new java.awt.geom.Rectangle2D.Double(0, 0, 5, 5));
                            
                                    // Test case where frames are not equal
                                    assertFalse((boolean) equalMethod.invoke(null, e1, e2));
                            
                                    // Test case where e1 is null and e2 is not null
                                    assertFalse((boolean) equalMethod.invoke(null, null, e2));
                            
                                    // Test case where both e1 and e2 are null
                                    assertTrue((boolean) equalMethod.invoke(null, null, null));
                            
                                    // Test case where e1 is not null and e2 is null
                                    assertFalse((boolean) equalMethod.invoke(null, e1, null));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    fail("Reflection failed while invoking the 'equal' method for Ellipse2D.");
                                }
                            }

    @Test
                            public void testEqual_DetectMutant() {
                                // Mocking the Arc2D objects
                                Arc2D arc1 = mock(Arc2D.class);
                                Arc2D arc2 = mock(Arc2D.class);
                            
                                // Setting up the mock behavior for arc1
                                when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 100, 100)); // Using a concrete implementation of Shape
                                when(arc1.getAngleStart()).thenReturn(30.0);
                                when(arc1.getAngleExtent()).thenReturn(90.0);
                                when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
                            
                                // Setting up the mock behavior for arc2
                                when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 100, 100)); // Using a concrete implementation of Shape
                                when(arc2.getAngleStart()).thenReturn(30.0);
                                when(arc2.getAngleExtent()).thenReturn(90.0);
                                when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
                            
                                // Simulating the behavior of the iterators (isDone logic)
                                // Assuming iterator1.isDone() and iterator2.isDone() are part of the logic
                                // Mocking the behavior to simulate the mutant's impact
                                boolean iterator1IsDone = true;
                                boolean iterator2IsDone = false;
                            
                                // Original logic: iterator1.isDone() && iterator2.isDone()
                                // Mutated logic: iterator1.isDone() != iterator2.isDone()
                                // This test case should fail for the mutant and pass for the original logic
                            
                                // Call the method under test
                                boolean result = ShapeUtilities.equal(arc1, arc2);
                            
                                // Assert the expected behavior
                                // The original logic would return false because both iterators are not done
                                // The mutant would return true due to the != condition
                                assertFalse("The mutant was not detected!", result);
                            
                                // Verify interactions with the mocked objects
                                verify(arc1, times(1)).getFrame();
                                verify(arc1, times(1)).getAngleStart();
                                verify(arc1, times(1)).getAngleExtent();
                                verify(arc1, times(1)).getArcType();
                            
                                verify(arc2, times(1)).getFrame();
                                verify(arc2, times(1)).getAngleStart();
                                verify(arc2, times(1)).getAngleExtent();
                                verify(arc2, times(1)).getArcType();
                            }

    @Test
                                public void testEqualPolygonWithMutantDetection() {
                                    // Create mock objects for the polygons
                                    Polygon polygon1 = mock(Polygon.class);
                                    Polygon polygon2 = mock(Polygon.class);
                            
                                    // Case 1: Both polygons are null
                                    assertTrue(ShapeUtilities.equal((Polygon) null, (Polygon) null));
                            
                                    // Case 2: One polygon is null, the other is not
                                    assertFalse(ShapeUtilities.equal(polygon1, null));
                                    assertFalse(ShapeUtilities.equal(null, polygon2));
                            
                                    // Case 3: Polygons with different number of points
                                    when(polygon1.npoints).thenReturn(3);
                                    when(polygon2.npoints).thenReturn(4);
                                    assertFalse(ShapeUtilities.equal(polygon1, polygon2));
                            
                                    // Case 4: Polygons with the same number of points but different xpoints
                                    when(polygon1.npoints).thenReturn(3);
                                    when(polygon2.npoints).thenReturn(3);
                                    when(polygon1.xpoints).thenReturn(new int[]{1, 2, 3});
                                    when(polygon2.xpoints).thenReturn(new int[]{1, 2, 4});
                                    assertFalse(ShapeUtilities.equal(polygon1, polygon2));
                            
                                    // Case 5: Polygons with the same number of points and same xpoints but different ypoints
                                    when(polygon1.xpoints).thenReturn(new int[]{1, 2, 3});
                                    when(polygon2.xpoints).thenReturn(new int[]{1, 2, 3});
                                    when(polygon1.ypoints).thenReturn(new int[]{4, 5, 6});
                                    when(polygon2.ypoints).thenReturn(new int[]{4, 5, 7});
                                    assertFalse(ShapeUtilities.equal(polygon1, polygon2));
                            
                                    // Case 6: Polygons with the same number of points and identical xpoints and ypoints
                                    when(polygon1.ypoints).thenReturn(new int[]{4, 5, 6});
                                    when(polygon2.ypoints).thenReturn(new int[]{4, 5, 6});
                                    assertTrue(ShapeUtilities.equal(polygon1, polygon2));
                            
                                    // Case 7: Mutant detection - iterator1.isDone() != iterator2.isDone()
                                    // Simulate the behavior of iterators to catch the mutant
                                    Polygon iterator1 = mock(Polygon.class);
                                    Polygon iterator2 = mock(Polygon.class);
                            
                                    // Simulate one iterator being done and the other not
                                    when(iterator1.npoints).thenReturn(3);
                                    when(iterator2.npoints).thenReturn(3);
                                    when(iterator1.xpoints).thenReturn(new int[]{1, 2, 3});
                                    when(iterator2.xpoints).thenReturn(new int[]{1, 2, 3});
                                    when(iterator1.ypoints).thenReturn(new int[]{4, 5, 6});
                                    when(iterator2.ypoints).thenReturn(new int[]{4, 5, 6});
                            
                                    // Simulate the mutant behavior
                                    boolean result = ShapeUtilities.equal(iterator1, iterator2);
                                    assertTrue("The mutant should be detected when iterator1.isDone() != iterator2.isDone()", result);
                                }

    @Test
                            public void testEqualWithDifferentLengthPaths() {
                                // Create two GeneralPath objects
                                GeneralPath path1 = new GeneralPath();
                                GeneralPath path2 = new GeneralPath();
                                
                                // Add segments to path1
                                path1.moveTo(0, 0);
                                path1.lineTo(1, 1);
                                path1.lineTo(2, 2);
                                
                                // Add fewer segments to path2
                                path2.moveTo(0, 0);
                                path2.lineTo(1, 1);
                                
                                // Use the equal method to compare the paths
                                boolean result = ShapeUtilities.equal(path1, path2);
                                
                                // Assert that the result is false, as the paths have different lengths
                                assertFalse("The paths should not be equal due to different lengths", result);
                            }

    @Test
                        public void testEqualWithPathIteratorMutation() {
                            // Mock the GeneralPath objects
                            GeneralPath mockPath1 = mock(GeneralPath.class);
                            GeneralPath mockPath2 = mock(GeneralPath.class);
                    
                            // Mock the PathIterator objects
                            PathIterator mockIterator1 = mock(PathIterator.class);
                            PathIterator mockIterator2 = mock(PathIterator.class);
                    
                            // Define behavior for getPathIterator(null) for the first path
                            when(mockPath1.getPathIterator(null)).thenReturn(mockIterator1);
                    
                            // Define behavior for getPathIterator(new AffineTransform()) for the first path
                            when(mockPath1.getPathIterator(new AffineTransform())).thenReturn(mockIterator1);
                    
                            // Define behavior for getPathIterator(null) for the second path
                            when(mockPath2.getPathIterator(null)).thenReturn(mockIterator2);
                    
                            // Define behavior for getPathIterator(new AffineTransform()) for the second path
                            when(mockPath2.getPathIterator(new AffineTransform())).thenReturn(mockIterator2);
                    
                            // Define behavior for PathIterator equality
                            when(mockIterator1.equals(mockIterator2)).thenReturn(true);
                    
                            // Call the method under test
                            boolean result = ShapeUtilities.equal(mockPath1, mockPath2);
                    
                            // Verify that the correct PathIterator was used (null, not new AffineTransform())
                            verify(mockPath1).getPathIterator(null);
                            verify(mockPath2).getPathIterator(null);
                    
                            // Assert the expected result
                            assertTrue("The method should return true for equal paths", result);
                        }

    @Test
                        public void testEqualGeneralPathMutation6() {
                            // Arrange
                            GeneralPath path1 = mock(GeneralPath.class);
                            GeneralPath path2 = mock(GeneralPath.class);
                    
                            // Mock behavior for path1 and path2
                            PathIterator iterator1 = mock(PathIterator.class);
                            PathIterator iterator2 = mock(PathIterator.class);
                    
                            when(path1.getPathIterator(null)).thenReturn(iterator1);
                            when(path2.getPathIterator(null)).thenReturn(iterator2);
                    
                            // Mock equality behavior for PathIterator
                            when(iterator1.equals(iterator2)).thenReturn(true);
                    
                            // Act
                            boolean result = ShapeUtilities.equal(path1, path2);
                    
                            // Assert
                            assertTrue("Expected the paths to be equal when using null transform.", result);
                    
                            // Additional verification to ensure the mutant is caught
                            verify(path1).getPathIterator(null); // Ensure null was passed
                            verify(path2).getPathIterator(null); // Ensure null was passed
                        }

    @Test
                        public void testEqualGeneralPathMutation7() {
                            // Create two GeneralPath objects
                            GeneralPath path1 = new GeneralPath();
                            GeneralPath path2 = new GeneralPath();
                    
                            // Mock the PathIterator behavior for path1 and path2
                            PathIterator mockIterator1 = mock(PathIterator.class);
                            PathIterator mockIterator2 = mock(PathIterator.class);
                    
                            // Define the behavior of the mock iterators
                            when(path1.getPathIterator(null)).thenReturn(mockIterator1);
                            when(path2.getPathIterator(null)).thenReturn(mockIterator2);
                    
                            // Set up the mock iterator to return different results for the mutation scenario
                            when(mockIterator1.isDone()).thenReturn(false, true);
                            when(mockIterator2.isDone()).thenReturn(false, true);
                    
                            // Assume the mutation causes a different AffineTransform to be used, which affects the iteration
                            AffineTransform transform = new AffineTransform();
                            PathIterator mutatedIterator1 = path1.getPathIterator(transform);
                            PathIterator mutatedIterator2 = path2.getPathIterator(transform);
                    
                            // Check if the original method returns true for equal paths
                            boolean originalResult = ShapeUtilities.equal(path1, path2);
                            assertTrue("Original paths should be equal", originalResult);
                    
                            // Check if the mutated method returns false due to different iteration behavior
                            boolean mutatedResult = mutatedIterator1.equals(mutatedIterator2);
                            assertFalse("Mutated paths should not be equal", mutatedResult);
                        }

    @Test
                        public void testEqualWithMutatedPathIterator1() {
                            // Mock the Polygon objects
                            Polygon p1 = mock(Polygon.class);
                            Polygon p2 = mock(Polygon.class);
                    
                            // Set up the behavior for the mocked objects
                            when(p1.npoints).thenReturn(4);
                            when(p2.npoints).thenReturn(4);
                    
                            // Mock the xpoints and ypoints arrays
                            int[] xpoints = {0, 1, 2, 3};
                            int[] ypoints = {0, 1, 2, 3};
                            when(p1.xpoints).thenReturn(xpoints);
                            when(p2.xpoints).thenReturn(xpoints);
                            when(p1.ypoints).thenReturn(ypoints);
                            when(p2.ypoints).thenReturn(ypoints);
                    
                            // Mock the getPathIterator method for both p1 and p2
                            PathIterator iterator1 = mock(PathIterator.class);
                            PathIterator iterator2 = mock(PathIterator.class);
                            when(p1.getPathIterator(null)).thenReturn(iterator1);
                            when(p1.getPathIterator(any(AffineTransform.class))).thenReturn(iterator2);
                            when(p2.getPathIterator(null)).thenReturn(iterator1);
                    
                            // Call the method under test
                            boolean result = ShapeUtilities.equal(p1, p2);
                    
                            // Verify the behavior of the mocked objects
                            verify(p1).getPathIterator(null); // Ensure the original method is called with null
                            verify(p1, never()).getPathIterator(any(AffineTransform.class)); // Ensure the mutated method is not called
                            verify(p2).getPathIterator(null);
                    
                            // Assert the expected result
                            assertTrue("The method should return true for identical polygons", result);
                    
                            // Now simulate the mutated behavior
                            reset(p1, p2); // Reset the mocks
                            when(p1.npoints).thenReturn(4);
                            when(p2.npoints).thenReturn(4);
                            when(p1.xpoints).thenReturn(xpoints);
                            when(p2.xpoints).thenReturn(xpoints);
                            when(p1.ypoints).thenReturn(ypoints);
                            when(p2.ypoints).thenReturn(ypoints);
                            when(p1.getPathIterator(null)).thenReturn(iterator1);
                            when(p1.getPathIterator(any(AffineTransform.class))).thenReturn(iterator2);
                            when(p2.getPathIterator(null)).thenReturn(iterator1);
                    
                            // Call the method under test again
                            result = ShapeUtilities.equal(p1, p2);
                    
                            // Verify the behavior of the mutated method
                            verify(p1, never()).getPathIterator(null); // Ensure the original method is not called
                            verify(p1).getPathIterator(any(AffineTransform.class)); // Ensure the mutated method is called
                            verify(p2).getPathIterator(null);
                    
                            // Assert the expected result
                            assertFalse("The method should return false for mutated behavior", result);
                        }

    @Test
                        public void testEqualMethodDetectsMutation() {
                            // Mocking GeneralPath objects
                            GeneralPath path1 = mock(GeneralPath.class);
                            GeneralPath path2 = mock(GeneralPath.class);
                    
                            // Mocking PathIterator objects
                            PathIterator iterator1 = mock(PathIterator.class);
                            PathIterator iterator2 = mock(PathIterator.class);
                    
                            // Setting up the mock behavior
                            when(path1.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                            when(path2.getWindingRule()).thenReturn(PathIterator.WIND_NON_ZERO);
                    
                            when(path1.getPathIterator(null)).thenReturn(iterator1);
                            when(path2.getPathIterator(null)).thenReturn(iterator2);
                    
                            // Mocking iterator behavior
                            double[] coords1 = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
                            double[] coords2 = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
                    
                            when(iterator1.isDone()).thenReturn(false, true);
                            when(iterator2.isDone()).thenReturn(false, true);
                    
                            when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                            when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                    
                            when(iterator1.currentSegment(coords1)).thenReturn(PathIterator.SEG_MOVETO);
                            when(iterator2.currentSegment(coords2)).thenReturn(PathIterator.SEG_MOVETO);
                    
                            when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                            when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                    
                            when(iterator1.isDone()).thenReturn(false, true);
                            when(iterator2.isDone()).thenReturn(false, true);
                    
                            // Test the equal method with the mocked paths
                            boolean result = ShapeUtilities.equal(path1, path2);
                    
                            // Verify that the method behaves correctly
                            assertTrue("The paths should be considered equal", result);
                    
                            // Verify that the PathIterator was obtained with null (original behavior)
                            verify(path1, times(1)).getPathIterator(null);
                            verify(path2, times(1)).getPathIterator(null);
                    
                            // If the mutant was active, it would call getPathIterator with new AffineTransform()
                            // This test should fail if the mutant is not detected
                            assertFalse("The paths should not be considered equal if the mutant is active", ShapeUtilities.equal(path1, path2));
                        }

    @Test
                public void testEqualGeneralPathMutation8() {
                    // Create two GeneralPath objects that should be equal
                    GeneralPath path1 = new GeneralPath();
                    path1.moveTo(0, 0);
                    path1.lineTo(1, 1);
                    path1.closePath();
                
                    GeneralPath path2 = new GeneralPath();
                    path2.moveTo(0, 0);
                    path2.lineTo(1, 1);
                    path2.closePath();
                
                    // Assert that the paths are equal using the ShapeUtilities method
                    boolean result = ShapeUtilities.equal(path1, path2);
                    assertTrue("The paths should be equal", result);
                
                    // Now test with the mutation
                    AffineTransform transform = new AffineTransform();
                    PathIterator mutatedIterator1 = path1.getPathIterator(transform);
                    PathIterator mutatedIterator2 = path2.getPathIterator(transform);
                
                    // Assert that the paths are equal when using the mutated PathIterator
                    // Since ShapeUtilities does not provide a method to compare PathIterator objects directly,
                    // we need to compare the paths after applying the transformation
                    GeneralPath transformedPath1 = new GeneralPath();
                    transformedPath1.append(mutatedIterator1, false);
                
                    GeneralPath transformedPath2 = new GeneralPath();
                    transformedPath2.append(mutatedIterator2, false);
                
                    boolean mutatedResult = ShapeUtilities.equal(transformedPath1, transformedPath2);
                    assertTrue("The paths should still be equal after applying the transformation", mutatedResult);
                }

    @Test
                public void testEqualArc2DWithMutant1() {
                    // Create mock Arc2D objects
                    Arc2D arc1 = mock(Arc2D.class);
                    Arc2D arc2 = mock(Arc2D.class);
            
                    // Set up the mock behavior for arc1
                    when(arc1.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                    when(arc1.getAngleStart()).thenReturn(0.0);
                    when(arc1.getAngleExtent()).thenReturn(180.0);
                    when(arc1.getArcType()).thenReturn(Arc2D.OPEN);
            
                    // Set up the mock behavior for arc2
                    when(arc2.getFrame()).thenReturn(new Rectangle2D.Double(0, 0, 10, 10));
                    when(arc2.getAngleStart()).thenReturn(0.0);
                    when(arc2.getAngleExtent()).thenReturn(180.0);
                    when(arc2.getArcType()).thenReturn(Arc2D.OPEN);
            
                    // Test the equal method with both arcs being equal
                    boolean result = ShapeUtilities.equal(arc1, arc2);
                    assertTrue("Expected arcs to be equal", result);
            
                    // Modify arc2 to make it different from arc1
                    when(arc2.getAngleExtent()).thenReturn(90.0);
            
                    // Test the equal method with different arcs
                    result = ShapeUtilities.equal(arc1, arc2);
                    assertFalse("Expected arcs to be not equal", result);
                }

    @Test
                public void testEqualWithMutantDetection4() {
                    // Create mock PathIterator objects
                    PathIterator iterator1 = mock(PathIterator.class);
                    PathIterator iterator2 = mock(PathIterator.class);
            
                    // Define the behavior of iterator1
                    when(iterator1.isDone()).thenReturn(true); // iterator1 is done
                    when(iterator1.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
                    
                    // Define the behavior of iterator2
                    when(iterator2.isDone()).thenReturn(false); // iterator2 is not done
                    when(iterator2.currentSegment(any(double[].class))).thenReturn(PathIterator.SEG_MOVETO);
            
                    // Create mock GeneralPath objects
                    GeneralPath path1 = mock(GeneralPath.class);
                    GeneralPath path2 = mock(GeneralPath.class);
            
                    // Define the behavior of path1 and path2 to return the mock iterators
                    when(path1.getPathIterator(null)).thenReturn(iterator1);
                    when(path2.getPathIterator(null)).thenReturn(iterator2);
            
                    // Define the behavior of getWindingRule to be the same for both paths
                    when(path1.getWindingRule()).thenReturn(0);
                    when(path2.getWindingRule()).thenReturn(0);
            
                    // Call the method under test
                    boolean result = ShapeUtilities.equal(path1, path2);
            
                    // Assert that the result is false, as the paths are not equal
                    assertFalse("The paths should not be equal due to different iterator states.", result);
                }

    @Test
            public void testEqualWithMutantDetection5() {
                // Mock two PathIterator objects
                PathIterator iterator1 = mock(PathIterator.class);
                PathIterator iterator2 = mock(PathIterator.class);
        
                // Configure the mock to simulate the mutation scenario
                // iterator1 is done, but iterator2 is not done
                when(iterator1.isDone()).thenReturn(true);
                when(iterator2.isDone()).thenReturn(false);
        
                // Create two GeneralPath objects
                GeneralPath path1 = new GeneralPath();
                GeneralPath path2 = new GeneralPath();
        
                // Use reflection to set the mocked iterators
                try {
                    java.lang.reflect.Field field1 = GeneralPath.class.getDeclaredField("pathIterator");
                    field1.setAccessible(true);
                    field1.set(path1, iterator1);
        
                    java.lang.reflect.Field field2 = GeneralPath.class.getDeclaredField("pathIterator");
                    field2.setAccessible(true);
                    field2.set(path2, iterator2);
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
        
                // Call the equal method and assert the expected outcome
                // Since the iterators are not both done, the shapes should not be considered equal
                boolean result = ShapeUtilities.equal(path1, path2);
                assertFalse("The shapes should not be considered equal if only one iterator is done.", result);
            }

    @Test
        public void testEqualWithMutantDetection6() {
            // Mocking the Ellipse2D.Double class to simulate the behavior of getFrame() method
            Ellipse2D.Double e1 = mock(Ellipse2D.Double.class);
            Ellipse2D.Double e2 = mock(Ellipse2D.Double.class);
        
            // Mocking the behavior of getFrame() to return different Rectangle2D objects
            Rectangle2D frame1 = new Rectangle2D.Double(0, 0, 10, 10);
            Rectangle2D frame2 = new Rectangle2D.Double(0, 0, 20, 20);
            when(e1.getFrame()).thenReturn(frame1);
            when(e2.getFrame()).thenReturn(frame2);
        
            // Test case where the frames are different, should return false
            // This is to ensure that the mutation is detected
            boolean result = ShapeUtilities.equal(e1, e2);
            assertFalse("The frames are different, so the method should return false.", result);
        
            // Now, let's test the case where both frames are equal
            when(e2.getFrame()).thenReturn(frame1); // Make frames equal
        
            // Test case where the frames are the same, should return true
            result = ShapeUtilities.equal(e1, e2);
            assertTrue("The frames are the same, so the method should return true.", result);
        }

    @Test
        public void testEqualPolygonWithMutant() {
            // Create two Polygon objects
            Polygon p1 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
            Polygon p2 = new Polygon(new int[]{0, 1, 2}, new int[]{0, 1, 2}, 3);
        
            // Test the equality method
            boolean result = ShapeUtilities.equal(p1, p2);
        
            // Assert that the result is true because the polygons are identical
            assertTrue("The polygons should be equal as they have identical points.", result);
        
            // Introduce a mutation by modifying one of the polygons
            p2 = new Polygon(new int[]{0, 1, 3}, new int[]{0, 1, 2}, 3);
        
            // Test the equality method again
            result = ShapeUtilities.equal(p1, p2);
        
            // Assert that the result is false due to the mutation
            assertFalse("The polygons should not be equal after mutation.", result);
        }

    @Test
    public void testEqualLine2DWithMutant1() {
        // Mock Line2D objects
        Line2D line1 = mock(Line2D.class);
        Line2D line2 = mock(Line2D.class);
    
        // Mock the behavior of the ShapeUtilities.equal method for Line2D
        // Since the tested method is static, we cannot directly mock it using 
        // Instead, we need to test the actual behavior of the method.
    
        // Define two Line2D objects with different properties
        Line2D.Double line1Actual = new Line2D.Double(0, 0, 1, 1);
        Line2D.Double line2Actual = new Line2D.Double(0, 0, 2, 2);
    
        // Call the equal method with the actual Line2D objects
        boolean result = ShapeUtilities.equal(line1Actual, line2Actual);
    
        // Assert that the result should be false, as the lines are not equal
        assertFalse("The method should return false when the lines are not equal.", result);
    
        // Define two Line2D objects with the same properties
        Line2D.Double line1Equal = new Line2D.Double(0, 0, 1, 1);
        Line2D.Double line2Equal = new Line2D.Double(0, 0, 1, 1);
    
        // Call the equal method with the equal Line2D objects
        boolean resultEqual = ShapeUtilities.equal(line1Equal, line2Equal);
    
        // Assert that the result should be true, as the lines are equal
        assertTrue("The method should return true when the lines are equal.", resultEqual);
    }


}
