package gentest.org.jfree.chart.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.util.*;
import java.awt.Shape;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
 
public class ShapeListTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                        public void testEquals_SameInstance() {
                                            ShapeList shapeList = new ShapeList();
                                            assertTrue(shapeList.equals(shapeList));
                                        }

    @Test
                                        public void testEquals_DifferentType() {
                                            ShapeList shapeList = new ShapeList();
                                            assertFalse(shapeList.equals(new Object()));
                                        }

    @Test
                                        public void testEquals_EqualShapeLists() {
                                            ShapeList shapeList1 = new ShapeList();
                                            ShapeList shapeList2 = new ShapeList();
                                            
                                            Shape shape1 = mock(Shape.class);
                                            Shape shape2 = mock(Shape.class);
                                            
                                            shapeList1.setShape(0, shape1);
                                            shapeList2.setShape(0, shape1);
                                            
                                            when(ShapeUtilities.equal(shape1, shape1)).thenReturn(true);
                                            
                                            assertTrue(shapeList1.equals(shapeList2));
                                        }

    @Test
                                        public void testEquals_DifferentShapeLists() {
                                            ShapeList shapeList1 = new ShapeList();
                                            ShapeList shapeList2 = new ShapeList();
                                            
                                            Shape shape1 = mock(Shape.class);
                                            Shape shape2 = mock(Shape.class);
                                            
                                            shapeList1.setShape(0, shape1);
                                            shapeList2.setShape(0, shape2);
                                            
                                            when(ShapeUtilities.equal(shape1, shape2)).thenReturn(false);
                                            
                                            assertFalse(shapeList1.equals(shapeList2));
                                        }

    @Test
                                        public void testEquals_DifferentSizes() {
                                            ShapeList shapeList1 = new ShapeList();
                                            ShapeList shapeList2 = new ShapeList();
                                            
                                            Shape shape1 = mock(Shape.class);
                                            
                                            shapeList1.setShape(0, shape1);
                                            
                                            assertFalse(shapeList1.equals(shapeList2));
                                        }

    @Test
                                        public void testEquals_NullObject() {
                                            ShapeList shapeList = new ShapeList();
                                            assertFalse(shapeList.equals(null));
                                        }

    @Test
                                    public void testEqualsWithMutantDetection() {
                                        // Arrange
                                        ShapeList list1 = new ShapeList();
                                        ShapeList list2 = new ShapeList();
                                
                                        // Mock Shape objects
                                        Shape shape1 = mock(Shape.class);
                                        Shape shape2 = mock(Shape.class);
                                
                                        // Add shapes to the lists
                                        list1.setShape(0, shape1);
                                        list1.setShape(1, shape2);
                                
                                        list2.setShape(0, shape1);
                                        list2.setShape(1, shape2);
                                
                                        // Mock ShapeUtilities.equal to return true for valid comparisons
                                        mockStatic(ShapeUtilities.class);
                                        when(ShapeUtilities.equal(shape1, shape1)).thenReturn(true);
                                        when(ShapeUtilities.equal(shape2, shape2)).thenReturn(true);
                                
                                        // Act & Assert
                                        assertTrue("Lists with identical shapes should be equal", list1.equals(list2));
                                
                                        // Add an extra shape to list2 to create a size mismatch
                                        Shape shape3 = mock(Shape.class);
                                        list2.setShape(2, shape3);
                                
                                        // Act & Assert
                                        assertFalse("Lists with different sizes should not be equal", list1.equals(list2));
                                    }

    @Test
                                public void testEqualsMethodDetectsMutant() {
                                    // Create two ShapeList objects
                                    ShapeList list1 = new ShapeList();
                                    ShapeList list2 = new ShapeList();
                            
                                    // Mock Shape objects
                                    Shape shape1 = mock(Shape.class);
                                    Shape shape2 = mock(Shape.class);
                            
                                    // Assuming ShapeUtilities.equal returns true for logically equal shapes
                                    when(ShapeUtilities.equal(shape1, shape2)).thenReturn(true);
                            
                                    // Add the same shape to both lists
                                    list1.setShape(0, shape1);
                                    list2.setShape(0, shape2);
                            
                                    // Check equality using the equals method
                                    boolean areEqual = list1.equals(list2);
                            
                                    // Assert that the lists are considered equal
                                    assertTrue("The lists should be equal when shapes are logically equal", areEqual);
                                }

    @Test
                                public void testEqualsMethodDetectsMutantWithDifferentShapes() {
                                    // Create two ShapeList objects
                                    ShapeList list1 = new ShapeList();
                                    ShapeList list2 = new ShapeList();
                            
                                    // Mock Shape objects
                                    Shape shape1 = mock(Shape.class);
                                    Shape shape2 = mock(Shape.class);
                            
                                    // Assuming ShapeUtilities.equal returns false for different shapes
                                    when(ShapeUtilities.equal(shape1, shape2)).thenReturn(false);
                            
                                    // Add different shapes to both lists
                                    list1.setShape(0, shape1);
                                    list2.setShape(0, shape2);
                            
                                    // Check equality using the equals method
                                    boolean areEqual = list1.equals(list2);
                            
                                    // Assert that the lists are not considered equal
                                    assertFalse("The lists should not be equal when shapes are different", areEqual);
                                }

    @Test
                                public void testEqualsMethodDetectsMutantWithSameInstance() {
                                    // Create two ShapeList objects
                                    ShapeList list1 = new ShapeList();
                                    ShapeList list2 = new ShapeList();
                            
                                    // Mock Shape object
                                    Shape shape = mock(Shape.class);
                            
                                    // Add the same shape instance to both lists
                                    list1.setShape(0, shape);
                                    list2.setShape(0, shape);
                            
                                    // Check equality using the equals method
                                    boolean areEqual = list1.equals(list2);
                            
                                    // Assert that the lists are considered equal
                                    assertTrue("The lists should be equal when shapes are the same instance", areEqual);
                                }

    @Test
                            public void testEqualsWithMutant() {
                                // Create mock shapes
                                Shape shape1 = mock(Shape.class);
                                Shape shape2 = mock(Shape.class);
                        
                                // Mock the ShapeUtilities.equal method
                                when(ShapeUtilities.equal(shape1, shape2)).thenReturn(true);
                                when(ShapeUtilities.equal(shape2, shape1)).thenReturn(false);
                        
                                // Create two ShapeList objects
                                ShapeList list1 = new ShapeList();
                                ShapeList list2 = new ShapeList();
                        
                                // Add shapes to the lists
                                list1.setShape(0, shape1);
                                list2.setShape(0, shape2);
                        
                                // Test equality - should return false due to the mutant
                                assertFalse(list1.equals(list2));
                            }

    @Test
                            public void testEqualsWithEmptyLists() {
                                ShapeList list1 = new ShapeList();
                                ShapeList list2 = new ShapeList();
                        
                                // Both lists are empty, should be equal
                                assertTrue(list1.equals(list2));
                            }

    @Test
                            public void testEqualsWithSingleElementLists() {
                                Shape shape = mock(Shape.class);
                                when(ShapeUtilities.equal(shape, shape)).thenReturn(true);
                        
                                ShapeList list1 = new ShapeList();
                                ShapeList list2 = new ShapeList();
                        
                                list1.setShape(0, shape);
                                list2.setShape(0, shape);
                        
                                // Both lists have the same single shape, should be equal
                                assertTrue(list1.equals(list2));
                            }

    @Test
                        public void testEqualsWithDifferentSizes() {
                            // Create two ShapeList instances
                            ShapeList list1 = new ShapeList();
                            ShapeList list2 = new ShapeList();
                    
                            // Mock ShapeUtilities to always return true for equal shapes
                            ShapeUtilities mockUtilities = mock(ShapeUtilities.class);
                            when(mockUtilities.equal(any(Shape.class), any(Shape.class))).thenReturn(true);
                    
                            // Case 1: Fewer than 10 elements
                            for (int i = 0; i < 5; i++) {
                                Shape shape = mock(Shape.class);
                                list1.setShape(i, shape);
                                list2.setShape(i, shape);
                            }
                            assertTrue("Lists with fewer than 10 identical elements should be equal", list1.equals(list2));
                    
                            // Case 2: More than 10 elements
                            for (int i = 5; i < 15; i++) {
                                Shape shape = mock(Shape.class);
                                list1.setShape(i, shape);
                                list2.setShape(i, shape);
                            }
                            assertTrue("Lists with more than 10 identical elements should be equal", list1.equals(list2));
                    
                            // Case 3: Exactly 10 elements
                            ShapeList list3 = new ShapeList();
                            ShapeList list4 = new ShapeList();
                            for (int i = 0; i < 10; i++) {
                                Shape shape = mock(Shape.class);
                                list3.setShape(i, shape);
                                list4.setShape(i, shape);
                            }
                            assertTrue("Lists with exactly 10 identical elements should be equal", list3.equals(list4));
                    
                            // Case 4: Different elements within 10
                            Shape differentShape = mock(Shape.class);
                            list3.setShape(5, differentShape);
                            assertFalse("Lists with different elements should not be equal", list3.equals(list4));
                        }

    @Test
                    public void testEqualsWithMutant1() {
                        // Create two ShapeList objects
                        ShapeList list1 = new ShapeList();
                        ShapeList list2 = new ShapeList();
                
                        // Mock Shape objects to be used in the lists
                        Shape shape1 = mock(Shape.class);
                        Shape shape2 = mock(Shape.class);
                
                        // Mock the ShapeUtilities.equal method to return true for these shapes
                        when(ShapeUtilities.equal(shape1, shape1)).thenReturn(true);
                        when(ShapeUtilities.equal(shape2, shape2)).thenReturn(true);
                
                        // Add shapes to both lists
                        list1.setShape(0, shape1);
                        list2.setShape(0, shape1);
                
                        // Add another shape to list1 only
                        list1.setShape(1, shape2);
                
                        // Test equality - should return false due to different sizes
                        assertFalse(list1.equals(list2));
                
                        // Add the second shape to list2
                        list2.setShape(1, shape2);
                
                        // Now both lists are equal
                        assertTrue(list1.equals(list2));
                
                        // Create a third list with more than 10 shapes
                        ShapeList list3 = new ShapeList();
                        for (int i = 0; i < 11; i++) {
                            list3.setShape(i, shape1);
                        }
                
                        // Test equality between list1 and list3 - should return false due to different sizes
                        assertFalse(list1.equals(list3));
                
                        // Ensure the mutant is caught: list3 has more elements than list1
                        // The mutant would incorrectly iterate only 10 times and might return true
                        // if the first 10 elements are equal, but the sizes are different.
                        assertFalse(list3.equals(list1));
                    }

    @Test
                public void testEqualsDetectMutant() {
                    // Arrange
                    ShapeList list1 = new ShapeList();
                    ShapeList list2 = new ShapeList();
            
                    // Mock Shape objects
                    Shape shape1 = mock(Shape.class);
                    Shape shape2 = mock(Shape.class);
                    Shape shape3 = mock(Shape.class);
            
                    // Mock ShapeUtilities.equal behavior
                    // Assuming ShapeUtilities.equal returns true for identical shapes
                    mockStatic(ShapeUtilities.class);
                    when(ShapeUtilities.equal(shape1, shape1)).thenReturn(true);
                    when(ShapeUtilities.equal(shape2, shape2)).thenReturn(true);
                    when(ShapeUtilities.equal(shape3, shape3)).thenReturn(true);
                    when(ShapeUtilities.equal(shape1, shape2)).thenReturn(false);
                    when(ShapeUtilities.equal(shape2, shape3)).thenReturn(false);
            
                    // Populate the lists
                    list1.setShape(0, shape1);
                    list1.setShape(1, shape2);
                    list1.setShape(2, shape3);
            
                    list2.setShape(0, shape1);
                    list2.setShape(1, shape2);
                    list2.setShape(2, shape3);
            
                    // Act & Assert: Test case 1 - Identical lists (should return true)
                    assertTrue("Identical lists should be equal", list1.equals(list2));
            
                    // Modify list2 to introduce a difference at an odd index
                    list2.setShape(1, shape3);
            
                    // Act & Assert: Test case 2 - Lists differ at an odd index (should return false)
                    assertFalse("Lists with differences at odd indices should not be equal", list1.equals(list2));
            
                    // Modify list2 to introduce a difference at an even index
                    list2.setShape(0, shape2);
            
                    // Act & Assert: Test case 3 - Lists differ at an even index (should return false)
                    assertFalse("Lists with differences at even indices should not be equal", list1.equals(list2));
                }

    @Test
            public void testEqualsDetectMutant1() {
                // Step 1: Create two ShapeList objects with identical contents
                ShapeList shapeList1 = new ShapeList();
                ShapeList shapeList2 = new ShapeList();
        
                // Mock the behavior of the get method to simulate identical contents
                Shape shapeMock1 = mock(Shape.class);
                Shape shapeMock2 = mock(Shape.class);
        
                // Assume ShapeUtilities.equal returns true when comparing the same shapes
                when(ShapeUtilities.equal(shapeMock1, shapeMock2)).thenReturn(true);
        
                // Add shapes to both ShapeList objects
                shapeList1.setShape(0, shapeMock1);
                shapeList2.setShape(0, shapeMock2);
        
                // Step 2: Verify that the equals method returns true for identical ShapeLists
                assertTrue("Expected shapeList1 to be equal to shapeList2", shapeList1.equals(shapeList2));
        
                // Step 3: Create a new ShapeList object to simulate the mutant behavior
                ShapeList shapeList3 = new ShapeList();
        
                // Add a different shape to shapeList3 to ensure it is not equal
                Shape differentShapeMock = mock(Shape.class);
                shapeList3.setShape(0, differentShapeMock);
        
                // Assume ShapeUtilities.equal returns false for different shapes
                when(ShapeUtilities.equal(shapeMock1, differentShapeMock)).thenReturn(false);
        
                // Step 4: Verify that the equals method returns false for non-identical ShapeLists
                assertFalse("Expected shapeList1 to not be equal to shapeList3", shapeList1.equals(shapeList3));
        
                // Step 5: Verify the mutant behavior
                // If the mutant is present, the equals method will incorrectly compare shapeList1 to a new ShapeList
                assertFalse("Expected shapeList1 to not be equal to a new ShapeList instance", shapeList1.equals(new ShapeList()));
            }

    @Test
        public void testEqualsDetectMutant2() {
            // Step 1: Create two ShapeList objects
            ShapeList list1 = new ShapeList();
            ShapeList list2 = new ShapeList();
    
            // Step 2: Mock Shape objects to use in the ShapeList
            Shape shape1 = mock(Shape.class);
            Shape shape2 = mock(Shape.class);
    
            // Step 3: Add shapes to both lists
            list1.setShape(0, shape1);
            list2.setShape(0, shape2);
    
            // Step 4: Mock ShapeUtilities.equal behavior
            // Simulate the behavior where the shapes are not equal
            when(ShapeUtilities.equal(shape1, shape2)).thenReturn(false);
    
            // Step 5: Assert that the equals method returns false
            // This should catch the mutant because the mutated code would incorrectly return true && false (which is false).
            assertFalse("The equals method should return false when shapes are not equal", list1.equals(list2));
    
            // Step 6: Add edge cases to ensure robustness
            // Case: Comparing a ShapeList with itself
            assertTrue("The equals method should return true when comparing the same object", list1.equals(list1));
    
            // Case: Comparing a ShapeList with a null object
            assertFalse("The equals method should return false when comparing with null", list1.equals(null));
    
            // Case: Comparing a ShapeList with an object of a different type
            assertFalse("The equals method should return false when comparing with a different type", list1.equals(new Object()));
    
            // Case: Comparing two empty ShapeLists
            ShapeList emptyList1 = new ShapeList();
            ShapeList emptyList2 = new ShapeList();
            assertTrue("The equals method should return true when comparing two empty ShapeLists", emptyList1.equals(emptyList2));
        }

}
