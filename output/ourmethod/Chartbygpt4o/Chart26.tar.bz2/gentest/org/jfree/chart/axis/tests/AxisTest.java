package gentest.org.jfree.chart.axis.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.axis.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.EventListener;
import java.util.List;
import javax.swing.event.EventListenerList;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.entity.AxisLabelEntity;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.event.AxisChangeEvent;
import org.jfree.chart.event.AxisChangeListener;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.text.TextAnchor;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
 
public class AxisTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testDrawLabel_EmptyLabel() throws Exception {
                // Use a concrete subclass of Axis, e.g., CategoryAxis
                Axis axis = new CategoryAxis("Test Axis");
                Graphics2D g2 = mock(Graphics2D.class);
                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                RectangleEdge edge = RectangleEdge.TOP;
                AxisState state = mock(AxisState.class);
                PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
        
                // Use reflection to access the protected drawLabel method
                Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                drawLabelMethod.setAccessible(true);
        
                AxisState result = (AxisState) drawLabelMethod.invoke(axis, "", g2, plotArea, dataArea, edge, state, plotState);
                assertEquals(state, result);
            }

    @Test
            public void testDrawLabel_NonEmptyLabel() throws Exception {
                // Mock the Axis class
                Axis axis = mock(Axis.class);
        
                // Mock other dependencies
                Graphics2D g2 = mock(Graphics2D.class);
                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                RectangleEdge edge = RectangleEdge.TOP;
                AxisState state = mock(AxisState.class);
                PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
        
                // Set up the mock behavior
                Font font = new Font("Serif", Font.PLAIN, 12);
                RectangleInsets insets = new RectangleInsets(1, 1, 1, 1);
                Paint paint = Color.BLACK;
        
                when(axis.getLabelFont()).thenReturn(font);
                when(axis.getLabelInsets()).thenReturn(insets);
                when(axis.getLabelPaint()).thenReturn(paint);
                when(g2.getFontMetrics()).thenReturn(mock(FontMetrics.class));
        
                // Use reflection to access the protected drawLabel method
                Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                drawLabelMethod.setAccessible(true);
        
                // Invoke the drawLabel method
                AxisState result = (AxisState) drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, state, plotState);
        
                // Verify the results
                assertNotNull(result);
                verify(g2).setFont(font);
                verify(g2).setPaint(paint);
            }

    @Test
        public void testDrawLabel_LabelPositioningTopEdge() throws Exception {
            // Create a mock subclass of Axis since Axis is abstract
            Axis axis = mock(Axis.class, withSettings().useConstructor("Test Axis").defaultAnswer(CALLS_REAL_METHODS));
        
            Graphics2D g2 = mock(Graphics2D.class);
            Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
            Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
            RectangleEdge edge = RectangleEdge.TOP;
            AxisState state = mock(AxisState.class);
            PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
        
            Font font = new Font("Serif", Font.PLAIN, 12);
            RectangleInsets insets = new RectangleInsets(1, 1, 1, 1);
            Paint paint = Color.BLACK;
        
            when(axis.getLabelFont()).thenReturn(font);
            when(axis.getLabelInsets()).thenReturn(insets);
            when(axis.getLabelPaint()).thenReturn(paint);
            when(g2.getFontMetrics()).thenReturn(mock(FontMetrics.class));
        
            // Use reflection to access the protected method
            Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
            drawLabelMethod.setAccessible(true);
        
            AxisState result = (AxisState) drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, state, plotState);
        
            assertNotNull(result);
            verify(g2).setFont(font);
            verify(g2).setPaint(paint);
            // Additional verification for drawing operations can be added here
        }

    @Test
            public void testDrawLabel_LabelPositioningBottomEdge() throws Exception {
                // Create a mock of the Axis class
                Axis axis = mock(Axis.class);
        
                Graphics2D g2 = mock(Graphics2D.class);
                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                RectangleEdge edge = RectangleEdge.BOTTOM;
                AxisState state = mock(AxisState.class);
                PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
        
                Font font = new Font("Serif", Font.PLAIN, 12);
                RectangleInsets insets = new RectangleInsets(1, 1, 1, 1);
                Paint paint = Color.BLACK;
        
                when(axis.getLabelFont()).thenReturn(font);
                when(axis.getLabelInsets()).thenReturn(insets);
                when(axis.getLabelPaint()).thenReturn(paint);
                when(g2.getFontMetrics()).thenReturn(mock(FontMetrics.class));
        
                // Use reflection to access the protected drawLabel method
                Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                drawLabelMethod.setAccessible(true);
        
                AxisState result = (AxisState) drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, state, plotState);
        
                assertNotNull(result);
                verify(g2).setFont(font);
                verify(g2).setPaint(paint);
                // Additional verification for drawing operations can be added here
            }

    @Test
            public void testDrawLabel_EntityCollectionInteraction() throws Exception {
                // Use a concrete subclass of Axis, e.g., CategoryAxis
                Axis axis = new CategoryAxis("Test Axis");
        
                Graphics2D g2 = mock(Graphics2D.class);
                Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
                Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
                RectangleEdge edge = RectangleEdge.TOP;
                AxisState state = mock(AxisState.class);
                PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
                ChartRenderingInfo owner = mock(ChartRenderingInfo.class);
                EntityCollection entities = mock(EntityCollection.class);
        
                when(plotState.getOwner()).thenReturn(owner);
                when(owner.getEntityCollection()).thenReturn(entities);
        
                // Use reflection to access the protected drawLabel method
                Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
                drawLabelMethod.setAccessible(true);
        
                AxisState result = (AxisState) drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, state, plotState);
        
                assertNotNull(result);
                verify(entities).add(any(AxisLabelEntity.class));
            }

    @Test
    public void testDrawLabel_NullState() throws Exception {
        // Use a concrete subclass of Axis, e.g., CategoryAxis
        CategoryAxis axis = new CategoryAxis("Test Axis");
        Graphics2D g2 = mock(Graphics2D.class);
        Rectangle2D plotArea = new Rectangle2D.Double(0, 0, 100, 100);
        Rectangle2D dataArea = new Rectangle2D.Double(0, 0, 100, 100);
        RectangleEdge edge = RectangleEdge.TOP;
        PlotRenderingInfo plotState = mock(PlotRenderingInfo.class);
    
        try {
            // Use reflection to access the protected drawLabel method
            Method drawLabelMethod = Axis.class.getDeclaredMethod("drawLabel", String.class, Graphics2D.class, Rectangle2D.class, Rectangle2D.class, RectangleEdge.class, AxisState.class, PlotRenderingInfo.class);
            drawLabelMethod.setAccessible(true);
    
            // Invoke the method with null state
            drawLabelMethod.invoke(axis, "Label", g2, plotArea, dataArea, edge, null, plotState);
            fail("Expected IllegalArgumentException to be thrown");
        } catch (InvocationTargetException e) {
            // Check if the cause is the expected IllegalArgumentException
            Throwable cause = e.getCause();
            assertTrue(cause instanceof IllegalArgumentException);
            assertEquals("Null 'state' argument.", cause.getMessage());
        }
    }


}
