package gentest.org.jfree.data.xy.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.xy.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class XYSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                            public void testAddOrUpdate_TypicalValues() {
                                                                                                                                // Arrange
                                                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                                                double x1 = 1.0, y1 = 2.0;
                                                                                                                                double x2 = 3.0, y2 = 4.0;
                                                                                                                        
                                                                                                                                // Act
                                                                                                                                XYDataItem result1 = series.addOrUpdate(x1, y1);
                                                                                                                                XYDataItem result2 = series.addOrUpdate(x2, y2);
                                                                                                                        
                                                                                                                                // Assert
                                                                                                                                assertNull(result1); // No previous value for x1
                                                                                                                                assertNull(result2); // No previous value for x2
                                                                                                                                assertEquals(2, series.getItemCount());
                                                                                                                                assertEquals(x1, series.getX(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y1, series.getY(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(x2, series.getX(1).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y2, series.getY(1).doubleValue(), 0.00001);
                                                                                                                            }

    @Test
                                                                                                                            public void testAddOrUpdate_UpdateExistingValue() {
                                                                                                                                // Arrange
                                                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                                                double x = 1.0, yInitial = 2.0, yUpdated = 3.0;
                                                                                                                                series.add(x, yInitial);
                                                                                                                        
                                                                                                                                // Act
                                                                                                                                XYDataItem previousItem = series.addOrUpdate(x, yUpdated);
                                                                                                                        
                                                                                                                                // Assert
                                                                                                                                assertNotNull(previousItem);
                                                                                                                                assertEquals(x, previousItem.getX().doubleValue(), 0.00001);
                                                                                                                                assertEquals(yInitial, previousItem.getY().doubleValue(), 0.00001);
                                                                                                                                assertEquals(1, series.getItemCount());
                                                                                                                                assertEquals(x, series.getX(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(yUpdated, series.getY(0).doubleValue(), 0.00001);
                                                                                                                            }

    @Test
                                                                                                                            public void testAddOrUpdate_AutoSortEnabled() {
                                                                                                                                // Arrange
                                                                                                                                XYSeries series = new XYSeries("Test Series", true);
                                                                                                                                double x1 = 3.0, y1 = 2.0;
                                                                                                                                double x2 = 1.0, y2 = 4.0;
                                                                                                                        
                                                                                                                                // Act
                                                                                                                                series.addOrUpdate(x1, y1);
                                                                                                                                series.addOrUpdate(x2, y2);
                                                                                                                        
                                                                                                                                // Assert
                                                                                                                                assertEquals(2, series.getItemCount());
                                                                                                                                assertEquals(x2, series.getX(0).doubleValue(), 0.00001); // Sorted by x
                                                                                                                                assertEquals(y2, series.getY(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(x1, series.getX(1).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y1, series.getY(1).doubleValue(), 0.00001);
                                                                                                                            }

    @Test
                                                                                                                            public void testAddOrUpdate_DuplicateXValuesAllowed() {
                                                                                                                                // Arrange
                                                                                                                                XYSeries series = new XYSeries("Test Series", true, true);
                                                                                                                                double x = 1.0, y1 = 2.0, y2 = 3.0;
                                                                                                                        
                                                                                                                                // Act
                                                                                                                                series.addOrUpdate(x, y1);
                                                                                                                                series.addOrUpdate(x, y2);
                                                                                                                        
                                                                                                                                // Assert
                                                                                                                                assertEquals(2, series.getItemCount()); // Duplicate x values allowed
                                                                                                                                assertEquals(x, series.getX(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y1, series.getY(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(x, series.getX(1).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y2, series.getY(1).doubleValue(), 0.00001);
                                                                                                                            }

    @Test
                                                                                                                            public void testAddOrUpdate_MaximumItemCountExceeded() {
                                                                                                                                // Arrange
                                                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                                                series.setMaximumItemCount(2);
                                                                                                                                double x1 = 1.0, y1 = 2.0;
                                                                                                                                double x2 = 3.0, y2 = 4.0;
                                                                                                                                double x3 = 5.0, y3 = 6.0;
                                                                                                                        
                                                                                                                                // Act
                                                                                                                                series.addOrUpdate(x1, y1);
                                                                                                                                series.addOrUpdate(x2, y2);
                                                                                                                                series.addOrUpdate(x3, y3);
                                                                                                                        
                                                                                                                                // Assert
                                                                                                                                assertEquals(2, series.getItemCount()); // Maximum item count is 2
                                                                                                                                assertEquals(x2, series.getX(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y2, series.getY(0).doubleValue(), 0.00001);
                                                                                                                                assertEquals(x3, series.getX(1).doubleValue(), 0.00001);
                                                                                                                                assertEquals(y3, series.getY(1).doubleValue(), 0.00001);
                                                                                                                            }

    @Test
                                                                                                                            public void testAddOrUpdate_NullValues() {
                                                                                                                                // Arrange
                                                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                                        
                                                                                                                                // Act & Assert
                                                                                                                                try {
                                                                                                                                    series.addOrUpdate(null, 2.0);
                                                                                                                                    fail("Expected IllegalArgumentException for null x value");
                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                    assertEquals("Null 'x' argument.", e.getMessage());
                                                                                                                                }
                                                                                                                        
                                                                                                                                try {
                                                                                                                                    series.addOrUpdate(1.0, null);
                                                                                                                                    fail("Expected IllegalArgumentException for null y value");
                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                    assertEquals("Null 'y' argument.", e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                        public void testAddOrUpdate_NullX_ThrowsException() {
                                                                                                                            // Create an instance of XYSeries
                                                                                                                            XYSeries series = new XYSeries("Test Series");
                                                                                                                    
                                                                                                                            // Set up the expected exception
                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                            thrown.expectMessage("Null 'x' argument.");
                                                                                                                    
                                                                                                                            // Call the method with a null 'x' value
                                                                                                                            series.addOrUpdate(null, 5);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddOrUpdate_AllowDuplicateXValues() {
                                                                                                                            // Define the series variable within the test method
                                                                                                                            XYSeries series = new XYSeries("Test Series", true, true);
                                                                                                                            
                                                                                                                            // Test the addOrUpdate method
                                                                                                                            assertNull(series.addOrUpdate(1, 1));
                                                                                                                            assertNull(series.addOrUpdate(1, 2)); // Should allow duplicate x
                                                                                                                            
                                                                                                                            // Assert the item count
                                                                                                                            assertEquals(2, series.getItemCount());
                                                                                                                        }

    @Test
                                                                                                                        public void testAddOrUpdate_DisallowDuplicateXValues_UpdateExisting() {
                                                                                                                            // Create an instance of XYSeries with a key and disallow duplicate X values
                                                                                                                            XYSeries series = new XYSeries("Test Series", true, false);
                                                                                                                    
                                                                                                                            // Add or update a data item with x = 1, y = 1
                                                                                                                            series.addOrUpdate(1, 1);
                                                                                                                    
                                                                                                                            // Add or update a data item with x = 1, y = 2 and capture the old item
                                                                                                                            XYDataItem oldItem = series.addOrUpdate(1, 2);
                                                                                                                    
                                                                                                                            // Assert that the old item is not null
                                                                                                                            assertNotNull(oldItem);
                                                                                                                    
                                                                                                                            // Assert that the old item's x value is 1.0
                                                                                                                            assertEquals(1.0, oldItem.getX().doubleValue(), 0.0001);
                                                                                                                    
                                                                                                                            // Assert that the old item's y value is 1.0
                                                                                                                            assertEquals(1.0, oldItem.getY().doubleValue(), 0.0001);
                                                                                                                    
                                                                                                                            // Assert that the series has only one item
                                                                                                                            assertEquals(1, series.getItemCount());
                                                                                                                    
                                                                                                                            // Assert that the y value of the first item in the series is 2.0
                                                                                                                            assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddOrUpdate_DisallowDuplicateXValues_AddNew() {
                                                                                                                            // Create an XYSeries object with the key "Series1", autoSort true, and disallow duplicate X values
                                                                                                                            XYSeries series = new XYSeries("Series1", true, false);
                                                                                                                    
                                                                                                                            // Add or update points in the series
                                                                                                                            series.addOrUpdate(1, 1);
                                                                                                                            series.addOrUpdate(2, 2);
                                                                                                                    
                                                                                                                            // Assert that the series contains 2 items
                                                                                                                            assertEquals(2, series.getItemCount());
                                                                                                                    
                                                                                                                            // Assert that the X values are as expected
                                                                                                                            assertEquals(1.0, series.getX(0).doubleValue(), 0.0001);
                                                                                                                            assertEquals(2.0, series.getX(1).doubleValue(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddOrUpdate_AutoSort() {
                                                                                                                            // Define the series variable within the method
                                                                                                                            XYSeries series = new XYSeries("Test Series", true, false);
                                                                                                                            
                                                                                                                            // Use the addOrUpdate method
                                                                                                                            series.addOrUpdate(2, 2);
                                                                                                                            series.addOrUpdate(1, 1);
                                                                                                                            
                                                                                                                            // Use assertEquals with the correct expected and actual values
                                                                                                                            assertEquals(1.0, series.getX(0).doubleValue(), 0.0000001);
                                                                                                                            assertEquals(2.0, series.getX(1).doubleValue(), 0.0000001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddOrUpdate_NoAutoSort() {
                                                                                                                            // Define and initialize the series object
                                                                                                                            XYSeries series = new XYSeries("Test Series", false, false);
                                                                                                                    
                                                                                                                            // Call the addOrUpdate method
                                                                                                                            series.addOrUpdate(2.0, 2.0);
                                                                                                                            series.addOrUpdate(1.0, 1.0);
                                                                                                                    
                                                                                                                            // Verify the order of elements in the series
                                                                                                                            assertEquals(2.0, series.getX(0).doubleValue(), 0.00001);
                                                                                                                            assertEquals(1.0, series.getX(1).doubleValue(), 0.00001);
                                                                                                                        }

    @Test
                                                                                                                        public void testAddOrUpdate_ExceedMaximumItemCount() {
                                                                                                                            // Initialize the XYSeries object with a key
                                                                                                                            XYSeries series = new XYSeries("Test Series");
                                                                                                                    
                                                                                                                            // Set maximum item count to 2
                                                                                                                            series.setMaximumItemCount(2);
                                                                                                                    
                                                                                                                            // Add or update items
                                                                                                                            series.addOrUpdate(1, 1);
                                                                                                                            series.addOrUpdate(2, 2);
                                                                                                                            series.addOrUpdate(3, 3); // Should remove the first item (1, 1)
                                                                                                                    
                                                                                                                            // Assert the item count and the values
                                                                                                                            assertEquals(2, series.getItemCount());
                                                                                                                            assertEquals(2.0, series.getX(0).doubleValue());
                                                                                                                            assertEquals(3.0, series.getX(1).doubleValue());
                                                                                                                        }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                    public void testAddOrUpdate_NullX_ThrowsException1() {
                                                                                                                        // Arrange
                                                                                                                        XYSeries series = new XYSeries("Test Series");
                                                                                                                
                                                                                                                        // Act
                                                                                                                        // This should throw an IllegalArgumentException if the method is implemented correctly.
                                                                                                                        series.addOrUpdate(null, 5.0);
                                                                                                                
                                                                                                                        // Assert
                                                                                                                        // The @Test(expected = IllegalArgumentException.class) annotation will handle the assertion.
                                                                                                                    }

    @Test
                                                                                                                public void testAddOrUpdate_NullX_ThrowsIllegalArgumentException() {
                                                                                                                    // Create an instance of XYSeries
                                                                                                                    XYSeries series = new XYSeries("Test Series");
                                                                                                            
                                                                                                                    // Set up the expected exception
                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                    thrown.expectMessage("Null 'x' argument.");
                                                                                                            
                                                                                                                    // Call the method with null x to trigger the exception
                                                                                                                    series.addOrUpdate(null, 5.0);
                                                                                                                }

    @Test
                                                                                                            public void testAddOrUpdate_MutantDetection() {
                                                                                                                // Step 1: Set up the test environment
                                                                                                                // Create an instance of XYSeries with allowDuplicateXValues set to true
                                                                                                                XYSeries series = new XYSeries("Test Series", true, true);
                                                                                                        
                                                                                                                // Step 2: Add an initial data point with a null y-value
                                                                                                                series.add(1.0, null);
                                                                                                        
                                                                                                                // Step 3: Add another data point with the same x-value but a non-null y-value
                                                                                                                // This should trigger the condition in the mutated code
                                                                                                                series.addOrUpdate(1.0, 2.0);
                                                                                                        
                                                                                                                // Step 4: Verify the behavior
                                                                                                                // In the original code, the second addOrUpdate should replace the first data point
                                                                                                                // because allowDuplicateXValues is true. However, the mutant introduces an additional
                                                                                                                // condition (y != null), which could prevent the replacement if y is null.
                                                                                                                assertEquals("The series should contain exactly one data point.", 1, series.getItemCount());
                                                                                                                assertEquals("The y-value of the data point should be updated to 2.0.", 2.0, series.getY(0).doubleValue(), 0.0001);
                                                                                                        
                                                                                                                // Step 5: Add another test case to ensure the mutant is caught
                                                                                                                // Add a data point with a null y-value again to verify the behavior
                                                                                                                series.addOrUpdate(1.0, null);
                                                                                                        
                                                                                                                // Verify that the y-value is updated to null (original behavior)
                                                                                                                assertEquals("The series should still contain exactly one data point.", 1, series.getItemCount());
                                                                                                                assertNull("The y-value of the data point should be updated to null.", series.getY(0));
                                                                                                            }

    @Test
                                                                                                        public void testAddOrUpdateWithNullYAndAllowDuplicateXValues() {
                                                                                                            // Create an instance of XYSeries with allowDuplicateXValues set to true
                                                                                                            XYSeries series = new XYSeries("Test Series", true, true);
                                                                                                    
                                                                                                            Number x = 1.0;
                                                                                                            Number y = null;
                                                                                                    
                                                                                                            // Add an item with a non-null y value first to ensure the list is not empty
                                                                                                            series.addOrUpdate(x, 2.0);
                                                                                                    
                                                                                                            // Now attempt to add an item with a null y value
                                                                                                            XYDataItem result = series.addOrUpdate(x, y);
                                                                                                    
                                                                                                            // Verify that the item was added (i.e., the list size should be 2)
                                                                                                            assertEquals(2, series.getItemCount());
                                                                                                    
                                                                                                            // Verify that the result is null (no item was overwritten)
                                                                                                            assertNull(result);
                                                                                                    
                                                                                                            // Verify that the y value of the added item is null
                                                                                                            assertNull(series.getY(1));
                                                                                                        }

    @Test
                                                                                                    public void testAddOrUpdateWithNullXWhenAllowDuplicateXValuesIsFalse() {
                                                                                                        // Arrange
                                                                                                        XYSeries series = new XYSeries("Test Series", true, false); // autoSort = true, allowDuplicateXValues = false
                                                                                                        Number yValue = 10.0;
                                                                                                
                                                                                                        // Act
                                                                                                        try {
                                                                                                            series.addOrUpdate(null, yValue);
                                                                                                            fail("Expected IllegalArgumentException when x is null and allowDuplicateXValues is false.");
                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                            // Assert
                                                                                                            assertEquals("Null 'x' argument.", e.getMessage());
                                                                                                        }
                                                                                                    }

    @Test
                                                                                                    public void testAddOrUpdateWithNullXWhenAllowDuplicateXValuesIsTrue() {
                                                                                                        // Arrange
                                                                                                        XYSeries series = new XYSeries("Test Series", true, true); // autoSort = true, allowDuplicateXValues = true
                                                                                                        Number yValue = 10.0;
                                                                                                
                                                                                                        // Act
                                                                                                        XYDataItem result = series.addOrUpdate(null, yValue);
                                                                                                
                                                                                                        // Assert
                                                                                                        assertNotNull(result); // Ensure the method executes successfully
                                                                                                        assertEquals(null, result.getX());
                                                                                                        assertEquals(yValue, result.getY());
                                                                                                    }

    @Test
                                                                                                public void testAddOrUpdateWithNullX() {
                                                                                                    // Create an instance of XYSeries to test the addOrUpdate method
                                                                                                    XYSeries series = new XYSeries("Test Series");
                                                                                            
                                                                                                    // This test is designed to catch the mutant by ensuring that a null 'x' throws an exception
                                                                                                    try {
                                                                                                        series.addOrUpdate(null, 5.0);
                                                                                                        fail("Expected IllegalArgumentException to be thrown");
                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                        assertEquals("Null 'x' argument.", e.getMessage());
                                                                                                    }
                                                                                                }

    @Test
                                                                                            public void testAddOrUpdateDetectMutant() {
                                                                                                // Step 1: Set up the test environment
                                                                                                XYSeries series = new XYSeries("Test Series");
                                                                                                
                                                                                                // Add initial data to the series
                                                                                                series.add(1.0, 2.0); // Index 0
                                                                                                series.add(2.0, 3.0); // Index 1
                                                                                                series.add(3.0, 4.0); // Index 2
                                                                                        
                                                                                                // Verify initial state
                                                                                                assertEquals(3, series.getItemCount());
                                                                                                assertEquals(2.0, series.getY(0).doubleValue(), 0.0001);
                                                                                                assertEquals(3.0, series.getY(1).doubleValue(), 0.0001);
                                                                                                assertEquals(4.0, series.getY(2).doubleValue(), 0.0001);
                                                                                        
                                                                                                // Step 2: Call addOrUpdate with an existing x-value (index 1)
                                                                                                XYDataItem updatedItem = series.addOrUpdate(2.0, 5.0);
                                                                                        
                                                                                                // Step 3: Verify the behavior
                                                                                                // The original item at index 1 should be updated
                                                                                                assertNotNull(updatedItem);
                                                                                                assertEquals(3.0, updatedItem.getYValue(), 0.0001); // The old value at index 1
                                                                                                assertEquals(5.0, series.getY(1).doubleValue(), 0.0001); // The new value at index 1
                                                                                        
                                                                                                // Verify that other items are unaffected
                                                                                                assertEquals(2.0, series.getY(0).doubleValue(), 0.0001); // Index 0 remains unchanged
                                                                                                assertEquals(4.0, series.getY(2).doubleValue(), 0.0001); // Index 2 remains unchanged
                                                                                        
                                                                                                // Step 4: Detect the mutant
                                                                                                // If the mutant is present, the item at index 0 will be updated instead of index 1
                                                                                                assertEquals(2.0, series.getY(0).doubleValue(), 0.0001); // This assertion will fail if the mutant is present
                                                                                            }

    @Test
                                                                                        public void testAddOrUpdateDetectsMutant() {
                                                                                            // Create an instance of XYSeries
                                                                                            XYSeries series = new XYSeries("Test Series");
                                                                                    
                                                                                            // Add initial data
                                                                                            series.add(1.0, 1.0);
                                                                                            series.add(2.0, 2.0);
                                                                                            series.add(3.0, 3.0);
                                                                                    
                                                                                            // Update the item with x = 2.0
                                                                                            XYDataItem overwritten = series.addOrUpdate(2.0, 4.0);
                                                                                    
                                                                                            // Verify that the correct item was updated
                                                                                            assertNotNull("Overwritten item should not be null", overwritten);
                                                                                            assertEquals("Overwritten item's x value should be 2.0", 2.0, overwritten.getX().doubleValue(), 0.0001);
                                                                                            assertEquals("Overwritten item's y value should be 2.0", 2.0, overwritten.getY().doubleValue(), 0.0001);
                                                                                    
                                                                                            // Verify the updated value in the series
                                                                                            XYDataItem updatedItem = series.getDataItem(1); // index 1 should correspond to x = 2.0
                                                                                            assertEquals("Updated item's x value should be 2.0", 2.0, updatedItem.getX().doubleValue(), 0.0001);
                                                                                            assertEquals("Updated item's y value should be 4.0", 4.0, updatedItem.getY().doubleValue(), 0.0001);
                                                                                    
                                                                                            // Verify that the first item remains unchanged
                                                                                            XYDataItem firstItem = series.getDataItem(0);
                                                                                            assertEquals("First item's x value should be 1.0", 1.0, firstItem.getX().doubleValue(), 0.0001);
                                                                                            assertEquals("First item's y value should be 1.0", 1.0, firstItem.getY().doubleValue(), 0.0001);
                                                                                        }

    @Test
                                                                                public void testAddOrUpdateWithNullXWhenAllowDuplicateXValuesIsTrue1() {
                                                                                    // Step 1: Set up the test environment
                                                                                    // Create an instance of XYSeries with allowDuplicateXValues set to true
                                                                                    XYSeries series = new XYSeries("Test Series", true, true);
                                                                            
                                                                                    // Mock the data list to observe interactions
                                                                                    ArrayList<XYDataItem> mockData = mock(ArrayList.class);
                                                                            
                                                                                    try {
                                                                                        // Use reflection to set the protected 'data' field
                                                                                        Field dataField = XYSeries.class.getDeclaredField("data");
                                                                                        dataField.setAccessible(true);
                                                                                        dataField.set(series, mockData);
                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                        fail("Failed to set the data field using reflection: " + e.getMessage());
                                                                                    }
                                                                            
                                                                                    // Step 2: Call the method under test with a null x value
                                                                                    Number x = null;
                                                                                    Number y = 10.0;
                                                                            
                                                                                    try {
                                                                                        series.addOrUpdate(x, y);
                                                                                        fail("Expected NullPointerException to be thrown when x is null.");
                                                                                    } catch (NullPointerException e) {
                                                                                        // Expected behavior
                                                                                    }
                                                                            
                                                                                    // Verify that no interactions occurred with the data list
                                                                                    verify(mockData, never()).add(any(XYDataItem.class));
                                                                                }

    @Test
                                                                                public void testAddOrUpdateWithNullXWhenAllowDuplicateXValuesIsFalse1() {
                                                                                    // Step 1: Set up the test environment
                                                                                    // Create an instance of XYSeries with allowDuplicateXValues set to false
                                                                                    XYSeries series = new XYSeries("Test Series", true, false);
                                                                            
                                                                                    // Mock the data list to observe interactions
                                                                                    List<XYDataItem> mockData = mock(ArrayList.class);
                                                                            
                                                                                    // Use reflection to set the protected 'data' field
                                                                                    try {
                                                                                        Field dataField = XYSeries.class.getDeclaredField("data");
                                                                                        dataField.setAccessible(true);
                                                                                        dataField.set(series, mockData);
                                                                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                        fail("Failed to set up mock data list using reflection.");
                                                                                    }
                                                                            
                                                                                    // Step 2: Call the method under test with a null x value
                                                                                    Number x = null;
                                                                                    Number y = 10.0;
                                                                            
                                                                                    try {
                                                                                        series.addOrUpdate(x, y);
                                                                                        fail("Expected NullPointerException to be thrown when x is null.");
                                                                                    } catch (NullPointerException e) {
                                                                                        // Expected behavior
                                                                                    }
                                                                            
                                                                                    // Verify that no interactions occurred with the data list
                                                                                    verify(mockData, never()).add(any(XYDataItem.class));
                                                                                }

    @Test
                                                                                public void testAddOrUpdateWithValidXWhenAllowDuplicateXValuesIsTrue() throws Exception {
                                                                                    // Step 1: Set up the test environment
                                                                                    // Create an instance of XYSeries with allowDuplicateXValues set to true
                                                                                    XYSeries series = new XYSeries("Test Series", true, true);
                                                                            
                                                                                    // Mock the data list to observe interactions
                                                                                    ArrayList<XYDataItem> mockData = mock(ArrayList.class);
                                                                            
                                                                                    // Use reflection to set the protected 'data' field
                                                                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                                                                    dataField.setAccessible(true);
                                                                                    dataField.set(series, mockData);
                                                                            
                                                                                    // Step 2: Call the method under test with a valid x value
                                                                                    Number x = 5.0;
                                                                                    Number y = 10.0;
                                                                            
                                                                                    series.addOrUpdate(x, y);
                                                                            
                                                                                    // Verify that the data list was updated correctly
                                                                                    verify(mockData).add(any(XYDataItem.class));
                                                                                }

    @Test
                                                                                public void testAddOrUpdateWithValidXWhenAllowDuplicateXValuesIsFalse() throws Exception {
                                                                                    // Step 1: Set up the test environment
                                                                                    // Create an instance of XYSeries with allowDuplicateXValues set to false
                                                                                    XYSeries series = new XYSeries("Test Series", true, false);
                                                                            
                                                                                    // Mock the data list to observe interactions
                                                                                    ArrayList<XYDataItem> mockData = mock(ArrayList.class);
                                                                            
                                                                                    // Use reflection to set the protected 'data' field
                                                                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                                                                    dataField.setAccessible(true);
                                                                                    dataField.set(series, mockData);
                                                                            
                                                                                    // Step 2: Call the method under test with a valid x value
                                                                                    Number x = 5.0;
                                                                                    Number y = 10.0;
                                                                            
                                                                                    series.addOrUpdate(x, y);
                                                                            
                                                                                    // Verify that the data list was updated correctly
                                                                                    verify(mockData).add(any(XYDataItem.class));
                                                                                }

    @Test
                                                                                public void testAddOrUpdateDetectMutant1() throws Exception {
                                                                                    // Step 1: Setup the test environment
                                                                                    // Create an instance of XYSeries with allowDuplicateXValues set to true
                                                                                    XYSeries series = new XYSeries("Test Series", true, true);
                                                                            
                                                                                    // Mock the data list to observe its behavior
                                                                                    ArrayList<XYDataItem> mockData = spy(new ArrayList<>());
                                                                            
                                                                                    // Use reflection to set the protected 'data' field
                                                                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                                                                    dataField.setAccessible(true);
                                                                                    dataField.set(series, mockData);
                                                                            
                                                                                    // Step 2: Define test inputs
                                                                                    Number x = null; // This is the edge case that the mutant introduces
                                                                                    Number y = 5;
                                                                            
                                                                                    // Step 3: Execute the method and capture the behavior
                                                                                    try {
                                                                                        series.addOrUpdate(x, y);
                                                                                        fail("Expected IllegalArgumentException for null 'x' argument.");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Verify the exception message
                                                                                        assertEquals("Null 'x' argument.", e.getMessage());
                                                                                    }
                                                                            
                                                                                    // Step 4: Verify the behavior
                                                                                    // Ensure that the mutant condition (allowDuplicateXValues && x != null) is caught
                                                                                    verify(mockData, never()).add(any(XYDataItem.class));
                                                                                }

    @Test
                                                                            public void testAddOrUpdateCloneNotSupportedException() {
                                                                                // Arrange: Create a mock of XYSeries
                                                                                XYSeries series = mock(XYSeries.class);
                                                                        
                                                                                // Set up the mock to throw CloneNotSupportedException when clone is called
                                                                                try {
                                                                                    when(series.clone()).thenThrow(new CloneNotSupportedException());
                                                                                } catch (CloneNotSupportedException e) {
                                                                                    // This catch is just to satisfy the compiler; it won't be executed.
                                                                                }
                                                                        
                                                                                // Act & Assert: Expect CloneNotSupportedException to be thrown
                                                                                thrown.expect(CloneNotSupportedException.class);
                                                                        
                                                                                // Call addOrUpdate to trigger the exception
                                                                                series.addOrUpdate(new Double(1.0), new Double(2.0));
                                                                            }

    @Test
                                                                    public void testAddOrUpdateWithDifferentException() throws Exception {
                                                                        // Create an instance of XYSeries
                                                                        XYSeries series = new XYSeries("Test Series");
                                                                    
                                                                        // Mock an XYDataItem to throw a RuntimeException when clone is called
                                                                        XYDataItem mockItem = mock(XYDataItem.class);
                                                                        when(mockItem.clone()).thenThrow(new RuntimeException("Test exception"));
                                                                    
                                                                        // Use reflection to access the private 'data' field in the XYSeries class
                                                                        java.lang.reflect.Field dataField = XYSeries.class.getDeclaredField("data");
                                                                        dataField.setAccessible(true);
                                                                    
                                                                        // Add the mock item to the series data
                                                                        @SuppressWarnings("unchecked")
                                                                        java.util.List<XYDataItem> data = (java.util.List<XYDataItem>) dataField.get(series);
                                                                        data.add(mockItem);
                                                                    
                                                                        // Attempt to update the item, which should trigger the clone and throw the exception
                                                                        try {
                                                                            series.addOrUpdate(mockItem.getX(), 10.0);
                                                                            fail("Expected RuntimeException was not thrown");
                                                                        } catch (RuntimeException e) {
                                                                            // Verify that the exception message matches the expected message
                                                                            assertEquals("Test exception", e.getMessage());
                                                                        }
                                                                    }

    @Test
                                                                public void testAddOrUpdateDetectCloneNotSupportedException() throws Exception {
                                                                    // Arrange
                                                                    Comparable key = "TestSeries";
                                                                    XYSeries series = new XYSeries(key, true, false); // autoSort = true, allowDuplicateXValues = false
                                                                    series.setMaximumItemCount(10); // Set maximum item count
                                                            
                                                                    // Use reflection to set the protected 'data' field
                                                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                                                    dataField.setAccessible(true);
                                                                    List mockData = mock(ArrayList.class); // Mock the data list
                                                                    dataField.set(series, mockData);
                                                            
                                                                    // Mock the behavior of the data list
                                                                    XYDataItem mockItem = mock(XYDataItem.class);
                                                                    when(mockData.get(anyInt())).thenReturn(mockItem);
                                                                    when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
                                                            
                                                                    // Act & Assert
                                                                    try {
                                                                        series.addOrUpdate(1.0, 2.0); // Attempt to add/update an item
                                                                        fail("Expected SeriesException due to CloneNotSupportedException");
                                                                    } catch (SeriesException ex) {
                                                                        // Verify the exception message
                                                                        assertEquals("Couldn't clone XYDataItem!", ex.getMessage());
                                                                    }
                                                            
                                                                    // Verify interactions with the mocked data list
                                                                    verify(mockData).get(anyInt());
                                                                    verify(mockItem).clone();
                                                                }

    @Test
                                                public void testAddOrUpdateCloneNotSupportedException1() {
                                                    // Arrange
                                                    XYSeries series = mock(XYSeries.class);
                                                    Number x = 1.0;
                                                    Number y = 2.0;
                                            
                                                    // Simulate RuntimeException when addOrUpdate is called
                                                    doThrow(new RuntimeException("CloneNotSupportedException")).when(series).addOrUpdate(x, y);
                                            
                                                    // Act and Assert
                                                    try {
                                                        series.addOrUpdate(x, y);
                                                        fail("Expected RuntimeException to be thrown");
                                                    } catch (RuntimeException e) {
                                                        // Assert the exception message
                                                        assertEquals("CloneNotSupportedException", e.getMessage());
                                                    }
                                                }

    @Test
                                        public void testAddOrUpdateCloneNotSupportedException2() throws Exception {
                                            // Arrange
                                            Number x = 1.0;
                                            Number y = 2.0;
                                    
                                            // Mock the data list and the XYDataItem
                                            List<XYDataItem> dataList = mock(List.class);
                                            XYDataItem existingItem = mock(XYDataItem.class);
                                    
                                            // Create an instance of XYSeries using reflection to set the private data field
                                            XYSeries series = new XYSeries("Test Series");
                                    
                                            // Use reflection to set the private 'data' field
                                            java.lang.reflect.Field dataField = XYSeries.class.getDeclaredField("data");
                                            dataField.setAccessible(true);
                                            dataField.set(series, dataList);
                                    
                                            // Mock the indexOf method to return a valid index
                                            when(series.indexOf(x)).thenReturn(0);
                                    
                                            // Mock the get method to return the existing item
                                            when(dataList.get(0)).thenReturn(existingItem);
                                    
                                            // Mock the clone method to throw CloneNotSupportedException
                                            when(existingItem.clone()).thenThrow(CloneNotSupportedException.class);
                                    
                                            // Expect a SeriesException to be thrown
                                            thrown.expect(SeriesException.class);
                                            thrown.expectMessage("Couldn't clone XYDataItem!");
                                    
                                            // Act
                                            series.addOrUpdate(x, y);
                                        }

    @Test
                                public void testAddOrUpdateThrowsSeriesException() throws Exception {
                                    // Arrange
                                    XYSeries series = new XYSeries("Test Series");
                                    Number x = 1.0;
                                    Number y = 2.0;
                                
                                    // Mock the behavior of the data list to simulate a cloning issue
                                    List mockedData = mock(List.class);
                                
                                    // Use reflection to set the protected 'data' field in the XYSeries instance
                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                    dataField.setAccessible(true);
                                    dataField.set(series, mockedData);
                                
                                    // Simulate an exception when trying to clone an XYDataItem
                                    doThrow(new SeriesException("Couldn't clone XYDataItem!")).when(mockedData).add(any());
                                
                                    // Act and Assert
                                    try {
                                        series.addOrUpdate(x, y);
                                        fail("Expected SeriesException to be thrown");
                                    } catch (SeriesException e) {
                                        // Assert
                                        assertEquals("Couldn't clone XYDataItem!", e.getMessage());
                                    }
                                }

    @Test
                            public void testAddOrUpdate_CloningExceptionMessage() {
                                try {
                                    // Arrange
                                    // Create an XYSeries instance with autoSort = false and allowDuplicateXValues = false
                                    XYSeries series = new XYSeries("Test Series", false, false);
                        
                                    // Use reflection to access the protected 'data' field
                                    Field dataField = XYSeries.class.getDeclaredField("data");
                                    dataField.setAccessible(true);
                        
                                    // Mock the data list and add a mock XYDataItem to simulate the cloning failure
                                    List<XYDataItem> mockData = new ArrayList<>();
                                    XYDataItem mockItem = mock(XYDataItem.class);
                                    mockData.add(mockItem);
                                    dataField.set(series, mockData);
                        
                                    // Simulate indexOf returning 0 (indicating the item exists in the list)
                                    XYSeries spySeries = spy(series);
                                    when(spySeries.indexOf(any(Number.class))).thenReturn(0);
                        
                                    // Simulate clone throwing CloneNotSupportedException
                                    when(mockItem.clone()).thenThrow(new CloneNotSupportedException());
                        
                                    // Act & Assert
                                    try {
                                        spySeries.addOrUpdate(1.0, 2.0); // Attempt to update the item
                                    } catch (SeriesException e) {
                                        // Verify that the exception message matches the original implementation
                                        assertEquals("Couldn't clone XYDataItem!", e.getMessage());
                                        return; // Test passes if exception message matches
                                    }
                        
                                    // Fail the test if no exception is thrown or the message does not match
                                    fail("Expected SeriesException with message 'Couldn't clone XYDataItem!' was not thrown.");
                                } catch (Exception e) {
                                    // Fail the test if any unexpected exception occurs
                                    fail("Unexpected exception occurred: " + e.getMessage());
                                }
                            }

    @Test
                        public void testAddOrUpdate_CloningFailure() throws CloneNotSupportedException {
                            // Create a series object with a key
                            XYSeries series = new XYSeries("Test Series");
                    
                            // Mock an XYDataItem that will cause a cloning failure
                            XYDataItem mockItem = mock(XYDataItem.class);
                            when(mockItem.clone()).thenThrow(new CloneNotSupportedException("Couldn't clone XYDataItem!"));
                    
                            // Add the mock item to the series to set up the condition
                            series.add(mockItem);
                    
                            // Expect the mutated exception message
                            thrown.expect(SeriesException.class);
                            thrown.expectMessage("Couldn't clone XYDataItem!");
                    
                            // Trigger the addOrUpdate method which should attempt to clone the item
                            series.addOrUpdate(new Double(1.0), new Double(2.0));
                        }

    @Test
                    public void testAddOrUpdate_MaximumItemCountExceeded_RemovesFirstElement() {
                        // Step 1: Setup the test environment
                        // Create an instance of XYSeries with autoSort = true and allowDuplicateXValues = false
                        XYSeries series = new XYSeries("Test Series", true, false);
                        series.setMaximumItemCount(3); // Set the maximum item count to 3
                
                        // Add initial data points to fill the series up to its maximum capacity
                        series.add(1.0, 10.0); // First element
                        series.add(2.0, 20.0); // Second element
                        series.add(3.0, 30.0); // Third element
                
                        // Step 2: Add a new data point to exceed the maximum item count
                        // This should trigger the removal of the first element (1.0, 10.0)
                        series.addOrUpdate(4.0, 40.0);
                
                        // Step 3: Verify the behavior
                        // Check that the first element (1.0, 10.0) was removed
                        assertEquals(3, series.getItemCount()); // Ensure the series still contains 3 items
                        assertEquals(2.0, series.getX(0).doubleValue(), 0.0001); // First element should now be (2.0, 20.0)
                        assertEquals(20.0, series.getY(0).doubleValue(), 0.0001);
                
                        // Check the remaining elements to ensure they are correct
                        assertEquals(3.0, series.getX(1).doubleValue(), 0.0001); // Second element should be (3.0, 30.0)
                        assertEquals(30.0, series.getY(1).doubleValue(), 0.0001);
                        assertEquals(4.0, series.getX(2).doubleValue(), 0.0001); // Third element should be (4.0, 40.0)
                        assertEquals(40.0, series.getY(2).doubleValue(), 0.0001);
                    }

    @Test
                public void testAddOrUpdateDetectsMutation() {
                    // Create an XYSeries instance with a key and set maximum item count to 3
                    XYSeries series = new XYSeries("Series", true, false);
                    series.setMaximumItemCount(3);
            
                    // Add items to fill the series to its maximum capacity
                    series.add(1.0, 1.0);
                    series.add(2.0, 2.0);
                    series.add(3.0, 3.0);
            
                    // At this point, the series is full. Adding another item should remove the first one.
                    series.addOrUpdate(4.0, 4.0);
            
                    // After adding (4.0, 4.0), the first item (1.0, 1.0) should be removed, not the last one.
                    List<XYDataItem> items = series.getItems();
            
                    // Check the size remains the same
                    assertEquals(3, items.size());
            
                    // Check that the first item is now (2.0, 2.0), meaning (1.0, 1.0) was removed
                    assertEquals(2.0, items.get(0).getX().doubleValue(), 0.0001);
                    assertEquals(2.0, items.get(0).getY().doubleValue(), 0.0001);
            
                    // Check that the last item is (4.0, 4.0), the newly added item
                    assertEquals(4.0, items.get(2).getX().doubleValue(), 0.0001);
                    assertEquals(4.0, items.get(2).getY().doubleValue(), 0.0001);
                }

    @Test
        public void testAddOrUpdateDetectsMutation1() {
            // Set up initial data
            XYSeries series = new XYSeries("Test Series"); // Define the series object
            series.add(1.0, 2.0);
            series.add(2.0, 3.0);
            series.add(3.0, 4.0);
    
            // Precondition: data should have 3 items
            assertEquals(3, series.getItemCount());
    
            // Call the method under test
            series.addOrUpdate(4.0, 5.0);
    
            // Check the size of the data list
            // If the mutation is present, the size will be 1 (only the new item)
            // If the mutation is not present, the size will be 3 (first item removed, new item added)
            assertEquals("The mutation was not detected: the list size is incorrect.", 3, series.getItemCount());
    
            // Check the remaining elements to ensure only the first was removed
            assertEquals(2.0, series.getX(0).doubleValue(), 0.001);
            assertEquals(3.0, series.getY(0).doubleValue(), 0.001);
            assertEquals(3.0, series.getX(1).doubleValue(), 0.001);
            assertEquals(4.0, series.getY(1).doubleValue(), 0.001);
            assertEquals(4.0, series.getX(2).doubleValue(), 0.001);
            assertEquals(5.0, series.getY(2).doubleValue(), 0.001);
        }

    @Test
        public void testAddOrUpdateWhenMaximumItemCountExceeded() {
            // Create an instance of XYSeries with a key and set the maximum item count to 3
            XYSeries series = new XYSeries("Test Series");
            series.setMaximumItemCount(3);
    
            // Add items to the series
            series.add(1.0, 1.0);
            series.add(2.0, 2.0);
            series.add(3.0, 3.0);
    
            // At this point, the series is full with 3 items
            assertEquals(3, series.getItemCount());
    
            // Add another item, which should cause the first item to be removed
            series.addOrUpdate(4.0, 4.0);
    
            // Verify that the first item was removed, not all items
            assertEquals(3, series.getItemCount());
            assertEquals(2.0, series.getX(0).doubleValue(), 0.001);
            assertEquals(3.0, series.getX(1).doubleValue(), 0.001);
            assertEquals(4.0, series.getX(2).doubleValue(), 0.001);
        }


}
