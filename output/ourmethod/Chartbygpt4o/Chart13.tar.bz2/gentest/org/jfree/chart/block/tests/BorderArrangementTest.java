package gentest.org.jfree.chart.block.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.block.*;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.Size2D;
import org.jfree.data.Range;
 
public class BorderArrangementTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                            public void testArrangeFF_CenterBlockOnly() {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                                Block centerBlock = mock(Block.class); // Mocking the Block object
                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class); // Mocking Graphics2D object
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                borderArrangement.add(centerBlock, "CENTER");
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                                Size2D centerSize = new Size2D(60, 100);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(centerSize);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                    Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                                    arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                                    Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                                    assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                                    assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                    verify(centerBlock).setBounds(new Rectangle2D.Double(20, 50, 60, 100));
                                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                                    fail("Exception occurred during test execution: " + e.getMessage());
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testArrangeFF_AllBlocksPresent() throws Exception {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Mocking dependencies
                                                                                                                                                                                                                                                Block topBlock = mock(Block.class);
                                                                                                                                                                                                                                                Block bottomBlock = mock(Block.class);
                                                                                                                                                                                                                                                Block leftBlock = mock(Block.class);
                                                                                                                                                                                                                                                Block rightBlock = mock(Block.class);
                                                                                                                                                                                                                                                Block centerBlock = mock(Block.class);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                borderArrangement.add(topBlock, "TOP");
                                                                                                                                                                                                                                                borderArrangement.add(bottomBlock, "BOTTOM");
                                                                                                                                                                                                                                                borderArrangement.add(leftBlock, "LEFT");
                                                                                                                                                                                                                                                borderArrangement.add(rightBlock, "RIGHT");
                                                                                                                                                                                                                                                borderArrangement.add(centerBlock, "CENTER");
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                                Size2D topSize = new Size2D(100, 50);
                                                                                                                                                                                                                                                Size2D bottomSize = new Size2D(100, 50);
                                                                                                                                                                                                                                                Size2D leftSize = new Size2D(20, 100);
                                                                                                                                                                                                                                                Size2D rightSize = new Size2D(20, 100);
                                                                                                                                                                                                                                                Size2D centerSize = new Size2D(60, 100);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(topSize);
                                                                                                                                                                                                                                                when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(bottomSize);
                                                                                                                                                                                                                                                when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(leftSize);
                                                                                                                                                                                                                                                when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(rightSize);
                                                                                                                                                                                                                                                when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(centerSize);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                // Using reflection to invoke the protected method arrangeFF
                                                                                                                                                                                                                                                java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                                assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100, 50));
                                                                                                                                                                                                                                                verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 150, 100, 50));
                                                                                                                                                                                                                                                verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50, 20, 100));
                                                                                                                                                                                                                                                verify(rightBlock).setBounds(new Rectangle2D.Double(80, 50, 20, 100));
                                                                                                                                                                                                                                                verify(centerBlock).setBounds(new Rectangle2D.Double(20, 50, 60, 100));
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testArrangeFF_NoBlocksPresent() throws Exception {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class); // Mock Graphics2D object
                                                                                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Use reflection to access the protected method
                                                                                                                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                                assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testArrangeFF_TopBlockOnly() throws Exception {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                                Block topBlock = mock(Block.class);
                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                borderArrangement.add(topBlock, "TOP");
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                                Size2D topSize = new Size2D(100, 50);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(topSize);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Use reflection to access the protected arrangeFF method
                                                                                                                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                                assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100, 50));
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testArrangeFF_BottomBlockOnly() throws Exception {
                                                                                                                                                                                                                                                // Create a mock Graphics2D object
                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Create a mock Block object
                                                                                                                                                                                                                                                Block bottomBlock = mock(Block.class);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Create a BorderArrangement object
                                                                                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                borderArrangement.add(bottomBlock, "BOTTOM");
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                                Size2D bottomSize = new Size2D(100, 50);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Mock the behavior of bottomBlock.arrange
                                                                                                                                                                                                                                                when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(bottomSize);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Use reflection to access the protected arrangeFF method
                                                                                                                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                                assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Verify that setBounds was called with the correct parameters
                                                                                                                                                                                                                                                verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 150, 100, 50));
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testArrangeFF_RightBlockOnly() throws Exception {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                                Block rightBlock = mock(Block.class);
                                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                borderArrangement.add(rightBlock, "RIGHT");
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                                Size2D rightSize = new Size2D(20, 100);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(rightSize);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Use reflection to access the protected arrangeFF method
                                                                                                                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                                assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                verify(rightBlock).setBounds(new Rectangle2D.Double(80, 50, 20, 100));
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                    public void testArrangeFF_LeftBlockOnly() throws Exception {
                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                        BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                                                                        Block leftBlock = mock(Block.class);
                                                                                                                                                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        borderArrangement.add(leftBlock, "LEFT");
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        RectangleConstraint constraint = new RectangleConstraint(100, 200);
                                                                                                                                                                                                                                        Size2D leftSize = new Size2D(20, 100);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(leftSize);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                        arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                        assertEquals(100, result.width, 0.0001);
                                                                                                                                                                                                                                        assertEquals(200, result.height, 0.0001);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 20.0, 100.0));
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                            public void testArrangeFFDetectMutant() throws Exception {
                                                                                                                                                                                                                                // Create mocks for the blocks
                                                                                                                                                                                                                                Block topBlock = mock(Block.class);
                                                                                                                                                                                                                                Block bottomBlock = mock(Block.class);
                                                                                                                                                                                                                                Block leftBlock = mock(Block.class);
                                                                                                                                                                                                                                Block rightBlock = mock(Block.class);
                                                                                                                                                                                                                                Block centerBlock = mock(Block.class);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Create a mock for Graphics2D
                                                                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Create a mock for RectangleConstraint
                                                                                                                                                                                                                                RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Set up the mock behavior for the blocks
                                                                                                                                                                                                                                when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 20.0));
                                                                                                                                                                                                                                when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 20.0));
                                                                                                                                                                                                                                when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 60.0));
                                                                                                                                                                                                                                when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 60.0));
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Create an instance of BorderArrangement
                                                                                                                                                                                                                                BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Add blocks to the arrangement
                                                                                                                                                                                                                                arrangement.add(topBlock, "TOP");
                                                                                                                                                                                                                                arrangement.add(bottomBlock, "BOTTOM");
                                                                                                                                                                                                                                arrangement.add(leftBlock, "LEFT");
                                                                                                                                                                                                                                arrangement.add(rightBlock, "RIGHT");
                                                                                                                                                                                                                                arrangement.add(centerBlock, "CENTER");
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Create a BlockContainer to pass to the arrangeFF method
                                                                                                                                                                                                                                BlockContainer container = new BlockContainer(arrangement);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Use reflection to call the protected arrangeFF method
                                                                                                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Verify the expected behavior
                                                                                                                                                                                                                                // The right block should have a height of h[2], which is 60.0, not h[1] which is 20.0
                                                                                                                                                                                                                                verify(rightBlock).setBounds(new Rectangle2D.Double(20.0, 20.0, 20.0, 60.0));
                                                                                                                                                                                                                        
                                                                                                                                                                                                                                // Assert the overall size is as expected
                                                                                                                                                                                                                                assertEquals(100.0, result.width, 0.0001);
                                                                                                                                                                                                                                assertEquals(100.0, result.height, 0.0001);
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                    public void testArrangeFFDetectMutant1() throws Exception {
                                                                                                                                                                                                                        // Step 1: Create mock objects for dependencies
                                                                                                                                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                                        RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                                                                                                                                        Block topBlock = mock(Block.class);
                                                                                                                                                                                                                        Block bottomBlock = mock(Block.class);
                                                                                                                                                                                                                        Block leftBlock = mock(Block.class);
                                                                                                                                                                                                                        Block rightBlock = mock(Block.class);
                                                                                                                                                                                                                        Block centerBlock = mock(Block.class);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Step 2: Set up the mock behavior
                                                                                                                                                                                                                        when(constraint.getWidth()).thenReturn(100.0);
                                                                                                                                                                                                                        when(constraint.getHeight()).thenReturn(200.0);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Mock the arrange method for each block to return specific sizes
                                                                                                                                                                                                                        when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 50.0));
                                                                                                                                                                                                                        when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 30.0));
                                                                                                                                                                                                                        when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 120.0));
                                                                                                                                                                                                                        when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(30.0, 120.0));
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Step 3: Create the object under test
                                                                                                                                                                                                                        BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Use reflection to set the private fields
                                                                                                                                                                                                                        Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                                                                                                                                                                        topBlockField.setAccessible(true);
                                                                                                                                                                                                                        topBlockField.set(arrangement, topBlock);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                                                                                                                                                                        bottomBlockField.setAccessible(true);
                                                                                                                                                                                                                        bottomBlockField.set(arrangement, bottomBlock);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                                                                                                                                                                        leftBlockField.setAccessible(true);
                                                                                                                                                                                                                        leftBlockField.set(arrangement, leftBlock);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                                                                                                                                                                        rightBlockField.setAccessible(true);
                                                                                                                                                                                                                        rightBlockField.set(arrangement, rightBlock);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                                                                                                                                                                        centerBlockField.setAccessible(true);
                                                                                                                                                                                                                        centerBlockField.set(arrangement, centerBlock);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Step 4: Call the method under test using reflection
                                                                                                                                                                                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                                        arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Step 5: Verify the expected behavior
                                                                                                                                                                                                                        double expectedH2 = 200.0 - 30.0 - 50.0; // 120.0
                                                                                                                                                                                                                        double expectedH3 = expectedH2; // h[3] should equal h[2]
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Verify that the blocks are set with the correct bounds
                                                                                                                                                                                                                        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
                                                                                                                                                                                                                        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
                                                                                                                                                                                                                        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 20.0, 120.0));
                                                                                                                                                                                                                        verify(rightBlock).setBounds(new Rectangle2D.Double(50.0, 50.0, 30.0, 120.0));
                                                                                                                                                                                                                        verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 50.0, 50.0, 120.0));
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Assert the overall size returned
                                                                                                                                                                                                                        assertEquals(100.0, result.getWidth(), 0.001);
                                                                                                                                                                                                                        assertEquals(200.0, result.getHeight(), 0.001);
                                                                                                                                                                                                                
                                                                                                                                                                                                                        // Additional verification to ensure the mutant is caught
                                                                                                                                                                                                                        verify(rightBlock).setBounds(new Rectangle2D.Double(50.0, 50.0, 30.0, expectedH3));
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                        public void testArrangeFFDetectMutant2() throws Exception {
                                                                                                                                                                                                            // Step 1: Create mock objects for dependencies
                                                                                                                                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                            Block topBlock = mock(Block.class);
                                                                                                                                                                                                            Block bottomBlock = mock(Block.class);
                                                                                                                                                                                                            Block leftBlock = mock(Block.class);
                                                                                                                                                                                                            Block rightBlock = mock(Block.class);
                                                                                                                                                                                                            Block centerBlock = mock(Block.class);
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Step 2: Create a RectangleConstraint and mock behavior for arrange calls
                                                                                                                                                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                                                                                                                                                            when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 50.0));
                                                                                                                                                                                                            when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 30.0));
                                                                                                                                                                                                            when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 120.0));
                                                                                                                                                                                                            when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 120.0));
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Step 3: Create an instance of BorderArrangement
                                                                                                                                                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Use reflection to set private fields
                                                                                                                                                                                                            java.lang.reflect.Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                                                                                                                                                            topBlockField.setAccessible(true);
                                                                                                                                                                                                            topBlockField.set(arrangement, topBlock);
                                                                                                                                                                                                        
                                                                                                                                                                                                            java.lang.reflect.Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                                                                                                                                                            bottomBlockField.setAccessible(true);
                                                                                                                                                                                                            bottomBlockField.set(arrangement, bottomBlock);
                                                                                                                                                                                                        
                                                                                                                                                                                                            java.lang.reflect.Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                                                                                                                                                            leftBlockField.setAccessible(true);
                                                                                                                                                                                                            leftBlockField.set(arrangement, leftBlock);
                                                                                                                                                                                                        
                                                                                                                                                                                                            java.lang.reflect.Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                                                                                                                                                            rightBlockField.setAccessible(true);
                                                                                                                                                                                                            rightBlockField.set(arrangement, rightBlock);
                                                                                                                                                                                                        
                                                                                                                                                                                                            java.lang.reflect.Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                                                                                                                                                            centerBlockField.setAccessible(true);
                                                                                                                                                                                                            centerBlockField.set(arrangement, centerBlock);
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Step 4: Call the arrangeFF method using reflection
                                                                                                                                                                                                            java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                            arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Step 5: Verify the expected behavior of h[3]
                                                                                                                                                                                                            // h[2] = constraint.getHeight() - h[1] - h[0] = 200.0 - 30.0 - 50.0 = 120.0
                                                                                                                                                                                                            // h[3] should be equal to h[2], but the mutant sets it to constraint.getHeight() (200.0)
                                                                                                                                                                                                            double expectedH3 = 120.0; // Original behavior
                                                                                                                                                                                                            double mutatedH3 = 200.0; // Mutated behavior
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Use reflection to access the private array h
                                                                                                                                                                                                            java.lang.reflect.Field hField = BorderArrangement.class.getDeclaredField("h");
                                                                                                                                                                                                            hField.setAccessible(true);
                                                                                                                                                                                                            double[] h = (double[]) hField.get(arrangement);
                                                                                                                                                                                                        
                                                                                                                                                                                                            // Verify that the mutant is detected
                                                                                                                                                                                                            assertEquals("The mutant should be detected by checking h[3].", expectedH3, h[3], 0.0001);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                    public void testArrangeFF_DetectMutant() throws Exception {
                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                        BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                                                
                                                                                                                                                                                                        // Mock dependencies
                                                                                                                                                                                                        Block topBlock = mock(Block.class);
                                                                                                                                                                                                        Block bottomBlock = mock(Block.class);
                                                                                                                                                                                                        Block leftBlock = mock(Block.class);
                                                                                                                                                                                                        Block rightBlock = mock(Block.class);
                                                                                                                                                                                                        Block centerBlock = mock(Block.class);
                                                                                                                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                                        RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Set up mock behavior
                                                                                                                                                                                                        when(constraint.getWidth()).thenReturn(100.0);
                                                                                                                                                                                                        when(constraint.getHeight()).thenReturn(200.0);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Mock topBlock behavior
                                                                                                                                                                                                        RectangleConstraint topConstraint = new RectangleConstraint(100.0, null, LengthConstraintType.FIXED, 0.0, new Range(0.0, 200.0), LengthConstraintType.RANGE);
                                                                                                                                                                                                        Size2D topSize = new Size2D(100.0, 50.0);
                                                                                                                                                                                                        when(topBlock.arrange(eq(g2), eq(topConstraint))).thenReturn(topSize);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Mock bottomBlock behavior
                                                                                                                                                                                                        RectangleConstraint bottomConstraint = new RectangleConstraint(100.0, null, LengthConstraintType.FIXED, 0.0, new Range(0.0, 150.0), LengthConstraintType.RANGE);
                                                                                                                                                                                                        Size2D bottomSize = new Size2D(100.0, 30.0);
                                                                                                                                                                                                        when(bottomBlock.arrange(eq(g2), eq(bottomConstraint))).thenReturn(bottomSize);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Mock leftBlock behavior
                                                                                                                                                                                                        RectangleConstraint leftConstraint = new RectangleConstraint(0.0, new Range(0.0, 100.0), LengthConstraintType.RANGE, 120.0, null, LengthConstraintType.FIXED);
                                                                                                                                                                                                        Size2D leftSize = new Size2D(20.0, 120.0);
                                                                                                                                                                                                        when(leftBlock.arrange(eq(g2), eq(leftConstraint))).thenReturn(leftSize);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Mock rightBlock behavior
                                                                                                                                                                                                        RectangleConstraint rightConstraint = new RectangleConstraint(0.0, new Range(0.0, 80.0), LengthConstraintType.RANGE, 120.0, null, LengthConstraintType.FIXED);
                                                                                                                                                                                                        Size2D rightSize = new Size2D(30.0, 120.0);
                                                                                                                                                                                                        when(rightBlock.arrange(eq(g2), eq(rightConstraint))).thenReturn(rightSize);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Use reflection to set private fields in BorderArrangement
                                                                                                                                                                                                        Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                                                                                                                                                        topBlockField.setAccessible(true);
                                                                                                                                                                                                        topBlockField.set(arrangement, topBlock);
                                                                                                                                                                                                
                                                                                                                                                                                                        Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                                                                                                                                                        bottomBlockField.setAccessible(true);
                                                                                                                                                                                                        bottomBlockField.set(arrangement, bottomBlock);
                                                                                                                                                                                                
                                                                                                                                                                                                        Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                                                                                                                                                        leftBlockField.setAccessible(true);
                                                                                                                                                                                                        leftBlockField.set(arrangement, leftBlock);
                                                                                                                                                                                                
                                                                                                                                                                                                        Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                                                                                                                                                        rightBlockField.setAccessible(true);
                                                                                                                                                                                                        rightBlockField.set(arrangement, rightBlock);
                                                                                                                                                                                                
                                                                                                                                                                                                        Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                                                                                                                                                        centerBlockField.setAccessible(true);
                                                                                                                                                                                                        centerBlockField.set(arrangement, centerBlock);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Use reflection to call the protected arrangeFF method
                                                                                                                                                                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                                        arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                        assertEquals(100.0, result.width, 0.0001);
                                                                                                                                                                                                        assertEquals(200.0, result.height, 0.0001);
                                                                                                                                                                                                
                                                                                                                                                                                                        // Verify bounds for each block
                                                                                                                                                                                                        verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
                                                                                                                                                                                                        verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
                                                                                                                                                                                                        verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 20.0, 120.0));
                                                                                                                                                                                                        verify(rightBlock).setBounds(new Rectangle2D.Double(20.0 + 50.0, 50.0, 30.0, 120.0));
                                                                                                                                                                                                        verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 50.0, 50.0, 120.0));
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testArrangeFFDetectsMutant() throws Exception {
                                                                                                                                                                                        // Set up the constraint with specific width and height
                                                                                                                                                                                        double width = 100.0;
                                                                                                                                                                                        double height = 100.0;
                                                                                                                                                                                        RectangleConstraint constraint = new RectangleConstraint(width, height);
                                                                                                                                                                                    
                                                                                                                                                                                        // Create mocks for the blocks and Graphics2D
                                                                                                                                                                                        Block topBlock = mock(Block.class);
                                                                                                                                                                                        Block bottomBlock = mock(Block.class);
                                                                                                                                                                                        Block leftBlock = mock(Block.class);
                                                                                                                                                                                        Block rightBlock = mock(Block.class);
                                                                                                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                                    
                                                                                                                                                                                        // Create an instance of BorderArrangement
                                                                                                                                                                                        BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                                    
                                                                                                                                                                                        // Use reflection to set private/protected fields if necessary
                                                                                                                                                                                        Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                                                                                                                                        topBlockField.setAccessible(true);
                                                                                                                                                                                        topBlockField.set(arrangement, topBlock);
                                                                                                                                                                                    
                                                                                                                                                                                        Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                                                                                                                                        bottomBlockField.setAccessible(true);
                                                                                                                                                                                        bottomBlockField.set(arrangement, bottomBlock);
                                                                                                                                                                                    
                                                                                                                                                                                        Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                                                                                                                                        leftBlockField.setAccessible(true);
                                                                                                                                                                                        leftBlockField.set(arrangement, leftBlock);
                                                                                                                                                                                    
                                                                                                                                                                                        Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                                                                                                                                        rightBlockField.setAccessible(true);
                                                                                                                                                                                        rightBlockField.set(arrangement, rightBlock);
                                                                                                                                                                                    
                                                                                                                                                                                        // Mock the behavior of the blocks
                                                                                                                                                                                        when(topBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                                .thenReturn(new Size2D(100.0, 20.0));
                                                                                                                                                                                        when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                                .thenReturn(new Size2D(100.0, 20.0));
                                                                                                                                                                                        when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                                .thenReturn(new Size2D(20.0, 60.0));
                                                                                                                                                                                        when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                                .thenReturn(new Size2D(20.0, 60.0));
                                                                                                                                                                                    
                                                                                                                                                                                        // Call the method under test using reflection to access the protected method
                                                                                                                                                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                        arrangeFFMethod.setAccessible(true);
                                                                                                                                                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                                                                                    
                                                                                                                                                                                        // Verify that the rightBlock was arranged with the correct constraint
                                                                                                                                                                                        verify(rightBlock).arrange(eq(g2), argThat(c -> {
                                                                                                                                                                                            Range widthRange = c.getWidthRange();
                                                                                                                                                                                            return widthRange.getUpperBound() == 80.0;
                                                                                                                                                                                        }));
                                                                                                                                                                                    
                                                                                                                                                                                        // Assert the final size is as expected
                                                                                                                                                                                        assertEquals(width, result.getWidth(), 0.0001);
                                                                                                                                                                                        assertEquals(height, result.getHeight(), 0.0001);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                            public void testArrangeFFDetectMutant3() throws Exception {
                                                                                                                                                                                // Step 1: Mock dependencies
                                                                                                                                                                                Block topBlock = mock(Block.class);
                                                                                                                                                                                Block bottomBlock = mock(Block.class);
                                                                                                                                                                                Block leftBlock = mock(Block.class);
                                                                                                                                                                                Block rightBlock = mock(Block.class);
                                                                                                                                                                                Block centerBlock = mock(Block.class);
                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                            
                                                                                                                                                                                // Step 2: Create the BorderArrangement object and set blocks
                                                                                                                                                                                BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                                                borderArrangement.add(topBlock, "top");
                                                                                                                                                                                borderArrangement.add(bottomBlock, "bottom");
                                                                                                                                                                                borderArrangement.add(leftBlock, "left");
                                                                                                                                                                                borderArrangement.add(rightBlock, "right");
                                                                                                                                                                                borderArrangement.add(centerBlock, "center");
                                                                                                                                                                            
                                                                                                                                                                                // Step 3: Define the constraint
                                                                                                                                                                                double width = 100.0;
                                                                                                                                                                                double height = 200.0;
                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(width, height);
                                                                                                                                                                            
                                                                                                                                                                                // Step 4: Mock the behavior of arrange method in blocks
                                                                                                                                                                                when(topBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                        .thenReturn(new Size2D(width, 50.0));
                                                                                                                                                                                when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                        .thenReturn(new Size2D(width, 30.0));
                                                                                                                                                                                when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                        .thenReturn(new Size2D(20.0, height - 80.0));
                                                                                                                                                                                when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                        .thenReturn(new Size2D(15.0, height - 80.0));
                                                                                                                                                                            
                                                                                                                                                                                // Step 5: Call the arrangeFF method using reflection
                                                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                                                                                                                                            
                                                                                                                                                                                // Step 6: Verify the result
                                                                                                                                                                                assertEquals("Width should match the constraint width", width, result.width, 0.001);
                                                                                                                                                                                assertEquals("Height should match the constraint height", height, result.height, 0.001);
                                                                                                                                                                            
                                                                                                                                                                                // Step 7: Verify the behavior of the mutated code
                                                                                                                                                                                // The mutant changes Math.max to Math.min in the calculation of the range for the rightBlock
                                                                                                                                                                                double expectedRightBlockWidthRange = Math.max(width - 20.0, 0.0); // Original behavior
                                                                                                                                                                                double mutatedRightBlockWidthRange = Math.min(width - 20.0, 0.0); // Mutated behavior
                                                                                                                                                                            
                                                                                                                                                                                // Assert that the original behavior is correct
                                                                                                                                                                                assertTrue("Right block width range should be calculated using Math.max",
                                                                                                                                                                                        expectedRightBlockWidthRange >= 0.0);
                                                                                                                                                                            
                                                                                                                                                                                // Assert that the mutated behavior is incorrect
                                                                                                                                                                                assertFalse("Mutated behavior should result in an incorrect width range",
                                                                                                                                                                                        mutatedRightBlockWidthRange >= 0.0);
                                                                                                                                                                            
                                                                                                                                                                                // Step 8: Verify the bounds of blocks
                                                                                                                                                                                verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, width, 50.0));
                                                                                                                                                                                verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 80.0, width, 30.0));
                                                                                                                                                                                verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 20.0, 120.0));
                                                                                                                                                                                verify(rightBlock).setBounds(new Rectangle2D.Double(20.0 + (width - 35.0), 50.0, 15.0, 120.0));
                                                                                                                                                                                verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 50.0, width - 35.0, 120.0));
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testArrangeFFDetectsMutant1() {
                                                                                                                                                                                // Arrange
                                                                                                                                                                                BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                                Block leftBlock = mock(Block.class);
                                                                                                                                                                                BlockContainer container = mock(BlockContainer.class);
                                                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                        
                                                                                                                                                                                // Set up the constraints and expected size
                                                                                                                                                                                RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                                                                                                                                Size2D expectedSize = new Size2D(50.0, 150.0); // Expected size if RANGE is used
                                                                                                                                                                        
                                                                                                                                                                                // Mock the behavior of leftBlock to return a specific size
                                                                                                                                                                                when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                                    .thenReturn(new Size2D(50.0, 150.0));
                                                                                                                                                                        
                                                                                                                                                                                // Add the leftBlock to the arrangement
                                                                                                                                                                                arrangement.add(leftBlock, "LEFT");
                                                                                                                                                                        
                                                                                                                                                                                // Act
                                                                                                                                                                                arrangement.arrange(container, g2, constraint);
                                                                                                                                                                        
                                                                                                                                                                                // Assert
                                                                                                                                                                                // Verify that the leftBlock was arranged with a RANGE constraint, not FIXED
                                                                                                                                                                                verify(leftBlock).arrange(eq(g2), argThat(arg ->
                                                                                                                                                                                    arg.getHeightConstraintType() == LengthConstraintType.RANGE &&
                                                                                                                                                                                    arg.getHeightRange().getUpperBound() == 200.0
                                                                                                                                                                                ));
                                                                                                                                                                        
                                                                                                                                                                                // Verify that the bounds are set correctly
                                                                                                                                                                                verify(leftBlock).setBounds(argThat(rect ->
                                                                                                                                                                                    rect.getHeight() == 150.0 // Ensure it respects the flexible height
                                                                                                                                                                                ));
                                                                                                                                                                            }

    @Test
                                                                                                                                                                public void testArrangeFF_detectMutant() throws Exception {
                                                                                                                                                                    // Create mock objects for dependencies
                                                                                                                                                                    Block topBlock = mock(Block.class);
                                                                                                                                                                    Block bottomBlock = mock(Block.class);
                                                                                                                                                                    Block leftBlock = mock(Block.class);
                                                                                                                                                                    Block rightBlock = mock(Block.class);
                                                                                                                                                                    Block centerBlock = mock(Block.class);
                                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                                
                                                                                                                                                                    // Define the constraint
                                                                                                                                                                    double width = 100.0;
                                                                                                                                                                    double height = 100.0;
                                                                                                                                                                    RectangleConstraint constraint = new RectangleConstraint(width, height);
                                                                                                                                                                
                                                                                                                                                                    // Mock the arrange method for each block
                                                                                                                                                                    when(topBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                        .thenReturn(new Size2D(width, 20.0));
                                                                                                                                                                    when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                        .thenReturn(new Size2D(width, 30.0));
                                                                                                                                                                    when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                        .thenReturn(new Size2D(10.0, height - 50.0)); // height - h[0] - h[1]
                                                                                                                                                                    when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                        .thenReturn(new Size2D(10.0, height - 50.0)); // height - h[0] - h[1]
                                                                                                                                                                    when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                                                        .thenReturn(new Size2D(80.0, height - 50.0)); // width - w[2] - w[3]
                                                                                                                                                                
                                                                                                                                                                    // Instantiate the BorderArrangement and set blocks
                                                                                                                                                                    BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                                    arrangement.add(topBlock, "TOP");
                                                                                                                                                                    arrangement.add(bottomBlock, "BOTTOM");
                                                                                                                                                                    arrangement.add(leftBlock, "LEFT");
                                                                                                                                                                    arrangement.add(rightBlock, "RIGHT");
                                                                                                                                                                    arrangement.add(centerBlock, "CENTER");
                                                                                                                                                                
                                                                                                                                                                    // Use reflection to access the protected arrangeFF method
                                                                                                                                                                    java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                                                                                                        "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class
                                                                                                                                                                    );
                                                                                                                                                                    arrangeFFMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                    // Create a BlockContainer mock to pass as the first argument
                                                                                                                                                                    BlockContainer container = mock(BlockContainer.class);
                                                                                                                                                                
                                                                                                                                                                    // Call the method under test using reflection
                                                                                                                                                                    Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
                                                                                                                                                                
                                                                                                                                                                    // Verify the expected behavior
                                                                                                                                                                    verify(rightBlock).arrange(eq(g2), argThat(c -> {
                                                                                                                                                                        // Check that the height constraint is h[2] (original) and not h[3] (mutant)
                                                                                                                                                                        return c.getHeightRange().getLowerBound() == height - 50.0;
                                                                                                                                                                    }));
                                                                                                                                                                
                                                                                                                                                                    // Assert the final size returned
                                                                                                                                                                    assertEquals(width, result.width, 0.0001);
                                                                                                                                                                    assertEquals(height, result.height, 0.0001);
                                                                                                                                                                }

    @Test
                                                                                                                                                        public void testArrangeFFDetectMutant4() throws Exception {
                                                                                                                                                            // Step 1: Set up the mock objects
                                                                                                                                                            Block mockTopBlock = mock(Block.class);
                                                                                                                                                            Block mockBottomBlock = mock(Block.class);
                                                                                                                                                            Block mockLeftBlock = mock(Block.class);
                                                                                                                                                            Block mockRightBlock = mock(Block.class);
                                                                                                                                                            Block mockCenterBlock = mock(Block.class);
                                                                                                                                                            Graphics2D mockGraphics2D = mock(Graphics2D.class);
                                                                                                                                                        
                                                                                                                                                            // Step 2: Create the BorderArrangement instance and set the blocks
                                                                                                                                                            BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                                                            borderArrangement.add(mockTopBlock, "top");
                                                                                                                                                            borderArrangement.add(mockBottomBlock, "bottom");
                                                                                                                                                            borderArrangement.add(mockLeftBlock, "left");
                                                                                                                                                            borderArrangement.add(mockRightBlock, "right");
                                                                                                                                                            borderArrangement.add(mockCenterBlock, "center");
                                                                                                                                                        
                                                                                                                                                            // Step 3: Define the RectangleConstraint
                                                                                                                                                            double width = 100.0;
                                                                                                                                                            double height = 200.0;
                                                                                                                                                            RectangleConstraint constraint = new RectangleConstraint(width, height);
                                                                                                                                                        
                                                                                                                                                            // Step 4: Mock the behavior of the arrange method for each block
                                                                                                                                                            when(mockTopBlock.arrange(eq(mockGraphics2D), any(RectangleConstraint.class)))
                                                                                                                                                                    .thenReturn(new Size2D(100.0, 50.0));
                                                                                                                                                            when(mockBottomBlock.arrange(eq(mockGraphics2D), any(RectangleConstraint.class)))
                                                                                                                                                                    .thenReturn(new Size2D(100.0, 30.0));
                                                                                                                                                            when(mockLeftBlock.arrange(eq(mockGraphics2D), any(RectangleConstraint.class)))
                                                                                                                                                                    .thenReturn(new Size2D(20.0, 120.0));
                                                                                                                                                            when(mockRightBlock.arrange(eq(mockGraphics2D), any(RectangleConstraint.class)))
                                                                                                                                                                    .thenReturn(new Size2D(30.0, 120.0));
                                                                                                                                                            when(mockCenterBlock.arrange(eq(mockGraphics2D), any(RectangleConstraint.class)))
                                                                                                                                                                    .thenReturn(new Size2D(50.0, 120.0));
                                                                                                                                                        
                                                                                                                                                            // Step 5: Call the arrangeFF method using reflection
                                                                                                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                            arrangeFFMethod.setAccessible(true);
                                                                                                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, mockGraphics2D, constraint);
                                                                                                                                                        
                                                                                                                                                            // Step 6: Verify the expected behavior
                                                                                                                                                            assertEquals("Width of the arranged size should match the constraint width", width, result.width, 0.001);
                                                                                                                                                            assertEquals("Height of the arranged size should match the constraint height", height, result.height, 0.001);
                                                                                                                                                        
                                                                                                                                                            // Verify that the blocks were arranged with the correct constraints
                                                                                                                                                            verify(mockTopBlock).arrange(eq(mockGraphics2D), argThat(c -> c.getWidth() == 100.0 && c.getHeightRange().getUpperBound() == height));
                                                                                                                                                            verify(mockBottomBlock).arrange(eq(mockGraphics2D), argThat(c -> c.getWidth() == 100.0 && c.getHeightRange().getUpperBound() == (height - 50.0)));
                                                                                                                                                            verify(mockLeftBlock).arrange(eq(mockGraphics2D), argThat(c -> c.getHeight() == 120.0 && c.getWidthRange().getUpperBound() == width));
                                                                                                                                                            verify(mockRightBlock).arrange(eq(mockGraphics2D), argThat(c -> c.getHeight() == 120.0 && c.getWidthRange().getUpperBound() == (width - 20.0)));
                                                                                                                                                            verify(mockCenterBlock).arrange(eq(mockGraphics2D), argThat(c -> c.getWidth() == 50.0 && c.getHeight() == 120.0));
                                                                                                                                                        
                                                                                                                                                            // Step 7: Verify the bounds of each block
                                                                                                                                                            verify(mockTopBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
                                                                                                                                                            verify(mockBottomBlock).setBounds(new Rectangle2D.Double(0.0, 170.0, 100.0, 30.0));
                                                                                                                                                            verify(mockLeftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 20.0, 120.0));
                                                                                                                                                            verify(mockRightBlock).setBounds(new Rectangle2D.Double(70.0, 50.0, 30.0, 120.0));
                                                                                                                                                            verify(mockCenterBlock).setBounds(new Rectangle2D.Double(20.0, 50.0, 50.0, 120.0));
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testArrangeFFDetectMutant5() throws Exception {
                                                                                                                                                    // Arrange
                                                                                                                                                    BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                                    Block topBlock = mock(Block.class);
                                                                                                                                                    Block bottomBlock = mock(Block.class);
                                                                                                                                                    Block leftBlock = mock(Block.class);
                                                                                                                                                    Block rightBlock = mock(Block.class);
                                                                                                                                                    Block centerBlock = mock(Block.class);
                                                                                                                                                
                                                                                                                                                    arrangement.add(topBlock, "TOP");
                                                                                                                                                    arrangement.add(bottomBlock, "BOTTOM");
                                                                                                                                                    arrangement.add(leftBlock, "LEFT");
                                                                                                                                                    arrangement.add(rightBlock, "RIGHT");
                                                                                                                                                    arrangement.add(centerBlock, "CENTER");
                                                                                                                                                
                                                                                                                                                    double width = 100.0;
                                                                                                                                                    double height = 100.0;
                                                                                                                                                    RectangleConstraint constraint = new RectangleConstraint(width, height);
                                                                                                                                                
                                                                                                                                                    // Mocking the arrange method to return specific sizes
                                                                                                                                                    when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 20.0));
                                                                                                                                                    when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 20.0));
                                                                                                                                                    when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 60.0));
                                                                                                                                                    when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20.0, 60.0));
                                                                                                                                                    when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(60.0, 60.0));
                                                                                                                                                
                                                                                                                                                    // Act
                                                                                                                                                    Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                    arrangeFFMethod.setAccessible(true);
                                                                                                                                                    Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                                                
                                                                                                                                                    // Assert
                                                                                                                                                    assertEquals("Width should match constraint width", width, result.width, 0.001);
                                                                                                                                                    assertEquals("Height should match constraint height", height, result.height, 0.001);
                                                                                                                                                
                                                                                                                                                    // Verify that the blocks are arranged with the correct constraints
                                                                                                                                                    verify(topBlock).arrange(eq(g2), argThat(c -> c.getHeightRange().getUpperBound() == height));
                                                                                                                                                    verify(bottomBlock).arrange(eq(g2), argThat(c -> c.getHeightRange().getUpperBound() == height - 20.0));
                                                                                                                                                    verify(leftBlock).arrange(eq(g2), argThat(c -> c.getWidthRange().getUpperBound() == width));
                                                                                                                                                    verify(rightBlock).arrange(eq(g2), argThat(c -> c.getWidthRange().getUpperBound() == width - 20.0));
                                                                                                                                                    verify(centerBlock).arrange(eq(g2), argThat(c -> c.getWidth() == 60.0 && c.getHeight() == 60.0));
                                                                                                                                                
                                                                                                                                                    // Check bounds setting
                                                                                                                                                    verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
                                                                                                                                                    verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 80.0, 100.0, 20.0));
                                                                                                                                                    verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 20.0, 60.0));
                                                                                                                                                    verify(rightBlock).setBounds(new Rectangle2D.Double(80.0, 20.0, 20.0, 60.0));
                                                                                                                                                    verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 20.0, 60.0, 60.0));
                                                                                                                                                }

    @Test
                                                                                                                                            public void testArrangeFFDetectMutant6() throws Exception {
                                                                                                                                                // Arrange
                                                                                                                                                BorderArrangement arrangement = new BorderArrangement();
                                                                                                                                        
                                                                                                                                                // Mocking blocks
                                                                                                                                                Block topBlock = mock(Block.class);
                                                                                                                                                Block bottomBlock = mock(Block.class);
                                                                                                                                                Block leftBlock = mock(Block.class);
                                                                                                                                                Block rightBlock = mock(Block.class);
                                                                                                                                                Block centerBlock = mock(Block.class);
                                                                                                                                        
                                                                                                                                                // Setting blocks in the arrangement
                                                                                                                                                arrangement.add(topBlock, "TOP");
                                                                                                                                                arrangement.add(bottomBlock, "BOTTOM");
                                                                                                                                                arrangement.add(leftBlock, "LEFT");
                                                                                                                                                arrangement.add(rightBlock, "RIGHT");
                                                                                                                                                arrangement.add(centerBlock, "CENTER");
                                                                                                                                        
                                                                                                                                                // Mocking Graphics2D
                                                                                                                                                Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                                        
                                                                                                                                                // Mocking RectangleConstraint
                                                                                                                                                RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                                                                when(constraint.getWidth()).thenReturn(100.0);
                                                                                                                                                when(constraint.getHeight()).thenReturn(100.0);
                                                                                                                                        
                                                                                                                                                // Mocking Size2D for blocks
                                                                                                                                                Size2D topSize = new Size2D(100.0, 20.0);
                                                                                                                                                Size2D bottomSize = new Size2D(100.0, 20.0);
                                                                                                                                                Size2D leftSize = new Size2D(20.0, 60.0);
                                                                                                                                                Size2D rightSize = new Size2D(20.0, 60.0);
                                                                                                                                        
                                                                                                                                                when(topBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(topSize);
                                                                                                                                                when(bottomBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(bottomSize);
                                                                                                                                                when(leftBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(leftSize);
                                                                                                                                                when(rightBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(rightSize);
                                                                                                                                        
                                                                                                                                                // Act
                                                                                                                                                Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                                                arrangeFFMethod.setAccessible(true);
                                                                                                                                                Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                                        
                                                                                                                                                // Assert
                                                                                                                                                // Check that the rightBlock's width is arranged correctly
                                                                                                                                                double expectedRightBlockWidth = Math.max(constraint.getWidth() - leftSize.width, 0.0);
                                                                                                                                                verify(rightBlock).arrange(eq(g2), argThat(c -> c.getWidthRange().getUpperBound() == expectedRightBlockWidth));
                                                                                                                                        
                                                                                                                                                // Verify the final size returned is as expected
                                                                                                                                                assertEquals(100.0, result.width, 0.001);
                                                                                                                                                assertEquals(100.0, result.height, 0.001);
                                                                                                                                            }

    @Test
                                                                                                                        public void testArrangeFFDetectMutant7() throws Exception {
                                                                                                                            // Mock dependencies
                                                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                            RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                                            Block topBlock = mock(Block.class);
                                                                                                                            Block bottomBlock = mock(Block.class);
                                                                                                                            Block leftBlock = mock(Block.class);
                                                                                                                            Block rightBlock = mock(Block.class);
                                                                                                                            Block centerBlock = mock(Block.class);
                                                                                                                        
                                                                                                                            // Create an instance of BorderArrangement
                                                                                                                            BorderArrangement borderArrangement = new BorderArrangement();
                                                                                                                        
                                                                                                                            // Add blocks to the arrangement
                                                                                                                            BlockContainer container = mock(BlockContainer.class);
                                                                                                                            when(container.getBlocks()).thenReturn(java.util.Arrays.asList(topBlock, bottomBlock, leftBlock, rightBlock, centerBlock));
                                                                                                                        
                                                                                                                            // Mock the arrange method for each block to return specific sizes
                                                                                                                            when(topBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                .thenReturn(new Size2D(100.0, 20.0));
                                                                                                                            when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                .thenReturn(new Size2D(100.0, 30.0));
                                                                                                                            when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                .thenReturn(new Size2D(20.0, 50.0));
                                                                                                                            when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                .thenReturn(new Size2D(30.0, 50.0));
                                                                                                                            when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                                .thenReturn(new Size2D(50.0, 50.0));
                                                                                                                        
                                                                                                                            // Use reflection to access the protected arrangeFF method
                                                                                                                            java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                            arrangeFFMethod.setAccessible(true);
                                                                                                                        
                                                                                                                            // Call the method under test using reflection
                                                                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(borderArrangement, container, g2, constraint);
                                                                                                                        
                                                                                                                            // Verify the expected behavior
                                                                                                                            verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 20.0));
                                                                                                                            verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 70.0, 100.0, 30.0));
                                                                                                                            verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 20.0, 50.0));
                                                                                                                            verify(rightBlock).setBounds(new Rectangle2D.Double(20.0, 20.0, 30.0, 50.0));
                                                                                                                            verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 20.0, 50.0, 50.0));
                                                                                                                        
                                                                                                                            // Assert the result size
                                                                                                                            assertEquals(100.0, result.width, 0.001);
                                                                                                                            assertEquals(100.0, result.height, 0.001);
                                                                                                                        
                                                                                                                            // Additional checks to ensure the mutant is detected
                                                                                                                            double expectedH3 = 50.0; // h[2] should be 50.0 based on the calculation
                                                                                                                            double actualH3 = 20.0; // h[0] is 20.0, which is incorrect if the mutant is present
                                                                                                                        
                                                                                                                            assertNotEquals(expectedH3, actualH3); // This assertion should fail if the mutant is present
                                                                                                                        }

    @Test
                                                                                                                public void testArrangeFFDetectMutant8() throws Exception {
                                                                                                                    // Mock dependencies
                                                                                                                    Block topBlock = mock(Block.class);
                                                                                                                    Block bottomBlock = mock(Block.class);
                                                                                                                    Block leftBlock = mock(Block.class);
                                                                                                                    Block rightBlock = mock(Block.class);
                                                                                                                    Block centerBlock = mock(Block.class);
                                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                                
                                                                                                                    // Create the BorderArrangement instance
                                                                                                                    BorderArrangement arrangement = new BorderArrangement();
                                                                                                                
                                                                                                                    // Use reflection to set private fields
                                                                                                                    java.lang.reflect.Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                                                                    topBlockField.setAccessible(true);
                                                                                                                    topBlockField.set(arrangement, topBlock);
                                                                                                                
                                                                                                                    java.lang.reflect.Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                                                                    bottomBlockField.setAccessible(true);
                                                                                                                    bottomBlockField.set(arrangement, bottomBlock);
                                                                                                                
                                                                                                                    java.lang.reflect.Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                                                                    leftBlockField.setAccessible(true);
                                                                                                                    leftBlockField.set(arrangement, leftBlock);
                                                                                                                
                                                                                                                    java.lang.reflect.Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                                                                    rightBlockField.setAccessible(true);
                                                                                                                    rightBlockField.set(arrangement, rightBlock);
                                                                                                                
                                                                                                                    java.lang.reflect.Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                                                                    centerBlockField.setAccessible(true);
                                                                                                                    centerBlockField.set(arrangement, centerBlock);
                                                                                                                
                                                                                                                    // Mock RectangleConstraint and Size2D behavior
                                                                                                                    RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                                    when(constraint.getWidth()).thenReturn(100.0);
                                                                                                                    when(constraint.getHeight()).thenReturn(200.0);
                                                                                                                
                                                                                                                    Size2D topSize = new Size2D(100.0, 50.0);
                                                                                                                    Size2D bottomSize = new Size2D(100.0, 70.0);
                                                                                                                    Size2D leftSize = new Size2D(30.0, 80.0);
                                                                                                                    Size2D rightSize = new Size2D(40.0, 80.0);
                                                                                                                
                                                                                                                    when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(topSize);
                                                                                                                    when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(bottomSize);
                                                                                                                    when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(leftSize);
                                                                                                                    when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(rightSize);
                                                                                                                
                                                                                                                    // Use reflection to call the protected arrangeFF method
                                                                                                                    java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                                    arrangeFFMethod.setAccessible(true);
                                                                                                                    Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                                                
                                                                                                                    // Verify the expected behavior
                                                                                                                    double[] expectedWidths = {100.0, 100.0, 30.0, 40.0, 30.0};
                                                                                                                    double[] expectedHeights = {50.0, 70.0, 80.0, 80.0, 80.0};
                                                                                                                
                                                                                                                    // Assertions to detect the mutant
                                                                                                                    assertEquals("Width mismatch for w[0]", expectedWidths[0], result.width, 0.001);
                                                                                                                    assertEquals("Height mismatch for h[0]", expectedHeights[0], topSize.height, 0.001);
                                                                                                                
                                                                                                                    assertEquals("Width mismatch for w[1]", expectedWidths[1], result.width, 0.001);
                                                                                                                    assertEquals("Height mismatch for h[1]", expectedHeights[1], bottomSize.height, 0.001);
                                                                                                                
                                                                                                                    assertEquals("Width mismatch for w[2]", expectedWidths[2], leftSize.width, 0.001);
                                                                                                                    assertEquals("Height mismatch for h[2]", expectedHeights[2], constraint.getHeight() - bottomSize.height - topSize.height, 0.001);
                                                                                                                
                                                                                                                    // This assertion specifically targets the mutant
                                                                                                                    assertEquals("Height mismatch for h[3] (detecting mutant)", expectedHeights[3], expectedHeights[2], 0.001);
                                                                                                                
                                                                                                                    assertEquals("Width mismatch for w[3]", expectedWidths[3], rightSize.width, 0.001);
                                                                                                                    assertEquals("Height mismatch for h[4]", expectedHeights[4], constraint.getHeight() - bottomSize.height - topSize.height, 0.001);
                                                                                                                
                                                                                                                    assertEquals("Width mismatch for w[4]", expectedWidths[4], constraint.getWidth() - rightSize.width - leftSize.width, 0.001);
                                                                                                                
                                                                                                                    // Verify that blocks are set correctly
                                                                                                                    verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, expectedWidths[0], expectedHeights[0]));
                                                                                                                    verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, expectedHeights[0] + expectedHeights[2], expectedWidths[1], expectedHeights[1]));
                                                                                                                    verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, expectedHeights[0], expectedWidths[2], expectedHeights[2]));
                                                                                                                    verify(rightBlock).setBounds(new Rectangle2D.Double(expectedWidths[2] + expectedWidths[4], expectedHeights[0], expectedWidths[3], expectedHeights[3]));
                                                                                                                    verify(centerBlock).setBounds(new Rectangle2D.Double(expectedWidths[2], expectedHeights[0], expectedWidths[4], expectedHeights[4]));
                                                                                                                }

    @Test
                                                                                                    public void testArrangeFFDetectsMutant2() throws Exception {
                                                                                                        // Set up the constraint
                                                                                                        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                                                    
                                                                                                        // Create mock objects
                                                                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                                                                        Block topBlock = mock(Block.class);
                                                                                                        Block bottomBlock = mock(Block.class);
                                                                                                        Block leftBlock = mock(Block.class);
                                                                                                        Block rightBlock = mock(Block.class);
                                                                                                        BlockContainer container = mock(BlockContainer.class);
                                                                                                    
                                                                                                        // Create the arrangement object
                                                                                                        BorderArrangement arrangement = new BorderArrangement();
                                                                                                    
                                                                                                        // Mock the topBlock arrangement to return a specific size
                                                                                                        when(topBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                .thenReturn(new Size2D(100.0, 50.0));
                                                                                                    
                                                                                                        // Mock the bottomBlock arrangement to return a specific size
                                                                                                        when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                .thenReturn(new Size2D(100.0, 50.0));
                                                                                                    
                                                                                                        // Mock the leftBlock arrangement to return a specific size
                                                                                                        when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                .thenReturn(new Size2D(30.0, 100.0));
                                                                                                    
                                                                                                        // Mock the rightBlock arrangement to return a specific size
                                                                                                        when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                                                                                                                .thenReturn(new Size2D(30.0, 100.0));
                                                                                                    
                                                                                                        // Use reflection to access the protected arrangeFF method
                                                                                                        java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                                                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                        arrangeFFMethod.setAccessible(true);
                                                                                                    
                                                                                                        // Call the method under test using reflection
                                                                                                        Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
                                                                                                    
                                                                                                        // Verify the bounds of the rightBlock
                                                                                                        verify(rightBlock).setBounds(new Rectangle2D.Double(30.0 + 40.0, 50.0, 30.0, 100.0));
                                                                                                    
                                                                                                        // Assert the result size is as expected
                                                                                                        assertEquals(100.0, result.width, 0.001);
                                                                                                        assertEquals(200.0, result.height, 0.001);
                                                                                                    }

    @Test
                                                                                                public void testArrangeFFDetectsMutant3() throws Exception {
                                                                                                    // Arrange
                                                                                                    BorderArrangement arrangement = new BorderArrangement();
                                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                                                    RectangleConstraint constraint = mock(RectangleConstraint.class);
                                                                                                    Block rightBlock = mock(Block.class);
                                                                                                    Block leftBlock = mock(Block.class);
                                                                                                    Block topBlock = mock(Block.class);
                                                                                                    Block bottomBlock = mock(Block.class);
                                                                                                    Block centerBlock = mock(Block.class);
                                                                                            
                                                                                                    // Mock constraint behavior
                                                                                                    when(constraint.getWidth()).thenReturn(100.0);
                                                                                                    when(constraint.getHeight()).thenReturn(200.0);
                                                                                            
                                                                                                    // Mock block behavior
                                                                                                    Size2D rightBlockSize = new Size2D(30.0, 50.0);
                                                                                                    Size2D leftBlockSize = new Size2D(20.0, 50.0);
                                                                                                    Size2D topBlockSize = new Size2D(100.0, 20.0);
                                                                                                    Size2D bottomBlockSize = new Size2D(100.0, 30.0);
                                                                                                    when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(rightBlockSize);
                                                                                                    when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(leftBlockSize);
                                                                                                    when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(topBlockSize);
                                                                                                    when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(bottomBlockSize);
                                                                                            
                                                                                                    // Use reflection to set private fields
                                                                                                    Field topBlockField = BorderArrangement.class.getDeclaredField("topBlock");
                                                                                                    topBlockField.setAccessible(true);
                                                                                                    topBlockField.set(arrangement, topBlock);
                                                                                            
                                                                                                    Field bottomBlockField = BorderArrangement.class.getDeclaredField("bottomBlock");
                                                                                                    bottomBlockField.setAccessible(true);
                                                                                                    bottomBlockField.set(arrangement, bottomBlock);
                                                                                            
                                                                                                    Field leftBlockField = BorderArrangement.class.getDeclaredField("leftBlock");
                                                                                                    leftBlockField.setAccessible(true);
                                                                                                    leftBlockField.set(arrangement, null); // Left block is null
                                                                                            
                                                                                                    Field rightBlockField = BorderArrangement.class.getDeclaredField("rightBlock");
                                                                                                    rightBlockField.setAccessible(true);
                                                                                                    rightBlockField.set(arrangement, rightBlock); // Right block is non-null
                                                                                            
                                                                                                    Field centerBlockField = BorderArrangement.class.getDeclaredField("centerBlock");
                                                                                                    centerBlockField.setAccessible(true);
                                                                                                    centerBlockField.set(arrangement, centerBlock);
                                                                                            
                                                                                                    // Act
                                                                                                    Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                                    arrangeFFMethod.setAccessible(true);
                                                                                                    Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                            
                                                                                                    // Assert
                                                                                                    // Verify that the rightBlock's arrange method was called
                                                                                                    verify(rightBlock, times(1)).arrange(eq(g2), any(RectangleConstraint.class));
                                                                                            
                                                                                                    // Verify that the leftBlock's arrange method was not called
                                                                                                    verify(leftBlock, never()).arrange(eq(g2), any(RectangleConstraint.class));
                                                                                            
                                                                                                    // Verify that the bounds for the rightBlock were set correctly
                                                                                                    verify(rightBlock, times(1)).setBounds(new Rectangle2D.Double(
                                                                                                            70.0, // w[2] + w[4] (from the calculation)
                                                                                                            20.0, // h[0] (from topBlock height)
                                                                                                            30.0, // w[3] (from rightBlock width)
                                                                                                            50.0  // h[3] (from rightBlock height)
                                                                                                    ));
                                                                                            
                                                                                                    // Verify that the bounds for other blocks were set correctly
                                                                                                    verify(topBlock, times(1)).setBounds(new Rectangle2D.Double(
                                                                                                            0.0, 0.0, 100.0, 20.0
                                                                                                    ));
                                                                                                    verify(bottomBlock, times(1)).setBounds(new Rectangle2D.Double(
                                                                                                            0.0, 70.0, 100.0, 30.0
                                                                                                    ));
                                                                                                    verify(centerBlock, times(1)).setBounds(new Rectangle2D.Double(
                                                                                                            20.0, 20.0, 50.0, 50.0
                                                                                                    ));
                                                                                            
                                                                                                    // Verify the final size returned by the method
                                                                                                    assertEquals(100.0, result.width, 0.0001);
                                                                                                    assertEquals(200.0, result.height, 0.0001);
                                                                                                }

    @Test
                                                                                        public void testArrangeFFDetectMutant9() throws Exception {
                                                                                            // Arrange
                                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                                            Block topBlock = mock(Block.class);
                                                                                            Block bottomBlock = mock(Block.class);
                                                                                            Block leftBlock = mock(Block.class);
                                                                                            Block rightBlock = mock(Block.class);
                                                                                            Block centerBlock = mock(Block.class);
                                                                                    
                                                                                            arrangement.add(topBlock, "TOP");
                                                                                            arrangement.add(bottomBlock, "BOTTOM");
                                                                                            arrangement.add(leftBlock, "LEFT");
                                                                                            arrangement.add(rightBlock, "RIGHT");
                                                                                            arrangement.add(centerBlock, "CENTER");
                                                                                    
                                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                                    
                                                                                            Size2D topSize = new Size2D(100.0, 50.0);
                                                                                            Size2D bottomSize = new Size2D(100.0, 50.0);
                                                                                            Size2D leftSize = new Size2D(30.0, 100.0);
                                                                                            Size2D rightSize = new Size2D(30.0, 100.0);
                                                                                    
                                                                                            when(topBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(topSize);
                                                                                            when(bottomBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(bottomSize);
                                                                                            when(leftBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(leftSize);
                                                                                            when(rightBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(rightSize);
                                                                                    
                                                                                            // Act
                                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                            arrangeFFMethod.setAccessible(true);
                                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                                    
                                                                                            // Assert
                                                                                            assertEquals(100.0, result.width, 0.0001);
                                                                                            assertEquals(200.0, result.height, 0.0001);
                                                                                    
                                                                                            // Verify that the leftBlock was arranged with the correct constraint
                                                                                            verify(leftBlock).arrange(eq(g2), argThat(c -> {
                                                                                                return c.getHeightRange() != null && c.getHeightRange().getLowerBound() == 100.0;
                                                                                            }));
                                                                                    
                                                                                            // Verify that the leftBlock bounds are set correctly
                                                                                            verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 30.0, 100.0));
                                                                                        }

    @Test
                                                                                public void testArrangeFFDetectsMutant4() throws Exception {
                                                                                    // Arrange
                                                                                    BorderArrangement arrangement = new BorderArrangement();
                                                                                    Graphics2D g2 = mock(Graphics2D.class);
                                                                            
                                                                                    // Mock the blocks
                                                                                    Block topBlock = mock(Block.class);
                                                                                    Block bottomBlock = mock(Block.class);
                                                                                    Block leftBlock = mock(Block.class);
                                                                                    Block rightBlock = mock(Block.class);
                                                                                    Block centerBlock = mock(Block.class);
                                                                            
                                                                                    // Set the blocks in the arrangement
                                                                                    arrangement.add(topBlock, "TOP");
                                                                                    arrangement.add(bottomBlock, "BOTTOM");
                                                                                    arrangement.add(leftBlock, "LEFT");
                                                                                    arrangement.add(rightBlock, "RIGHT");
                                                                                    arrangement.add(centerBlock, "CENTER");
                                                                            
                                                                                    // Define the constraint
                                                                                    double width = 100.0;
                                                                                    double height = 100.0;
                                                                                    RectangleConstraint constraint = new RectangleConstraint(width, height);
                                                                            
                                                                                    // Mock the arrange method to return fixed sizes
                                                                                    when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100, 20));
                                                                                    when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100, 20));
                                                                                    when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20, 60));
                                                                                    when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(20, 60));
                                                                                    when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(60, 60));
                                                                            
                                                                                    // Use reflection to access the protected arrangeFF method
                                                                                    Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                                    arrangeFFMethod.setAccessible(true);
                                                                            
                                                                                    // Act
                                                                                    Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                            
                                                                                    // Assert
                                                                                    assertEquals("Width should be 100", 100, result.width, 0.001);
                                                                                    assertEquals("Height should be 100", 100, result.height, 0.001);
                                                                            
                                                                                    // Verify that the blocks are arranged with fixed constraints
                                                                                    verify(topBlock).arrange(eq(g2), argThat(c -> c.getWidthConstraintType() == LengthConstraintType.FIXED));
                                                                                    verify(bottomBlock).arrange(eq(g2), argThat(c -> c.getWidthConstraintType() == LengthConstraintType.FIXED));
                                                                                    verify(leftBlock).arrange(eq(g2), argThat(c -> c.getHeightConstraintType() == LengthConstraintType.FIXED));
                                                                                    verify(rightBlock).arrange(eq(g2), argThat(c -> c.getHeightConstraintType() == LengthConstraintType.FIXED));
                                                                                }

    @Test
                                                                        public void testArrangeFFDetectsMutant5() throws Exception {
                                                                            // Create a BorderArrangement instance
                                                                            BorderArrangement arrangement = new BorderArrangement();
                                                                    
                                                                            // Mock the Block objects
                                                                            Block topBlock = mock(Block.class);
                                                                            Block bottomBlock = mock(Block.class);
                                                                            Block leftBlock = mock(Block.class);
                                                                            Block rightBlock = mock(Block.class);
                                                                            Block centerBlock = mock(Block.class);
                                                                    
                                                                            // Set the blocks in the arrangement
                                                                            arrangement.add(topBlock, "TOP");
                                                                            arrangement.add(bottomBlock, "BOTTOM");
                                                                            arrangement.add(leftBlock, "LEFT");
                                                                            arrangement.add(rightBlock, "RIGHT");
                                                                            arrangement.add(centerBlock, "CENTER");
                                                                    
                                                                            // Mock the Graphics2D object
                                                                            Graphics2D g2 = mock(Graphics2D.class);
                                                                    
                                                                            // Define a RectangleConstraint with specific dimensions
                                                                            RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                                    
                                                                            // Mock the arrange method for each block to return specific sizes
                                                                            when(topBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 50.0));
                                                                            when(bottomBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 50.0));
                                                                            when(leftBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(new Size2D(30.0, 100.0));
                                                                            when(rightBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(new Size2D(30.0, 100.0));
                                                                            when(centerBlock.arrange(g2, any(RectangleConstraint.class))).thenReturn(new Size2D(40.0, 100.0));
                                                                    
                                                                            // Use reflection to call the protected arrangeFF method
                                                                            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                                            arrangeFFMethod.setAccessible(true);
                                                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                                                    
                                                                            // Verify the expected outcome
                                                                            verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, 100.0, 50.0));
                                                                            verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 150.0, 100.0, 50.0));
                                                                            verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 50.0, 30.0, 100.0));
                                                                            verify(rightBlock).setBounds(new Rectangle2D.Double(70.0, 50.0, 30.0, 100.0));
                                                                            verify(centerBlock).setBounds(new Rectangle2D.Double(30.0, 50.0, 40.0, 100.0));
                                                                    
                                                                            // Assert the final size of the arrangement
                                                                            assertEquals(100.0, result.getWidth(), 0.001);
                                                                            assertEquals(200.0, result.getHeight(), 0.001);
                                                                        }

    @Test
                                                    public void testArrangeFFDetectMutant10() throws Exception {
                                                        // Arrange
                                                        RectangleConstraint constraint = new RectangleConstraint(100.0, 200.0);
                                                        Size2D expectedSize = new Size2D(100.0, 200.0);
                                                
                                                        // Create mock objects for the blocks
                                                        Block topBlock = mock(Block.class);
                                                        Block bottomBlock = mock(Block.class);
                                                        Block rightBlock = mock(Block.class);
                                                        Block centerBlock = mock(Block.class);
                                                        Block leftBlock = mock(Block.class); // Although leftBlock will not be used, it needs to be defined
                                                
                                                        // Create a mock Graphics2D object
                                                        Graphics2D g2 = mock(Graphics2D.class);
                                                
                                                        // Create an instance of BorderArrangement
                                                        BorderArrangement borderArrangement = new BorderArrangement();
                                                
                                                        // Mock the behavior of the blocks
                                                        when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 50.0));
                                                        when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 50.0));
                                                        when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(30.0, 100.0));
                                                        when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(70.0, 100.0));
                                                
                                                        // Add blocks to the BorderArrangement using reflection to access constants
                                                        Method addMethod = BorderArrangement.class.getDeclaredMethod("add", Block.class, Object.class);
                                                        addMethod.invoke(borderArrangement, topBlock, "TOP");
                                                        addMethod.invoke(borderArrangement, bottomBlock, "BOTTOM");
                                                        addMethod.invoke(borderArrangement, rightBlock, "RIGHT");
                                                        addMethod.invoke(borderArrangement, centerBlock, "CENTER");
                                                        addMethod.invoke(borderArrangement, null, "LEFT"); // Set leftBlock to null to ensure the mutant is detected
                                                
                                                        // Act
                                                        // Use reflection to access the protected arrangeFF method
                                                        Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                                        arrangeFFMethod.setAccessible(true);
                                                        Size2D resultSize = (Size2D) arrangeFFMethod.invoke(borderArrangement, null, g2, constraint);
                                                
                                                        // Assert
                                                        assertEquals(expectedSize, resultSize);
                                                
                                                        // Verify that rightBlock was arranged, not leftBlock
                                                        verify(rightBlock, times(1)).arrange(eq(g2), any(RectangleConstraint.class));
                                                        verify(leftBlock, never()).arrange(eq(g2), any(RectangleConstraint.class));
                                                    }

    @Test
                                        public void testArrangeFFDetectMutant11() throws Exception {
                                            // Arrange
                                            BorderArrangement arrangement = new BorderArrangement();
                                        
                                            // Mocking dependencies
                                            Block leftBlock = mock(Block.class);
                                            Graphics2D g2 = mock(Graphics2D.class);
                                            RectangleConstraint constraint = mock(RectangleConstraint.class);
                                        
                                            // Setting up mock behavior
                                            when(constraint.getWidth()).thenReturn(100.0);
                                            when(constraint.getHeight()).thenReturn(200.0);
                                            when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(30.0, 50.0));
                                        
                                            // Injecting the mocked leftBlock into the arrangement
                                            arrangement.add(leftBlock, "LEFT");
                                        
                                            // Using reflection to access the protected arrangeFF method
                                            java.lang.reflect.Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod(
                                                "arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                                            arrangeFFMethod.setAccessible(true);
                                        
                                            // Act
                                            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
                                        
                                            // Assert
                                            // Verify that the leftBlock was arranged with the correct RectangleConstraint
                                            verify(leftBlock).arrange(eq(g2), argThat(c -> {
                                                if (c instanceof RectangleConstraint) {
                                                    RectangleConstraint rc = (RectangleConstraint) c;
                                                    return rc.getWidthConstraintType() == LengthConstraintType.RANGE
                                                            && rc.getHeightConstraintType() == LengthConstraintType.FIXED
                                                            && rc.getHeight() == 200.0 - 0.0 - 0.0; // h[2] logic
                                                }
                                                return false;
                                            }));
                                        
                                            // Additional assertions to ensure the result matches expectations
                                            assertNotNull(result);
                                            assertEquals(100.0, result.width, 0.001);
                                            assertEquals(200.0, result.height, 0.001);
                                        }

    @Test
                public void testArrangeFFDetectsMutant6() throws Exception {
                    // Arrange
                    BorderArrangement arrangement = new BorderArrangement();
                    BlockContainer container = mock(BlockContainer.class);
                    Graphics2D g2 = mock(Graphics2D.class);
            
                    Block rightBlock = mock(Block.class);
                    Block topBlock = mock(Block.class);
                    Block bottomBlock = mock(Block.class);
            
                    // Set up the blocks in the arrangement
                    arrangement.add(rightBlock, "RIGHT");
                    arrangement.add(topBlock, "TOP");
                    arrangement.add(bottomBlock, "BOTTOM");
            
                    // Mock the constraints and sizes
                    RectangleConstraint constraint = new RectangleConstraint(100.0, 100.0);
                    when(topBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 20.0));
                    when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(100.0, 30.0));
            
                    // Mock the right block to return a specific size
                    when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class))).thenReturn(new Size2D(40.0, 50.0));
            
                    // Act
                    Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
                    arrangeFFMethod.setAccessible(true);
                    Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, container, g2, constraint);
            
                    // Assert
                    // Check the size of the arrangement
                    assertEquals(100.0, result.width, 0.001);
                    assertEquals(100.0, result.height, 0.001);
            
                    // Verify that the rightBlock was arranged with the expected constraint
                    verify(rightBlock).arrange(eq(g2), argThat(argument -> argument.getHeightRange().getUpperBound() == 50.0));
                }

    @Test
        public void testArrangeFFWithFixedConstraint() throws Exception {
            // Arrange
            BorderArrangement arrangement = new BorderArrangement();
    
            Block topBlock = mock(Block.class);
            Block bottomBlock = mock(Block.class);
            Block leftBlock = mock(Block.class);
            Block rightBlock = mock(Block.class);
            Block centerBlock = mock(Block.class);
    
            arrangement.add(topBlock, "TOP");
            arrangement.add(bottomBlock, "BOTTOM");
            arrangement.add(leftBlock, "LEFT");
            arrangement.add(rightBlock, "RIGHT");
            arrangement.add(centerBlock, "CENTER");
    
            Graphics2D g2 = mock(Graphics2D.class);
    
            double width = 100.0;
            double height = 100.0;
    
            RectangleConstraint constraint = new RectangleConstraint(width, height);
    
            when(topBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(width, 20.0));
            when(bottomBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(width, 20.0));
            when(leftBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(20.0, height - 40.0));
            when(rightBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(20.0, height - 40.0));
            when(centerBlock.arrange(eq(g2), any(RectangleConstraint.class)))
                .thenReturn(new Size2D(width - 40.0, height - 40.0));
    
            // Act
            // Use reflection to invoke the protected arrangeFF method
            Method arrangeFFMethod = BorderArrangement.class.getDeclaredMethod("arrangeFF", 
                BlockContainer.class, Graphics2D.class, RectangleConstraint.class);
            arrangeFFMethod.setAccessible(true);
            Size2D result = (Size2D) arrangeFFMethod.invoke(arrangement, null, g2, constraint);
    
            // Assert
            assertEquals("Width should be fixed as constraint width", width, result.width, 0.001);
            assertEquals("Height should be fixed as constraint height", height, result.height, 0.001);
    
            verify(topBlock).setBounds(new Rectangle2D.Double(0.0, 0.0, width, 20.0));
            verify(bottomBlock).setBounds(new Rectangle2D.Double(0.0, 60.0, width, 20.0));
            verify(leftBlock).setBounds(new Rectangle2D.Double(0.0, 20.0, 20.0, 60.0));
            verify(rightBlock).setBounds(new Rectangle2D.Double(80.0, 20.0, 20.0, 60.0));
            verify(centerBlock).setBounds(new Rectangle2D.Double(20.0, 20.0, 60.0, 60.0));
        }


}
