package gentest.org.jfree.data.time.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.time.*;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.data.general.Series;
import org.jfree.data.general.SeriesChangeEvent;
import org.jfree.data.general.SeriesException;
 
public class TimeSeriesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                        public void testClone_TypicalValues() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            TimeSeries original = new TimeSeries("Test Series", "Domain", "Range", Day.class);
                                                                                                                                                                                                                            original.add(new Day(1, 1, 2023), 10.0);
                                                                                                                                                                                                                            original.add(new Day(2, 1, 2023), 20.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                            TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                            assertNotSame("Cloned object should not be the same instance as the original", original, cloned);
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same domain description as the original", original.getDomainDescription(), cloned.getDomainDescription());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same range description as the original", original.getRangeDescription(), cloned.getRangeDescription());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same time period class as the original", original.getTimePeriodClass(), cloned.getTimePeriodClass());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same maximum item count as the original", original.getMaximumItemCount(), cloned.getMaximumItemCount());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same maximum item age as the original", original.getMaximumItemAge(), cloned.getMaximumItemAge());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same number of items as the original", original.getItemCount(), cloned.getItemCount());
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Verify deep clone of data
                                                                                                                                                                                                                            List originalData = original.getItems();
                                                                                                                                                                                                                            List clonedData = cloned.getItems();
                                                                                                                                                                                                                            assertNotSame("Cloned data list should not be the same instance as the original data list", originalData, clonedData);
                                                                                                                                                                                                                            assertEquals("Cloned data list should have the same content as the original data list", originalData, clonedData);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Verify that modifying the cloned object does not affect the original
                                                                                                                                                                                                                            cloned.add(new Day(3, 1, 2023), 30.0);
                                                                                                                                                                                                                            assertEquals("Original object should not be affected by changes to the cloned object", 2, original.getItemCount());
                                                                                                                                                                                                                            assertEquals("Cloned object should reflect the new item added", 3, cloned.getItemCount());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testClone_EmptySeries() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            TimeSeries original = new TimeSeries("Empty Series", "Domain", "Range", Day.class);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                            TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                            assertNotSame("Cloned object should not be the same instance as the original", original, cloned);
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same domain description as the original", original.getDomainDescription(), cloned.getDomainDescription());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same range description as the original", original.getRangeDescription(), cloned.getRangeDescription());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same time period class as the original", original.getTimePeriodClass(), cloned.getTimePeriodClass());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same maximum item count as the original", original.getMaximumItemCount(), cloned.getMaximumItemCount());
                                                                                                                                                                                                                            assertEquals("Cloned object should have the same maximum item age as the original", original.getMaximumItemAge(), cloned.getMaximumItemAge());
                                                                                                                                                                                                                            assertEquals("Cloned object should have no items", 0, cloned.getItemCount());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testClone_ModifiedDataAfterCloning() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            TimeSeries original = new TimeSeries("Test Series", "Domain", "Range", Day.class);
                                                                                                                                                                                                                            original.add(new Day(1, 1, 2023), 10.0);
                                                                                                                                                                                                                            original.add(new Day(2, 1, 2023), 20.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                            TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                                                                                                                            List clonedData = cloned.getItems();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Modify the cloned data
                                                                                                                                                                                                                            clonedData.clear();
                                                                                                                                                                                                                    
                                                                                                                                                                                                                            // Assert
                                                                                                                                                                                                                            assertEquals("Original data should remain unchanged after modifying cloned data", 2, original.getItemCount());
                                                                                                                                                                                                                            assertEquals("Cloned data should reflect the modification", 0, cloned.getItemCount());
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                    public void testClone_NullData() throws Exception {
                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                        TimeSeries original = new TimeSeries("Null Data Series", "Domain", "Range", Day.class);
                                                                                                                                                                                                    
                                                                                                                                                                                                        // Use reflection to set the protected 'data' field to null
                                                                                                                                                                                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                                                                        dataField.setAccessible(true);
                                                                                                                                                                                                        dataField.set(original, null);
                                                                                                                                                                                                    
                                                                                                                                                                                                        // Act & Assert
                                                                                                                                                                                                        try {
                                                                                                                                                                                                            original.clone();
                                                                                                                                                                                                            fail("Expected NullPointerException to be thrown");
                                                                                                                                                                                                        } catch (NullPointerException e) {
                                                                                                                                                                                                            // Test passes if NullPointerException is thrown
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                            public void testCloneDetectMutant() throws Exception {
                                                                                                                                                                                                // Step 1: Create a TimeSeries object and populate its data list
                                                                                                                                                                                                TimeSeries original = new TimeSeries("Original Series");
                                                                                                                                                                                                original.add(new Day(1, 1, 2023), 100.0); // Using Day class from JFreeChart library
                                                                                                                                                                                                original.add(new Day(2, 1, 2023), 200.0);
                                                                                                                                                                                            
                                                                                                                                                                                                // Step 2: Clone the original TimeSeries object
                                                                                                                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                                                                                            
                                                                                                                                                                                                // Step 3: Use reflection to access the protected 'data' field
                                                                                                                                                                                                java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                                                                                dataField.setAccessible(true);
                                                                                                                                                                                            
                                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                                List<?> originalData = (List<?>) dataField.get(original);
                                                                                                                                                                                            
                                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                                List<?> clonedData = (List<?>) dataField.get(cloned);
                                                                                                                                                                                            
                                                                                                                                                                                                // Step 4: Verify that the cloned object's data list is not cleared
                                                                                                                                                                                                assertNotNull("Cloned data list should not be null", clonedData);
                                                                                                                                                                                                assertEquals("Cloned data list should have the same size as the original", originalData.size(), clonedData.size());
                                                                                                                                                                                            
                                                                                                                                                                                                // Step 5: Verify that the contents of the cloned data list match the original
                                                                                                                                                                                                for (int i = 0; i < originalData.size(); i++) {
                                                                                                                                                                                                    assertEquals("Cloned data list should match the original data list", originalData.get(i), clonedData.get(i));
                                                                                                                                                                                                }
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                public void testCloneDetectsMutant() {
                                                                                                                                                                                    try {
                                                                                                                                                                                        // Step 1: Set up the original TimeSeries object with some data
                                                                                                                                                                                        TimeSeries original = new TimeSeries("Test Series", Day.class);
                                                                                                                                                                                        original.add(new Day(1, 1, 2023), 1.0);
                                                                                                                                                                                        original.add(new Day(2, 1, 2023), 2.0);
                                                                                                                                                                                
                                                                                                                                                                                        // Step 2: Clone the original TimeSeries
                                                                                                                                                                                        TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                                                                                
                                                                                                                                                                                        // Step 3: Verify that the cloned data is a deep clone, not an unmodifiable list
                                                                                                                                                                                        List originalData = original.getItems();
                                                                                                                                                                                        List clonedData = cloned.getItems();
                                                                                                                                                                                
                                                                                                                                                                                        // Check that the cloned data is not the same instance as the original data
                                                                                                                                                                                        assertNotSame("Cloned data should be a different instance from original data", originalData, clonedData);
                                                                                                                                                                                
                                                                                                                                                                                        // Check that modifications to the cloned data do not affect the original data
                                                                                                                                                                                        clonedData.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 3.0));
                                                                                                                                                                                        assertEquals("Original data size should remain unchanged", 2, originalData.size());
                                                                                                                                                                                        assertEquals("Cloned data size should be updated", 3, clonedData.size());
                                                                                                                                                                                
                                                                                                                                                                                        // Check that the cloned data is modifiable (i.e., not unmodifiable)
                                                                                                                                                                                        try {
                                                                                                                                                                                            clonedData.add(new TimeSeriesDataItem(new Day(4, 1, 2023), 4.0));
                                                                                                                                                                                            // If we can add, it means the list is modifiable
                                                                                                                                                                                        } catch (UnsupportedOperationException e) {
                                                                                                                                                                                            fail("Cloned data should be modifiable, indicating deep clone");
                                                                                                                                                                                        }
                                                                                                                                                                                    } catch (CloneNotSupportedException e) {
                                                                                                                                                                                        fail("CloneNotSupportedException should not be thrown");
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testCreateCopyWithEndEqualToStart() {
                                                                                                                                                                            // Initialize the TimeSeries object
                                                                                                                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                                                                                                    
                                                                                                                                                                            // Expect an exception when end is equal to start
                                                                                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                            thrown.expectMessage("Invalid range: end must be greater than start");
                                                                                                                                                                    
                                                                                                                                                                            try {
                                                                                                                                                                                // Call createCopy with end equal to start
                                                                                                                                                                                timeSeries.createCopy(1, 1);
                                                                                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                                                                                // Handle the CloneNotSupportedException if necessary
                                                                                                                                                                                // In this case, we don't expect it to be thrown, so we can rethrow it as a runtime exception
                                                                                                                                                                                throw new RuntimeException(e);
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testCreateCopyMutationDetection() {
                                                                                                                                                            // Create a TimeSeries object with some sample data
                                                                                                                                                            TimeSeries originalSeries = new TimeSeries("Sample Series");
                                                                                                                                                        
                                                                                                                                                            // Populate the TimeSeries with some data items using Day as the concrete RegularTimePeriod
                                                                                                                                                            originalSeries.add(new Day(1, 1, 2023), 1.0);
                                                                                                                                                            originalSeries.add(new Day(2, 1, 2023), 2.0);
                                                                                                                                                            originalSeries.add(new Day(3, 1, 2023), 3.0);
                                                                                                                                                        
                                                                                                                                                            // Attempt to create a copy with start > end, which should trigger the mutant
                                                                                                                                                            try {
                                                                                                                                                                TimeSeries copiedSeries = originalSeries.createCopy(2, 1);
                                                                                                                                                                fail("Expected IllegalArgumentException due to invalid range (start > end)");
                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                // Expected exception, test passes
                                                                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                                                                fail("Unexpected CloneNotSupportedException thrown");
                                                                                                                                                            }
                                                                                                                                                        
                                                                                                                                                            // Attempt to create a valid copy with start < end
                                                                                                                                                            try {
                                                                                                                                                                TimeSeries copiedSeries = originalSeries.createCopy(1, 2);
                                                                                                                                                                assertNotNull(copiedSeries);
                                                                                                                                                                assertEquals(2, copiedSeries.getItemCount());
                                                                                                                                                                assertEquals(originalSeries.getDataItem(1), copiedSeries.getDataItem(0));
                                                                                                                                                                assertEquals(originalSeries.getDataItem(2), copiedSeries.getDataItem(1));
                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                fail("Did not expect IllegalArgumentException for valid range (start < end)");
                                                                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                                                                fail("Unexpected CloneNotSupportedException thrown");
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testCreateCopyThrowsExceptionForInvalidRange() {
                                                                                                                                                        // Arrange
                                                                                                                                                        TimeSeries series = new TimeSeries("Test Series");
                                                                                                                                                
                                                                                                                                                        // Act & Assert
                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                        thrown.expectMessage("Requires start <= end.");
                                                                                                                                                
                                                                                                                                                        try {
                                                                                                                                                            // Attempt to create a copy with an invalid range
                                                                                                                                                            series.createCopy(5, 3);
                                                                                                                                                        } catch (CloneNotSupportedException e) {
                                                                                                                                                            // Handle the exception if thrown
                                                                                                                                                            throw new RuntimeException(e);
                                                                                                                                                        }
                                                                                                                                                    }

    @Test
                                                                                                                                    public void testCloneMethodExceptionHandling() {
                                                                                                                                        // Step 1: Set up the test environment
                                                                                                                                        // Create a TimeSeries object with dummy data
                                                                                                                                        TimeSeries timeSeries = new TimeSeries("Test Series", "Domain", "Range", Day.class);
                                                                                                                                        List<Object> dummyData = new ArrayList<>();
                                                                                                                                        dummyData.add(new Object()); // Add some dummy data
                                                                                                                                    
                                                                                                                                        try {
                                                                                                                                            // Use reflection to set the protected 'data' field
                                                                                                                                            Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                                            dataField.setAccessible(true);
                                                                                                                                            dataField.set(timeSeries, dummyData);
                                                                                                                                    
                                                                                                                                            // Step 2: Simulate the mutation scenario
                                                                                                                                            // Here, we are testing the behavior of the clone method to ensure it throws the correct exception
                                                                                                                                            try {
                                                                                                                                                // Attempt to clone the TimeSeries object
                                                                                                                                                TimeSeries clonedSeries = (TimeSeries) timeSeries.clone();
                                                                                                                                    
                                                                                                                                                // Step 3: Verify the expected behavior
                                                                                                                                                // If no exception is thrown, the test fails
                                                                                                                                                fail("Expected IllegalArgumentException was not thrown.");
                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                // Step 4: Validate the correct exception type
                                                                                                                                                // The test passes if IllegalArgumentException is thrown
                                                                                                                                                assertEquals("Requires start <= end.", e.getMessage());
                                                                                                                                            } catch (CloneNotSupportedException e) {
                                                                                                                                                // Handle CloneNotSupportedException if thrown
                                                                                                                                                fail("CloneNotSupportedException was thrown: " + e.getMessage());
                                                                                                                                            } catch (RuntimeException e) {
                                                                                                                                                // If a RuntimeException is thrown, the test fails
                                                                                                                                                fail("Mutation detected: RuntimeException was thrown instead of IllegalArgumentException.");
                                                                                                                                            }
                                                                                                                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                                            fail("Failed to set up test environment: " + e.getMessage());
                                                                                                                                        }
                                                                                                                                    }

    @Test
                                                                                                                                    public void testCloneMethodDetectsMutant() throws CloneNotSupportedException {
                                                                                                                                        // Step 1: Set up the original TimeSeries object with some data
                                                                                                                                        TimeSeries original = new TimeSeries("Test Series", Day.class);
                                                                                                                                        original.add(new Day(1, 1, 2020), 100.0);
                                                                                                                                        original.add(new Day(2, 1, 2020), 200.0);
                                                                                                                                        original.add(new Day(3, 1, 2020), 300.0);
                                                                                                                                
                                                                                                                                        // Step 2: Clone the original TimeSeries
                                                                                                                                        TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                                
                                                                                                                                        // Step 3: Verify that the cloned object is not the same instance as the original
                                                                                                                                        assertNotSame("Cloned object should not be the same instance as the original", original, cloned);
                                                                                                                                
                                                                                                                                        // Step 4: Verify that the data list is deeply cloned
                                                                                                                                        assertNotSame("Data list should be deeply cloned", original.getItems(), cloned.getItems());
                                                                                                                                
                                                                                                                                        // Step 5: Verify that the contents of the data list are equal
                                                                                                                                        assertEquals("Data list contents should be equal", original.getItems(), cloned.getItems());
                                                                                                                                
                                                                                                                                        // Step 6: Modify the cloned object and verify that the original is not affected
                                                                                                                                        cloned.add(new Day(4, 1, 2020), 400.0);
                                                                                                                                        assertEquals("Original should not be affected by changes to the clone", 3, original.getItemCount());
                                                                                                                                        assertEquals("Cloned should reflect the new addition", 4, cloned.getItemCount());
                                                                                                                                    }

    @Test
                                                                                                                            public void testCloneMethodCapturesMutant() throws CloneNotSupportedException {
                                                                                                                                // Create a TimeSeries instance with some data
                                                                                                                                TimeSeries original = new TimeSeries("Test Series");
                                                                                                                                original.add(new Day(1, 1, 2023), 10.0); // Using Day as a RegularTimePeriod
                                                                                                                                original.add(new Day(2, 1, 2023), 20.0);
                                                                                                                                original.add(new Day(3, 1, 2023), 30.0);
                                                                                                                        
                                                                                                                                // Clone the TimeSeries
                                                                                                                                TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                                        
                                                                                                                                // Verify that the cloned series has the same data as the original
                                                                                                                                assertEquals("Cloned series should have the same item count as original", original.getItemCount(), cloned.getItemCount());
                                                                                                                        
                                                                                                                                // Check each item in the cloned list to ensure it matches the original
                                                                                                                                for (int i = 0; i < original.getItemCount(); i++) {
                                                                                                                                    assertEquals("Cloned series item should match original", original.getDataItem(i), cloned.getDataItem(i));
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                        public void testCloneDetectsMutation() throws Exception {
                                                                                                                            // Arrange
                                                                                                                            TimeSeries original = new TimeSeries("Test Series");
                                                                                                                            original.add(new TimeSeriesDataItem(new Day(1, 1, 2020), 100.0));
                                                                                                                            original.add(new TimeSeriesDataItem(new Day(2, 1, 2020), 200.0));
                                                                                                                            original.add(new TimeSeriesDataItem(new Day(3, 1, 2020), 300.0));
                                                                                                                    
                                                                                                                            // Act
                                                                                                                            TimeSeries clone = (TimeSeries) original.clone();
                                                                                                                    
                                                                                                                            // Assert
                                                                                                                            // The original data should remain unchanged
                                                                                                                            assertEquals(3, original.getItemCount());
                                                                                                                    
                                                                                                                            // The clone should have the same data as the original
                                                                                                                            assertEquals(original.getItemCount(), clone.getItemCount());
                                                                                                                            for (int i = 0; i < original.getItemCount(); i++) {
                                                                                                                                assertEquals(original.getDataItem(i), clone.getDataItem(i));
                                                                                                                            }
                                                                                                                    
                                                                                                                            // Now, let's simulate the mutation effect
                                                                                                                            // Remove an item from the original and clone again
                                                                                                                            original.delete(1, 1); // This should remove the second item
                                                                                                                    
                                                                                                                            TimeSeries cloneAfterDelete = (TimeSeries) original.clone();
                                                                                                                    
                                                                                                                            // The clone should have the same data as the original after deletion
                                                                                                                            assertEquals(original.getItemCount(), cloneAfterDelete.getItemCount());
                                                                                                                            for (int i = 0; i < original.getItemCount(); i++) {
                                                                                                                                assertEquals(original.getDataItem(i), cloneAfterDelete.getDataItem(i));
                                                                                                                            }
                                                                                                                    
                                                                                                                            // If the mutant is present, the cloneAfterDelete will have an empty data list
                                                                                                                            // This assertion will fail if the mutant is not caught
                                                                                                                            assertFalse(cloneAfterDelete.getItems().isEmpty());
                                                                                                                        }

    @Test
                                                                                                                public void testCloneDetectMutant1() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                                    // Step 1: Create a TimeSeries object and populate it with test data
                                                                                                                    TimeSeries original = new TimeSeries("Test Series");
                                                                                                            
                                                                                                                    // Use reflection to access the protected 'data' field
                                                                                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                                    dataField.setAccessible(true);
                                                                                                            
                                                                                                                    // Add items to the original TimeSeries
                                                                                                                    List originalData = (List) dataField.get(original);
                                                                                                                    originalData.add("Item 1");
                                                                                                                    originalData.add("Item 2");
                                                                                                                    originalData.add("Item 3");
                                                                                                            
                                                                                                                    // Step 2: Clone the original TimeSeries object
                                                                                                                    TimeSeries clone = (TimeSeries) original.clone();
                                                                                                            
                                                                                                                    // Access the cloned data using reflection
                                                                                                                    List cloneData = (List) dataField.get(clone);
                                                                                                            
                                                                                                                    // Step 3: Verify that the cloned object's data matches the original
                                                                                                                    assertNotNull(clone);
                                                                                                                    assertNotSame(original, clone); // Ensure it's a deep copy
                                                                                                                    assertNotSame(originalData, cloneData); // Ensure the data list is deep cloned
                                                                                                                    assertEquals(originalData, cloneData); // Ensure the contents are identical
                                                                                                            
                                                                                                                    // Step 4: Simulate the mutation and verify behavior
                                                                                                                    // Remove an item from the cloned data and verify the behavior
                                                                                                                    cloneData.remove(1); // Remove the second item ("Item 2")
                                                                                                            
                                                                                                                    // Verify that the original data is unaffected
                                                                                                                    assertEquals(3, originalData.size());
                                                                                                                    assertEquals("Item 1", originalData.get(0));
                                                                                                                    assertEquals("Item 2", originalData.get(1));
                                                                                                                    assertEquals("Item 3", originalData.get(2));
                                                                                                            
                                                                                                                    // Verify that the cloned data reflects the removal
                                                                                                                    assertEquals(2, cloneData.size());
                                                                                                                    assertEquals("Item 1", cloneData.get(0));
                                                                                                                    assertEquals("Item 3", cloneData.get(1));
                                                                                                            
                                                                                                                    // If the mutation were present, the wrong item would have been removed
                                                                                                                    // (e.g., "Item 3" instead of "Item 2"). This test ensures that the mutation is detected.
                                                                                                                }

    @Test
                                                                                                        public void testCloneDetectsFireSeriesChanged() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                            // Step 1: Create a mock of the TimeSeries class
                                                                                                            TimeSeries original = spy(new TimeSeries("Test Series"));
                                                                                                    
                                                                                                            // Step 2: Set up the data for the original TimeSeries using reflection
                                                                                                            List<Object> mockData = new ArrayList<>();
                                                                                                            mockData.add("Sample Data");
                                                                                                    
                                                                                                            // Access the protected 'data' field using reflection
                                                                                                            Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                            dataField.setAccessible(true);
                                                                                                            dataField.set(original, mockData);
                                                                                                    
                                                                                                            // Step 3: Clone the TimeSeries
                                                                                                            TimeSeries cloned = (TimeSeries) original.clone();
                                                                                                    
                                                                                                            // Step 4: Verify that the data was deep-cloned
                                                                                                            List<Object> clonedData = (List<Object>) dataField.get(cloned);
                                                                                                            assertNotSame("The data list should be deep-cloned", mockData, clonedData);
                                                                                                            assertEquals("The cloned data list should have the same content as the original", mockData, clonedData);
                                                                                                    
                                                                                                            // Step 5: Verify that fireSeriesChanged() was called
                                                                                                            verify(original).fireSeriesChanged();
                                                                                                        }

    @Test
                                                                                                public void testCloneDetectsMutant1() throws CloneNotSupportedException, NoSuchFieldException, IllegalAccessException {
                                                                                                    // Step 1: Create a mock of the TimeSeries class to intercept method calls
                                                                                                    TimeSeries original = mock(TimeSeries.class);
                                                                                                    List<Object> mockData = new ArrayList<>();
                                                                                                    mockData.add("SampleData");
                                                                                            
                                                                                                    // Use reflection to mock the private `data` field in the original TimeSeries object
                                                                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                                    dataField.setAccessible(true);
                                                                                                    dataField.set(original, mockData);
                                                                                            
                                                                                                    // Allow real method invocation for the clone method
                                                                                                    when(original.clone()).thenCallRealMethod();
                                                                                            
                                                                                                    // Step 2: Call the clone method
                                                                                                    TimeSeries cloned = (TimeSeries) original.clone();
                                                                                            
                                                                                                    // Step 3: Validate that the data list is deeply cloned
                                                                                                    Field clonedDataField = TimeSeries.class.getDeclaredField("data");
                                                                                                    clonedDataField.setAccessible(true);
                                                                                                    List<Object> clonedData = (List<Object>) clonedDataField.get(cloned);
                                                                                            
                                                                                                    assertNotSame("Data list should be deeply cloned", mockData, clonedData);
                                                                                                    assertEquals("Cloned data list should have the same content", mockData, clonedData);
                                                                                                }

    @Test
                                                                                        public void testCloneMethod() throws CloneNotSupportedException {
                                                                                            // Step 1: Create an instance of TimeSeries
                                                                                            TimeSeries original = new TimeSeries("Test Series", "Domain", "Range", Day.class);
                                                                                    
                                                                                            // Step 2: Add some data to the TimeSeries
                                                                                            original.add(new Day(1, 1, 2020), 100.0);
                                                                                            original.add(new Day(2, 1, 2020), 200.0);
                                                                                    
                                                                                            // Step 3: Clone the TimeSeries
                                                                                            TimeSeries cloned = (TimeSeries) original.clone();
                                                                                    
                                                                                            // Step 4: Verify that the clone is not null (to catch the mutant)
                                                                                            assertNotNull("The clone should not be null", cloned);
                                                                                    
                                                                                            // Step 5: Verify that the cloned object is a different instance
                                                                                            assertNotSame("The clone should be a different instance", original, cloned);
                                                                                    
                                                                                            // Step 6: Verify that the data in the clone is the same as the original
                                                                                            assertEquals("The cloned data should be equal to the original data", original.getItems(), cloned.getItems());
                                                                                    
                                                                                            // Step 7: Verify that modifying the original does not affect the clone
                                                                                            original.add(new Day(3, 1, 2020), 300.0);
                                                                                            assertNotEquals("The cloned data should not change when the original is modified", original.getItems(), cloned.getItems());
                                                                                    
                                                                                            // Step 8: Verify that modifying the clone does not affect the original
                                                                                            cloned.add(new Day(4, 1, 2020), 400.0);
                                                                                            assertNotEquals("The original data should not change when the clone is modified", original.getItems(), cloned.getItems());
                                                                                        }

    @Test
                                                                                    public void testDeleteStartEnd_MutantDetection() {
                                                                                        // Step 1: Create a TimeSeries object
                                                                                        TimeSeries timeSeries = new TimeSeries("Test Series", Day.class);
                                                                                
                                                                                        // Step 2: Add some data to the time series
                                                                                        RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                                                                                        RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                                                                                        RegularTimePeriod period3 = mock(RegularTimePeriod.class);
                                                                                
                                                                                        timeSeries.add(period1, 10.0);
                                                                                        timeSeries.add(period2, 20.0);
                                                                                        timeSeries.add(period3, 30.0);
                                                                                
                                                                                        // Step 3: Validate initial state
                                                                                        assertEquals(3, timeSeries.getItemCount());
                                                                                
                                                                                        // Step 4: Test the delete method with valid range (start < end)
                                                                                        timeSeries.delete(0, 1); // Deletes period1 and period2
                                                                                        assertEquals(1, timeSeries.getItemCount());
                                                                                        assertEquals(period3, timeSeries.getTimePeriod(0));
                                                                                
                                                                                        // Step 5: Test the delete method with invalid range (start > end)
                                                                                        try {
                                                                                            timeSeries.delete(2, 1); // This should not delete anything
                                                                                            fail("Expected IllegalArgumentException for start > end");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            // Expected behavior
                                                                                        }
                                                                                
                                                                                        // Step 6: Test the delete method with start == end
                                                                                        timeSeries.delete(0, 0); // Deletes period3
                                                                                        assertEquals(0, timeSeries.getItemCount());
                                                                                
                                                                                        // Step 7: Test the mutant condition (end > start instead of end < start)
                                                                                        // If the mutant survives, the following test will fail
                                                                                        try {
                                                                                            timeSeries.delete(1, 2); // start > end should throw an exception
                                                                                            fail("Mutant detected: Expected IllegalArgumentException for start > end");
                                                                                        } catch (IllegalArgumentException e) {
                                                                                            // Expected behavior
                                                                                        }
                                                                                    }

    @Test
                                                                                public void testDeleteThrowsExceptionWhenEndLessThanStart() {
                                                                                    // Create an instance of TimeSeries
                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                            
                                                                                    int start = 5;
                                                                                    int end = 3; // end is less than start, should throw IllegalArgumentException
                                                                            
                                                                                    try {
                                                                                        timeSeries.delete(start, end);
                                                                                        fail("Expected IllegalArgumentException to be thrown");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Test passes if IllegalArgumentException is thrown
                                                                                    }
                                                                                }

    @Test
                                                                            public void testDeleteValidRange() {
                                                                                // Initialize the TimeSeries object with a name
                                                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                            
                                                                                // Populate the TimeSeries with sample data
                                                                                try {
                                                                                    // Use reflection to access the private 'data' field in the TimeSeries class
                                                                                    java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                    dataField.setAccessible(true);
                                                                            
                                                                                    // Create a list of sample data items
                                                                                    List<TimeSeriesDataItem> sampleData = new ArrayList<>();
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 0.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 10.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 20.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(4, 1, 2023), 30.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(5, 1, 2023), 40.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(6, 1, 2023), 50.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(7, 1, 2023), 60.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(8, 1, 2023), 70.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(9, 1, 2023), 80.0));
                                                                                    sampleData.add(new TimeSeriesDataItem(new Day(10, 1, 2023), 90.0));
                                                                            
                                                                                    // Set the sample data into the TimeSeries object
                                                                                    dataField.set(timeSeries, sampleData);
                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                    throw new RuntimeException("Failed to initialize TimeSeries data", e);
                                                                                }
                                                                            
                                                                                // Test normal behavior when start <= end
                                                                                int start = 2;
                                                                                int end = 5;
                                                                            
                                                                                // Ensure the initial size of the data list
                                                                                assertEquals(10, timeSeries.getItemCount());
                                                                            
                                                                                // Perform the delete operation
                                                                                timeSeries.delete(start, end);
                                                                            
                                                                                // Verify that the correct number of items have been removed
                                                                                assertEquals(6, timeSeries.getItemCount());
                                                                            
                                                                                // Verify the remaining items in the list
                                                                                assertEquals(0.0, timeSeries.getDataItem(0).getValue());
                                                                                assertEquals(10.0, timeSeries.getDataItem(1).getValue());
                                                                                assertEquals(60.0, timeSeries.getDataItem(2).getValue());
                                                                                assertEquals(70.0, timeSeries.getDataItem(3).getValue());
                                                                                assertEquals(80.0, timeSeries.getDataItem(4).getValue());
                                                                                assertEquals(90.0, timeSeries.getDataItem(5).getValue());
                                                                            }

    @Test
                                                                                public void testDeleteBoundaryCondition() throws Exception {
                                                                                    // Create a TimeSeries object with some initial data
                                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                                    
                                                                                    // Add data to the time series
                                                                                    for (int i = 0; i < 10; i++) {
                                                                                        timeSeries.add(new Day(i + 1, 1, 2020), i * 10.0);
                                                                                    }
                                                                            
                                                                                    // Test the boundary condition where start == end
                                                                                    int start = 4;
                                                                                    int end = 4;
                                                                            
                                                                                    // Ensure the initial size of the data list
                                                                                    assertEquals(10, timeSeries.getItemCount());
                                                                            
                                                                                    // Perform the delete operation
                                                                                    timeSeries.delete(start, end);
                                                                            
                                                                                    // Verify that only one item has been removed
                                                                                    assertEquals(9, timeSeries.getItemCount());
                                                                            
                                                                                    // Access the private data list using reflection
                                                                                    Field dataField = TimeSeries.class.getDeclaredField("data");
                                                                                    dataField.setAccessible(true);
                                                                                    List<TimeSeriesDataItem> data = (List<TimeSeriesDataItem>) dataField.get(timeSeries);
                                                                            
                                                                                    // Verify the remaining items in the list
                                                                                    assertEquals(0.0, data.get(0).getValue());
                                                                                    assertEquals(10.0, data.get(1).getValue());
                                                                                    assertEquals(20.0, data.get(2).getValue());
                                                                                    assertEquals(30.0, data.get(3).getValue());
                                                                                    assertEquals(50.0, data.get(4).getValue());
                                                                                    assertEquals(60.0, data.get(5).getValue());
                                                                                    assertEquals(70.0, data.get(6).getValue());
                                                                                    assertEquals(80.0, data.get(7).getValue());
                                                                                    assertEquals(90.0, data.get(8).getValue());
                                                                                }

    @Test
                                                                        public void testDeleteWithInvalidRange() {
                                                                            // Arrange
                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                            int start = 5;
                                                                            int end = 5; // This should be valid in the original method but invalid in the mutant
                                                                    
                                                                            // Act & Assert
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            thrown.expectMessage("Requires start <= end.");
                                                                    
                                                                            // This should throw an exception in the original method, but not in the mutant
                                                                            timeSeries.delete(start, end);
                                                                        }

    @Test
                                                                    public void testDeleteWithValidRange() {
                                                                        // Arrange
                                                                        Comparable name = "Test Series";
                                                                        TimeSeries timeSeries = new TimeSeries(name);
                                                                        
                                                                        // Add some sample data to the TimeSeries
                                                                        timeSeries.add(new org.jfree.data.time.Day(1, 1, 2023), 10.0);
                                                                        timeSeries.add(new org.jfree.data.time.Day(2, 1, 2023), 20.0);
                                                                        timeSeries.add(new org.jfree.data.time.Day(3, 1, 2023), 30.0);
                                                                        timeSeries.add(new org.jfree.data.time.Day(4, 1, 2023), 40.0);
                                                                        timeSeries.add(new org.jfree.data.time.Day(5, 1, 2023), 50.0);
                                                                    
                                                                        int start = 0; // Start index
                                                                        int end = 4;   // End index
                                                                    
                                                                        // Act
                                                                        try {
                                                                            timeSeries.delete(start, end);
                                                                        } catch (IllegalArgumentException e) {
                                                                            fail("Exception should not be thrown for valid range");
                                                                        }
                                                                    
                                                                        // Assert
                                                                        // Verify that the items in the specified range were deleted
                                                                        assertEquals("Item count should be 1 after deletion", 1, timeSeries.getItemCount());
                                                                        assertEquals("Remaining item should be the last one", 50.0, timeSeries.getValue(0).doubleValue(), 0.001);
                                                                    }

    @Test
                                                                        public void testDeleteWithEqualStartAndEnd() {
                                                                            // Create a TimeSeries object
                                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                                    
                                                                            // We expect no exception to be thrown in the original method
                                                                            // However, the mutant will throw an exception for start == end
                                                                    
                                                                            // Set start and end to the same value
                                                                            int start = 1;
                                                                            int end = 1;
                                                                    
                                                                            // No exception should be thrown in the original method
                                                                            timeSeries.delete(start, end);
                                                                    
                                                                            // To catch the mutant, we expect an exception
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            thrown.expectMessage("Requires start < end.");
                                                                    
                                                                            // Execute the method again to trigger the mutant's behavior
                                                                            timeSeries.delete(start, end);
                                                                        }

    @Test
                                                                    public void testDelete_ThrowsIllegalArgumentException() {
                                                                        // Arrange
                                                                        TimeSeries timeSeries = new TimeSeries("Test Series", String.class);
                                                                        RegularTimePeriod mockPeriod = mock(RegularTimePeriod.class);
                                                                
                                                                        // Mock the getIndex method to return -1 to simulate an invalid period
                                                                        TimeSeries spyTimeSeries = spy(timeSeries);
                                                                        doReturn(-1).when(spyTimeSeries).getIndex(mockPeriod);
                                                                
                                                                        // Act & Assert
                                                                        try {
                                                                            spyTimeSeries.delete(mockPeriod);
                                                                            fail("Expected IllegalArgumentException to be thrown");
                                                                        } catch (IllegalArgumentException e) {
                                                                            // Verify the exception message
                                                                            assertEquals("Requires start <= end.", e.getMessage());
                                                                        } catch (RuntimeException e) {
                                                                            fail("Mutant detected: Unexpected RuntimeException was thrown instead of IllegalArgumentException.");
                                                                        }
                                                                    }

    @Test
                                                                public void testDeleteWithInvalidRangeThrowsIllegalArgumentException() {
                                                                    // Test case to capture the mutant where IllegalArgumentException was mutated to RuntimeException
                                                                    // This test expects an IllegalArgumentException to be thrown when end < start
                                                            
                                                                    // Define the variables
                                                                    int start = 5;
                                                                    int end = 3; // Invalid range where end < start
                                                            
                                                                    // Create a TimeSeries object to test
                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            
                                                                    try {
                                                                        // This should throw an IllegalArgumentException according to the original method
                                                                        timeSeries.delete(start, end);
                                                                        fail("Expected IllegalArgumentException to be thrown, but it was not.");
                                                                    } catch (IllegalArgumentException e) {
                                                                        // Test passes if IllegalArgumentException is thrown
                                                                    }
                                                                }

    @Test
                                                            public void testDeleteValidRange1() {
                                                                // Test case for a valid range to ensure normal functionality
                                                            
                                                                // Create a TimeSeries object
                                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            
                                                                // Add data items to the TimeSeries
                                                                timeSeries.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
                                                                timeSeries.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0));
                                                                timeSeries.add(new TimeSeriesDataItem(new Day(3, 1, 2023), 30.0));
                                                            
                                                                // Define the range to delete
                                                                int start = 0;
                                                                int end = 1; // Valid range
                                                            
                                                                // Delete the specified range
                                                                timeSeries.delete(start, end);
                                                            
                                                                // After deletion, only one item should remain
                                                                assertEquals(1, timeSeries.getItemCount());
                                                                assertEquals(30.0, timeSeries.getValue(0).doubleValue(), 0.001);
                                                            }

    @Test
                                                                public void testDeleteBoundaryCondition1() {
                                                                    // Create a TimeSeries object
                                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            
                                                                    // Add data items to the time series
                                                                    timeSeries.add(new TimeSeriesDataItem(new Day(1, 1, 2023), 10.0));
                                                                    timeSeries.add(new TimeSeriesDataItem(new Day(2, 1, 2023), 20.0));
                                                            
                                                                    int start = 1;
                                                                    int end = 1; // Boundary condition where start == end
                                                            
                                                                    // Delete the item at the specified index
                                                                    timeSeries.delete(start, end);
                                                            
                                                                    // After deletion, only the first item should remain
                                                                    assertEquals(1, timeSeries.getItemCount());
                                                                    assertEquals(10.0, timeSeries.getValue(0).doubleValue(), 0.001);
                                                                }

    @Test
                                                        public void testDeleteMethodCapturesMutant() throws Exception {
                                                            // Arrange
                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                            List<TimeSeriesDataItem> mockData = new ArrayList<>();
                                                            TimeSeriesDataItem item1 = mock(TimeSeriesDataItem.class);
                                                            TimeSeriesDataItem item2 = mock(TimeSeriesDataItem.class);
                                                            mockData.add(item1);
                                                            mockData.add(item2);
                                                    
                                                            RegularTimePeriod mockPeriod = mock(RegularTimePeriod.class);
                                                            
                                                            // Mock the behavior of getIndex to return 0 for the first item
                                                            TimeSeries spyTimeSeries = spy(timeSeries);
                                                            doReturn(0).when(spyTimeSeries).getIndex(mockPeriod);
                                                    
                                                            // Inject the mock data into the timeSeries object using reflection
                                                            Field dataField = TimeSeries.class.getDeclaredField("data");
                                                            dataField.setAccessible(true);
                                                            dataField.set(spyTimeSeries, mockData);
                                                    
                                                            // Act
                                                            spyTimeSeries.delete(mockPeriod);
                                                    
                                                            // Assert
                                                            // Check that the first item has been removed
                                                            assertEquals(1, mockData.size());
                                                            assertSame(item2, mockData.get(0));
                                                    
                                                            // Verify that fireSeriesChanged was called
                                                            // Assuming fireSeriesChanged is a method that should be called
                                                            // after a successful deletion. If it's not, this line should be removed.
                                                            verify(spyTimeSeries).fireSeriesChanged();
                                                        }

    @Test
                                                        public void testDeleteThrowsExceptionForInvalidRange() {
                                                            // Initialize a TimeSeries object
                                                            TimeSeries timeSeries = new TimeSeries("Test Series");
                                                    
                                                            // Define the invalid range
                                                            int start = 3;
                                                            int end = 1;
                                                    
                                                            // Test that an exception is thrown for an invalid range
                                                            try {
                                                                timeSeries.delete(start, end);
                                                                fail("Expected an IllegalArgumentException to be thrown");
                                                            } catch (IllegalArgumentException e) {
                                                                // Exception was thrown as expected, test passes
                                                            }
                                                        }

    @Test
                                                public void testDeleteCapturesMutant() {
                                                    // Create a TimeSeries object
                                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                                
                                                    // Initialize the timeSeries with some data
                                                    timeSeries.add(new Day(1, 1, 2020), 0.0);
                                                    timeSeries.add(new Day(2, 1, 2020), 1.0);
                                                    timeSeries.add(new Day(3, 1, 2020), 2.0);
                                                    timeSeries.add(new Day(4, 1, 2020), 3.0);
                                                    timeSeries.add(new Day(5, 1, 2020), 4.0);
                                                
                                                    // Original method should remove elements from index 1 to 3 inclusive
                                                    int start = 1;
                                                    int end = 3;
                                                
                                                    // Expected data after deletion: ["Item 0", "Item 4"]
                                                    List<Double> expectedData = new ArrayList<>();
                                                    expectedData.add(0.0);
                                                    expectedData.add(4.0);
                                                
                                                    // Call the delete method
                                                    timeSeries.delete(start, end);
                                                
                                                    // Assert that the data list matches the expected result
                                                    List<Double> actualData = new ArrayList<>();
                                                    for (int i = 0; i < timeSeries.getItemCount(); i++) {
                                                        actualData.add(timeSeries.getValue(i).doubleValue());
                                                    }
                                                
                                                    assertEquals("Data list should match expected after deletion", expectedData, actualData);
                                                }

    @Test
                                            public void testDeleteRemovesCorrectElement() throws Exception {
                                                // Define the mock period
                                                RegularTimePeriod mockPeriod = mock(RegularTimePeriod.class);
                                        
                                                // Create a TimeSeries object with some initial data
                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                                timeSeries.add(mock(RegularTimePeriod.class), 1.0);
                                                timeSeries.add(mockPeriod, 2.0);
                                                timeSeries.add(mock(RegularTimePeriod.class), 3.0);
                                        
                                                // Spy on the TimeSeries object
                                                TimeSeries spySeries = spy(timeSeries);
                                                doReturn(1).when(spySeries).getIndex(mockPeriod);
                                        
                                                // Call the delete method
                                                spySeries.delete(mockPeriod);
                                        
                                                // Use reflection to access the protected 'data' field
                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                dataField.setAccessible(true);
                                                List<?> data = (List<?>) dataField.get(spySeries);
                                        
                                                // Verify that the element at index 1 is removed
                                                assertEquals(2, data.size());
                                                assertNotNull(data.get(0)); // Element at index 0 should still exist
                                                assertNotNull(data.get(1)); // Element at index 2 should now be at index 1
                                        
                                                // Verify that the element originally at index 1 is removed
                                                verify(data, times(1)).remove(1);
                                            }

    @Test
                                            public void testDeleteMethodCapturesMutant1() throws Exception {
                                                // Create an instance of TimeSeries
                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                        
                                                // Use reflection to access the private 'data' field
                                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                                dataField.setAccessible(true);
                                        
                                                // Initialize the data list with initial values
                                                List<String> initialData = new ArrayList<>();
                                                initialData.add("Item 0");
                                                initialData.add("Item 1");
                                                initialData.add("Item 2");
                                                initialData.add("Item 3");
                                                initialData.add("Item 4");
                                        
                                                // Set the initial data to the timeSeries object
                                                dataField.set(timeSeries, initialData);
                                        
                                                // Define the start and end indices for deletion
                                                int start = 1;
                                                int end = 3;
                                        
                                                // Expected data after deletion: ["Item 0", "Item 4"]
                                                List<String> expectedData = new ArrayList<>();
                                                expectedData.add("Item 0");
                                                expectedData.add("Item 4");
                                        
                                                // Call the delete method
                                                timeSeries.delete(start, end);
                                        
                                                // Retrieve the modified data list from the timeSeries object
                                                List<String> actualData = (List<String>) dataField.get(timeSeries);
                                        
                                                // Assert that the data list matches the expected data
                                                assertEquals("The data list should match the expected data after deletion.", expectedData, actualData);
                                            }

    @Test
                                            public void testDeleteMethodThrowsExceptionForInvalidRange() {
                                                // Initialize the TimeSeries object
                                                TimeSeries timeSeries = new TimeSeries("Test Series");
                                        
                                                // Define an invalid range where end < start
                                                int start = 3;
                                                int end = 1;
                                        
                                                // Set up the expectation for an IllegalArgumentException
                                                thrown.expect(IllegalArgumentException.class);
                                        
                                                // Call the delete method, expecting an IllegalArgumentException
                                                timeSeries.delete(start, end);
                                            }

    @Test
                                    public void testDeleteMethodDetectsMutant() throws Exception {
                                        // Step 1: Mock the RegularTimePeriod class (since its behavior is not provided).
                                        RegularTimePeriod mockPeriod = mock(RegularTimePeriod.class);
                                
                                        // Step 2: Create an instance of TimeSeries with a mock Comparable name.
                                        TimeSeries timeSeries = new TimeSeries("Test Series");
                                
                                        // Step 3: Add a mock data item to the TimeSeries using reflection to access the protected 'data' field.
                                        TimeSeriesDataItem mockDataItem = mock(TimeSeriesDataItem.class);
                                        when(mockPeriod.equals(any())).thenReturn(true); // Mock equality check.
                                
                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                        dataField.setAccessible(true);
                                        @SuppressWarnings("unchecked")
                                        java.util.List<TimeSeriesDataItem> dataList = (java.util.List<TimeSeriesDataItem>) dataField.get(timeSeries);
                                        dataList.add(mockDataItem);
                                
                                        // Step 4: Mock the getIndex method to return the index of the mockPeriod.
                                        TimeSeries spyTimeSeries = spy(timeSeries);
                                        doReturn(0).when(spyTimeSeries).getIndex(mockPeriod);
                                
                                        // Step 5: Add a listener to detect if fireSeriesChanged() is called.
                                        // We'll use a flag to confirm the method is invoked.
                                        final boolean[] seriesChangedCalled = {false};
                                        spyTimeSeries.addChangeListener(event -> seriesChangedCalled[0] = true);
                                
                                        // Step 6: Call the delete method with the mockPeriod.
                                        spyTimeSeries.delete(mockPeriod);
                                
                                        // Step 7: Verify that the item was removed from the data list.
                                        assertEquals("The data list should be empty after deletion.", 0, dataList.size());
                                
                                        // Step 8: Verify that fireSeriesChanged() was called.
                                        assertTrue("fireSeriesChanged() should be called after deleting an item.", seriesChangedCalled[0]);
                                    }

    @Test
                                public void testDeleteMethodDetectsMutant1() {
                                    // Arrange
                                    int start = 0;
                                    int end = 2;
                                
                                    // Mocking dependencies
                                    List<Integer> mockData = mock(List.class);
                                    TimeSeries timeSeries = new TimeSeries("Test Series");
                                    
                                    // Using reflection to set the private 'data' field in TimeSeries
                                    try {
                                        Field dataField = TimeSeries.class.getDeclaredField("data");
                                        dataField.setAccessible(true);
                                        dataField.set(timeSeries, mockData);
                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                        fail("Failed to set up mock data using reflection: " + e.getMessage());
                                    }
                                
                                    when(mockData.size()).thenReturn(5);
                                
                                    // Act
                                    timeSeries.delete(start, end);
                                
                                    // Assert
                                    // Verify that remove was called the correct number of times
                                    verify(mockData, times(end - start + 1)).remove(anyInt());
                                
                                    // Verify that fireSeriesChanged was called indirectly
                                    // Using reflection to check if a state change occurred
                                    try {
                                        Field versionField = TimeSeries.class.getDeclaredField("version");
                                        versionField.setAccessible(true);
                                        int version = (int) versionField.get(timeSeries);
                                        assertTrue("Expected version to be incremented", version > 0);
                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                        fail("Failed to verify state change using reflection: " + e.getMessage());
                                    }
                                }

    @Test
                        public void testDeleteMethodDetectsMutant2() throws Exception {
                            // Step 1: Mock the TimeSeries class
                            TimeSeries timeSeries = spy(new TimeSeries("Test Series", RegularTimePeriod.class));
                        
                            // Step 2: Prepare test data
                            RegularTimePeriod period1 = mock(RegularTimePeriod.class);
                            RegularTimePeriod period2 = mock(RegularTimePeriod.class);
                            TimeSeriesDataItem dataItem1 = mock(TimeSeriesDataItem.class);
                            TimeSeriesDataItem dataItem2 = mock(TimeSeriesDataItem.class);
                        
                            // Mock the getIndex method to return the correct index for the period
                            doReturn(0).when(timeSeries).getIndex(period1);
                            doReturn(1).when(timeSeries).getIndex(period2);
                        
                            // Use reflection to access the protected 'data' field
                            Field dataField = TimeSeries.class.getDeclaredField("data");
                            dataField.setAccessible(true);
                        
                            // Add mock data to the timeSeries
                            @SuppressWarnings("unchecked")
                            List<TimeSeriesDataItem> data = (List<TimeSeriesDataItem>) dataField.get(timeSeries);
                            data.add(dataItem1);
                            data.add(dataItem2);
                        
                            // Step 3: Call the delete method
                            timeSeries.delete(period1);
                        
                            // Step 4: Verify the behavior of the delete method
                            // Assert that the data item was removed
                            assertEquals(1, data.size());
                            assertFalse(data.contains(dataItem1));
                        
                            // Verify that fireSeriesChanged() was called
                            verify(timeSeries, times(1)).fireSeriesChanged();
                        
                            // Step 5: Test edge case - deleting a non-existent period
                            RegularTimePeriod nonExistentPeriod = mock(RegularTimePeriod.class);
                            doReturn(-1).when(timeSeries).getIndex(nonExistentPeriod);
                        
                            // Call the delete method with a non-existent period
                            timeSeries.delete(nonExistentPeriod);
                        
                            // Assert that the data size remains unchanged
                            assertEquals(1, data.size());
                        
                            // Verify that fireSeriesChanged() was not called for a non-existent period
                            verify(timeSeries, times(1)).fireSeriesChanged(); // Still only called once
                        }

    @Test
                            public void testDeleteDetectsMutant() throws Exception {
                                // Step 1: Mock dependencies and set up the test object
                                TimeSeries timeSeries = spy(new TimeSeries("Test Series", ArrayList.class));
                                List<Object> mockData = spy(new ArrayList<>());
                        
                                // Use reflection to set the protected 'data' field
                                Field dataField = TimeSeries.class.getDeclaredField("data");
                                dataField.setAccessible(true);
                                dataField.set(timeSeries, mockData);
                        
                                // Step 2: Populate the data list with dummy values
                                mockData.add("Item1");
                                mockData.add("Item2");
                                mockData.add("Item3");
                                mockData.add("Item4");
                        
                                // Step 3: Define the start and end indices for deletion
                                int start = 1; // Index of "Item2"
                                int end = 2;   // Index of "Item3"
                        
                                // Step 4: Perform the delete operation
                                timeSeries.delete(start, end);
                        
                                // Step 5: Verify that the correct items were removed
                                assertEquals(2, mockData.size());
                                assertEquals("Item1", mockData.get(0));
                                assertEquals("Item4", mockData.get(1));
                        
                                // Step 6: Verify that fireSeriesChanged() was called exactly once
                                verify(timeSeries, times(1)).fireSeriesChanged();
                            }

    @Test
                        public void testDeleteMethodDetectMutant() {
                            // Step 1: Setup the TimeSeries object
                            TimeSeries timeSeries = new TimeSeries("Test Series", Day.class);
                    
                            // Mocking the RegularTimePeriod class
                            RegularTimePeriod mockPeriod1 = mock(RegularTimePeriod.class);
                            RegularTimePeriod mockPeriod2 = mock(RegularTimePeriod.class);
                    
                            // Mocking TimeSeriesDataItem
                            TimeSeriesDataItem mockDataItem1 = mock(TimeSeriesDataItem.class);
                            TimeSeriesDataItem mockDataItem2 = mock(TimeSeriesDataItem.class);
                    
                            // Step 2: Add items to the TimeSeries object
                            timeSeries.add(mockPeriod1, 10.0);
                            timeSeries.add(mockPeriod2, 20.0);
                    
                            // Verify the initial state of the data list
                            assertEquals(2, timeSeries.getItemCount());
                            assertEquals(10.0, timeSeries.getValue(mockPeriod1).doubleValue(), 0.001);
                            assertEquals(20.0, timeSeries.getValue(mockPeriod2).doubleValue(), 0.001);
                    
                            // Step 3: Mock the behavior of getIndex to simulate the mutation
                            TimeSeries spyTimeSeries = spy(timeSeries);
                            doReturn(0).when(spyTimeSeries).getIndex(mockPeriod1); // Mocking index retrieval for mockPeriod1
                    
                            // Step 4: Call the delete method
                            spyTimeSeries.delete(mockPeriod1);
                    
                            // Step 5: Assertions to verify the mutant behavior
                            // Check that the item was removed from the data list
                            assertEquals(1, spyTimeSeries.getItemCount());
                            assertNull(spyTimeSeries.getValue(mockPeriod1)); // Ensure mockPeriod1 is removed
                            assertEquals(20.0, spyTimeSeries.getValue(mockPeriod2).doubleValue(), 0.001); // Ensure mockPeriod2 remains
                    
                            // Step 6: Verify fireSeriesChanged was called
                            verify(spyTimeSeries).fireSeriesChanged();
                    
                            // Step 7: Additional edge case - Attempt to delete a period not in the list
                            doReturn(-1).when(spyTimeSeries).getIndex(mock(RegularTimePeriod.class)); // Simulate period not found
                            spyTimeSeries.delete(mock(RegularTimePeriod.class));
                    
                            // Ensure no changes were made to the data list
                            assertEquals(1, spyTimeSeries.getItemCount());
                            assertEquals(20.0, spyTimeSeries.getValue(mockPeriod2).doubleValue(), 0.001);
                        }

    @Test
                    public void testDeleteWithInvalidRange1() {
                        // Create a TimeSeries instance
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                
                        try {
                            // This should throw an IllegalArgumentException
                            timeSeries.delete(5, 3);
                            fail("Expected IllegalArgumentException to be thrown");
                        } catch (IllegalArgumentException e) {
                            // Test passes if IllegalArgumentException is thrown
                        }
                    }

    @Test
                    public void testDeleteWithValidRange1() {
                        // Create a TimeSeries object with a name
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                
                        // Add some data to the timeSeries for testing
                        timeSeries.add(new org.jfree.data.time.Day(1, 1, 2023), 1.0);
                        timeSeries.add(new org.jfree.data.time.Day(2, 1, 2023), 2.0);
                        timeSeries.add(new org.jfree.data.time.Day(3, 1, 2023), 3.0);
                        timeSeries.add(new org.jfree.data.time.Day(4, 1, 2023), 4.0);
                        timeSeries.add(new org.jfree.data.time.Day(5, 1, 2023), 5.0);
                
                        // Initial size of the data list
                        int initialSize = timeSeries.getItemCount();
                
                        // Delete elements from index 2 to 4 (inclusive)
                        timeSeries.delete(2, 4);
                
                        // Expected size after deletion
                        int expectedSize = initialSize - 3;
                
                        // Check the size of the list after deletion
                        assertEquals("The size of the list should be reduced by 3", expectedSize, timeSeries.getItemCount());
                
                        // Check that the correct elements were removed
                        assertNull("Element at index 2 should be removed", timeSeries.getDataItem(2));
                        assertNull("Element at index 3 should be removed", timeSeries.getDataItem(3));
                        assertNull("Element at index 4 should be removed", timeSeries.getDataItem(4));
                    }

    @Test
                    public void testDeleteWithBoundaryCondition() {
                        // Create a TimeSeries object with a name
                        TimeSeries timeSeries = new TimeSeries("Test Series");
                
                        // Add some data to the timeSeries to ensure it has elements to delete
                        for (int i = 0; i < 10; i++) {
                            timeSeries.add(new org.jfree.data.time.Day(i + 1, 1, 2023), i);
                        }
                
                        // Initial size of the data list
                        int initialSize = timeSeries.getItemCount();
                
                        // Delete elements from index 0 to 9 (inclusive)
                        timeSeries.delete(0, 9);
                
                        // Expected size after deletion
                        int expectedSize = initialSize - 10;
                
                        // Check the size of the list after deletion
                        assertEquals("All elements should be removed", expectedSize, timeSeries.getItemCount());
                    }

    @Test
                public void testFireSeriesChangedCalled() {
                    // Assuming fireSeriesChanged() has some observable effect or can be mocked
                    // Here we would verify that fireSeriesChanged() is called
                    // This requires additional setup if fireSeriesChanged() has side effects
                }

    @Test
            public void testDeleteMethodCapturesMutant2() throws Exception {
                // Create a mock period
                RegularTimePeriod mockPeriod = mock(RegularTimePeriod.class);
        
                // Create a TimeSeries instance to be spied on
                TimeSeries timeSeries = new TimeSeries("Test Series");
        
                // Spy the TimeSeries object
                TimeSeries spyTimeSeries = spy(timeSeries);
        
                // Mock the getIndex method to return a valid index
                doReturn(0).when(spyTimeSeries).getIndex(mockPeriod);
        
                // Add a mock data item to the data list using reflection
                TimeSeriesDataItem mockDataItem = mock(TimeSeriesDataItem.class);
        
                Field dataField = TimeSeries.class.getDeclaredField("data");
                dataField.setAccessible(true);
                ((java.util.List) dataField.get(spyTimeSeries)).add(mockDataItem);
        
                // Call the delete method
                spyTimeSeries.delete(mockPeriod);
        
                // Verify that the data item was removed
                assertFalse(((java.util.List) dataField.get(spyTimeSeries)).contains(mockDataItem));
        
                // Verify that fireSeriesChanged was called, which indicates the block was executed
                verify(spyTimeSeries, times(1)).fireSeriesChanged();
            }

    @Test
        public void testDeleteMethodNoChangeWhenIndexNegative() throws Exception {
            // Create a mock RegularTimePeriod object
            RegularTimePeriod mockPeriod = mock(RegularTimePeriod.class);
        
            // Create a TimeSeries object to be spied on
            TimeSeries timeSeries = new TimeSeries("Test Series");
        
            // Spy on the TimeSeries object
            TimeSeries spyTimeSeries = spy(timeSeries);
        
            // Mock the getIndex method to return a negative index
            doReturn(-1).when(spyTimeSeries).getIndex(mockPeriod);
        
            // Use reflection to access the protected 'data' field
            java.lang.reflect.Field dataField = TimeSeries.class.getDeclaredField("data");
            dataField.setAccessible(true);
        
            // Add a mock data item to the 'data' list
            TimeSeriesDataItem mockDataItem = mock(TimeSeriesDataItem.class);
            @SuppressWarnings("unchecked")
            List<TimeSeriesDataItem> dataList = (List<TimeSeriesDataItem>) dataField.get(spyTimeSeries);
            dataList.add(mockDataItem);
        
            // Call the delete method
            spyTimeSeries.delete(mockPeriod);
        
            // Verify that the data item was not removed
            assertTrue(dataList.contains(mockDataItem));
        
            // Verify that fireSeriesChanged was not called
            verify(spyTimeSeries, never()).fireSeriesChanged();
        }

    @Test
            public void testDeleteThrowsExceptionWhenEndLessThanStart1() {
                // Set up the expected exception
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("Requires start <= end.");
        
                // Create a TimeSeries object
                TimeSeries timeSeries = new TimeSeries("Test Series");
        
                // Call the delete method with incorrect parameters
                timeSeries.delete(3, 2);
            }

    @Test
            public void testDeleteRemovesCorrectElements() throws Exception {
                // Step 1: Create a TimeSeries instance
                TimeSeries timeSeries = new TimeSeries("Test Series");
        
                // Step 2: Use reflection to access the private 'data' field of TimeSeries
                Field dataField = TimeSeries.class.getDeclaredField("data");
                dataField.setAccessible(true);
        
                // Step 3: Populate the 'data' field with initial test data
                List<String> initialData = new ArrayList<>();
                initialData.add("Item 1");
                initialData.add("Item 2");
                initialData.add("Item 3");
                initialData.add("Item 4");
                dataField.set(timeSeries, initialData);
        
                // Step 4: Call the delete method to remove elements at indices 1 and 2
                timeSeries.delete(1, 2);
        
                // Step 5: Define the expected data after deletion
                List<String> expectedData = new ArrayList<>();
                expectedData.add("Item 1");
                expectedData.add("Item 4");
        
                // Step 6: Retrieve the modified 'data' field using reflection
                @SuppressWarnings("unchecked")
                List<String> actualData = (List<String>) dataField.get(timeSeries);
        
                // Step 7: Assert that the actual data matches the expected data
                assertEquals(expectedData, actualData);
            }

    @Test
            public void testDeleteRemovesAllElements() {
                // Create an instance of TimeSeries
                TimeSeries timeSeries = new TimeSeries("Test Series");
        
                // Add some data to the timeSeries to ensure it is not empty before deletion
                timeSeries.add(new org.jfree.data.time.Day(1, 1, 2020), 1.0);
                timeSeries.add(new org.jfree.data.time.Day(2, 1, 2020), 2.0);
                timeSeries.add(new org.jfree.data.time.Day(3, 1, 2020), 3.0);
        
                // Call the delete method
                timeSeries.delete(0, 2);
        
                // Assert that the timeSeries is empty
                assertTrue(timeSeries.getItems().isEmpty());
            }

    @Test
            public void testDeleteDoesNotRemoveAnyElements() {
                // Create an instance of TimeSeries
                TimeSeries timeSeries = new TimeSeries("Sample Series");
        
                // Add some data to the time series
                timeSeries.add(new Year(2020), 100.0);
                timeSeries.add(new Year(2021), 200.0);
                timeSeries.add(new Year(2022), 300.0);
        
                try {
                    // Attempt to delete elements from an invalid range
                    timeSeries.delete(2, 1); // This should throw an exception
                    // If no exception is thrown, the test should fail
                    fail("Expected an IllegalArgumentException to be thrown");
                } catch (IllegalArgumentException e) {
                    // Expected exception was thrown, test passes
                }
            }

    @Test
        public void testDeleteRemovesSingleElement() {
            // Create an instance of TimeSeries with a name
            TimeSeries timeSeries = new TimeSeries("Test Series");
    
            // Add some initial data to the timeSeries
            timeSeries.add(new Day(1, 1, 2020), 1.0);
            timeSeries.add(new Day(2, 1, 2020), 2.0);
            timeSeries.add(new Day(3, 1, 2020), 3.0);
            timeSeries.add(new Day(4, 1, 2020), 4.0);
    
            // Delete the element at index 2
            timeSeries.delete(2, 2);
    
            // Create the expected data list
            List<Double> expectedData = new ArrayList<>();
            expectedData.add(1.0);
            expectedData.add(2.0);
            expectedData.add(4.0);
    
            // Retrieve the actual data from the timeSeries
            List<Double> actualData = new ArrayList<>();
            for (int i = 0; i < timeSeries.getItemCount(); i++) {
                actualData.add(timeSeries.getDataItem(i).getValue().doubleValue());
            }
    
            // Assert that the expected data matches the actual data
            assertEquals(expectedData, actualData);
        }


}
