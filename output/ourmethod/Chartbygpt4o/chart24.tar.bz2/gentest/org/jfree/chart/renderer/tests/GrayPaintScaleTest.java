package gentest.org.jfree.chart.renderer.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.renderer.*;
import java.awt.Color;
import java.awt.Paint;
import java.io.Serializable;
import org.jfree.chart.util.PublicCloneable;
 
public class GrayPaintScaleTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                    public void testGetPaintDetectMutant() {
                                                                                                        // Create an instance of GrayPaintScale with specific bounds
                                                                                                        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
                                                                                                
                                                                                                        // Test with a value below the lower bound
                                                                                                        double testValue = -0.5;
                                                                                                        Color expectedColor = new Color(0, 0, 0); // Since value is below lowerBound, v should be lowerBound, resulting in g = 0
                                                                                                        Color actualColor = (Color) scale.getPaint(testValue);
                                                                                                
                                                                                                        // Assert that the color is as expected
                                                                                                        assertEquals("Color should be black when value is below lowerBound", expectedColor, actualColor);
                                                                                                
                                                                                                        // Test with a value above the upper bound
                                                                                                        testValue = 1.5;
                                                                                                        expectedColor = new Color(255, 255, 255); // Since value is above upperBound, v should be upperBound, resulting in g = 255
                                                                                                        actualColor = (Color) scale.getPaint(testValue);
                                                                                                
                                                                                                        // Assert that the color is as expected
                                                                                                        assertEquals("Color should be white when value is above upperBound", expectedColor, actualColor);
                                                                                                
                                                                                                        // Test with a value exactly at the lower bound
                                                                                                        testValue = 0.0;
                                                                                                        expectedColor = new Color(0, 0, 0); // v should be lowerBound, resulting in g = 0
                                                                                                        actualColor = (Color) scale.getPaint(testValue);
                                                                                                
                                                                                                        // Assert that the color is as expected
                                                                                                        assertEquals("Color should be black when value is at lowerBound", expectedColor, actualColor);
                                                                                                
                                                                                                        // Test with a value exactly at the upper bound
                                                                                                        testValue = 1.0;
                                                                                                        expectedColor = new Color(255, 255, 255); // v should be upperBound, resulting in g = 255
                                                                                                        actualColor = (Color) scale.getPaint(testValue);
                                                                                                
                                                                                                        // Assert that the color is as expected
                                                                                                        assertEquals("Color should be white when value is at upperBound", expectedColor, actualColor);
                                                                                                
                                                                                                        // Test with a value between the bounds
                                                                                                        testValue = 0.5;
                                                                                                        expectedColor = new Color(127, 127, 127); // v should be 0.5, resulting in g = 127
                                                                                                        actualColor = (Color) scale.getPaint(testValue);
                                                                                                
                                                                                                        // Assert that the color is as expected
                                                                                                        assertEquals("Color should be gray when value is between lowerBound and upperBound", expectedColor, actualColor);
                                                                                                    }

    @Test
                                                                                                public void testGetPaintDetectsMutant() {
                                                                                                    // Create an instance of GrayPaintScale with specific bounds
                                                                                                    double lowerBound = 0.0;
                                                                                                    double upperBound = 1.0;
                                                                                                    GrayPaintScale scale = new GrayPaintScale(lowerBound, upperBound);
                                                                                            
                                                                                                    // Test case where value is less than lowerBound
                                                                                                    double value = -0.5; // This is less than the lowerBound
                                                                                                    Color expectedColor = new Color(0, 0, 0); // Since v should be clamped to lowerBound, g should be 0
                                                                                            
                                                                                                    // Get the paint color
                                                                                                    Color actualColor = (Color) scale.getPaint(value);
                                                                                            
                                                                                                    // Assert that the color is as expected
                                                                                                    assertEquals("The color should be clamped to lowerBound resulting in Color(0, 0, 0)", expectedColor, actualColor);
                                                                                            
                                                                                                    // Additional test cases can be added here to ensure comprehensive coverage
                                                                                                }

    @Test
                                                                                    public void testGetPaintDetectMutant1() {
                                                                                        // Create an instance of GrayPaintScale with specific bounds
                                                                                        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
                                                                                    
                                                                                        // Test case where value is greater than upperBound
                                                                                        double value = 1.5; // This is greater than the upperBound of 1.0
                                                                                    
                                                                                        // Calculate expected result based on the original method logic
                                                                                        double expectedV = 1.0; // Since value > upperBound, v should be clamped to upperBound
                                                                                        int expectedG = (int) ((expectedV - 0.0) / (1.0 - 0.0) * 255.0);
                                                                                        Color expectedColor = new Color(expectedG, expectedG, expectedG);
                                                                                    
                                                                                        // Get the actual result from the method
                                                                                        Paint actualPaint = scale.getPaint(value);
                                                                                    
                                                                                        // Since actualPaint is of type Paint, we need to cast it to Color
                                                                                        assertTrue("The paint should be an instance of Color", actualPaint instanceof Color);
                                                                                        Color actualColor = (Color) actualPaint;
                                                                                    
                                                                                        // Assert that the actual result matches the expected result
                                                                                        assertEquals("The color should be clamped to upperBound", expectedColor, actualColor);
                                                                                    }

    @Test
                                                                            public void testGetPaintDetectMutant2() {
                                                                                // Arrange: Create an instance of GrayPaintScale with specific bounds
                                                                                double lowerBound = 0.0;
                                                                                double upperBound = 100.0;
                                                                                GrayPaintScale scale = new GrayPaintScale(lowerBound, upperBound);
                                                                            
                                                                                // Test case 1: Value within bounds
                                                                                double valueWithinBounds = 50.0; // Expected behavior: v = 50.0
                                                                                Color expectedColorWithinBounds = new Color(127, 127, 127); // g = 127
                                                                                Color actualColorWithinBounds = (Color) scale.getPaint(valueWithinBounds);
                                                                                assertEquals("Value within bounds failed", expectedColorWithinBounds, actualColorWithinBounds);
                                                                            
                                                                                // Test case 2: Value above upper bound
                                                                                double valueAboveUpperBound = 150.0; // Expected behavior: v = upperBound = 100.0
                                                                                Color expectedColorAboveUpperBound = new Color(255, 255, 255); // g = 255
                                                                                Color actualColorAboveUpperBound = (Color) scale.getPaint(valueAboveUpperBound);
                                                                                assertEquals("Value above upper bound failed", expectedColorAboveUpperBound, actualColorAboveUpperBound);
                                                                            
                                                                                // Test case 3: Value below lower bound
                                                                                double valueBelowLowerBound = -50.0; // Expected behavior: v = lowerBound = 0.0
                                                                                Color expectedColorBelowLowerBound = new Color(0, 0, 0); // g = 0
                                                                                Color actualColorBelowLowerBound = (Color) scale.getPaint(valueBelowLowerBound);
                                                                                assertEquals("Value below lower bound failed", expectedColorBelowLowerBound, actualColorBelowLowerBound);
                                                                            
                                                                                // Test case 4: Edge case - Value exactly at upper bound
                                                                                double valueAtUpperBound = upperBound; // Expected behavior: v = upperBound = 100.0
                                                                                Color expectedColorAtUpperBound = new Color(255, 255, 255); // g = 255
                                                                                Color actualColorAtUpperBound = (Color) scale.getPaint(valueAtUpperBound);
                                                                                assertEquals("Value at upper bound failed", expectedColorAtUpperBound, actualColorAtUpperBound);
                                                                            
                                                                                // Test case 5: Edge case - Value exactly at lower bound
                                                                                double valueAtLowerBound = lowerBound; // Expected behavior: v = lowerBound = 0.0
                                                                                Color expectedColorAtLowerBound = new Color(0, 0, 0); // g = 0
                                                                                Color actualColorAtLowerBound = (Color) scale.getPaint(valueAtLowerBound);
                                                                                assertEquals("Value at lower bound failed", expectedColorAtLowerBound, actualColorAtLowerBound);
                                                                            
                                                                                // Test case 6: Value slightly below upper bound
                                                                                double valueSlightlyBelowUpperBound = upperBound - 0.1; // Expected behavior: v = 99.9
                                                                                int gSlightlyBelowUpperBound = (int) ((valueSlightlyBelowUpperBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                                                Color expectedColorSlightlyBelowUpperBound = new Color(gSlightlyBelowUpperBound, gSlightlyBelowUpperBound, gSlightlyBelowUpperBound);
                                                                                Color actualColorSlightlyBelowUpperBound = (Color) scale.getPaint(valueSlightlyBelowUpperBound);
                                                                                assertEquals("Value slightly below upper bound failed", expectedColorSlightlyBelowUpperBound, actualColorSlightlyBelowUpperBound);
                                                                            }

    @Test
                                                                            public void testGetPaint_MutantDetection() {
                                                                                // Step 1: Setup the GrayPaintScale object with specific bounds
                                                                                double lowerBound = 0.0;
                                                                                double upperBound = 1.0;
                                                                                GrayPaintScale grayPaintScale = new GrayPaintScale(lowerBound, upperBound);
                                                                        
                                                                                // Step 2: Define the input value and expected output for the original method
                                                                                double inputValue = 0.5; // A mid-range value within the bounds
                                                                                double expectedGrayValue = (inputValue - lowerBound) / (upperBound - lowerBound) * 255.0;
                                                                                int expectedGrayInt = (int) expectedGrayValue;
                                                                                Color expectedColor = new Color(expectedGrayInt, expectedGrayInt, expectedGrayInt);
                                                                        
                                                                                // Step 3: Call the getPaint method and verify the result
                                                                                Color actualColor = (Color) grayPaintScale.getPaint(inputValue);
                                                                                assertEquals("The color returned by getPaint does not match the expected value.", expectedColor, actualColor);
                                                                        
                                                                                // Step 4: Add additional assertions to ensure the mutant is detected
                                                                                // Specifically, test the behavior for edge cases and boundary conditions
                                                                                double edgeValue1 = lowerBound; // Test the lower bound
                                                                                expectedGrayValue = (edgeValue1 - lowerBound) / (upperBound - lowerBound) * 255.0;
                                                                                expectedGrayInt = (int) expectedGrayValue;
                                                                                expectedColor = new Color(expectedGrayInt, expectedGrayInt, expectedGrayInt);
                                                                                actualColor = (Color) grayPaintScale.getPaint(edgeValue1);
                                                                                assertEquals("The color for the lower bound does not match the expected value.", expectedColor, actualColor);
                                                                        
                                                                                double edgeValue2 = upperBound; // Test the upper bound
                                                                                expectedGrayValue = (edgeValue2 - lowerBound) / (upperBound - lowerBound) * 255.0;
                                                                                expectedGrayInt = (int) expectedGrayValue;
                                                                                expectedColor = new Color(expectedGrayInt, expectedGrayInt, expectedGrayInt);
                                                                                actualColor = (Color) grayPaintScale.getPaint(edgeValue2);
                                                                                assertEquals("The color for the upper bound does not match the expected value.", expectedColor, actualColor);
                                                                        
                                                                                // Step 5: Test a value outside the range to ensure clamping behavior
                                                                                double outOfRangeValue = 1.5; // Value greater than upper bound
                                                                                double clampedValue = Math.min(Math.max(outOfRangeValue, lowerBound), upperBound);
                                                                                expectedGrayValue = (clampedValue - lowerBound) / (upperBound - lowerBound) * 255.0;
                                                                                expectedGrayInt = (int) expectedGrayValue;
                                                                                expectedColor = new Color(expectedGrayInt, expectedGrayInt, expectedGrayInt);
                                                                                actualColor = (Color) grayPaintScale.getPaint(outOfRangeValue);
                                                                                assertEquals("The color for an out-of-range value does not match the expected value.", expectedColor, actualColor);
                                                                            }

    @Test
                                                                public void testGetPaintDetectMutant3() {
                                                                    // Create a GrayPaintScale instance with specific bounds
                                                                    GrayPaintScale scale = new GrayPaintScale(0.0, 10.0);
                                                                
                                                                    // Test a value in the middle of the range
                                                                    double value = 5.0;
                                                                    Color expectedColor = new Color(127, 127, 127); // Expected color for the original method
                                                                
                                                                    // Get the paint color from the method
                                                                    Paint actualPaint = scale.getPaint(value);
                                                                
                                                                    // Convert Paint to Color if possible
                                                                    assertTrue("The returned Paint should be an instance of Color.", actualPaint instanceof Color);
                                                                    Color actualColor = (Color) actualPaint;
                                                                
                                                                    // Assert that the color matches the expected color
                                                                    assertEquals("The color should match the expected grayscale value.", expectedColor, actualColor);
                                                                
                                                                    // Test a value at the lower bound
                                                                    value = 0.0;
                                                                    expectedColor = new Color(0, 0, 0); // Expected color for the original method
                                                                
                                                                    // Get the paint color from the method
                                                                    actualPaint = scale.getPaint(value);
                                                                
                                                                    // Convert Paint to Color if possible
                                                                    assertTrue("The returned Paint should be an instance of Color.", actualPaint instanceof Color);
                                                                    actualColor = (Color) actualPaint;
                                                                
                                                                    // Assert that the color matches the expected color
                                                                    assertEquals("The color should match the expected grayscale value at lower bound.", expectedColor, actualColor);
                                                                
                                                                    // Test a value at the upper bound
                                                                    value = 10.0;
                                                                    expectedColor = new Color(255, 255, 255); // Expected color for the original method
                                                                
                                                                    // Get the paint color from the method
                                                                    actualPaint = scale.getPaint(value);
                                                                
                                                                    // Convert Paint to Color if possible
                                                                    assertTrue("The returned Paint should be an instance of Color.", actualPaint instanceof Color);
                                                                    actualColor = (Color) actualPaint;
                                                                
                                                                    // Assert that the color matches the expected color
                                                                    assertEquals("The color should match the expected grayscale value at upper bound.", expectedColor, actualColor);
                                                                }

    @Test
                                                            public void testGetPaintDetectMutant4() {
                                                                // Create an instance of GrayPaintScale with specific bounds
                                                                GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
                                                        
                                                                // Test case where value is at the lower bound
                                                                double valueAtLowerBound = 0.0;
                                                                Color expectedColorAtLowerBound = new Color(0, 0, 0); // g should be 0
                                                                Paint actualPaintAtLowerBound = scale.getPaint(valueAtLowerBound);
                                                                if (actualPaintAtLowerBound instanceof Color) {
                                                                    Color actualColorAtLowerBound = (Color) actualPaintAtLowerBound;
                                                                    assertEquals("Color at lower bound should be black", expectedColorAtLowerBound, actualColorAtLowerBound);
                                                                } else {
                                                                    throw new AssertionError("Expected a Color instance");
                                                                }
                                                        
                                                                // Test case where value is at the upper bound
                                                                double valueAtUpperBound = 1.0;
                                                                Color expectedColorAtUpperBound = new Color(255, 255, 255); // g should be 255
                                                                Paint actualPaintAtUpperBound = scale.getPaint(valueAtUpperBound);
                                                                if (actualPaintAtUpperBound instanceof Color) {
                                                                    Color actualColorAtUpperBound = (Color) actualPaintAtUpperBound;
                                                                    assertEquals("Color at upper bound should be white", expectedColorAtUpperBound, actualColorAtUpperBound);
                                                                } else {
                                                                    throw new AssertionError("Expected a Color instance");
                                                                }
                                                        
                                                                // Test case where value is in the middle of the range
                                                                double valueInMiddle = 0.5;
                                                                Color expectedColorInMiddle = new Color(127, 127, 127); // g should be approximately 127
                                                                Paint actualPaintInMiddle = scale.getPaint(valueInMiddle);
                                                                if (actualPaintInMiddle instanceof Color) {
                                                                    Color actualColorInMiddle = (Color) actualPaintInMiddle;
                                                                    assertEquals("Color in the middle should be gray", expectedColorInMiddle, actualColorInMiddle);
                                                                } else {
                                                                    throw new AssertionError("Expected a Color instance");
                                                                }
                                                        
                                                                // Test case where value is slightly above lower bound
                                                                double valueSlightlyAboveLower = 0.1;
                                                                Color expectedColorSlightlyAboveLower = new Color(25, 25, 25); // g should be approximately 25
                                                                Paint actualPaintSlightlyAboveLower = scale.getPaint(valueSlightlyAboveLower);
                                                                if (actualPaintSlightlyAboveLower instanceof Color) {
                                                                    Color actualColorSlightlyAboveLower = (Color) actualPaintSlightlyAboveLower;
                                                                    assertEquals("Color slightly above lower bound", expectedColorSlightlyAboveLower, actualColorSlightlyAboveLower);
                                                                } else {
                                                                    throw new AssertionError("Expected a Color instance");
                                                                }
                                                        
                                                                // Test case where value is slightly below upper bound
                                                                double valueSlightlyBelowUpper = 0.9;
                                                                Color expectedColorSlightlyBelowUpper = new Color(229, 229, 229); // g should be approximately 229
                                                                Paint actualPaintSlightlyBelowUpper = scale.getPaint(valueSlightlyBelowUpper);
                                                                if (actualPaintSlightlyBelowUpper instanceof Color) {
                                                                    Color actualColorSlightlyBelowUpper = (Color) actualPaintSlightlyBelowUpper;
                                                                    assertEquals("Color slightly below upper bound", expectedColorSlightlyBelowUpper, actualColorSlightlyBelowUpper);
                                                                } else {
                                                                    throw new AssertionError("Expected a Color instance");
                                                                }
                                                            }

    @Test
                                                        public void testGetPaintDetectMutant5() {
                                                            // Arrange: Create an instance of GrayPaintScale with specific bounds
                                                            double lowerBound = 0.0;
                                                            double upperBound = 100.0;
                                                            GrayPaintScale grayPaintScale = new GrayPaintScale(lowerBound, upperBound);
                                                    
                                                            // Test case 1: Value within bounds (normal scenario)
                                                            double value1 = 50.0; // Midpoint between lowerBound and upperBound
                                                            Paint paint1 = grayPaintScale.getPaint(value1);
                                                            assertTrue(paint1 instanceof Color);
                                                            Color color1 = (Color) paint1;
                                                            int expectedGray1 = (int) ((value1 - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                            assertEquals(expectedGray1, color1.getRed());
                                                            assertEquals(expectedGray1, color1.getGreen());
                                                            assertEquals(expectedGray1, color1.getBlue());
                                                    
                                                            // Test case 2: Value equal to lowerBound (boundary scenario)
                                                            double value2 = lowerBound;
                                                            Paint paint2 = grayPaintScale.getPaint(value2);
                                                            assertTrue(paint2 instanceof Color);
                                                            Color color2 = (Color) paint2;
                                                            int expectedGray2 = (int) ((value2 - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                            assertEquals(expectedGray2, color2.getRed());
                                                            assertEquals(expectedGray2, color2.getGreen());
                                                            assertEquals(expectedGray2, color2.getBlue());
                                                    
                                                            // Test case 3: Value equal to upperBound (boundary scenario)
                                                            double value3 = upperBound;
                                                            Paint paint3 = grayPaintScale.getPaint(value3);
                                                            assertTrue(paint3 instanceof Color);
                                                            Color color3 = (Color) paint3;
                                                            int expectedGray3 = (int) ((value3 - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                            assertEquals(expectedGray3, color3.getRed());
                                                            assertEquals(expectedGray3, color3.getGreen());
                                                            assertEquals(expectedGray3, color3.getBlue());
                                                    
                                                            // Test case 4: Value less than lowerBound (clamping scenario)
                                                            double value4 = -10.0; // Below lowerBound
                                                            Paint paint4 = grayPaintScale.getPaint(value4);
                                                            assertTrue(paint4 instanceof Color);
                                                            Color color4 = (Color) paint4;
                                                            int expectedGray4 = (int) ((lowerBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                            assertEquals(expectedGray4, color4.getRed());
                                                            assertEquals(expectedGray4, color4.getGreen());
                                                            assertEquals(expectedGray4, color4.getBlue());
                                                    
                                                            // Test case 5: Value greater than upperBound (clamping scenario)
                                                            double value5 = 150.0; // Above upperBound
                                                            Paint paint5 = grayPaintScale.getPaint(value5);
                                                            assertTrue(paint5 instanceof Color);
                                                            Color color5 = (Color) paint5;
                                                            int expectedGray5 = (int) ((upperBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                            assertEquals(expectedGray5, color5.getRed());
                                                            assertEquals(expectedGray5, color5.getGreen());
                                                            assertEquals(expectedGray5, color5.getBlue());
                                                        }

    @Test
                                                    public void testGetPaintDetectMutant6() {
                                                        // Arrange: Create an instance of GrayPaintScale with specific bounds
                                                        double lowerBound = 0.0;
                                                        double upperBound = 100.0;
                                                        GrayPaintScale grayPaintScale = new GrayPaintScale(lowerBound, upperBound);
                                                
                                                        // Test Case 1: Value within bounds
                                                        double valueWithinBounds = 50.0; // Midpoint between lowerBound and upperBound
                                                        Paint paintWithinBounds = grayPaintScale.getPaint(valueWithinBounds);
                                                        assertTrue(paintWithinBounds instanceof Color);
                                                        Color colorWithinBounds = (Color) paintWithinBounds;
                                                
                                                        // Expected g calculation for midpoint
                                                        double normalizedValue = (valueWithinBounds - lowerBound) / (upperBound - lowerBound);
                                                        int expectedG = (int) (normalizedValue * 255.0);
                                                
                                                        // Assert: Verify the original behavior (g, g, g)
                                                        assertEquals(expectedG, colorWithinBounds.getRed());
                                                        assertEquals(expectedG, colorWithinBounds.getGreen());
                                                        assertEquals(expectedG, colorWithinBounds.getBlue());
                                                
                                                        // Test Case 2: Value at lower bound
                                                        double valueAtLowerBound = lowerBound;
                                                        Paint paintAtLowerBound = grayPaintScale.getPaint(valueAtLowerBound);
                                                        assertTrue(paintAtLowerBound instanceof Color);
                                                        Color colorAtLowerBound = (Color) paintAtLowerBound;
                                                
                                                        // Expected g calculation for lower bound
                                                        expectedG = (int) ((valueAtLowerBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                
                                                        // Assert: Verify the original behavior (g, g, g)
                                                        assertEquals(expectedG, colorAtLowerBound.getRed());
                                                        assertEquals(expectedG, colorAtLowerBound.getGreen());
                                                        assertEquals(expectedG, colorAtLowerBound.getBlue());
                                                
                                                        // Test Case 3: Value at upper bound
                                                        double valueAtUpperBound = upperBound;
                                                        Paint paintAtUpperBound = grayPaintScale.getPaint(valueAtUpperBound);
                                                        assertTrue(paintAtUpperBound instanceof Color);
                                                        Color colorAtUpperBound = (Color) paintAtUpperBound;
                                                
                                                        // Expected g calculation for upper bound
                                                        expectedG = (int) ((valueAtUpperBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                
                                                        // Assert: Verify the original behavior (g, g, g)
                                                        assertEquals(expectedG, colorAtUpperBound.getRed());
                                                        assertEquals(expectedG, colorAtUpperBound.getGreen());
                                                        assertEquals(expectedG, colorAtUpperBound.getBlue());
                                                
                                                        // Test Case 4: Value outside bounds (below lower bound)
                                                        double valueBelowLowerBound = -10.0; // Below lowerBound
                                                        Paint paintBelowLowerBound = grayPaintScale.getPaint(valueBelowLowerBound);
                                                        assertTrue(paintBelowLowerBound instanceof Color);
                                                        Color colorBelowLowerBound = (Color) paintBelowLowerBound;
                                                
                                                        // Expected g calculation for clamped value
                                                        double clampedValueBelow = Math.max(valueBelowLowerBound, lowerBound);
                                                        expectedG = (int) ((clampedValueBelow - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                
                                                        // Assert: Verify the original behavior (g, g, g)
                                                        assertEquals(expectedG, colorBelowLowerBound.getRed());
                                                        assertEquals(expectedG, colorBelowLowerBound.getGreen());
                                                        assertEquals(expectedG, colorBelowLowerBound.getBlue());
                                                
                                                        // Test Case 5: Value outside bounds (above upper bound)
                                                        double valueAboveUpperBound = 150.0; // Above upperBound
                                                        Paint paintAboveUpperBound = grayPaintScale.getPaint(valueAboveUpperBound);
                                                        assertTrue(paintAboveUpperBound instanceof Color);
                                                        Color colorAboveUpperBound = (Color) paintAboveUpperBound;
                                                
                                                        // Expected g calculation for clamped value
                                                        double clampedValueAbove = Math.min(valueAboveUpperBound, upperBound);
                                                        expectedG = (int) ((clampedValueAbove - lowerBound) / (upperBound - lowerBound) * 255.0);
                                                
                                                        // Assert: Verify the original behavior (g, g, g)
                                                        assertEquals(expectedG, colorAboveUpperBound.getRed());
                                                        assertEquals(expectedG, colorAboveUpperBound.getGreen());
                                                        assertEquals(expectedG, colorAboveUpperBound.getBlue());
                                                    }

    @Test
                                        public void testGetPaintDetectMutant7() {
                                            // Arrange
                                            double lowerBound = 0.0;
                                            double upperBound = 1.0;
                                            GrayPaintScale scale = new GrayPaintScale(lowerBound, upperBound);
                                        
                                            // Test a value within the bounds
                                            double value = 0.5;
                                            double expectedGrayValue = (value - lowerBound) / (upperBound - lowerBound) * 255.0;
                                            int expectedG = (int) expectedGrayValue;
                                        
                                            // Act
                                            Paint paint = scale.getPaint(value);
                                        
                                            // Assert
                                            assertTrue("Paint should be an instance of Color", paint instanceof Color);
                                            Color color = (Color) paint;
                                            assertEquals("Red component should be equal to calculated gray value", expectedG, color.getRed());
                                            assertEquals("Green component should be equal to calculated gray value", expectedG, color.getGreen());
                                            assertEquals("Blue component should be equal to calculated gray value", expectedG, color.getBlue());
                                        }

    @Test
                                    public void testGetPaint_detectMutant() {
                                        // Create an instance of GrayPaintScale with specific bounds
                                        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
                                
                                        // Test case where value is exactly at the lower bound
                                        double value = 0.0;
                                        Color expectedColor = new Color(0, 0, 0); // g should be 0
                                        Paint paint = scale.getPaint(value);
                                        Color actualColor = (Color) paint;
                                        assertEquals("Color at lower bound should be (0, 0, 0)", expectedColor, actualColor);
                                
                                        // Test case where value is exactly at the upper bound
                                        value = 1.0;
                                        expectedColor = new Color(255, 255, 255); // g should be 255
                                        paint = scale.getPaint(value);
                                        actualColor = (Color) paint;
                                        assertEquals("Color at upper bound should be (255, 255, 255)", expectedColor, actualColor);
                                
                                        // Test case where value is in the middle of the range
                                        value = 0.5;
                                        expectedColor = new Color(127, 127, 127); // g should be 127
                                        paint = scale.getPaint(value);
                                        actualColor = (Color) paint;
                                        assertEquals("Color at mid-point should be (127, 127, 127)", expectedColor, actualColor);
                                
                                        // Test case where value is slightly above the lower bound
                                        value = 0.1;
                                        expectedColor = new Color(25, 25, 25); // g should be 25
                                        paint = scale.getPaint(value);
                                        actualColor = (Color) paint;
                                        assertEquals("Color slightly above lower bound should be (25, 25, 25)", expectedColor, actualColor);
                                
                                        // Test case where value is slightly below the upper bound
                                        value = 0.9;
                                        expectedColor = new Color(229, 229, 229); // g should be 229
                                        paint = scale.getPaint(value);
                                        actualColor = (Color) paint;
                                        assertEquals("Color slightly below upper bound should be (229, 229, 229)", expectedColor, actualColor);
                                    }

    @Test
                                public void testGetPaintDetectMutant8() {
                                    // Test case 1: Typical usage within bounds
                                    GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
                                    double value = 0.5; // Midpoint between lowerBound and upperBound
                                    Color expectedColor = new Color(127, 127, 127); // g = 127
                                    Color actualColor = (Color) scale.getPaint(value);
                                    assertEquals("Expected R component to match", expectedColor.getRed(), actualColor.getRed());
                                    assertEquals("Expected G component to match", expectedColor.getGreen(), actualColor.getGreen());
                                    assertEquals("Expected B component to match", expectedColor.getBlue(), actualColor.getBlue());
                            
                                    // Test case 2: Value at lower bound
                                    value = 0.0;
                                    expectedColor = new Color(0, 0, 0); // g = 0
                                    actualColor = (Color) scale.getPaint(value);
                                    assertEquals("Expected R component to match", expectedColor.getRed(), actualColor.getRed());
                                    assertEquals("Expected G component to match", expectedColor.getGreen(), actualColor.getGreen());
                                    assertEquals("Expected B component to match", expectedColor.getBlue(), actualColor.getBlue());
                            
                                    // Test case 3: Value at upper bound
                                    value = 1.0;
                                    expectedColor = new Color(255, 255, 255); // g = 255
                                    actualColor = (Color) scale.getPaint(value);
                                    assertEquals("Expected R component to match", expectedColor.getRed(), actualColor.getRed());
                                    assertEquals("Expected G component to match", expectedColor.getGreen(), actualColor.getGreen());
                                    assertEquals("Expected B component to match", expectedColor.getBlue(), actualColor.getBlue());
                            
                                    // Test case 4: Value below lower bound (clamped to lowerBound)
                                    value = -0.5;
                                    expectedColor = new Color(0, 0, 0); // g = 0
                                    actualColor = (Color) scale.getPaint(value);
                                    assertEquals("Expected R component to match", expectedColor.getRed(), actualColor.getRed());
                                    assertEquals("Expected G component to match", expectedColor.getGreen(), actualColor.getGreen());
                                    assertEquals("Expected B component to match", expectedColor.getBlue(), actualColor.getBlue());
                            
                                    // Test case 5: Value above upper bound (clamped to upperBound)
                                    value = 1.5;
                                    expectedColor = new Color(255, 255, 255); // g = 255
                                    actualColor = (Color) scale.getPaint(value);
                                    assertEquals("Expected R component to match", expectedColor.getRed(), actualColor.getRed());
                                    assertEquals("Expected G component to match", expectedColor.getGreen(), actualColor.getGreen());
                                    assertEquals("Expected B component to match", expectedColor.getBlue(), actualColor.getBlue());
                                }

    @Test
                            public void testGetPaintDetectMutant9() {
                                // Arrange: Create an instance of GrayPaintScale with specific bounds
                                double lowerBound = 0.0;
                                double upperBound = 100.0;
                                GrayPaintScale scale = new GrayPaintScale(lowerBound, upperBound);
                        
                                // Test case 1: Value within bounds (typical case)
                                double value1 = 50.0; // Midpoint value
                                Paint paint1 = scale.getPaint(value1);
                                assertTrue(paint1 instanceof Color);
                                Color color1 = (Color) paint1;
                                int expectedGray1 = (int) ((value1 - lowerBound) / (upperBound - lowerBound) * 255.0);
                                assertEquals("Gray value for red channel is incorrect", expectedGray1, color1.getRed());
                                assertEquals("Gray value for green channel is incorrect", expectedGray1, color1.getGreen());
                                assertEquals("Gray value for blue channel is incorrect", expectedGray1, color1.getBlue());
                        
                                // Test case 2: Value at lower bound
                                double value2 = lowerBound;
                                Paint paint2 = scale.getPaint(value2);
                                assertTrue(paint2 instanceof Color);
                                Color color2 = (Color) paint2;
                                int expectedGray2 = (int) ((value2 - lowerBound) / (upperBound - lowerBound) * 255.0);
                                assertEquals("Gray value for red channel is incorrect", expectedGray2, color2.getRed());
                                assertEquals("Gray value for green channel is incorrect", expectedGray2, color2.getGreen());
                                assertEquals("Gray value for blue channel is incorrect", expectedGray2, color2.getBlue());
                        
                                // Test case 3: Value at upper bound
                                double value3 = upperBound;
                                Paint paint3 = scale.getPaint(value3);
                                assertTrue(paint3 instanceof Color);
                                Color color3 = (Color) paint3;
                                int expectedGray3 = (int) ((value3 - lowerBound) / (upperBound - lowerBound) * 255.0);
                                assertEquals("Gray value for red channel is incorrect", expectedGray3, color3.getRed());
                                assertEquals("Gray value for green channel is incorrect", expectedGray3, color3.getGreen());
                                assertEquals("Gray value for blue channel is incorrect", expectedGray3, color3.getBlue());
                        
                                // Test case 4: Value outside bounds (less than lower bound)
                                double value4 = -10.0;
                                Paint paint4 = scale.getPaint(value4);
                                assertTrue(paint4 instanceof Color);
                                Color color4 = (Color) paint4;
                                int expectedGray4 = (int) ((lowerBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                assertEquals("Gray value for red channel is incorrect", expectedGray4, color4.getRed());
                                assertEquals("Gray value for green channel is incorrect", expectedGray4, color4.getGreen());
                                assertEquals("Gray value for blue channel is incorrect", expectedGray4, color4.getBlue());
                        
                                // Test case 5: Value outside bounds (greater than upper bound)
                                double value5 = 150.0;
                                Paint paint5 = scale.getPaint(value5);
                                assertTrue(paint5 instanceof Color);
                                Color color5 = (Color) paint5;
                                int expectedGray5 = (int) ((upperBound - lowerBound) / (upperBound - lowerBound) * 255.0);
                                assertEquals("Gray value for red channel is incorrect", expectedGray5, color5.getRed());
                                assertEquals("Gray value for green channel is incorrect", expectedGray5, color5.getGreen());
                                assertEquals("Gray value for blue channel is incorrect", expectedGray5, color5.getBlue());
                            }

    @Test
                    public void testGetPaintDetectMutant10() {
                        // Initialize the GrayPaintScale object with specific bounds
                        GrayPaintScale scale = new GrayPaintScale(0.0, 1.0);
                
                        // Test case: value within bounds
                        double valueWithinBounds = 0.5;
                        Color expectedColorWithinBounds = new Color(127, 127, 127); // g = (int)((0.5 - 0.0)/(1.0 - 0.0) * 255.0)
                        Paint actualPaintWithinBounds = scale.getPaint(valueWithinBounds);
                        assertEquals("Color within bounds should have equal RGB components", expectedColorWithinBounds, actualPaintWithinBounds);
                
                        // Test case: value at lower bound
                        double valueAtLowerBound = 0.0;
                        Color expectedColorAtLowerBound = new Color(0, 0, 0); // g = (int)((0.0 - 0.0)/(1.0 - 0.0) * 255.0)
                        Paint actualPaintAtLowerBound = scale.getPaint(valueAtLowerBound);
                        assertEquals("Color at lower bound should be black", expectedColorAtLowerBound, actualPaintAtLowerBound);
                
                        // Test case: value at upper bound
                        double valueAtUpperBound = 1.0;
                        Color expectedColorAtUpperBound = new Color(255, 255, 255); // g = (int)((1.0 - 0.0)/(1.0 - 0.0) * 255.0)
                        Paint actualPaintAtUpperBound = scale.getPaint(valueAtUpperBound);
                        assertEquals("Color at upper bound should be white", expectedColorAtUpperBound, actualPaintAtUpperBound);
                
                        // Test case: value below lower bound
                        double valueBelowLowerBound = -0.5;
                        Color expectedColorBelowLowerBound = new Color(0, 0, 0); // g = (int)((0.0 - 0.0)/(1.0 - 0.0) * 255.0)
                        Paint actualPaintBelowLowerBound = scale.getPaint(valueBelowLowerBound);
                        assertEquals("Color below lower bound should be black", expectedColorBelowLowerBound, actualPaintBelowLowerBound);
                
                        // Test case: value above upper bound
                        double valueAboveUpperBound = 1.5;
                        Color expectedColorAboveUpperBound = new Color(255, 255, 255); // g = (int)((1.0 - 0.0)/(1.0 - 0.0) * 255.0)
                        Paint actualPaintAboveUpperBound = scale.getPaint(valueAboveUpperBound);
                        assertEquals("Color above upper bound should be white", expectedColorAboveUpperBound, actualPaintAboveUpperBound);
                    }

    @Test
        public void testGetPaintDetectMutant11() {
            // Arrange
            double lowerBound = 0.0;
            double upperBound = 1.0;
            GrayPaintScale scale = new GrayPaintScale(lowerBound, upperBound);
        
            // Test case to detect the mutant
            double testValue = 0.5; // A value between lowerBound and upperBound
            Color expectedColor = new Color(128, 128, 128); // Expected color with factor 128.0
        
            // Act
            Paint paint = scale.getPaint(testValue);
            Color actualColor = null;
            if (paint instanceof Color) {
                actualColor = (Color) paint;
            }
        
            // Assert
            assertNotNull("The paint should be an instance of Color", actualColor);
            assertEquals("The color should match the expected value with factor 128.0", expectedColor, actualColor);
        }

    @Test
        public void testGetPaintDetectMutant12() {
            // Step 1: Create an instance of GrayPaintScale with specific bounds
            double lowerBound = 0.0;
            double upperBound = 1.0;
            GrayPaintScale scale = new GrayPaintScale(lowerBound, upperBound);
    
            // Step 2: Define test inputs and expected outputs
            double testValue = 0.5; // Midpoint value between lowerBound and upperBound
            double expectedGOriginal = (testValue - lowerBound) / (upperBound - lowerBound) * 255.0;
            int expectedG = (int) expectedGOriginal;
    
            // Step 3: Call the getPaint method and verify the result
            Color resultColor = (Color) scale.getPaint(testValue);
    
            // Assert that the color matches the expected value
            assertEquals("Red channel mismatch", expectedG, resultColor.getRed());
            assertEquals("Green channel mismatch", expectedG, resultColor.getGreen());
            assertEquals("Blue channel mismatch", expectedG, resultColor.getBlue());
    
            // Step 4: Add additional test cases to detect the mutant
            // Test edge cases at the lower and upper bounds
            double edgeValueLower = lowerBound;
            double edgeValueUpper = upperBound;
    
            Color resultColorLower = (Color) scale.getPaint(edgeValueLower);
            Color resultColorUpper = (Color) scale.getPaint(edgeValueUpper);
    
            int expectedGLower = (int) ((edgeValueLower - lowerBound) / (upperBound - lowerBound) * 255.0);
            int expectedGUpper = (int) ((edgeValueUpper - lowerBound) / (upperBound - lowerBound) * 255.0);
    
            assertEquals("Lower bound red channel mismatch", expectedGLower, resultColorLower.getRed());
            assertEquals("Lower bound green channel mismatch", expectedGLower, resultColorLower.getGreen());
            assertEquals("Lower bound blue channel mismatch", expectedGLower, resultColorLower.getBlue());
    
            assertEquals("Upper bound red channel mismatch", expectedGUpper, resultColorUpper.getRed());
            assertEquals("Upper bound green channel mismatch", expectedGUpper, resultColorUpper.getGreen());
            assertEquals("Upper bound blue channel mismatch", expectedGUpper, resultColorUpper.getBlue());
    
            // Step 5: Test edge case near mutation impact
            double nearMutationValue = 0.25; // A value that highlights the scaling factor difference
            double expectedGNearOriginal = (nearMutationValue - lowerBound) / (upperBound - lowerBound) * 255.0;
            int expectedGNear = (int) expectedGNearOriginal;
    
            Color resultColorNear = (Color) scale.getPaint(nearMutationValue);
    
            assertEquals("Near mutation red channel mismatch", expectedGNear, resultColorNear.getRed());
            assertEquals("Near mutation green channel mismatch", expectedGNear, resultColorNear.getGreen());
            assertEquals("Near mutation blue channel mismatch", expectedGNear, resultColorNear.getBlue());
        }

}
