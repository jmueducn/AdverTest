package gentest.org.jfree.chart.plot.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.chart.plot.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.RenderingSource;
import org.jfree.chart.annotations.XYAnnotation;
import org.jfree.chart.annotations.XYAnnotationBoundsInfo;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.AxisCollection;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.AxisSpace;
import org.jfree.chart.axis.AxisState;
import org.jfree.chart.axis.TickType;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.axis.ValueTick;
import org.jfree.chart.event.ChartChangeEventType;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.renderer.RendererUtilities;
import org.jfree.chart.renderer.xy.AbstractXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRendererState;
import org.jfree.chart.util.Layer;
import org.jfree.chart.util.ObjectList;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.ResourceBundleWrapper;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.data.Range;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.AbstractXYDataset;
import org.jfree.data.xy.SelectableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDatasetSelectionState;
 
public class XYPlotTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                                public void testGetDataRange_TypicalDomainAxis() {
                                                                                                                                                                                                                                                                    // Create mock objects
                                                                                                                                                                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                                    XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Create an instance of XYPlot
                                                                                                                                                                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Set up the mock behavior
                                                                                                                                                                                                                                                                    when(mockAxis.equals(any())).thenReturn(true);
                                                                                                                                                                                                                                                                    plot.setDataset(0, mockDataset);
                                                                                                                                                                                                                                                                    plot.setRenderer(0, mockRenderer);
                                                                                                                                                                                                                                                                    when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 5.0));
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                                                                                                    Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Assert the results
                                                                                                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                                                                                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                                                                                                    assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testGetDataRange_EmptyDatasets() {
                                                                                                                                                                                                                                                                    // Create a mock for the ValueAxis
                                                                                                                                                                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Create an instance of XYPlot
                                                                                                                                                                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Set up the mock behavior
                                                                                                                                                                                                                                                                    when(mockAxis.equals(any())).thenReturn(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Clear domain and range axes
                                                                                                                                                                                                                                                                    plot.clearDomainAxes();
                                                                                                                                                                                                                                                                    plot.clearRangeAxes();
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                                                                                                    Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Assert that the result is null
                                                                                                                                                                                                                                                                    assertNull(result);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testGetDataRange_NullRenderer() {
                                                                                                                                                                                                                                                                    // Mock the necessary objects
                                                                                                                                                                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Set up the mock behavior
                                                                                                                                                                                                                                                                    when(mockAxis.equals(any())).thenReturn(true);
                                                                                                                                                                                                                                                                    plot.setDataset(0, mockDataset);
                                                                                                                                                                                                                                                                    plot.setRenderer(0, null);
                                                                                                                                                                                                                                                                    when(DatasetUtilities.findDomainBounds(mockDataset)).thenReturn(new Range(2.0, 6.0));
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                                                                                                    Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Verify the results
                                                                                                                                                                                                                                                                    assertNotNull(result);
                                                                                                                                                                                                                                                                    assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                                                                                                    assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testGetDataRange_NullAxis() {
                                                                                                                                                                                                                                                                    // Create an instance of XYPlot
                                                                                                                                                                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Set up the ExpectedException rule
                                                                                                                                                                                                                                                                    ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                                    thrown.expect(NullPointerException.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                    // Call the method with null and expect a NullPointerException
                                                                                                                                                                                                                                                                    plot.getDataRange(null);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                        public void testGetDataRange_AnnotationsIncluded() {
                                                                                                                                                                                                                                                            // Mock the necessary objects
                                                                                                                                                                                                                                                            ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                            XYPlot plot = new XYPlot();
                                                                                                                                                                                                                                                            XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Set up the mock behavior
                                                                                                                                                                                                                                                            when(mockAxis.equals(any())).thenReturn(true);
                                                                                                                                                                                                                                                            plot.addAnnotation(mockAnnotation);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Use a custom Answer to simulate the behavior of getIncludeInDataBounds() and getXRange()
                                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                                // Use reflection to mock the methods if they are not directly accessible
                                                                                                                                                                                                                                                                when(mockAnnotation.getClass().getMethod("getIncludeInDataBounds").invoke(mockAnnotation)).thenReturn(true);
                                                                                                                                                                                                                                                                when(mockAnnotation.getClass().getMethod("getXRange").invoke(mockAnnotation)).thenReturn(new Range(3.0, 7.0));
                                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Call the method under test
                                                                                                                                                                                                                                                            Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                            // Verify the results
                                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                                            assertEquals(3.0, result.getLowerBound(), 0.0001);
                                                                                                                                                                                                                                                            assertEquals(7.0, result.getUpperBound(), 0.0001);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                            public void testGetDataRangeWithNullRenderer() {
                                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                                XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                                                                                ValueAxis domainAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                ValueAxis rangeAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                                                XYPlot plot = new XYPlot(dataset, domainAxis, rangeAxis, null);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                when(domainAxis.equals(any())).thenReturn(true);
                                                                                                                                                                                                                                                when(rangeAxis.equals(any())).thenReturn(false);
                                                                                                                                                                                                                                                when(plot.getDomainAxisIndex(domainAxis)).thenReturn(0);
                                                                                                                                                                                                                                                when(plot.getRangeAxisIndex(rangeAxis)).thenReturn(-1);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Mock DatasetUtilities to return a specific range
                                                                                                                                                                                                                                                Range expectedRange = new Range(1.0, 10.0);
                                                                                                                                                                                                                                                mockStatic(DatasetUtilities.class);
                                                                                                                                                                                                                                                when(DatasetUtilities.findDomainBounds(dataset)).thenReturn(expectedRange);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                                Range result = plot.getDataRange(domainAxis);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                                assertEquals("The range should match the expected range from DatasetUtilities", expectedRange, result);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                // Cleanup
                                                                                                                                                                                                                                                clearAllCaches();
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                    public void testGetDataRangeDetectsMutant() {
                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                                                                        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                        
                                                                                                                                                                                                                        // Create a custom mock for XYAnnotation
                                                                                                                                                                                                                        XYAnnotation mockAnnotation = mock(XYAnnotation.class, invocation -> {
                                                                                                                                                                                                                            String methodName = invocation.getMethod().getName();
                                                                                                                                                                                                                            if ("getIncludeInDataBounds".equals(methodName)) {
                                                                                                                                                                                                                                return true;
                                                                                                                                                                                                                            } else if ("getXRange".equals(methodName)) {
                                                                                                                                                                                                                                return new Range(1.0, 2.0);
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                        });
                                                                                                                                                                                                                    
                                                                                                                                                                                                                        // Create a mock collection of annotations
                                                                                                                                                                                                                        List<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                                                                        annotations.add(mockAnnotation);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                        // Mock the behavior of the renderer to return the annotations
                                                                                                                                                                                                                        when(mockRenderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                        // Create an instance of XYPlot with the mock renderer
                                                                                                                                                                                                                        XYPlot xyPlot = new XYPlot(null, null, null, mockRenderer);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                        Range result = xyPlot.getDataRange(mockAxis);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                        assertNotNull("Resulting range should not be null", result);
                                                                                                                                                                                                                        assertTrue("Resulting range should include the annotation's x-range",
                                                                                                                                                                                                                                result.contains(1.0) && result.contains(2.0));
                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                            public void testGetDataRangeWithAnnotations() throws Exception {
                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                                                XYAnnotation annotation = mock(XYAnnotation.class);
                                                                                                                                                                                                                XYPlot plot = new XYPlot(null, null, null, renderer);
                                                                                                                                                                                                        
                                                                                                                                                                                                                when(renderer.getAnnotations()).thenReturn(Collections.singletonList(annotation));
                                                                                                                                                                                                        
                                                                                                                                                                                                                // Use reflection to set up the annotation methods
                                                                                                                                                                                                                Method getIncludeInDataBoundsMethod = annotation.getClass().getMethod("getIncludeInDataBounds");
                                                                                                                                                                                                                when((Boolean) getIncludeInDataBoundsMethod.invoke(annotation)).thenReturn(true);
                                                                                                                                                                                                        
                                                                                                                                                                                                                Range expectedRange = new Range(1.0, 2.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                                Method getXRangeMethod = annotation.getClass().getMethod("getXRange");
                                                                                                                                                                                                                when((Range) getXRangeMethod.invoke(annotation)).thenReturn(expectedRange);
                                                                                                                                                                                                        
                                                                                                                                                                                                                Method getYRangeMethod = annotation.getClass().getMethod("getYRange");
                                                                                                                                                                                                                when((Range) getYRangeMethod.invoke(annotation)).thenReturn(expectedRange);
                                                                                                                                                                                                        
                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                Range result = plot.getDataRange(null);
                                                                                                                                                                                                        
                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                assertNotNull("The result should not be null", result);
                                                                                                                                                                                                                assertEquals("The range should match the expected range from annotations", expectedRange, result);
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testGetDataRangeDetectsMutant1() throws Exception {
                                                                                                                                                                                            // Setup
                                                                                                                                                                                            XYPlot plot = new XYPlot();
                                                                                                                                                                                            ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                                            XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                                            XYAnnotationBoundsInfo annotationBoundsInfo = mock(XYAnnotationBoundsInfo.class);
                                                                                                                                                                                        
                                                                                                                                                                                            // Mock behavior
                                                                                                                                                                                            when(axis.getPlot()).thenReturn(plot);
                                                                                                                                                                                            when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                        
                                                                                                                                                                                            // Use reflection to access the private method getDatasetsMappedToDomainAxis
                                                                                                                                                                                            Method getDatasetsMappedToDomainAxis = XYPlot.class.getDeclaredMethod("getDatasetsMappedToDomainAxis", Integer.TYPE);
                                                                                                                                                                                            getDatasetsMappedToDomainAxis.setAccessible(true);
                                                                                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                                                                                            List<XYDataset> datasets = (List<XYDataset>) getDatasetsMappedToDomainAxis.invoke(plot, 0);
                                                                                                                                                                                            datasets.add(dataset);
                                                                                                                                                                                        
                                                                                                                                                                                            when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
                                                                                                                                                                                            when(renderer.findDomainBounds(dataset)).thenReturn(new Range(0.0, 10.0));
                                                                                                                                                                                        
                                                                                                                                                                                            // Mock the behavior of annotationBoundsInfo
                                                                                                                                                                                            when(annotationBoundsInfo.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                                            when(annotationBoundsInfo.getXRange()).thenReturn(new Range(5.0, 15.0));
                                                                                                                                                                                        
                                                                                                                                                                                            // Add annotations to the plot
                                                                                                                                                                                            plot.addAnnotation((XYAnnotation) annotationBoundsInfo);
                                                                                                                                                                                        
                                                                                                                                                                                            // Execute
                                                                                                                                                                                            Range result = plot.getDataRange(axis);
                                                                                                                                                                                        
                                                                                                                                                                                            // Verify
                                                                                                                                                                                            assertNotNull("Resulting range should not be null", result);
                                                                                                                                                                                            assertEquals("Expected range should be the combination of dataset and annotation bounds",
                                                                                                                                                                                                    new Range(0.0, 15.0), result);
                                                                                                                                                                                        
                                                                                                                                                                                            // Verify that the loop does not run infinitely
                                                                                                                                                                                            verify(renderer, times(1)).findDomainBounds(dataset);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                public void testGetDataRangeWithAnnotations1() {
                                                                                                                                                                                    // Create a mock plot
                                                                                                                                                                                    XYPlot plot = mock(XYPlot.class);
                                                                                                                                                                            
                                                                                                                                                                                    // Create a mock axis
                                                                                                                                                                                    ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                            
                                                                                                                                                                                    // Create mock annotations
                                                                                                                                                                                    XYAnnotation annotation1 = mock(XYAnnotation.class);
                                                                                                                                                                                    XYAnnotation annotation2 = mock(XYAnnotation.class);
                                                                                                                                                                            
                                                                                                                                                                                    // Assume the axis is a domain axis
                                                                                                                                                                                    when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                                    when(plot.getRangeAxisIndex(axis)).thenReturn(-1);
                                                                                                                                                                            
                                                                                                                                                                                    // Mock the range returned by the annotations
                                                                                                                                                                                    Range range1 = new Range(1.0, 2.0);
                                                                                                                                                                                    Range range2 = new Range(2.0, 3.0);
                                                                                                                                                                            
                                                                                                                                                                                    // Use reflection to mock the behavior of getXRange() method
                                                                                                                                                                                    try {
                                                                                                                                                                                        java.lang.reflect.Method getXRangeMethod = XYAnnotation.class.getDeclaredMethod("getXRange");
                                                                                                                                                                                        getXRangeMethod.setAccessible(true);
                                                                                                                                                                                        when(getXRangeMethod.invoke(annotation1)).thenReturn(range1);
                                                                                                                                                                                        when(getXRangeMethod.invoke(annotation2)).thenReturn(range2);
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        e.printStackTrace();
                                                                                                                                                                                    }
                                                                                                                                                                            
                                                                                                                                                                                    // Add annotations to the plot
                                                                                                                                                                                    plot.addAnnotation(annotation1);
                                                                                                                                                                                    plot.addAnnotation(annotation2);
                                                                                                                                                                            
                                                                                                                                                                                    // Call the method under test
                                                                                                                                                                                    Range result = plot.getDataRange(axis);
                                                                                                                                                                            
                                                                                                                                                                                    // Verify the expected range is the combination of both annotation ranges
                                                                                                                                                                                    Range expectedRange = Range.combine(range1, range2);
                                                                                                                                                                                    assertEquals(expectedRange, result);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                    public void testGetDataRangeDetectsMutant2() {
                                                                                                                                                                        // Create a mock XYPlot
                                                                                                                                                                        XYPlot plot = new XYPlot();
                                                                                                                                                                    
                                                                                                                                                                        // Mock the axis
                                                                                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                                                                                    
                                                                                                                                                                        // Mock the dataset
                                                                                                                                                                        XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                    
                                                                                                                                                                        // Mock the renderer
                                                                                                                                                                        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                                                                    
                                                                                                                                                                        // Mock the annotations
                                                                                                                                                                        XYAnnotation mockAnnotation = mock(XYAnnotation.class, withSettings().extraInterfaces(XYAnnotationBoundsInfo.class));
                                                                                                                                                                        XYAnnotationBoundsInfo mockAnnotationBoundsInfo = (XYAnnotationBoundsInfo) mockAnnotation;
                                                                                                                                                                        when(mockAnnotationBoundsInfo.getIncludeInDataBounds()).thenReturn(true);
                                                                                                                                                                        when(mockAnnotationBoundsInfo.getXRange()).thenReturn(new Range(1.0, 2.0));
                                                                                                                                                                        when(mockAnnotationBoundsInfo.getYRange()).thenReturn(new Range(1.0, 2.0));
                                                                                                                                                                    
                                                                                                                                                                        List<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                                                        annotations.add(mockAnnotation);
                                                                                                                                                                    
                                                                                                                                                                        // Mock the renderer's getAnnotations method
                                                                                                                                                                        when(mockRenderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                                                    
                                                                                                                                                                        // Set up the plot with the mock dataset and renderer
                                                                                                                                                                        plot.setDataset(0, mockDataset);
                                                                                                                                                                        plot.setRenderer(0, mockRenderer);
                                                                                                                                                                    
                                                                                                                                                                        // Add the annotation to the plot
                                                                                                                                                                        plot.addAnnotation(mockAnnotation);
                                                                                                                                                                    
                                                                                                                                                                        // Call the method under test
                                                                                                                                                                        Range result = plot.getDataRange(mockAxis);
                                                                                                                                                                    
                                                                                                                                                                        // Verify the result
                                                                                                                                                                        assertNotNull("The result should not be null", result);
                                                                                                                                                                        assertEquals("The result range should be combined correctly", new Range(1.0, 2.0), result);
                                                                                                                                                                    
                                                                                                                                                                        // Verify that the renderer's annotations were iterated correctly
                                                                                                                                                                        verify(mockRenderer, times(1)).getAnnotations();
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testGetDataRangeWithMutant() {
                                                                                                                                                                        // Create a mock XYDataset
                                                                                                                                                                        XYDataset dataset = mock(XYDataset.class);
                                                                                                                                                                
                                                                                                                                                                        // Create a mock XYItemRenderer
                                                                                                                                                                        XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                                                                                                
                                                                                                                                                                        // Set up the renderer to return null for getAnnotations()
                                                                                                                                                                        when(renderer.getAnnotations()).thenReturn(null);
                                                                                                                                                                
                                                                                                                                                                        // Mock the findDomainBounds method to return a specific range
                                                                                                                                                                        Range expectedRange = new Range(1.0, 5.0);
                                                                                                                                                                        when(renderer.findDomainBounds(dataset)).thenReturn(expectedRange);
                                                                                                                                                                
                                                                                                                                                                        // Create an instance of XYPlot with the mocked dataset and renderer
                                                                                                                                                                        XYPlot plot = new XYPlot(dataset, null, null, renderer);
                                                                                                                                                                
                                                                                                                                                                        // Assume axis is a mock or a real instance that fits the test
                                                                                                                                                                        ValueAxis axis = mock(ValueAxis.class);
                                                                                                                                                                        when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                                                                                                        when(plot.getRangeAxisIndex(axis)).thenReturn(-1);
                                                                                                                                                                
                                                                                                                                                                        // Call the method under test
                                                                                                                                                                        Range result = plot.getDataRange(axis);
                                                                                                                                                                
                                                                                                                                                                        // Assert that the result is the expected range
                                                                                                                                                                        assertEquals("The range should be combined even if renderer's annotations are null", expectedRange, result);
                                                                                                                                                                    }

    @Test
                                                                                                                                                            public void testGetDataRangeWithNullAnnotation() {
                                                                                                                                                                // Create mocks for the necessary objects
                                                                                                                                                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                                                                XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                                                                XYPlot plot = new XYPlot();
                                                                                                                                                        
                                                                                                                                                                // Mock the behavior of getAnnotations to return a collection containing null
                                                                                                                                                                Collection<XYAnnotation> annotationsWithNull = new ArrayList<>();
                                                                                                                                                                annotationsWithNull.add(null);
                                                                                                                                                                when(mockRenderer.getAnnotations()).thenReturn(annotationsWithNull);
                                                                                                                                                        
                                                                                                                                                                // Mock the behavior of findDomainBounds and findRangeBounds
                                                                                                                                                                when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(null);
                                                                                                                                                                when(mockRenderer.findRangeBounds(mockDataset)).thenReturn(null);
                                                                                                                                                        
                                                                                                                                                                // Mock the behavior of getDatasetsMappedToDomainAxis and getDatasetsMappedToRangeAxis
                                                                                                                                                                List<XYDataset> datasets = Collections.singletonList(mockDataset);
                                                                                                                                                                plot.setDataset(0, mockDataset);
                                                                                                                                                                plot.setRenderer(0, mockRenderer);
                                                                                                                                                        
                                                                                                                                                                // Call the method under test
                                                                                                                                                                Range result = plot.getDataRange(null);
                                                                                                                                                        
                                                                                                                                                                // Assert that the result is null, as no valid range should be calculated
                                                                                                                                                                assertNull(result);
                                                                                                                                                        
                                                                                                                                                                // Verify that the getAnnotations method was called
                                                                                                                                                                verify(mockRenderer).getAnnotations();
                                                                                                                                                            }

    @Test
                                                                                                                                        public void testGetDataRangeWithAnnotations2() throws Exception {
                                                                                                                                            // Arrange
                                                                                                                                            XYPlot plot = new XYPlot(); // Create an instance of XYPlot
                                                                                                                                            XYItemRenderer renderer = mock(XYItemRenderer.class); // Mock the renderer
                                                                                                                                            XYAnnotation annotation = mock(XYAnnotation.class); // Mock the annotation
                                                                                                                                    
                                                                                                                                            List<XYAnnotation> annotations = new ArrayList<>();
                                                                                                                                            annotations.add(annotation);
                                                                                                                                    
                                                                                                                                            // Mocking the methods using reflection if they are not accessible directly
                                                                                                                                            when(renderer.getAnnotations()).thenReturn(annotations);
                                                                                                                                    
                                                                                                                                            // Assuming these methods exist in the real class, otherwise, you need to adjust accordingly
                                                                                                                                            Method getIncludeInDataBounds = annotation.getClass().getMethod("getIncludeInDataBounds");
                                                                                                                                            Method getXRange = annotation.getClass().getMethod("getXRange");
                                                                                                                                            Method getYRange = annotation.getClass().getMethod("getYRange");
                                                                                                                                    
                                                                                                                                            when(getIncludeInDataBounds.invoke(annotation)).thenReturn(true);
                                                                                                                                            when(getXRange.invoke(annotation)).thenReturn(new Range(1.0, 2.0));
                                                                                                                                            when(getYRange.invoke(annotation)).thenReturn(new Range(3.0, 4.0));
                                                                                                                                    
                                                                                                                                            plot.addAnnotation(annotation);
                                                                                                                                    
                                                                                                                                            // Act
                                                                                                                                            Range result = plot.getDataRange(null);
                                                                                                                                    
                                                                                                                                            // Assert
                                                                                                                                            assertNotNull("Resulting range should not be null", result);
                                                                                                                                            assertTrue("Annotation should be included in the data range", result.contains(1.0) && result.contains(2.0));
                                                                                                                                        }

    @Test
                                                                                                                        public void testGetDataRangeWithAnnotations3() {
                                                                                                                            // Create mock objects
                                                                                                                            XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                                                            XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                                                            XYDataset mockDataset = mock(XYDataset.class);
                                                                                                                            XYPlot plot = new XYPlot();
                                                                                                                    
                                                                                                                            // Mock the behavior of the annotation using reflection
                                                                                                                            try {
                                                                                                                                when(mockAnnotation.getClass().getMethod("getIncludeInDataBounds").invoke(mockAnnotation)).thenReturn(true);
                                                                                                                                when(mockAnnotation.getClass().getMethod("getXRange").invoke(mockAnnotation)).thenReturn(new Range(1.0, 2.0));
                                                                                                                                when(mockAnnotation.getClass().getMethod("getYRange").invoke(mockAnnotation)).thenReturn(new Range(3.0, 4.0));
                                                                                                                            } catch (Exception e) {
                                                                                                                                e.printStackTrace();
                                                                                                                            }
                                                                                                                    
                                                                                                                            // Mock the behavior of the dataset and renderer
                                                                                                                            when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(5.0, 6.0));
                                                                                                                            when(mockRenderer.findRangeBounds(mockDataset)).thenReturn(new Range(7.0, 8.0));
                                                                                                                            when(plot.getRendererForDataset(mockDataset)).thenReturn(mockRenderer);
                                                                                                                    
                                                                                                                            // Add dataset to plot
                                                                                                                            plot.setDataset(0, mockDataset);
                                                                                                                    
                                                                                                                            // Add annotation to plot
                                                                                                                            plot.addAnnotation(mockAnnotation);
                                                                                                                    
                                                                                                                            // Call the method under test
                                                                                                                            Range result = plot.getDataRange(null);
                                                                                                                    
                                                                                                                            // Verify that the annotation was added to the includedAnnotations list
                                                                                                                            List<XYAnnotation> annotations = plot.getAnnotations();
                                                                                                                            assertEquals(1, annotations.size());
                                                                                                                            assertEquals(mockAnnotation, annotations.get(0));
                                                                                                                    
                                                                                                                            // Verify the range result
                                                                                                                            Range expectedRange = Range.combine(new Range(5.0, 6.0), new Range(1.0, 2.0));
                                                                                                                            expectedRange = Range.combine(expectedRange, new Range(7.0, 8.0));
                                                                                                                            assertEquals(expectedRange, result);
                                                                                                                        }

    @Test
                                                                                                                public void testGetDataRangeCapturesMutant() {
                                                                                                                    // Create a mock plot and axis
                                                                                                                    XYPlot plot = new XYPlot();
                                                                                                                    ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                            
                                                                                                                    // Create a mock annotation
                                                                                                                    XYAnnotation mockAnnotation1 = mock(XYAnnotation.class);
                                                                                                            
                                                                                                                    // Add the mock annotation to the plot
                                                                                                                    plot.addAnnotation(mockAnnotation1);
                                                                                                            
                                                                                                                    // Call the method under test
                                                                                                                    Range result = plot.getDataRange(mockAxis);
                                                                                                            
                                                                                                                    // Verify that only the annotations that should be included are added
                                                                                                                    List<XYAnnotation> expectedAnnotations = new ArrayList<>();
                                                                                                                    expectedAnnotations.add(mockAnnotation1);
                                                                                                            
                                                                                                                    // Check that the includedAnnotations list only contains the expected annotation
                                                                                                                    assertEquals(1, plot.getAnnotations().size());
                                                                                                                    assertTrue(plot.getAnnotations().containsAll(expectedAnnotations));
                                                                                                                }

    @Test
                                                                                                    public void testGetDataRangeDetectsMutant3() {
                                                                                                        // Create a mock XYPlot
                                                                                                        XYPlot plot = new XYPlot();
                                                                                                
                                                                                                        // Create a mock XYAnnotation
                                                                                                        XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                                
                                                                                                        // Add the mock annotation to the plot
                                                                                                        plot.addAnnotation(mockAnnotation);
                                                                                                
                                                                                                        // Create a mock ValueAxis
                                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                                
                                                                                                        // Execute the method under test
                                                                                                        Range result = plot.getDataRange(mockAxis);
                                                                                                
                                                                                                        // Verify the includedAnnotations list contains XYAnnotation objects
                                                                                                        List<XYAnnotation> includedAnnotations = plot.getAnnotations();
                                                                                                        assertTrue("The includedAnnotations list should contain XYAnnotation objects",
                                                                                                                   includedAnnotations.stream().allMatch(a -> a instanceof XYAnnotation));
                                                                                                    }

    @Test
                                                                                    public void testGetDataRangeDetectsMutant4() {
                                                                                        // Arrange
                                                                                        XYPlot plot = new XYPlot();
                                                                                        XYDataset mockDataset = mock(XYDataset.class);
                                                                                        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                                        XYAnnotation mockAnnotation = mock(XYAnnotation.class);
                                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                                        
                                                                                        // Assuming that getIncludeInDataBounds() and getAnnotations() are not available,
                                                                                        // we will directly add the annotation to the plot.
                                                                                        plot.addAnnotation(mockAnnotation);
                                                                                        
                                                                                        when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 5.0));
                                                                                        
                                                                                        plot.setDataset(0, mockDataset);
                                                                                        plot.setRenderer(0, mockRenderer);
                                                                                        
                                                                                        // Act
                                                                                        Range result = plot.getDataRange(mockAxis);
                                                                                        
                                                                                        // Assert
                                                                                        // Verify that the includedAnnotations list contains the actual annotation, not its class
                                                                                        List<XYAnnotation> annotations = plot.getAnnotations();
                                                                                        assertTrue("The annotation should be included in the list", annotations.contains(mockAnnotation));
                                                                                        assertFalse("The list should not contain the class of the annotation", annotations.contains(mockAnnotation.getClass()));
                                                                                        
                                                                                        // Verify the result range
                                                                                        assertNotNull("The result range should not be null", result);
                                                                                        assertEquals("The result range should match the expected range", new Range(1.0, 5.0), result);
                                                                                    }

    @Test
                                                                                public void testGetDataRangeWithRenderer() {
                                                                                    // Mock objects
                                                                                    XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                                                    XYDataset dataset = mock(XYDataset.class);
                                                                                    XYPlot plot = new XYPlot(dataset, null, null, renderer);
                                                                                    Range rendererRange = new Range(0.0, 1.0);
                                                                                    Range utilityRange = new Range(0.0, 1.0);
                                                                                    ValueAxis axis = mock(ValueAxis.class);
                                                                            
                                                                                    // Mock the behavior of the renderer and dataset utilities
                                                                                    when(renderer.findDomainBounds(dataset)).thenReturn(rendererRange);
                                                                                    when(renderer.findRangeBounds(dataset)).thenReturn(rendererRange);
                                                                                    when(DatasetUtilities.findDomainBounds(dataset)).thenReturn(utilityRange);
                                                                                    when(DatasetUtilities.findRangeBounds(dataset)).thenReturn(utilityRange);
                                                                            
                                                                                    // Assume the axis is a domain axis
                                                                                    when(plot.getDomainAxisIndex(axis)).thenReturn(0);
                                                                                    when(plot.getRangeAxisIndex(axis)).thenReturn(-1);
                                                                            
                                                                                    // Call the method under test
                                                                                    Range result = plot.getDataRange(axis);
                                                                            
                                                                                    // Verify that the renderer's range is used
                                                                                    assertEquals("Renderer's range should be used when renderer is not null", rendererRange, result);
                                                                            
                                                                                    // Verify interactions
                                                                                    verify(renderer, times(1)).findDomainBounds(dataset);
                                                                                    verify(renderer, never()).findRangeBounds(dataset);
                                                                                    verifyNoMoreInteractions(renderer);
                                                                                }

    @Test
                                                                    public void testGetDataRangeDetectsMutant5() {
                                                                        // Create mock objects for the dataset and renderer
                                                                        XYDataset mockDataset = mock(XYDataset.class);
                                                                        XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                                    
                                                                        // Create an instance of XYPlot and set up the plot with the mock dataset and renderer
                                                                        XYPlot xyPlot = new XYPlot();
                                                                        xyPlot.setDataset(0, mockDataset);
                                                                        xyPlot.setRenderer(0, mockRenderer);
                                                                    
                                                                        // Assume the axis is a domain axis
                                                                        ValueAxis mockAxis = mock(ValueAxis.class);
                                                                        when(xyPlot.getDomainAxisIndex(mockAxis)).thenReturn(0);
                                                                        when(xyPlot.getRangeAxisIndex(mockAxis)).thenReturn(-1);
                                                                    
                                                                        // Call the method under test
                                                                        Range result = xyPlot.getDataRange(mockAxis);
                                                                    
                                                                        // Verify that the result includes the range from the annotation
                                                                        Range expectedRange = Range.combine(new Range(1.0, 5.0), new Range(3.0, 4.0));
                                                                        assertEquals(expectedRange, result);
                                                                    }

    @Test
                                                        public void testGetDataRangeDetectsMutant6() {
                                                            // Create a mock annotation
                                                            XYAnnotation annotation = mock(XYAnnotation.class);
                                                        
                                                            // Set up the mock renderer to return a collection with one annotation
                                                            Collection<XYAnnotation> annotations = new ArrayList<>();
                                                            annotations.add(annotation);
                                                        
                                                            // Create a mock renderer
                                                            XYItemRenderer renderer = mock(XYItemRenderer.class);
                                                            when(renderer.getAnnotations()).thenReturn(annotations);
                                                        
                                                            // Since we don't have getIncludeInDataBounds, getXRange, and getYRange methods,
                                                            // we need to assume the logic that would use these methods.
                                                            // For this example, let's assume we are checking if the annotation affects the data range.
                                                        
                                                            // Create a mock plot and set the renderer
                                                            XYPlot plot = new XYPlot();
                                                            plot.setRenderer(renderer);
                                                        
                                                            // Set up the domain axis to be mapped
                                                            ValueAxis domainAxis = mock(ValueAxis.class);
                                                            when(plot.getDomainAxisIndex(domainAxis)).thenReturn(0);
                                                        
                                                            // Call the method under test
                                                            Range result = plot.getDataRange(domainAxis);
                                                        
                                                            // Verify that the result includes the annotation's range
                                                            // Since we don't have the actual logic for getXRange, let's assume a range for testing
                                                            Range expectedRange = new Range(1.0, 2.0); // This should be the expected range based on the annotation logic
                                                            assertNotNull("Resulting range should not be null", result);
                                                            assertEquals("Resulting X range should match annotation's X range", expectedRange, result);
                                                        }

    @Test
                                            public void testGetDataRangeDetectsMutation() {
                                                // Arrange: Create mock objects
                                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                                                XYDataset mockDataset = mock(XYDataset.class);
                                                ValueAxis mockAxis = mock(ValueAxis.class);
                                            
                                                // Create an instance of XYPlot with mock objects
                                                XYPlot plot = new XYPlot(mockDataset, mockAxis, null, mockRenderer);
                                            
                                                // Set up the mock behavior
                                                when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 2.0));
                                            
                                                // Act: Call the method under test
                                                Range result = plot.getDataRange(mockAxis);
                                            
                                                // Assert: Verify the result
                                                assertNotNull("Resulting range should not be null", result);
                                                assertEquals("Range should be combined correctly with annotations", new Range(1.0, 2.0), result);
                                            }

    @Test
                                    public void testGetDataRangeWithAnnotations4() {
                                        // Create mock objects
                                        XYDataset dataset = mock(XYDataset.class);
                                        XYItemRenderer renderer = mock(XYItemRenderer.class);
                                        XYAnnotation annotation = mock(XYAnnotation.class);
                                
                                        // Create an instance of XYPlot with the mock dataset and renderer
                                        XYPlot plot = new XYPlot(dataset, null, null, renderer);
                                
                                        // Set up the mock behavior
                                        when(renderer.findDomainBounds(dataset)).thenReturn(new Range(1.0, 5.0));
                                        when(renderer.getAnnotations()).thenReturn(Collections.singletonList(annotation));
                                
                                        try {
                                            // Use reflection to simulate the behavior of getIncludeInDataBounds()
                                            Method getIncludeInDataBoundsMethod = annotation.getClass().getMethod("getIncludeInDataBounds");
                                            when((Boolean) getIncludeInDataBoundsMethod.invoke(annotation)).thenReturn(true);
                                
                                            // Use reflection to simulate the behavior of getXRange()
                                            Method getXRangeMethod = annotation.getClass().getMethod("getXRange");
                                            when((Range) getXRangeMethod.invoke(annotation)).thenReturn(new Range(2.0, 4.0));
                                        } catch (Exception e) {
                                            fail("Reflection failed: " + e.getMessage());
                                        }
                                
                                        // Call the method under test
                                        Range result = plot.getDataRange(null); // Assuming null axis for simplicity
                                
                                        // Verify the expected behavior
                                        assertNotNull("Resulting range should not be null", result);
                                        assertEquals("Resulting range should combine dataset and annotation ranges", new Range(1.0, 5.0), result);
                                    }

    @Test
                            public void testGetDataRangeDetectsMutant7() {
                                // Create mock objects for the dataset and renderer
                                XYDataset mockDataset = mock(XYDataset.class);
                                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                        
                                // Setup the mock renderer to return a collection with a size > 0 but no elements
                                Collection<XYAnnotation> annotations = mock(Collection.class);
                                when(annotations.size()).thenReturn(1); // Size > 0
                                when(annotations.iterator()).thenReturn(new ArrayList<XYAnnotation>().iterator()); // Empty iterator
                        
                                when(mockRenderer.getAnnotations()).thenReturn(annotations);
                                when(mockDataset.getItemCount(0)).thenReturn(1);
                        
                                // Create an instance of XYPlot and add the mock dataset and renderer to the plot
                                XYPlot plot = new XYPlot();
                                plot.setDataset(0, mockDataset);
                                plot.setRenderer(0, mockRenderer);
                        
                                // Call the method under test
                                Range result = plot.getDataRange(null);
                        
                                // Assert that the result is null, indicating the mutant was detected
                                assertNull("The result should be null if the mutant is detected", result);
                            }

    @Test
            public void testGetDataRangeWithNullRendererAnnotations() {
                // Arrange
                XYPlot plot = new XYPlot();
                XYItemRenderer mockRenderer = mock(XYItemRenderer.class);
                XYDataset mockDataset = mock(XYDataset.class);
                ValueAxis mockAxis = mock(ValueAxis.class);
        
                // Assuming XYAnnotation is an interface or class that doesn't have the methods
                // getIncludeInDataBounds, getXRange, getYRange, we will not mock these methods.
                XYAnnotation mockAnnotationBoundsInfo = mock(XYAnnotation.class);
        
                when(mockRenderer.getAnnotations()).thenReturn(null); // Simulate null annotations
                when(mockRenderer.findDomainBounds(mockDataset)).thenReturn(new Range(1.0, 10.0));
                when(mockRenderer.findRangeBounds(mockDataset)).thenReturn(new Range(5.0, 15.0));
        
                // Add the renderer and dataset to the plot
                plot.setRenderer(mockRenderer);
                plot.setDataset(mockDataset);
        
                // Act
                Range result = plot.getDataRange(mockAxis);
        
                // Assert
                assertNotNull("Expected non-null range result", result);
                assertEquals("Unexpected range result", new Range(1.0, 10.0), result);
            }

    @Test
        public void testGetDataRangeDetectsMutant8() {
            // Mock the behavior of getAnnotations to return a collection containing null
            Collection<XYAnnotation> annotations = new ArrayList<>();
            annotations.add(null); // Add null to trigger the mutant behavior
            when(renderer.getAnnotations()).thenReturn(annotations);
    
            // Mock the behavior of other necessary methods
            when(plot.getDatasetsMappedToDomainAxis(anyInt())).thenReturn(List.of(dataset));
            when(plot.getDatasetsMappedToRangeAxis(anyInt())).thenReturn(List.of(dataset));
            when(plot.getRendererForDataset(dataset)).thenReturn(renderer);
            when(plot.getDomainAxisIndex(any(ValueAxis.class))).thenReturn(0);
            when(plot.getRangeAxisIndex(any(ValueAxis.class))).thenReturn(-1); // Ensure it's a domain axis
    
            // Call the method under test
            Range result = plot.getDataRange(mock(ValueAxis.class));
    
            // Assert that the result is as expected
            // Since the mutant changes the loop condition, the presence of null should affect the result
            // In this case, we expect the result to be null because the original loop would not process null
            assertNull("The result should be null because the original loop does not process null annotations", result);
        }

}
