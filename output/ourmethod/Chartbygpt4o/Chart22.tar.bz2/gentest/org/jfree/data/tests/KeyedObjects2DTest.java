package gentest.org.jfree.data.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.*;
import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
 
public class KeyedObjects2DTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

}
