package gentest.org.jfree.data.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.jfree.data.general.*;
import org.jfree.data.pie.PieDataset;
import org.jfree.data.pie.DefaultPieDataset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jfree.chart.util.ArrayUtilities;
import org.jfree.data.DomainInfo;
import org.jfree.data.KeyToGroupMap;
import org.jfree.data.KeyedValues;
import org.jfree.data.Range;
import org.jfree.data.RangeInfo;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryRangeInfo;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.function.Function2D;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.BoxAndWhiskerXYDataset;
import org.jfree.data.statistics.MultiValueCategoryDataset;
import org.jfree.data.statistics.StatisticalCategoryDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.OHLCDataset;
import org.jfree.data.xy.TableXYDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYDomainInfo;
import org.jfree.data.xy.XYRangeInfo;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
 
public class DatasetUtilitiesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testIterateDomainBounds_NullDataset() {
                                                    // Test when the dataset is null
                                                    thrown.expect(IllegalArgumentException.class);
                                                    DatasetUtilities.iterateDomainBounds(null);
                                                }

    @Test
                                                public void testIterateRangeBounds_TypicalDataset() {
                                                    // Mocking a typical XYDataset
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(2);
                                                    when(dataset.getItemCount(0)).thenReturn(3);
                                                    when(dataset.getItemCount(1)).thenReturn(3);
                                                    
                                                    // Mocking values for the dataset
                                                    when(dataset.getYValue(0, 0)).thenReturn(1.0);
                                                    when(dataset.getYValue(0, 1)).thenReturn(2.0);
                                                    when(dataset.getYValue(0, 2)).thenReturn(3.0);
                                                    when(dataset.getYValue(1, 0)).thenReturn(4.0);
                                                    when(dataset.getYValue(1, 1)).thenReturn(5.0);
                                                    when(dataset.getYValue(1, 2)).thenReturn(6.0);
                                            
                                                    // Call the method under test
                                                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                            
                                                    // Assert the expected range
                                                    assertEquals(new Range(1.0, 6.0), result);
                                                }

    @Test
                                                public void testIterateRangeBounds_EmptyDataset() {
                                                    // Mocking an empty XYDataset
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(0);
                                            
                                                    // Call the method under test
                                                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                            
                                                    // Assert that the range is null for an empty dataset
                                                    assertNull(result);
                                                }

    @Test
                                                public void testIterateRangeBounds_SingleValueDataset() {
                                                    // Mocking a dataset with a single value
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                    when(dataset.getItemCount(0)).thenReturn(1);
                                                    when(dataset.getYValue(0, 0)).thenReturn(5.0);
                                            
                                                    // Call the method under test
                                                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                            
                                                    // Assert the expected range
                                                    assertEquals(new Range(5.0, 5.0), result);
                                                }

    @Test
                                                public void testIterateRangeBounds_NegativeValuesDataset() {
                                                    // Mocking a dataset with negative values
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                    when(dataset.getItemCount(0)).thenReturn(3);
                                                    when(dataset.getYValue(0, 0)).thenReturn(-3.0);
                                                    when(dataset.getYValue(0, 1)).thenReturn(-2.0);
                                                    when(dataset.getYValue(0, 2)).thenReturn(-1.0);
                                            
                                                    // Call the method under test
                                                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                            
                                                    // Assert the expected range
                                                    assertEquals(new Range(-3.0, -1.0), result);
                                                }

    @Test
                                                public void testIterateRangeBounds_MixedValuesDataset() {
                                                    // Mocking a dataset with mixed positive and negative values
                                                    XYDataset dataset = mock(XYDataset.class);
                                                    when(dataset.getSeriesCount()).thenReturn(1);
                                                    when(dataset.getItemCount(0)).thenReturn(3);
                                                    when(dataset.getYValue(0, 0)).thenReturn(-1.0);
                                                    when(dataset.getYValue(0, 1)).thenReturn(0.0);
                                                    when(dataset.getYValue(0, 2)).thenReturn(1.0);
                                            
                                                    // Call the method under test
                                                    Range result = DatasetUtilities.iterateRangeBounds(dataset, true);
                                            
                                                    // Assert the expected range
                                                    assertEquals(new Range(-1.0, 1.0), result);
                                                }

    @Test
                                                public void testIterateRangeBounds_CategoryDataset_TypicalValues() {
                                                    CategoryDataset mockDataset = mock(CategoryDataset.class);
                                                    // Assuming the dataset is not empty and has typical values
                                                    when(mockDataset.getRowCount()).thenReturn(3);
                                                    when(mockDataset.getColumnCount()).thenReturn(3);
                                                    // Mocking behavior for typical values
                                                    when(mockDataset.getValue(0, 0)).thenReturn(1.0);
                                                    when(mockDataset.getValue(0, 1)).thenReturn(2.0);
                                                    when(mockDataset.getValue(0, 2)).thenReturn(3.0);
                                                    when(mockDataset.getValue(1, 0)).thenReturn(4.0);
                                                    when(mockDataset.getValue(1, 1)).thenReturn(5.0);
                                                    when(mockDataset.getValue(1, 2)).thenReturn(6.0);
                                                    when(mockDataset.getValue(2, 0)).thenReturn(7.0);
                                                    when(mockDataset.getValue(2, 1)).thenReturn(8.0);
                                                    when(mockDataset.getValue(2, 2)).thenReturn(9.0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(9.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_CategoryDataset_EmptyDataset() {
                                                    CategoryDataset mockDataset = mock(CategoryDataset.class);
                                                    // Assuming the dataset is empty
                                                    when(mockDataset.getRowCount()).thenReturn(0);
                                                    when(mockDataset.getColumnCount()).thenReturn(0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testIterateRangeBounds_CategoryDataset_NullValues() {
                                                    CategoryDataset mockDataset = mock(CategoryDataset.class);
                                                    // Assuming the dataset contains null values
                                                    when(mockDataset.getRowCount()).thenReturn(2);
                                                    when(mockDataset.getColumnCount()).thenReturn(2);
                                                    when(mockDataset.getValue(0, 0)).thenReturn(null);
                                                    when(mockDataset.getValue(0, 1)).thenReturn(2.0);
                                                    when(mockDataset.getValue(1, 0)).thenReturn(3.0);
                                                    when(mockDataset.getValue(1, 1)).thenReturn(null);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(3.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_XYDataset_TypicalValues() {
                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                    // Assuming the dataset is not empty and has typical values
                                                    when(mockDataset.getSeriesCount()).thenReturn(2);
                                                    when(mockDataset.getItemCount(0)).thenReturn(3);
                                                    when(mockDataset.getItemCount(1)).thenReturn(3);
                                                    // Mocking behavior for typical values
                                                    when(mockDataset.getYValue(0, 0)).thenReturn(1.0);
                                                    when(mockDataset.getYValue(0, 1)).thenReturn(2.0);
                                                    when(mockDataset.getYValue(0, 2)).thenReturn(3.0);
                                                    when(mockDataset.getYValue(1, 0)).thenReturn(4.0);
                                                    when(mockDataset.getYValue(1, 1)).thenReturn(5.0);
                                                    when(mockDataset.getYValue(1, 2)).thenReturn(6.0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_XYDataset_EmptyDataset() {
                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                    // Assuming the dataset is empty
                                                    when(mockDataset.getSeriesCount()).thenReturn(0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testIterateRangeBounds_XYDataset_NullValues() {
                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                    // Assuming the dataset contains null values
                                                    when(mockDataset.getSeriesCount()).thenReturn(1);
                                                    when(mockDataset.getItemCount(0)).thenReturn(2);
                                                    when(mockDataset.getYValue(0, 0)).thenReturn(Double.NaN);
                                                    when(mockDataset.getYValue(0, 1)).thenReturn(2.0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(2.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_IntervalXYDataset() {
                                                    IntervalXYDataset mockDataset = mock(IntervalXYDataset.class);
                                                    when(mockDataset.getSeriesCount()).thenReturn(1);
                                                    when(mockDataset.getItemCount(0)).thenReturn(3);
                                                    when(mockDataset.getYValue(0, 0)).thenReturn(2.0);
                                                    when(mockDataset.getStartYValue(0, 0)).thenReturn(1.0);
                                                    when(mockDataset.getEndYValue(0, 0)).thenReturn(3.0);
                                                    when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                    when(mockDataset.getStartYValue(0, 1)).thenReturn(4.0);
                                                    when(mockDataset.getEndYValue(0, 1)).thenReturn(5.0);
                                                    when(mockDataset.getYValue(0, 2)).thenReturn(6.0);
                                                    when(mockDataset.getStartYValue(0, 2)).thenReturn(Double.NaN);
                                                    when(mockDataset.getEndYValue(0, 2)).thenReturn(7.0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(1.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(7.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_OHLCDataset() {
                                                    OHLCDataset mockDataset = mock(OHLCDataset.class);
                                                    when(mockDataset.getSeriesCount()).thenReturn(1);
                                                    when(mockDataset.getItemCount(0)).thenReturn(3);
                                                    when(mockDataset.getLowValue(0, 0)).thenReturn(2.0);
                                                    when(mockDataset.getHighValue(0, 0)).thenReturn(3.0);
                                                    when(mockDataset.getLowValue(0, 1)).thenReturn(Double.NaN);
                                                    when(mockDataset.getHighValue(0, 1)).thenReturn(5.0);
                                                    when(mockDataset.getLowValue(0, 2)).thenReturn(6.0);
                                                    when(mockDataset.getHighValue(0, 2)).thenReturn(Double.NaN);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, true);
                                                    assertNotNull(result);
                                                    assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(5.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_XYDataset() {
                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                    when(mockDataset.getSeriesCount()).thenReturn(1);
                                                    when(mockDataset.getItemCount(0)).thenReturn(3);
                                                    when(mockDataset.getYValue(0, 0)).thenReturn(2.0);
                                                    when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                    when(mockDataset.getYValue(0, 2)).thenReturn(6.0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, false);
                                                    assertNotNull(result);
                                                    assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                    assertEquals(6.0, result.getUpperBound(), 0.0001);
                                                }

    @Test
                                                public void testIterateRangeBounds_EmptyDataset1() {
                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                    when(mockDataset.getSeriesCount()).thenReturn(0);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, false);
                                                    assertNull(result);
                                                }

    @Test
                                                public void testIterateRangeBounds_AllNaNValues() {
                                                    XYDataset mockDataset = mock(XYDataset.class);
                                                    when(mockDataset.getSeriesCount()).thenReturn(1);
                                                    when(mockDataset.getItemCount(0)).thenReturn(3);
                                                    when(mockDataset.getYValue(0, 0)).thenReturn(Double.NaN);
                                                    when(mockDataset.getYValue(0, 1)).thenReturn(Double.NaN);
                                                    when(mockDataset.getYValue(0, 2)).thenReturn(Double.NaN);
                                            
                                                    Range result = DatasetUtilities.iterateRangeBounds(mockDataset, false);
                                                    assertNull(result);
                                                }

    @Test
                                            public void testIterateDomainBounds_EmptyDataset() {
                                                // Create a mock XYDataset
                                                XYDataset mockDataset = mock(XYDataset.class);
                                        
                                                // Set up the mock to return 0 series count
                                                when(mockDataset.getSeriesCount()).thenReturn(0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateDomainBounds(mockDataset);
                                        
                                                // Assert that the result is null for an empty dataset
                                                assertNull("Expected null range for empty dataset", result);
                                            }

    @Test
                                            public void testIterateDomainBounds_MultiplePoints() {
                                                // Create a mock XYDataset
                                                XYDataset mockDataset = mock(XYDataset.class);
                                        
                                                // Set up the mock dataset to return specific values
                                                when(mockDataset.getSeriesCount()).thenReturn(1);
                                                when(mockDataset.getItemCount(0)).thenReturn(3);
                                                when(mockDataset.getXValue(0, 0)).thenReturn(1.0);
                                                when(mockDataset.getXValue(0, 1)).thenReturn(3.0);
                                                when(mockDataset.getXValue(0, 2)).thenReturn(2.0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateDomainBounds(mockDataset);
                                        
                                                // Assert that the result is as expected
                                                assertEquals("Expected range from 1.0 to 3.0", new Range(1.0, 3.0), result);
                                            }

    @Test
                                            public void testIterateDomainBounds_MultipleSeries() {
                                                // Create a mock dataset
                                                XYDataset mockDataset = mock(XYDataset.class);
                                        
                                                // Define the behavior of the mock dataset
                                                when(mockDataset.getSeriesCount()).thenReturn(2);
                                                when(mockDataset.getItemCount(0)).thenReturn(2);
                                                when(mockDataset.getItemCount(1)).thenReturn(2);
                                                when(mockDataset.getXValue(0, 0)).thenReturn(1.0);
                                                when(mockDataset.getXValue(0, 1)).thenReturn(4.0);
                                                when(mockDataset.getXValue(1, 0)).thenReturn(2.0);
                                                when(mockDataset.getXValue(1, 1)).thenReturn(5.0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateDomainBounds(mockDataset);
                                        
                                                // Assert the expected outcome
                                                assertEquals("Expected range from 1.0 to 5.0", new Range(1.0, 5.0), result);
                                            }

    @Test
                                        public void testIterateDomainBounds_EmptyDataset1() {
                                            // Mocking the XYDataset
                                            XYDataset mockDataset = mock(XYDataset.class);
                                        
                                            // Defining the behavior of the mocked dataset
                                            when(mockDataset.getSeriesCount()).thenReturn(0);
                                        
                                            // Calling the method under test
                                            Range result = DatasetUtilities.iterateDomainBounds(mockDataset, false);
                                        
                                            // Verifying the result
                                            assertNull(result);
                                        }

    @Test
                                            public void testIterateDomainBounds_IntervalDataset() {
                                                // Create a mock IntervalXYDataset
                                                IntervalXYDataset mockIntervalDataset = mock(IntervalXYDataset.class);
                                        
                                                // Define the behavior of the mock object
                                                when(mockIntervalDataset.getSeriesCount()).thenReturn(1);
                                                when(mockIntervalDataset.getItemCount(0)).thenReturn(3);
                                                when(mockIntervalDataset.getXValue(0, 0)).thenReturn(1.0);
                                                when(mockIntervalDataset.getStartXValue(0, 0)).thenReturn(0.5);
                                                when(mockIntervalDataset.getEndXValue(0, 0)).thenReturn(1.5);
                                                when(mockIntervalDataset.getXValue(0, 1)).thenReturn(2.0);
                                                when(mockIntervalDataset.getStartXValue(0, 1)).thenReturn(1.5);
                                                when(mockIntervalDataset.getEndXValue(0, 1)).thenReturn(2.5);
                                                when(mockIntervalDataset.getXValue(0, 2)).thenReturn(3.0);
                                                when(mockIntervalDataset.getStartXValue(0, 2)).thenReturn(2.5);
                                                when(mockIntervalDataset.getEndXValue(0, 2)).thenReturn(3.5);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateDomainBounds(mockIntervalDataset, true);
                                        
                                                // Verify the results
                                                assertNotNull(result);
                                                assertEquals(0.5, result.getLowerBound(), 0.0001);
                                                assertEquals(3.5, result.getUpperBound(), 0.0001);
                                            }

    @Test
                                        public void testIterateDomainBounds_NonIntervalDataset() {
                                            // Create a mock dataset using Mockito
                                            XYDataset mockDataset = mock(XYDataset.class);
                                        
                                            // Define the behavior of the mock object
                                            when(mockDataset.getSeriesCount()).thenReturn(1);
                                            when(mockDataset.getItemCount(0)).thenReturn(3);
                                            when(mockDataset.getXValue(0, 0)).thenReturn(1.0);
                                            when(mockDataset.getXValue(0, 1)).thenReturn(2.0);
                                            when(mockDataset.getXValue(0, 2)).thenReturn(3.0);
                                        
                                            // Call the method under test
                                            Range result = DatasetUtilities.iterateDomainBounds(mockDataset, false);
                                        
                                            // Assert the results
                                            assertNotNull(result);
                                            assertEquals(1.0, result.getLowerBound(), 0.0001);
                                            assertEquals(3.0, result.getUpperBound(), 0.0001);
                                        }

    @Test
                                            public void testIterateDomainBounds_DatasetWithNaNValues() {
                                                // Create a mock XYDataset
                                                XYDataset mockDataset = mock(XYDataset.class);
                                        
                                                // Define the behavior of the mock object
                                                when(mockDataset.getSeriesCount()).thenReturn(1);
                                                when(mockDataset.getItemCount(0)).thenReturn(3);
                                                when(mockDataset.getXValue(0, 0)).thenReturn(Double.NaN);
                                                when(mockDataset.getXValue(0, 1)).thenReturn(2.0);
                                                when(mockDataset.getXValue(0, 2)).thenReturn(Double.NaN);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateDomainBounds(mockDataset, false);
                                        
                                                // Assert the result
                                                assertNotNull(result);
                                                assertEquals(2.0, result.getLowerBound(), 0.0001);
                                                assertEquals(2.0, result.getUpperBound(), 0.0001);
                                            }

    @Test
                                            public void testIterateRangeBounds_NullDataset() {
                                                // Test with a null dataset
                                                Range result = DatasetUtilities.iterateRangeBounds((CategoryDataset) null, false);
                                                assertNull("Expected null range for null dataset", result);
                                            }

    @Test
                                            public void testIterateRangeBounds_EmptyDataset2() {
                                                // Create a mock CategoryDataset
                                                CategoryDataset mockCategoryDataset = mock(CategoryDataset.class);
                                        
                                                // Set up the mock to return 0 for row and column count
                                                when(mockCategoryDataset.getRowCount()).thenReturn(0);
                                                when(mockCategoryDataset.getColumnCount()).thenReturn(0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateRangeBounds(mockCategoryDataset, false);
                                        
                                                // Assert that the result is null
                                                assertNull("Expected null range for empty dataset", result);
                                            }

    @Test
                                            public void testIterateRangeBounds_SingleValue() {
                                                // Create a mock CategoryDataset
                                                CategoryDataset mockCategoryDataset = mock(CategoryDataset.class);
                                        
                                                // Define behavior for the mock
                                                when(mockCategoryDataset.getRowCount()).thenReturn(1);
                                                when(mockCategoryDataset.getColumnCount()).thenReturn(1);
                                                when(mockCategoryDataset.getValue(0, 0)).thenReturn(5.0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateRangeBounds(mockCategoryDataset, false);
                                        
                                                // Perform assertions
                                                assertNotNull("Expected a valid range", result);
                                                assertEquals("Expected minimum value to be 5.0", 5.0, result.getLowerBound(), 0.0001);
                                                assertEquals("Expected maximum value to be 5.0", 5.0, result.getUpperBound(), 0.0001);
                                            }

    @Test
                                        public void testIterateRangeBounds_MultipleValues() {
                                            // Mocking the CategoryDataset
                                            CategoryDataset mockCategoryDataset = mock(CategoryDataset.class);
                                        
                                            // Define behavior for the mocked dataset
                                            when(mockCategoryDataset.getRowCount()).thenReturn(2);
                                            when(mockCategoryDataset.getColumnCount()).thenReturn(2);
                                            when(mockCategoryDataset.getValue(0, 0)).thenReturn(1.0);
                                            when(mockCategoryDataset.getValue(0, 1)).thenReturn(3.0);
                                            when(mockCategoryDataset.getValue(1, 0)).thenReturn(2.0);
                                            when(mockCategoryDataset.getValue(1, 1)).thenReturn(4.0);
                                        
                                            // Call the method under test
                                            Range result = DatasetUtilities.iterateRangeBounds(mockCategoryDataset, false);
                                        
                                            // Assert the result
                                            assertNotNull("Expected a valid range", result);
                                            assertEquals("Expected minimum value to be 1.0", 1.0, result.getLowerBound(), 0.0001);
                                            assertEquals("Expected maximum value to be 4.0", 4.0, result.getUpperBound(), 0.0001);
                                        }

    @Test
                                            public void testIterateRangeBounds_WithNaNValues() {
                                                // Create a mock CategoryDataset
                                                CategoryDataset mockCategoryDataset = mock(CategoryDataset.class);
                                        
                                                // Define the behavior of the mock object
                                                when(mockCategoryDataset.getRowCount()).thenReturn(1);
                                                when(mockCategoryDataset.getColumnCount()).thenReturn(3);
                                                when(mockCategoryDataset.getValue(0, 0)).thenReturn(Double.NaN);
                                                when(mockCategoryDataset.getValue(0, 1)).thenReturn(2.0);
                                                when(mockCategoryDataset.getValue(0, 2)).thenReturn(3.0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateRangeBounds(mockCategoryDataset, false);
                                        
                                                // Validate the results
                                                assertNotNull("Expected a valid range", result);
                                                assertEquals("Expected minimum value to be 2.0", 2.0, result.getLowerBound(), 0.0001);
                                                assertEquals("Expected maximum value to be 3.0", 3.0, result.getUpperBound(), 0.0001);
                                            }

    @Test
                                            public void testIterateRangeBounds_IntervalDataset() {
                                                // Create a mock IntervalCategoryDataset
                                                IntervalCategoryDataset mockIntervalCategoryDataset = mock(IntervalCategoryDataset.class);
                                        
                                                // Set up the mock to return specific values
                                                when(mockIntervalCategoryDataset.getRowCount()).thenReturn(1);
                                                when(mockIntervalCategoryDataset.getColumnCount()).thenReturn(1);
                                                when(mockIntervalCategoryDataset.getValue(0, 0)).thenReturn(5.0);
                                                when(mockIntervalCategoryDataset.getStartValue(0, 0)).thenReturn(4.0);
                                                when(mockIntervalCategoryDataset.getEndValue(0, 0)).thenReturn(6.0);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateRangeBounds(mockIntervalCategoryDataset, true);
                                        
                                                // Assert the results
                                                assertNotNull("Expected a valid range", result);
                                                assertEquals("Expected minimum value to be 4.0", 4.0, result.getLowerBound(), 0.0001);
                                                assertEquals("Expected maximum value to be 6.0", 6.0, result.getUpperBound(), 0.0001);
                                            }

    @Test
                                            public void testIterateRangeBounds_IntervalDatasetWithNaN() {
                                                // Create a mock IntervalCategoryDataset
                                                IntervalCategoryDataset mockIntervalCategoryDataset = mock(IntervalCategoryDataset.class);
                                        
                                                // Define the behavior of the mock
                                                when(mockIntervalCategoryDataset.getRowCount()).thenReturn(1);
                                                when(mockIntervalCategoryDataset.getColumnCount()).thenReturn(1);
                                                when(mockIntervalCategoryDataset.getValue(0, 0)).thenReturn(Double.NaN);
                                                when(mockIntervalCategoryDataset.getStartValue(0, 0)).thenReturn(4.0);
                                                when(mockIntervalCategoryDataset.getEndValue(0, 0)).thenReturn(Double.NaN);
                                        
                                                // Call the method under test
                                                Range result = DatasetUtilities.iterateRangeBounds(mockIntervalCategoryDataset, true);
                                        
                                                // Assert the results
                                                assertNotNull("Expected a valid range", result);
                                                assertEquals("Expected minimum value to be 4.0", 4.0, result.getLowerBound(), 0.0001);
                                                assertEquals("Expected maximum value to be 4.0", 4.0, result.getUpperBound(), 0.0001);
                                            }

    @Test
                                        public void testIterateDomainBounds_SinglePoint() {
                                            // Create a mock XYDataset
                                            XYDataset mockDataset = mock(XYDataset.class);
                                    
                                            // Test with a dataset containing a single point
                                            when(mockDataset.getSeriesCount()).thenReturn(1);
                                            when(mockDataset.getItemCount(0)).thenReturn(1);
                                            when(mockDataset.getXValue(0, 0)).thenReturn(5.0);
                                    
                                            // Call the method under test
                                            Range result = DatasetUtilities.iterateDomainBounds(mockDataset);
                                    
                                            // Verify the result
                                            assertEquals("Expected range with single point", new Range(5.0, 5.0), result);
                                        }

    @Test
        public void testIterateDomainBounds_NullDataset1() {
            // Set up the expected exception
    
            // Call the tested method with null dataset
            DatasetUtilities.iterateDomainBounds(null, true);
        }


}
