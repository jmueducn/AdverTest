package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                             public void testPrintAndQuote_QuoteModeAll() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "test";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"test\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeNonNumeric_WithNumber() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                 StringWriter out = new StringWriter();
                                                 Integer value = 123;
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuoteMethod.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuoteMethod.invoke(
                                                     format, 
                                                     value, 
                                                     value.toString(), 
                                                     0, 
                                                     value.toString().length(), 
                                                     out, 
                                                     false
                                                 );
                                                 
                                                 // Verify
                                                 assertEquals("123", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeNonNumeric_WithString() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                 StringWriter out = new StringWriter();
                                                 String value = "test";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"test\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeNone() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                                 StringWriter out = new StringWriter();
                                                 String value = "test,value";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("test,value", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_EmptyValueNewRecord() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "";
                                                 
                                                 // Get the private method via reflection
                                                 Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuoteMethod.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, true);
                                                 
                                                 // Verify
                                                 assertEquals("\"\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_EmptyValueNotNewRecord() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_ContainsDelimiter() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                     .withDelimiter(',');
                                                 StringWriter out = new StringWriter();
                                                 String value = "test,value";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"test,value\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_ContainsQuoteChar() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                     .withQuote('"');
                                                 StringWriter out = new StringWriter();
                                                 String value = "test\"value";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuoteMethod.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"test\"\"value\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_ContainsLineBreak() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "test\nvalue";
                                                 
                                                 // Get the private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"test\nvalue\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_StartsWithSpecialChar() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "\u0001test";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"\u0001test\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_EndsWithSpecialChar() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "test\u001F";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("\"test\u001F\"", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_QuoteModeMinimal_SafeValue() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "safe_value";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                 
                                                 // Verify
                                                 assertEquals("safe_value", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_InvalidQuoteMode() throws Exception {
                                                 // Setup
                                                 CSVFormat format = mock(CSVFormat.class);
                                                 when(format.getQuoteMode()).thenReturn(null);
                                                 when(format.getDelimiter()).thenReturn(',');
                                                 when(format.getQuoteCharacter()).thenReturn('"');
                                                 
                                                 StringWriter out = new StringWriter();
                                                 String value = "test";
                                                 
                                                 // Expect exception
                                                 thrown.expect(IllegalStateException.class);
                                                 thrown.expectMessage("Unexpected Quote value: null");
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuoteMethod.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                             }

 @Test
                                             public void testPrintAndQuote_Substring() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                 StringWriter out = new StringWriter();
                                                 String value = "longvalue";
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute - only print characters 4-7
                                                 printAndQuote.invoke(format, null, value, 4, 3, out, false);
                                                 
                                                 // Verify
                                                 assertEquals("val", out.toString());
                                             }

 @Test
                                             public void testPrintAndQuote_WithNullString() throws Exception {
                                                 // Setup
                                                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                     .withNullString("NULL");
                                                 StringWriter out = new StringWriter();
                                                 
                                                 // Get private method via reflection
                                                 Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                     "printAndQuote", 
                                                     Object.class, 
                                                     CharSequence.class, 
                                                     int.class, 
                                                     int.class, 
                                                     Appendable.class, 
                                                     boolean.class
                                                 );
                                                 printAndQuote.setAccessible(true);
                                                 
                                                 // Execute
                                                 printAndQuote.invoke(format, null, null, 0, 0, out, false);
                                                 
                                                 // Verify
                                                 assertEquals("NULL", out.toString());
                                             }

 @Test
     public void testPrintAndQuote_MinimalMode_NewRecordWithControlCharacter_DetectsMutant() throws IOException {
         // Setup
         CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
         StringBuilder out = new StringBuilder();
         String value = "\u001Ftest"; // 0x1F is a control character
         boolean newRecord = true;
         
         // Create a spy to access the private method
         CSVFormat spyFormat = spy(format);
         doCallRealMethod().when(spyFormat).print(any(), any(), anyBoolean());
         
         // Execute
         spyFormat.print(value, out, newRecord);
         
         // Verify - original would quote, mutant wouldn't
         assertTrue("Output should be quoted for control character in new record", 
                    out.toString().startsWith("\"") && out.toString().endsWith("\""));
         
         // Additional check for the specific mutant behavior
         // Mutant would not quote, so output would equal input
         assertNotEquals("Mutant detected - output should not equal input for control character",
                        value, out.toString());
     }

 @Test
    public void testPrintAndQuote_MinimalMode_NonNewRecordWithSpecialChar_ShouldNotQuote() throws IOException {
        // Setup
        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        StringBuilder out = new StringBuilder();
        String value = "\u001Ftest"; // Contains special character (0x1F) at start
        boolean newRecord = false; // Not a new record
        
        // Mock the necessary format methods
        when(format.getDelimiter()).thenReturn(',');
        when(format.getQuoteCharacter()).thenReturn('"');
        
        // Execute
        format.print(value, out, newRecord);
        
        // Verify - should NOT be quoted since it's not a new record
        assertFalse("Output should not be quoted", out.toString().startsWith("\""));
        assertEquals("Output should match input", value, out.toString());
        
        // Additional verification for mutated case
        // If the mutant survives, the output would be quoted
        assertFalse("Mutant detection: Output should not be quoted for non-new record with special char", 
                   out.toString().startsWith("\"") && out.toString().endsWith("\""));
    }

 @Test
   public void testPrintAndQuote_MinimalMode_NewRecord_DetectMutant() throws IOException {
       // Setup
       CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
       StringBuilder out = new StringBuilder();
       String value = "\"abc\""; // Contains quote character (0x22) which should trigger quoting
       
       // Test a character that should only be quoted in original condition (0x22)
       // In original: (0x22 > 0x21 && 0x22 < 0x23) → true → quote
       // In mutant: (0x22 > 0x21) → true → quote
       // So we need a character where original would not quote but mutant would
       // Let's use 0x25 ('%') which is between 0x23-0x2B
       // Original: (0x25 > 0x21 && 0x25 < 0x23) → false, (0x25 > 0x2B && 0x25 < 0x2D) → false → no quote
       // Mutant: (0x25 > 0x21) → true → quote
       value = "%abc%";
       
       // Execute
       format.print(value, out, true); // true for newRecord
       
       // Verify
       // Original would not quote this (output should be "%abc%")
       // Mutant would quote this (output should be ""%abc%"")
       // So if output contains quotes, mutant is present
       assertFalse("Output should not be quoted for character '%' in minimal mode", 
                  out.toString().startsWith("\"") && out.toString().endsWith("\""));
       
       // Additional test with character 0x2C (',') which is delimiter
       out = new StringBuilder();
       value = ",abc,";
       format.print(value, out, true);
       // Should be quoted in both original and mutant because it contains delimiter
       assertTrue("Output should be quoted when containing delimiter", 
                 out.toString().startsWith("\"") && out.toString().endsWith("\""));
   }

 @Test
  public void testPrintAndQuote_MinimalMode_NonNewRecord_NonTextDataChar_ShouldNotQuote() throws IOException {
      // Setup
      CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
      StringBuilder out = new StringBuilder();
      String value = "\u0001test"; // First char is 0x01 (non-textdata)
      boolean newRecord = false; // Not a new record
      
      // Mock behavior for getDelimiter and getQuoteCharacter
      when(format.getDelimiter()).thenReturn(',');
      when(format.getQuoteCharacter()).thenReturn('"');
      
      // Execute
      format.print(value, out, newRecord);
      
      // Verify - should not quote since it's not a new record
      // Original would output as-is, mutant would quote
      assertEquals("\u0001test", out.toString());
  }

 @Test
 public void testPrintAndQuote_ShouldQuoteCharAbove7E_WhenNewRecord() throws IOException {
     // Setup
     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
     StringBuilder out = new StringBuilder();
     String value = "\u007Ftest"; // 0x7F is the DEL character
     
     // Execute
     format.print(value, out, true); // true = newRecord
     
     // Verify
     String result = out.toString();
     assertTrue("Should quote string starting with char > 0x7E", 
                result.startsWith("\"") && result.endsWith("\""));
     
     // Additional check to ensure the content is properly quoted
     assertEquals("\"\u007Ftest\"", result);
 }

}
