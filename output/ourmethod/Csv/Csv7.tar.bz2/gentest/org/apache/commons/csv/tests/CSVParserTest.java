package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                  public void testInitializeHeader_WithNonEmptyFormatHeader_NoSkip() throws Exception {
                                                      // Setup
                                                      CSVFormat format = mock(CSVFormat.class);
                                                      when(format.getHeader()).thenReturn(new String[]{"field1", "field2"});
                                                      when(format.getSkipHeaderRecord()).thenReturn(false);
                                                      
                                                      Reader reader = new StringReader("");
                                                      CSVParser parser = new CSVParser(reader, format);
                                                      
                                                      // Use reflection to access private method
                                                      Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                      initializeHeaderMethod.setAccessible(true);
                                                      
                                                      // Execute
                                                      @SuppressWarnings("unchecked")
                                                      Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                      
                                                      // Verify
                                                      assertNotNull(result);
                                                      assertEquals(2, result.size());
                                                      assertEquals(Integer.valueOf(0), result.get("field1"));
                                                      assertEquals(Integer.valueOf(1), result.get("field2"));
                                                      
                                                      // Clean up
                                                      parser.close();
                                                  }

 @Test
                                                  public void testInitializeHeader_WithNullFormatHeader_ReturnsNull() throws Exception {
                                                      // Setup
                                                      CSVFormat format = mock(CSVFormat.class);
                                                      when(format.getHeader()).thenReturn(null);
                                                      
                                                      Reader reader = new StringReader("");
                                                      CSVParser parser = new CSVParser(reader, format);
                                                      
                                                      // Get the private method using reflection
                                                      Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                      initializeHeaderMethod.setAccessible(true);
                                                      
                                                      // Execute
                                                      @SuppressWarnings("unchecked")
                                                      Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                      
                                                      // Verify
                                                      assertNull(result);
                                                      
                                                      // Clean up
                                                      parser.close();
                                                  }

 @Test
                                                  public void testInitializeHeader_WithDuplicateHeaderNames_ThrowsException() throws Exception {
                                                      // Setup
                                                      CSVFormat format = mock(CSVFormat.class);
                                                      when(format.getHeader()).thenReturn(new String[]{"dup", "dup"});
                                                      when(format.getSkipHeaderRecord()).thenReturn(false);
                                                      
                                                      // Create a real parser instance instead of mocking it
                                                      CSVParser parser = new CSVParser(new StringReader(""), format);
                                                      
                                                      // Get the private method via reflection
                                                      Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                      initializeHeaderMethod.setAccessible(true);
                                                      
                                                      // Expect exception
                                                      thrown.expect(IllegalStateException.class);
                                                      thrown.expectMessage("The header contains duplicate names: [dup, dup]");
                                                      
                                                      // Execute
                                                      initializeHeaderMethod.invoke(parser);
                                                  }

 @Test
                                                  public void testInitializeHeader_WithEmptyHeaderArray_ReturnsNull() throws Exception {
                                                      // Setup
                                                      CSVFormat format = mock(CSVFormat.class);
                                                      when(format.getHeader()).thenReturn(new String[0]);
                                                      when(format.getSkipHeaderRecord()).thenReturn(false);
                                                      
                                                      // Create a real parser instance instead of mocking it
                                                      CSVParser parser = new CSVParser(new StringReader(""), format);
                                                      
                                                      // Use reflection to access the private initializeHeader method
                                                      Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                      initializeHeaderMethod.setAccessible(true);
                                                      
                                                      // Execute
                                                      @SuppressWarnings("unchecked")
                                                      Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                      
                                                      // Verify
                                                      assertNull(result);
                                                  }

 @Test
                                              public void testInitializeHeader_WithEmptyFormatHeader_NoRecords_ReturnsNull() throws Exception {
                                                  // Setup
                                                  CSVFormat format = mock(CSVFormat.class);
                                                  when(format.getHeader()).thenReturn(new String[0]);
                                                  when(format.getSkipHeaderRecord()).thenReturn(false);
                                                  
                                                  // Create a parser with empty input
                                                  Reader reader = new StringReader("");
                                                  CSVParser parser = new CSVParser(reader, format);
                                                  
                                                  // Use reflection to call the private initializeHeader method
                                                  Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                  initializeHeaderMethod.setAccessible(true);
                                                  
                                                  // Execute
                                                  @SuppressWarnings("unchecked")
                                                  Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                  
                                                  // Verify
                                                  assertNull(result);
                                              }

 @Test
                                          public void testInitializeHeader_WithEmptyFormatHeader_ReadsFromFirstRecord() throws Exception {
                                              // Setup
                                              CSVFormat format = mock(CSVFormat.class);
                                              when(format.getHeader()).thenReturn(new String[0]);
                                              when(format.getSkipHeaderRecord()).thenReturn(false);
                                              
                                              // Create a real parser instance
                                              CSVParser realParser = new CSVParser(new StringReader("col1,col2\nvalue1,value2"), format);
                                              
                                              // Use reflection to access private initializeHeader method
                                              Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                              initializeHeaderMethod.setAccessible(true);
                                              
                                              // Mock the lexer field to control behavior
                                              Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                              lexerField.setAccessible(true);
                                              Object mockLexer = mock(Class.forName("org.apache.commons.csv.Lexer")); // Use reflection to access non-public Lexer
                                              
                                              // Mock the nextRecord behavior
                                              Method nextRecordMethod = CSVParser.class.getDeclaredMethod("nextRecord");
                                              nextRecordMethod.setAccessible(true);
                                              when(nextRecordMethod.invoke(realParser)).thenAnswer(invocation -> {
                                                  CSVRecord mockRecord = mock(CSVRecord.class);
                                                  Method valuesMethod = CSVRecord.class.getDeclaredMethod("values");
                                                  valuesMethod.setAccessible(true);
                                                  when(valuesMethod.invoke(mockRecord)).thenReturn(new String[]{"col1", "col2"});
                                                  return mockRecord;
                                              });
                                              
                                              // Set the mocked lexer
                                              lexerField.set(realParser, mockLexer);
                                              
                                              // Execute
                                              @SuppressWarnings("unchecked")
                                              Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(realParser);
                                              
                                              // Verify
                                              assertNotNull(result);
                                              assertEquals(2, result.size());
                                              assertEquals(Integer.valueOf(0), result.get("col1"));
                                              assertEquals(Integer.valueOf(1), result.get("col2"));
                                          }

 @Test
                                          public void testInitializeHeader_WithNonEmptyFormatHeader_WithSkip() throws Exception {
                                              // Setup
                                              CSVFormat format = mock(CSVFormat.class);
                                              when(format.getHeader()).thenReturn(new String[]{"field1", "field2"});
                                              when(format.getSkipHeaderRecord()).thenReturn(true);
                                              
                                              // Create real parser instance
                                              CSVParser parser = new CSVParser(new StringReader(""), format);
                                              
                                              // Get lexer field via reflection
                                              Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                              lexerField.setAccessible(true);
                                              Class<?> lexerClass = Class.forName("org.apache.commons.csv.Lexer");
                                              Object lexer = mock(lexerClass); // Mock lexer through reflection
                                              
                                              // Set mock lexer to parser
                                              lexerField.set(parser, lexer);
                                              
                                              // Mock nextToken behavior
                                              Class<?> tokenClass = Class.forName("org.apache.commons.csv.Token");
                                              Method nextTokenMethod = lexerClass.getDeclaredMethod("nextToken", tokenClass);
                                              when(nextTokenMethod.invoke(lexer, any())).thenReturn(false); // Simulate end of input
                                              
                                              // Execute initializeHeader via reflection
                                              Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                              initializeHeaderMethod.setAccessible(true);
                                              @SuppressWarnings("unchecked")
                                              Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                              
                                              // Verify
                                              verify(lexer, times(1)).getClass().getDeclaredMethod("nextToken", tokenClass).invoke(lexer, any());
                                              assertNotNull(result);
                                              assertEquals(2, result.size());
                                          }

 @Test
          public void testInitializeHeaderWithNonNullHeaders() throws Exception {
              // Setup test data
              String[] testHeaders = {"col1", "col2", "col3"};
              
              // Mock dependencies
              CSVFormat format = mock(CSVFormat.class);
              when(format.getHeader()).thenReturn(testHeaders);
              when(format.getSkipHeaderRecord()).thenReturn(false);
              
              // Create parser instance (constructor will call initializeHeader)
              CSVParser parser = new CSVParser(new StringReader(""), format);
              
              // Get header map through reflection since it's private
              Field headerMapField = CSVParser.class.getDeclaredField("headerMap");
              headerMapField.setAccessible(true);
              Map<String, Integer> headerMap = (Map<String, Integer>) headerMapField.get(parser);
              
              // Verify results - this will fail for the mutant
              assertNotNull("Header map should not be null when headers exist", headerMap);
              assertEquals(3, headerMap.size());
              assertEquals(Integer.valueOf(0), headerMap.get("col1"));
              assertEquals(Integer.valueOf(1), headerMap.get("col2"));
              assertEquals(Integer.valueOf(2), headerMap.get("col3"));
          }

 @Test(expected = IllegalStateException.class)
         public void testInitializeHeaderWithDuplicateHeadersShouldThrowException() throws Exception {
             // Setup test data with duplicate headers
             String[] headersWithDuplicates = {"name", "age", "name"};
             
             // Mock the CSVFormat to return our test headers
             CSVFormat format = mock(CSVFormat.class);
             when(format.getHeader()).thenReturn(headersWithDuplicates);
             when(format.getSkipHeaderRecord()).thenReturn(false);
             
             // Create parser with our mocked format
             // We use null reader since we're testing header processing only
             CSVParser parser = new CSVParser(new StringReader(""), format);
             
             try {
                 // Use reflection to access private method since it's called in constructor
                 Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
                 method.setAccessible(true);
                 method.invoke(parser);
             } catch (InvocationTargetException e) {
                 // Unwrap the expected exception
                 throw (Exception) e.getCause();
             }
         }

 @Test
            public void testInitializeHeaderWithDuplicateHeadersShouldThrowExceptionWithCorrectMessage() throws Exception {
                // Setup test data
                String[] duplicateHeaders = {"name", "age", "name"};
                
                // Mock dependencies
                CSVFormat format = mock(CSVFormat.class);
                when(format.getHeader()).thenReturn(duplicateHeaders);
                when(format.getSkipHeaderRecord()).thenReturn(false);
                
                // Create parser with mocked dependencies
                CSVParser parser = new CSVParser(new StringReader(""), format);
                
                // Set exception expectation with exact message
                thrown.expect(IllegalStateException.class);
                thrown.expectMessage("The header contains duplicate names: " + Arrays.toString(duplicateHeaders));
                
                // Trigger the method that should throw
                parser.getHeaderMap();
            }

 @Test
       public void testInitializeHeader_ShouldStoreIntegerObjects() throws Exception {
           // Setup test data
           String[] headers = {"col1", "col2", "col3"};
           CSVFormat format = mock(CSVFormat.class);
           when(format.getHeader()).thenReturn(headers);
           when(format.getSkipHeaderRecord()).thenReturn(false);
           
           CSVParser parser = new CSVParser(new StringReader(""), format);
           
           // Use reflection to access private method
           Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
           method.setAccessible(true);
           Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
           
           // Verify the map contains proper Integer objects
           for (Map.Entry<String, Integer> entry : headerMap.entrySet()) {
               // This assertion will fail with the mutant since it uses primitive int
               assertTrue("Map values should be Integer objects", 
                         entry.getValue() instanceof Integer);
               
               // Additional check to ensure proper boxing
               Integer value = entry.getValue();
               assertEquals(Integer.class, value.getClass());
           }
           
           // Verify the actual values are correct
           assertEquals(Integer.valueOf(0), headerMap.get("col1"));
           assertEquals(Integer.valueOf(1), headerMap.get("col2"));
           assertEquals(Integer.valueOf(2), headerMap.get("col3"));
       }

 @Test(expected = NullPointerException.class)
      public void testInitializeHeader_ShouldThrowNPEWhenHdrMapNull() throws Exception {
          // Setup test data with duplicate headers
          String[] headersWithDuplicates = {"col1", "col2", "col1"};
          
          // Mock the CSVFormat to return our test headers and skip header record
          CSVFormat format = mock(CSVFormat.class);
          when(format.getHeader()).thenReturn(headersWithDuplicates);
          when(format.getSkipHeaderRecord()).thenReturn(false);
          
          // Create parser with our mocked format
          CSVParser parser = new CSVParser(new StringReader(""), format);
          
          // Use reflection to manipulate internal state and force hdrMap to be null
          // when duplicate check happens (simulating a bug scenario)
          Field hdrMapField = CSVParser.class.getDeclaredField("headerMap");
          hdrMapField.setAccessible(true);
          hdrMapField.set(parser, null);
          
          // This should throw NullPointerException in original code
          // but would pass in mutated code
          parser.getHeaderMap();
      }

 @Test
     public void testInitializeHeader_ShouldMapHeaderNamesToCorrectIndices() throws Exception {
         // Setup test data with multiple headers
         String[] headers = {"Name", "Age", "Email"};
         
         // Mock the format object and its behavior
         CSVFormat format = mock(CSVFormat.class);
         when(format.getHeader()).thenReturn(headers);
         when(format.getSkipHeaderRecord()).thenReturn(false);
         
         // Create parser with mocked format (reader can be null since we mock everything)
         CSVParser parser = new CSVParser(null, format);
         
         // Use reflection to access private initializeHeader method
         Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
         method.setAccessible(true);
         Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
         
         // Verify the mapping is correct
         assertNotNull(headerMap);
         assertEquals(3, headerMap.size());
         
         // This is where the mutant would fail - all values would be 0
         assertEquals(0, (int) headerMap.get("Name"));
         assertEquals(1, (int) headerMap.get("Age"));
         assertEquals(2, (int) headerMap.get("Email"));
         
         // Verify no duplicate headers (though this isn't the focus of this test)
         try {
             when(format.getHeader()).thenReturn(new String[]{"Name", "Name"});
             parser = new CSVParser(null, format);
             method.invoke(parser);
             fail("Should have thrown IllegalStateException for duplicate headers");
         } catch (InvocationTargetException e) {
             assertTrue(e.getCause() instanceof IllegalStateException);
         }
     }

 @Test
    public void testInitializeHeader_ShouldMapHeadersToCorrectIndices() throws Exception {
        // Setup test data
        String[] headers = {"Column1", "Column2", "Column3"};
        CSVFormat format = mock(CSVFormat.class);
        when(format.getHeader()).thenReturn(headers);
        when(format.getSkipHeaderRecord()).thenReturn(false);
        
        CSVParser parser = new CSVParser(new StringReader(""), format);
        
        // Use reflection to access private method since it's called in constructor
        Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
        method.setAccessible(true);
        Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
        
        // Verify mappings
        assertNotNull(headerMap);
        assertEquals(3, headerMap.size());
        assertEquals(Integer.valueOf(0), headerMap.get("Column1"));  // This will fail with mutant
        assertEquals(Integer.valueOf(1), headerMap.get("Column2"));  // This will fail with mutant
        assertEquals(Integer.valueOf(2), headerMap.get("Column3"));  // This will fail with mutant
    }

 @Test
    public void testInitializeHeaderThroughPublicAPI_ShouldMapHeadersToCorrectIndices() throws Exception {
        // Setup test data
        String[] headers = {"Column1", "Column2", "Column3"};
        CSVFormat format = mock(CSVFormat.class);
        when(format.getHeader()).thenReturn(headers);
        when(format.getSkipHeaderRecord()).thenReturn(false);
        
        // Create parser which calls initializeHeader() in constructor
        CSVParser parser = new CSVParser(new StringReader(""), format);
        
        // Get header map through public API
        Map<String, Integer> headerMap = parser.getHeaderMap();
        
        // Verify mappings
        assertNotNull(headerMap);
        assertEquals(3, headerMap.size());
        assertEquals(Integer.valueOf(0), headerMap.get("Column1"));  // This will fail with mutant
        assertEquals(Integer.valueOf(1), headerMap.get("Column2"));  // This will fail with mutant
        assertEquals(Integer.valueOf(2), headerMap.get("Column3"));  // This will fail with mutant
    }

 @Test
   public void testInitializeHeaderProcessesAllHeaders() throws Exception {
       // Setup test data - header with 3 elements
       String[] testHeaders = {"header1", "header2", "header3"};
       
       // Mock the CSVFormat to return our test headers and not skip header record
       CSVFormat format = mock(CSVFormat.class);
       when(format.getHeader()).thenReturn(testHeaders);
       when(format.getSkipHeaderRecord()).thenReturn(false);
       
       // Create parser with mocked format (reader can be null since we're testing header processing)
       CSVParser parser = new CSVParser(null, format);
       
       // Use reflection to access private initializeHeader method
       Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
       method.setAccessible(true);
       Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
       
       // Verify all headers are processed
       assertEquals(3, headerMap.size());
       assertEquals(Integer.valueOf(0), headerMap.get("header1"));
       assertEquals(Integer.valueOf(1), headerMap.get("header2"));
       // This assertion would fail with the mutant as it skips the last header
       assertEquals(Integer.valueOf(2), headerMap.get("header3"));
   }

 @Test
  public void testInitializeHeader_ShouldReturnZeroBasedIndices() throws Exception {
      // Setup test data
      String[] headers = {"col1", "col2", "col3"};
      CSVFormat format = mock(CSVFormat.class);
      when(format.getHeader()).thenReturn(headers);
      when(format.getSkipHeaderRecord()).thenReturn(false);
      
      // Mock nextRecord() to return null since we're testing formatHeader path
      CSVParser parser = new CSVParser(new StringReader(""), format);
      
      // Use reflection to access private method for testing
      Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
      method.setAccessible(true);
      Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
      
      // Verify indices are zero-based
      assertEquals(0, headerMap.get("col1").intValue());
      assertEquals(1, headerMap.get("col2").intValue());
      assertEquals(2, headerMap.get("col3").intValue());
      
      // Verify all headers are present
      assertTrue(headerMap.containsKey("col1"));
      assertTrue(headerMap.containsKey("col2"));
      assertTrue(headerMap.containsKey("col3"));
  }

 @Test
 public void testInitializeHeaderProcessesAllElements() throws Exception {
     // Setup test data - header with 2 elements to catch the -1 mutation
     String[] testHeader = {"col1", "col2"};
     
     // Mock the format object and its behavior
     CSVFormat format = mock(CSVFormat.class);
     when(format.getHeader()).thenReturn(testHeader);
     when(format.getSkipHeaderRecord()).thenReturn(false);
     
     // Create parser with mocked format (reader can be null since we mock everything)
     CSVParser parser = new CSVParser(null, format);
     
     // Use reflection to access private method since it's not exposed publicly
     Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
     method.setAccessible(true);
     Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
     
     // Verify all headers are processed
     assertNotNull(result);
     assertEquals(2, result.size());
     assertTrue(result.containsKey("col1"));
     assertTrue(result.containsKey("col2"));  // This would fail with the mutant
     assertEquals(Integer.valueOf(0), result.get("col1"));
     assertEquals(Integer.valueOf(1), result.get("col2"));  // This would fail with the mutant
 }

}
