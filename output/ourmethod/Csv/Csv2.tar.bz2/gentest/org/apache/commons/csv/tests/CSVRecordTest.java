package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                               public void testGet_WithNullMapping_ThrowsIllegalStateException() throws Exception {
                                                                                                                                                                                   // Setup
                                                                                                                                                                                   String[] values = {"value1", "value2"};
                                                                                                                                                                                   String comment = "test";
                                                                                                                                                                                   long recordNumber = 1L;
                                                                                                                                                                                   
                                                                                                                                                                                   // Use reflection to access private constructor
                                                                                                                                                                                   Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                       String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                                                                   CSVRecord record = constructor.newInstance(values, null, comment, recordNumber);
                                                                                                                                                                               
                                                                                                                                                                                   // Expect exception
                                                                                                                                                                                   thrown.expect(IllegalStateException.class);
                                                                                                                                                                                   thrown.expectMessage("No header mapping was specified, the record values can't be accessed by name");
                                                                                                                                                                               
                                                                                                                                                                                   // Test
                                                                                                                                                                                   record.get("anyName");
                                                                                                                                                                               }

    @Test
                                                                                                                                               public void testGet_WithNullValuesArray_ReturnsNullForValidMapping() {
                                                                                                                                                   // Setup
                                                                                                                                                   java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                                                   mapping.put("field1", 0);
                                                                                                                                                   String comment = "test";
                                                                                                                                                   long recordNumber = 1L;
                                                                                                                                                   String[] values = null;
                                                                                                                                                   
                                                                                                                                                   // Create CSVRecord instance using reflection since constructor is not public
                                                                                                                                                   try {
                                                                                                                                                       java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                                                                                                                                           org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                               String[].class, 
                                                                                                                                                               java.util.Map.class, 
                                                                                                                                                               String.class, 
                                                                                                                                                               long.class);
                                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                                       org.apache.commons.csv.CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                                                                                                       
                                                                                                                                                       // Test and verify
                                                                                                                                                       assertNull(record.get("field1"));
                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                       fail("Failed to create CSVRecord instance: " + e.getMessage());
                                                                                                                                                   }
                                                                                                                                               }

    @Test
                                                                                                                                   public void testGet_WithEmptyValuesArray_ReturnsNullForValidMapping() {
                                                                                                                                       // Setup
                                                                                                                                       String[] values = new String[0];
                                                                                                                                       java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                       mapping.put("field1", 0);
                                                                                                                                       String comment = "test";
                                                                                                                                       long recordNumber = 1L;
                                                                                                                                       
                                                                                                                                       // Create CSVRecord instance using reflection since constructor is not public
                                                                                                                                       CSVRecord record;
                                                                                                                                       try {
                                                                                                                                           Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                               String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                           record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Test and verify
                                                                                                                                       assertNull(record.get("field1"));
                                                                                                                                   }

    @Test
                                                                                                                               public void testGet_WithIndexOutOfBounds_ThrowsIllegalArgumentException() {
                                                                                                                                   // Setup
                                                                                                                                   String[] values = {"value1"};
                                                                                                                                   java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                                   mapping.put("field1", 0);
                                                                                                                                   mapping.put("field2", 1); // This index is out of bounds
                                                                                                                                   String comment = "test";
                                                                                                                                   long recordNumber = 1L;
                                                                                                                                   
                                                                                                                                   // Create CSVRecord instance using reflection since constructor is not public
                                                                                                                                   CSVRecord record;
                                                                                                                                   try {
                                                                                                                                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                           String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                       constructor.setAccessible(true);
                                                                                                                                       record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Expect exception
                                                                                                                                   try {
                                                                                                                                       record.get("field2");
                                                                                                                                       fail("Expected IllegalArgumentException to be thrown");
                                                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                                                       assertEquals("Index for header 'field2' is 1 but CSVRecord only has 1 values!", e.getMessage());
                                                                                                                                   }
                                                                                                                               }

    @Test
                                                                                                                           public void testGet_WithNonExistentName_ReturnsNull() {
                                                                                                                               // Setup
                                                                                                                               String[] values = {"value1", "value2"};
                                                                                                                               java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                               mapping.put("field1", 0);
                                                                                                                               String comment = "test";
                                                                                                                               long recordNumber = 1L;
                                                                                                                               
                                                                                                                               // Use reflection to access package-private constructor
                                                                                                                               CSVRecord record;
                                                                                                                               try {
                                                                                                                                   Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                       String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                   record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                                                                               } catch (NoSuchMethodException | SecurityException | InstantiationException | 
                                                                                                                                       IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                                                                                                                                   throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                                               }
                                                                                                                               
                                                                                                                               // Test and verify
                                                                                                                               assertNull(record.get("nonexistent"));
                                                                                                                           }

    @Test
                                                                                                               public void testGet_EmptyValuesArray() {
                                                                                                                   String[] values = {};
                                                                                                                   java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                   org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                   
                                                                                                                   try {
                                                                                                                       // Get the constructor
                                                                                                                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                           String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                       constructor.setAccessible(true);
                                                                                                                       
                                                                                                                       // Create instance
                                                                                                                       CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                       
                                                                                                                       // Verify behavior
                                                                                                                       thrown.expect(IndexOutOfBoundsException.class);
                                                                                                                       record.get(0);
                                                                                                                   } catch (NoSuchMethodException | SecurityException | InstantiationException | 
                                                                                                                            IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                                                                                                                       throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                                   }
                                                                                                               }

    @Test
                                                                                                           public void testGet_IndexOutOfBounds() {
                                                                                                               String[] values = {"apple", "banana", "cherry"};
                                                                                                               Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                               
                                                                                                               // Create CSVRecord instance using reflection since constructor is not public
                                                                                                               try {
                                                                                                                   Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                       String[].class, Map.class, String.class, long.class);
                                                                                                                   constructor.setAccessible(true);
                                                                                                                   CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                   
                                                                                                                   try {
                                                                                                                       record.get(3);  // This should throw IndexOutOfBoundsException
                                                                                                                       fail("Expected IndexOutOfBoundsException");
                                                                                                                   } catch (IndexOutOfBoundsException e) {
                                                                                                                       // expected
                                                                                                                   }
                                                                                                               } catch (Exception e) {
                                                                                                                   throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                               }
                                                                                                           }

    @Test
                                                                                                   public void testGet_WithValidMappingAndName_ReturnsCorrectValue() throws Exception {
                                                                                                       // Setup
                                                                                                       String[] values = {"value1", "value2"};
                                                                                                       
                                                                                                       // Use reflection to access non-public constructor
                                                                                                   }

    @Test
                                                                               public void testGet_NullValuesArray() throws Exception {
                                                                                   // Get the constructor
                                                                                   Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                                                                       org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                                                                           String[].class, 
                                                                                           java.util.Map.class, 
                                                                                           String.class, 
                                                                                           long.class);
                                                                                   constructor.setAccessible(true);
                                                                                   
                                                                                   // Create mapping for the test
                                                                                   java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                   mapping.put("test", Integer.valueOf(0));
                                                                                   
                                                                                   // Create instance with null values array - should throw NullPointerException
                                                                                   try {
                                                                                       constructor.newInstance(
                                                                                           null,          // values array
                                                                                           mapping,      // mapping
                                                                                           "comment",    // comment
                                                                                           1L            // recordNumber
                                                                                       );
                                                                                       fail("Expected NullPointerException to be thrown");
                                                                                   } catch (InvocationTargetException e) {
                                                                                       assertTrue(e.getCause() instanceof NullPointerException);
                                                                                   }
                                                                               }

    @Test
                                                                           public void testGet_NegativeIndex() {
                                                                               String[] values = {"apple", "banana", "cherry"};
                                                                               java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                               String comment = null;
                                                                               long recordNumber = 1L;
                                                                               
                                                                               try {
                                                                                   java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                       String[].class, java.util.Map.class, String.class, long.class);
                                                                                   constructor.setAccessible(true);
                                                                                   CSVRecord record = constructor.newInstance(
                                                                                       values, mapping, comment, recordNumber);
                                                                                   
                                                                                   // This should throw ArrayIndexOutOfBoundsException
                                                                                   record.get(-1);
                                                                                   fail("Expected ArrayIndexOutOfBoundsException");
                                                                               } catch (NoSuchMethodException | InstantiationException | 
                                                                                        IllegalAccessException | InvocationTargetException e) {
                                                                                   throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                               } catch (ArrayIndexOutOfBoundsException e) {
                                                                                   // Expected exception
                                                                               }
                                                                           }

    @Test
                                                           public void testGet_ValidIndex() throws Exception {
                                                               String[] values = {"apple", "banana", "cherry"};
                                                               java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                               mapping.put("0", 0);
                                                               mapping.put("1", 1);
                                                               mapping.put("2", 2);
                                                               
                                                               // Use reflection to access the non-public constructor
                                                               java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                   String[].class, java.util.Map.class, String.class, long.class);
                                                               constructor.setAccessible(true);
                                                               CSVRecord record = constructor.newInstance(
                                                                   values, mapping, null, 1L);
                                                               
                                                               assertEquals("apple", record.get(0));
                                                               assertEquals("banana", record.get(1));
                                                               assertEquals("cherry", record.get(2));
                                                           }

    @Test
                                               public void testGet_WithSingleElement() {
                                                   String[] values = {"single"};
                                                   java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                   mapping.put("single", 0);
                                                   String comment = null;
                                                   long recordNumber = 1L;
                                                   
                                                   // Create CSVRecord instance using reflection
                                                   try {
                                                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                           String[].class, java.util.Map.class, String.class, long.class);
                                                       constructor.setAccessible(true);
                                                       CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                       
                                                       // Test the get method
                                                       assertEquals("single", record.get(0));
                                                       assertEquals("single", record.get("single"));
                                                   } catch (Exception e) {
                                                       fail("Failed to create CSVRecord instance: " + e.getMessage());
                                                   }
                                               }

    @Test
                                          public void testGetWithValidHeaderNameShouldReturnCorrectValue() throws Exception {
                                              // Setup test data
                                              String[] values = {"value1", "value2", "value3"};
                                              java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                              mapping.put("header1", 0);
                                              mapping.put("header2", 1);
                                              mapping.put("header3", 2);
                                              
                                              // Create CSVRecord instance using reflection
                                              java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                                  org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                                      String[].class, Map.class, String.class, long.class);
                                              constructor.setAccessible(true);
                                              org.apache.commons.csv.CSVRecord record = 
                                                  constructor.newInstance(values, mapping, null, 1L);
                                              
                                              // Test with existing header name
                                              String result = record.get("header2");
                                              
                                              // Verify the correct value is returned
                                              assertEquals("value2", result);
                                              
                                              // Also test another header to be thorough
                                              String result2 = record.get("header1");
                                              assertEquals("value1", result2);
                                          }

    @Test
                                      public void testGetIntShouldReturnCorrectValue() {
                                          // Setup test data
                                          String[] testValues = {"value1", "value2", "value3"};
                                          java.util.Map<String, Integer> testMapping = new java.util.HashMap<String, Integer>();
                                          String testComment = "test comment";
                                          long testRecordNumber = 1L;
                                          
                                          // Create CSVRecord with test data using reflection since constructor is not public
                                          CSVRecord record;
                                          try {
                                              java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                  String[].class, java.util.Map.class, String.class, long.class);
                                              constructor.setAccessible(true);
                                              record = constructor.newInstance(testValues, testMapping, testComment, testRecordNumber);
                                          } catch (Exception e) {
                                              throw new RuntimeException("Failed to create CSVRecord instance", e);
                                          }
                                          
                                          // Test that get returns the correct value for each index
                                          assertEquals("value1", record.get(0));
                                          assertEquals("value2", record.get(1));
                                          assertEquals("value3", record.get(2));
                                          
                                          // Also test that it doesn't return null for populated values
                                          assertNotNull(record.get(0));
                                          assertNotNull(record.get(1));
                                          assertNotNull(record.get(2));
                                      }

    @Test
                             public void testGetWithCaseSensitiveHeaderName() throws Exception {
                                 // Setup test data with case-sensitive mapping
                                 java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                 mapping.put("Name", 0);  // Note the capital 'N'
                                 String[] values = {"John Doe"};
                                 
                                 // Use reflection to access non-public constructor
                                 java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                     org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                         String[].class, 
                                         java.util.Map.class, 
                                         String.class, 
                                         long.class);
                                 constructor.setAccessible(true);
                                 org.apache.commons.csv.CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                 
                                 // Test with exact case match - should work in both original and mutant
                                 assertEquals("John Doe", record.get("Name"));
                                 
                                 // Test with different case - should FAIL in original but PASS in mutant
                                 // This is the key test to detect the mutant
                                 assertNull("Should return null for case mismatch", record.get("name"));
                                 
                                 // Additional edge cases
                                 assertNull(record.get("NAME"));  // All caps
                                 assertNull(record.get("nAmE"));  // Mixed case
                             }

    @Test
         public void testGetWithNameCaseSensitivity() {
             // Setup test data
             String[] values = {"value1", "value2"};
             java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
             mapping.put("Name", 0);  // Mixed case key
             mapping.put("other", 1); // Lowercase key
             
             // Create test record using reflection since constructor is not public
             org.apache.commons.csv.CSVRecord record;
             try {
                 java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                     org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                         String[].class, java.util.Map.class, String.class, long.class);
                 constructor.setAccessible(true);
                 record = constructor.newInstance(values, mapping, null, 1L);
             } catch (Exception e) {
                 throw new RuntimeException("Failed to create CSVRecord instance", e);
             }
             
             // Test case-sensitive lookup - should find exact match
             assertEquals("value1", record.get("Name"));
             
             // Test case-insensitive lookup - should NOT find match in original
             // This would pass in mutated version but fail in original
             assertNull(record.get("name"));
             
             // Test exact match with lowercase key
             assertEquals("value2", record.get("other"));
         }

    @Test
    public void testGetShouldOnlyCatchArrayIndexOutOfBounds() throws Exception {
        // Create a CSVRecord with a mock values array that throws different exceptions
        String[] values = mock(String[].class);
        
        // Get the non-public constructor using reflection
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        
        // Case 1: Test normal ArrayIndexOutOfBounds behavior (should be caught in both original and mutant)
        when(values[0]).thenThrow(new ArrayIndexOutOfBoundsException());
        CSVRecord record = constructor.newInstance(values, null, null, 0L);
        record.get(0); // Should not throw anything as exception is caught
        
        // Case 2: Test with a different RuntimeException (NullPointerException)
        // This should only be caught by the mutant
        when(values[1]).thenThrow(new NullPointerException());
        thrown.expect(NullPointerException.class);
        record.get(1); // Should throw in original, but be caught by mutant
    }

    @Test(expected = NullPointerException.class)
    public void testGetShouldNotCatchOtherRuntimeExceptions() throws Exception {
        // Setup
        String[] values = {"value1", "value2"};
        Map<String, Integer> mapping = mock(Map.class);
        when(mapping.get(anyString())).thenThrow(new NullPointerException("test exception"));
        
        // Use reflection to access private constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
        
        // This should throw NullPointerException (original behavior)
        // If it throws IllegalArgumentException instead, the mutant survived
        record.get("anyName");
    }


}
