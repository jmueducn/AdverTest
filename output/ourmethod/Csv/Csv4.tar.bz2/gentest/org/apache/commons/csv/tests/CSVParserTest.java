package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testGetHeaderMap_WhenHeaderMapIsNull() throws Exception {
                                                    // Arrange
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    Reader reader = new StringReader("");
                                                    CSVParser parser = new CSVParser(reader, format);
                                                    
                                                    // Use reflection to set headerMap to null since it's final
                                                    // This is just for testing purposes
                                                    java.lang.reflect.Field field = CSVParser.class.getDeclaredField("headerMap");
                                                    field.setAccessible(true);
                                                    field.set(parser, null);
                                                    
                                                    // Act
                                                    Map<String, Integer> result = parser.getHeaderMap();
                                                    
                                                    // Assert
                                                    assertNull("Header map should be null when headerMap is null", result);
                                                }

    @Test
                                                public void testGetHeaderMap_WhenHeaderMapIsNotEmpty() throws Exception {
                                                    // Arrange
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    Reader reader = new StringReader("");
                                                    CSVParser parser = new CSVParser(reader, format);
                                                    
                                                    // Create a sample header map
                                                    Map<String, Integer> expectedHeaderMap = new LinkedHashMap<>();
                                                    expectedHeaderMap.put("Name", 0);
                                                    expectedHeaderMap.put("Age", 1);
                                                    expectedHeaderMap.put("City", 2);
                                                    
                                                    // Use reflection to set headerMap since it's final
                                                    java.lang.reflect.Field field = CSVParser.class.getDeclaredField("headerMap");
                                                    field.setAccessible(true);
                                                    field.set(parser, expectedHeaderMap);
                                                    
                                                    // Act
                                                    Map<String, Integer> result = parser.getHeaderMap();
                                                    
                                                    // Assert
                                                    assertNotNull("Header map should not be null", result);
                                                    assertEquals("Header map size should match", expectedHeaderMap.size(), result.size());
                                                    assertEquals("Header map content should match", expectedHeaderMap, result);
                                                    assertNotSame("Should return a copy of the header map", expectedHeaderMap, result);
                                                }

    @Test
                                                public void testGetHeaderMap_ReturnsImmutableCopy() throws Exception {
                                                    // Arrange
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    Reader reader = new StringReader("");
                                                    CSVParser parser = new CSVParser(reader, format);
                                                    
                                                    // Create a sample header map
                                                    Map<String, Integer> originalHeaderMap = new LinkedHashMap<>();
                                                    originalHeaderMap.put("Name", 0);
                                                    originalHeaderMap.put("Age", 1);
                                                    
                                                    // Use reflection to set headerMap since it's final
                                                    java.lang.reflect.Field field = CSVParser.class.getDeclaredField("headerMap");
                                                    field.setAccessible(true);
                                                    field.set(parser, originalHeaderMap);
                                                    
                                                    // Act
                                                    Map<String, Integer> result = parser.getHeaderMap();
                                                    
                                                    // Modify the returned map
                                                    result.put("City", 2);
                                                    
                                                    // Get the header map again
                                                    Map<String, Integer> secondResult = parser.getHeaderMap();
                                                    
                                                    // Assert
                                                    assertEquals("Original header map should not be modified", 
                                                                 originalHeaderMap.size(), secondResult.size());
                                                    assertFalse("Original header map should not contain the new key", 
                                                                secondResult.containsKey("City"));
                                                }

    @Test
                                                public void testGetHeaderMap_ReturnsLinkedHashMap() throws Exception {
                                                    // Arrange
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    Reader reader = new StringReader("");
                                                    CSVParser parser = new CSVParser(reader, format);
                                                    
                                                    // Create a sample header map
                                                    Map<String, Integer> originalHeaderMap = new LinkedHashMap<>();
                                                    originalHeaderMap.put("Name", 0);
                                                    originalHeaderMap.put("Age", 1);
                                                    originalHeaderMap.put("City", 2);
                                                    
                                                    // Use reflection to set headerMap since it's final
                                                    java.lang.reflect.Field field = CSVParser.class.getDeclaredField("headerMap");
                                                    field.setAccessible(true);
                                                    field.set(parser, originalHeaderMap);
                                                    
                                                    // Act
                                                    Map<String, Integer> result = parser.getHeaderMap();
                                                    
                                                    // Assert
                                                    assertTrue("Returned map should be a LinkedHashMap", 
                                                              result instanceof LinkedHashMap);
                                                }


}
