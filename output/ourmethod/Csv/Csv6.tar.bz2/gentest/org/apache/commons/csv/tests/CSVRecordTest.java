package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
    public void testPutIn_WithValidMappingAndValues() throws Exception {
        // Setup
        String[] values = {"value1", "value2", "value3"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        mapping.put("col2", 1);
        mapping.put("col3", 2);
        
        // Get constructor via reflection and make it accessible
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Get method via reflection and make it accessible
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        // Execute
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertEquals(3, result.size());
        assertEquals("value1", result.get("col1"));
        assertEquals("value2", result.get("col2"));
        assertEquals("value3", result.get("col3"));
        assertSame(targetMap, result); // Should return the same map instance
    }

    @Test
    public void testPutIn_WithMappingExceedingValuesLength() throws Exception {
        // Setup
        String[] values = {"value1", "value2"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        mapping.put("col2", 1);
        mapping.put("col3", 2); // This column index exceeds values length
        
        // Use reflection to access the non-public constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Use reflection to access the non-public putIn method
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertEquals(2, result.size()); // Only valid mappings should be added
        assertEquals("value1", result.get("col1"));
        assertEquals("value2", result.get("col2"));
        assertFalse(result.containsKey("col3")); // Should not contain the out-of-bounds mapping
    }

    @Test
    public void testPutIn_WithEmptyValuesArray() throws Exception {
        // Setup
        String[] values = {};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        mapping.put("col2", 1);
        
        // Get constructor via reflection
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Get putIn method via reflection
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        // Execute
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertTrue(result.isEmpty()); // No values should be added
    }

    @Test
    public void testPutIn_WithNullValuesArray() throws Exception {
        // Setup
        String[] values = null;
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        
        // Use reflection to access non-public constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Use reflection to access non-public putIn method
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        // Execute
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertTrue(result.isEmpty()); // Should use EMPTY_STRING_ARRAY and not add anything
    }

    @Test
    public void testPutIn_WithEmptyMapping() throws Exception {
        // Setup
        String[] values = {"value1", "value2"};
        Map<String, Integer> mapping = new HashMap<>();
        
        // Get constructor via reflection and make it accessible
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Get putIn method via reflection and make it accessible
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        // Execute
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertTrue(result.isEmpty()); // No mappings means nothing should be added
    }

    @Test
    public void testPutIn_WithNullTargetMap() throws Exception {
        // Setup
        String[] values = {"value1"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        
        // Create CSVRecord instance using reflection
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        // Get putIn method using reflection
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        // Expect exception
        thrown.expect(NullPointerException.class);
        
        // Execute
        putInMethod.invoke(record, (Object) null);
    }

    @Test
    public void testPutIn_WithNegativeColumnIndex() throws Exception {
        // Setup
        String[] values = {"value1"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", -1); // Negative index
        
        // Get constructor via reflection and make it accessible
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Get putIn method via reflection and make it accessible
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        // Execute
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertTrue(result.isEmpty()); // Negative index should be ignored
    }

    @Test
    public void testPutIn_WithDuplicateKeysInTargetMap() throws Exception {
        // Setup
        String[] values = {"newValue"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        
        // Use reflection to access non-public constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        targetMap.put("col1", "oldValue"); // Existing key
        
        // Use reflection to access non-public putIn method
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertEquals(1, result.size());
        assertEquals("newValue", result.get("col1")); // Should overwrite existing value
    }

    @Test
    public void testPutIn_WithNullValuesInArray() throws Exception {
        // Setup
        String[] values = {null, "value2"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        mapping.put("col2", 1);
        
        // Use reflection to access non-public constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Use reflection to access non-public putIn method
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        @SuppressWarnings("unchecked")
        Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, targetMap);
        
        // Verify
        assertEquals(2, result.size());
        assertNull(result.get("col1")); // Null values should be preserved
        assertEquals("value2", result.get("col2"));
    }


}
