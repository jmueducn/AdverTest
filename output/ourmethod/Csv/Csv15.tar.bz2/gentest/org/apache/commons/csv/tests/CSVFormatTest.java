package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                            public void testPrintAndQuote_AllQuoteMode() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                StringWriter out = new StringWriter();
                                                String value = "test";
                                                
                                                // Get the private method via reflection
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuoteMethod.invoke(
                                                    format, 
                                                    null, 
                                                    value, 
                                                    0, 
                                                    value.length(), 
                                                    out, 
                                                    false
                                                );
                                                
                                                // Verify
                                                assertEquals("\"test\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_AllNonNullQuoteMode_WithNull() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
                                                StringWriter out = new StringWriter();
                                                
                                                // Get private method via reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, null, null, 0, 0, out, false);
                                                
                                                // Verify
                                                assertEquals("", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_NonNumericQuoteMode_WithString() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                StringWriter out = new StringWriter();
                                                String value = "text";
                                                
                                                // Get the private method using reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, value, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"text\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_MinimalQuoteMode_EmptyValueNewRecord() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                StringWriter out = new StringWriter();
                                                String value = "";
                                                
                                                // Get private method via reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, null, value, 0, value.length(), out, true);
                                                
                                                // Verify
                                                assertEquals("\"\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_MinimalQuoteMode_ContainsDelimiter() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                    .withDelimiter(',');
                                                StringWriter out = new StringWriter();
                                                String value = "test,value";
                                                
                                                // Get private method via reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"test,value\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_MinimalQuoteMode_ContainsQuoteChar() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                    .withQuote('"');
                                                StringWriter out = new StringWriter();
                                                String value = "test\"value";
                                                
                                                // Get private method via reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"test\"\"value\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_MinimalQuoteMode_ContainsLineBreak() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                StringWriter out = new StringWriter();
                                                String value = "test\nvalue";
                                                
                                                // Get private method via reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"test\nvalue\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_MinimalQuoteMode_StartsWithSpecialChar() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                StringWriter out = new StringWriter();
                                                String value = "\u0001test";
                                                
                                                // Get the private method using reflection
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"\u0001test\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_MinimalQuoteMode_EndsWithSpecialChar() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                StringWriter out = new StringWriter();
                                                String value = "test\u001F";
                                                
                                                // Get private method via reflection
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"test\u001F\"", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_InvalidQuoteMode() throws Exception {
                                                // Setup
                                                Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                    char.class, Character.class, QuoteMode.class, Character.class, Character.class,
                                                    boolean.class, boolean.class, String.class, String.class, Object[].class,
                                                    String[].class, boolean.class, boolean.class, boolean.class, boolean.class,
                                                    boolean.class, boolean.class);
                                                constructor.setAccessible(true);
                                                CSVFormat format = constructor.newInstance(
                                                    ',', null, null, null, null, false, false, null, null, null, null,
                                                    false, false, false, false, false, false);
                                                StringWriter out = new StringWriter();
                                                
                                                // Expect exception
                                                thrown.expect(IllegalStateException.class);
                                                thrown.expectMessage("Unexpected Quote value: null");
                                                
                                                // Get private method via reflection
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", Object.class, CharSequence.class, int.class, int.class,
                                                    Appendable.class, boolean.class);
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuoteMethod.invoke(format, null, "test", 0, 4, out, false);
                                            }

 @Test
                                            public void testPrintAndQuote_SubstringHandling() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                StringWriter out = new StringWriter();
                                                String value = "longvalue";
                                                
                                                // Get the private method using reflection
                                                Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuoteMethod.setAccessible(true);
                                                
                                                // Execute - test substring handling (offset 4, length 4)
                                                printAndQuoteMethod.invoke(format, null, value, 4, 4, out, false);
                                                
                                                // Verify
                                                assertEquals("valu", out.toString());
                                            }

 @Test
                                            public void testPrintAndQuote_QuoteCharacterDoubling() throws Exception {
                                                // Setup
                                                CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                    .withQuote('"');
                                                StringWriter out = new StringWriter();
                                                String value = "test\"middle\"end";
                                                
                                                // Get private method via reflection
                                                Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                    "printAndQuote", 
                                                    Object.class, 
                                                    CharSequence.class, 
                                                    int.class, 
                                                    int.class, 
                                                    Appendable.class, 
                                                    boolean.class
                                                );
                                                printAndQuote.setAccessible(true);
                                                
                                                // Execute
                                                printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                
                                                // Verify
                                                assertEquals("\"test\"\"middle\"\"end\"", out.toString());
                                            }

 @Test
                                        public void testPrintAndQuote_NonNumericQuoteMode_WithNumber() throws Exception {
                                            // Setup
                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                            StringWriter out = new StringWriter();
                                            Integer number = 123;
                                            
                                            // Get private method via reflection
                                            Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                "printAndQuote", 
                                                Object.class, 
                                                CharSequence.class, 
                                                int.class, 
                                                int.class, 
                                                Appendable.class, 
                                                boolean.class
                                            );
                                            printAndQuote.setAccessible(true);
                                            
                                            // Execute
                                            printAndQuote.invoke(
                                                format, 
                                                number, 
                                                number.toString(), 
                                                0, 
                                                number.toString().length(), 
                                                out, 
                                                false
                                            );
                                            
                                            // Verify
                                            assertEquals("123", out.toString());
                                        }

 @Test
                                        public void testPrintAndQuote_NoneQuoteMode() throws Exception {
                                            // Setup
                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                            StringWriter out = new StringWriter();
                                            String value = "test,value";
                                            
                                            // Get private method via reflection
                                            Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                "printAndQuote", 
                                                Object.class, 
                                                CharSequence.class, 
                                                int.class, 
                                                int.class, 
                                                Appendable.class, 
                                                boolean.class
                                            );
                                            printAndQuote.setAccessible(true);
                                            
                                            // Execute
                                            printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                            
                                            // Verify
                                            assertEquals("test,value", out.toString());
                                        }

 @Test
        public void testPrintAndQuoteDetectsMutatedCharAt() throws IOException {
            // Setup
            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
            Appendable out = new StringBuilder();
            String value = "a,b"; // First char 'a' doesn't need quoting, but ',' does
            int offset = 0;
            int len = value.length();
            boolean newRecord = true;
            
            // Execute
            format.print(value, out, newRecord);
            
            // Verify - original would quote because of comma, mutant wouldn't
            assertEquals("\"a,b\"", out.toString());
        }

 @Test
        public void testPrintAndQuoteWithSpecialCharLaterInString() throws IOException {
            // Setup - string where first char is safe but later char needs quoting
            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
            Appendable out = new StringBuilder();
            String value = "text\"withquote"; // Quote character appears later
            int offset = 0;
            int len = value.length();
            boolean newRecord = true;
            
            // Execute
            format.print(value, out, newRecord);
            
            // Verify - should be quoted because of the quote character
            assertEquals("\"text\"\"withquote\"", out.toString());
        }

 @Test
   public void testPrintAndQuoteWithControlCharAfterFirstPosition() throws Exception {
       // Setup
       CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
       StringBuilder out = new StringBuilder();
       String value = "A\u0001"; // 'A' followed by control character (<= COMMENT)
       boolean newRecord = true;
       
       // Create a spy to access the private method
       CSVFormat spyFormat = spy(format);
       doCallRealMethod().when(spyFormat).print(any(), any(), anyBoolean());
       
       // Execute
       spyFormat.print(value, out, newRecord);
       
       // Verify
       // Original behavior would quote the string because of control character
       // Mutant would not quote because control character is not at position 0
       assertTrue("Output should be quoted due to control character", 
                  out.toString().startsWith("\"") && out.toString().endsWith("\""));
       
       // Additional verification that the content is correct
       assertEquals("\"A\u0001\"", out.toString());
   }

 @Test
  public void testPrintAndQuote_MinimalMode_StartsWithDelimiter() throws IOException {
      // Setup
      CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
      StringBuilder out = new StringBuilder();
      String value = ",test"; // starts with delimiter
      boolean newRecord = true;
      
      // Mock the behavior of getDelimiter and getQuoteCharacter
      when(format.getDelimiter()).thenReturn(',');
      when(format.getQuoteCharacter()).thenReturn('"');
      
      // Execute
      format.print(value, out, newRecord);
      
      // Verify - original behavior should not quote this
      // If mutant exists, it would quote it
      assertFalse("Value should not be quoted when starting with delimiter in MINIMAL mode", 
          out.toString().startsWith("\"") && out.toString().endsWith("\""));
      
      // Additional check for exact output
      assertEquals(",test", out.toString());
  }

 @Test
 public void testPrintAndQuote_MinimalMode_NewRecordWithNormalChar_ShouldNotQuote() throws Exception {
     // Setup
     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
     StringBuilder out = new StringBuilder();
     String value = "normalText"; // First character 'n' > COMMENT
     boolean newRecord = true;
     
     // Mock necessary components
     when(format.getDelimiter()).thenReturn(',');
     when(format.getQuoteCharacter()).thenReturn('"');
     
     // Create test object (using reflection since method is private)
     Method printAndQuote = CSVFormat.class.getDeclaredMethod(
         "printAndQuote", 
         Object.class, CharSequence.class, int.class, int.class, 
         Appendable.class, boolean.class);
     printAndQuote.setAccessible(true);
     
     // Execute
     printAndQuote.invoke(format, null, value, 0, value.length(), out, newRecord);
     
     // Verify - output should not be quoted
     assertEquals("normalText", out.toString());
     
     // Additional verification that we didn't go through the quoting path
     assertFalse(out.toString().startsWith("\""));
     assertFalse(out.toString().endsWith("\""));
 }

}
