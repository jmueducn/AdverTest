package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
         public void testPutIn_NullMapping() throws Exception {
             // Setup
             String[] values = {"val1", "val2"};
             Map<String, Integer> mapping = null;
             
             // Use reflection to access package-private constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             inputMap.put("existing", "value");
             
             // Use reflection to access package-private method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertSame(inputMap, result);
             assertEquals(1, result.size());
             assertEquals("value", result.get("existing"));
         }

    @Test
         public void testPutIn_EmptyMapping() throws Exception {
             // Setup
             String[] values = {"val1", "val2"};
             Map<String, Integer> mapping = new HashMap<>();
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access package-private constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             // Use reflection to access package-private method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertSame(inputMap, result);
             assertTrue(result.isEmpty());
         }

    @Test
         public void testPutIn_ValidMappings() throws Exception {
             // Setup
             String[] values = {"val1", "val2", "val3"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             mapping.put("key2", 1);
             mapping.put("key3", 2);
             
             // Use reflection to access package-private constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access package-private method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertSame(inputMap, result);
             assertEquals(3, result.size());
             assertEquals("val1", result.get("key1"));
             assertEquals("val2", result.get("key2"));
             assertEquals("val3", result.get("key3"));
         }

    @Test
         public void testPutIn_OutOfBoundMappings() throws Exception {
             // Setup
             String[] values = {"val1"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("valid", 0);
             mapping.put("invalid", 1); // Out of bounds
             
             // Get constructor via reflection and make it accessible
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Get method via reflection and make it accessible
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(1, result.size());
             assertEquals("val1", result.get("valid"));
             assertFalse(result.containsKey("invalid"));
         }

    @Test
         public void testPutIn_MixedValidAndInvalidMappings() throws Exception {
             // Setup
             String[] values = {"val1", "val2"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);  // valid
             mapping.put("key2", 1);  // valid
             mapping.put("key3", 2);  // invalid
             mapping.put("key4", -1); // invalid
             
             // Use reflection to access private constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access private putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(2, result.size());
             assertEquals("val1", result.get("key1"));
             assertEquals("val2", result.get("key2"));
             assertFalse(result.containsKey("key3"));
             assertFalse(result.containsKey("key4"));
         }

    @Test
         public void testPutIn_NullInputMap() throws Exception {
             // Setup
             String[] values = {"val1"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             
             // Create CSVRecord instance using reflection
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             // Get putIn method using reflection
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Expect exception
             thrown.expect(NullPointerException.class);
             
             // Execute
             putInMethod.invoke(record, (Map<String, String>)null);
         }

    @Test
         public void testPutIn_PreservesExistingMapEntries() throws Exception {
             // Setup
             String[] values = {"val1"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("newKey", 0);
             
             // Get constructor via reflection and make it accessible
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             inputMap.put("existingKey", "existingValue");
             
             // Get method via reflection and make it accessible
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(2, result.size());
             assertEquals("val1", result.get("newKey"));
             assertEquals("existingValue", result.get("existingKey"));
         }

    @Test
         public void testPutIn_EmptyValuesArray() throws Exception {
             // Setup
             String[] values = {};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             mapping.put("key2", 1);
             
             // Use reflection to access package-private constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access package-private putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertTrue(result.isEmpty());
         }

    @Test
    public void testIteratorReturnsRegularIteratorNotListIterator() {
        // Setup test data
        String[] values = {"value1", "value2", "value3"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        mapping.put("col2", 1);
        mapping.put("col3", 2);
        
        // Create test object using reflection since constructor is not public
        CSVRecord record;
        try {
            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                String[].class, Map.class, String.class, long.class);
            constructor.setAccessible(true);
            record = constructor.newInstance(values, mapping, "comment", 1L);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create CSVRecord instance", e);
        }
        
        // Get the iterator
        Iterator<String> iterator = record.iterator();
        
        // Verify it's not a ListIterator
        assertFalse("Iterator should not be a ListIterator", 
                   iterator instanceof java.util.ListIterator);
        
        // Also verify it's a proper Iterator that works as expected
        assertTrue(iterator.hasNext());
        assertEquals("value1", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("value2", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("value3", iterator.next());
        assertFalse(iterator.hasNext());
    }


}
