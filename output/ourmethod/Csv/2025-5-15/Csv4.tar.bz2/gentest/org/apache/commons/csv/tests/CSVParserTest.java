package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                         public void testGetHeaderMap_WhenHeaderMapIsNull() throws Exception {
                                             // Setup mocks
                                             Reader reader = mock(Reader.class);
                                             CSVFormat format = mock(CSVFormat.class);
                                             
                                             // Setup parser with null header map
                                             when(format.getHeader()).thenReturn(null);
                                             CSVParser parser = new CSVParser(reader, format);
                                             
                                             // Verify null is returned
                                             assertNull(parser.getHeaderMap());
                                         }

 @Test
                                         public void testGetHeaderMap_WhenHeaderMapHasValues() throws Exception {
                                             // Setup expected header map
                                             Map<String, Integer> expectedHeaders = new LinkedHashMap<>();
                                             expectedHeaders.put("Name", 0);
                                             expectedHeaders.put("Age", 1);
                                             expectedHeaders.put("City", 2);
                                             
                                             // Setup mocks
                                             Reader reader = new StringReader("");
                                             CSVFormat format = mock(CSVFormat.class);
                                             
                                             // Setup format to return headers
                                             when(format.getHeader()).thenReturn(new String[]{"Name", "Age", "City"});
                                             CSVParser parser = new CSVParser(reader, format);
                                             
                                             // Verify returned map matches expected
                                             Map<String, Integer> result = parser.getHeaderMap();
                                             assertEquals(expectedHeaders, result);
                                             
                                             // Verify it's a different instance (defensive copy)
                                             assertNotSame(parser.getHeaderMap(), parser.getHeaderMap());
                                         }

 @Test
                                         public void testGetHeaderMap_ReturnsLinkedHashMap() throws Exception {
                                             // Setup mocks
                                             Reader reader = mock(Reader.class);
                                             CSVFormat format = mock(CSVFormat.class);
                                             
                                             // Setup headers
                                             when(format.getHeader()).thenReturn(new String[]{"A", "B"});
                                             CSVParser parser = new CSVParser(reader, format);
                                             
                                             // Verify type is LinkedHashMap
                                             assertTrue(parser.getHeaderMap() instanceof LinkedHashMap);
                                         }

 @Test
                                         public void testGetHeaderMap_ModificationDoesNotAffectOriginal() throws Exception {
                                             // Setup mocks
                                             Reader reader = mock(Reader.class);
                                             CSVFormat format = mock(CSVFormat.class);
                                             
                                             // Setup headers
                                             when(format.getHeader()).thenReturn(new String[]{"X", "Y"});
                                             CSVParser parser = new CSVParser(reader, format);
                                             
                                             // Get and modify the copy
                                             Map<String, Integer> headerCopy = parser.getHeaderMap();
                                             headerCopy.put("Z", 2);
                                             
                                             // Verify original wasn't modified
                                             Map<String, Integer> original = parser.getHeaderMap();
                                             assertEquals(2, original.size());
                                             assertFalse(original.containsKey("Z"));
                                         }

 @Test
                                         public void testGetHeaderMap_MaintainsInsertionOrder() throws Exception {
                                             // Setup mocks
                                             CSVFormat format = mock(CSVFormat.class);
                                             Reader reader = mock(Reader.class);
                                             
                                             // Setup headers in specific order
                                             String[] headers = {"First", "Second", "Third"};
                                             when(format.getHeader()).thenReturn(headers);
                                             CSVParser parser = new CSVParser(reader, format);
                                             
                                             // Verify order is maintained
                                             Map<String, Integer> result = parser.getHeaderMap();
                                             String[] keys = result.keySet().toArray(new String[0]);
                                             assertArrayEquals(headers, keys);
                                         }

 @Test
     public void testGetHeaderMapReturnsNullWhenHeaderMapIsNull() throws Exception {
         // Arrange
         // Create a CSVParser with null headerMap
         // Since headerMap is final and set in constructor, we need to mock or use reflection
         // Alternatively, we can create a parser with a format that results in null headerMap
         // For this test, we'll use reflection to set headerMap to null
         
         CSVParser parser = new CSVParser(new java.io.StringReader(""), CSVFormat.DEFAULT);
         try {
             // Use reflection to set the final headerMap field to null
             java.lang.reflect.Field field = CSVParser.class.getDeclaredField("headerMap");
             field.setAccessible(true);
             field.set(parser, null);
             
             // Act
             Map<String, Integer> result = parser.getHeaderMap();
             
             // Assert
             assertNull("Expected null when headerMap is null", result);
         } catch (NoSuchFieldException | IllegalAccessException e) {
             fail("Failed to set headerMap to null via reflection: " + e.getMessage());
         }
     }

 @Test
     public void testGetHeaderMapReturnsCopyWhenHeaderMapExists() throws Exception {
         // Arrange
         Map<String, Integer> originalMap = new LinkedHashMap<>();
         originalMap.put("Header1", 0);
         originalMap.put("Header2", 1);
         
         CSVParser parser = new CSVParser(new java.io.StringReader(""), CSVFormat.DEFAULT);
         try {
             // Use reflection to set the final headerMap field
             java.lang.reflect.Field field = CSVParser.class.getDeclaredField("headerMap");
             field.setAccessible(true);
             field.set(parser, originalMap);
             
             // Act
             Map<String, Integer> result = parser.getHeaderMap();
             
             // Assert
             assertNotNull("Should not return null when headerMap exists", result);
             assertEquals("Should return a copy with same contents", originalMap, result);
             assertNotSame("Should return a new instance, not the original", originalMap, result);
         } catch (NoSuchFieldException | IllegalAccessException e) {
             fail("Failed to set headerMap via reflection: " + e.getMessage());
         }
     }

}
