package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.TreeMap;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                            public void testGetNextRecord_SuccessfulRead() throws Exception {
                                                                                                                                                                // Setup test CSV data
                                                                                                                                                                String csvData = "name,age\nJohn,30\nJane,25";
                                                                                                                                                                CSVParser parser = new CSVParser(new StringReader(csvData), CSVFormat.DEFAULT);
                                                                                                                                                                Iterator<CSVRecord> iterator = parser.iterator();
                                                                                                                                                                
                                                                                                                                                                // Test first record
                                                                                                                                                                assertTrue(iterator.hasNext());
                                                                                                                                                                CSVRecord firstRecord = iterator.next();
                                                                                                                                                                assertNotNull(firstRecord);
                                                                                                                                                                assertEquals("John", firstRecord.get(0));
                                                                                                                                                                assertEquals("30", firstRecord.get(1));
                                                                                                                                                                
                                                                                                                                                                // Test second record
                                                                                                                                                                assertTrue(iterator.hasNext());
                                                                                                                                                                CSVRecord secondRecord = iterator.next();
                                                                                                                                                                assertNotNull(secondRecord);
                                                                                                                                                                assertEquals("Jane", secondRecord.get(0));
                                                                                                                                                                assertEquals("25", secondRecord.get(1));
                                                                                                                                                                
                                                                                                                                                                // Verify no more records
                                                                                                                                                                assertFalse(iterator.hasNext());
                                                                                                                                                                parser.close();
                                                                                                                                                            }

    @Test
                                                                                                                                                            public void testGetNextRecord_ClosedParser() throws Exception {
                                                                                                                                                                // Setup test CSV data
                                                                                                                                                                String csvData = "name,age\nJohn,30";
                                                                                                                                                                CSVParser parser = new CSVParser(new StringReader(csvData), CSVFormat.DEFAULT);
                                                                                                                                                                Iterator<CSVRecord> iterator = parser.iterator();
                                                                                                                                                                
                                                                                                                                                                // Close the parser
                                                                                                                                                                parser.close();
                                                                                                                                                                
                                                                                                                                                                // Verify hasNext() returns false
                                                                                                                                                                assertFalse(iterator.hasNext());
                                                                                                                                                                
                                                                                                                                                                // Verify next() throws IllegalStateException
                                                                                                                                                                try {
                                                                                                                                                                    iterator.next();
                                                                                                                                                                    fail("Expected IllegalStateException");
                                                                                                                                                                } catch (IllegalStateException e) {
                                                                                                                                                                    assertEquals("CSVParser has been closed", e.getMessage());
                                                                                                                                                                }
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testGetNextRecord_EmptyInput() throws Exception {
                                                                                                                                                            // Setup empty CSV data
                                                                                                                                                            String csvData = "";
                                                                                                                                                            CSVParser parser = new CSVParser(new StringReader(csvData), CSVFormat.DEFAULT);
                                                                                                                                                            
                                                                                                                                                            // Verify no records available
                                                                                                                                                            assertFalse(parser.iterator().hasNext());
                                                                                                                                                            
                                                                                                                                                            // Verify next() throws NoSuchElementException
                                                                                                                                                            try {
                                                                                                                                                                parser.iterator().next();
                                                                                                                                                                fail("Expected NoSuchElementException");
                                                                                                                                                            } catch (java.util.NoSuchElementException e) {
                                                                                                                                                                // expected
                                                                                                                                                            }
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testGetNextRecord_WithHeadersOnly() throws Exception {
                                                                                                                                                    // Setup CSV with only headers
                                                                                                                                                    String csvData = "name,age\n";
                                                                                                                                                    CSVParser parser = new CSVParser(new StringReader(csvData), CSVFormat.DEFAULT.withFirstRecordAsHeader());
                                                                                                                                                    
                                                                                                                                                    // Verify hasNext() returns false
                                                                                                                                                    assertFalse(parser.iterator().hasNext());
                                                                                                                                                    
                                                                                                                                                    // Verify header map is populated
                                                                                                                                                    assertNotNull(parser.getHeaderMap());
                                                                                                                                                    assertEquals(2, parser.getHeaderMap().size());
                                                                                                                                                }

    @Test
                                                                                public void testGetNextRecord_ThrowsIOException() throws Exception {
                                                                                    // Create a mock Reader that throws IOException
                                                                                    Reader mockReader = mock(Reader.class);
                                                                                    when(mockReader.read()).thenThrow(new IOException("Test IO Error"));
                                                                                    
                                                                                    // Create parser with mock reader
                                                                                    CSVFormat format = CSVFormat.DEFAULT;
                                                                                    CSVParser parser = new CSVParser(mockReader, format);
                                                                                    
                                                                                    // Use reflection to access private getNextRecord method
                                                                                    java.lang.reflect.Method method = CSVParser.class.getDeclaredMethod("getNextRecord");
                                                                                    method.setAccessible(true);
                                                                                    
                                                                                    try {
                                                                                        method.invoke(parser);
                                                                                        fail("Expected IOException to be thrown");
                                                                                    } catch (InvocationTargetException e) {
                                                                                        Throwable cause = e.getCause();
                                                                                        assertTrue(cause instanceof IOException);
                                                                                        assertEquals("Test IO Error", cause.getMessage());
                                                                                    }
                                                                                }

    @Test
                                        public void testIterator_WhenParserInitialized_ShouldReturnNonNullIterator() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("header1,header2\nvalue1,value2");
                                            CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                            CSVParser parser = new CSVParser(reader, format);
                                            
                                            // Act
                                            Iterator<CSVRecord> iterator = parser.iterator();
                                            
                                            // Assert
                                            assertNotNull("Iterator should not be null", iterator);
                                        }

    @Test
                                        public void testIterator_WhenParserInitialized_ShouldReturnSameInstance() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("header1,header2\nvalue1,value2");
                                            CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                            CSVParser parser = new CSVParser(reader, format);
                                            
                                            // Act
                                            Iterator<CSVRecord> iterator1 = parser.iterator();
                                            Iterator<CSVRecord> iterator2 = parser.iterator();
                                            
                                            // Assert
                                            assertSame("Multiple calls to iterator() should return same instance", iterator1, iterator2);
                                        }

    @Test
                                        public void testIterator_WhenParserClosed_ShouldNotAffectIterator() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("header1,header2\nvalue1,value2");
                                            CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                            CSVParser parser = new CSVParser(reader, format);
                                            Iterator<CSVRecord> iterator = parser.iterator();
                                            
                                            // Act
                                            parser.close();
                                            
                                            // Assert
                                            assertTrue("Iterator should still be usable after parser is closed", iterator.hasNext());
                                        }

    @Test
                                        public void testIterator_WhenEmptyInput_ShouldReturnEmptyIterator() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("");
                                            CSVFormat format = CSVFormat.DEFAULT;
                                            CSVParser parser = new CSVParser(reader, format);
                                            
                                            // Act
                                            Iterator<CSVRecord> iterator = parser.iterator();
                                            
                                            // Assert
                                            assertFalse("Iterator should be empty for empty input", iterator.hasNext());
                                        }

    @Test
                                        public void testIterator_WhenHeadersOnly_ShouldReturnEmptyIterator() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("header1,header2");
                                            CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                            CSVParser parser = new CSVParser(reader, format);
                                            
                                            // Act
                                            Iterator<CSVRecord> iterator = parser.iterator();
                                            
                                            // Assert
                                            assertFalse("Iterator should be empty when only headers present", iterator.hasNext());
                                        }

    @Test
                                        public void testIterator_WhenMultipleRecords_ShouldReturnCorrectNumberOfRecords() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("header1,header2\nvalue1,value2\nvalue3,value4");
                                            CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                            CSVParser parser = new CSVParser(reader, format);
                                            Iterator<CSVRecord> iterator = parser.iterator();
                                            int count = 0;
                                            
                                            // Act
                                            while (iterator.hasNext()) {
                                                iterator.next();
                                                count++;
                                            }
                                            
                                            // Assert
                                            assertEquals("Should return correct number of records", 2, count);
                                        }

    @Test
                                        public void testIterator_WhenCalledMultipleTimes_ShouldReturnSameIteratorInstance() throws IOException {
                                            // Arrange
                                            StringReader reader = new StringReader("header1,header2\nvalue1,value2");
                                            CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                            CSVParser parser = new CSVParser(reader, format);
                                            
                                            // Act
                                            Iterator<CSVRecord> firstCall = parser.iterator();
                                            Iterator<CSVRecord> secondCall = parser.iterator();
                                            
                                            // Assert
                                            assertSame("Multiple calls to iterator() should return same instance", firstCall, secondCall);
                                        }

    @Test
                                        public void testRemove_ShouldThrowUnsupportedOperationException() {
                                            // Arrange
                                            String csvData = "header1,header2\nvalue1,value2";
                                            CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
                                            CSVParser parser = null;
                                            try {
                                                parser = CSVParser.parse(csvData, format);
                                                Iterator<CSVRecord> iterator = parser.iterator();
                                                
                                                // Expect exception
                                                try {
                                                    // Act
                                                    iterator.remove();
                                                    fail("Expected UnsupportedOperationException");
                                                } catch (UnsupportedOperationException e) {
                                                    // Assert
                                                    // Exception was thrown as expected
                                                } finally {
                                                    try {
                                                        if (parser != null) {
                                                            parser.close();
                                                        }
                                                    } catch (IOException e) {
                                                        // Ignore
                                                    }
                                                }
                                            } catch (IOException e) {
                                                fail("Failed to parse CSV data: " + e.getMessage());
                                            }
                                        }


}
