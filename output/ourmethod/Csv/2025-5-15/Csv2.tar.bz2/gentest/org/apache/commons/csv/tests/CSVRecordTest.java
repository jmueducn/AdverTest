package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                public void testGet_WhenMappingIsNull_ThrowsIllegalStateException() throws Exception {
                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                    String[] values = {"value1", "value2"};
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Create instance using reflection
                                                                                                                                                                                                                                                                    Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                                                        String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                                                                    CSVRecord record = constructor.newInstance(values, null, null, 1L);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Expect exception
                                                                                                                                                                                                                                                                    thrown.expect(IllegalStateException.class);
                                                                                                                                                                                                                                                                    thrown.expectMessage("No header mapping was specified, the record values can't be accessed by name");
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Test
                                                                                                                                                                                                                                                                    record.get("anyName");
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testGet_WithNullValuesArray_ReturnsNullForValidName() throws Exception {
                                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                                    java.util.HashMap<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                                                                                                                                                    mapping.put("name", 0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Use reflection to access package-private constructor
                                                                                                                                                                                                                                                                    Class<?> clazz = Class.forName("org.apache.commons.csv.CSVRecord");
                                                                                                                                                                                                                                                                    Constructor<?> constructor = clazz.getDeclaredConstructor(
                                                                                                                                                                                                                                                                        String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                                                                                                    CSVRecord record = (CSVRecord) constructor.newInstance(
                                                                                                                                                                                                                                                                        null, mapping, null, 1L);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Test
                                                                                                                                                                                                                                                                    assertNull(record.get("name"));
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                        public void testGet_ValidIndex() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String[] testValues = {"value1", "value2", "value3"};
                                                                                                                                                                                                                            java.util.Map<String, Integer> mockMapping = new java.util.HashMap<>();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access package-private constructor
                                                                                                                                                                                                                            java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            CSVRecord record = constructor.newInstance(testValues, mockMapping, "comment", 1L);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Act & Assert
                                                                                                                                                                                                                            assertEquals("value1", record.get(0));
                                                                                                                                                                                                                            assertEquals("value2", record.get(1));
                                                                                                                                                                                                                            assertEquals("value3", record.get(2));
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_NegativeIndex() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String[] testValues = {"value1", "value2"};
                                                                                                                                                                                                                            java.util.Map<String, Integer> mockMapping = new java.util.HashMap<>();
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access private constructor
                                                                                                                                                                                                                            java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            CSVRecord record = constructor.newInstance(testValues, mockMapping, "comment", 1L);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Expect exception
                                                                                                                                                                                                                            thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Act
                                                                                                                                                                                                                            record.get(-1);
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_IndexOutOfBounds() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String[] testValues = {"value1", "value2"};
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access package-private constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                fail("Expected ArrayIndexOutOfBoundsException");
                                                                                                                                                                                                                            } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                                                                                // Assert
                                                                                                                                                                                                                                // Exception expected, test passes
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_NullValuesArrayUsesEmptyArray() {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String[] nullValues = null;
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access package-private constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor;
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                constructor = CSVRecord.class.getDeclaredConstructor(String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Expect exception (since EMPTY_STRING_ARRAY has length 0)
                                                                                                                                                                                                                                thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                fail("Failed to create CSVRecord instance: " + e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_WithNullValuesInArray() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String[] testValues = {null, "value2", null};
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access package-private constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Act & Assert
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_FirstAndLastElements() throws Exception {
                                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                                            String[] testValues = {"first", "middle", "last"};
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access non-public constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Act & Assert
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_WhenNameNotInMapping_ReturnsNull() {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            String[] values = {"value1", "value2"};
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                // Use reflection to access package-private constructor
                                                                                                                                                                                                                                Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                    String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                                constructor.setAccessible(true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Test
                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                fail("Failed to create CSVRecord instance: " + e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_WhenNameExists_ReturnsCorrectValue() throws Exception {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            String[] values = {"value1", "value2", "value3"};
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access non-public constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_WhenIndexOutOfBounds_ThrowsIllegalArgumentException() throws Exception {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            String[] values = {"value1"};
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access the package-private constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test and verify exception
                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                assertEquals("Index for header 'invalid' is 1 but CSVRecord only has 1 values!", e.getMessage());
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                        public void testGet_WithEmptyValuesArray_ReturnsNullForValidName() throws Exception {
                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                            String[] values = {};
                                                                                                                                                                                                                            java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                                                                                                            mapping.put("name", 0);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Use reflection to access non-public constructor
                                                                                                                                                                                                                            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                                                                String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                                                                            CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                                                                                                            
                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                            assertNull(record.get("name"));
                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                               public void testGetWithNullMappingShouldNotThrowException() throws Exception {
                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                   String[] values = {"value1", "value2"};
                                                                                                                                                                                   Map<String, Integer> nullMapping = null;
                                                                                                                                                                                   String comment = "test comment";
                                                                                                                                                                                   long recordNumber = 1L;
                                                                                                                                                                                   
                                                                                                                                                                                   // Get the constructor using reflection
                                                                                                                                                                                   Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                       String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Create CSVRecord with null mapping using reflection
                                                                                                                                                                                   CSVRecord record = constructor.newInstance(values, nullMapping, comment, recordNumber);
                                                                                                                                                                                   
                                                                                                                                                                                   // Test that get() works normally even with null mapping
                                                                                                                                                                                   assertEquals("value1", record.get(0));
                                                                                                                                                                                   assertEquals("value2", record.get(1));
                                                                                                                                                                               }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                               public void testGetWithNullMappingShouldThrowException() throws Exception {
                                                                                                                                                                                   // Arrange
                                                                                                                                                                                   String[] values = {"value1", "value2"};
                                                                                                                                                                                   // Use reflection to access the private constructor
                                                                                                                                                                                   Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                       String[].class, Map.class, String.class, long.class);
                                                                                                                                                                                   constructor.setAccessible(true);
                                                                                                                                                                                   CSVRecord record = constructor.newInstance(values, null, null, 1L);
                                                                                                                                                                                   
                                                                                                                                                                                   // Act
                                                                                                                                                                                   record.get("anyHeader");
                                                                                                                                                                                   // Assert is handled by expected exception
                                                                                                                                                                               }

    @Test
                                                                                                                                                                           public void testGetWithValidMappingShouldNotThrowException() throws Exception {
                                                                                                                                                                               // Arrange
                                                                                                                                                                               String[] values = {"value1", "value2"};
                                                                                                                                                                               java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                                                               mapping.put("header1", 0);
                                                                                                                                                                               mapping.put("header2", 1);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access the package-private constructor
                                                                                                                                                                               Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                                   String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                                               CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                                                               
                                                                                                                                                                               // Act & Assert
                                                                                                                                                                               try {
                                                                                                                                                                                   String result = record.get("header1");
                                                                                                                                                                                   assertEquals("value1", result); // Verify normal functionality works
                                                                                                                                                                               } catch (IllegalStateException e) {
                                                                                                                                                                                   fail("Should not throw IllegalStateException when mapping exists");
                                                                                                                                                                               }
                                                                                                                                                                           }

    @Test
                                                                                                                                                                       public void testGetWithNonNullMappingShouldWork() throws Exception {
                                                                                                                                                                           // Setup test data
                                                                                                                                                                           String[] values = {"value1", "value2"};
                                                                                                                                                                           java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                                                                           mapping.put("col1", 0);
                                                                                                                                                                           mapping.put("col2", 1);
                                                                                                                                                                           String comment = "test comment";
                                                                                                                                                                           long recordNumber = 1L;
                                                                                                                                                                           
                                                                                                                                                                           // Get the CSVRecord constructor using reflection
                                                                                                                                                                           java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                               String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           // Create CSVRecord with non-null mapping
                                                                                                                                                                           CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                                                                                                                           
                                                                                                                                                                           // Test that get() works normally
                                                                                                                                                                           assertEquals("value1", record.get(0));
                                                                                                                                                                           assertEquals("value2", record.get(1));
                                                                                                                                                                       }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                                              public void testGetWithInvalidIndexShouldThrowException() throws Exception {
                                                                                                                                                                  // Setup mapping with invalid index
                                                                                                                                                                  java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                                                  mapping.put("invalid", 99); // index out of bounds
                                                                                                                                                                  String[] values = {"value1"};
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to access package-private constructor
                                                                                                                                                                  java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                      String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                  CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                                                  
                                                                                                                                                                  // This should throw IllegalArgumentException
                                                                                                                                                                  record.get("invalid");
                                                                                                                                                                  
                                                                                                                                                                  // With the mutant, this would try to access index 0 and not throw
                                                                                                                                                              }

    @Test
                                                                                                                                                          public void testGetWithNameShouldReturnCorrectMappedValue() {
                                                                                                                                                              // Setup mapping and values
                                                                                                                                                              java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                                                              mapping.put("header1", 0);
                                                                                                                                                              mapping.put("header2", 1);
                                                                                                                                                              String[] values = {"value1", "value2"};
                                                                                                                                                              
                                                                                                                                                              try {
                                                                                                                                                                  // Get the constructor using reflection
                                                                                                                                                                  Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                                      String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                                  constructor.setAccessible(true);
                                                                                                                                                                  
                                                                                                                                                                  // Create CSVRecord with our mapping and values
                                                                                                                                                                  CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                                                  
                                                                                                                                                                  // Test that get returns correct value for each header
                                                                                                                                                                  assertEquals("value1", record.get("header1"));
                                                                                                                                                                  assertEquals("value2", record.get("header2"));
                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                  fail("Failed to create CSVRecord instance: " + e.getMessage());
                                                                                                                                                              }
                                                                                                                                                          }

    @Test
                                                                                                                                                      public void testGetByNameShouldReturnCorrectValueBasedOnMapping() throws Exception {
                                                                                                                                                          // Setup test data
                                                                                                                                                          String[] values = {"first", "second", "third"};
                                                                                                                                                          java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                                                          mapping.put("col1", 0);
                                                                                                                                                          mapping.put("col2", 1);
                                                                                                                                                          mapping.put("col3", 2);
                                                                                                                                                          
                                                                                                                                                          // Use reflection to access private constructor
                                                                                                                                                          java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                              String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                          constructor.setAccessible(true);
                                                                                                                                                          CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                                          
                                                                                                                                                          // Test that different names return different values based on mapping
                                                                                                                                                          assertEquals("first", record.get("col1"));
                                                                                                                                                          assertEquals("second", record.get("col2"));  // This would fail with the mutant
                                                                                                                                                          assertEquals("third", record.get("col3"));   // This would fail with the mutant
                                                                                                                                                          
                                                                                                                                                          // Additional test with non-zero index
                                                                                                                                                          mapping.put("another", 1);
                                                                                                                                                          assertEquals("second", record.get("another"));  // This would fail with the mutant
                                                                                                                                                      }

    @Test
                                                                                                                                                 public void testGetWithNonZeroIndexShouldReturnCorrectValue() throws Exception {
                                                                                                                                                     // Setup test data
                                                                                                                                                     String[] values = {"first", "second", "third"};
                                                                                                                                                     java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                                     mapping.put("header1", 0);  // maps to first element
                                                                                                                                                     mapping.put("header2", 1);  // maps to second element
                                                                                                                                                     mapping.put("header3", 2);  // maps to third element
                                                                                                                                                     
                                                                                                                                                     // Create test object using reflection to access package-private constructor
                                                                                                                                                     Class<?>[] paramTypes = {String[].class, java.util.Map.class, String.class, long.class};
                                                                                                                                                     java.lang.reflect.Constructor<?> constructor = 
                                                                                                                                                         CSVRecord.class.getDeclaredConstructor(paramTypes);
                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                     CSVRecord record = (CSVRecord) constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                                     
                                                                                                                                                     // Test that each header returns the correct value
                                                                                                                                                     assertEquals("first", record.get("header1"));
                                                                                                                                                     assertEquals("second", record.get("header2"));  // This will fail with the mutant
                                                                                                                                                     assertEquals("third", record.get("header3"));   // This will fail with the mutant
                                                                                                                                                     
                                                                                                                                                     // Also test with null mapping case
                                                                                                                                                     try {
                                                                                                                                                         CSVRecord nullRecord = (CSVRecord) constructor.newInstance(values, null, null, 1L);
                                                                                                                                                         nullRecord.get("any");
                                                                                                                                                         fail("Expected IllegalStateException");
                                                                                                                                                     } catch (IllegalStateException e) {
                                                                                                                                                         // expected
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     // Test with index out of bounds
                                                                                                                                                     mapping.put("invalid", 10);  // index beyond array length
                                                                                                                                                     try {
                                                                                                                                                         record.get("invalid");
                                                                                                                                                         fail("Expected IllegalArgumentException");
                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                         assertTrue(e.getMessage().contains("Index for header 'invalid' is 10"));
                                                                                                                                                     }
                                                                                                                                                 }

    @Test
                                                                                                                                             public void testGetIntShouldReturnCorrectIndexValue() throws Exception {
                                                                                                                                                 // Setup test data
                                                                                                                                                 String[] testValues = {"first", "second", "third"};
                                                                                                                                                 java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                                                 String comment = "test";
                                                                                                                                                 long recordNumber = 1L;
                                                                                                                                                 
                                                                                                                                                 // Get the CSVRecord constructor using reflection
                                                                                                                                                 Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                     String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                 
                                                                                                                                                 // Create CSVRecord with test data
                                                                                                                                                 CSVRecord record = constructor.newInstance(testValues, mapping, comment, recordNumber);
                                                                                                                                                 
                                                                                                                                                 // Test getting values from different indices
                                                                                                                                                 assertEquals("first", record.get(0));  // First element
                                                                                                                                                 assertEquals("second", record.get(1)); // Second element - would fail with mutant
                                                                                                                                                 assertEquals("third", record.get(2));  // Third element - would fail with mutant
                                                                                                                                                 
                                                                                                                                                 // Also test with empty array
                                                                                                                                                 CSVRecord emptyRecord = constructor.newInstance(new String[0], mapping, comment, recordNumber);
                                                                                                                                                 try {
                                                                                                                                                     emptyRecord.get(0);
                                                                                                                                                     fail("Should throw ArrayIndexOutOfBoundsException");
                                                                                                                                                 } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                     // Expected
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                        public void testGetWithNonExistentHeaderNameShouldReturnNull() throws Exception {
                                                                                                                                            // Setup
                                                                                                                                            String[] values = {"value1", "value2"};
                                                                                                                                            java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                                            mapping.put("header1", 0);
                                                                                                                                            mapping.put("header2", 1);
                                                                                                                                            
                                                                                                                                            // Use reflection to access private constructor
                                                                                                                                            java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                                String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                            CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                                            
                                                                                                                                            // Test with non-existent header name
                                                                                                                                            String result = record.get("nonexistent");
                                                                                                                                            
                                                                                                                                            // Assert - this will catch the mutant which returns "" instead of null
                                                                                                                                            assertNull("Method should return null for non-existent header names", result);
                                                                                                                                        }

    @Test
                                                                                                                                    public void testGetWithNullIndexShouldReturnNull() throws Exception {
                                                                                                                                        // Setup test data
                                                                                                                                        String[] testValues = {"value1", "value2"};
                                                                                                                                        java.util.Map<String, Integer> testMapping = new java.util.HashMap<String, Integer>();
                                                                                                                                        String testComment = "test";
                                                                                                                                        long testRecordNumber = 1L;
                                                                                                                                        
                                                                                                                                        // Get the CSVRecord constructor using reflection
                                                                                                                                        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                            String[].class, Map.class, String.class, long.class);
                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Create CSVRecord instance
                                                                                                                                        CSVRecord record = constructor.newInstance(testValues, testMapping, testComment, testRecordNumber);
                                                                                                                                        
                                                                                                                                        // Test with null index
                                                                                                                                        Integer nullIndex = null;
                                                                                                                                        String result = record.get(nullIndex);
                                                                                                                                        
                                                                                                                                        // Assert that null should be returned for null index
                                                                                                                                        assertNull("Expected null when index is null", result);
                                                                                                                                        
                                                                                                                                        // Additional assertion to explicitly catch the mutant
                                                                                                                                        assertNotEquals("Empty string should not be returned for null index", "", result);
                                                                                                                                    }

    @Test
                                                                                                                           public void testGetReturnsNullForMissingHeaderNotStringNull() throws Exception {
                                                                                                                               // Setup
                                                                                                                               java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                                                                               mapping.put("existingHeader", 0);
                                                                                                                               String[] values = {"value1"};
                                                                                                                               
                                                                                                                               // Use reflection to access private constructor
                                                                                                                               java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                                   String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                               constructor.setAccessible(true);
                                                                                                                               CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                                               
                                                                                                                               // Test non-existent header
                                                                                                                               String result = record.get("nonExistentHeader");
                                                                                                                               
                                                                                                                               // Assert
                                                                                                                               assertNull("Method should return null for missing header, not string 'null'", result);
                                                                                                                               
                                                                                                                               // Additional verification that it's not returning "null" string
                                                                                                                               assertFalse("\"null\" string was returned instead of null", "null".equals(result));
                                                                                                                           }

    @Test
                                                                                                                   public void testGetWithIntegerIndex() throws Exception {
                                                                                                                       // Setup test data
                                                                                                                       String[] testValues = {"value1", "value2", "value3"};
                                                                                                                       java.util.Map<String, Integer> testMapping = new java.util.HashMap<>();
                                                                                                                       String testComment = "test comment";
                                                                                                                       long testRecordNumber = 1L;
                                                                                                                       
                                                                                                                       // Get the constructor and make it accessible
                                                                                                                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                           String[].class, Map.class, String.class, long.class);
                                                                                                                       constructor.setAccessible(true);
                                                                                                                       
                                                                                                                       // Create test record using reflection - need to wrap array in Object[]
                                                                                                                       CSVRecord record = constructor.newInstance(
                                                                                                                           new Object[]{testValues, testMapping, testComment, testRecordNumber});
                                                                                                                       
                                                                                                                       // Test case 1: non-null index
                                                                                                                       Integer validIndex = 1;
                                                                                                                       assertEquals("value2", record.get(validIndex));
                                                                                                                       
                                                                                                                       // Test case 2: null index - this should catch the mutant
                                                                                                                       Integer nullIndex = null;
                                                                                                                       try {
                                                                                                                           record.get(nullIndex);
                                                                                                                           fail("Expected NullPointerException");
                                                                                                                       } catch (NullPointerException e) {
                                                                                                                           // Expected exception
                                                                                                                       }
                                                                                                                       
                                                                                                                       // Test case 3: edge case - first element
                                                                                                                       assertEquals("value1", record.get(0));
                                                                                                                       
                                                                                                                       // Test case 4: edge case - last element
                                                                                                                       assertEquals("value3", record.get(2));
                                                                                                                   }

    @Test
                                                                                                              public void testGetWithIntegerIndex_DetectsOffByOneMutant() throws Exception {
                                                                                                                  // Setup test data
                                                                                                                  String[] testValues = {"first", "second", "third"};
                                                                                                                  Map<String, Integer> mockMapping = mock(Map.class);
                                                                                                                  
                                                                                                                  // Use reflection to access package-private constructor
                                                                                                                  Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                      String[].class, Map.class, String.class, long.class);
                                                                                                                  constructor.setAccessible(true);
                                                                                                                  CSVRecord record = constructor.newInstance(testValues, mockMapping, null, 1L);
                                                                                                                  
                                                                                                                  // Test index 1 should return "second"
                                                                                                                  Integer index = 1;
                                                                                                                  String expected = "second";
                                                                                                                  
                                                                                                                  // Verify
                                                                                                                  assertEquals("Should return exact index position", 
                                                                                                                             expected, 
                                                                                                                             record.get(index));
                                                                                                                  
                                                                                                                  // Additional edge case - first element
                                                                                                                  index = 0;
                                                                                                                  expected = "first";
                                                                                                                  assertEquals("Should handle first element correctly",
                                                                                                                             expected,
                                                                                                                             record.get(index));
                                                                                                                  
                                                                                                                  // Additional edge case - last element
                                                                                                                  index = 2;
                                                                                                                  expected = "third";
                                                                                                                  assertEquals("Should handle last element correctly",
                                                                                                                             expected,
                                                                                                                             record.get(index));
                                                                                                              }

    @Test
                                                                                                              public void testGetWithIndexZeroShouldNotCauseUnderflow() throws Exception {
                                                                                                                  // Setup test data where a header maps to index 0
                                                                                                                  String[] values = {"value0", "value1"};
                                                                                                                  java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                                  mapping.put("header0", 0);  // header0 maps to index 0
                                                                                                                  
                                                                                                                  // Use reflection to access package-private constructor
                                                                                                                  java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                                                                                                      org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                                                                                                          String[].class, java.util.Map.class, String.class, long.class);
                                                                                                                  constructor.setAccessible(true);
                                                                                                                  
                                                                                                                  // Create test object
                                                                                                                  org.apache.commons.csv.CSVRecord record = constructor.newInstance(
                                                                                                                      values, mapping, null, 1L);
                                                                                                                  
                                                                                                                  // Test and verify
                                                                                                                  assertEquals("value0", record.get("header0"));
                                                                                                                  // Mutant would try to access values[-1] causing ArrayIndexOutOfBoundsException
                                                                                                                  // which would then be wrapped in IllegalArgumentException
                                                                                                              }

    @Test
                                                                                                          public void testGetWithValidIndexShouldReturnCorrectValue() throws Exception {
                                                                                                              // Setup test data
                                                                                                              String[] values = {"value0", "value1", "value2"};
                                                                                                              java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                              mapping.put("header1", 1);  // header1 maps to index 1
                                                                                                              
                                                                                                              // Create test object using reflection to access package-private constructor
                                                                                                              Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                                  String[].class, java.util.Map.class, String.class, long.class);
                                                                                                              constructor.setAccessible(true);
                                                                                                              CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                                                                              
                                                                                                              // Test and verify
                                                                                                              assertEquals("value1", record.get("header1"));
                                                                                                              // This will fail with mutant since mutant would return values[0] ("value0") instead of values[1] ("value1")
                                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                                                     public void testGet_ShouldCatchArrayIndexOutOfBounds() throws Exception {
                                                                                                         // Setup mapping with invalid index
                                                                                                         java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                         mapping.put("testHeader", 999); // Index way beyond array bounds
                                                                                                         
                                                                                                         // Create record with small values array and our problematic mapping
                                                                                                         String[] values = {"value1", "value2"};
                                                                                                         
                                                                                                         // Use reflection to access package-private constructor
                                                                                                         java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                                                                                             org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                                                                                                 String[].class, java.util.Map.class, String.class, long.class);
                                                                                                         constructor.setAccessible(true);
                                                                                                         org.apache.commons.csv.CSVRecord record = 
                                                                                                             constructor.newInstance(values, mapping, null, 1L);
                                                                                                         
                                                                                                         // This should throw ArrayIndexOutOfBounds which should be caught 
                                                                                                         // and converted to IllegalArgumentException
                                                                                                         record.get("testHeader");
                                                                                                     }

    @Test
                                                                                                 public void testGetWithInvalidIndexShouldThrowArrayIndexOutOfBounds() {
                                                                                                     // Prepare test data
                                                                                                     String[] values = {"value1", "value2"};
                                                                                                     java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                     String comment = "test";
                                                                                                     long recordNumber = 1L;
                                                                                                     
                                                                                                     // Create CSVRecord with test data using reflection since constructor is not public
                                                                                                     CSVRecord record;
                                                                                                     try {
                                                                                                         Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                             String[].class, java.util.Map.class, String.class, long.class);
                                                                                                         constructor.setAccessible(true);
                                                                                                         record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                                                     } catch (Exception e) {
                                                                                                         throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                     }
                                                                                                     
                                                                                                     // Set expectation for exception
                                                                                                     thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                                                                     
                                                                                                     // Trigger the test - this should throw ArrayIndexOutOfBoundsException
                                                                                                     // in the original code, but would be caught if the mutant survives
                                                                                                     record.get(5); // Using index clearly out of bounds
                                                                                                 }

    @Test
                                                                                        public void testGetWithInvalidIndexThrowsIllegalArgumentException() {
                                                                                            // Prepare test data
                                                                                            String[] testValues = {"value1", "value2"};
                                                                                            Map<String, Integer> testMapping = new java.util.HashMap<String, Integer>();
                                                                                            String testComment = "test";
                                                                                            long testRecordNumber = 1L;
                                                                                            
                                                                                            // Create CSVRecord instance - using reflection to access package-private constructor
                                                                                            CSVRecord record;
                                                                                            try {
                                                                                                Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                    String[].class, Map.class, String.class, long.class);
                                                                                                constructor.setAccessible(true);
                                                                                                record = constructor.newInstance(testValues, testMapping, testComment, testRecordNumber);
                                                                                            } catch (Exception e) {
                                                                                                throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                            }
                                                                                            
                                                                                            // Set expectation for the exception
                                                                                            org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Index out of bounds");
                                                                                            
                                                                                            // Trigger the exception by accessing out-of-bounds index
                                                                                            record.get(2); // Only valid indices are 0 and 1
                                                                                        }

    @Test
                                                                                    public void testGet_ThrowsIllegalArgumentExceptionWhenIndexOutOfBounds() throws Exception {
                                                                                        // Setup
                                                                                        String[] values = {"value1", "value2"};
                                                                                        java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                                                        mapping.put("header1", 2); // This index is out of bounds for values array
                                                                                        
                                                                                        // Use reflection to access package-private constructor
                                                                                        Class<?> clazz = Class.forName("org.apache.commons.csv.CSVRecord");
                                                                                        java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(
                                                                                            String[].class, java.util.Map.class, String.class, long.class);
                                                                                        constructor.setAccessible(true);
                                                                                        Object record = constructor.newInstance(values, mapping, null, 1L);
                                                                                        
                                                                                        // Exercise & Verify
                                                                                        try {
                                                                                            clazz.getMethod("get", String.class).invoke(record, "header1");
                                                                                            fail("Expected IllegalArgumentException to be thrown");
                                                                                        } catch (InvocationTargetException e) {
                                                                                            Throwable cause = e.getCause();
                                                                                            assertEquals("Index for header 'header1' is 2 but CSVRecord only has 2 values!", 
                                                                                                        cause.getMessage());
                                                                                            // Removed the rethrow statement as we've already verified the exception
                                                                                        }
                                                                                    }

    @Test
                                                                           public void testGet_ShouldThrowExceptionWithDetailedMessageWhenIndexOutOfBounds() throws Exception {
                                                                               // Setup test data
                                                                               String[] values = {"value1", "value2"};
                                                                               java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                               mapping.put("header1", 0);  // valid index
                                                                               mapping.put("header2", 5);  // invalid index (out of bounds)
                                                                               String comment = "test comment";
                                                                               long recordNumber = 1L;
                                                                               
                                                                               // Use reflection to access non-public constructor
                                                                               Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                   String[].class, java.util.Map.class, String.class, long.class);
                                                                               constructor.setAccessible(true);
                                                                               CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                               
                                                                               // Set up expected exception
                                                                               ExpectedException expectedEx = ExpectedException.none();
                                                                               expectedEx.expect(IllegalArgumentException.class);
                                                                               expectedEx.expectMessage("Index for header 'header2' is 5 but CSVRecord only has 2 values!");
                                                                               
                                                                               // Trigger the exception
                                                                               record.get("header2");
                                                                           }

    @Test
                                                                   public void testGetWithInvalidIndexShouldThrowExceptionWithDetailedMessage() throws Exception {
                                                                       // Prepare test data
                                                                       String[] values = {"value1", "value2"};
                                                                       java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                                       mapping.put("header1", 0);
                                                                       mapping.put("header2", 1);
                                                                       String comment = "test comment";
                                                                       long recordNumber = 1L;
                                                                       
                                                                       // Create CSVRecord instance using reflection since constructor is not public
                                                                       java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                           String[].class, java.util.Map.class, String.class, long.class);
                                                                       constructor.setAccessible(true);
                                                                       CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                                       
                                                                       // Set up exception expectation
                                                                       try {
                                                                           record.get(2); // Index 2 is out of bounds for array of length 2
                                                                           fail("Expected IndexOutOfBoundsException");
                                                                       } catch (IndexOutOfBoundsException e) {
                                                                           assertTrue(e.getMessage().contains("Index for header"));
                                                                           assertTrue(e.getMessage().contains("is"));
                                                                           assertTrue(e.getMessage().contains("but CSVRecord only has"));
                                                                       }
                                                                   }

    @Test
                                                          public void testGetWithNegativeIndexShouldThrowExceptionWithDescriptiveMessage() throws Exception {
                                                              // Setup test data
                                                              String[] values = {"value1", "value2"};
                                                              java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                              String comment = "test comment";
                                                              long recordNumber = 1L;
                                                              
                                                              // Setup expected exception rule
                                                              org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                              expectedException.expect(ArrayIndexOutOfBoundsException.class);
                                                              expectedException.expectMessage("Index for header");
                                                              
                                                              // Get the constructor and make it accessible
                                                              Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                  String[].class, Map.class, String.class, long.class);
                                                              constructor.setAccessible(true);
                                                              
                                                              // Create CSVRecord instance using reflection
                                                              CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                                              
                                                              // Test with negative index
                                                              record.get(-1);
                                                          }

    @Test
                                      public void testGetWithInvalidIndexShouldThrowExceptionWithDescriptiveMessage() throws Exception {
                                          // Setup test data
                                          String[] values = {"value1", "value2"};
                                          java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                          String comment = "test comment";
                                          long recordNumber = 1L;
                                          
                                          // Setup exception expectation
                                          org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                          exception.expect(ArrayIndexOutOfBoundsException.class);
                                          exception.expectMessage("Index for header"); // Original would have this message
                                          
                                          // Get constructor via reflection
                                          java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                              String[].class, java.util.Map.class, String.class, long.class);
                                          constructor.setAccessible(true);
                                          
                                          // Create CSVRecord instance
                                          CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                          
                                          // Test with invalid index
                                          int invalidIndex = values.length; // This is out of bounds
                                          record.get(invalidIndex);
                                      }

    @Test
                                      public void testGetWithInvalidIndexShouldThrowExceptionWithDescriptiveMessage1() throws Exception {
                                          // Setup test data
                                          String[] values = {"value1", "value2"};
                                          java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                          String comment = "test comment";
                                          long recordNumber = 1L;
                                          
                                          // Setup exception expectation
                                          ExpectedException exception = ExpectedException.none();
                                          exception.expect(ArrayIndexOutOfBoundsException.class);
                                          exception.expectMessage("Index for header"); // Original would have this message
                                          
                                          // Get constructor via reflection
                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                              String[].class, java.util.Map.class, String.class, long.class);
                                          constructor.setAccessible(true);
                                          
                                          // Create CSVRecord instance
                                          CSVRecord record = constructor.newInstance(values, mapping, comment, recordNumber);
                                          
                                          // Test with invalid index
                                          int invalidIndex = values.length; // This is out of bounds
                                          record.get(invalidIndex);
                                      }

    @Test
                                 public void testGet_ShouldIncludeHeaderNameInOutOfBoundsErrorMessage() {
                                     // Setup
                                     String headerName = "testHeader";
                                     int outOfBoundsIndex = 10;
                                     String[] values = new String[]{"value1", "value2"};
                                     
                                     Map<String, Integer> mapping = new java.util.HashMap<>();
                                     mapping.put(headerName, outOfBoundsIndex);
                                     
                                     // Use reflection to access package-private constructor
                                     try {
                                         Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                             String[].class, Map.class, String.class, long.class);
                                         constructor.setAccessible(true);
                                         CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                         
                                         // Act & Assert
                                         try {
                                             record.get(headerName);
                                             fail("Expected IllegalArgumentException");
                                         } catch (IllegalArgumentException e) {
                                             // Verify the exception message contains the original header name
                                             assertTrue("Exception message should contain header name", 
                                                      e.getMessage().contains(headerName));
                                             throw e;
                                         }
                                     } catch (Exception e) {
                                         fail("Failed to create CSVRecord instance: " + e.getMessage());
                                     }
                                 }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                             public void testGetWithNullValuesDetectsMutant() throws Exception {
                                 // This test will pass with the mutant (throws NPE) 
                                 // but fail with original code (would throw ArrayIndexOutOfBoundsException)
                                 java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                 
                                 // Use reflection to access the non-public constructor
                                 Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                     String[].class, java.util.Map.class, String.class, long.class);
                                 constructor.setAccessible(true);
                                 
                                 // Create record with null values array
                                 CSVRecord record = constructor.newInstance(null, mapping, null, 1L);
                                 
                                 // This should throw ArrayIndexOutOfBoundsException with original code
                                 record.get(0);
                             }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
                         public void testGetWithEmptyValues() throws Exception {
                             String[] values = {};
                             java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                 String[].class, Map.class, String.class, long.class);
                             constructor.setAccessible(true);
                             CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                             record.get(0); // Should throw ArrayIndexOutOfBoundsException
                         }

    @Test
                     public void testGetWithNonNullValues() {
                         String[] values = {"a", "b", "c"};
                         java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                         try {
                             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                 String[].class, Map.class, String.class, long.class);
                             constructor.setAccessible(true);
                             CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                             
                             assertEquals("a", record.get(0));
                             assertEquals("b", record.get(1));
                             assertEquals("c", record.get(2));
                         } catch (Exception e) {
                             fail("Failed to create CSVRecord instance: " + e.getMessage());
                         }
                     }

    @Test
            public void testGet_ShouldThrowExceptionWithCorrectArrayLength() throws Exception {
                // Setup
                java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                mapping.put("header1", 1); // This index is out of bounds
                String[] values = new String[]{"value0"}; // Only has index 0
                
                // Create CSVRecord instance using reflection since constructor is not public
                java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                    String[].class, java.util.Map.class, String.class, long.class);
                constructor.setAccessible(true);
                CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                
                // Expected exception
                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                exception.expect(IllegalArgumentException.class);
                exception.expectMessage("Index for header 'header1' is 1 but CSVRecord only has 1 values!");
                
                // Test
                record.get("header1");
            }

    @Test
        public void testGetInt_ShouldReturnValueForValidIndex() {
            // Setup
            String[] values = {"value1", "value2", "value3"};
            java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
            long recordNumber = 1L;
            String comment = null;
            
            // Create record using reflection since constructor is package-private
            CSVRecord record;
            try {
                java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                    String[].class, java.util.Map.class, String.class, long.class);
                constructor.setAccessible(true);
                record = constructor.newInstance(values, mapping, comment, recordNumber);
            } catch (Exception e) {
                throw new RuntimeException("Failed to create CSVRecord instance", e);
            }
            
            // Test valid indices
            assertEquals("value1", record.get(0));
            assertEquals("value2", record.get(1));
            assertEquals("value3", record.get(2));
        }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
        public void testGetInt_ShouldThrowForNegativeIndex() throws Exception {
            // Setup
            String[] values = {"value1", "value2"};
            java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
            long recordNumber = 1L;
            
            // Use reflection to access the package-private constructor
            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                String[].class, java.util.Map.class, String.class, long.class);
            constructor.setAccessible(true);
            CSVRecord record = constructor.newInstance(values, mapping, null, recordNumber);
            
            // Test negative index - should throw ArrayIndexOutOfBoundsException
            record.get(-1);
        }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testGetInt_ShouldThrowWhenIndexExceedsArrayBounds() throws Exception {
        // Setup
        String[] smallArray = {"a", "b", "c"};
        java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
        long recordNumber = 1L;
        
        // Get the package-private constructor using reflection
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, java.util.Map.class, String.class, long.class);
        constructor.setAccessible(true);
        
        // Create record with small array (length=3)
        CSVRecord record = constructor.newInstance(smallArray, mapping, null, recordNumber);
        
        // Try to access index beyond array bounds
        // This should throw ArrayIndexOutOfBoundsException
        record.get(3);
    }


}
