package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                         public void testNewFormat_WithValidDelimiter() {
                                                                                                                             // Test with typical delimiter characters
                                                                                                                             char comma = ',';
                                                                                                                             char tab = '\t';
                                                                                                                             char pipe = '|';
                                                                                                                             
                                                                                                                             CSVFormat commaFormat = CSVFormat.newFormat(comma);
                                                                                                                             assertEquals(comma, commaFormat.getDelimiter());
                                                                                                                             assertNull(commaFormat.getQuoteCharacter());
                                                                                                                             assertNull(commaFormat.getQuoteMode());
                                                                                                                             assertNull(commaFormat.getCommentMarker());
                                                                                                                             assertNull(commaFormat.getEscapeCharacter());
                                                                                                                             assertFalse(commaFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertFalse(commaFormat.getIgnoreEmptyLines());
                                                                                                                             assertNull(commaFormat.getRecordSeparator());
                                                                                                                             assertNull(commaFormat.getNullString());
                                                                                                                             assertNull(commaFormat.getHeader());
                                                                                                                             assertFalse(commaFormat.getSkipHeaderRecord());
                                                                                                                             assertFalse(commaFormat.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             CSVFormat tabFormat = CSVFormat.newFormat(tab);
                                                                                                                             assertEquals(tab, tabFormat.getDelimiter());
                                                                                                                             
                                                                                                                             CSVFormat pipeFormat = CSVFormat.newFormat(pipe);
                                                                                                                             assertEquals(pipe, pipeFormat.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testNewFormat_WithSpecialCharacters() {
                                                                                                                             // Test with special characters that are not line breaks
                                                                                                                             char semicolon = ';';
                                                                                                                             char colon = ':';
                                                                                                                             char dollar = '$';
                                                                                                                             
                                                                                                                             CSVFormat semicolonFormat = CSVFormat.newFormat(semicolon);
                                                                                                                             assertEquals(semicolon, semicolonFormat.getDelimiter());
                                                                                                                             
                                                                                                                             CSVFormat colonFormat = CSVFormat.newFormat(colon);
                                                                                                                             assertEquals(colon, colonFormat.getDelimiter());
                                                                                                                             
                                                                                                                             CSVFormat dollarFormat = CSVFormat.newFormat(dollar);
                                                                                                                             assertEquals(dollar, dollarFormat.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testNewFormat_WithLineBreakDelimiterShouldThrowException() {
                                                                                                                             // Test that using line break characters as delimiter throws exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                             
                                                                                                                             char newline = '\n';
                                                                                                                             CSVFormat.newFormat(newline);
                                                                                                                         }

 @Test
                                                                                                                         public void testNewFormat_WithCarriageReturnDelimiterShouldThrowException() {
                                                                                                                             // Test that using carriage return as delimiter throws exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                             
                                                                                                                             char carriageReturn = '\r';
                                                                                                                             CSVFormat.newFormat(carriageReturn);
                                                                                                                         }

 @Test
                                                                                                                         public void testNewFormat_DefaultValues() {
                                                                                                                             // Verify all other fields are set to default values (null or false)
                                                                                                                             char delimiter = ';';
                                                                                                                             CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                             
                                                                                                                             // Verify all nullable fields are null
                                                                                                                             assertNull(format.getQuoteCharacter());
                                                                                                                             assertNull(format.getQuoteMode());
                                                                                                                             assertNull(format.getCommentMarker());
                                                                                                                             assertNull(format.getEscapeCharacter());
                                                                                                                             assertNull(format.getRecordSeparator());
                                                                                                                             assertNull(format.getNullString());
                                                                                                                             assertNull(format.getHeader());
                                                                                                                             
                                                                                                                             // Verify all boolean fields are false
                                                                                                                             assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                             assertFalse(format.getIgnoreEmptyLines());
                                                                                                                             assertFalse(format.getSkipHeaderRecord());
                                                                                                                             assertFalse(format.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testNewFormat_EqualsAndHashCode() {
                                                                                                                             // Test that two instances with same delimiter are equal
                                                                                                                             char delimiter1 = ',';
                                                                                                                             char delimiter2 = ',';
                                                                                                                             
                                                                                                                             CSVFormat format1 = CSVFormat.newFormat(delimiter1);
                                                                                                                             CSVFormat format2 = CSVFormat.newFormat(delimiter2);
                                                                                                                             
                                                                                                                             assertEquals(format1, format2);
                                                                                                                             assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                             
                                                                                                                             // Test with different delimiters
                                                                                                                             char delimiter3 = '|';
                                                                                                                             CSVFormat format3 = CSVFormat.newFormat(delimiter3);
                                                                                                                             
                                                                                                                             assertNotEquals(format1, format3);
                                                                                                                             assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithSingleValue() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Object[] values = {"test"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("test", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithMultipleValues() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Object[] values = {"value1", "value2", "value3"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("value1,value2,value3", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithEmptyValues() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Object[] values = {};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithNullValues() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                             Object[] values = {null, "value", null};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("NULL,value,NULL", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithCustomDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.newFormat('|');
                                                                                                                             Object[] values = {"a", "b", "c"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("a|b|c", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithQuotedValues() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                             Object[] values = {"value,with,comma", "normal"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("\"value,with,comma\",normal", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithSpecialCharacters() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Object[] values = {"line\nbreak", "tab\tcharacter", "quote\"mark"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("line\nbreak,tab\tcharacter,quote\"mark", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithDifferentRecordSeparator() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                             Object[] values = {"value1", "value2"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("value1,value2", result); // Record separator shouldn't affect format() output
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WhenStringWriterThrowsIOException() throws IOException {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             StringWriter mockWriter = mock(StringWriter.class);
                                                                                                                             when(mockWriter.toString()).thenThrow(new IOException("Test exception"));
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalStateException.class);
                                                                                                                             thrown.expectMessage("java.io.IOException: Test exception");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             format.format(new Object[]{"test"}, mockWriter);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithDifferentQuoteModes() {
                                                                                                                             // Setup - Test ALL quote mode
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                             Object[] values = {"value1", "value2"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("\"value1\",\"value2\"", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithEmptyStringValues() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Object[] values = {"", "", ""};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(",", result); // Two empty strings with comma delimiter
                                                                                                                         }

 @Test
                                                                                                                         public void testFormat_WithMixedTypes() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Object[] values = {123, 45.67, true, "text"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             String result = format.format(values);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals("123,45.67,true,text", result);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_UsingDefaultFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualCommentMarker = format.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(actualCommentMarker);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_UsingExcelFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.EXCEL;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualCommentMarker = format.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(actualCommentMarker);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_UsingTDFFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.TDF;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualCommentMarker = format.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(actualCommentMarker);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_UsingMySQLFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.MYSQL;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualCommentMarker = format.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(actualCommentMarker);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_UsingRFC4180Format() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.RFC4180;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualCommentMarker = format.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(actualCommentMarker);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_AfterWithCommentMarker() {
                                                                                                                             // Arrange
                                                                                                                             Character expectedCommentMarker = ';';
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             CSVFormat modifiedFormat = originalFormat.withCommentMarker(expectedCommentMarker);
                                                                                                                             Character actualCommentMarker = modifiedFormat.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                                                             assertNull(originalFormat.getCommentMarker()); // original should remain unchanged
                                                                                                                         }

 @Test
                                                                                                                         public void testGetCommentMarker_AfterWithNullCommentMarker() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             CSVFormat modifiedFormat = originalFormat.withCommentMarker(null);
                                                                                                                             Character actualCommentMarker = modifiedFormat.getCommentMarker();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(actualCommentMarker);
                                                                                                                             assertEquals(Character.valueOf('#'), originalFormat.getCommentMarker()); // original should remain unchanged
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_DefaultFormat() {
                                                                                                                             // Test with DEFAULT format (comma delimiter)
                                                                                                                             assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_ExcelFormat() {
                                                                                                                             // Test with EXCEL format (comma delimiter)
                                                                                                                             assertEquals(',', CSVFormat.EXCEL.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_TabDelimitedFormat() {
                                                                                                                             // Test with TDF format (tab delimiter)
                                                                                                                             assertEquals('\t', CSVFormat.TDF.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_MySQLFormat() {
                                                                                                                             // Test with MYSQL format (tab delimiter)
                                                                                                                             assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_RFC4180Format() {
                                                                                                                             // Test with RFC4180 format (comma delimiter)
                                                                                                                             assertEquals(',', CSVFormat.RFC4180.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_CustomFormat() {
                                                                                                                             // Test with custom delimiter
                                                                                                                             char customDelimiter = '|';
                                                                                                                             CSVFormat format = CSVFormat.newFormat(customDelimiter);
                                                                                                                             assertEquals(customDelimiter, format.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_NonStandardDelimiter() {
                                                                                                                             // Test with non-standard delimiter
                                                                                                                             char nonStandardDelimiter = ';';
                                                                                                                             CSVFormat format = CSVFormat.newFormat(nonStandardDelimiter);
                                                                                                                             assertEquals(nonStandardDelimiter, format.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetDelimiter_AfterWithDelimiter() {
                                                                                                                             // Test that withDelimiter creates a new format with the correct delimiter
                                                                                                                             char originalDelimiter = ',';
                                                                                                                             char newDelimiter = ';';
                                                                                                                             CSVFormat original = CSVFormat.newFormat(originalDelimiter);
                                                                                                                             CSVFormat modified = original.withDelimiter(newDelimiter);
                                                                                                                             
                                                                                                                             assertEquals(originalDelimiter, original.getDelimiter());
                                                                                                                             assertEquals(newDelimiter, modified.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_UsingDefaultFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character escapeChar = defaultFormat.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(escapeChar);  // DEFAULT format typically has no escape character
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_UsingExcelFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character escapeChar = excelFormat.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(escapeChar);  // EXCEL format typically has no escape character
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_UsingTDFFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat tdfFormat = CSVFormat.TDF;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character escapeChar = tdfFormat.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(escapeChar);  // TDF format typically has no escape character
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_UsingMySQLFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat mysqlFormat = CSVFormat.MYSQL;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character escapeChar = mysqlFormat.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals(Character.valueOf('\\'), escapeChar);  // MySQL uses backslash as escape
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_UsingRFC4180Format() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat rfc4180Format = CSVFormat.RFC4180;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character escapeChar = rfc4180Format.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(escapeChar);  // RFC4180 doesn't specify an escape character
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_AfterModificationWithWithEscape() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character newEscape = '!';
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             CSVFormat modifiedFormat = originalFormat.withEscape(newEscape);
                                                                                                                             Character escapeChar = modifiedFormat.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals(newEscape, escapeChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetEscapeCharacter_AfterModificationWithNullEscape() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat originalFormat = CSVFormat.newFormat(',').withEscape('\\');
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             CSVFormat modifiedFormat = originalFormat.withEscape(null);
                                                                                                                             Character escapeChar = modifiedFormat.getEscapeCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull(escapeChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetAllowMissingColumnNames_WhenTrue() {
                                                                                                                             // Create a CSVFormat instance with allowMissingColumnNames set to true
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                                                             
                                                                                                                             // Verify the getter returns true
                                                                                                                             assertTrue(format.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetAllowMissingColumnNames_WhenFalse() {
                                                                                                                             // Create a CSVFormat instance with allowMissingColumnNames set to false
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                             // Verify the getter returns false
                                                                                                                             assertFalse(format.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetAllowMissingColumnNames_DefaultValue() {
                                                                                                                             // Verify the default value is false (based on common CSV format conventions)
                                                                                                                             assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
                                                                                                                             assertFalse(CSVFormat.RFC4180.getAllowMissingColumnNames());
                                                                                                                             assertFalse(CSVFormat.EXCEL.getAllowMissingColumnNames());
                                                                                                                             assertFalse(CSVFormat.TDF.getAllowMissingColumnNames());
                                                                                                                             assertFalse(CSVFormat.MYSQL.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetAllowMissingColumnNames_AfterModification() {
                                                                                                                             // Create a format and modify the setting
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                                                             assertTrue(format.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Modify it again
                                                                                                                             CSVFormat modifiedFormat = format.withAllowMissingColumnNames(false);
                                                                                                                             assertFalse(modifiedFormat.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Original format should remain unchanged
                                                                                                                             assertTrue(format.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreEmptyLines_DefaultFormat() {
                                                                                                                             // Test with DEFAULT format (should be false according to commons-csv behavior)
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             assertFalse("DEFAULT format should have ignoreEmptyLines=false", 
                                                                                                                                        format.getIgnoreEmptyLines());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreEmptyLines_AfterWithIgnoreEmptyLines() {
                                                                                                                             // Test behavior after using withIgnoreEmptyLines
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             CSVFormat modifiedTrue = original.withIgnoreEmptyLines(true);
                                                                                                                             CSVFormat modifiedFalse = original.withIgnoreEmptyLines(false);
                                                                                                                             
                                                                                                                             assertTrue("Modified with true should return true",
                                                                                                                                       modifiedTrue.getIgnoreEmptyLines());
                                                                                                                             assertFalse("Modified with false should return false",
                                                                                                                                        modifiedFalse.getIgnoreEmptyLines());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreEmptyLines_WithDifferentFormats() {
                                                                                                                             // Test with different predefined formats
                                                                                                                             assertFalse("RFC4180 format should have ignoreEmptyLines=false",
                                                                                                                                        CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                                                             assertFalse("EXCEL format should have ignoreEmptyLines=false",
                                                                                                                                        CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                                                             assertFalse("TDF format should have ignoreEmptyLines=false",
                                                                                                                                        CSVFormat.TDF.getIgnoreEmptyLines());
                                                                                                                             assertFalse("MYSQL format should have ignoreEmptyLines=false",
                                                                                                                                        CSVFormat.MYSQL.getIgnoreEmptyLines());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_WhenTrue() {
                                                                                                                             // Create a CSVFormat instance with ignoreSurroundingSpaces set to true
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                             assertTrue("Should return true when ignoreSurroundingSpaces is set", 
                                                                                                                                        format.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_WhenFalse() {
                                                                                                                             // Create a CSVFormat instance with ignoreSurroundingSpaces set to false
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                             assertFalse("Should return false when ignoreSurroundingSpaces is not set", 
                                                                                                                                         format.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_DefaultFormat() {
                                                                                                                             // Test the default format's setting
                                                                                                                             assertFalse("DEFAULT format should have ignoreSurroundingSpaces false by default", 
                                                                                                                                         CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_RFC4180Format() {
                                                                                                                             // Test the RFC4180 format's setting
                                                                                                                             assertFalse("RFC4180 format should have ignoreSurroundingSpaces false by default", 
                                                                                                                                         CSVFormat.RFC4180.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_ExcelFormat() {
                                                                                                                             // Test the EXCEL format's setting
                                                                                                                             assertFalse("EXCEL format should have ignoreSurroundingSpaces false by default", 
                                                                                                                                         CSVFormat.EXCEL.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_TDFFormat() {
                                                                                                                             // Test the TDF format's setting
                                                                                                                             assertFalse("TDF format should have ignoreSurroundingSpaces false by default", 
                                                                                                                                         CSVFormat.TDF.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_MySQLFormat() {
                                                                                                                             // Test the MYSQL format's setting
                                                                                                                             assertFalse("MYSQL format should have ignoreSurroundingSpaces false by default", 
                                                                                                                                         CSVFormat.MYSQL.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetIgnoreSurroundingSpaces_AfterModification() {
                                                                                                                             // Test that changes to ignoreSurroundingSpaces are reflected
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                             
                                                                                                                             CSVFormat modifiedFormat = format.withIgnoreSurroundingSpaces(true);
                                                                                                                             assertTrue(modifiedFormat.getIgnoreSurroundingSpaces());
                                                                                                                             
                                                                                                                             // Original format should remain unchanged
                                                                                                                             assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNullString_UsingDefaultFormat() {
                                                                                                                             // Test with DEFAULT format which should have null nullString
                                                                                                                             assertNull(CSVFormat.DEFAULT.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNullString_UsingExcelFormat() {
                                                                                                                             // Test with EXCEL format which should have null nullString
                                                                                                                             assertNull(CSVFormat.EXCEL.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNullString_UsingRFC4180Format() {
                                                                                                                             // Test with RFC4180 format which should have null nullString
                                                                                                                             assertNull(CSVFormat.RFC4180.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNullString_UsingTDFFormat() {
                                                                                                                             // Test with TDF format which should have null nullString
                                                                                                                             assertNull(CSVFormat.TDF.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNullString_UsingMySQLFormat() {
                                                                                                                             // Test with MYSQL format which should have null nullString
                                                                                                                             assertNull(CSVFormat.MYSQL.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WhenQuoteCharacterIsSet() {
                                                                                                                             // Arrange
                                                                                                                             Character expectedQuote = '"';
                                                                                                                             CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                 .withQuote(expectedQuote);
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualQuote = format.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals("Quote character should match the set value", 
                                                                                                                                 expectedQuote, actualQuote);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WhenQuoteCharacterIsNull() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                 .withQuote((Character) null);
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character actualQuote = format.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull("Quote character should be null", actualQuote);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WithDifferentQuoteCharacters() {
                                                                                                                             // Arrange
                                                                                                                             Character singleQuote = '\'';
                                                                                                                             Character backtick = '`';
                                                                                                                             Character pipe = '|';
                                                                                                                             
                                                                                                                             CSVFormat format1 = CSVFormat.newFormat(',').withQuote(singleQuote);
                                                                                                                             CSVFormat format2 = CSVFormat.newFormat(',').withQuote(backtick);
                                                                                                                             CSVFormat format3 = CSVFormat.newFormat(',').withQuote(pipe);
                                                                                                                             
                                                                                                                             // Act & Assert
                                                                                                                             assertEquals("Should return single quote", 
                                                                                                                                 singleQuote, format1.getQuoteCharacter());
                                                                                                                             assertEquals("Should return backtick", 
                                                                                                                                 backtick, format2.getQuoteCharacter());
                                                                                                                             assertEquals("Should return pipe", 
                                                                                                                                 pipe, format3.getQuoteCharacter());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WithDefaultFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character quoteChar = defaultFormat.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals("Default format should use double quote", 
                                                                                                                                 Character.valueOf('"'), quoteChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WithRFC4180Format() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat rfcFormat = CSVFormat.RFC4180;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character quoteChar = rfcFormat.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals("RFC4180 format should use double quote", 
                                                                                                                                 Character.valueOf('"'), quoteChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WithExcelFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character quoteChar = excelFormat.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals("Excel format should use double quote", 
                                                                                                                                 Character.valueOf('"'), quoteChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WithTDFFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat tdfFormat = CSVFormat.TDF;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character quoteChar = tdfFormat.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals("TDF format should use double quote", 
                                                                                                                                 Character.valueOf('"'), quoteChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_WithMySQLFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat mysqlFormat = CSVFormat.MYSQL;
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             Character quoteChar = mysqlFormat.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertNull("MySQL format should have no quote character", quoteChar);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteCharacter_AfterModifyingFormat() {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                 .withQuote('"');
                                                                                                                             
                                                                                                                             // Act - first check
                                                                                                                             Character initialQuote = format.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Modify
                                                                                                                             format = format.withQuote('\'');
                                                                                                                             Character modifiedQuote = format.getQuoteCharacter();
                                                                                                                             
                                                                                                                             // Assert
                                                                                                                             assertEquals("Initial quote should be double quote", 
                                                                                                                                 Character.valueOf('"'), initialQuote);
                                                                                                                             assertEquals("Modified quote should be single quote", 
                                                                                                                                 Character.valueOf('\''), modifiedQuote);
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteMode_WhenUsingDefaultFormat() {
                                                                                                                             // Test with DEFAULT format which should have a non-null quote mode
                                                                                                                             assertNotNull(CSVFormat.DEFAULT.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteMode_WhenUsingRFC4180Format() {
                                                                                                                             // Test with RFC4180 format which should have a specific quote mode
                                                                                                                             assertNotNull(CSVFormat.RFC4180.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteMode_WhenUsingExcelFormat() {
                                                                                                                             // Test with EXCEL format which should have a specific quote mode
                                                                                                                             assertNotNull(CSVFormat.EXCEL.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteMode_WhenUsingTDFFormat() {
                                                                                                                             // Test with TDF format which should have a specific quote mode
                                                                                                                             assertNotNull(CSVFormat.TDF.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteMode_WhenUsingMySQLFormat() {
                                                                                                                             // Test with MYSQL format which should have a specific quote mode
                                                                                                                             assertNotNull(CSVFormat.MYSQL.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetQuoteMode_AfterWithQuoteModeModification() {
                                                                                                                             // Create a format and then modify its quote mode
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             CSVFormat modified = original.withQuoteMode(QuoteMode.ALL);
                                                                                                                             
                                                                                                                             assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                                                             // Original should remain unchanged
                                                                                                                             assertNotEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_DefaultFormat() {
                                                                                                                             // Test with DEFAULT format (which should have system line separator)
                                                                                                                             String expected = System.lineSeparator();
                                                                                                                             assertEquals(expected, CSVFormat.DEFAULT.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_RFC4180Format() {
                                                                                                                             // RFC4180 specifies CRLF as record separator
                                                                                                                             assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_ExcelFormat() {
                                                                                                                             // EXCEL format should use CRLF
                                                                                                                             assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_TabDelimitedFormat() {
                                                                                                                             // TDF format should use LF
                                                                                                                             assertEquals("\n", CSVFormat.TDF.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_MySQLFormat() {
                                                                                                                             // MySQL format should use LF
                                                                                                                             assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_AfterWithRecordSeparatorModification() {
                                                                                                                             // Test that withRecordSeparator properly updates the separator
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             CSVFormat modified = original.withRecordSeparator("|||");
                                                                                                                             assertEquals("|||", modified.getRecordSeparator());
                                                                                                                             // Original should remain unchanged
                                                                                                                             assertEquals(System.lineSeparator(), original.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetRecordSeparator_AfterWithRecordSeparatorCharModification() {
                                                                                                                             // Test that withRecordSeparator(char) properly updates the separator
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             CSVFormat modified = original.withRecordSeparator('|');
                                                                                                                             assertEquals("|", modified.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetSkipHeaderRecord_DefaultFormat() {
                                                                                                                             // Test with the DEFAULT format instance
                                                                                                                             assertFalse("DEFAULT format should have skipHeaderRecord false", 
                                                                                                                                        CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetSkipHeaderRecord_RFC4180Format() {
                                                                                                                             // Test with the RFC4180 format instance
                                                                                                                             assertFalse("RFC4180 format should have skipHeaderRecord false", 
                                                                                                                                        CSVFormat.RFC4180.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetSkipHeaderRecord_ExcelFormat() {
                                                                                                                             // Test with the EXCEL format instance
                                                                                                                             assertFalse("EXCEL format should have skipHeaderRecord false", 
                                                                                                                                        CSVFormat.EXCEL.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetSkipHeaderRecord_TabDelimitedFormat() {
                                                                                                                             // Test with the TDF format instance
                                                                                                                             assertFalse("TDF format should have skipHeaderRecord false", 
                                                                                                                                        CSVFormat.TDF.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetSkipHeaderRecord_MySQLFormat() {
                                                                                                                             // Test with the MYSQL format instance
                                                                                                                             assertFalse("MYSQL format should have skipHeaderRecord false", 
                                                                                                                                        CSVFormat.MYSQL.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testGetSkipHeaderRecord_AfterWithSkipHeaderRecord() {
                                                                                                                             // Test that withSkipHeaderRecord modifies the value correctly
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             assertFalse("Original format should remain unchanged", original.getSkipHeaderRecord());
                                                                                                                             assertTrue("Modified format should have skipHeaderRecord true", modified.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsCommentMarkerSet_UsingDefaultFormat() {
                                                                                                                             // Test with DEFAULT format (which typically doesn't have a comment marker)
                                                                                                                             assertFalse("DEFAULT format should not have comment marker set", 
                                                                                                                                        CSVFormat.DEFAULT.isCommentMarkerSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsCommentMarkerSet_AfterWithCommentMarker() {
                                                                                                                             // Create format without comment marker
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                 .withCommentMarker('#');
                                                                                                                             
                                                                                                                             assertTrue("Should return true after setting comment marker", 
                                                                                                                                       format.isCommentMarkerSet());
                                                                                                                             
                                                                                                                             // Then remove the comment marker
                                                                                                                             CSVFormat formatWithoutComment = format
                                                                                                                                 .withCommentMarker(null);
                                                                                                                             
                                                                                                                             assertFalse("Should return false after removing comment marker", 
                                                                                                                                        formatWithoutComment.isCommentMarkerSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsCommentMarkerSet_WithDifferentCommentMarkers() {
                                                                                                                             // Test with different comment marker characters
                                                                                                                             char[] markers = {'#', '!', '%', '@'};
                                                                                                                             
                                                                                                                             for (char marker : markers) {
                                                                                                                                 CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                     .withCommentMarker(marker);
                                                                                                                                 
                                                                                                                                 assertTrue("Should return true for comment marker: " + marker, 
                                                                                                                                           format.isCommentMarkerSet());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_WithDefaultFormat() {
                                                                                                                             assertFalse("DEFAULT format should have null escape character", 
                                                                                                                                        CSVFormat.DEFAULT.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_WithRFC4180Format() {
                                                                                                                             assertFalse("RFC4180 format should have null escape character", 
                                                                                                                                        CSVFormat.RFC4180.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_WithExcelFormat() {
                                                                                                                             assertFalse("EXCEL format should have null escape character", 
                                                                                                                                        CSVFormat.EXCEL.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_WithTDFFormat() {
                                                                                                                             assertFalse("TDF format should have null escape character", 
                                                                                                                                        CSVFormat.TDF.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_WithMySQLFormat() {
                                                                                                                             assertTrue("MYSQL format should have non-null escape character", 
                                                                                                                                       CSVFormat.MYSQL.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_AfterWithEscape() {
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                             assertTrue("Should return true after setting escape character", 
                                                                                                                                       format.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsEscapeCharacterSet_AfterWithEscapeNull() {
                                                                                                                             CSVFormat format = CSVFormat.MYSQL.withEscape(null);
                                                                                                                             assertFalse("Should return false after setting escape character to null", 
                                                                                                                                        format.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsNullStringSet_UsingDefaultFormat() {
                                                                                                                             // Test with DEFAULT format which should have nullString set to null
                                                                                                                             assertFalse("DEFAULT format should have nullString not set", CSVFormat.DEFAULT.isNullStringSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsQuoteCharacterSet_WithDefaultFormat() {
                                                                                                                             // Test with DEFAULT format (which typically has quote character set)
                                                                                                                             assertTrue("DEFAULT format should have quote character set", 
                                                                                                                                 CSVFormat.DEFAULT.isQuoteCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsQuoteCharacterSet_WithExcelFormat() {
                                                                                                                             // Test with EXCEL format (which typically has quote character set)
                                                                                                                             assertTrue("EXCEL format should have quote character set", 
                                                                                                                                 CSVFormat.EXCEL.isQuoteCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsQuoteCharacterSet_WithTDFFormat() {
                                                                                                                             // Test with TDF format (which typically doesn't have quote character)
                                                                                                                             assertFalse("TDF format should not have quote character set", 
                                                                                                                                 CSVFormat.TDF.isQuoteCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsQuoteCharacterSet_WithMySQLFormat() {
                                                                                                                             // Test with MYSQL format (which typically doesn't have quote character)
                                                                                                                             assertFalse("MYSQL format should not have quote character set", 
                                                                                                                                 CSVFormat.MYSQL.isQuoteCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testIsQuoteCharacterSet_WithRFC4180Format() {
                                                                                                                             // Test with RFC4180 format (which typically has quote character set)
                                                                                                                             assertTrue("RFC4180 format should have quote character set", 
                                                                                                                                 CSVFormat.RFC4180.isQuoteCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testParse_WithNullReader() throws IOException {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(NullPointerException.class);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             format.parse(null);
                                                                                                                         }

 @Test
                                                                                                                         public void testParse_WithMockedReader() throws IOException {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             Reader mockedReader = mock(Reader.class);
                                                                                                                             when(mockedReader.read(any(char[].class), anyInt(), anyInt()))
                                                                                                                                 .thenReturn(-1); // Simulate EOF
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVParser parser = format.parse(mockedReader);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(parser);
                                                                                                                             assertFalse(parser.iterator().hasNext());
                                                                                                                             
                                                                                                                             // Cleanup
                                                                                                                             parser.close();
                                                                                                                         }

 @Test
                                                                                                                         public void testPrint_WithNullAppendable() throws IOException {
                                                                                                                             // Arrange
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("Parameter 'out' must not be null");
                                                                                                                             
                                                                                                                             // Act
                                                                                                                             format.print(null);
                                                                                                                             
                                                                                                                             // Assert - exception expected
                                                                                                                         }

 @Test
                                                                                                                         public void testToString_DefaultFormat() {
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             String expected = "Delimiter=<,> QuoteChar=<\"> Escape=<\\> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:false";
                                                                                                                             assertEquals(expected, format.toString());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_NonNullValue() {
                                                                                                                             // Setup original format with no comment marker
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                             
                                                                                                                             // Test setting a comment marker
                                                                                                                             Character commentMarker = '#';
                                                                                                                             CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                                                             
                                                                                                                             // Verify the new format has the comment marker set
                                                                                                                             assertTrue(newFormat.isCommentMarkerSet());
                                                                                                                             assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                             
                                                                                                                             // Verify other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(original.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), newFormat.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_NullValue() {
                                                                                                                             // Setup original format with a comment marker
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                             
                                                                                                                             // Test setting null comment marker
                                                                                                                             CSVFormat newFormat = original.withCommentMarker(null);
                                                                                                                             
                                                                                                                             // Verify the new format has no comment marker set
                                                                                                                             assertFalse(newFormat.isCommentMarkerSet());
                                                                                                                             assertNull(newFormat.getCommentMarker());
                                                                                                                             
                                                                                                                             // Verify other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(original.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), newFormat.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_LineBreakCharacter() {
                                                                                                                             // Setup original format
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Expect exception when trying to set a line break as comment marker
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The comment marker cannot be a line break");
                                                                                                                             
                                                                                                                             // Try to set line break as comment marker
                                                                                                                             original.withCommentMarker('\n');
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_SameValueReturnsSameInstance() {
                                                                                                                             // Setup original format with comment marker
                                                                                                                             Character commentMarker = '#';
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withCommentMarker(commentMarker);
                                                                                                                             
                                                                                                                             // Call with same comment marker
                                                                                                                             CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                                                             
                                                                                                                             // Should return same instance for optimization
                                                                                                                             assertSame(original, newFormat);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_DifferentValueReturnsNewInstance() {
                                                                                                                             // Setup original format with comment marker
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                             
                                                                                                                             // Call with different comment marker
                                                                                                                             CSVFormat newFormat = original.withCommentMarker('!');
                                                                                                                             
                                                                                                                             // Should return new instance
                                                                                                                             assertNotSame(original, newFormat);
                                                                                                                             assertEquals(Character.valueOf('!'), newFormat.getCommentMarker());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_ValidCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character validCommentMarker = '#';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withCommentMarker(validCommentMarker);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertEquals(validCommentMarker, newFormat.getCommentMarker());
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_NullMarker() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withCommentMarker((Character) null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertNull(newFormat.getCommentMarker());
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_LineBreakCharacter1() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character lineBreak = '\n';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             originalFormat.withCommentMarker(lineBreak);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_OtherSpecialCharacters() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character[] specialChars = {'@', '$', '%', '^', '&', '*', ';'};
                                                                                                                             
                                                                                                                             for (Character c : specialChars) {
                                                                                                                                 // Execute
                                                                                                                                 CSVFormat newFormat = originalFormat.withCommentMarker(c);
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 assertNotNull(newFormat);
                                                                                                                                 assertEquals(c, newFormat.getCommentMarker());
                                                                                                                                 assertNotSame(originalFormat, newFormat);
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_OriginalFormatUnchanged() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character originalCommentMarker = originalFormat.getCommentMarker();
                                                                                                                             Character newCommentMarker = '#';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withCommentMarker(newCommentMarker);
                                                                                                                             
                                                                                                                             // Verify original format unchanged
                                                                                                                             assertEquals(originalCommentMarker, originalFormat.getCommentMarker());
                                                                                                                             
                                                                                                                             // Verify new format has new marker
                                                                                                                             assertEquals(newCommentMarker, newFormat.getCommentMarker());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithCommentMarker_AllOtherPropertiesPreserved() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.newFormat('|')
                                                                                                                                 .withQuote('"')
                                                                                                                                 .withQuoteMode(QuoteMode.ALL)
                                                                                                                                 .withEscape('\\')
                                                                                                                                 .withIgnoreSurroundingSpaces(true)
                                                                                                                                 .withIgnoreEmptyLines(false)
                                                                                                                                 .withRecordSeparator("\r\n")
                                                                                                                                 .withNullString("NULL")
                                                                                                                                 .withHeader("Col1", "Col2")
                                                                                                                                 .withSkipHeaderRecord(true)
                                                                                                                                 .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                             Character newCommentMarker = '#';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withCommentMarker(newCommentMarker);
                                                                                                                             
                                                                                                                             // Verify all properties except comment marker are preserved
                                                                                                                             assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                             assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                             assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Only comment marker should be different
                                                                                                                             assertEquals(newCommentMarker, newFormat.getCommentMarker());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithDelimiter_ValidDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char newDelimiter = '|';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withDelimiter(newDelimiter);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(newDelimiter, newFormat.getDelimiter());
                                                                                                                             assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                             assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                             assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                             assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithDelimiter_LineBreakDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char lineBreakDelimiter = '\n';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             originalFormat.withDelimiter(lineBreakDelimiter);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithDelimiter_CarriageReturnDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char carriageReturnDelimiter = '\r';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             originalFormat.withDelimiter(carriageReturnDelimiter);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithDelimiter_SameDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char sameDelimiter = originalFormat.getDelimiter();
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withDelimiter(sameDelimiter);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(originalFormat, newFormat); // Should return new instance
                                                                                                                             assertEquals(sameDelimiter, newFormat.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithDelimiter_SpecialCharacterDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char[] specialChars = {'\t', '\f', '\b', '\0', '\\', '"', '\''};
                                                                                                                             
                                                                                                                             for (char specialChar : specialChars) {
                                                                                                                                 if (specialChar == '\n' || specialChar == '\r') continue; // Skip line breaks
                                                                                                                                 
                                                                                                                                 // Execute
                                                                                                                                 CSVFormat newFormat = originalFormat.withDelimiter(specialChar);
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 assertEquals(specialChar, newFormat.getDelimiter());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testWithDelimiter_UnicodeCharacterDelimiter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char unicodeChar = 'Ω'; // Greek capital letter Omega
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withDelimiter(unicodeChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(unicodeChar, newFormat.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_NonNullCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character escapeChar = '\\';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                             assertEquals(escapeChar, newFormat.getEscapeCharacter());
                                                                                                                             assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                             
                                                                                                                             // Verify other properties remain unchanged
                                                                                                                             assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                             assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                             assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_NullCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape((Character) null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                             assertNull(newFormat.getEscapeCharacter());
                                                                                                                             assertFalse(newFormat.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_LineBreakCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character lineBreak = '\n';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The escape cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             originalFormat.withEscape(lineBreak);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_SameEscapeCharacter() {
                                                                                                                             // Setup
                                                                                                                             Character escapeChar = '\\';
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(escapeChar);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertSame(originalFormat, newFormat); // Should return same instance when escape is the same
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_DifferentEscapeCharacter() {
                                                                                                                             // Setup
                                                                                                                             Character originalEscape = '\\';
                                                                                                                             Character newEscape = '/';
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(originalEscape);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(newEscape);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                             assertEquals(newEscape, newFormat.getEscapeCharacter());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_FromNullToNonNull() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape((Character) null);
                                                                                                                             Character newEscape = '\\';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(newEscape);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                             assertEquals(newEscape, newFormat.getEscapeCharacter());
                                                                                                                             assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_FromNonNullToNull() {
                                                                                                                             // Setup
                                                                                                                             Character originalEscape = '\\';
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(originalEscape);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape((Character) null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                             assertNull(newFormat.getEscapeCharacter());
                                                                                                                             assertFalse(newFormat.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_ValidCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character escapeChar = '\\';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(escapeChar, newFormat.getEscapeCharacter());
                                                                                                                             assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                             // Verify other properties remain unchanged
                                                                                                                             assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_NullCharacter1() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape((Character) null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNull(newFormat.getEscapeCharacter());
                                                                                                                             assertFalse(newFormat.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_LineBreakCharacter1() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character lineBreak = '\n';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The escape character cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             originalFormat.withEscape(lineBreak);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_PrimitiveChar() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char escapeChar = '\\';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(Character.valueOf(escapeChar), newFormat.getEscapeCharacter());
                                                                                                                             assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_PrimitiveLineBreakChar() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             char lineBreak = '\n';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The escape character cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             originalFormat.withEscape(lineBreak);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_VerifyImmutability() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             Character escapeChar = '\\';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                                             
                                                                                                                             // Verify original format remains unchanged
                                                                                                                             assertNull(originalFormat.getEscapeCharacter());
                                                                                                                             assertFalse(originalFormat.isEscapeCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_SameCharacterReturnsSameInstance() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape('\\');
                                                                                                                             
                                                                                                                             // Verify same instance is returned when escape character is the same
                                                                                                                             assertSame(originalFormat, newFormat);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithEscape_DifferentCharacterReturnsNewInstance() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withEscape('/');
                                                                                                                             
                                                                                                                             // Verify new instance is returned when escape character changes
                                                                                                                             assertNotSame(originalFormat, newFormat);
                                                                                                                             assertEquals(Character.valueOf('/'), newFormat.getEscapeCharacter());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_ValidSingleHeader() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             String header = "Name";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(header);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertArrayEquals(new String[]{"Name"}, newFormat.getHeader());
                                                                                                                             assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_ValidMultipleHeaders() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             String[] headers = {"Name", "Age", "Email"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertArrayEquals(headers, newFormat.getHeader());
                                                                                                                             assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_NullHeader() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader((String[]) null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNull(newFormat.getHeader());
                                                                                                                             assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_EmptyHeaderArray() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             String[] emptyHeaders = {};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(emptyHeaders);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertArrayEquals(emptyHeaders, newFormat.getHeader());
                                                                                                                             assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_DuplicateHeaders() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             String[] duplicateHeaders = {"Name", "Name"};
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The header contains a duplicate entry: 'Name'");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             baseFormat.withHeader(duplicateHeaders);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_VerifyImmutability() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             String[] originalHeaders = {"Name", "Age"};
                                                                                                                             String[] headersToModify = originalHeaders.clone();
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(headersToModify);
                                                                                                                             headersToModify[0] = "Modified"; // Modify after creating format
                                                                                                                             
                                                                                                                             // Verify original headers in format didn't change
                                                                                                                             assertArrayEquals(new String[]{"Name", "Age"}, newFormat.getHeader());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_CombinedWithOtherSettings() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                                                 .withDelimiter(';')
                                                                                                                                 .withQuote('"')
                                                                                                                                 .withIgnoreEmptyLines(true);
                                                                                                                             String[] headers = {"ID", "Value"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                                             
                                                                                                                             // Verify headers and other settings
                                                                                                                             assertArrayEquals(headers, newFormat.getHeader());
                                                                                                                             assertEquals(';', newFormat.getDelimiter());
                                                                                                                             assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                             assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_AfterWithSkipHeaderRecord() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                             String[] headers = {"Field1", "Field2"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertArrayEquals(headers, newFormat.getHeader());
                                                                                                                             assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithHeader_WithNullStringInArray() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                             String[] headers = {"Valid", null, "Another"};
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertArrayEquals(headers, newFormat.getHeader());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithAllowMissingColumnNames_True() {
                                                                                                                             // Setup original format with default values
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Call method under test
                                                                                                                             CSVFormat modified = original.withAllowMissingColumnNames(true);
                                                                                                                             
                                                                                                                             // Verify new value is set
                                                                                                                             assertTrue(modified.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Verify all other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithAllowMissingColumnNames_False() {
                                                                                                                             // Setup original format with allowMissingColumnNames=true
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                                                             
                                                                                                                             // Call method under test
                                                                                                                             CSVFormat modified = original.withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                             // Verify new value is set
                                                                                                                             assertFalse(modified.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Verify all other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithAllowMissingColumnNames_SameValueReturnsSameInstance() {
                                                                                                                             // Setup original format
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Call method with same value
                                                                                                                             CSVFormat modified = original.withAllowMissingColumnNames(original.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Should return same instance
                                                                                                                             assertSame(original, modified);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithAllowMissingColumnNames_HeaderValidation() {
                                                                                                                             // Setup format with duplicate headers (should throw exception)
                                                                                                                             String[] duplicateHeaders = {"name", "age", "name"};
                                                                                                                             
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The header contains a duplicate entry: 'name'");
                                                                                                                             
                                                                                                                             CSVFormat.DEFAULT
                                                                                                                                 .withHeader(duplicateHeaders)
                                                                                                                                 .withAllowMissingColumnNames(true);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreEmptyLines_True() {
                                                                                                                             // Setup original format with default values
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Call method under test
                                                                                                                             CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                             
                                                                                                                             // Verify new format has the correct setting
                                                                                                                             assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                             
                                                                                                                             // Verify all other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreEmptyLines_False() {
                                                                                                                             // Setup original format with ignoreEmptyLines=true
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                             
                                                                                                                             // Call method under test
                                                                                                                             CSVFormat modified = original.withIgnoreEmptyLines(false);
                                                                                                                             
                                                                                                                             // Verify new format has the correct setting
                                                                                                                             assertFalse(modified.getIgnoreEmptyLines());
                                                                                                                             
                                                                                                                             // Verify all other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreEmptyLines_FromTrueToTrue() {
                                                                                                                             // Setup original format with ignoreEmptyLines=true
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                             
                                                                                                                             // Call method under test
                                                                                                                             CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                             
                                                                                                                             // Verify new format has the correct setting
                                                                                                                             assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                             
                                                                                                                             // Verify it's a new instance (immutable pattern)
                                                                                                                             assertNotSame(original, modified);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreEmptyLines_FromFalseToFalse() {
                                                                                                                             // Setup original format with ignoreEmptyLines=false
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                             
                                                                                                                             // Call method under test
                                                                                                                             CSVFormat modified = original.withIgnoreEmptyLines(false);
                                                                                                                             
                                                                                                                             // Verify new format has the correct setting
                                                                                                                             assertFalse(modified.getIgnoreEmptyLines());
                                                                                                                             
                                                                                                                             // Verify it's a new instance (immutable pattern)
                                                                                                                             assertNotSame(original, modified);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreEmptyLines_WithNullOriginal() {
                                                                                                                             thrown.expect(NullPointerException.class);
                                                                                                                             thrown.expectMessage("The original format must not be null.");
                                                                                                                             
                                                                                                                             CSVFormat original = null;
                                                                                                                             original.withIgnoreEmptyLines(true);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreSurroundingSpaces_True() {
                                                                                                                             // Setup initial format with default values
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                                                 .withDelimiter(',')
                                                                                                                                 .withQuote('"')
                                                                                                                                 .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                 .withCommentMarker('#')
                                                                                                                                 .withEscape('\\')
                                                                                                                                 .withIgnoreSurroundingSpaces(false)
                                                                                                                                 .withIgnoreEmptyLines(true)
                                                                                                                                 .withRecordSeparator("\r\n")
                                                                                                                                 .withNullString("NULL")
                                                                                                                                 .withHeader("Col1", "Col2")
                                                                                                                                 .withSkipHeaderRecord(false)
                                                                                                                                 .withAllowMissingColumnNames(true);
                                                                                                                     
                                                                                                                             // Test setting ignoreSurroundingSpaces to true
                                                                                                                             CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                                             
                                                                                                                             // Verify new format has the new setting
                                                                                                                             assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             
                                                                                                                             // Verify all other properties remain unchanged
                                                                                                                             assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                             assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                             assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                             assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreSurroundingSpaces_False() {
                                                                                                                             // Setup initial format with ignoreSurroundingSpaces true
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                                                 .withIgnoreSurroundingSpaces(true);
                                                                                                                     
                                                                                                                             // Test setting ignoreSurroundingSpaces to false
                                                                                                                             CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(false);
                                                                                                                             
                                                                                                                             // Verify new format has the new setting
                                                                                                                             assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreSurroundingSpaces_SameValue() {
                                                                                                                             // Setup initial format
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                                                 .withIgnoreSurroundingSpaces(true);
                                                                                                                     
                                                                                                                             // Test setting same value
                                                                                                                             CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                                             
                                                                                                                             // Verify it's the same instance (optimization)
                                                                                                                             assertSame(originalFormat, newFormat);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreSurroundingSpaces_FromDefault() {
                                                                                                                             // Test setting ignoreSurroundingSpaces from DEFAULT format
                                                                                                                             CSVFormat newFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                             
                                                                                                                             // Verify new format has the setting
                                                                                                                             assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             
                                                                                                                             // Verify DEFAULT format remains unchanged
                                                                                                                             assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreSurroundingSpaces_FromRFC() {
                                                                                                                             // Test setting ignoreSurroundingSpaces from RFC4180 format
                                                                                                                             CSVFormat newFormat = CSVFormat.RFC4180.withIgnoreSurroundingSpaces(false);
                                                                                                                             
                                                                                                                             // Verify new format has the setting
                                                                                                                             assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             
                                                                                                                             // Verify RFC4180 format remains unchanged
                                                                                                                             assertFalse(CSVFormat.RFC4180.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithIgnoreSurroundingSpaces_FromExcel() {
                                                                                                                             // Test setting ignoreSurroundingSpaces from EXCEL format
                                                                                                                             CSVFormat newFormat = CSVFormat.EXCEL.withIgnoreSurroundingSpaces(true);
                                                                                                                             
                                                                                                                             // Verify new format has the setting
                                                                                                                             assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             
                                                                                                                             // Verify EXCEL format remains unchanged
                                                                                                                             assertFalse(CSVFormat.EXCEL.getIgnoreSurroundingSpaces());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_ValidString() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             String newNullString = "NULL";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(newNullString);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertEquals(newNullString, newFormat.getNullString());
                                                                                                                             assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                             assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                             assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                             assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                             assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                             assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                             assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                             assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                             assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                             assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_NullInput() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertNull(newFormat.getNullString());
                                                                                                                             assertFalse(newFormat.isNullStringSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_EmptyString() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             String emptyString = "";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(emptyString);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertEquals(emptyString, newFormat.getNullString());
                                                                                                                             assertTrue(newFormat.isNullStringSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_WhitespaceString() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                             String whitespaceString = "   ";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(whitespaceString);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(newFormat);
                                                                                                                             assertEquals(whitespaceString, newFormat.getNullString());
                                                                                                                             assertTrue(newFormat.isNullStringSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_SameAsOriginal() {
                                                                                                                             // Setup
                                                                                                                             String nullString = "NA";
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withNullString(nullString);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(nullString);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(originalFormat, newFormat); // Should return new instance
                                                                                                                             assertEquals(nullString, newFormat.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_ChangingExistingNullString() {
                                                                                                                             // Setup
                                                                                                                             String originalNullString = "NULL";
                                                                                                                             String newNullString = "N/A";
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withNullString(originalNullString);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(newNullString);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(newNullString, newFormat.getNullString());
                                                                                                                             assertNotEquals(originalNullString, newFormat.getNullString());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_FromNullToNonNull() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                             String newNullString = "NULL";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(newNullString);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertEquals(newNullString, newFormat.getNullString());
                                                                                                                             assertTrue(newFormat.isNullStringSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithNullString_FromNonNullToNull() {
                                                                                                                             // Setup
                                                                                                                             String originalNullString = "NULL";
                                                                                                                             CSVFormat originalFormat = CSVFormat.DEFAULT.withNullString(originalNullString);
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = originalFormat.withNullString(null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNull(newFormat.getNullString());
                                                                                                                             assertFalse(newFormat.isNullStringSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuote_ValidCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             char quoteChar = '\'';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat result = original.withQuote(quoteChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(result);
                                                                                                                             assertEquals(Character.valueOf(quoteChar), result.getQuoteCharacter());
                                                                                                                             assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), result.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), result.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), result.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), result.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), result.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), result.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), result.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), result.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), result.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuote_NullCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             char nullChar = '\0';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat result = original.withQuote(nullChar);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotNull(result);
                                                                                                                             assertNull(result.getQuoteCharacter());
                                                                                                                             assertFalse(result.isQuoteCharacterSet());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuote_LineBreakCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             char lineBreak = '\n';
                                                                                                                             
                                                                                                                             // Expect exception
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             original.withQuote(lineBreak);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuote_SameAsCurrentQuote() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                             char sameQuote = '"';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat result = original.withQuote(sameQuote);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertSame(original, result);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuote_ChangesOnlyQuoteCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                 .withDelimiter(';')
                                                                                                                                 .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                                                 .withCommentMarker('#')
                                                                                                                                 .withEscape('\\')
                                                                                                                                 .withIgnoreSurroundingSpaces(true)
                                                                                                                                 .withIgnoreEmptyLines(false)
                                                                                                                                 .withRecordSeparator("\r\n")
                                                                                                                                 .withNullString("NULL")
                                                                                                                                 .withHeader("col1", "col2")
                                                                                                                                 .withSkipHeaderRecord(true)
                                                                                                                                 .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                             char newQuote = '\'';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat result = original.withQuote(newQuote);
                                                                                                                             
                                                                                                                             // Verify only quote character changed
                                                                                                                             assertEquals(Character.valueOf(newQuote), result.getQuoteCharacter());
                                                                                                                             assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), result.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), result.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), result.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), result.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), result.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), result.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), result.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), result.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), result.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuoteMode_NonNullQuoteMode() {
                                                                                                                             // Setup original CSVFormat with default values
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                 .withDelimiter(',')
                                                                                                                                 .withQuote('"')
                                                                                                                                 .withCommentMarker('#')
                                                                                                                                 .withEscape('\\')
                                                                                                                                 .withIgnoreSurroundingSpaces(true)
                                                                                                                                 .withIgnoreEmptyLines(false)
                                                                                                                                 .withRecordSeparator("\r\n")
                                                                                                                                 .withNullString("NULL")
                                                                                                                                 .withHeader("Name", "Age")
                                                                                                                                 .withSkipHeaderRecord(true)
                                                                                                                                 .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                             // Test with different quote modes
                                                                                                                             QuoteMode[] modes = QuoteMode.values();
                                                                                                                             for (QuoteMode mode : modes) {
                                                                                                                                 CSVFormat modified = original.withQuoteMode(mode);
                                                                                                                                 
                                                                                                                                 // Verify quote mode changed
                                                                                                                                 assertEquals(mode, modified.getQuoteMode());
                                                                                                                                 
                                                                                                                                 // Verify all other properties remain the same
                                                                                                                                 assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                 assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                 assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                 assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                 assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                 assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                 assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                 assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                 assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                 assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                 assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuoteMode_NullQuoteMode() {
                                                                                                                             // Setup original CSVFormat
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                             thrown.expectMessage("The quote mode policy must not be null!");
                                                                                                                             
                                                                                                                             original.withQuoteMode(null);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuoteMode_VerifyImmutability() {
                                                                                                                             // Verify that original format isn't modified
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                             CSVFormat modified = original.withQuoteMode(QuoteMode.ALL);
                                                                                                                             
                                                                                                                             assertNotSame(original, modified);
                                                                                                                             assertEquals(QuoteMode.MINIMAL, original.getQuoteMode());
                                                                                                                             assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithQuoteMode_EdgeCaseEmptyHeader() {
                                                                                                                             // Test with empty header array
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withHeader(new String[0]);
                                                                                                                             CSVFormat modified = original.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                                                             
                                                                                                                             assertEquals(QuoteMode.NON_NUMERIC, modified.getQuoteMode());
                                                                                                                             assertArrayEquals(new String[0], modified.getHeader());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_String_NormalSeparator() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             String separator = "\n";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(separator, newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_String_EmptyString() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             String separator = "";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(separator, newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_String_NullSeparator() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator((String) null);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertNull(newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_String_MultipleCharacters() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             String separator = "\r\n";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(separator, newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_String_SpecialCharacters() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             String separator = "|";
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(separator, newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_Char_NormalCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             char separator = '\n';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(String.valueOf(separator), newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_Char_SpecialCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             char separator = '|';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(String.valueOf(separator), newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_Char_NonPrintableCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             char separator = '\t';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(String.valueOf(separator), newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_Char_UnicodeCharacter() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             char separator = '¶';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(String.valueOf(separator), newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_Char_EqualsOriginal() {
                                                                                                                             // Setup
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                             char separator = '\n';
                                                                                                                             
                                                                                                                             // Execute
                                                                                                                             CSVFormat newFormat = format.withRecordSeparator(separator);
                                                                                                                             
                                                                                                                             // Verify
                                                                                                                             assertNotSame(format, newFormat);
                                                                                                                             assertEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_String() {
                                                                                                                             // Setup initial format with all possible parameters
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                 .withDelimiter(',')
                                                                                                                                 .withQuote('"')
                                                                                                                                 .withQuoteMode(QuoteMode.ALL)
                                                                                                                                 .withCommentMarker('#')
                                                                                                                                 .withEscape('\\')
                                                                                                                                 .withIgnoreSurroundingSpaces(true)
                                                                                                                                 .withIgnoreEmptyLines(false)
                                                                                                                                 .withNullString("NULL")
                                                                                                                                 .withHeader("Name", "Age")
                                                                                                                                 .withSkipHeaderRecord(true)
                                                                                                                                 .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                             // Test with standard record separator
                                                                                                                             String newSeparator = "\r\n";
                                                                                                                             CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                                             
                                                                                                                             // Verify all properties except record separator remain the same
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                             assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                             
                                                                                                                             // Verify record separator was updated
                                                                                                                             assertEquals(newSeparator, modified.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_Char() {
                                                                                                                             // Setup initial format
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withDelimiter(';');
                                                                                                                             
                                                                                                                             // Test with char record separator
                                                                                                                             char newSeparator = '\n';
                                                                                                                             CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                                             
                                                                                                                             // Verify record separator was updated to String representation
                                                                                                                             assertEquals(String.valueOf(newSeparator), modified.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_NullString() {
                                                                                                                             // Setup initial format
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                             
                                                                                                                             // Test with null record separator
                                                                                                                             CSVFormat modified = original.withRecordSeparator((String) null);
                                                                                                                             
                                                                                                                             // Verify record separator was set to null
                                                                                                                             assertNull(modified.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_EmptyString() {
                                                                                                                             // Setup initial format
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                             
                                                                                                                             // Test with empty string record separator
                                                                                                                             CSVFormat modified = original.withRecordSeparator("");
                                                                                                                             
                                                                                                                             // Verify record separator was set to empty string
                                                                                                                             assertEquals("", modified.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_LineBreakCharacters() {
                                                                                                                             // Test various line break combinations
                                                                                                                             String[] separators = {"\n", "\r", "\r\n", "\n\r", "\u2028", "\u2029"};
                                                                                                                             
                                                                                                                             for (String separator : separators) {
                                                                                                                                 CSVFormat modified = CSVFormat.DEFAULT.withRecordSeparator(separator);
                                                                                                                                 assertEquals(separator, modified.getRecordSeparator());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_NonBreakingCharacters() {
                                                                                                                             // Test with non-breaking characters
                                                                                                                             String[] separators = {"|", "~~~", "END", " ", "\t"};
                                                                                                                             
                                                                                                                             for (String separator : separators) {
                                                                                                                                 CSVFormat modified = CSVFormat.DEFAULT.withRecordSeparator(separator);
                                                                                                                                 assertEquals(separator, modified.getRecordSeparator());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_UnicodeCharacters() {
                                                                                                                             // Test with Unicode characters
                                                                                                                             String[] separators = {"\u00A7", "¶", "§", "•"};
                                                                                                                             
                                                                                                                             for (String separator : separators) {
                                                                                                                                 CSVFormat modified = CSVFormat.DEFAULT.withRecordSeparator(separator);
                                                                                                                                 assertEquals(separator, modified.getRecordSeparator());
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                         public void testWithRecordSeparator_ImmutableOriginal() {
                                                                                                                             // Verify original format remains unchanged
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                             String originalSeparator = original.getRecordSeparator();
                                                                                                                             
                                                                                                                             CSVFormat modified = original.withRecordSeparator("\r\n");
                                                                                                                             
                                                                                                                             assertEquals("\n", originalSeparator);
                                                                                                                             assertEquals("\n", original.getRecordSeparator());
                                                                                                                             assertEquals("\r\n", modified.getRecordSeparator());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_True() {
                                                                                                                             // Setup original format with skipHeaderRecord = false
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                                             
                                                                                                                             // Test changing to true
                                                                                                                             CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             assertTrue(modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                             assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                             assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                             assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                             assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                             assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                             assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                             assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                             assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_False() {
                                                                                                                             // Setup original format with skipHeaderRecord = true
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             // Test changing to false
                                                                                                                             CSVFormat modified = original.withSkipHeaderRecord(false);
                                                                                                                             
                                                                                                                             assertFalse(modified.getSkipHeaderRecord());
                                                                                                                             // Verify all other properties remain unchanged
                                                                                                                             assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                             assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                             // ... other property assertions similar to above test
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_SameValue() {
                                                                                                                             // Setup original format
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             // Test setting same value
                                                                                                                             CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             // Should return same instance for optimization
                                                                                                                             assertSame(original, modified);
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_WithHeaders() {
                                                                                                                             String[] headers = {"Name", "Age", "City"};
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withHeader(headers).withSkipHeaderRecord(false);
                                                                                                                             
                                                                                                                             CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             assertTrue(modified.getSkipHeaderRecord());
                                                                                                                             assertArrayEquals(headers, modified.getHeader());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_NoHeaders() {
                                                                                                                             CSVFormat original = CSVFormat.DEFAULT.withHeader((String[]) null).withSkipHeaderRecord(false);
                                                                                                                             
                                                                                                                             CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             assertTrue(modified.getSkipHeaderRecord());
                                                                                                                             assertNull(modified.getHeader());
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_FromDefault() {
                                                                                                                             // Test changing DEFAULT format's skipHeaderRecord
                                                                                                                             CSVFormat modified = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             assertTrue(modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(CSVFormat.DEFAULT.getDelimiter(), modified.getDelimiter());
                                                                                                                             // ... other default property assertions
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_FromRFC() {
                                                                                                                             // Test changing RFC4180 format's skipHeaderRecord
                                                                                                                             CSVFormat modified = CSVFormat.RFC4180.withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                             assertTrue(modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(CSVFormat.RFC4180.getDelimiter(), modified.getDelimiter());
                                                                                                                             // ... other RFC4180 property assertions
                                                                                                                         }

 @Test
                                                                                                                         public void testWithSkipHeaderRecord_FromExcel() {
                                                                                                                             // Test changing EXCEL format's skipHeaderRecord
                                                                                                                             CSVFormat modified = CSVFormat.EXCEL.withSkipHeaderRecord(false);
                                                                                                                             
                                                                                                                             assertFalse(modified.getSkipHeaderRecord());
                                                                                                                             assertEquals(CSVFormat.EXCEL.getDelimiter(), modified.getDelimiter());
                                                                                                                             // ... other EXCEL property assertions
                                                                                                                         }

 @Test
                                                                                                                 public void testIsLineBreak_WithLF() throws Exception {
                                                                                                                     // Test with Line Feed character (LF)
                                                                                                                     Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     method.setAccessible(true);
                                                                                                                     boolean result = (boolean) method.invoke(null, '\n');
                                                                                                                     assertTrue(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithCR() throws Exception {
                                                                                                                     // Test with Carriage Return character (CR)
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, '\r');
                                                                                                                     assertTrue(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithRegularCharacter() throws Exception {
                                                                                                                     // Test with regular character (not a line break)
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, 'a');
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithSpaceCharacter() throws Exception {
                                                                                                                     // Test with space character
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, ' ');
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithTabCharacter() throws Exception {
                                                                                                                     // Test with tab character
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, '\t');
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithNullCharacter() throws Exception {
                                                                                                                     // Test with null character
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, '\0');
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithUnicodeLineSeparator() throws Exception {
                                                                                                                     // Test with Unicode line separator (U+2028)
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, '\u2028');
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithUnicodeParagraphSeparator() throws Exception {
                                                                                                                     // Test with Unicode paragraph separator (U+2029)
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, '\u2029');
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithCharacterObjectLF() throws Exception {
                                                                                                                     // Test with Character object containing LF
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, Character.valueOf('\n'));
                                                                                                                     assertTrue(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithCharacterObjectCR() throws Exception {
                                                                                                                     // Test with Character object containing CR
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, Character.valueOf('\r'));
                                                                                                                     assertTrue(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithCharacterObjectRegularChar() throws Exception {
                                                                                                                     // Test with Character object containing regular character
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     boolean result = (boolean) isLineBreakMethod.invoke(null, Character.valueOf('x'));
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithNullCharacterObject() throws Exception {
                                                                                                                     // Test with null Character object
                                                                                                                     Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     method.setAccessible(true);
                                                                                                                     boolean result = (boolean) method.invoke(null, (Character) null);
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithNullCharacter1() throws Exception {
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                     Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     method.setAccessible(true);
                                                                                                                     boolean result = (boolean) method.invoke(format, (Character) null);
                                                                                                                     assertFalse(result);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithNonLineBreakCharacters() {
                                                                                                                     // Test that non-line-break characters can be used as delimiters
                                                                                                                     // (since the constructor throws exception if isLineBreak returns true)
                                                                                                                     try {
                                                                                                                         CSVFormat format1 = CSVFormat.newFormat('a');
                                                                                                                         CSVFormat format2 = CSVFormat.newFormat(' ');
                                                                                                                         CSVFormat format3 = CSVFormat.newFormat('\t');
                                                                                                                         CSVFormat format4 = CSVFormat.newFormat('1');
                                                                                                                         CSVFormat format5 = CSVFormat.newFormat('@');
                                                                                                                         // If we get here, none of these characters were considered line breaks
                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                         fail("Non-line-break characters should be valid delimiters");
                                                                                                                     }
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithUnicodeLineSeparator1() throws Exception {
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     
                                                                                                                     assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u2028')); // Line separator
                                                                                                                     assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u2029')); // Paragraph separator
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithControlCharacters() {
                                                                                                                     try {
                                                                                                                         // Test that control characters are not considered line breaks
                                                                                                                         // by trying to use them as delimiters (which should work)
                                                                                                                         CSVFormat format1 = CSVFormat.newFormat('\b');
                                                                                                                         CSVFormat format2 = CSVFormat.newFormat('\f');
                                                                                                                         
                                                                                                                         // If we get here, the characters were accepted as delimiters,
                                                                                                                         // which means they're not line breaks
                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                         fail("Control characters should not be considered line breaks");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Also test with actual line breaks to ensure our test is valid
                                                                                                                     try {
                                                                                                                         CSVFormat.newFormat('\n');
                                                                                                                         fail("Expected IllegalArgumentException for line break character");
                                                                                                                     } catch (IllegalArgumentException expected) {
                                                                                                                         // expected
                                                                                                                     }
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithSpecialCharacters() {
                                                                                                                     try {
                                                                                                                         // Test that line break characters throw IllegalArgumentException
                                                                                                                         CSVFormat.newFormat('\n');
                                                                                                                         fail("Expected IllegalArgumentException for line break delimiter");
                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                         // Expected
                                                                                                                     }
                                                                                                                     
                                                                                                                     try {
                                                                                                                         // Test that line break characters throw IllegalArgumentException
                                                                                                                         CSVFormat.newFormat('\r');
                                                                                                                         fail("Expected IllegalArgumentException for line break delimiter");
                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                         // Expected
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Test that non-line-break characters are accepted
                                                                                                                     CSVFormat format1 = CSVFormat.newFormat(';');
                                                                                                                     assertNotNull(format1);
                                                                                                                     
                                                                                                                     CSVFormat format2 = CSVFormat.newFormat(',');
                                                                                                                     assertNotNull(format2);
                                                                                                                     
                                                                                                                     CSVFormat format3 = CSVFormat.newFormat('"');
                                                                                                                     assertNotNull(format3);
                                                                                                                 }

 @Test
                                                                                                                 public void testIsLineBreak_WithWhitespaceButNotLineBreak() throws Exception {
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                     Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                     isLineBreakMethod.setAccessible(true);
                                                                                                                     
                                                                                                                     assertFalse((Boolean) isLineBreakMethod.invoke(format, ' '));
                                                                                                                     assertFalse((Boolean) isLineBreakMethod.invoke(format, '\t'));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_Reflexive() {
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     assertTrue(format.equals(format));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_Symmetric() {
                                                                                                                     CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertTrue(format1.equals(format2));
                                                                                                                     assertTrue(format2.equals(format1));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_NullObject() {
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     assertFalse(format.equals(null));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentClass() {
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     assertFalse(format.equals("Not a CSVFormat object"));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentDelimiter() {
                                                                                                                     CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.newFormat(';')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentQuoteCharacter() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('\'')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_NullQuoteCharacter() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote(null)
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_BothNullQuoteCharacter() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     assertTrue(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentQuoteMode() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentCommentMarker() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('!')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentIgnoreSurroundingSpaces() {
                                                                                                                     CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(true)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentIgnoreEmptyLines() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(true)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentNullString() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("NULL")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentHeaders() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header3")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_BothNullHeaders() {
                                                                                                                     CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader((String[]) null)
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader((String[]) null)
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                             
                                                                                                                     assertTrue(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_DifferentSkipHeaderRecord() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(false);
                                                                                                                             
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                             .withDelimiter(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\n")
                                                                                                                             .withNullString("null")
                                                                                                                             .withHeader("header1", "header2")
                                                                                                                             .withSkipHeaderRecord(true);
                                                                                                                             
                                                                                                                     assertFalse(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testEquals_AllFieldsEqual() {
                                                                                                                     CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                     assertTrue(format1.equals(format2));
                                                                                                                 }

 @Test
                                                                                                                 public void testGetCommentMarker_WhenCommentMarkerIsSet() {
                                                                                                                     // Arrange
                                                                                                                     Character expectedCommentMarker = '#';
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                             .withCommentMarker(expectedCommentMarker)
                                                                                                                             .withEscape('\\')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\r\n")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     Character actualCommentMarker = format.getCommentMarker();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                                                 }

 @Test
                                                                                                                 public void testGetCommentMarker_WhenCommentMarkerIsNull() {
                                                                                                                     // Arrange
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     Character actualCommentMarker = format.getCommentMarker();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertNull(actualCommentMarker);
                                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                 public void testGetDelimiter_ConstructorValidation() {
                                                                                                                     // Test that constructor validates against line break delimiters
                                                                                                                     CSVFormat.newFormat('\n');
                                                                                                                 }

 @Test
                                                                                                                 public void testGetEscapeCharacter_WhenEscapeCharacterIsSet() {
                                                                                                                     // Arrange
                                                                                                                     Character expectedEscape = '\\';
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                             .withQuote('"')
                                                                                                                             .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                             .withCommentMarker('#')
                                                                                                                             .withEscape(expectedEscape)
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("\r\n")
                                                                                                                             .withNullString(null)
                                                                                                                             .withHeader("Header1")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     Character actualEscape = format.getEscapeCharacter();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertEquals(expectedEscape, actualEscape);
                                                                                                                 }

 @Test
                                                                                                                 public void testGetEscapeCharacter_WhenEscapeCharacterIsNull() {
                                                                                                                     // Arrange
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader("Header1")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     Character actualEscape = format.getEscapeCharacter();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertNull(actualEscape);
                                                                                                                 }

 @Test
                                                                                                                 public void testGetHeader_WhenHeaderIsNull() {
                                                                                                                     // Arrange
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(null)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act & Assert
                                                                                                                     assertNull(format.getHeader());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetHeader_WhenHeaderIsEmptyArray() {
                                                                                                                     // Arrange
                                                                                                                     String[] emptyHeader = new String[0];
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(null)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader(emptyHeader)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     String[] result = format.getHeader();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertNotNull(result);
                                                                                                                     assertEquals(0, result.length);
                                                                                                                     assertNotSame(emptyHeader, result); // Verify it's a clone
                                                                                                                 }

 @Test
                                                                                                                 public void testGetHeader_WhenHeaderHasSingleElement() {
                                                                                                                     // Arrange
                                                                                                                     String[] singleHeader = {"Column1"};
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(null)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader(singleHeader)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     String[] result = format.getHeader();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertNotNull(result);
                                                                                                                     assertEquals(1, result.length);
                                                                                                                     assertEquals("Column1", result[0]);
                                                                                                                     assertNotSame(singleHeader, result); // Verify it's a clone
                                                                                                                 }

 @Test
                                                                                                                 public void testGetHeader_WhenHeaderHasMultipleElements() {
                                                                                                                     // Arrange
                                                                                                                     String[] multiHeader = {"Column1", "Column2", "Column3"};
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withHeader(multiHeader)
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(null)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     String[] result = format.getHeader();
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     assertNotNull(result);
                                                                                                                     assertEquals(3, result.length);
                                                                                                                     assertArrayEquals(multiHeader, result);
                                                                                                                     assertNotSame(multiHeader, result); // Verify it's a clone
                                                                                                                 }

 @Test
                                                                                                                 public void testGetHeader_ReturnsDefensiveCopy() {
                                                                                                                     // Arrange
                                                                                                                     String[] originalHeader = {"Col1", "Col2"};
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT.withHeader(originalHeader);
                                                                                                                     
                                                                                                                     // Act
                                                                                                                     String[] firstCopy = format.getHeader();
                                                                                                                     firstCopy[0] = "Modified"; // Modify the copy
                                                                                                                     
                                                                                                                     // Assert
                                                                                                                     String[] secondCopy = format.getHeader();
                                                                                                                     assertEquals("Col1", secondCopy[0]); // Original should remain unchanged
                                                                                                                 }

 @Test
                                                                                                                 public void testGetIgnoreEmptyLines_True() {
                                                                                                                     // Create format with ignoreEmptyLines=true using builder pattern
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                                                             .withQuote('"')                     // quoteChar
                                                                                                                             .withQuoteMode(QuoteMode.MINIMAL)   // quoteMode
                                                                                                                             .withCommentMarker(null)            // commentStart
                                                                                                                             .withEscape(null)                   // escape
                                                                                                                             .withIgnoreSurroundingSpaces(false) // ignoreSurroundingSpaces
                                                                                                                             .withIgnoreEmptyLines(true)         // ignoreEmptyLines
                                                                                                                             .withRecordSeparator("\r\n")        // recordSeparator
                                                                                                                             .withNullString(null)               // nullString
                                                                                                                             .withHeader((String[]) null)        // header
                                                                                                                             .withSkipHeaderRecord(false)        // skipHeaderRecord
                                                                                                                             .withAllowMissingColumnNames(false); // allowMissingColumnNames
                                                                                                                     
                                                                                                                     assertTrue("Format with ignoreEmptyLines=true should return true",
                                                                                                                               format.getIgnoreEmptyLines());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetIgnoreEmptyLines_False() {
                                                                                                                     // Create format with ignoreEmptyLines=false using builder pattern
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     assertFalse("Format with ignoreEmptyLines=false should return false",
                                                                                                                                format.getIgnoreEmptyLines());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetIgnoreEmptyLines_Consistency() {
                                                                                                                     // Test that the value remains consistent
                                                                                                                     CSVFormat format = CSVFormat.newFormat('\t')  // delimiter
                                                                                                                             .withQuote('\'')                     // quoteChar
                                                                                                                             .withQuoteMode(QuoteMode.ALL)        // quoteMode
                                                                                                                             .withCommentMarker('#')              // commentStart
                                                                                                                             .withEscape('\\')                    // escape
                                                                                                                             .withIgnoreSurroundingSpaces(true)   // ignoreSurroundingSpaces
                                                                                                                             .withIgnoreEmptyLines(true)          // ignoreEmptyLines
                                                                                                                             .withRecordSeparator("\n")          // recordSeparator
                                                                                                                             .withNullString("NULL")              // nullString
                                                                                                                             .withHeader("Header1", "Header2")   // header
                                                                                                                             .withSkipHeaderRecord(true)         // skipHeaderRecord
                                                                                                                             .withAllowMissingColumnNames(true);  // allowMissingColumnNames
                                                                                                                     
                                                                                                                     // Multiple calls should return same value
                                                                                                                     assertTrue(format.getIgnoreEmptyLines());
                                                                                                                     assertTrue(format.getIgnoreEmptyLines());
                                                                                                                     assertTrue(format.getIgnoreEmptyLines());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetNullString_WhenNullStringIsNull() {
                                                                                                                     // Create a CSVFormat instance with null nullString using builder pattern
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     assertNull(format.getNullString());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetNullString_WhenNullStringIsEmpty() {
                                                                                                                     // Create a CSVFormat instance with empty nullString
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString("")
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     assertEquals("", format.getNullString());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetNullString_WhenNullStringIsSet() {
                                                                                                                     // Create a CSVFormat instance with specific nullString
                                                                                                                     String testNullString = "NULL";
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString(testNullString)
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     assertEquals(testNullString, format.getNullString());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetNullString_AfterWithNullStringModification() {
                                                                                                                     // Create a format and then modify it with withNullString
                                                                                                                     String originalNullString = "NULL";
                                                                                                                     String newNullString = "NA";
                                                                                                                     
                                                                                                                     // Start with DEFAULT format and modify it with our settings
                                                                                                                     CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString(originalNullString)
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     CSVFormat modifiedFormat = originalFormat.withNullString(newNullString);
                                                                                                                     
                                                                                                                     assertEquals(originalNullString, originalFormat.getNullString());
                                                                                                                     assertEquals(newNullString, modifiedFormat.getNullString());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetQuoteMode_WhenQuoteModeIsNull() {
                                                                                                                     // Create a CSVFormat instance with null quote mode
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                     assertNull(format.getQuoteMode());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetQuoteMode_WhenQuoteModeIsAll() {
                                                                                                                     // Create a CSVFormat instance with ALL quote mode
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withAllowMissingColumnNames(false)
                                                                                                                         .withSkipHeaderRecord(false);
                                                                                                                     
                                                                                                                     assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetQuoteMode_WhenQuoteModeIsMinimal() {
                                                                                                                     // Create a CSVFormat instance with MINIMAL quote mode
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                     
                                                                                                                     assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetQuoteMode_WhenQuoteModeIsNonNumeric() {
                                                                                                                     // Create a CSVFormat instance with NON_NUMERIC quote mode using builder pattern
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                                                     
                                                                                                                     assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetRecordSeparator_CustomFormatWithNullSeparator() {
                                                                                                                     // Test with custom format where record separator is null
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                             .withRecordSeparator(null);
                                                                                                                     assertNull(format.getRecordSeparator());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetRecordSeparator_CustomFormatWithEmptyString() {
                                                                                                                     // Test with custom format where record separator is empty string
                                                                                                                     CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("");
                                                                                                                     assertEquals("", format.getRecordSeparator());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetRecordSeparator_CustomFormatWithSingleChar() {
                                                                                                                     // Test with custom format where record separator is a single character
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                             .withRecordSeparator("|")
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withIgnoreSurroundingSpaces(false);
                                                                                                                     assertEquals("|", format.getRecordSeparator());
                                                                                                                 }

 @Test
                                                                                                                 public void testGetRecordSeparator_CustomFormatWithMultipleChars() {
                                                                                                                     // Test with custom format where record separator is multiple characters
                                                                                                                     CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                                             .withRecordSeparator("~~~")
                                                                                                                             .withSkipHeaderRecord(false)
                                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                                     assertEquals("~~~", format.getRecordSeparator());
                                                                                                                 }

 @Test
                                                                                                             public void testGetSkipHeaderRecord_WhenTrue() {
                                                                                                                 // Create a CSVFormat instance with skipHeaderRecord set to true using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                     .withCommentMarker('#')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader("a", "b")
                                                                                                                     .withSkipHeaderRecord(true)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertTrue("Expected skipHeaderRecord to be true", format.getSkipHeaderRecord());
                                                                                                             }

 @Test
                                                                                                             public void testGetSkipHeaderRecord_WhenFalse() {
                                                                                                                 // Create a CSVFormat instance with skipHeaderRecord set to false using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                     .withCommentMarker('#')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader("a", "b")
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertFalse("Expected skipHeaderRecord to be false", format.getSkipHeaderRecord());
                                                                                                             }

 @Test
                                                                                                             public void testHashCode_AllFieldsSet() {
                                                                                                                 // Create a CSVFormat with all fields set using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.ALL)
                                                                                                                     .withCommentMarker('#')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(true)
                                                                                                                     .withIgnoreEmptyLines(true)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString("NULL")
                                                                                                                     .withHeader("Header1", "Header2")
                                                                                                                     .withSkipHeaderRecord(true)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                             
                                                                                                                 // Calculate expected hash code manually
                                                                                                                 int expected = 31;
                                                                                                                 expected = 31 * expected + ',';
                                                                                                                 expected = 31 * expected + QuoteMode.ALL.hashCode();
                                                                                                                 expected = 31 * expected + '"';
                                                                                                                 expected = 31 * expected + '#';
                                                                                                                 expected = 31 * expected + '\\';
                                                                                                                 expected = 31 * expected + "NULL".hashCode();
                                                                                                                 expected = 31 * expected + (true ? 1231 : 1237);
                                                                                                                 expected = 31 * expected + (true ? 1231 : 1237);
                                                                                                                 expected = 31 * expected + (true ? 1231 : 1237);
                                                                                                                 expected = 31 * expected + "\r\n".hashCode();
                                                                                                                 expected = 31 * expected + Arrays.hashCode(new String[]{"Header1", "Header2"});
                                                                                                                 
                                                                                                                 assertEquals(expected, format.hashCode());
                                                                                                             }

 @Test
                                                                                                             public void testHashCode_DefaultFormat() {
                                                                                                                 // Get the DEFAULT format (assuming it's a static field)
                                                                                                                 CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                                 
                                                                                                                 // Create another instance with same values using builder pattern
                                                                                                                 CSVFormat sameAsDefault = CSVFormat.newFormat(defaultFormat.getDelimiter())
                                                                                                                     .withQuote(defaultFormat.getQuoteCharacter())
                                                                                                                     .withQuoteMode(defaultFormat.getQuoteMode())
                                                                                                                     .withCommentMarker(defaultFormat.getCommentMarker())
                                                                                                                     .withEscape(defaultFormat.getEscapeCharacter())
                                                                                                                     .withIgnoreSurroundingSpaces(defaultFormat.getIgnoreSurroundingSpaces())
                                                                                                                     .withIgnoreEmptyLines(defaultFormat.getIgnoreEmptyLines())
                                                                                                                     .withRecordSeparator(defaultFormat.getRecordSeparator())
                                                                                                                     .withNullString(defaultFormat.getNullString())
                                                                                                                     .withHeader(defaultFormat.getHeader())
                                                                                                                     .withSkipHeaderRecord(defaultFormat.getSkipHeaderRecord())
                                                                                                                     .withAllowMissingColumnNames(defaultFormat.getAllowMissingColumnNames());
                                                                                                                 
                                                                                                                 assertEquals(defaultFormat.hashCode(), sameAsDefault.hashCode());
                                                                                                             }

 @Test
                                                                                                             public void testHashCode_OnlyBooleanFlagsDifferent() {
                                                                                                                 CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                     .withIgnoreSurroundingSpaces(true)
                                                                                                                     .withIgnoreEmptyLines(true)
                                                                                                                     .withSkipHeaderRecord(true);
                                                                                                                 CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withSkipHeaderRecord(false);
                                                                                                                 
                                                                                                                 assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                             }

 @Test
                                                                                                             public void testHashCode_WithEmptyHeader() {
                                                                                                                 CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator(null)
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader(new String[]{})
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                 CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator(null)
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader(null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                             }

 @Test
                                                                                                             public void testHashCode_ConsistentWithEquals() {
                                                                                                                 // Two equal objects must have the same hash code
                                                                                                                 CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.ALL)
                                                                                                                     .withCommentMarker('#')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(true)
                                                                                                                     .withIgnoreEmptyLines(true)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString("NULL")
                                                                                                                     .withHeader("Header")
                                                                                                                     .withSkipHeaderRecord(true)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                     
                                                                                                                 CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.ALL)
                                                                                                                     .withCommentMarker('#')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(true)
                                                                                                                     .withIgnoreEmptyLines(true)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString("NULL")
                                                                                                                     .withHeader("Header")
                                                                                                                     .withSkipHeaderRecord(true)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertEquals(format1, format2);
                                                                                                                 assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                             }

 @Test
                                                                                                             public void testIsCommentMarkerSet_WhenCommentMarkerIsNull() {
                                                                                                                 // Create a CSVFormat with null comment marker using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[])null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertFalse("Should return false when commentMarker is null", 
                                                                                                                            format.isCommentMarkerSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNull() {
                                                                                                                 // Create CSVFormat with null escape character using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertFalse("Should return false when escape character is null", 
                                                                                                                            format.isEscapeCharacterSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNotNull() {
                                                                                                                 // Create CSVFormat with non-null escape character using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertTrue("Should return true when escape character is not null", 
                                                                                                                           format.isEscapeCharacterSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsNullStringSet_WhenNullStringIsNull() {
                                                                                                                 // Create CSVFormat with nullString set to null using public methods
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[])null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertFalse("Should return false when nullString is null", format.isNullStringSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsNullStringSet_WhenNullStringIsEmptyString() {
                                                                                                                 // Create CSVFormat with empty string as nullString using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.DEFAULT
                                                                                                                     .withDelimiter(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString("")
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertTrue("Should return true when nullString is empty string", format.isNullStringSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsNullStringSet_WhenNullStringIsNonEmptyString() {
                                                                                                                 // Create CSVFormat with non-empty nullString using builder pattern
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString("NULL")
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertTrue("Should return true when nullString is non-empty", format.isNullStringSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsNullStringSet_AfterWithNullStringModification() {
                                                                                                                 // Create format with null nullString using factory method
                                                                                                                 CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 assertFalse("Original should have nullString not set", original.isNullStringSet());
                                                                                                                 
                                                                                                                 // Modify with non-null nullString
                                                                                                                 CSVFormat modified = original.withNullString("NULL");
                                                                                                                 assertTrue("Modified format should have nullString set", modified.isNullStringSet());
                                                                                                                 
                                                                                                                 // Modify back to null
                                                                                                                 CSVFormat modifiedBack = modified.withNullString(null);
                                                                                                                 assertFalse("Modified back format should have nullString not set", modifiedBack.isNullStringSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNull() {
                                                                                                                 // Create CSVFormat with null quote character
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',').withQuote((Character) null);
                                                                                                                 
                                                                                                                 assertFalse("Should return false when quoteCharacter is null", 
                                                                                                                     format.isQuoteCharacterSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNotNull() {
                                                                                                                 // Create CSVFormat with non-null quote character
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',').withQuote('"');
                                                                                                                 
                                                                                                                 assertTrue("Should return true when quoteCharacter is not null", 
                                                                                                                     format.isQuoteCharacterSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsQuoteCharacterSet_AfterWithQuote() {
                                                                                                                 // Create format without quote character using factory method
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withRecordSeparator("\r\n")
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withIgnoreSurroundingSpaces(false);
                                                                                                                 
                                                                                                                 assertFalse("Initial format should not have quote character", 
                                                                                                                     format.isQuoteCharacterSet());
                                                                                                                 
                                                                                                                 // Add quote character
                                                                                                                 CSVFormat newFormat = format.withQuote('"');
                                                                                                                 assertTrue("After withQuote, should have quote character set", 
                                                                                                                     newFormat.isQuoteCharacterSet());
                                                                                                             }

 @Test
                                                                                                             public void testIsQuoteCharacterSet_AfterWithNullQuote() {
                                                                                                                 // Create initial format with delimiter only
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',');
                                                                                                                 // Set quote character
                                                                                                                 format = format.withQuote('"');
                                                                                                                 
                                                                                                                 assertTrue("Initial format should have quote character", 
                                                                                                                     format.isQuoteCharacterSet());
                                                                                                                 
                                                                                                                 // Set quote character to null
                                                                                                                 CSVFormat newFormat = format.withQuote((Character) null);
                                                                                                                 assertFalse("After withQuote(null), should not have quote character set", 
                                                                                                                     newFormat.isQuoteCharacterSet());
                                                                                                             }

 @Test
                                                                                                             public void testParse_WithEmptyInput() throws IOException {
                                                                                                                 // Setup
                                                                                                                 org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                                                                                 String input = "";
                                                                                                                 java.io.Reader reader = new java.io.StringReader(input);
                                                                                                                 
                                                                                                                 // Execute
                                                                                                                 org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 assertNotNull(parser);
                                                                                                                 assertFalse(parser.iterator().hasNext());
                                                                                                                 
                                                                                                                 // Cleanup
                                                                                                                 parser.close();
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithAllOptions() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat(';')
                                                                                                                         .withQuote('\'')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(true)
                                                                                                                         .withIgnoreEmptyLines(true)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString("NULL")
                                                                                                                         .withHeader("col1", "col2")
                                                                                                                         .withSkipHeaderRecord(true)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<;> Escape=<\\> QuoteChar=<'> CommentStart=<#> NullString=<NULL> " +
                                                                                                                                  "RecordSeparator=<\r\n> EmptyLines:ignored SurroundingSpaces:ignored " +
                                                                                                                                  "SkipHeaderRecord:true Header:[col1, col2]";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithNullValues() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat('\t')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator(null)
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[])null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<\t> SkipHeaderRecord:false";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithOnlyDelimiterAndHeader() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat('|')
                                                                                                                         .withQuote(null)
                                                                                                                         .withQuoteMode(null)
                                                                                                                         .withCommentMarker(null)
                                                                                                                         .withEscape(null)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator(null)
                                                                                                                         .withNullString(null)
                                                                                                                         .withHeader("a", "b", "c")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<|> SkipHeaderRecord:false Header:[a, b, c]";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithEmptyHeader() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withQuote(null)
                                                                                                                     .withQuoteMode(null)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator(null)
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader(new String[]{})
                                                                                                                     .withSkipHeaderRecord(true)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<,> SkipHeaderRecord:true Header:[]";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithOnlyDelimiterAndRecordSeparator() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withRecordSeparator("|")
                                                                                                                     .withSkipHeaderRecord(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<,> RecordSeparator=<|> SkipHeaderRecord:false";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithOnlyQuoteAndEscapeCharacters() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testToString_WithOnlySpaceHandlingOptions() {
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                     .withIgnoreSurroundingSpaces(true)
                                                                                                                     .withIgnoreEmptyLines(true)
                                                                                                                     .withSkipHeaderRecord(false);
                                                                                                                 
                                                                                                                 String expected = "Delimiter=<,> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:false";
                                                                                                                 assertEquals(expected, format.toString());
                                                                                                             }

 @Test
                                                                                                             public void testValidate_QuoteCharSameAsDelimiter() {
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The quoteChar character and the delimiter cannot be the same ('\"')");
                                                                                                                 
                                                                                                                 CSVFormat format = CSVFormat.newFormat('"').withQuote('"');
                                                                                                             }

 @Test
                                                                                                             public void testValidate_EscapeCharSameAsDelimiter() {
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The escape character and the delimiter cannot be the same ('\\')");
                                                                                                                 
                                                                                                                 CSVFormat.newFormat('\\').withEscape('\\');
                                                                                                             }

 @Test
                                                                                                             public void testValidate_CommentMarkerSameAsDelimiter() {
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The comment start character and the delimiter cannot be the same ('#')");
                                                                                                                 
                                                                                                                 CSVFormat format = CSVFormat.newFormat('#')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#');
                                                                                                             }

 @Test
                                                                                                             public void testValidate_QuoteCharSameAsCommentMarker() {
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The comment start character and the quoteChar cannot be the same ('!')");
                                                                                                                 
                                                                                                                 CSVFormat.newFormat(',')
                                                                                                                     .withQuote('!')
                                                                                                                     .withQuoteMode(QuoteMode.ALL)
                                                                                                                     .withCommentMarker('!');
                                                                                                             }

 @Test
                                                                                                             public void testValidate_EscapeCharSameAsCommentMarker() {
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The comment start and the escape character cannot be the same ('*')");
                                                                                                                 
                                                                                                                 CSVFormat.newFormat(',')
                                                                                                                          .withQuoteMode(QuoteMode.ALL)
                                                                                                                          .withCommentMarker('*')
                                                                                                                          .withEscape('*')
                                                                                                                          .withIgnoreSurroundingSpaces(false)
                                                                                                                          .withIgnoreEmptyLines(false)
                                                                                                                          .withRecordSeparator("\n")
                                                                                                                          .withSkipHeaderRecord(false)
                                                                                                                          .withAllowMissingColumnNames(false);
                                                                                                             }

 @Test
                                                                                                             public void testValidate_NoEscapeCharWithQuoteModeNone() {
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("No quotes mode set but no escape character is set");
                                                                                                                 
                                                                                                                 CSVFormat.newFormat(',')
                                                                                                                     .withQuoteMode(QuoteMode.NONE)
                                                                                                                     .withQuote(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\n")
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                             }

 @Test
                                                                                                             public void testValidate_ValidConfigWithQuoteModeNoneAndEscape() {
                                                                                                                 // Should not throw exception
                                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                         .withQuoteMode(QuoteMode.NONE)
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                             }

 @Test
                                                                                                             public void testValidate_ValidConfigWithAllParameters() {
                                                                                                                 // Should not throw exception
                                                                                                                 CSVFormat.newFormat(',')
                                                                                                                     .withQuote('"')
                                                                                                                     .withQuoteMode(QuoteMode.ALL)
                                                                                                                     .withCommentMarker('#')
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\n")
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                             }

 @Test
                                                                                                             public void testValidate_ValidConfigWithMinimalParameters() {
                                                                                                                 // Should not throw exception
                                                                                                                 CSVFormat.newFormat(',')
                                                                                                                     .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                     .withEscape('\\')
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator("\n")
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                             }

 @Test
                                                                                                             public void testWithAllowMissingColumnNames_LineBreakDelimiter() {
                                                                                                                 // Setup format with line break delimiter (should throw exception)
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                 
                                                                                                                 CSVFormat.newFormat('\n').withAllowMissingColumnNames(true);
                                                                                                             }

 @Test
                                                                                                             public void testWithQuote_ValidCharacter1() {
                                                                                                                 // Setup
                                                                                                                 char delimiter = ',';
                                                                                                                 Character quoteChar = '"';
                                                                                                                 CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                                     .withCommentMarker(null)
                                                                                                                     .withEscape(null)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                                     .withRecordSeparator(null)
                                                                                                                     .withNullString(null)
                                                                                                                     .withHeader((String[]) null)
                                                                                                                     .withSkipHeaderRecord(false)
                                                                                                                     .withAllowMissingColumnNames(false);
                                                                                                                 
                                                                                                                 // Test
                                                                                                                 CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                                 assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                                 assertNull(newFormat.getCommentMarker());
                                                                                                                 assertNull(newFormat.getEscapeCharacter());
                                                                                                                 assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                 assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                                                 assertNull(newFormat.getRecordSeparator());
                                                                                                                 assertNull(newFormat.getNullString());
                                                                                                                 assertNull(newFormat.getHeader());
                                                                                                                 assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                                 assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                                             }

 @Test
                                                                                                             public void testWithQuote_NullCharacter1() {
                                                                                                                 // Setup
                                                                                                                 char delimiter = ',';
                                                                                                                 CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false);
                                                                                                                 
                                                                                                                 // Test
                                                                                                                 CSVFormat newFormat = originalFormat.withQuote((Character) null);
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 assertNull(newFormat.getQuoteCharacter());
                                                                                                                 assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                             }

 @Test
                                                                                                             public void testWithQuote_LineBreakCharacter_ShouldThrowException() {
                                                                                                                 // Setup
                                                                                                                 char delimiter = ',';
                                                                                                                 CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false);
                                                                                                                 
                                                                                                                 // Expect exception
                                                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                                                 thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                                 
                                                                                                                 // Test with line break character
                                                                                                                 originalFormat.withQuote('\n');
                                                                                                             }

 @Test
                                                                                                             public void testWithQuote_PreservesOtherSettings() {
                                                                                                                 // Setup
                                                                                                                 char delimiter = '|';
                                                                                                                 Character quoteChar = '\'';
                                                                                                                 Character commentMarker = '#';
                                                                                                                 Character escape = '\\';
                                                                                                                 boolean ignoreSpaces = true;
                                                                                                                 boolean ignoreEmptyLines = true;
                                                                                                                 String recordSeparator = "\r\n";
                                                                                                                 String nullString = "NULL";
                                                                                                                 String[] header = {"col1", "col2"};
                                                                                                                 boolean skipHeader = true;
                                                                                                                 boolean allowMissing = true;
                                                                                                                 
                                                                                                                 // Create base format using public factory method
                                                                                                                 CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                                     .withQuoteMode(QuoteMode.ALL)
                                                                                                                     .withCommentMarker(commentMarker)
                                                                                                                     .withEscape(escape)
                                                                                                                     .withIgnoreSurroundingSpaces(ignoreSpaces)
                                                                                                                     .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                     .withRecordSeparator(recordSeparator)
                                                                                                                     .withNullString(nullString)
                                                                                                                     .withHeader(header)
                                                                                                                     .withSkipHeaderRecord(skipHeader)
                                                                                                                     .withAllowMissingColumnNames(allowMissing);
                                                                                                                 
                                                                                                                 // Test
                                                                                                                 CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                 
                                                                                                                 // Verify all other settings are preserved
                                                                                                                 assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                                 assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                                 assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                                 assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                 assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                                                 assertEquals(ignoreSpaces, newFormat.getIgnoreSurroundingSpaces());
                                                                                                                 assertEquals(ignoreEmptyLines, newFormat.getIgnoreEmptyLines());
                                                                                                                 assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                                                 assertEquals(nullString, newFormat.getNullString());
                                                                                                                 assertArrayEquals(header, newFormat.getHeader());
                                                                                                                 assertEquals(skipHeader, newFormat.getSkipHeaderRecord());
                                                                                                                 assertEquals(allowMissing, newFormat.getAllowMissingColumnNames());
                                                                                                             }

 @Test
                                                                                                             public void testWithQuote_PrimitiveCharVersion() {
                                                                                                                 // Setup
                                                                                                                 char delimiter = '\t';
                                                                                                                 char quoteChar = '\'';
                                                                                                                 CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                                     .withIgnoreEmptyLines(false);
                                                                                                                 
                                                                                                                 // Test
                                                                                                                 CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                                 assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                             }

 @Test
                                                                                                             public void testIsLineBreak_WithLineBreakCharacters() {
                                                                                                                 try {
                                                                                                                     // Test through newFormat validation which uses isLineBreak internally
                                                                                                                     CSVFormat.newFormat('\n');
                                                                                                                     fail("Expected IllegalArgumentException for line break delimiter");
                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                     assertEquals("The delimiter cannot be a line break", e.getMessage());
                                                                                                                 }
                                                                                                                 
                                                                                                                 try {
                                                                                                                     CSVFormat.newFormat('\r');
                                                                                                                     fail("Expected IllegalArgumentException for line break delimiter");
                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                     assertEquals("The delimiter cannot be a line break", e.getMessage());
                                                                                                                 }
                                                                                                             }

 @Test
                                                                                                             public void testIsLineBreak_WithCombinationCharacters() {
                                                                                                                 // Test through withDelimiter validation which uses isLineBreak internally
                                                                                                                 try {
                                                                                                                     CSVFormat.DEFAULT.withDelimiter('\n');
                                                                                                                     fail("Expected IllegalArgumentException");
                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                     assertEquals("The delimiter cannot be a line break", e.getMessage());
                                                                                                                 }
                                                                                                                 
                                                                                                                 // Test with normal character that shouldn't be line break
                                                                                                                 try {
                                                                                                                     CSVFormat.DEFAULT.withDelimiter('x');
                                                                                                                 } catch (IllegalArgumentException e) {
                                                                                                                     fail("Should not throw exception for non-line-break delimiter");
                                                                                                                 }
                                                                                                             }

 @Test
                                                                                                             public void testEquals_DifferentEscapeCharacter() {
                                                                                                                 CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                 CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('/')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                 assertFalse(format1.equals(format2));
                                                                                                             }

 @Test
                                                                                                             public void testEquals_DifferentRecordSeparator() {
                                                                                                                 CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                 CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\r\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                 assertFalse(format1.equals(format2));
                                                                                                             }

 @Test
                                                                                                             public void testEquals_NullHeaders() {
                                                                                                                 CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader((String[]) null)
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                 CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                         .withDelimiter(',')
                                                                                                                         .withQuote('"')
                                                                                                                         .withQuoteMode(QuoteMode.ALL)
                                                                                                                         .withCommentMarker('#')
                                                                                                                         .withEscape('\\')
                                                                                                                         .withIgnoreSurroundingSpaces(false)
                                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                                         .withRecordSeparator("\n")
                                                                                                                         .withNullString("null")
                                                                                                                         .withHeader("header1", "header2")
                                                                                                                         .withSkipHeaderRecord(false)
                                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                                         
                                                                                                                 assertFalse(format1.equals(format2));
                                                                                                             }

 @Test
                                                                                                         public void testValidate_ValidConfigWithNullParameters() {
                                                                                                             // Should not throw exception
                                                                                                             CSVFormat.newFormat(',')
                                                                                                                 .withQuote(null)
                                                                                                                 .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                                 .withCommentMarker(null)
                                                                                                                 .withEscape(null)
                                                                                                                 .withIgnoreSurroundingSpaces(false)
                                                                                                                 .withIgnoreEmptyLines(false)
                                                                                                                 .withRecordSeparator("\n")
                                                                                                                 .withNullString(null)
                                                                                                                 .withHeader((String[]) null)
                                                                                                                 .withSkipHeaderRecord(false)
                                                                                                                 .withAllowMissingColumnNames(false);
                                                                                                         }

 @Test
                                                                                                     public void testHashCode_WithNullFields() {
                                                                                                         // Create a CSVFormat with some null fields using builder pattern
                                                                                                         CSVFormat format = CSVFormat.newFormat('\t')
                                                                                                             .withQuote((Character) null)
                                                                                                             .withQuoteMode(null)
                                                                                                             .withCommentMarker(null)
                                                                                                             .withEscape(null)
                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                             .withRecordSeparator(null)
                                                                                                             .withNullString(null)
                                                                                                             .withHeader((String[]) null)
                                                                                                             .withSkipHeaderRecord(false)
                                                                                                             .withAllowMissingColumnNames(true);
                                                                                                         
                                                                                                         // Calculate expected hash code manually
                                                                                                         int expected = 31;
                                                                                                         expected = 31 * expected + (int) '\t';  // delimiter
                                                                                                         expected = 31 * expected + 0;           // null quoteMode
                                                                                                         expected = 31 * expected + 0;           // null quoteCharacter
                                                                                                         expected = 31 * expected + 0;           // null commentMarker
                                                                                                         expected = 31 * expected + 0;           // null escapeCharacter
                                                                                                         expected = 31 * expected + 0;           // null nullString
                                                                                                         expected = 31 * expected + (false ? 1231 : 1237);  // ignoreSurroundingSpaces
                                                                                                         expected = 31 * expected + (false ? 1231 : 1237);  // ignoreEmptyLines
                                                                                                         expected = 31 * expected + (false ? 1231 : 1237);  // skipHeaderRecord
                                                                                                         expected = 31 * expected + 0;           // null recordSeparator
                                                                                                         expected = 31 * expected + 0;           // null header
                                                                                                         
                                                                                                         assertEquals(expected, format.hashCode());
                                                                                                     }

 @Test
                                                                                                     public void testParse_WithQuotedValues() throws IOException {
                                                                                                         // Setup
                                                                                                         org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                                                                         String input = "\"a\",\"b\",\"c\"\n\"1\",\"2\",\"3\"";
                                                                                                         java.io.Reader reader = new java.io.StringReader(input);
                                                                                                         
                                                                                                         // Execute
                                                                                                         org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                                         
                                                                                                         // Verify
                                                                                                         assertNotNull(parser);
                                                                                                         java.util.Iterator<org.apache.commons.csv.CSVRecord> records = parser.iterator();
                                                                                                         assertTrue(records.hasNext());
                                                                                                         assertEquals("a", records.next().get(0));
                                                                                                         assertTrue(records.hasNext());
                                                                                                         assertEquals("1", records.next().get(0));
                                                                                                         
                                                                                                         // Cleanup
                                                                                                         parser.close();
                                                                                                     }

 @Test
                                                                                                     public void testWithQuoteMode_AllNullFieldsExceptQuoteMode() {
                                                                                                         // Test with all optional fields null
                                                                                                         CSVFormat original = CSVFormat.newFormat(',')
                                                                                                             .withQuote((Character) null)
                                                                                                             .withQuoteMode(null)
                                                                                                             .withCommentMarker((Character) null)
                                                                                                             .withEscape((Character) null)
                                                                                                             .withIgnoreSurroundingSpaces(false)
                                                                                                             .withIgnoreEmptyLines(false)
                                                                                                             .withRecordSeparator((String) null)
                                                                                                             .withNullString(null)
                                                                                                             .withHeader((String[])null)
                                                                                                             .withSkipHeaderRecord(false)
                                                                                                             .withAllowMissingColumnNames(false);
                                                                                                         
                                                                                                         CSVFormat modified = original.withQuoteMode(QuoteMode.ALL);
                                                                                                         
                                                                                                         assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                                         assertNull(modified.getQuoteCharacter());
                                                                                                         assertNull(modified.getCommentMarker());
                                                                                                         assertNull(modified.getEscapeCharacter());
                                                                                                         assertNull(modified.getRecordSeparator());
                                                                                                         assertNull(modified.getNullString());
                                                                                                         assertNull(modified.getHeader());
                                                                                                     }

 @Test
                                                                                                 public void testWithQuoteMode_FromNullQuoteMode() {
                                                                                                     // Create format with null quote mode by starting with DEFAULT and modifying properties
                                                                                                     CSVFormat original = CSVFormat.DEFAULT
                                                                                                         .withDelimiter(',')
                                                                                                         .withQuote('"')
                                                                                                         .withQuoteMode(null)
                                                                                                         .withCommentMarker('#')
                                                                                                         .withEscape('\\')
                                                                                                         .withIgnoreSurroundingSpaces(true)
                                                                                                         .withIgnoreEmptyLines(false)
                                                                                                         .withRecordSeparator("\r\n")
                                                                                                         .withNullString("NULL")
                                                                                                         .withHeader("Name", "Age")
                                                                                                         .withSkipHeaderRecord(true)
                                                                                                         .withAllowMissingColumnNames(false);
                                                                                                     
                                                                                                     // Set to non-null quote mode
                                                                                                     CSVFormat modified = original.withQuoteMode(org.apache.commons.csv.QuoteMode.ALL);
                                                                                                     
                                                                                                     assertEquals(org.apache.commons.csv.QuoteMode.ALL, modified.getQuoteMode());
                                                                                                     assertNull(original.getQuoteMode()); // original should remain unchanged
                                                                                                 }

 @Test
                                                                                             public void testPrint_WithAllFeaturesEnabled() throws IOException {
                                                                                                 // Arrange
                                                                                                 java.io.StringWriter writer = new java.io.StringWriter();
                                                                                                 org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat('\t')
                                                                                                     .withQuote('"')
                                                                                                     .withEscape('\\')
                                                                                                     .withCommentMarker(Character.valueOf('#'))
                                                                                                     .withNullString("NULL")
                                                                                                     .withIgnoreEmptyLines(true)
                                                                                                     .withIgnoreSurroundingSpaces(true)
                                                                                                     .withRecordSeparator("\r\n")
                                                                                                     .withHeader("Col1", "Col2", "Col3")
                                                                                                     .withSkipHeaderRecord(true);
                                                                                                 
                                                                                                 // Act
                                                                                                 org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                                                                 
                                                                                                 // Assert
                                                                                                 assertNotNull(printer);
                                                                                                 assertSame(writer, printer.getOut());
                                                                                                 
                                                                                                 // Verify format indirectly by checking printer behavior
                                                                                                 printer.print("value1");
                                                                                                 printer.print((String) null);  // should print "NULL"
                                                                                                 printer.println();
                                                                                                 printer.printComment("comment");
                                                                                                 printer.close();
                                                                                                 
                                                                                                 String result = writer.toString();
                                                                                                 assertTrue(result.contains("value1"));
                                                                                                 assertTrue(result.contains("NULL"));
                                                                                                 assertTrue(result.contains("#comment"));
                                                                                             }

 @Test
                                                                                             public void testPrint_WithMinimalFormat() throws IOException {
                                                                                                 // Arrange
                                                                                                 StringWriter writer = new StringWriter();
                                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                                     .withQuote(null)
                                                                                                     .withEscape(null)
                                                                                                     .withCommentMarker((Character) null)
                                                                                                     .withNullString(null)
                                                                                                     .withIgnoreEmptyLines(false)
                                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                                     .withRecordSeparator("\n")
                                                                                                     .withHeader((String[]) null)
                                                                                                     .withSkipHeaderRecord(false);
                                                                                                 
                                                                                                 // Act
                                                                                                 CSVPrinter printer = format.print(writer);
                                                                                                 
                                                                                                 // Assert
                                                                                                 assertNotNull(printer);
                                                                                                 assertSame(writer, printer.getOut());
                                                                                             }

 @Test
                                                                                         public void testParse_WithHeader() throws IOException {
                                                                                             // Setup
                                                                                             String[] headers = {"Name", "Age", "City"};
                                                                                             org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withHeader(headers);
                                                                                             String input = "John,30,New York";
                                                                                             java.io.Reader reader = new java.io.StringReader(input);
                                                                                             
                                                                                             // Execute
                                                                                             org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                             
                                                                                             // Verify
                                                                                             assertNotNull(parser);
                                                                                             assertArrayEquals(headers, format.getHeader());
                                                                                             
                                                                                             // Cleanup
                                                                                             parser.close();
                                                                                         }

 @Test
                                                                                         public void testPrint_WithMockAppendable() throws Exception {
                                                                                             // Arrange
                                                                                             Appendable mockAppendable = mock(Appendable.class);
                                                                                             org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(',');
                                                                                             
                                                                                             // Act
                                                                                             org.apache.commons.csv.CSVPrinter printer = format.print(mockAppendable);
                                                                                             
                                                                                             // Assert
                                                                                             org.junit.Assert.assertNotNull(printer);
                                                                                             // Use reflection to access private format field
                                                                                             java.lang.reflect.Field formatField = org.apache.commons.csv.CSVPrinter.class.getDeclaredField("format");
                                                                                             formatField.setAccessible(true);
                                                                                             org.apache.commons.csv.CSVFormat actualFormat = (org.apache.commons.csv.CSVFormat) formatField.get(printer);
                                                                                             org.junit.Assert.assertEquals(format, actualFormat);
                                                                                             org.junit.Assert.assertSame(mockAppendable, printer.getOut());
                                                                                         }

 @Test
                                                                                     public void testPrint_WithCustomFormat() throws IOException {
                                                                                         // Arrange
                                                                                         StringWriter writer = new StringWriter();
                                                                                         CSVFormat format = CSVFormat.newFormat(';')
                                                                                             .withQuote('"')
                                                                                             .withQuoteMode(QuoteMode.ALL)
                                                                                             .withHeader("Name", "Age");
                                                                                         
                                                                                         // Act
                                                                                         CSVPrinter printer = format.print(writer);
                                                                                         
                                                                                         // Assert
                                                                                         assertNotNull(printer);
                                                                                         assertSame(writer, printer.getOut());
                                                                                     }

 @Test
                                                                                 public void testPrint_WithDefaultFormat() throws IOException {
                                                                                     // Arrange
                                                                                     java.io.StringWriter writer = new java.io.StringWriter();
                                                                                     org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(',')
                                                                                         .withQuote('"')
                                                                                         .withRecordSeparator("\r\n")
                                                                                         .withIgnoreEmptyLines(false)
                                                                                         .withIgnoreSurroundingSpaces(false);
                                                                                     
                                                                                     // Act
                                                                                     org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                                                     
                                                                                     // Assert
                                                                                     org.junit.Assert.assertNotNull(printer);
                                                                                     org.junit.Assert.assertSame(writer, printer.getOut());
                                                                                     
                                                                                     // Verify format indirectly by printing a value
                                                                                     printer.print("test");
                                                                                     printer.flush();
                                                                                     org.junit.Assert.assertEquals("\"test\"\r\n", writer.toString());
                                                                                 }

 @Test
                                                                             public void testIsCommentMarkerSet_WhenCommentMarkerIsSet() {
                                                                                 // Create a CSVFormat with a comment marker using builder pattern
                                                                                 CSVFormat format = CSVFormat.newFormat(',')
                                                                                     .withCommentMarker('#')
                                                                                     .withQuote(null)
                                                                                     .withQuoteMode(null)
                                                                                     .withEscape(null)
                                                                                     .withIgnoreSurroundingSpaces(false)
                                                                                     .withIgnoreEmptyLines(false)
                                                                                     .withRecordSeparator("\n")
                                                                                     .withNullString(null)
                                                                                     .withHeader((String[]) null)
                                                                                     .withSkipHeaderRecord(false)
                                                                                     .withAllowMissingColumnNames(false);
                                                                                 
                                                                                 assertTrue("Should return true when commentMarker is set", 
                                                                                           format.isCommentMarkerSet());
                                                                             }

 @Test
                                                                         public void testHashCode_OnlyDelimiterDifferent() {
                                                                             CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                 .withQuoteMode(null)
                                                                                 .withCommentMarker((Character) null)
                                                                                 .withEscape((Character) null)
                                                                                 .withIgnoreSurroundingSpaces(false)
                                                                                 .withIgnoreEmptyLines(false)
                                                                                 .withRecordSeparator((String) null)
                                                                                 .withNullString((String) null)
                                                                                 .withHeader((String[]) null)
                                                                                 .withSkipHeaderRecord(false)
                                                                                 .withAllowMissingColumnNames(false);
                                                                                 
                                                                             CSVFormat format2 = CSVFormat.newFormat(';')
                                                                                 .withQuoteMode(null)
                                                                                 .withCommentMarker((Character) null)
                                                                                 .withEscape((Character) null)
                                                                                 .withIgnoreSurroundingSpaces(false)
                                                                                 .withIgnoreEmptyLines(false)
                                                                                 .withRecordSeparator((String) null)
                                                                                 .withNullString((String) null)
                                                                                 .withHeader((String[]) null)
                                                                                 .withSkipHeaderRecord(false)
                                                                                 .withAllowMissingColumnNames(false);
                                                                             
                                                                             assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                         }

 @Test
                                                                         public void testParse_WithValidReader() throws IOException {
                                                                             // Setup
                                                                             org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(',');
                                                                             String input = "a,b,c\n1,2,3";
                                                                             java.io.Reader reader = new java.io.StringReader(input);
                                                                             
                                                                             // Execute
                                                                             org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                             
                                                                             // Verify
                                                                             org.junit.Assert.assertNotNull(parser);
                                                                             
                                                                             // Cleanup
                                                                             parser.close();
                                                                         }

 @Test
                                                                         public void testParse_WithCustomFormat() throws IOException {
                                                                             // Setup
                                                                             CSVFormat format = CSVFormat.newFormat(';')
                                                                                 .withQuote('"')
                                                                                 .withRecordSeparator("\r\n")
                                                                                 .withIgnoreEmptyLines(true);
                                                                             String input = "a;b;c\r\n1;2;3";
                                                                             java.io.Reader reader = new java.io.StringReader(input);
                                                                             
                                                                             // Execute
                                                                             org.apache.commons.csv.CSVParser parser = new org.apache.commons.csv.CSVParser(reader, format);
                                                                             
                                                                             // Verify
                                                                             assertNotNull(parser);
                                                                             
                                                                             // Verify parsed content
                                                                             java.util.List<org.apache.commons.csv.CSVRecord> records = parser.getRecords();
                                                                             assertEquals(2, records.size());
                                                                             assertEquals("a", records.get(0).get(0));
                                                                             assertEquals("b", records.get(0).get(1));
                                                                             assertEquals("c", records.get(0).get(2));
                                                                             assertEquals("1", records.get(1).get(0));
                                                                             assertEquals("2", records.get(1).get(1));
                                                                             assertEquals("3", records.get(1).get(2));
                                                                             
                                                                             // Cleanup
                                                                             parser.close();
                                                                         }

}
