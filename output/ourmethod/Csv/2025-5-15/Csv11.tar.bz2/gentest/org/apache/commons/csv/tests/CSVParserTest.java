package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                            public void testInitializeHeader_WithNonEmptyFormatHeader_NoSkip() throws Exception {
                                                // Setup
                                                CSVFormat format = mock(CSVFormat.class);
                                                when(format.getHeader()).thenReturn(new String[]{"header1", "header2"});
                                                when(format.getSkipHeaderRecord()).thenReturn(false);
                                                when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                
                                                // Create parser with null reader since we're testing header initialization
                                                CSVParser parser = new CSVParser(null, format);
                                                
                                                // Test
                                                Map<String, Integer> result = parser.getHeaderMap();
                                                
                                                // Verify
                                                assertNotNull(result);
                                                assertEquals(2, result.size());
                                                assertEquals(Integer.valueOf(0), result.get("header1"));
                                                assertEquals(Integer.valueOf(1), result.get("header2"));
                                            }

 @Test
                                            public void testInitializeHeader_WithDuplicateHeaders_ThrowsException() throws Exception {
                                                // Setup
                                                CSVFormat format = mock(CSVFormat.class);
                                                when(format.getHeader()).thenReturn(new String[]{"dup", "dup"});
                                                when(format.getSkipHeaderRecord()).thenReturn(false);
                                                when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                
                                                // Expect exception
                                                ExpectedException thrown = ExpectedException.none();
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("The header contains a duplicate name: \"dup\" in [dup, dup]");
                                                
                                                // Create parser
                                                CSVParser parser = new CSVParser(new StringReader(""), format);
                                                
                                                // Test - should throw
                                                parser.getHeaderMap();
                                            }

 @Test
                                            public void testInitializeHeader_WithEmptyHeaders_WhenIgnoreEmptyHeaders() throws Exception {
                                                // Setup
                                                CSVFormat format = mock(CSVFormat.class);
                                                when(format.getHeader()).thenReturn(new String[]{"", "valid", null});
                                                when(format.getSkipHeaderRecord()).thenReturn(false);
                                                when(format.getIgnoreEmptyHeaders()).thenReturn(true);
                                                
                                                // Create parser
                                                CSVParser parser = new CSVParser(new StringReader(""), format);
                                                
                                                // Test
                                                Map<String, Integer> result = parser.getHeaderMap();
                                                
                                                // Verify
                                                assertNotNull(result);
                                                assertEquals(3, result.size()); // All are stored, but duplicates would be allowed for empty
                                                assertEquals(Integer.valueOf(0), result.get(""));
                                                assertEquals(Integer.valueOf(1), result.get("valid"));
                                                assertEquals(Integer.valueOf(2), result.get(null));
                                            }

 @Test
                                            public void testInitializeHeader_WithNullFormatHeader_ReturnsNull() throws Exception {
                                                // Setup
                                                CSVFormat format = mock(CSVFormat.class);
                                                when(format.getHeader()).thenReturn(null);
                                                
                                                // Create parser
                                                CSVParser parser = new CSVParser(null, format);
                                                
                                                // Test
                                                Map<String, Integer> result = parser.getHeaderMap();
                                                
                                                // Verify
                                                assertNull(result);
                                            }

 @Test
                                            public void testInitializeHeader_WithEmptyStringHeaders() throws Exception {
                                                // Setup
                                                CSVFormat format = mock(CSVFormat.class);
                                                when(format.getHeader()).thenReturn(new String[]{"", "  ", null});
                                                when(format.getSkipHeaderRecord()).thenReturn(false);
                                                when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                
                                                // Create parser with null reader since we're testing header initialization
                                                CSVParser parser = new CSVParser(new StringReader(""), format);
                                                
                                                // Test
                                                Map<String, Integer> result = parser.getHeaderMap();
                                                
                                                // Verify
                                                assertNotNull(result);
                                                assertEquals(3, result.size());
                                                assertEquals(Integer.valueOf(0), result.get(""));
                                                assertEquals(Integer.valueOf(1), result.get("  "));
                                                assertEquals(Integer.valueOf(2), result.get(null));
                                            }

 @Test
                                    public void testInitializeHeader_WithEmptyFormatHeader_ReadsFromFirstRecord() throws Exception {
                                        // Setup
                                        CSVFormat format = mock(CSVFormat.class);
                                        when(format.getHeader()).thenReturn(new String[0]);
                                        when(format.getSkipHeaderRecord()).thenReturn(false);
                                        when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                        
                                        // Create parser with test data
                                        CSVParser parser = new CSVParser(new StringReader("col1,col2\nval1,val2"), format);
                                        
                                        // Use reflection to set headerMap to null to force initialization
                                        try {
                                            Field headerMapField = CSVParser.class.getDeclaredField("headerMap");
                                            headerMapField.setAccessible(true);
                                            headerMapField.set(parser, null);
                                        } catch (Exception e) {
                                            throw new RuntimeException(e);
                                        }
                                        
                                        // Test
                                        Map<String, Integer> result = parser.getHeaderMap();
                                        
                                        // Verify
                                        assertNotNull(result);
                                        assertEquals(2, result.size());
                                        assertEquals(Integer.valueOf(0), result.get("col1"));
                                        assertEquals(Integer.valueOf(1), result.get("col2"));
                                    }

 @Test
                                    public void testInitializeHeader_WithNonEmptyFormatHeader_WithSkip() throws Exception {
                                        // Setup
                                        CSVFormat format = mock(CSVFormat.class);
                                        when(format.getHeader()).thenReturn(new String[]{"header1", "header2"});
                                        when(format.getSkipHeaderRecord()).thenReturn(true);
                                        when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                        
                                        // Create parser with empty input (which will make nextRecord() return null)
                                        Reader reader = new StringReader("");
                                        CSVParser parser = new CSVParser(reader, format);
                                        
                                        // Test
                                        Map<String, Integer> result = parser.getHeaderMap();
                                        
                                        // Verify
                                        assertNotNull(result);
                                        assertEquals(2, result.size());
                                    }

 @Test
                                    public void testInitializeHeader_WithEmptyFormatHeader_AndNoRecords_ReturnsNull() throws Exception {
                                        // Setup
                                        CSVFormat format = mock(CSVFormat.class);
                                        when(format.getHeader()).thenReturn(new String[0]);
                                        when(format.getSkipHeaderRecord()).thenReturn(false);
                                        
                                        // Create parser with no records using empty input
                                        CSVParser parser = new CSVParser(new StringReader(""), format);
                                        
                                        // Use reflection to access the lexer field and set it to null to simulate no records
                                        Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                        lexerField.setAccessible(true);
                                        lexerField.set(parser, null);
                                        
                                        // Test
                                        Map<String, Integer> result = parser.getHeaderMap();
                                        
                                        // Verify
                                        assertNull(result);
                                    }

 @Test
    public void testInitializeHeaderWithDuplicateEmptyHeadersWhenIgnored() throws Exception {
        // Setup
        CSVFormat format = mock(CSVFormat.class);
        when(format.getHeader()).thenReturn(new String[]{"", ""}); // Duplicate empty headers
        when(format.getSkipHeaderRecord()).thenReturn(false);
        when(format.getIgnoreEmptyHeaders()).thenReturn(true); // Empty headers should be ignored
        
        CSVParser parser = new CSVParser(new StringReader(""), format);
        
        // This should not throw exception in original, but mutant will throw
        Map<String, Integer> result = parser.getHeaderMap();
        
        // Verify
        assertNotNull(result);
        assertEquals(2, result.size()); // Both empty headers should be included
        assertEquals(Integer.valueOf(0), result.get(""));
        assertEquals(Integer.valueOf(1), result.get(""));
        
        // Additional verification that no exception was thrown
        // (The mutant would throw IllegalArgumentException here)
    }

 @Test
   public void testInitializeHeader_DetectsArrayIndexOutOfBoundsMutant() throws Exception {
       // Setup
       CSVFormat format = CSVFormat.DEFAULT.withHeader("col1", "col2");
       Reader reader = new StringReader(""); // Empty reader since we're using format headers
       CSVParser parser = new CSVParser(reader, format);
       
       // Test - should not throw exception with original code
       // If mutant exists (i <= length), this would throw ArrayIndexOutOfBoundsException
       Map<String, Integer> headerMap = parser.getHeaderMap();
       
       // Verify
       assertNotNull(headerMap);
       assertEquals(2, headerMap.size());
       assertEquals(Integer.valueOf(0), headerMap.get("col1"));
       assertEquals(Integer.valueOf(1), headerMap.get("col2"));
       
       // Additional verification that all headers were processed
       String[] expectedHeaders = {"col1", "col2"};
       for (String header : expectedHeaders) {
           assertTrue(headerMap.containsKey(header));
       }
   }

 @Test
  public void testInitializeHeader_DetectsMutatedHeaderIndexing() throws Exception {
      // Setup test data with multiple distinct headers
      String[] testHeaders = {"Header1", "Header2", "Header3"};
      
      // Mock CSVFormat behavior
      CSVFormat mockFormat = mock(CSVFormat.class);
      when(mockFormat.getHeader()).thenReturn(testHeaders);
      when(mockFormat.getSkipHeaderRecord()).thenReturn(false);
      when(mockFormat.getIgnoreEmptyHeaders()).thenReturn(false);
      
      // Create parser with mocked format (no need for real reader since we're testing header initialization)
      CSVParser parser = new CSVParser(new StringReader(""), mockFormat);
      
      // Use reflection to access private method for testing
      Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
      initializeHeader.setAccessible(true);
      
      // Execute the method
      @SuppressWarnings("unchecked")
      Map<String, Integer> headerMap = (Map<String, Integer>) initializeHeader.invoke(parser);
      
      // Verify each header maps to correct index
      assertEquals(3, headerMap.size());
      assertEquals(Integer.valueOf(0), headerMap.get("Header1"));
      assertEquals(Integer.valueOf(1), headerMap.get("Header2"));
      assertEquals(Integer.valueOf(2), headerMap.get("Header3"));
      
      // The mutant would fail these assertions because all headers would map to index 0
  }

 @Test
 public void testInitializeHeaderWithDuplicateEmptyHeaderWhenIgnored() throws Exception {
     // Setup
     CSVFormat format = mock(CSVFormat.class);
     when(format.getHeader()).thenReturn(new String[]{"", ""}); // duplicate empty headers
     when(format.getSkipHeaderRecord()).thenReturn(false);
     when(format.getIgnoreEmptyHeaders()).thenReturn(true);
     
     CSVParser parser = new CSVParser(new StringReader(""), format);
     
     // Test - should not throw exception with original code
     Map<String, Integer> result = parser.getHeaderMap();
     
     // Verify
     assertNotNull(result);
     assertEquals(0, result.size()); // empty headers should be ignored
 }

}
