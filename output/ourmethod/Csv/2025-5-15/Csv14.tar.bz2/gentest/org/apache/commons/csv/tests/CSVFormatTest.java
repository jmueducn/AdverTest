package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                public void testPrintAndQuote_AllMode() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuote.setAccessible(true);
                                                    printAndQuote.invoke(format, "test", "test", 0, 4, out, false);
                                                    
                                                    assertEquals("\"test\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_NonNumericMode_WithNumber() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    format.print(123, out, false);
                                                    assertEquals("123", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_NonNumericMode_WithString() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Get the private method via reflection
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    
                                                    // Invoke the method
                                                    printAndQuoteMethod.invoke(
                                                        format, 
                                                        "text",  // object
                                                        "text",  // value
                                                        0,      // offset
                                                        4,      // len
                                                        out,    // appendable
                                                        false   // newRecord
                                                    );
                                                    
                                                    assertEquals("\"text\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_NoneMode() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuote.setAccessible(true);
                                                    printAndQuote.invoke(format, "test", "test", 0, 4, out, false);
                                                    
                                                    assertEquals("test", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_EmptyStringNewRecord() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuote.setAccessible(true);
                                                    printAndQuote.invoke(format, "", "", 0, 0, out, true);
                                                    
                                                    assertEquals("\"\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_EmptyStringNotNewRecord() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuote.setAccessible(true);
                                                    printAndQuote.invoke(format, null, "", 0, 0, out, false);
                                                    
                                                    assertEquals("", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_ContainsDelimiter() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuote.setAccessible(true);
                                                    printAndQuote.invoke(format, "a,b", "a,b", 0, 3, out, false);
                                                    
                                                    assertEquals("\"a,b\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_ContainsQuote() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuote('"').withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Get the private method via reflection
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    
                                                    // Invoke the method
                                                    printAndQuoteMethod.invoke(
                                                        format, 
                                                        "a\"b",  // object
                                                        "a\"b",  // value
                                                        0,       // offset
                                                        3,       // len
                                                        out,     // appendable
                                                        false    // newRecord
                                                    );
                                                    
                                                    assertEquals("\"a\"\"b\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_ContainsLineBreak() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    
                                                    String value = "a\nb";
                                                    printAndQuoteMethod.invoke(format, value, value, 0, 3, out, false);
                                                    
                                                    assertEquals("\"a\nb\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_StartsWithSpecialChar() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Get the private method via reflection
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    
                                                    // Test with character less than 0x20
                                                    String testString = "\u0019test";
                                                    printAndQuoteMethod.invoke(format, testString, testString, 0, 5, out, true);
                                                    assertEquals("\"\u0019test\"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_MinimalMode_EndsWithSpecialChar() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Get the private method via reflection
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    
                                                    // Test with space at end (ASCII 32)
                                                    printAndQuoteMethod.invoke(
                                                        format, 
                                                        "test ",  // object
                                                        "test ",  // value
                                                        0,        // offset
                                                        5,        // len
                                                        out,      // appendable
                                                        false     // newRecord
                                                    );
                                                    
                                                    assertEquals("\"test \"", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_InvalidQuoteMode() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT;
                                                    // Use reflection to set an invalid QuoteMode since it's not possible normally
                                                    java.lang.reflect.Field field = format.getClass().getDeclaredField("quoteMode");
                                                    field.setAccessible(true);
                                                    field.set(format, null);
                                                    
                                                    thrown.expect(IllegalStateException.class);
                                                    thrown.expectMessage("Unexpected Quote value: null");
                                                    
                                                    StringWriter out = new StringWriter();
                                                    // Use reflection to access the private printAndQuote method
                                                    Method printAndQuoteMethod = format.getClass().getDeclaredMethod("printAndQuote", 
                                                        Object.class, CharSequence.class, int.class, int.class, Appendable.class, boolean.class);
                                                    printAndQuoteMethod.setAccessible(true);
                                                    printAndQuoteMethod.invoke(format, "test", "test", 0, 4, out, false);
                                                }

 @Test
                                                public void testPrintAndQuote_OffsetAndLength() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    printAndQuoteMethod.invoke(format, "xytestz", "xytestz", 2, 4, out, false);
                                                    
                                                    assertEquals("test", out.toString());
                                                }

 @Test
                                                public void testPrintAndQuote_QuoteDoubling() throws Exception {
                                                    CSVFormat format = CSVFormat.DEFAULT.withQuote('"').withQuoteMode(QuoteMode.MINIMAL);
                                                    StringWriter out = new StringWriter();
                                                    
                                                    // Use reflection to access private method
                                                    Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                        "printAndQuote", 
                                                        Object.class, 
                                                        CharSequence.class, 
                                                        int.class, 
                                                        int.class, 
                                                        Appendable.class, 
                                                        boolean.class
                                                    );
                                                    printAndQuoteMethod.setAccessible(true);
                                                    printAndQuoteMethod.invoke(
                                                        format, 
                                                        "\"test\"",  // object
                                                        "\"test\"",  // value
                                                        0,          // offset
                                                        6,          // len
                                                        out,        // appendable
                                                        false       // newRecord
                                                    );
                                                    
                                                    assertEquals("\"\"\"test\"\"\"", out.toString());
                                                }

 @Test
        public void testPrintAndQuoteMinimalModeWithExclamationMarkNewRecord() throws IOException {
            // Setup
            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
            StringBuilder out = new StringBuilder();
            String value = "!test"; // Starts with '!' (0x21)
            boolean newRecord = true;
            
            // Execute
            format.print(value, out, newRecord);
            
            // Verify - original should not quote, mutant would quote
            assertFalse("Value starting with '!' in new record should not be quoted", 
                       out.toString().startsWith("\"") && out.toString().endsWith("\""));
            
            // Additional verification of exact output
            assertEquals("Output should match input without quotes", value, out.toString());
        }

 @Test
       public void testPrintAndQuote_MinimalMode_NewRecordWithHyphen() throws IOException {
           // Setup
           CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
           StringBuilder out = new StringBuilder();
           String value = "-test"; // Starts with hyphen (0x2D)
           boolean newRecord = true;
           
           // Execute
           format.print(value, out, newRecord);
           
           // Verify - original should not quote, mutant would quote
           assertFalse("String starting with hyphen should not be quoted in MINIMAL mode", 
                      out.toString().startsWith("\"") && out.toString().endsWith("\""));
           
           // Additional verification for other characters in the same range
           value = "+test"; // 0x2B
           out = new StringBuilder();
           format.print(value, out, newRecord);
           assertFalse("String starting with '+' should not be quoted", 
                      out.toString().startsWith("\"") && out.toString().endsWith("\""));
           
           value = ",test"; // 0x2C
           out = new StringBuilder();
           format.print(value, out, newRecord);
           assertFalse("String starting with ',' should not be quoted", 
                      out.toString().startsWith("\"") && out.toString().endsWith("\""));
       }

 @Test
      public void testPrintAndQuoteWithTildeCharacter() throws IOException {
          // Setup
          CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
          StringBuilder out = new StringBuilder();
          String value = "~test"; // Starts with 0x7E character
          boolean newRecord = true;
          
          // Execute
          format.print(value, out, newRecord);
          
          // Verify
          // Original behavior: ~ shouldn't be quoted (0x7E is not > 0x7E)
          // Mutated behavior: ~ would be quoted (0x7E is >= 0x7E)
          assertFalse("Output should not start with quote character", 
                     out.toString().startsWith(String.valueOf(format.getQuoteCharacter())));
          
          // Additional verification that the tilde is present in output
          assertTrue("Output should contain the tilde character", 
                    out.toString().contains("~"));
      }

 @Test
     public void testPrintAndQuote_MinimalMode_WithDoubleQuoteChar_ShouldNotQuote() throws IOException {
         // Setup
         CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
         StringBuilder out = new StringBuilder();
         String value = "\""; // This is just the double quote character (0x22)
         boolean newRecord = true;
         
         // Create a spy to access the private method
         CSVFormat spyFormat = spy(format);
         doCallRealMethod().when(spyFormat).print(any(), any(), anyBoolean());
         
         // Execute
         spyFormat.print(value, out, newRecord);
         
         // Verify - should not be quoted in original, but will be in mutant
         assertFalse("Output should not be quoted for double quote char in minimal mode", 
                    out.toString().startsWith("\"") && out.toString().endsWith("\""));
         
         // Additional check for the exact expected output
         assertEquals("Output should match input for double quote char", 
                     value, out.toString());
     }

 @Test
    public void testPrintAndQuoteMinimalModeWithHyphenNewRecord() throws IOException {
        // Setup
        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        StringBuilder out = new StringBuilder();
        String value = "-test"; // Starts with hyphen (0x2D)
        boolean newRecord = true;
        
        // Execute
        format.print(value, out, newRecord);
        
        // Verify
        // Original would quote because hyphen (0x2D) matches c > 0x2B && c < 0x2D is false
        // Mutant would not quote because hyphen (0x2D) matches c > 0x2B && c <= 0x2D is true
        assertTrue("String starting with hyphen in new record should be quoted", 
                   out.toString().startsWith("\"") && out.toString().endsWith("\""));
        
        // Additional check for exact output
        assertEquals("\"-test\"", out.toString());
    }

 @Test
   public void testPrintAndQuote_MinimalMode_DetectsMutant() throws IOException {
       // Setup
       CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
       StringBuilder out = new StringBuilder();
       String value = ","; // 0x2C character which should be quoted in original but not in mutant
       
       // Execute
       format.print(value, out, true); // true for newRecord
       
       // Verify
       // Original would quote this (output: ",")
       // Mutant would not quote this (output: ,)
       assertTrue("Output should be quoted for 0x2C character in minimal mode", 
                  out.toString().startsWith("\"") && out.toString().endsWith("\""));
       
       // Additional verification for exact output
       assertEquals("\",\"", out.toString());
   }

 @Test
  public void testPrintAndQuote_MinimalMode_ExclamationMark_NewRecord() throws IOException {
      // Setup
      CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
      StringBuilder out = new StringBuilder();
      String value = "!test"; // Starts with '!' (0x21)
      boolean newRecord = true;
      
      // Execute
      format.print(value, out, newRecord);
      
      // Verify - should not be quoted since '!' is valid per RFC4180
      assertEquals("!test", out.toString());
      
      // Additional verification that no quote characters were added
      assertFalse(out.toString().contains("\""));
  }

 @Test
 public void testPrintAndQuote_MinimalMode_DetectsMutant1() throws IOException {
     // Setup
     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
     StringBuilder out = new StringBuilder();
     String value = "$test"; // '$' is 0x24 which is between 0x23 and 0x2B
     boolean newRecord = true;
     
     // Execute
     format.print(value, out, newRecord);
     
     // Verify - mutated code would add quotes, original wouldn't
     // The original code would output "$test" while mutated would output "\"$test\""
     assertFalse("Output should not be quoted for character $ in original code", 
                out.toString().startsWith("\"") && out.toString().endsWith("\""));
     
     // Additional verification that the output matches exactly what we expect
     assertEquals("$test", out.toString());
 }

}
