package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
 
public class ExtendedBufferedReaderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                     public void testRead_ZeroLength() throws Exception {
                                                                                                                                                                                         Reader mockReader = mock(Reader.class);
                                                                                                                                                                                         char[] testBuffer = new char[10]; // Define test buffer
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access the constructor
                                                                                                                                                                                         Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                                         Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                                                         Object reader = constructor.newInstance(mockReader);
                                                                                                                                                                                         
                                                                                                                                                                                         Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                                         int result = (int) readMethod.invoke(reader, testBuffer, 0, 0);
                                                                                                                                                                                         
                                                                                                                                                                                         assertEquals(0, result);
                                                                                                                                                                                         verify(mockReader, never()).read(any(char[].class), anyInt(), anyInt());
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                     public void testRead_MixedLineEndings() throws Exception {
                                                                                                                                                                                         String input = "line1\nline2\rline3\r\nline4";
                                                                                                                                                                                         java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                                         Object reader = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                                                                                                                                                                                             .getConstructor(java.io.Reader.class)
                                                                                                                                                                                                             .newInstance(stringReader);
                                                                                                                                                                                         
                                                                                                                                                                                         char[] testBuffer = new char[input.length()];
                                                                                                                                                                                         int result = (int) reader.getClass()
                                                                                                                                                                                                                 .getMethod("read", char[].class, int.class, int.class)
                                                                                                                                                                                                                 .invoke(reader, testBuffer, Integer.valueOf(0), Integer.valueOf(input.length()));
                                                                                                                                                                                         
                                                                                                                                                                                         assertEquals(input.length(), result);
                                                                                                                                                                                         
                                                                                                                                                                                         int lineNumber = (int) reader.getClass()
                                                                                                                                                                                                                     .getMethod("getLineNumber")
                                                                                                                                                                                                                     .invoke(reader);
                                                                                                                                                                                         assertEquals(3, lineNumber);
                                                                                                                                                                                         
                                                                                                                                                                                         char lastChar = (char) reader.getClass()
                                                                                                                                                                                                                     .getDeclaredField("lastChar")
                                                                                                                                                                                                                     .get(reader);
                                                                                                                                                                                         assertEquals('4', lastChar);
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                 public void testRead_NormalCharacter() throws IOException {
                                                                                                                                                                                     // Create mock Reader
                                                                                                                                                                                     Reader mockReader = mock(Reader.class);
                                                                                                                                                                                     when(mockReader.read()).thenReturn((int)'a');
                                                                                                                                                                                     
                                                                                                                                                                                     // Create ExtendedBufferedReader with mock Reader using reflection
                                                                                                                                                                                     Object bufferedReader;
                                                                                                                                                                                     try {
                                                                                                                                                                                         Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                                         Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                                                         bufferedReader = constructor.newInstance(mockReader);
                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                         fail("Failed to create ExtendedBufferedReader instance: " + e.getMessage());
                                                                                                                                                                                         return;
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Test read operation using reflection
                                                                                                                                                                                     try {
                                                                                                                                                                                         Method readMethod = bufferedReader.getClass().getDeclaredMethod("read");
                                                                                                                                                                                         int result = (Integer) readMethod.invoke(bufferedReader);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify results
                                                                                                                                                                                         assertEquals('a', result);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify lastChar field
                                                                                                                                                                                         Field lastCharField = bufferedReader.getClass().getDeclaredField("lastChar");
                                                                                                                                                                                         lastCharField.setAccessible(true);
                                                                                                                                                                                         assertEquals('a', lastCharField.get(bufferedReader));
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify lineCounter field
                                                                                                                                                                                         Field lineCounterField = bufferedReader.getClass().getDeclaredField("lineCounter");
                                                                                                                                                                                         lineCounterField.setAccessible(true);
                                                                                                                                                                                         assertEquals(0, lineCounterField.get(bufferedReader));
                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                         fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                 public void testRead_NewlineAtStart() throws Exception {
                                                                                                                                                                                     String input = "\nline";
                                                                                                                                                                                     // Create test buffer
                                                                                                                                                                                     char[] testBuffer = new char[input.length()];
                                                                                                                                                                                     
                                                                                                                                                                                     // Get ExtendedBufferedReader class via reflection
                                                                                                                                                                                     Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                                     Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                                                     java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                                     Object reader = constructor.newInstance(stringReader);
                                                                                                                                                                                     
                                                                                                                                                                                     // Call read method via reflection
                                                                                                                                                                                     Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                                     readMethod.setAccessible(true);
                                                                                                                                                                                     int result = (int) readMethod.invoke(reader, testBuffer, 0, input.length());
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify results
                                                                                                                                                                                     assertEquals(input.length(), result);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify line number
                                                                                                                                                                                     Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                                                                                                                     getLineNumberMethod.setAccessible(true);
                                                                                                                                                                                     assertEquals(1, getLineNumberMethod.invoke(reader));
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify lastChar
                                                                                                                                                                                     Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                                                     lastCharField.setAccessible(true);
                                                                                                                                                                                     assertEquals('e', lastCharField.get(reader));
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                             public void testRead_NewLineAfterNonCarriageReturn() throws Exception {
                                                                                                                                                                                 // Setup mock reader
                                                                                                                                                                                 Reader mockReader = mock(Reader.class);
                                                                                                                                                                                 when(mockReader.read()).thenReturn((int)'a', (int)'\n');
                                                                                                                                                                                 
                                                                                                                                                                                 // Create buffered reader with mock using reflection
                                                                                                                                                                                 Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                                 Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                                                 Object bufferedReader = constructor.newInstance(mockReader);
                                                                                                                                                                                 
                                                                                                                                                                                 // Perform reads using reflection
                                                                                                                                                                                 Method readMethod = clazz.getDeclaredMethod("read");
                                                                                                                                                                                 readMethod.invoke(bufferedReader); // read 'a'
                                                                                                                                                                                 int result = (int) readMethod.invoke(bufferedReader); // read '\n'
                                                                                                                                                                                 
                                                                                                                                                                                 // Verify results
                                                                                                                                                                                 assertEquals('\n', result);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to verify private fields
                                                                                                                                                                                 Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                                                 lastCharField.setAccessible(true);
                                                                                                                                                                                 assertEquals('\n', lastCharField.get(bufferedReader));
                                                                                                                                                                                 
                                                                                                                                                                                 Field lineCounterField = clazz.getDeclaredField("lineCounter");
                                                                                                                                                                                 lineCounterField.setAccessible(true);
                                                                                                                                                                                 assertEquals(1, lineCounterField.get(bufferedReader));
                                                                                                                                                                             }

    @Test
                                                                                                                                                                             public void testRead_PartialReads() throws Exception {
                                                                                                                                                                                 String input = "a\nb\r\nc";
                                                                                                                                                                                 char[] testBuffer = new char[10];
                                                                                                                                                                                 
                                                                                                                                                                                 // Create reader instance using reflection since class is not public
                                                                                                                                                                                 Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                                 Constructor<?> constructor = clazz.getConstructor(java.io.Reader.class);
                                                                                                                                                                                 java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                                 Object reader = constructor.newInstance(stringReader);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to access private lastChar field
                                                                                                                                                                                 Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                                                 lastCharField.setAccessible(true);
                                                                                                                                                                                 
                                                                                                                                                                                 // First read
                                                                                                                                                                                 Method readMethod = clazz.getMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                                 int result1 = (int) readMethod.invoke(reader, testBuffer, 0, 2); // Reads 'a' and '\n'
                                                                                                                                                                                 assertEquals(2, result1);
                                                                                                                                                                                 Method getLineNumberMethod = clazz.getMethod("getLineNumber");
                                                                                                                                                                                 assertEquals(1, getLineNumberMethod.invoke(reader));
                                                                                                                                                                                 assertEquals('\n', lastCharField.get(reader));
                                                                                                                                                                                 
                                                                                                                                                                                 // Second read
                                                                                                                                                                                 int result2 = (int) readMethod.invoke(reader, testBuffer, 2, 3); // Reads 'b', '\r', '\n'
                                                                                                                                                                                 assertEquals(3, result2);
                                                                                                                                                                                 assertEquals(2, getLineNumberMethod.invoke(reader));
                                                                                                                                                                                 assertEquals('\n', lastCharField.get(reader));
                                                                                                                                                                                 
                                                                                                                                                                                 // Third read
                                                                                                                                                                                 int result3 = (int) readMethod.invoke(reader, testBuffer, 5, 1); // Reads 'c'
                                                                                                                                                                                 assertEquals(1, result3);
                                                                                                                                                                                 assertEquals(2, getLineNumberMethod.invoke(reader)); // No new line
                                                                                                                                                                                 assertEquals('c', lastCharField.get(reader));
                                                                                                                                                                             }

    @Test
                                                                                                                                                                         public void testRead_EndOfStream() throws Exception {
                                                                                                                                                                             // Create mock reader
                                                                                                                                                                             Reader mockReader = mock(Reader.class);
                                                                                                                                                                             when(mockReader.read()).thenReturn(-1);  // -1 is standard END_OF_STREAM
                                                                                                                                                                             
                                                                                                                                                                             // Get ExtendedBufferedReader constructor via reflection
                                                                                                                                                                             Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                             Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                                             Object bufferedReader = constructor.newInstance(mockReader);
                                                                                                                                                                             
                                                                                                                                                                             // Test read() at end of stream
                                                                                                                                                                             Method readMethod = clazz.getDeclaredMethod("read");
                                                                                                                                                                             int result = (int) readMethod.invoke(bufferedReader);
                                                                                                                                                                             
                                                                                                                                                                             // Verify results
                                                                                                                                                                             assertEquals(-1, result);
                                                                                                                                                                             
                                                                                                                                                                             // Verify private fields using reflection
                                                                                                                                                                             Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                                             lastCharField.setAccessible(true);
                                                                                                                                                                             assertEquals(-1, lastCharField.get(bufferedReader));
                                                                                                                                                                             
                                                                                                                                                                             Field lineCounterField = clazz.getDeclaredField("lineCounter");
                                                                                                                                                                             lineCounterField.setAccessible(true);
                                                                                                                                                                             assertEquals(0, lineCounterField.get(bufferedReader));
                                                                                                                                                                         }

    @Test
                                                                                                                                                                         public void testRead_EndOfStream1() throws Exception {
                                                                                                                                                                             String input = "";
                                                                                                                                                                             char[] testBuffer = new char[10];
                                                                                                                                                                             java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                             Object reader = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                                                                                                                                                                                .getConstructor(java.io.Reader.class)
                                                                                                                                                                                                .newInstance(stringReader);
                                                                                                                                                                             
                                                                                                                                                                             Method readMethod = reader.getClass().getMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                             int result = (int) readMethod.invoke(reader, testBuffer, 0, 10);
                                                                                                                                                                             
                                                                                                                                                                             assertEquals(-1, result);
                                                                                                                                                                             
                                                                                                                                                                             Field lastCharField = reader.getClass().getDeclaredField("lastChar");
                                                                                                                                                                             lastCharField.setAccessible(true);
                                                                                                                                                                             int lastChar = lastCharField.getInt(reader);
                                                                                                                                                                             
                                                                                                                                                                             Field endOfStreamField = reader.getClass().getDeclaredField("END_OF_STREAM");
                                                                                                                                                                             endOfStreamField.setAccessible(true);
                                                                                                                                                                             int END_OF_STREAM = endOfStreamField.getInt(null);
                                                                                                                                                                             
                                                                                                                                                                             assertEquals(END_OF_STREAM, lastChar);
                                                                                                                                                                             
                                                                                                                                                                             Method getLineNumberMethod = reader.getClass().getMethod("getLineNumber");
                                                                                                                                                                             int lineNumber = (int) getLineNumberMethod.invoke(reader);
                                                                                                                                                                             assertEquals(0, lineNumber);
                                                                                                                                                                         }

    @Test
                                                                                                                                                                 public void testRead_SingleLineWithNewline() throws Exception {
                                                                                                                                                                     String input = "line1\nline2";
                                                                                                                                                                     java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to create instance since class is package-private
                                                                                                                                                                     Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                     java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                                     Object reader = constructor.newInstance(stringReader);
                                                                                                                                                                     
                                                                                                                                                                     char[] testBuffer = new char[input.length()];
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to invoke read method
                                                                                                                                                                     java.lang.reflect.Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                     int result = (int) readMethod.invoke(reader, testBuffer, 0, input.length());
                                                                                                                                                                     
                                                                                                                                                                     assertEquals(input.length(), result);
                                                                                                                                                                     
                                                                                                                                                                     // Verify line number
                                                                                                                                                                     java.lang.reflect.Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                                                                                                     int lineNumber = (int) getLineNumberMethod.invoke(reader);
                                                                                                                                                                     assertEquals(1, lineNumber);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to access private lastChar field
                                                                                                                                                                     java.lang.reflect.Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                                     lastCharField.setAccessible(true);
                                                                                                                                                                     char lastChar = (char) lastCharField.get(reader);
                                                                                                                                                                     assertEquals('\n', lastChar);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testRead_OnlyCarriageReturn() throws Exception {
                                                                                                                                                                     // Arrange
                                                                                                                                                                     String input = "line1\\rline2";
                                                                                                                                                                     char[] testBuffer = new char[input.length()];
                                                                                                                                                                     
                                                                                                                                                                     // Need to use reflection to access the non-public class
                                                                                                                                                                     Class<?> readerClass = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                     Constructor<?> constructor = readerClass.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                                     java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                     java.io.Reader reader = (java.io.Reader) constructor.newInstance(stringReader);
                                                                                                                                                                     
                                                                                                                                                                     // Act
                                                                                                                                                                     Method readMethod = readerClass.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                     readMethod.setAccessible(true);
                                                                                                                                                                     int result = (int) readMethod.invoke(reader, testBuffer, 0, input.length());
                                                                                                                                                                     
                                                                                                                                                                     // Assert
                                                                                                                                                                     assertEquals(input.length(), result);
                                                                                                                                                                     
                                                                                                                                                                     // Verify line number
                                                                                                                                                                     Method getLineNumberMethod = readerClass.getDeclaredMethod("getLineNumber");
                                                                                                                                                                     getLineNumberMethod.setAccessible(true);
                                                                                                                                                                     int lineNumber = (int) getLineNumberMethod.invoke(reader);
                                                                                                                                                                     assertEquals(1, lineNumber);
                                                                                                                                                                     
                                                                                                                                                                     // Verify last character
                                                                                                                                                                     Field lastCharField = readerClass.getDeclaredField("lastChar");
                                                                                                                                                                     lastCharField.setAccessible(true);
                                                                                                                                                                     char lastChar = (char) lastCharField.get(reader);
                                                                                                                                                                     assertEquals('\r', lastChar);
                                                                                                                                                                 }

    @Test
                                                                                                                                                             public void testRead_MultipleLinesWithCRLF() throws Exception {
                                                                                                                                                                 String input = "line1\\r\\nline2\\r\\nline3";
                                                                                                                                                                 char[] testBuffer = new char[input.length()];
                                                                                                                                                                 java.io.Reader stringReader = new java.io.StringReader(input);
                                                                                                                                                                 
                                                                                                                                                                 try {
                                                                                                                                                                     // Use the full package path for the class
                                                                                                                                                                     Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                                     Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                                     Object reader = constructor.newInstance(stringReader);
                                                                                                                                                                     
                                                                                                                                                                     Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                                     int result = (int) readMethod.invoke(reader, testBuffer, 0, input.length());
                                                                                                                                                                     
                                                                                                                                                                     assertEquals(input.length(), result);
                                                                                                                                                                     
                                                                                                                                                                     Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                                                                                                     int lineNumber = (int) getLineNumberMethod.invoke(reader);
                                                                                                                                                                     assertEquals(3, lineNumber); // After reading 2 CRLFs, we should be on line 3
                                                                                                                                                                     
                                                                                                                                                                     try {
                                                                                                                                                                         Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                                         lastCharField.setAccessible(true);
                                                                                                                                                                         char lastChar = lastCharField.getChar(reader);
                                                                                                                                                                         assertEquals('\n', lastChar);
                                                                                                                                                                     } catch (NoSuchFieldException e) {
                                                                                                                                                                         // Field might not exist in all versions
                                                                                                                                                                         fail("lastChar field not found in ExtendedBufferedReader");
                                                                                                                                                                     }
                                                                                                                                                                 } catch (ClassNotFoundException e) {
                                                                                                                                                                     fail("ExtendedBufferedReader class not found");
                                                                                                                                                                 }
                                                                                                                                                             }

    @Test
                                                                                                                                                         public void testRead_MultipleLineEndings() throws Exception {
                                                                                                                                                             // Setup mock reader
                                                                                                                                                             Reader mockReader = mock(Reader.class);
                                                                                                                                                             when(mockReader.read())
                                                                                                                                                                 .thenReturn((int)'\r')
                                                                                                                                                                 .thenReturn((int)'\n')
                                                                                                                                                                 .thenReturn((int)'\r')
                                                                                                                                                                 .thenReturn((int)'\n')
                                                                                                                                                                 .thenReturn((int)'\n')
                                                                                                                                                                 .thenReturn(-1); // Add EOF to prevent infinite reads
                                                                                                                                                             
                                                                                                                                                             // Get ExtendedBufferedReader class and constructor using reflection
                                                                                                                                                             Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                             Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                             Object bufferedReader = constructor.newInstance(mockReader);
                                                                                                                                                             
                                                                                                                                                             // Read characters and test behavior
                                                                                                                                                             Method readMethod = clazz.getDeclaredMethod("read");
                                                                                                                                                             readMethod.invoke(bufferedReader); // \r
                                                                                                                                                             readMethod.invoke(bufferedReader); // \n
                                                                                                                                                             readMethod.invoke(bufferedReader); // \r
                                                                                                                                                             readMethod.invoke(bufferedReader); // \n
                                                                                                                                                             int result = (int) readMethod.invoke(bufferedReader); // \n
                                                                                                                                                             
                                                                                                                                                             // Use reflection to access private fields
                                                                                                                                                             Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                             lastCharField.setAccessible(true);
                                                                                                                                                             Field lineCounterField = clazz.getDeclaredField("lineCounter");
                                                                                                                                                             lineCounterField.setAccessible(true);
                                                                                                                                                             
                                                                                                                                                             // Verify results
                                                                                                                                                             assertEquals('\n', (char)result);
                                                                                                                                                             assertEquals('\n', (char)lastCharField.get(bufferedReader));
                                                                                                                                                             assertEquals(3, lineCounterField.get(bufferedReader));
                                                                                                                                                         }

    @Test
                                                                                                                                                     public void testRead_OffsetHandling() throws Exception {
                                                                                                                                                         String input = "prefix\nline";
                                                                                                                                                         char[] testBuffer = new char[10];
                                                                                                                                                         
                                                                                                                                                         // Create ExtendedBufferedReader instance using reflection
                                                                                                                                                         try {
                                                                                                                                                             Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                             Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                             java.io.Reader reader = new java.io.StringReader(input);
                                                                                                                                                             Object extendedReader = constructor.newInstance(reader);
                                                                                                                                                             
                                                                                                                                                             // Read with offset 6 to skip "prefix"
                                                                                                                                                             Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                             readMethod.setAccessible(true);
                                                                                                                                                             int result = (int) readMethod.invoke(extendedReader, testBuffer, 6, 4); // Reads '\n' and "lin"
                                                                                                                                                             
                                                                                                                                                             assertEquals(4, result);
                                                                                                                                                             
                                                                                                                                                             // Get line number
                                                                                                                                                             Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                                                                                             getLineNumberMethod.setAccessible(true);
                                                                                                                                                             int lineNumber = (int) getLineNumberMethod.invoke(extendedReader);
                                                                                                                                                             assertEquals(1, lineNumber);
                                                                                                                                                             
                                                                                                                                                             // Access private lastChar field using reflection
                                                                                                                                                             Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                             lastCharField.setAccessible(true);
                                                                                                                                                             char lastChar = (char) lastCharField.get(extendedReader);
                                                                                                                                                             assertEquals('n', lastChar);
                                                                                                                                                             
                                                                                                                                                             assertEquals('\n', testBuffer[6]);
                                                                                                                                                             assertEquals('l', testBuffer[7]);
                                                                                                                                                             assertEquals('i', testBuffer[8]);
                                                                                                                                                             assertEquals('n', testBuffer[9]);
                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                             fail("Reflection failed: " + e.getMessage());
                                                                                                                                                         }
                                                                                                                                                     }

    @Test
                                                                                                                                             public void testRead_CarriageReturnAtEnd() throws Exception {
                                                                                                                                                 String input = "line\\r";
                                                                                                                                                 // Create reader
                                                                                                                                                 java.io.StringReader stringReader = new java.io.StringReader(input);
                                                                                                                                                 // Access ExtendedBufferedReader through reflection
                                                                                                                                                 Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                                 java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                                                 constructor.setAccessible(true);
                                                                                                                                                 Object reader = constructor.newInstance(stringReader);
                                                                                                                                                 
                                                                                                                                                 char[] testBuffer = new char[input.length()];
                                                                                                                                                 
                                                                                                                                                 // Get read method
                                                                                                                                                 java.lang.reflect.Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                                                                 readMethod.setAccessible(true);
                                                                                                                                                 int result = (int) readMethod.invoke(reader, testBuffer, 0, input.length());
                                                                                                                                                 
                                                                                                                                                 assertEquals(input.length(), result);
                                                                                                                                                 
                                                                                                                                                 // Get line number
                                                                                                                                                 java.lang.reflect.Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                                                                                 getLineNumberMethod.setAccessible(true);
                                                                                                                                                 int lineNumber = (int) getLineNumberMethod.invoke(reader);
                                                                                                                                                 assertEquals(1, lineNumber);
                                                                                                                                                 
                                                                                                                                                 // Access private lastChar field using reflection
                                                                                                                                                 java.lang.reflect.Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                                 lastCharField.setAccessible(true);
                                                                                                                                                 char lastChar = (char) lastCharField.get(reader);
                                                                                                                                                 assertEquals('\r', lastChar);
                                                                                                                                             }

    @Test
                                                                                                                                         public void testRead_CarriageReturn() throws IOException, NoSuchFieldException, IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException, ClassNotFoundException {
                                                                                                                                             // Create mock Reader
                                                                                                                                             Reader mockReader = mock(Reader.class);
                                                                                                                                             when(mockReader.read()).thenReturn((int)'\r');
                                                                                                                                             
                                                                                                                                             // Get ExtendedBufferedReader class and constructor using reflection
                                                                                                                                             Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                                             Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                             Object bufferedReader = constructor.newInstance(mockReader);
                                                                                                                                             
                                                                                                                                             // Test read operation
                                                                                                                                             Method readMethod = clazz.getDeclaredMethod("read");
                                                                                                                                             int result = (int) readMethod.invoke(bufferedReader);
                                                                                                                                             assertEquals('\r', result);
                                                                                                                                             
                                                                                                                                             // Access private field lastChar using reflection
                                                                                                                                             Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                                                             lastCharField.setAccessible(true);
                                                                                                                                             assertEquals('\r', lastCharField.get(bufferedReader));
                                                                                                                                             
                                                                                                                                             // Access private field lineCounter using reflection
                                                                                                                                             Field lineCounterField = clazz.getDeclaredField("lineCounter");
                                                                                                                                             lineCounterField.setAccessible(true);
                                                                                                                                             assertEquals(1, lineCounterField.get(bufferedReader));
                                                                                                                                         }

    @Test
                                                                                                             public void testRead_IOException() throws Exception {
                                                                                                                 // Setup
                                                                                                                 // Create ExtendedBufferedReader instance using reflection
                                                                                                                 Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                                 java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                                 constructor.setAccessible(true);
                                                                                                                 java.lang.reflect.Method readMethod = clazz.getDeclaredMethod("read");
                                                                                                                 readMethod.setAccessible(true);
                                                                                                                 
                                                                                                                 // Expectations
                                                                                                                 
                                                                                                                 // Exception verification
                                                                                                         {
                                                                                                                     org.junit.Assert.fail("Expected IOException to be thrown");
                                                                                                         }{
                                                                                                                 }
                                                                                                             }

    @Test
                                                                                                        public void testRead_ShouldReturnActualReadLength_NotZero() throws Exception {
                                                                                                            // Setup
                                                                                                            Reader mockReader = mock(Reader.class);
                                                                                                            
                                                                                                            // Use reflection to access non-public ExtendedBufferedReader
                                                                                                            Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                                                                                                .getDeclaredConstructor(Reader.class);
                                                                                                            constructor.setAccessible(true);
                                                                                                            Object reader = constructor.newInstance(mockReader);
                                                                                                            Method readMethod = reader.getClass().getMethod("read", char[].class, int.class, int.class);
                                                                                                            Method getLineNumberMethod = reader.getClass().getMethod("getLineNumber");
                                                                                                            Field lastCharField = reader.getClass().getDeclaredField("lastChar");
                                                                                                            lastCharField.setAccessible(true);
                                                                                                        
                                                                                                            // Mock data with line endings to test counting
                                                                                                            char[] testData = {'a', '\n', 'b', '\r', 'c'};
                                                                                                            when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                                                                                                                .thenAnswer(invocation -> {
                                                                                                                    char[] buf = (char[]) invocation.getArguments()[0];
                                                                                                                    int offset = (int) invocation.getArguments()[1];
                                                                                                                    int length = (int) invocation.getArguments()[2];
                                                                                                                    System.arraycopy(testData, 0, buf, offset, Math.min(testData.length, length));
                                                                                                                    return testData.length;
                                                                                                                });
                                                                                                            
                                                                                                            // Test
                                                                                                            char[] buffer = new char[10];
                                                                                                            int result = (int) readMethod.invoke(reader, buffer, 0, 10);
                                                                                                            
                                                                                                            // Verify
                                                                                                            assertEquals("Should return actual read length", testData.length, result);
                                                                                                            assertEquals("Should count line endings", 2, getLineNumberMethod.invoke(reader));
                                                                                                            assertEquals("Last char should be updated", 'c', lastCharField.get(reader));
                                                                                                        }

    @Test
                                                                                                    public void testReadDetectsMutant() throws Exception {
                                                                                                        // Setup test data - create a reader with known content
                                                                                                        String testData = "a\nb\r\nc";
                                                                                                        java.io.Reader reader = new java.io.StringReader(testData);
                                                                                                        
                                                                                                        // Use reflection to access non-public class
                                                                                                        Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                        Constructor<?> constructor = clazz.getConstructor(java.io.Reader.class);
                                                                                                        Object bufferedReader = constructor.newInstance(reader);
                                                                                                        
                                                                                                        // Test first character (should be 'a')
                                                                                                        Method readMethod = clazz.getMethod("read");
                                                                                                        int firstChar = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals('a', firstChar); // Mutant would return 0 here
                                                                                                        
                                                                                                        Method getLineNumberMethod = clazz.getMethod("getLineNumber");
                                                                                                        int lineNumber = (int) getLineNumberMethod.invoke(bufferedReader);
                                                                                                        assertEquals(0, lineNumber); // No newline yet
                                                                                                        
                                                                                                        // Test newline character (should be '\n' and increment counter)
                                                                                                        int newlineChar = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals('\n', newlineChar); // Mutant would return 0 here
                                                                                                        lineNumber = (int) getLineNumberMethod.invoke(bufferedReader);
                                                                                                        assertEquals(1, lineNumber); // Mutant would still be 0
                                                                                                        
                                                                                                        // Test next character after newline (should be 'b')
                                                                                                        int secondChar = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals('b', secondChar); // Mutant would return 0 here
                                                                                                        
                                                                                                        // Test Windows-style newline (should be '\r' then '\n')
                                                                                                        int crChar = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals('\r', crChar); // Mutant would return 0 here
                                                                                                        int lfChar = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals('\n', lfChar); // Mutant would return 0 here
                                                                                                        lineNumber = (int) getLineNumberMethod.invoke(bufferedReader);
                                                                                                        assertEquals(2, lineNumber); // Mutant would still be 0
                                                                                                        
                                                                                                        // Test final character (should be 'c')
                                                                                                        int lastChar = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals('c', lastChar); // Mutant would return 0 here
                                                                                                        
                                                                                                        // Test EOF (should be -1)
                                                                                                        int eof = (int) readMethod.invoke(bufferedReader);
                                                                                                        assertEquals(-1, eof); // Mutant would return 0 here
                                                                                                    }

    @Test
                                                                                               public void testReadDetectsStreamReadingMutation() throws Exception {
                                                                                                   // Arrange
                                                                                                   Reader mockReader = mock(Reader.class);
                                                                                                   when(mockReader.read()).thenReturn((int)'a', (int)'\n', (int)'b', (int)'\r', -1);
                                                                                                   
                                                                                                   // Use reflection to create ExtendedBufferedReader instance
                                                                                                   Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                   Constructor<?> constructor = clazz.getConstructor(Reader.class);
                                                                                                   Object reader = constructor.newInstance(mockReader);
                                                                                                   
                                                                                                   // Act & Assert - First read should return 'a' and not increment line counter
                                                                                                   Method readMethod = clazz.getMethod("read");
                                                                                                   assertEquals('a', readMethod.invoke(reader));
                                                                                                   Method getLineNumberMethod = clazz.getMethod("getLineNumber");
                                                                                                   assertEquals(0, getLineNumberMethod.invoke(reader));
                                                                                                   
                                                                                                   // Second read should return '\n' and increment line counter
                                                                                                   assertEquals('\n', readMethod.invoke(reader));
                                                                                                   assertEquals(1, getLineNumberMethod.invoke(reader));
                                                                                                   
                                                                                                   // Third read should return 'b'
                                                                                                   assertEquals('b', readMethod.invoke(reader));
                                                                                                   assertEquals(1, getLineNumberMethod.invoke(reader));
                                                                                                   
                                                                                                   // Fourth read should return '\r' and increment line counter
                                                                                                   assertEquals('\r', readMethod.invoke(reader));
                                                                                                   assertEquals(2, getLineNumberMethod.invoke(reader));
                                                                                                   
                                                                                                   // Fifth read should return -1 (END_OF_STREAM)
                                                                                                   assertEquals(-1, readMethod.invoke(reader));
                                                                                                   assertEquals(2, getLineNumberMethod.invoke(reader));
                                                                                                   
                                                                                                   // Verify mock interactions to ensure super.read() was called
                                                                                                   verify(mockReader, times(5)).read();
                                                                                               }

    @Test
                                                                                               public void testReadDoesNotAlwaysReturnMinusOne() throws Exception {
                                                                                                   // Setup test data with line breaks
                                                                                                   char[] testData = "Line1\nLine2\rLine3".toCharArray();
                                                                                                   java.io.Reader reader = new java.io.CharArrayReader(testData);
                                                                                                   
                                                                                                   // Use reflection to access non-public constructor
                                                                                                   Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                                   java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                                                                                   constructor.setAccessible(true);
                                                                                                   Object bufferedReader = constructor.newInstance(reader);
                                                                                                   
                                                                                                   // Create buffer to read into
                                                                                                   char[] buf = new char[100];
                                                                                                   
                                                                                                   // First read - should read some characters
                                                                                                   java.lang.reflect.Method readMethod = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                                                   readMethod.setAccessible(true);
                                                                                                   int len = (int) readMethod.invoke(bufferedReader, buf, 0, 100);
                                                                                                   
                                                                                                   // Verify not -1 (would indicate mutation)
                                                                                                   assertNotEquals("Method should not always return -1", -1, len);
                                                                                                   
                                                                                                   // Verify line counting worked
                                                                                                   java.lang.reflect.Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                                   getLineNumberMethod.setAccessible(true);
                                                                                                   int lineNumber = (int) getLineNumberMethod.invoke(bufferedReader);
                                                                                                   assertTrue("Line counter should increment", lineNumber > 0);
                                                                                                   
                                                                                                   // Verify lastChar is set to last read character
                                                                                                   java.lang.reflect.Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                                                   lastCharField.setAccessible(true);
                                                                                                   int lastChar = (int) lastCharField.get(bufferedReader);
                                                                                                   int END_OF_STREAM = (int) clazz.getDeclaredField("END_OF_STREAM").get(null);
                                                                                                   assertNotEquals("lastChar should not be END_OF_STREAM", END_OF_STREAM, lastChar);
                                                                                                   
                                                                                                   // Read until end of stream
                                                                                                   while (len != -1) {
                                                                                                       len = (int) readMethod.invoke(bufferedReader, buf, 0, 100);
                                                                                                   }
                                                                                                   
                                                                                                   // Now verify end of stream behavior
                                                                                                   lastChar = (int) lastCharField.get(bufferedReader);
                                                                                                   assertEquals("lastChar should be END_OF_STREAM at end", END_OF_STREAM, lastChar);
                                                                                               }

    @Test
                                                                                          public void testReadLineCountingWithNewlineAndCRLF() throws Exception {
                                                                                              // Setup mock reader to return specific character sequence
                                                                                              Reader mockReader = mock(Reader.class);
                                                                                              when(mockReader.read())
                                                                                                  .thenReturn((int)'a')  // any non-newline char
                                                                                                  .thenReturn((int)'\n') // standalone newline
                                                                                                  .thenReturn((int)'\r') // CR
                                                                                                  .thenReturn((int)'\n') // LF after CR
                                                                                                  .thenReturn(-1);      // EOF
                                                                                              
                                                                                              // Use reflection to create ExtendedBufferedReader instance
                                                                                              Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                              Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                              constructor.setAccessible(true);
                                                                                              Object readerObj = constructor.newInstance(mockReader);
                                                                                              
                                                                                              // Read first char (shouldn't affect line count)
                                                                                              Method readMethod = clazz.getDeclaredMethod("read");
                                                                                              readMethod.invoke(readerObj);
                                                                                              Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                                              assertEquals(0, getLineNumberMethod.invoke(readerObj));
                                                                                              
                                                                                              // Read standalone '\n' - should increment counter
                                                                                              readMethod.invoke(readerObj);
                                                                                              assertEquals(1, getLineNumberMethod.invoke(readerObj));
                                                                                              
                                                                                              // Read '\r' - should increment counter
                                                                                              readMethod.invoke(readerObj);
                                                                                              assertEquals(2, getLineNumberMethod.invoke(readerObj));
                                                                                              
                                                                                              // Read '\n' after '\r' - should NOT increment counter
                                                                                              readMethod.invoke(readerObj);
                                                                                              assertEquals(2, getLineNumberMethod.invoke(readerObj));
                                                                                              
                                                                                              // Verify the sequence was read completely
                                                                                              assertEquals(-1, readMethod.invoke(readerObj));
                                                                                          }

    @Test
                                                                                      public void testReadLineEndingsWithMutation() throws Exception {
                                                                                          // Setup test data - \r\n sequence
                                                                                          char[] testData1 = {'a', '\r', '\n', 'b'};
                                                                                          Reader mockReader1 = mock(Reader.class);
                                                                                          when(mockReader1.read(any(char[].class), anyInt(), anyInt()))
                                                                                              .thenAnswer(invocation -> {
                                                                                                  char[] buffer = (char[]) invocation.getArguments()[0];
                                                                                                  System.arraycopy(testData1, 0, buffer, 0, testData1.length);
                                                                                                  return testData1.length;
                                                                                              });
                                                                                          
                                                                                          // Use reflection to access non-public constructor
                                                                                          Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                                                                              .getDeclaredConstructor(Reader.class);
                                                                                          constructor.setAccessible(true);
                                                                                          Object reader = constructor.newInstance(mockReader1);
                                                                                          Method readMethod = reader.getClass().getMethod("read", char[].class, int.class, int.class);
                                                                                          Method getLineNumberMethod = reader.getClass().getMethod("getLineNumber");
                                                                                          
                                                                                          char[] buf = new char[10];
                                                                                          
                                                                                          // First read - should read all characters
                                                                                          int read = (int) readMethod.invoke(reader, buf, 0, 10);
                                                                                          assertEquals(testData1.length, read);
                                                                                          
                                                                                          // Verify line counting - original should count \r and not count \n after \r
                                                                                          assertEquals(1, getLineNumberMethod.invoke(reader));
                                                                                          
                                                                                          // Additional test with standalone \n
                                                                                          char[] testData2 = {'a', '\n', 'b'};
                                                                                          Reader mockReader2 = mock(Reader.class);
                                                                                          when(mockReader2.read(any(char[].class), anyInt(), anyInt()))
                                                                                              .thenAnswer(invocation -> {
                                                                                                  char[] buffer = (char[]) invocation.getArguments()[0];
                                                                                                  System.arraycopy(testData2, 0, buffer, 0, testData2.length);
                                                                                                  return testData2.length;
                                                                                              });
                                                                                          
                                                                                          reader = constructor.newInstance(mockReader2);
                                                                                          readMethod = reader.getClass().getMethod("read", char[].class, int.class, int.class);
                                                                                          getLineNumberMethod = reader.getClass().getMethod("getLineNumber");
                                                                                          
                                                                                          read = (int) readMethod.invoke(reader, buf, 0, 10);
                                                                                          assertEquals(testData2.length, read);
                                                                                          
                                                                                          // Original counts standalone \n
                                                                                          assertEquals(1, getLineNumberMethod.invoke(reader));
                                                                                      }

    @Test
                                                                                 public void testReadLineCountingWithRegularCharacter() throws Exception {
                                                                                     // Setup test data where we have a regular character not preceded by '\r'
                                                                                     char[] testBuffer = {'a'};
                                                                                     Reader mockReader = mock(Reader.class);
                                                                                     when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                                                                                         .thenAnswer(invocation -> {
                                                                                             char[] buf = (char[]) invocation.getArguments()[0];
                                                                                             int off = (Integer) invocation.getArguments()[1];
                                                                                             System.arraycopy(testBuffer, 0, buf, off, testBuffer.length);
                                                                                             return testBuffer.length;
                                                                                         });
                                                                                     
                                                                                     // Use reflection to create ExtendedBufferedReader instance
                                                                                     Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                                                                         .getDeclaredConstructor(Reader.class);
                                                                                     constructor.setAccessible(true);
                                                                                     Object reader = constructor.newInstance(mockReader);
                                                                                     Method readMethod = reader.getClass().getMethod("read", char[].class, int.class, int.class);
                                                                                     Method getLineNumberMethod = reader.getClass().getMethod("getLineNumber");
                                                                                     
                                                                                     // Execute read operation
                                                                                     char[] buf = new char[10];
                                                                                     int read = (Integer) readMethod.invoke(reader, buf, 0, 10);
                                                                                     
                                                                                     // Verify line counting - should NOT increment for regular character
                                                                                     assertEquals("Should not count lines for regular characters", 0, getLineNumberMethod.invoke(reader));
                                                                                     
                                                                                     // The mutant would incorrectly count this if lastChar wasn't '\r'
                                                                                     // So if lineCounter is > 0, the mutant is detected
                                                                                 }

    @Test
                                                                             public void testReadLineCountingWithNewline() throws Exception {
                                                                                 // Setup test with mocked Reader
                                                                                 Reader mockReader = mock(Reader.class);
                                                                                 
                                                                                 // Use reflection to access non-public constructor and methods
                                                                                 Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                                 Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                                 constructor.setAccessible(true);
                                                                                 Object readerObj = constructor.newInstance(mockReader);
                                                                                 
                                                                                 // Test case 1: '\n' without preceding '\r' - should increment line counter
                                                                                 when(mockReader.read()).thenReturn((int)'a', (int)'\n');
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads 'a'
                                                                                 int before = (int) clazz.getMethod("getLineNumber").invoke(readerObj);
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads '\n' - should increment
                                                                                 assertEquals(before + 1, clazz.getMethod("getLineNumber").invoke(readerObj));
                                                                                 
                                                                                 // Test case 2: non '\n' without preceding '\r' - should NOT increment
                                                                                 when(mockReader.read()).thenReturn((int)'a', (int)'b');
                                                                                 readerObj = constructor.newInstance(mockReader);
                                                                                 before = (int) clazz.getMethod("getLineNumber").invoke(readerObj);
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads 'a'
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads 'b' - mutant would increment here
                                                                                 assertEquals(before, clazz.getMethod("getLineNumber").invoke(readerObj));
                                                                                 
                                                                                 // Test case 3: '\r' should always increment
                                                                                 when(mockReader.read()).thenReturn((int)'\r');
                                                                                 readerObj = constructor.newInstance(mockReader);
                                                                                 before = (int) clazz.getMethod("getLineNumber").invoke(readerObj);
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads '\r' - should increment
                                                                                 assertEquals(before + 1, clazz.getMethod("getLineNumber").invoke(readerObj));
                                                                                 
                                                                                 // Test case 4: '\n' after '\r' should NOT increment (Windows line ending)
                                                                                 when(mockReader.read()).thenReturn((int)'\r', (int)'\n');
                                                                                 readerObj = constructor.newInstance(mockReader);
                                                                                 before = (int) clazz.getMethod("getLineNumber").invoke(readerObj);
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads '\r' - increments
                                                                                 int afterFirst = (int) clazz.getMethod("getLineNumber").invoke(readerObj);
                                                                                 clazz.getMethod("read").invoke(readerObj); // reads '\n' - should NOT increment again
                                                                                 assertEquals(afterFirst, clazz.getMethod("getLineNumber").invoke(readerObj));
                                                                             }

    @Test
                                                                     public void testReadLineCountingWithNewlineWithoutCR() throws Exception {
                                                                         // Setup test data
                                                                         char[] testBuffer = {'a', '\n', 'b'}; // '\n' not preceded by '\r'
                                                                         Reader mockReader = mock(Reader.class);
                                                                         when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                                                                             .thenAnswer(invocation -> {
                                                                                 char[] buf = (char[]) invocation.getArguments()[0];
                                                                                 int off = (int) invocation.getArguments()[1];
                                                                                 System.arraycopy(testBuffer, 0, buf, off, testBuffer.length);
                                                                                 return testBuffer.length;
                                                                             });
                                                                         
                                                                         // Create ExtendedBufferedReader instance using reflection since it's not public
                                                                         Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                                                             .getDeclaredConstructor(Reader.class);
                                                                         constructor.setAccessible(true);
                                                                         Object reader = constructor.newInstance(mockReader);
                                                                         Method getLineNumber = reader.getClass().getDeclaredMethod("getLineNumber");
                                                                         getLineNumber.setAccessible(true);
                                                                         Method readMethod = reader.getClass().getDeclaredMethod("read", char[].class, int.class, int.class);
                                                                         readMethod.setAccessible(true);
                                                                         
                                                                         // Execute read operation
                                                                         char[] buf = new char[10];
                                                                         int read = (int) readMethod.invoke(reader, buf, 0, 10);
                                                                         
                                                                         // Verify line counting
                                                                         assertEquals("Should count one line for standalone newline", 1, getLineNumber.invoke(reader));
                                                                         
                                                                         // Verify the mutation by checking the line counter
                                                                         // Original code would increment lineCounter for '\n'
                                                                         // Mutated code would not increment lineCounter for '\n'
                                                                         // So if lineCounter is 0, the mutant is detected
                                                                     }

    @Test
                                                                public void testReadLineCountingWithNewlineAfterCarriageReturn() throws Exception {
                                                                    // Setup mock reader to return specific sequence: '\r', '\n', 'a'
                                                                    Reader mockReader = mock(Reader.class);
                                                                    when(mockReader.read())
                                                                        .thenReturn((int)'\r')  // first read returns '\r'
                                                                        .thenReturn((int)'\n')  // second read returns '\n'
                                                                        .thenReturn((int)'a');  // third read returns 'a'
                                                                    
                                                                    // Use reflection to create ExtendedBufferedReader instance
                                                                    Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                    Constructor<?> constructor = clazz.getDeclaredConstructor(Reader.class);
                                                                    constructor.setAccessible(true);
                                                                    Object reader = constructor.newInstance(mockReader);
                                                                    
                                                                    // First read - '\r' (should increment counter)
                                                                    Method readMethod = clazz.getDeclaredMethod("read");
                                                                    readMethod.invoke(reader);
                                                                    Method getLineNumberMethod = clazz.getDeclaredMethod("getLineNumber");
                                                                    assertEquals(1, (int)getLineNumberMethod.invoke(reader));
                                                                    
                                                                    // Second read - '\n' after '\r' 
                                                                    // Original: shouldn't increment (because lastChar was '\r')
                                                                    // Mutant: WILL increment (because of || condition)
                                                                    readMethod.invoke(reader);
                                                                    // This assertion will fail for the mutant but pass for original
                                                                    assertEquals(1, (int)getLineNumberMethod.invoke(reader));
                                                                    
                                                                    // Third read - 'a' (shouldn't increment)
                                                                    readMethod.invoke(reader);
                                                                    assertEquals(1, (int)getLineNumberMethod.invoke(reader));
                                                                }

    @Test
                                                                public void testReadWithCarriageReturnNewline() throws Exception {
                                                                    // Setup test data - \r\n sequence
                                                                    char[] testData = {'a', '\r', '\n', 'b'};
                                                                    java.io.Reader reader = new java.io.CharArrayReader(testData);
                                                                    
                                                                    // Use reflection to access package-private ExtendedBufferedReader
                                                                    Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                                    java.lang.reflect.Constructor<?> constructor = clazz.getConstructor(java.io.Reader.class);
                                                                    Object bufferedReader = constructor.newInstance(reader);
                                                                    
                                                                    // Create buffer to read into
                                                                    char[] buf = new char[4];
                                                                    
                                                                    // Read all data at once
                                                                    java.lang.reflect.Method readMethod = clazz.getMethod("read", char[].class, int.class, int.class);
                                                                    int len = (int) readMethod.invoke(bufferedReader, buf, 0, 4);
                                                                    
                                                                    // Verify the line counter - should be 1 for \r\n sequence
                                                                    java.lang.reflect.Method getLineNumberMethod = clazz.getMethod("getLineNumber");
                                                                    assertEquals(1, getLineNumberMethod.invoke(bufferedReader));
                                                                    
                                                                    // Verify last character is stored correctly
                                                                    java.lang.reflect.Field lastCharField = clazz.getDeclaredField("lastChar");
                                                                    lastCharField.setAccessible(true);
                                                                    assertEquals('b', lastCharField.get(bufferedReader));
                                                                    
                                                                    // Verify correct number of chars read
                                                                    assertEquals(4, len);
                                                                    
                                                                    // Verify buffer content
                                                                    assertArrayEquals(testData, buf);
                                                                }

    @Test
                                                           public void testReadShouldIncrementLineCounterForLineEndings() throws Exception {
                                                               // Arrange
                                                               Reader mockReader = mock(Reader.class);
                                                               
                                                               // Use reflection to create ExtendedBufferedReader instance
                                                               Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                               Constructor<?> constructor = clazz.getConstructor(Reader.class);
                                                               Object reader = constructor.newInstance(mockReader);
                                                               
                                                               Method readMethod = clazz.getMethod("read");
                                                               Method getLineNumberMethod = clazz.getMethod("getLineNumber");
                                                           
                                                               // Test case 1: Standalone carriage return should increment counter
                                                               when(mockReader.read()).thenReturn((int)'\r');
                                                               int initialCount = (int) getLineNumberMethod.invoke(reader);
                                                               readMethod.invoke(reader);
                                                               assertEquals("Line counter should increment for standalone \\r", 
                                                                           initialCount + 1, getLineNumberMethod.invoke(reader));
                                                               
                                                               // Test case 2: Newline not preceded by carriage return should increment counter
                                                               when(mockReader.read()).thenReturn((int)'\n');
                                                               initialCount = (int) getLineNumberMethod.invoke(reader);
                                                               readMethod.invoke(reader);
                                                               assertEquals("Line counter should increment for \\n not after \\r", 
                                                                           initialCount + 1, getLineNumberMethod.invoke(reader));
                                                               
                                                               // Test case 3: Newline preceded by carriage return should NOT increment again
                                                               when(mockReader.read())
                                                                   .thenReturn((int)'\r')  // first read returns \r
                                                                   .thenReturn((int)'\n'); // second read returns \n
                                                               initialCount = (int) getLineNumberMethod.invoke(reader);
                                                               readMethod.invoke(reader); // reads \r and increments
                                                               readMethod.invoke(reader); // reads \n but shouldn't increment again
                                                               assertEquals("Line counter should not increment twice for \\r\\n sequence", 
                                                                           initialCount + 1, getLineNumberMethod.invoke(reader));
                                                           }

    @Test
                                                           public void testReadLineCountingWithMutant() throws Exception {
                                                               // Setup test data with various line endings
                                                               char[] testData = {'a', '\r', 'b', '\n', '\r', '\n', 'c'};
                                                               java.io.Reader mockReader = new java.io.CharArrayReader(testData);
                                                               
                                                               // Use reflection to create ExtendedBufferedReader since it's package-private
                                                               Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                                               java.lang.reflect.Constructor<?> constructor = clazz.getConstructor(java.io.Reader.class);
                                                               Object reader = constructor.newInstance(mockReader);
                                                               
                                                               // Buffer to read into
                                                               char[] buf = new char[testData.length];
                                                               
                                                               // Initial line count should be 0
                                                               java.lang.reflect.Method getLineNumber = clazz.getDeclaredMethod("getLineNumber");
                                                               assertEquals(0, getLineNumber.invoke(reader));
                                                               
                                                               // Read all data (should detect 3 line endings: \r, \n, and \r\n)
                                                               java.lang.reflect.Method read = clazz.getDeclaredMethod("read", char[].class, int.class, int.class);
                                                               int len = (int) read.invoke(reader, buf, 0, testData.length);
                                                               assertEquals(testData.length, len);
                                                               
                                                               // Verify line counting works (original would be 3, mutant would be 0)
                                                               // This is the key assertion that catches the mutant
                                                               assertTrue("Line counter should increment for line endings", 
                                                                          (int) getLineNumber.invoke(reader) > 0);
                                                               
                                                               // More specific assertions about exact count
                                                               // Original would count: \r (1), \n (2), \r\n (3)
                                                               assertEquals(3, getLineNumber.invoke(reader));
                                                               
                                                               // Verify last character is stored
                                                               java.lang.reflect.Field lastCharField = clazz.getDeclaredField("lastChar");
                                                               lastCharField.setAccessible(true);
                                                               assertEquals('c', lastCharField.get(reader));
                                                           }

    @Test
                                          public void testLineCounterIncrementsOnStandaloneCarriageReturn() throws Exception {
                                              String input = "\r";
                                              java.io.Reader stringReader = new java.io.StringReader(input);
                                              
                                              // Get constructor via reflection and create instance
                                              Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                              java.lang.reflect.Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                              constructor.setAccessible(true);
                                              Object reader = constructor.newInstance(stringReader);
                                              
                                              // Get lineCounter field via reflection
                                              java.lang.reflect.Field lineCounterField = clazz.getDeclaredField("lineCounter");
                                              lineCounterField.setAccessible(true);
                                              
                                              int initialLineCount = (int) lineCounterField.get(reader);
                                              
                                              // Call read method via reflection
                                              java.lang.reflect.Method readMethod = clazz.getDeclaredMethod("read");
                                              readMethod.invoke(reader); // Read the \r
                                              
                                              int finalLineCount = (int) lineCounterField.get(reader);
                                              
                                              assertEquals("Line counter should increment for standalone \\r", 
                                                          initialLineCount + 1, finalLineCount);
                                          }

    @Test
                                  public void testReadNewlineIncrementsLineCounter() throws Exception {
                                      // Setup test data with a single newline character
                                      String testData = "Test\nString";
                                      
                                      // Use reflection to create ExtendedBufferedReader instance
                                      Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                      Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                      constructor.setAccessible(true);
                                      java.io.Reader reader = new java.io.StringReader(testData);
                                      Object extendedReader = constructor.newInstance(reader);
                                      java.io.BufferedReader bufferedReader = (java.io.BufferedReader) extendedReader;
                                      
                                      // Get initial line count (should be 0)
                                      Method getLineNumber = clazz.getDeclaredMethod("getLineNumber");
                                      getLineNumber.setAccessible(true);
                                      int initialLineCount = (int) getLineNumber.invoke(extendedReader);
                                      
                                      // Create buffer and read data
                                      char[] buf = new char[testData.length()];
                                      int bytesRead = bufferedReader.read(buf, 0, testData.length());
                                      
                                      // Verify we read all characters
                                      assertEquals(testData.length(), bytesRead);
                                      
                                      // Verify line counter increased by 1 (because of the \n)
                                      assertEquals(initialLineCount + 1, getLineNumber.invoke(extendedReader));
                                      
                                      // Additional verification that the newline wasn't preceded by \r
                                      assertNotEquals('\r', buf[4-1]); // 4 is position of \n in "Test\nString"
                                  }

    @Test
                              public void testLineCounterIncrementsOnNewlineWithoutPrecedingCarriageReturn() throws Exception {
                                  java.io.StringReader reader = new java.io.StringReader("\n");
                                  // Use reflection to access the constructor
                                  Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                                      .getDeclaredConstructor(java.io.Reader.class);
                                  constructor.setAccessible(true);
                                  Object extendedReader = constructor.newInstance(reader);
                                  
                                  Field lineCounterField = extendedReader.getClass().getDeclaredField("lineCounter");
                                  lineCounterField.setAccessible(true);
                                  
                                  int initialLineCount = (int) lineCounterField.get(extendedReader);
                                  // Use reflection to call read method
                                  Method readMethod = extendedReader.getClass().getDeclaredMethod("read");
                                  readMethod.setAccessible(true);
                                  readMethod.invoke(extendedReader); // Read the \n
                                  int finalLineCount = (int) lineCounterField.get(extendedReader);
                                  
                                  assertEquals("Line counter should increment for \\n without preceding \\r", 
                                              initialLineCount + 1, finalLineCount);
                              }

    @Test
                          public void testLineCounterIncrementsOnNewline() throws Exception {
                              // Setup test input with different line endings
                              String input = "Line1\\r\\nLine2\\nLine3\\rLine4";
                              
                              try {
                                  // Create reader using reflection since constructor might not be accessible
                                  Class<?> clazz = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                                  Constructor<?> constructor = clazz.getDeclaredConstructor(java.io.Reader.class);
                                  constructor.setAccessible(true);
                                  java.io.Reader stringReader = new java.io.StringReader(input);
                                  Object reader = constructor.newInstance(stringReader);
                                  
                                  // Get the lineCounter field via reflection for verification
                                  Field lineCounterField = clazz.getDeclaredField("lineCounter");
                                  lineCounterField.setAccessible(true);
                                  
                                  long initialLineCount = ((Number) lineCounterField.get(reader)).longValue();
                                  
                                  // Read characters until we've processed all line endings
                                  Method readMethod = clazz.getDeclaredMethod("read");
                                  readMethod.setAccessible(true);
                                  while ((Integer) readMethod.invoke(reader) != -1) {
                                      // Just reading to process line endings
                                  }
                                  
                                  long finalLineCount = ((Number) lineCounterField.get(reader)).longValue();
                                  
                                  // Verify line counter increased by 3 (for \r\n, \n, and \r)
                                  assertEquals("Line counter should increment for each line ending", 
                                              initialLineCount + 3, finalLineCount);
                              } catch (ClassNotFoundException | NoSuchMethodException | 
                                       IllegalAccessException | InstantiationException | 
                                       InvocationTargetException | NoSuchFieldException e) {
                                  fail("Test failed due to reflection error: " + e.getMessage());
                              }
                          }

    @Test
                     public void testReadWithNewlineSequences() throws Exception {
                         // Create a mock reader that returns test sequence
                         Reader mockReader = mock(Reader.class);
                         when(mockReader.read())
                             .thenReturn((int)'a')  // any character
                             .thenReturn((int)'\r') // CR
                             .thenReturn((int)'\n') // LF
                             .thenReturn((int)'b')   // any character
                             .thenReturn((int)'\n')  // LF alone
                             .thenReturn(-1);       // EOF
                         
                         // Get ExtendedBufferedReader class via reflection
                         Class<?> readerClass = Class.forName("org.apache.commons.csv.ExtendedBufferedReader");
                         Constructor<?> constructor = readerClass.getDeclaredConstructor(Reader.class);
                         constructor.setAccessible(true);
                         Object reader = constructor.newInstance(mockReader);
                         
                         // Read first character (should not affect line count)
                         Method readMethod = readerClass.getDeclaredMethod("read");
                         assertEquals('a', readMethod.invoke(reader));
                         
                         // Read CR - should increment line counter
                         assertEquals('\r', readMethod.invoke(reader));
                         Method getLineNumberMethod = readerClass.getDeclaredMethod("getLineNumber");
                         assertEquals(1, getLineNumberMethod.invoke(reader));
                         
                         // Read LF - should NOT increment (CRLF sequence counts as one line)
                         assertEquals('\n', readMethod.invoke(reader));
                         assertEquals(1, getLineNumberMethod.invoke(reader));
                         
                         // Read next character
                         assertEquals('b', readMethod.invoke(reader));
                         
                         // Read standalone LF - should increment line counter
                         assertEquals('\n', readMethod.invoke(reader));
                         assertEquals(2, getLineNumberMethod.invoke(reader));
                         
                         // Verify EOF
                         assertEquals(-1, readMethod.invoke(reader));
                         
                         // The key assertion that catches the mutant:
                         // After reading '\n', lastChar should be '\n' (not 0)
                         // We can verify this by reading again - if lastChar was preserved,
                         // a standalone '\n' would not increment the counter
                         // (but with mutant, it would increment incorrectly)
                         when(mockReader.read())
                             .thenReturn((int)'\n')  // LF
                             .thenReturn((int)'\n'); // LF
                         
                         reader = constructor.newInstance(mockReader);
                         assertEquals('\n', readMethod.invoke(reader));
                         assertEquals(1, getLineNumberMethod.invoke(reader));
                         assertEquals('\n', readMethod.invoke(reader));
                         // Original: should stay 1 (since lastChar was '\n')
                         // Mutant: would increment to 2 (since lastChar was 0)
                         assertEquals(1, getLineNumberMethod.invoke(reader));
                     }

    @Test
             public void testReadWithCrLfSequenceAcrossReads() throws IOException, ClassNotFoundException, NoSuchMethodException, 
                     InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
                 // Setup test data - \r\n sequence split across two reads
                 final char[] firstRead = {'a', '\r'};  // ends with \r
                 final char[] secondRead = {'\n', 'b'}; // starts with \n
                 
                 // Mock the Reader to return our test data
                 Reader mockReader = mock(Reader.class);
                 when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                     .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                         @Override
                         public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                             char[] buf = (char[]) invocation.getArguments()[0];
                             int off = (Integer) invocation.getArguments()[1];
                             int len = (Integer) invocation.getArguments()[2];
                             // First read returns first part
                             System.arraycopy(firstRead, 0, buf, off, Math.min(len, firstRead.length));
                             return firstRead.length;
                         }
                     })
                     .thenAnswer(new org.mockito.stubbing.Answer<Integer>() {
                         @Override
                         public Integer answer(org.mockito.invocation.InvocationOnMock invocation) throws Throwable {
                             char[] buf = (char[]) invocation.getArguments()[0];
                             int off = (Integer) invocation.getArguments()[1];
                             int len = (Integer) invocation.getArguments()[2];
                             // Second read returns second part
                             System.arraycopy(secondRead, 0, buf, off, Math.min(len, secondRead.length));
                             return secondRead.length;
                         }
                     });
                 
                 // Create ExtendedBufferedReader instance through reflection since it's not public
                 Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                     .getDeclaredConstructor(Reader.class);
                 constructor.setAccessible(true);
                 Object reader = constructor.newInstance(mockReader);
                 Method readMethod = reader.getClass().getMethod("read", char[].class, int.class, int.class);
                 Method getLineNumberMethod = reader.getClass().getMethod("getLineNumber");
                 
                 // First read - should store '\r' in lastChar
                 char[] buf1 = new char[10];
                 int len1 = (int) readMethod.invoke(reader, buf1, 0, 2);
                 assertEquals(2, len1);
                 
                 // Second read - should detect the \n after \r and NOT count as new line
                 char[] buf2 = new char[10];
                 int len2 = (int) readMethod.invoke(reader, buf2, 0, 2);
                 assertEquals(2, len2);
                 
                 // Verify line count - should be 1 (for the \r) not 2
                 int lineNumber = (int) getLineNumberMethod.invoke(reader);
                 assertEquals(1, lineNumber);
             }

    @Test
        public void testRead_LastCharShouldBeSetToLastReadCharacter() throws Exception {
            // Setup test data - a buffer containing "a\nb\r"
            char[] testBuffer = {'a', '\n', 'b', '\r'};
            Reader mockReader = mock(Reader.class);
            
            // Mock the read operation
            when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                .thenAnswer(invocation -> {
                    Object[] args = invocation.getArguments();
                    char[] buf = (char[]) args[0];
                    int offset = (int) args[1];
                    int length = (int) args[2];
                    System.arraycopy(testBuffer, 0, buf, offset, Math.min(length, testBuffer.length));
                    return testBuffer.length;
                });
            
            // Create ExtendedBufferedReader instance using reflection
            Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
                .getDeclaredConstructor(Reader.class);
            constructor.setAccessible(true);
            Object reader = constructor.newInstance(mockReader);
            
            char[] buf = new char[10];
            
            // Perform read operation using reflection
            Method readMethod = reader.getClass().getDeclaredMethod("read", char[].class, int.class, int.class);
            int result = (int) readMethod.invoke(reader, buf, 0, 10);
            
            // Verify lastChar is set to the last character read ('\r') and not -1
            Field lastCharField = reader.getClass().getDeclaredField("lastChar");
            lastCharField.setAccessible(true);
            assertEquals('\r', lastCharField.get(reader));
            assertEquals(testBuffer.length, result);
            
            // Verify line counting is correct (should be 2 lines)
            Method getLineNumberMethod = reader.getClass().getDeclaredMethod("getLineNumber");
            assertEquals(2, getLineNumberMethod.invoke(reader));
        }

    @Test
    public void testReadWithNewlineNotPrecededByCarriageReturn() throws Exception {
        // Setup - mock the parent reader to return specific sequence
        Reader mockReader = mock(Reader.class);
        when(mockReader.read())
            .thenReturn((int)'a')  // first character
            .thenReturn((int)'\n') // newline not preceded by \r
            .thenReturn(-1); // END_OF_STREAM
        
        // Use reflection to access package-private constructor
        Constructor<?> constructor = Class.forName("org.apache.commons.csv.ExtendedBufferedReader")
            .getDeclaredConstructor(Reader.class);
        constructor.setAccessible(true);
        Object reader = constructor.newInstance(mockReader);
        
        // First read - should store 'a' in lastChar
        Method readMethod = reader.getClass().getDeclaredMethod("read");
        assertEquals('a', readMethod.invoke(reader));
        
        // Second read - should count line and store '\n' in lastChar
        // But mutant would store -1 instead
        assertEquals('\n', readMethod.invoke(reader));
        
        Method getLineNumberMethod = reader.getClass().getDeclaredMethod("getLineNumber");
        assertEquals(1, getLineNumberMethod.invoke(reader)); // line should be counted
        
        // Verify lastChar was properly set (test will fail with mutant)
        Field lastCharField = reader.getClass().getDeclaredField("lastChar");
        lastCharField.setAccessible(true);
        int lastCharValue = lastCharField.getInt(reader);
        assertEquals('\n', lastCharValue); // This will catch the mutant
    }


}
