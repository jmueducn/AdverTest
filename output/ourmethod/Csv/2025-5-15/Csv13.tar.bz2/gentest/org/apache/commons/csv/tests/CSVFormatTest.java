package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                           public void testNewFormat_WithStandardDelimiter() {
                                                                                                                                               // Test with comma delimiter (standard CSV)
                                                                                                                                               char delimiter = ',';
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               assertEquals(delimiter, format.getDelimiter());
                                                                                                                                               assertNull(format.getQuoteCharacter());
                                                                                                                                               assertNull(format.getQuoteMode());
                                                                                                                                               assertNull(format.getCommentMarker());
                                                                                                                                               assertNull(format.getEscapeCharacter());
                                                                                                                                               assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                               assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                               assertNull(format.getRecordSeparator());
                                                                                                                                               assertNull(format.getNullString());
                                                                                                                                               assertNull(format.getHeader());
                                                                                                                                               assertNull(format.getHeaderComments());
                                                                                                                                               assertFalse(format.getSkipHeaderRecord());
                                                                                                                                               assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testNewFormat_WithTabDelimiter() {
                                                                                                                                               // Test with tab delimiter (TSV format)
                                                                                                                                               char delimiter = '\t';
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               assertEquals(delimiter, format.getDelimiter());
                                                                                                                                               assertNull(format.getQuoteCharacter());
                                                                                                                                               assertNull(format.getQuoteMode());
                                                                                                                                               assertNull(format.getCommentMarker());
                                                                                                                                               assertNull(format.getEscapeCharacter());
                                                                                                                                               assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                               assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                               assertNull(format.getRecordSeparator());
                                                                                                                                               assertNull(format.getNullString());
                                                                                                                                               assertNull(format.getHeader());
                                                                                                                                               assertNull(format.getHeaderComments());
                                                                                                                                               assertFalse(format.getSkipHeaderRecord());
                                                                                                                                               assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testNewFormat_WithPipeDelimiter() {
                                                                                                                                               // Test with pipe delimiter (common alternative)
                                                                                                                                               char delimiter = '|';
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               assertEquals(delimiter, format.getDelimiter());
                                                                                                                                               assertNull(format.getQuoteCharacter());
                                                                                                                                               assertNull(format.getQuoteMode());
                                                                                                                                               assertNull(format.getCommentMarker());
                                                                                                                                               assertNull(format.getEscapeCharacter());
                                                                                                                                               assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                               assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                               assertNull(format.getRecordSeparator());
                                                                                                                                               assertNull(format.getNullString());
                                                                                                                                               assertNull(format.getHeader());
                                                                                                                                               assertNull(format.getHeaderComments());
                                                                                                                                               assertFalse(format.getSkipHeaderRecord());
                                                                                                                                               assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testNewFormat_WithSpecialCharacterDelimiter() {
                                                                                                                                               // Test with special character delimiter
                                                                                                                                               char delimiter = '¬';
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               assertEquals(delimiter, format.getDelimiter());
                                                                                                                                               assertNull(format.getQuoteCharacter());
                                                                                                                                               assertNull(format.getQuoteMode());
                                                                                                                                               assertNull(format.getCommentMarker());
                                                                                                                                               assertNull(format.getEscapeCharacter());
                                                                                                                                               assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                               assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                               assertNull(format.getRecordSeparator());
                                                                                                                                               assertNull(format.getNullString());
                                                                                                                                               assertNull(format.getHeader());
                                                                                                                                               assertNull(format.getHeaderComments());
                                                                                                                                               assertFalse(format.getSkipHeaderRecord());
                                                                                                                                               assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testNewFormat_WithNonPrintableDelimiter() {
                                                                                                                                               // Test with non-printable character delimiter
                                                                                                                                               char delimiter = '\u0001';
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               assertEquals(delimiter, format.getDelimiter());
                                                                                                                                               assertNull(format.getQuoteCharacter());
                                                                                                                                               assertNull(format.getQuoteMode());
                                                                                                                                               assertNull(format.getCommentMarker());
                                                                                                                                               assertNull(format.getEscapeCharacter());
                                                                                                                                               assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                               assertFalse(format.getIgnoreEmptyLines());
                                                                                                                                               assertNull(format.getRecordSeparator());
                                                                                                                                               assertNull(format.getNullString());
                                                                                                                                               assertNull(format.getHeader());
                                                                                                                                               assertNull(format.getHeaderComments());
                                                                                                                                               assertFalse(format.getSkipHeaderRecord());
                                                                                                                                               assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testNewFormat_EqualsAndHashCode() {
                                                                                                                                               // Test that two formats with same delimiter are equal
                                                                                                                                               char delimiter = ';';
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(delimiter);
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               assertTrue(format1.equals(format2));
                                                                                                                                               assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testNewFormat_NotEquals() {
                                                                                                                                               // Test that two formats with different delimiters are not equal
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                                                                               
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                               assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testValueOf_AllPredefinedFormats() {
                                                                                                                                               // Test all predefined formats
                                                                                                                                               assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.valueOf("Default").getFormat());
                                                                                                                                               assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.valueOf("Excel").getFormat());
                                                                                                                                               assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.valueOf("RFC4180").getFormat());
                                                                                                                                               assertEquals(CSVFormat.TDF, CSVFormat.Predefined.valueOf("TDF").getFormat());
                                                                                                                                               assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.valueOf("MySQL").getFormat());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testValueOf_CaseInsensitive() {
                                                                                                                                               // Test case insensitivity
                                                                                                                                               assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.valueOf("default").getFormat());
                                                                                                                                               assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.valueOf("excel").getFormat());
                                                                                                                                               assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.valueOf("rfc4180").getFormat());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testValueOf_InvalidFormat() {
                                                                                                                                               // Test invalid format name
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("No enum constant");
                                                                                                                                               CSVFormat.Predefined.valueOf("INVALID_FORMAT").getFormat();
                                                                                                                                           }

 @Test
                                                                                                                                           public void testValueOf_NullInput() {
                                                                                                                                               // Test null input
                                                                                                                                               thrown.expect(NullPointerException.class);
                                                                                                                                               CSVFormat.Predefined.valueOf(null).getFormat();
                                                                                                                                           }

 @Test
                                                                                                                                           public void testValueOf_EmptyString() {
                                                                                                                                               // Test empty string input
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("No enum constant");
                                                                                                                                               CSVFormat.Predefined.valueOf("").getFormat();
                                                                                                                                           }

 @Test
                                                                                                                                           public void testValueOf_WhitespaceString() {
                                                                                                                                               // Test whitespace string input
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("No enum constant");
                                                                                                                                               CSVFormat.Predefined.valueOf("   ").getFormat();
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_Reflexive() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertTrue(format.equals(format));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_Symmetric() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT;
                                                                                                                                               assertTrue(format1.equals(format2));
                                                                                                                                               assertTrue(format2.equals(format1));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullComparison() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertFalse(format.equals(null));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentClass() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertFalse(format.equals("Not a CSVFormat"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentDelimiter() {
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentQuoteCharacter() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withQuote('\'');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullQuoteCharacter() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentQuoteMode() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentCommentMarker() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('!');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullCommentMarker() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentEscapeCharacter() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withEscape('/');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullEscapeCharacter() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withEscape(null);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentNullString() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withNullString("null");
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullNullString() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentHeader() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withHeader("X", "Y");
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullHeader() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withHeader((String[])null);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withHeader("A", "B");
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentIgnoreSurroundingSpaces() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentIgnoreEmptyLines() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentSkipHeaderRecord() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_DifferentRecordSeparator() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_NullRecordSeparator() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                               assertFalse(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testEquals_AllFieldsEqual() {
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                                                                   .withDelimiter(',')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(false)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withRecordSeparator("\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("A", "B")
                                                                                                                                                   .withSkipHeaderRecord(false);
                                                                                                                                       
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                                                                   .withDelimiter(',')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(false)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withRecordSeparator("\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("A", "B")
                                                                                                                                                   .withSkipHeaderRecord(false);
                                                                                                                                       
                                                                                                                                               assertTrue(format1.equals(format2));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_SimpleValues() throws Exception {
                                                                                                                                               // Test basic formatting with default format
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               Object[] values = {"value1", "value2", "value3"};
                                                                                                                                               String expected = "value1,value2,value3";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithQuotes() throws Exception {
                                                                                                                                               // Test formatting with quotes
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               Object[] values = {"value1", "value,with,comma", "value3"};
                                                                                                                                               String expected = "\"value1\",\"value,with,comma\",\"value3\"";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithDifferentDelimiter() throws Exception {
                                                                                                                                               // Test with tab delimiter
                                                                                                                                               CSVFormat format = CSVFormat.TDF;
                                                                                                                                               Object[] values = {"value1", "value2", "value3"};
                                                                                                                                               String expected = "value1\tvalue2\tvalue3";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_EmptyValues() throws Exception {
                                                                                                                                               // Test with empty values array
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               Object[] values = {};
                                                                                                                                               String expected = "";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_NullValues() throws Exception {
                                                                                                                                               // Test with null values
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                               Object[] values = {"value1", null, "value3"};
                                                                                                                                               String expected = "value1,NULL,value3";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithRecordSeparator() throws Exception {
                                                                                                                                               // Test with custom record separator
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                                                               Object[] values = {"value1", "value2", "value3"};
                                                                                                                                               String expected = "value1,value2,value3";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithQuoteMode() throws Exception {
                                                                                                                                               // Test with different quote modes
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                                               Object[] values = {"value1", "value2", "value3"};
                                                                                                                                               String expected = "\"value1\",\"value2\",\"value3\"";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithSpecialCharacters() throws Exception {
                                                                                                                                               // Test with special characters
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               Object[] values = {"line\nbreak", "tab\tcharacter", "quote\"character"};
                                                                                                                                               String expected = "\"line\nbreak\",\"tab\tcharacter\",\"quote\"\"character\"";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithSurroundingSpaces() throws Exception {
                                                                                                                                               // Test with surrounding spaces
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                               Object[] values = {"  value1  ", "  value2  ", "  value3  "};
                                                                                                                                               String expected = "value1,value2,value3";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithHeader() throws Exception {
                                                                                                                                               // Test with header configuration
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withHeader("Header1", "Header2", "Header3");
                                                                                                                                               Object[] values = {"value1", "value2", "value3"};
                                                                                                                                               String expected = "value1,value2,value3";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithEmptyStringValues() throws Exception {
                                                                                                                                               // Test with empty string values
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               Object[] values = {"", "", ""};
                                                                                                                                               String expected = ",,";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testFormat_WithDifferentQuoteCharacter() throws Exception {
                                                                                                                                               // Test with single quote character
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
                                                                                                                                               Object[] values = {"value1", "value,with,comma", "value3"};
                                                                                                                                               String expected = "'value1','value,with,comma','value3'";
                                                                                                                                               assertEquals(expected, format.format(values));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetCommentMarker_UsingDefaultFormat() {
                                                                                                                                               // Act
                                                                                                                                               Character commentMarker = CSVFormat.DEFAULT.getCommentMarker();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertNull(commentMarker);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetCommentMarker_UsingExcelFormat() {
                                                                                                                                               // Act
                                                                                                                                               Character commentMarker = CSVFormat.EXCEL.getCommentMarker();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertNull(commentMarker);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetCommentMarker_UsingRFC4180Format() {
                                                                                                                                               // Act
                                                                                                                                               Character commentMarker = CSVFormat.RFC4180.getCommentMarker();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertNull(commentMarker);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetCommentMarker_UsingTDFFormat() {
                                                                                                                                               // Act
                                                                                                                                               Character commentMarker = CSVFormat.TDF.getCommentMarker();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertNull(commentMarker);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetCommentMarker_UsingMySQLFormat() {
                                                                                                                                               // Act
                                                                                                                                               Character commentMarker = CSVFormat.MYSQL.getCommentMarker();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertNull(commentMarker);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetCommentMarker_AfterWithCommentMarker() {
                                                                                                                                               // Arrange
                                                                                                                                               Character expectedCommentMarker = '!';
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat modifiedFormat = originalFormat.withCommentMarker(expectedCommentMarker);
                                                                                                                                               Character actualCommentMarker = modifiedFormat.getCommentMarker();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                                                                               assertNull(originalFormat.getCommentMarker()); // original should remain unchanged
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_DefaultFormat() {
                                                                                                                                               // Test with DEFAULT format (comma delimiter)
                                                                                                                                               assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_ExcelFormat() {
                                                                                                                                               // Test with EXCEL format (comma delimiter)
                                                                                                                                               assertEquals(',', CSVFormat.EXCEL.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_TabDelimitedFormat() {
                                                                                                                                               // Test with TDF format (tab delimiter)
                                                                                                                                               assertEquals('\t', CSVFormat.TDF.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_MySQLFormat() {
                                                                                                                                               // Test with MYSQL format (tab delimiter)
                                                                                                                                               assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_RFC4180Format() {
                                                                                                                                               // Test with RFC4180 format (comma delimiter)
                                                                                                                                               assertEquals(',', CSVFormat.RFC4180.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_CustomFormat() {
                                                                                                                                               // Test with custom delimiter
                                                                                                                                               char testDelimiter = '|';
                                                                                                                                               CSVFormat customFormat = CSVFormat.newFormat(testDelimiter);
                                                                                                                                               assertEquals(testDelimiter, customFormat.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_NonPrintableCharacter() {
                                                                                                                                               // Test with non-printable character as delimiter
                                                                                                                                               char testDelimiter = '\u0001'; // ASCII 1 (Start of Header)
                                                                                                                                               CSVFormat customFormat = CSVFormat.newFormat(testDelimiter);
                                                                                                                                               assertEquals(testDelimiter, customFormat.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_UnicodeCharacter() {
                                                                                                                                               // Test with Unicode character as delimiter
                                                                                                                                               char testDelimiter = 'Ω'; // Greek capital letter Omega
                                                                                                                                               CSVFormat customFormat = CSVFormat.newFormat(testDelimiter);
                                                                                                                                               assertEquals(testDelimiter, customFormat.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetDelimiter_AfterWithDelimiter() {
                                                                                                                                               // Test that withDelimiter creates new instance with new delimiter
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char newDelimiter = ';';
                                                                                                                                               CSVFormat modified = original.withDelimiter(newDelimiter);
                                                                                                                                               
                                                                                                                                               assertEquals(newDelimiter, modified.getDelimiter());
                                                                                                                                               // Original should remain unchanged
                                                                                                                                               assertEquals(',', original.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetEscapeCharacter_UsingPredefinedFormats() {
                                                                                                                                               // Test with predefined formats
                                                                                                                                               assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
                                                                                                                                               assertNull(CSVFormat.RFC4180.getEscapeCharacter());
                                                                                                                                               assertNull(CSVFormat.EXCEL.getEscapeCharacter());
                                                                                                                                               
                                                                                                                                               // TDF (Tab-Delimited Format) might have different settings
                                                                                                                                               Character tdfEscape = CSVFormat.TDF.getEscapeCharacter();
                                                                                                                                               assertTrue(tdfEscape == null || tdfEscape instanceof Character);
                                                                                                                                               
                                                                                                                                               // MySQL format might have backslash as escape
                                                                                                                                               assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetAllowMissingColumnNames_DefaultFormat() {
                                                                                                                                               // Test with DEFAULT format (should be false according to common CSV specifications)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetAllowMissingColumnNames_AfterWithAllowMissingColumnNames() {
                                                                                                                                               // Test the withAllowMissingColumnNames() method
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                                                                               assertFalse(original.getAllowMissingColumnNames());
                                                                                                                                               
                                                                                                                                               CSVFormat modified = original.withAllowMissingColumnNames(true);
                                                                                                                                               assertTrue(modified.getAllowMissingColumnNames());
                                                                                                                                               
                                                                                                                                               // Original should remain unchanged (immutable pattern)
                                                                                                                                               assertFalse(original.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetAllowMissingColumnNames_AfterWithAllowMissingColumnNamesNoArg() {
                                                                                                                                               // Test the no-arg withAllowMissingColumnNames() method
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                                                                               assertFalse(original.getAllowMissingColumnNames());
                                                                                                                                               
                                                                                                                                               CSVFormat modified = original.withAllowMissingColumnNames();
                                                                                                                                               assertTrue(modified.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetAllowMissingColumnNames_AllPredefinedFormats() {
                                                                                                                                               // Test all predefined formats
                                                                                                                                               assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(CSVFormat.RFC4180.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(CSVFormat.EXCEL.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(CSVFormat.TDF.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(CSVFormat.MYSQL.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_DefaultFormat() {
                                                                                                                                               // Test the default format (DEFAULT static instance)
                                                                                                                                               assertFalse("DEFAULT format should not ignore empty lines", 
                                                                                                                                                          CSVFormat.DEFAULT.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_ExcelFormat() {
                                                                                                                                               // Test the EXCEL format
                                                                                                                                               assertFalse("EXCEL format should not ignore empty lines", 
                                                                                                                                                          CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_RFC4180Format() {
                                                                                                                                               // Test the RFC4180 format
                                                                                                                                               assertFalse("RFC4180 format should not ignore empty lines", 
                                                                                                                                                          CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_TDFFormat() {
                                                                                                                                               // Test the TDF format
                                                                                                                                               assertFalse("TDF format should not ignore empty lines", 
                                                                                                                                                          CSVFormat.TDF.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_MySQLFormat() {
                                                                                                                                               // Test the MYSQL format
                                                                                                                                               assertFalse("MYSQL format should not ignore empty lines", 
                                                                                                                                                          CSVFormat.MYSQL.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_AfterWithIgnoreEmptyLinesTrue() {
                                                                                                                                               // Test after using withIgnoreEmptyLines(true)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                               assertTrue("Format after withIgnoreEmptyLines(true) should return true", 
                                                                                                                                                         format.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_AfterWithIgnoreEmptyLinesFalse() {
                                                                                                                                               // Test after using withIgnoreEmptyLines(false)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               assertFalse("Format after withIgnoreEmptyLines(false) should return false", 
                                                                                                                                                          format.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreEmptyLines_AfterWithIgnoreEmptyLines() {
                                                                                                                                               // Test after using withIgnoreEmptyLines() (no-arg version)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines();
                                                                                                                                               assertTrue("Format after withIgnoreEmptyLines() should return true", 
                                                                                                                                                         format.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_DefaultFormat() {
                                                                                                                                               // Test with the DEFAULT format instance
                                                                                                                                               assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_RFC4180Format() {
                                                                                                                                               // Test with the RFC4180 format instance
                                                                                                                                               assertFalse(CSVFormat.RFC4180.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_ExcelFormat() {
                                                                                                                                               // Test with the EXCEL format instance
                                                                                                                                               assertFalse(CSVFormat.EXCEL.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_TDFFormat() {
                                                                                                                                               // Test with the TDF format instance
                                                                                                                                               assertFalse(CSVFormat.TDF.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_MySQLFormat() {
                                                                                                                                               // Test with the MYSQL format instance
                                                                                                                                               assertFalse(CSVFormat.MYSQL.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_AfterWithIgnoreSurroundingSpacesTrue() {
                                                                                                                                               // Test with a format modified using withIgnoreSurroundingSpaces(true)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                               assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_AfterWithIgnoreSurroundingSpacesFalse() {
                                                                                                                                               // Test with a format modified using withIgnoreSurroundingSpaces(false)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                                               assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreSurroundingSpaces_AfterWithIgnoreSurroundingSpaces() {
                                                                                                                                               // Test with the convenience method that toggles the setting
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces();
                                                                                                                                               assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_DefaultFormat() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertFalse("DEFAULT format should not ignore header case", format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_ExcelFormat() {
                                                                                                                                               CSVFormat format = CSVFormat.EXCEL;
                                                                                                                                               assertFalse("EXCEL format should not ignore header case", format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_RFC4180Format() {
                                                                                                                                               CSVFormat format = CSVFormat.RFC4180;
                                                                                                                                               assertFalse("RFC4180 format should not ignore header case", format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_TDFFormat() {
                                                                                                                                               CSVFormat format = CSVFormat.TDF;
                                                                                                                                               assertFalse("TDF format should not ignore header case", format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_MySQLFormat() {
                                                                                                                                               CSVFormat format = CSVFormat.MYSQL;
                                                                                                                                               assertFalse("MYSQL format should not ignore header case", format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_WithIgnoreHeaderCaseTrue() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                               assertTrue("Format with ignoreHeaderCase set to true should return true", 
                                                                                                                                                         format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetIgnoreHeaderCase_WithIgnoreHeaderCaseFalse() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
                                                                                                                                               assertFalse("Format with ignoreHeaderCase set to false should return false", 
                                                                                                                                                          format.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetNullString_UsingDefaultFormat() {
                                                                                                                                               // Test with DEFAULT format which should have null nullString
                                                                                                                                               assertNull(CSVFormat.DEFAULT.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetNullString_UsingExcelFormat() {
                                                                                                                                               // Test with EXCEL format which should have null nullString
                                                                                                                                               assertNull(CSVFormat.EXCEL.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetNullString_UsingRFC4180Format() {
                                                                                                                                               // Test with RFC4180 format which should have null nullString
                                                                                                                                               assertNull(CSVFormat.RFC4180.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetNullString_UsingTDFFormat() {
                                                                                                                                               // Test with TDF format which should have null nullString
                                                                                                                                               assertNull(CSVFormat.TDF.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetNullString_UsingMySQLFormat() {
                                                                                                                                               // Test with MYSQL format which should have null nullString
                                                                                                                                               assertNull(CSVFormat.MYSQL.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetNullString_AfterWithNullStringModification() {
                                                                                                                                               // Create format and then modify it with withNullString
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat modified = original.withNullString("N/A");
                                                                                                                                               
                                                                                                                                               assertEquals("N/A", modified.getNullString());
                                                                                                                                               // Original should remain unchanged
                                                                                                                                               assertNull(original.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteCharacter_UsingDefaultFormat() {
                                                                                                                                               // Arrange - Using the DEFAULT static instance
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       
                                                                                                                                               // Act
                                                                                                                                               Character actualQuote = format.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(Character.valueOf('"'), actualQuote);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteCharacter_UsingExcelFormat() {
                                                                                                                                               // Arrange - Using the EXCEL static instance
                                                                                                                                               CSVFormat format = CSVFormat.EXCEL;
                                                                                                                                       
                                                                                                                                               // Act
                                                                                                                                               Character actualQuote = format.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(Character.valueOf('"'), actualQuote);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteCharacter_UsingTDFFormat() {
                                                                                                                                               // Arrange - Using the TDF static instance
                                                                                                                                               CSVFormat format = CSVFormat.TDF;
                                                                                                                                       
                                                                                                                                               // Act
                                                                                                                                               Character actualQuote = format.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(Character.valueOf('"'), actualQuote);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteCharacter_UsingMySQLFormat() {
                                                                                                                                               // Arrange - Using the MYSQL static instance
                                                                                                                                               CSVFormat format = CSVFormat.MYSQL;
                                                                                                                                       
                                                                                                                                               // Act
                                                                                                                                               Character actualQuote = format.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(Character.valueOf('\0'), actualQuote);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteCharacter_UsingRFC4180Format() {
                                                                                                                                               // Arrange - Using the RFC4180 static instance
                                                                                                                                               CSVFormat format = CSVFormat.RFC4180;
                                                                                                                                       
                                                                                                                                               // Act
                                                                                                                                               Character actualQuote = format.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(Character.valueOf('"'), actualQuote);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteCharacter_AfterModificationWithWithQuote() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character newQuote = '\'';
                                                                                                                                       
                                                                                                                                               // Act
                                                                                                                                               CSVFormat modifiedFormat = originalFormat.withQuote(newQuote);
                                                                                                                                               Character actualQuote = modifiedFormat.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(newQuote, actualQuote);
                                                                                                                                               // Verify original format wasn't modified (since CSVFormat is immutable)
                                                                                                                                               assertEquals(Character.valueOf('"'), originalFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteMode_OnDefaultInstance() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertEquals(QuoteMode.MINIMAL, CSVFormat.DEFAULT.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteMode_OnRFC4180Instance() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertEquals(QuoteMode.MINIMAL, CSVFormat.RFC4180.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteMode_OnExcelInstance() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertEquals(QuoteMode.MINIMAL, CSVFormat.EXCEL.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteMode_OnTDFInstance() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertEquals(QuoteMode.MINIMAL, CSVFormat.TDF.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteMode_OnMySQLInstance() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertEquals(QuoteMode.NONE, CSVFormat.MYSQL.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetQuoteMode_AfterWithQuoteMode() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat modified = original.withQuoteMode(QuoteMode.ALL);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                                                                               assertEquals(QuoteMode.MINIMAL, original.getQuoteMode()); // original unchanged
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetRecordSeparator_DefaultFormat() {
                                                                                                                                               // Test with DEFAULT format which should have system line separator
                                                                                                                                               String expected = System.lineSeparator();
                                                                                                                                               assertEquals(expected, CSVFormat.DEFAULT.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetRecordSeparator_RFC4180Format() {
                                                                                                                                               // Test with RFC4180 format which should have CRLF separator
                                                                                                                                               assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetRecordSeparator_ExcelFormat() {
                                                                                                                                               // Test with EXCEL format which should have CRLF separator
                                                                                                                                               assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetRecordSeparator_TabDelimitedFormat() {
                                                                                                                                               // Test with TDF format which should have system line separator
                                                                                                                                               String expected = System.lineSeparator();
                                                                                                                                               assertEquals(expected, CSVFormat.TDF.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetRecordSeparator_MySQLFormat() {
                                                                                                                                               // Test with MYSQL format which should have LF separator
                                                                                                                                               assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetRecordSeparator_AfterModificationWithWithRecordSeparator() {
                                                                                                                                               // Test that withRecordSeparator creates a new instance with the new separator
                                                                                                                                               String originalSeparator = CSVFormat.DEFAULT.getRecordSeparator();
                                                                                                                                               String newSeparator = "||";
                                                                                                                                               
                                                                                                                                               CSVFormat modifiedFormat = CSVFormat.DEFAULT.withRecordSeparator(newSeparator);
                                                                                                                                               
                                                                                                                                               assertEquals(newSeparator, modifiedFormat.getRecordSeparator());
                                                                                                                                               // Original format should remain unchanged
                                                                                                                                               assertEquals(originalSeparator, CSVFormat.DEFAULT.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_DefaultFormat() {
                                                                                                                                               // Test the DEFAULT format instance
                                                                                                                                               assertFalse("DEFAULT format should have skipHeaderRecord as false", 
                                                                                                                                                          CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_ExcelFormat() {
                                                                                                                                               // Test the EXCEL format instance
                                                                                                                                               assertFalse("EXCEL format should have skipHeaderRecord as false", 
                                                                                                                                                          CSVFormat.EXCEL.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_RFC4180Format() {
                                                                                                                                               // Test the RFC4180 format instance
                                                                                                                                               assertFalse("RFC4180 format should have skipHeaderRecord as false", 
                                                                                                                                                          CSVFormat.RFC4180.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_TDFFormat() {
                                                                                                                                               // Test the TDF format instance
                                                                                                                                               assertFalse("TDF format should have skipHeaderRecord as false", 
                                                                                                                                                          CSVFormat.TDF.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_MySQLFormat() {
                                                                                                                                               // Test the MYSQL format instance
                                                                                                                                               assertFalse("MYSQL format should have skipHeaderRecord as false", 
                                                                                                                                                          CSVFormat.MYSQL.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_AfterWithSkipHeaderRecord() {
                                                                                                                                               // Test after using withSkipHeaderRecord() method
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                                               
                                                                                                                                               assertFalse("Original format should remain unchanged", 
                                                                                                                                                          original.getSkipHeaderRecord());
                                                                                                                                               assertTrue("Modified format should have skipHeaderRecord as true", 
                                                                                                                                                         modified.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testGetSkipHeaderRecord_AfterWithSkipHeaderRecordFalse() {
                                                                                                                                               // Test after using withSkipHeaderRecord(false) method
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               CSVFormat modified = original.withSkipHeaderRecord(false);
                                                                                                                                               
                                                                                                                                               assertTrue("Original format should remain unchanged", 
                                                                                                                                                         original.getSkipHeaderRecord());
                                                                                                                                               assertFalse("Modified format should have skipHeaderRecord as false", 
                                                                                                                                                          modified.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testHashCode_EqualsObjectsHaveSameHashCode() {
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                                   .withRecordSeparator("\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("col1", "col2")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                                   
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                                   .withRecordSeparator("\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("col1", "col2")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                                   
                                                                                                                                               assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testHashCode_DifferentObjectsDifferentHashCodes() {
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                                                                               
                                                                                                                                               assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testHashCode_BooleanFieldsImpactHashCode() {
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withSkipHeaderRecord(true);
                                                                                                                                                   
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                                                                   .withIgnoreSurroundingSpaces(false)
                                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                                   .withSkipHeaderRecord(false);
                                                                                                                                                   
                                                                                                                                               assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testHashCode_HeaderArrayImpactsHashCode() {
                                                                                                                                               CSVFormat format1 = CSVFormat.newFormat(',').withHeader("a", "b");
                                                                                                                                               CSVFormat format2 = CSVFormat.newFormat(',').withHeader("x", "y");
                                                                                                                                               
                                                                                                                                               assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsCommentMarkerSet_AfterModificationWithWithCommentMarker() {
                                                                                                                                               // Start with default format (which typically has no comment marker)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertFalse("Default format should have no comment marker", 
                                                                                                                                                          format.isCommentMarkerSet());
                                                                                                                                               
                                                                                                                                               // Modify with a comment marker
                                                                                                                                               CSVFormat modifiedFormat = format.withCommentMarker('#');
                                                                                                                                               assertTrue("Should return true after setting comment marker", 
                                                                                                                                                         modifiedFormat.isCommentMarkerSet());
                                                                                                                                               
                                                                                                                                               // Modify back to null
                                                                                                                                               CSVFormat resetFormat = modifiedFormat.withCommentMarker(null);
                                                                                                                                               assertFalse("Should return false after resetting comment marker to null", 
                                                                                                                                                          resetFormat.isCommentMarkerSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsEscapeCharacterSet_UsingPredefinedFormats() {
                                                                                                                                               // Test with DEFAULT format (which typically has null escape character)
                                                                                                                                               assertFalse("DEFAULT format should have null escape character", 
                                                                                                                                                          CSVFormat.DEFAULT.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Test with RFC4180 format (which typically has null escape character)
                                                                                                                                               assertFalse("RFC4180 format should have null escape character", 
                                                                                                                                                          CSVFormat.RFC4180.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Test with EXCEL format (which typically has null escape character)
                                                                                                                                               assertFalse("EXCEL format should have null escape character", 
                                                                                                                                                          CSVFormat.EXCEL.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Test with TDF format (which might have an escape character)
                                                                                                                                               // Note: Actual behavior depends on implementation, adjust if needed
                                                                                                                                               assertFalse("TDF format should have null escape character", 
                                                                                                                                                          CSVFormat.TDF.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Test with MYSQL format (which might have an escape character)
                                                                                                                                               // Note: Actual behavior depends on implementation, adjust if needed
                                                                                                                                               assertFalse("MYSQL format should have null escape character", 
                                                                                                                                                          CSVFormat.MYSQL.isEscapeCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsEscapeCharacterSet_AfterModification() {
                                                                                                                                               // Create format with null escape character
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               assertFalse("Initial format should have null escape character", 
                                                                                                                                                          format.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Modify with non-null escape character
                                                                                                                                               format = format.withEscape('\\');
                                                                                                                                               assertTrue("After withEscape, should return true", 
                                                                                                                                                        format.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Modify back to null escape character
                                                                                                                                               format = format.withEscape(null);
                                                                                                                                               assertFalse("After setting escape to null, should return false", 
                                                                                                                                                         format.isEscapeCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_AfterWithNullStringCalledWithNull() {
                                                                                                                                               // Create a default CSVFormat and then call withNullString(null)
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                                               assertFalse("Should return false after withNullString(null)", format.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_AfterWithNullStringCalledWithValue() {
                                                                                                                                               // Create a default CSVFormat and then call withNullString("NULL")
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                                                               assertTrue("Should return true after withNullString(\"NULL\")", format.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_OnDefaultFormat() {
                                                                                                                                               // Test the default format's nullString setting
                                                                                                                                               assertFalse("Default format should have null nullString", CSVFormat.DEFAULT.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_OnRFC4180Format() {
                                                                                                                                               // Test the RFC4180 format's nullString setting
                                                                                                                                               assertFalse("RFC4180 format should have null nullString", CSVFormat.RFC4180.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_OnExcelFormat() {
                                                                                                                                               // Test the Excel format's nullString setting
                                                                                                                                               assertFalse("Excel format should have null nullString", CSVFormat.EXCEL.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_OnTDFFormat() {
                                                                                                                                               // Test the TDF format's nullString setting
                                                                                                                                               assertFalse("TDF format should have null nullString", CSVFormat.TDF.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsNullStringSet_OnMySQLFormat() {
                                                                                                                                               // Test the MySQL format's nullString setting
                                                                                                                                               assertFalse("MySQL format should have null nullString", CSVFormat.MYSQL.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_WithDefaultFormat() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_WithRFC4180Format() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertTrue(CSVFormat.RFC4180.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_WithExcelFormat() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertTrue(CSVFormat.EXCEL.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_WithTDFFormat() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertTrue(CSVFormat.TDF.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_WithMySQLFormat() {
                                                                                                                                               // Act & Assert
                                                                                                                                               assertTrue(CSVFormat.MYSQL.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_AfterSettingQuoteCharacter() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               
                                                                                                                                               // Act & Assert
                                                                                                                                               assertTrue(format.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testIsQuoteCharacterSet_AfterRemovingQuoteCharacter() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                               
                                                                                                                                               // Act & Assert
                                                                                                                                               assertFalse(format.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testParse_WithNullReader() throws IOException {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(NullPointerException.class);
                                                                                                                                               thrown.expectMessage("in");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               format.parse(null);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testPrint_WithNullWriter() throws IOException {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("Parameter 'out' must not be null!");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               format.print(null);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testPrint_WithWriterThatThrowsIOException() throws IOException {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               Appendable faultyAppendable = mock(Appendable.class);
                                                                                                                                               when(faultyAppendable.append(anyChar())).thenThrow(new IOException("Test exception"));
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IOException.class);
                                                                                                                                               thrown.expectMessage("Test exception");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               format.print(faultyAppendable);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_DefaultFormat() {
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertTrue(result.startsWith("Delimiter=<,>"));
                                                                                                                                               assertTrue(result.contains("QuoteChar=<\">"));
                                                                                                                                               assertFalse(result.contains("Escape="));
                                                                                                                                               assertFalse(result.contains("CommentStart="));
                                                                                                                                               assertFalse(result.contains("NullString="));
                                                                                                                                               assertFalse(result.contains("RecordSeparator="));
                                                                                                                                               assertFalse(result.contains("EmptyLines:ignored"));
                                                                                                                                               assertFalse(result.contains("SurroundingSpaces:ignored"));
                                                                                                                                               assertFalse(result.contains("IgnoreHeaderCase:ignored"));
                                                                                                                                               assertTrue(result.contains("SkipHeaderRecord:false"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_WithAllFeatures() {
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withIgnoreEmptyLines()
                                                                                                                                                   .withIgnoreSurroundingSpaces()
                                                                                                                                                   .withIgnoreHeaderCase()
                                                                                                                                                   .withSkipHeaderRecord()
                                                                                                                                                   .withHeaderComments("HeaderComment1", "HeaderComment2")
                                                                                                                                                   .withHeader("Col1", "Col2");
                                                                                                                                               
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertTrue(result.startsWith("Delimiter=<;>"));
                                                                                                                                               assertTrue(result.contains("Escape=<\\>"));
                                                                                                                                               assertTrue(result.contains("QuoteChar=<\">"));
                                                                                                                                               assertTrue(result.contains("CommentStart=<#>"));
                                                                                                                                               assertTrue(result.contains("NullString=<NULL>"));
                                                                                                                                               assertTrue(result.contains("RecordSeparator=<\r\n>"));
                                                                                                                                               assertTrue(result.contains("EmptyLines:ignored"));
                                                                                                                                               assertTrue(result.contains("SurroundingSpaces:ignored"));
                                                                                                                                               assertTrue(result.contains("IgnoreHeaderCase:ignored"));
                                                                                                                                               assertTrue(result.contains("SkipHeaderRecord:true"));
                                                                                                                                               assertTrue(result.contains("HeaderComments:[HeaderComment1, HeaderComment2]"));
                                                                                                                                               assertTrue(result.contains("Header:[Col1, Col2]"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_WithOnlyDelimiter() {
                                                                                                                                               CSVFormat format = CSVFormat.newFormat('\t');
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertEquals("Delimiter=<\t> SkipHeaderRecord:false", result);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_WithQuoteAndEscape() {
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                   .withQuote('\'')
                                                                                                                                                   .withEscape('!');
                                                                                                                                               
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertTrue(result.startsWith("Delimiter=<,>"));
                                                                                                                                               assertTrue(result.contains("Escape=<!>"));
                                                                                                                                               assertTrue(result.contains("QuoteChar=<'>"));
                                                                                                                                               assertFalse(result.contains("CommentStart="));
                                                                                                                                               assertFalse(result.contains("NullString="));
                                                                                                                                               assertFalse(result.contains("RecordSeparator="));
                                                                                                                                               assertFalse(result.contains("EmptyLines:ignored"));
                                                                                                                                               assertFalse(result.contains("SurroundingSpaces:ignored"));
                                                                                                                                               assertFalse(result.contains("IgnoreHeaderCase:ignored"));
                                                                                                                                               assertTrue(result.contains("SkipHeaderRecord:false"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_WithNullStringAndRecordSeparator() {
                                                                                                                                               CSVFormat format = CSVFormat.newFormat('|')
                                                                                                                                                   .withNullString("\\N")
                                                                                                                                                   .withRecordSeparator("\n");
                                                                                                                                               
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertTrue(result.startsWith("Delimiter=<|>"));
                                                                                                                                               assertFalse(result.contains("Escape="));
                                                                                                                                               assertFalse(result.contains("QuoteChar="));
                                                                                                                                               assertFalse(result.contains("CommentStart="));
                                                                                                                                               assertTrue(result.contains("NullString=<\\N>"));
                                                                                                                                               assertTrue(result.contains("RecordSeparator=<\n>"));
                                                                                                                                               assertFalse(result.contains("EmptyLines:ignored"));
                                                                                                                                               assertFalse(result.contains("SurroundingSpaces:ignored"));
                                                                                                                                               assertFalse(result.contains("IgnoreHeaderCase:ignored"));
                                                                                                                                               assertTrue(result.contains("SkipHeaderRecord:false"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_WithEmptyHeaderAndComments() {
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                   .withHeaderComments(new String[0])
                                                                                                                                                   .withHeader(new String[0]);
                                                                                                                                               
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertTrue(result.startsWith("Delimiter=<,>"));
                                                                                                                                               assertTrue(result.contains("HeaderComments:[]"));
                                                                                                                                               assertTrue(result.contains("Header:[]"));
                                                                                                                                               assertTrue(result.contains("SkipHeaderRecord:false"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testToString_WithNullHeaderAndComments() {
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                                   .withHeaderComments((Object[])null)
                                                                                                                                                   .withHeader((String[])null);
                                                                                                                                               
                                                                                                                                               String result = format.toString();
                                                                                                                                               
                                                                                                                                               assertTrue(result.startsWith("Delimiter=<,>"));
                                                                                                                                               assertFalse(result.contains("HeaderComments:"));
                                                                                                                                               assertFalse(result.contains("Header:"));
                                                                                                                                               assertTrue(result.contains("SkipHeaderRecord:false"));
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_LineBreakCharacter() {
                                                                                                                                               // Setup original format
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Expect exception when using line break as comment marker
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The comment start character cannot be a line break");
                                                                                                                                               
                                                                                                                                               // Test with line break character
                                                                                                                                               original.withCommentMarker('\n');
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_ValidCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character commentMarker = '#';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.isCommentMarkerSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_NullMarker() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withCommentMarker((Character) null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNull(newFormat.getCommentMarker());
                                                                                                                                               assertFalse(newFormat.isCommentMarkerSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_LineBreakCharacter_ThrowsException() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character lineBreak = '\n';
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               originalFormat.withCommentMarker(lineBreak);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_CarriageReturn_ThrowsException() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character carriageReturn = '\r';
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               originalFormat.withCommentMarker(carriageReturn);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_OtherPropertiesPreserved() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                                                                   .withDelimiter(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("col1", "col2")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                               
                                                                                                                                               Character commentMarker = '!';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                                                                               
                                                                                                                                               // Verify all other properties are preserved
                                                                                                                                               assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                                               assertEquals(';', newFormat.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                                                               assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                                                               assertEquals("NULL", newFormat.getNullString());
                                                                                                                                               assertArrayEquals(new String[]{"col1", "col2"}, newFormat.getHeader());
                                                                                                                                               assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                                               assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithCommentMarker_SameMarkerReturnsSameInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withCommentMarker('#');
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertSame(originalFormat, newFormat);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithDelimiter_LineBreakCharacters() {
                                                                                                                                               // Setup base format
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test with various line break characters
                                                                                                                                               char[] lineBreaks = {'\n', '\r', '\u2028', '\u2029'};
                                                                                                                                               
                                                                                                                                               for (char lineBreak : lineBreaks) {
                                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                                   thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                                                   baseFormat.withDelimiter(lineBreak);
                                                                                                                                               }
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithDelimiter_SpecialCharacters() {
                                                                                                                                               // Test with special characters that might be used as delimiters
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               char[] specialChars = {'\u0001', '\u001F', '~', '!', '@', '$', '%', '^', '&', '*'};
                                                                                                                                               
                                                                                                                                               for (char specialChar : specialChars) {
                                                                                                                                                   CSVFormat newFormat = baseFormat.withDelimiter(specialChar);
                                                                                                                                                   assertEquals(specialChar, newFormat.getDelimiter());
                                                                                                                                               }
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithDelimiter_NullCharacter() {
                                                                                                                                               // Test with null character (0x00)
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               CSVFormat newFormat = baseFormat.withDelimiter('\0');
                                                                                                                                               assertEquals('\0', newFormat.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithDelimiter_UnicodeCharacters() {
                                                                                                                                               // Test with various Unicode characters
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               char[] unicodeChars = {'§', '©', '®', 'µ', '¶', '†', '‡', '•', '◊'};
                                                                                                                                               
                                                                                                                                               for (char unicodeChar : unicodeChars) {
                                                                                                                                                   CSVFormat newFormat = baseFormat.withDelimiter(unicodeChar);
                                                                                                                                                   assertEquals(unicodeChar, newFormat.getDelimiter());
                                                                                                                                               }
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_NonNullCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character escapeChar = '\\';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertEquals(escapeChar, newFormat.getEscapeCharacter());
                                                                                                                                               assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_NullCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withEscape(null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertNull(newFormat.getEscapeCharacter());
                                                                                                                                               assertFalse(newFormat.isEscapeCharacterSet());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_SameCharacterReturnsSameInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat formatWithEscape = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = formatWithEscape.withEscape('\\');
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertSame(formatWithEscape, newFormat);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_DifferentCharacterReturnsNewInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat formatWithEscape = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = formatWithEscape.withEscape('/');
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(formatWithEscape, newFormat);
                                                                                                                                               assertEquals(Character.valueOf('/'), newFormat.getEscapeCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_FromNoEscapeToWithEscape() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat formatWithoutEscape = CSVFormat.DEFAULT.withEscape(null);
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = formatWithoutEscape.withEscape('\\');
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(formatWithoutEscape, newFormat);
                                                                                                                                               assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                                                               assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_FromEscapeToNoEscape() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat formatWithEscape = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = formatWithEscape.withEscape(null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(formatWithEscape, newFormat);
                                                                                                                                               assertNull(newFormat.getEscapeCharacter());
                                                                                                                                               assertFalse(newFormat.isEscapeCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_VerifyImmutability() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character originalEscape = originalFormat.getEscapeCharacter();
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withEscape('\\');
                                                                                                                                               
                                                                                                                                               // Verify original format unchanged
                                                                                                                                               assertEquals(originalEscape, originalFormat.getEscapeCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_ValidCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char escapeChar = '\\';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = original.withEscape(escapeChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertEquals(Character.valueOf(escapeChar), newFormat.getEscapeCharacter());
                                                                                                                                               assertNotSame(original, newFormat); // Should return a new instance
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_NullCharacter1() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = original.withEscape((Character) null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNull(newFormat.getEscapeCharacter());
                                                                                                                                               assertNotSame(original, newFormat);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_LineBreakCharacter_ShouldThrowException() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char lineBreak = '\n';
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The escape character cannot be a line break");
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               original.withEscape(lineBreak);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_OtherParametersRemainSame() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char escapeChar = '\\';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = original.withEscape(escapeChar);
                                                                                                                                               
                                                                                                                                               // Verify other parameters remain unchanged
                                                                                                                                               assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(original.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(original.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(original.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(original.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(original.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(original.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertArrayEquals(original.getHeader(), newFormat.getHeader());
                                                                                                                                               assertEquals(original.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                               assertEquals(original.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(original.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_AllOtherMethodsShouldWorkWithNewEscape() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char escapeChar = '\\';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = original.withEscape(escapeChar);
                                                                                                                                               
                                                                                                                                               // Verify the new escape character is properly set and used
                                                                                                                                               assertEquals(Character.valueOf(escapeChar), newFormat.getEscapeCharacter());
                                                                                                                                               assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithEscape_FromFormatWithDifferentSettings() {
                                                                                                                                               // Setup - create a format with non-default settings
                                                                                                                                               CSVFormat original = CSVFormat.newFormat('|')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeaderComments("Comment1", "Comment2")
                                                                                                                                                   .withHeader("Col1", "Col2")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withAllowMissingColumnNames(true)
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                               
                                                                                                                                               char escapeChar = '\\';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = original.withEscape(escapeChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertEquals(Character.valueOf(escapeChar), newFormat.getEscapeCharacter());
                                                                                                                                               // Verify all other settings remain the same
                                                                                                                                               assertEquals('|', newFormat.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                                                               assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                                                               assertEquals("NULL", newFormat.getNullString());
                                                                                                                                               assertArrayEquals(new String[]{"Comment1", "Comment2"}, newFormat.getHeaderComments());
                                                                                                                                               assertArrayEquals(new String[]{"Col1", "Col2"}, newFormat.getHeader());
                                                                                                                                               assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                                               assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_NullHeader() {
                                                                                                                                               // Setup base format
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test with null header
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader((String[]) null);
                                                                                                                                               
                                                                                                                                               // Verify header is null
                                                                                                                                               assertNull(newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_EmptyHeader() {
                                                                                                                                               // Setup base format
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test with empty header
                                                                                                                                               String[] emptyHeader = {};
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(emptyHeader);
                                                                                                                                               
                                                                                                                                               // Verify header is empty
                                                                                                                                               assertArrayEquals(emptyHeader, newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_HeaderWithEmptyStrings() {
                                                                                                                                               // Setup base format
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test with header containing empty strings
                                                                                                                                               String[] headerWithEmpty = {"", "Field1", "", "Field2"};
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(headerWithEmpty);
                                                                                                                                               
                                                                                                                                               // Verify header is set correctly
                                                                                                                                               assertArrayEquals(headerWithEmpty, newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_HeaderWithNullElements() {
                                                                                                                                               // Setup base format
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test with header containing null elements
                                                                                                                                               String[] headerWithNull = {"Field1", null, "Field2"};
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(headerWithNull);
                                                                                                                                               
                                                                                                                                               // Verify header is set correctly (null elements should be preserved)
                                                                                                                                               assertArrayEquals(headerWithNull, newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_HeaderIsCloned() {
                                                                                                                                               // Setup base format
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test with header
                                                                                                                                               String[] originalHeader = {"A", "B", "C"};
                                                                                                                                               String[] headerToPass = originalHeader.clone();
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(headerToPass);
                                                                                                                                               
                                                                                                                                               // Modify the original array
                                                                                                                                               headerToPass[0] = "X";
                                                                                                                                               
                                                                                                                                               // Verify the format's header wasn't affected
                                                                                                                                               assertArrayEquals(originalHeader, newFormat.getHeader());
                                                                                                                                               assertNotSame(originalHeader, newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_ResultSet_NonNullResultSet() throws Exception {
                                                                                                                                               // Setup
                                                                                                                                               ResultSet mockResultSet = mock(ResultSet.class);
                                                                                                                                               ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
                                                                                                                                               
                                                                                                                                               // Create a base format to test with
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(mockResultSet);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNotSame(baseFormat, newFormat);
                                                                                                                                               verify(mockResultSet).getMetaData();
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_ResultSet_NullResultSet() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_ResultSet_ResultSetThrowsException() throws Exception {
                                                                                                                                               // Setup
                                                                                                                                               ResultSet mockResultSet = mock(ResultSet.class);
                                                                                                                                               when(mockResultSet.getMetaData()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                               
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(RuntimeException.class);
                                                                                                                                               thrown.expectMessage("Test exception");
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               baseFormat.withHeader(mockResultSet);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_ResultSet_VerifyHeaderContent() throws Exception {
                                                                                                                                               // Setup
                                                                                                                                               ResultSet mockResultSet = mock(ResultSet.class);
                                                                                                                                               ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
                                                                                                                                               when(mockMetaData.getColumnCount()).thenReturn(3);
                                                                                                                                               when(mockMetaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                                                                               when(mockMetaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                                                                               when(mockMetaData.getColumnLabel(3)).thenReturn("Column3");
                                                                                                                                               
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(mockResultSet);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertArrayEquals(new String[]{"Column1", "Column2", "Column3"}, newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_ResultSet_EmptyResultSet() throws Exception {
                                                                                                                                               // Setup
                                                                                                                                               ResultSet mockResultSet = mock(ResultSet.class);
                                                                                                                                               ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
                                                                                                                                               when(mockMetaData.getColumnCount()).thenReturn(0);
                                                                                                                                               
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               CSVFormat newFormat = baseFormat.withHeader(mockResultSet);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat.getHeader());
                                                                                                                                               assertEquals(0, newFormat.getHeader().length);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_WithNullMetaData() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeader((ResultSetMetaData) null);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNull(newFormat.getHeader());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               // Verify other properties are preserved
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_WithEmptyResultSetMetaData() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(metaData.getColumnCount()).thenReturn(0);
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeader(metaData);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotNull(newFormat.getHeader());
                                                                                                                                               assertEquals(0, newFormat.getHeader().length);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_WithSingleColumnMetaData() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(metaData.getColumnCount()).thenReturn(1);
                                                                                                                                               when(metaData.getColumnLabel(1)).thenReturn("id");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeader(metaData);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotNull(newFormat.getHeader());
                                                                                                                                               assertEquals(1, newFormat.getHeader().length);
                                                                                                                                               assertEquals("id", newFormat.getHeader()[0]);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_WithMultipleColumnsMetaData() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(metaData.getColumnCount()).thenReturn(3);
                                                                                                                                               when(metaData.getColumnLabel(1)).thenReturn("id");
                                                                                                                                               when(metaData.getColumnLabel(2)).thenReturn("name");
                                                                                                                                               when(metaData.getColumnLabel(3)).thenReturn("age");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeader(metaData);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotNull(newFormat.getHeader());
                                                                                                                                               assertEquals(3, newFormat.getHeader().length);
                                                                                                                                               assertArrayEquals(new String[]{"id", "name", "age"}, newFormat.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_PreservesOtherFormatSettings() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.newFormat('|')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withAllowMissingColumnNames(true)
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                               
                                                                                                                                               ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                               when(metaData.getColumnLabel(1)).thenReturn("col1");
                                                                                                                                               when(metaData.getColumnLabel(2)).thenReturn("col2");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeader(metaData);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertEquals('|', newFormat.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                                                               assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                                                               assertEquals("NULL", newFormat.getNullString());
                                                                                                                                               assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                                               assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_WithNullColumnLabels() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(metaData.getColumnCount()).thenReturn(2);
                                                                                                                                               when(metaData.getColumnLabel(1)).thenReturn(null);
                                                                                                                                               when(metaData.getColumnLabel(2)).thenReturn("valid");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeader(metaData);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotNull(newFormat.getHeader());
                                                                                                                                               assertEquals(2, newFormat.getHeader().length);
                                                                                                                                               assertNull(newFormat.getHeader()[0]);
                                                                                                                                               assertEquals("valid", newFormat.getHeader()[1]);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeader_ThrowsExceptionWhenMetaDataFails() throws Exception {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                                                                               when(metaData.getColumnCount()).thenThrow(new RuntimeException("Test exception"));
                                                                                                                                               
                                                                                                                                               thrown.expect(RuntimeException.class);
                                                                                                                                               thrown.expectMessage("Test exception");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               originalFormat.withHeader(metaData);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithValidComments() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Object[] comments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertArrayEquals(new String[]{"Comment1", "Comment2"}, newFormat.getHeaderComments());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithNullComments() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments((Object[])null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertNull(newFormat.getHeaderComments());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithEmptyComments() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Object[] comments = new Object[0];
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertNotNull(newFormat.getHeaderComments());
                                                                                                                                               assertEquals(0, newFormat.getHeaderComments().length);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithMixedTypeComments() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Object[] comments = new Object[]{"String", 123, true};
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertArrayEquals(new String[]{"String", "123", "true"}, newFormat.getHeaderComments());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithNullElementsInComments() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Object[] comments = new Object[]{"Valid", null, "Another"};
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertArrayEquals(new String[]{"Valid", null, "Another"}, newFormat.getHeaderComments());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithVeryLongComment() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               String longComment = new String(new char[10000]).replace('\0', 'x');
                                                                                                                                               Object[] comments = new Object[]{longComment};
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertEquals(1, newFormat.getHeaderComments().length);
                                                                                                                                               assertEquals(longComment, newFormat.getHeaderComments()[0]);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_WithSpecialCharacters() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Object[] comments = new Object[]{"Comment with \n newline", "Comment with \t tab", "Comment with \" quote"};
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertArrayEquals(comments, newFormat.getHeaderComments());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithHeaderComments_VerifyImmutability() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Object[] comments = new Object[]{"Comment1", "Comment2"};
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withHeaderComments(comments);
                                                                                                                                               
                                                                                                                                               // Modify the original array
                                                                                                                                               comments[0] = "Modified";
                                                                                                                                               
                                                                                                                                               // Verify the new format wasn't affected
                                                                                                                                               assertArrayEquals(new String[]{"Comment1", "Comment2"}, newFormat.getHeaderComments());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithAllowMissingColumnNames_NoParameter_ShouldReturnNewInstanceWithTrue() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withAllowMissingColumnNames();
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(false, originalFormat.getAllowMissingColumnNames()); // Original should remain unchanged
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithAllowMissingColumnNames_True_ShouldReturnNewInstanceWithTrue() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(false, originalFormat.getAllowMissingColumnNames()); // Original should remain unchanged
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithAllowMissingColumnNames_False_ShouldReturnNewInstanceWithFalse() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(false);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(false, originalFormat.getAllowMissingColumnNames()); // Original should remain unchanged
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithAllowMissingColumnNames_WhenCalledMultipleTimes_ShouldCreateNewInstanceEachTime() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat format2 = format1.withAllowMissingColumnNames();
                                                                                                                                               CSVFormat format3 = format2.withAllowMissingColumnNames(false);
                                                                                                                                               CSVFormat format4 = format3.withAllowMissingColumnNames(true);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertNotSame(format1, format2);
                                                                                                                                               assertNotSame(format2, format3);
                                                                                                                                               assertNotSame(format3, format4);
                                                                                                                                               assertFalse(format1.getAllowMissingColumnNames());
                                                                                                                                               assertTrue(format2.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(format3.getAllowMissingColumnNames());
                                                                                                                                               assertTrue(format4.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithAllowMissingColumnNames_ShouldPreserveOtherProperties() {
                                                                                                                                               // Arrange
                                                                                                                                               CSVFormat originalFormat = CSVFormat.newFormat('|')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                                   .withHeader("Col1", "Col2");
                                                                                                                                               
                                                                                                                                               // Act
                                                                                                                                               CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                                                                               
                                                                                                                                               // Assert
                                                                                                                                               assertEquals('|', newFormat.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                                                               assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertArrayEquals(new String[]{"Col1", "Col2"}, newFormat.getHeader());
                                                                                                                                               assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithAllowMissingColumnNamesBoolean() {
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test setting to true
                                                                                                                                               CSVFormat trueFormat = baseFormat.withAllowMissingColumnNames(true);
                                                                                                                                               assertTrue(trueFormat.getAllowMissingColumnNames());
                                                                                                                                               
                                                                                                                                               // Test setting to false
                                                                                                                                               CSVFormat falseFormat = baseFormat.withAllowMissingColumnNames(false);
                                                                                                                                               assertFalse(falseFormat.getAllowMissingColumnNames());
                                                                                                                                               
                                                                                                                                               // Verify original format unchanged
                                                                                                                                               assertFalse(baseFormat.getAllowMissingColumnNames());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_DefaultTrue() {
                                                                                                                                               // Create a base format with ignoreEmptyLines = false
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               assertFalse(baseFormat.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Test the parameterless version
                                                                                                                                               CSVFormat modifiedFormat = baseFormat.withIgnoreEmptyLines();
                                                                                                                                               assertTrue(modifiedFormat.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(baseFormat.getDelimiter(), modifiedFormat.getDelimiter());
                                                                                                                                               assertEquals(baseFormat.getQuoteCharacter(), modifiedFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(baseFormat.getRecordSeparator(), modifiedFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_True() {
                                                                                                                                               // Create a base format with ignoreEmptyLines = false
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               assertFalse(baseFormat.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Test setting to true
                                                                                                                                               CSVFormat modifiedFormat = baseFormat.withIgnoreEmptyLines(true);
                                                                                                                                               assertTrue(modifiedFormat.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(baseFormat.getDelimiter(), modifiedFormat.getDelimiter());
                                                                                                                                               assertEquals(baseFormat.getQuoteCharacter(), modifiedFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(baseFormat.getRecordSeparator(), modifiedFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_False() {
                                                                                                                                               // Create a base format with ignoreEmptyLines = true
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                               assertTrue(baseFormat.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Test setting to false
                                                                                                                                               CSVFormat modifiedFormat = baseFormat.withIgnoreEmptyLines(false);
                                                                                                                                               assertFalse(modifiedFormat.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(baseFormat.getDelimiter(), modifiedFormat.getDelimiter());
                                                                                                                                               assertEquals(baseFormat.getQuoteCharacter(), modifiedFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(baseFormat.getRecordSeparator(), modifiedFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_Immutable() {
                                                                                                                                               // Verify that the original format remains unchanged after modification
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                               
                                                                                                                                               assertNotSame(original, modified);
                                                                                                                                               assertFalse(original.getIgnoreEmptyLines()); // DEFAULT format has ignoreEmptyLines = false
                                                                                                                                               assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_True1() {
                                                                                                                                               // Setup original format with ignoreEmptyLines = false
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                               
                                                                                                                                               // Verify new format has ignoreEmptyLines = true
                                                                                                                                               assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Verify all other properties remain unchanged
                                                                                                                                               assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                               assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                               assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                               assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                               assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                               assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                               assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                               assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                               assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_False1() {
                                                                                                                                               // Setup original format with ignoreEmptyLines = true
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                                                               
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = original.withIgnoreEmptyLines(false);
                                                                                                                                               
                                                                                                                                               // Verify new format has ignoreEmptyLines = false
                                                                                                                                               assertFalse(modified.getIgnoreEmptyLines());
                                                                                                                                               
                                                                                                                                               // Verify all other properties remain unchanged
                                                                                                                                               assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                               assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                               assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                               assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                               assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                               assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                               assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                               assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                               assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_DefaultFormat() {
                                                                                                                                               // Test with DEFAULT format (which has ignoreEmptyLines = true)
                                                                                                                                               CSVFormat modified = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               
                                                                                                                                               assertFalse(modified.getIgnoreEmptyLines());
                                                                                                                                               assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines()); // Original unchanged
                                                                                                                                               
                                                                                                                                               // Verify other DEFAULT properties are preserved
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_NoParameter() {
                                                                                                                                               // Test the no-parameter version which should toggle to true
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               CSVFormat modified = original.withIgnoreEmptyLines();
                                                                                                                                               
                                                                                                                                               assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreEmptyLines_Immutable1() {
                                                                                                                                               // Verify that original format is not modified
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                                                               CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                                                               
                                                                                                                                               assertNotSame(original, modified);
                                                                                                                                               assertFalse(original.getIgnoreEmptyLines());
                                                                                                                                               assertTrue(modified.getIgnoreEmptyLines());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreSurroundingSpaces_True() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Exercise
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               // Verify other properties remain the same
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                               assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreSurroundingSpaces_False() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                               
                                                                                                                                               // Exercise
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(false);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               // Verify other properties remain the same
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreSurroundingSpaces_NoArg() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                                                               
                                                                                                                                               // Exercise
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces();
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               // Verify other properties remain the same
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreSurroundingSpaces_Immutable() {
                                                                                                                                               // Verify that the original format remains unchanged
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                                                               
                                                                                                                                               assertFalse(originalFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreSurroundingSpaces_FromDifferentFormat() {
                                                                                                                                               // Test with a format different from DEFAULT
                                                                                                                                               CSVFormat originalFormat = CSVFormat.EXCEL;
                                                                                                                                               
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                                                               
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreSurroundingSpaces() {
                                                                                                                                               // Create a base format with known settings
                                                                                                                                               CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                                                                   .withDelimiter(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.ALL)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("Name", "Age")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withAllowMissingColumnNames(false)
                                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                                               
                                                                                                                                               // Test setting ignoreSurroundingSpaces to true
                                                                                                                                               CSVFormat formatWithSpacesTrue = baseFormat.withIgnoreSurroundingSpaces(true);
                                                                                                                                               assertTrue(formatWithSpacesTrue.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(';', formatWithSpacesTrue.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('"'), formatWithSpacesTrue.getQuoteCharacter());
                                                                                                                                               assertEquals(QuoteMode.ALL, formatWithSpacesTrue.getQuoteMode());
                                                                                                                                               assertEquals(Character.valueOf('#'), formatWithSpacesTrue.getCommentMarker());
                                                                                                                                               assertEquals(Character.valueOf('\\'), formatWithSpacesTrue.getEscapeCharacter());
                                                                                                                                               assertFalse(formatWithSpacesTrue.getIgnoreEmptyLines());
                                                                                                                                               assertEquals("\r\n", formatWithSpacesTrue.getRecordSeparator());
                                                                                                                                               assertEquals("NULL", formatWithSpacesTrue.getNullString());
                                                                                                                                               assertArrayEquals(new String[]{"Name", "Age"}, formatWithSpacesTrue.getHeader());
                                                                                                                                               assertTrue(formatWithSpacesTrue.getSkipHeaderRecord());
                                                                                                                                               assertFalse(formatWithSpacesTrue.getAllowMissingColumnNames());
                                                                                                                                               assertFalse(formatWithSpacesTrue.getIgnoreHeaderCase());
                                                                                                                                               
                                                                                                                                               // Test setting ignoreSurroundingSpaces to false
                                                                                                                                               CSVFormat formatWithSpacesFalse = baseFormat.withIgnoreSurroundingSpaces(false);
                                                                                                                                               assertFalse(formatWithSpacesFalse.getIgnoreSurroundingSpaces());
                                                                                                                                               // Verify other settings remain unchanged
                                                                                                                                               assertEquals(';', formatWithSpacesFalse.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('"'), formatWithSpacesFalse.getQuoteCharacter());
                                                                                                                                               
                                                                                                                                               // Test chaining with other methods
                                                                                                                                               CSVFormat chainedFormat = baseFormat
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withDelimiter(',')
                                                                                                                                                   .withQuote('\'');
                                                                                                                                               assertTrue(chainedFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(',', chainedFormat.getDelimiter());
                                                                                                                                               assertEquals(Character.valueOf('\''), chainedFormat.getQuoteCharacter());
                                                                                                                                               
                                                                                                                                               // Test with default format
                                                                                                                                               CSVFormat defaultWithSpaces = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                                                               assertTrue(defaultWithSpaces.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getDelimiter(), defaultWithSpaces.getDelimiter());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), defaultWithSpaces.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_True() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Exercise
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreHeaderCase(true);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat); // Should return a new instance
                                                                                                                                               assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               // Verify all other properties remain the same
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_False() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                               
                                                                                                                                               // Exercise
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreHeaderCase(false);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat); // Should return a new instance
                                                                                                                                               assertFalse(newFormat.getIgnoreHeaderCase());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               // Verify all other properties remain the same
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_Default() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Exercise
                                                                                                                                               CSVFormat newFormat = originalFormat.withIgnoreHeaderCase();
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat); // Should return a new instance
                                                                                                                                               assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               // Verify all other properties remain the same
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_Chaining() {
                                                                                                                                               // Test that multiple calls can be chained
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                                   .withIgnoreHeaderCase(true)
                                                                                                                                                   .withDelimiter(';')
                                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                                               
                                                                                                                                               assertFalse(format.getIgnoreHeaderCase());
                                                                                                                                               assertEquals(';', format.getDelimiter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_True1() {
                                                                                                                                               // Setup original format with default values
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                   .withDelimiter(',')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("Name", "Age")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withAllowMissingColumnNames(false)
                                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Verify all properties except ignoreHeaderCase remain the same
                                                                                                                                               assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                               assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                               assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                               assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                               assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                               assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                               assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                               assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                               
                                                                                                                                               // Verify ignoreHeaderCase was changed
                                                                                                                                               assertTrue(modified.getIgnoreHeaderCase());
                                                                                                                                               assertFalse(original.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_False1() {
                                                                                                                                               // Setup original format with ignoreHeaderCase true
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = original.withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                               // Verify ignoreHeaderCase was changed
                                                                                                                                               assertFalse(modified.getIgnoreHeaderCase());
                                                                                                                                               assertTrue(original.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_NoChange() {
                                                                                                                                               // Setup original format
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                   .withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Call method with same value
                                                                                                                                               CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Should return same instance for optimization
                                                                                                                                               assertSame(original, modified);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_FromDefault() {
                                                                                                                                               // Default format should have ignoreHeaderCase false
                                                                                                                                               assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
                                                                                                                                       
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Verify change
                                                                                                                                               assertTrue(modified.getIgnoreHeaderCase());
                                                                                                                                               assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_WithNullHeader() {
                                                                                                                                               // Setup format with null header
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                   .withHeader((String[]) null)
                                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Verify change
                                                                                                                                               assertTrue(modified.getIgnoreHeaderCase());
                                                                                                                                               assertNull(modified.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithIgnoreHeaderCase_WithEmptyHeader() {
                                                                                                                                               // Setup format with empty header
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                   .withHeader(new String[0])
                                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                               // Call method under test
                                                                                                                                               CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                                                                       
                                                                                                                                               // Verify change
                                                                                                                                               assertTrue(modified.getIgnoreHeaderCase());
                                                                                                                                               assertArrayEquals(new String[0], modified.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithNullString_ValidString() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               String nullString = "NULL";
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withNullString(nullString);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertEquals(nullString, newFormat.getNullString());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithNullString_EmptyString() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               String nullString = "";
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withNullString(nullString);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertEquals(nullString, newFormat.getNullString());
                                                                                                                                               assertTrue(newFormat.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithNullString_NullInput() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withNullString(null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNull(newFormat.getNullString());
                                                                                                                                               assertFalse(newFormat.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithNullString_VerifyImmutability() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               String originalNullString = originalFormat.getNullString();
                                                                                                                                               String newNullString = "NA";
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withNullString(newNullString);
                                                                                                                                               
                                                                                                                                               // Verify original format wasn't modified
                                                                                                                                               assertEquals(originalNullString, originalFormat.getNullString());
                                                                                                                                               assertEquals(newNullString, newFormat.getNullString());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithNullString_VerifyIsNullStringSet() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                                               assertFalse(originalFormat.isNullStringSet());
                                                                                                                                               
                                                                                                                                               // Execute with non-null string
                                                                                                                                               CSVFormat newFormat = originalFormat.withNullString("NULL");
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertTrue(newFormat.isNullStringSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_NonNullCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character quoteChar = '"';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                                                               assertTrue(newFormat.isQuoteCharacterSet());
                                                                                                                                               
                                                                                                                                               // Verify other properties remain unchanged
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_NullCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               Character quoteChar = null;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotNull(newFormat);
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertNull(newFormat.getQuoteCharacter());
                                                                                                                                               assertFalse(newFormat.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_SameCharacterReturnsSameInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               Character quoteChar = '"';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertSame(originalFormat, newFormat);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_DifferentCharacterReturnsNewInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               Character quoteChar = '\'';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_FromNullToNonNull() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote(null);
                                                                                                                                               Character quoteChar = '"';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                                                               assertTrue(newFormat.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_FromNonNullToNull() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                                                               Character quoteChar = null;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertNull(newFormat.getQuoteCharacter());
                                                                                                                                               assertFalse(newFormat.isQuoteCharacterSet());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_InvalidQuoteCharacterSameAsDelimiter() {
                                                                                                                                               // Setup
                                                                                                                                               char delimiter = ',';
                                                                                                                                               char quoteChar = delimiter;
                                                                                                                                               CSVFormat originalFormat = CSVFormat.newFormat(delimiter);
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The quoteChar character and the delimiter cannot be the same ('" + delimiter + "')");
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               originalFormat.withQuote(quoteChar);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_InvalidQuoteCharacterSameAsCommentMarker() {
                                                                                                                                               // Setup
                                                                                                                                               char commentMarker = '#';
                                                                                                                                               char quoteChar = commentMarker;
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker(commentMarker);
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The quoteChar character and the commentMarker cannot be the same ('" + commentMarker + "')");
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               originalFormat.withQuote(quoteChar);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_InvalidQuoteCharacterSameAsEscapeCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               char escape = '\\';
                                                                                                                                               char quoteChar = escape;
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(escape);
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The quoteChar character and the escape character cannot be the same ('" + escape + "')");
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               originalFormat.withQuote(quoteChar);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_NullCharacter1() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               CSVFormat newFormat = original.withQuote((Character) null);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNull(newFormat.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_LineBreakCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char lineBreak = '\n';
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               original.withQuote(lineBreak);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_LineBreakCharacterObject() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               Character lineBreak = '\n';
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               original.withQuote(lineBreak);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_OtherSpecialCharacters() {
                                                                                                                                               // Test various special characters that should be valid
                                                                                                                                               char[] validChars = {'"', '\'', '|', '\t', ' '};
                                                                                                                                               
                                                                                                                                               for (char c : validChars) {
                                                                                                                                                   CSVFormat newFormat = CSVFormat.DEFAULT.withQuote(c);
                                                                                                                                                   assertEquals(Character.valueOf(c), newFormat.getQuoteCharacter());
                                                                                                                                               }
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuote_VerifyImmutability() {
                                                                                                                                               // Verify that the original format is not modified
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat newFormat = original.withQuote('"');
                                                                                                                                               
                                                                                                                                               assertNotSame(original, newFormat);
                                                                                                                                               assertNull(original.getQuoteCharacter());
                                                                                                                                               assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuoteMode_NonNullQuoteMode() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT
                                                                                                                                                   .withDelimiter(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                                   .withNullString("NULL")
                                                                                                                                                   .withHeader("Name", "Age")
                                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                                   .withAllowMissingColumnNames(true)
                                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                               // Test
                                                                                                                                               QuoteMode newQuoteMode = QuoteMode.ALL;
                                                                                                                                               CSVFormat modified = original.withQuoteMode(newQuoteMode);
                                                                                                                                       
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(original, modified);
                                                                                                                                               assertEquals(newQuoteMode, modified.getQuoteMode());
                                                                                                                                               
                                                                                                                                               // Verify all other properties remain the same
                                                                                                                                               assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                               assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                               assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                               assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                               assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                               assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                               assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuoteMode_NullQuoteMode() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("quoteMode");
                                                                                                                                       
                                                                                                                                               // Test
                                                                                                                                               original.withQuoteMode(null);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuoteMode_SameQuoteModeReturnsSameInstance() {
                                                                                                                                               // Setup
                                                                                                                                               QuoteMode quoteMode = QuoteMode.NON_NUMERIC;
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withQuoteMode(quoteMode);
                                                                                                                                       
                                                                                                                                               // Test
                                                                                                                                               CSVFormat result = original.withQuoteMode(quoteMode);
                                                                                                                                       
                                                                                                                                               // Verify
                                                                                                                                               assertSame(original, result);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuoteMode_DifferentQuoteModeReturnsNewInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                                                       
                                                                                                                                               // Test
                                                                                                                                               CSVFormat result = original.withQuoteMode(QuoteMode.NONE);
                                                                                                                                       
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(original, result);
                                                                                                                                               assertEquals(QuoteMode.NONE, result.getQuoteMode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithQuoteMode_VerifyQuoteModeBehavior() {
                                                                                                                                               // Test all possible QuoteMode values
                                                                                                                                               for (QuoteMode mode : QuoteMode.values()) {
                                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(mode);
                                                                                                                                                   assertEquals(mode, format.getQuoteMode());
                                                                                                                                               }
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_ValidCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               char recordSeparator = '\n';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = format.withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(format, newFormat);
                                                                                                                                               assertEquals(String.valueOf(recordSeparator), newFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_NonPrintableCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               char recordSeparator = '\u0001'; // ASCII control character
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = format.withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertEquals(String.valueOf(recordSeparator), newFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_SameCharacter() {
                                                                                                                                               // Setup
                                                                                                                                               char recordSeparator = '\r';
                                                                                                                                               CSVFormat format = CSVFormat.newFormat(',').withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = format.withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertSame(format, newFormat); // Should return same instance when no change
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_DefaultFormat() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                               char recordSeparator = '|';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = format.withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(String.valueOf(recordSeparator), newFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_ExcelFormat() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat format = CSVFormat.EXCEL;
                                                                                                                                               char recordSeparator = '\t';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = format.withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotEquals(format.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(String.valueOf(recordSeparator), newFormat.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_AllOtherPropertiesPreserved() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.newFormat(';')
                                                                                                                                                   .withQuote('"')
                                                                                                                                                   .withEscape('\\')
                                                                                                                                                   .withCommentMarker('#')
                                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                                   .withHeader("Col1", "Col2");
                                                                                                                                               char recordSeparator = '\n';
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat modified = original.withRecordSeparator(recordSeparator);
                                                                                                                                               
                                                                                                                                               // Verify record separator changed
                                                                                                                                               assertEquals(String.valueOf(recordSeparator), modified.getRecordSeparator());
                                                                                                                                               
                                                                                                                                               // Verify all other properties remain the same
                                                                                                                                               assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                               assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                               assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                               assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_Char() {
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               char newSeparator = '|';
                                                                                                                                               CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                                                       
                                                                                                                                               assertEquals(String.valueOf(newSeparator), modified.getRecordSeparator());
                                                                                                                                               // Verify it's a new instance
                                                                                                                                               assertNotSame(original, modified);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_NullString() {
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat modified = original.withRecordSeparator((String)null);
                                                                                                                                       
                                                                                                                                               assertNull(modified.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_EmptyString() {
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat modified = original.withRecordSeparator("");
                                                                                                                                       
                                                                                                                                               assertEquals("", modified.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_UnicodeString() {
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               String unicodeSeparator = "❄";
                                                                                                                                               CSVFormat modified = original.withRecordSeparator(unicodeSeparator);
                                                                                                                                       
                                                                                                                                               assertEquals(unicodeSeparator, modified.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_ControlCharacter() {
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               String controlCharSeparator = "\u0001";
                                                                                                                                               CSVFormat modified = original.withRecordSeparator(controlCharSeparator);
                                                                                                                                       
                                                                                                                                               assertEquals(controlCharSeparator, modified.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithRecordSeparator_VerifyImmutability() {
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               CSVFormat modified = original.withRecordSeparator("|");
                                                                                                                                       
                                                                                                                                               // Verify original wasn't modified
                                                                                                                                               assertNotEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_True() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                               // Verify all other properties are copied correctly
                                                                                                                                               assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                               assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                               assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                               assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                               assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                                                               assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                                                               assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                               assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_False() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat originalFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               CSVFormat newFormat = originalFormat.withSkipHeaderRecord(false);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(originalFormat, newFormat);
                                                                                                                                               assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                                                               // Verify all other properties remain unchanged
                                                                                                                                               assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                               assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_DefaultInstance() {
                                                                                                                                               // Verify that DEFAULT instance has skipHeaderRecord false by default
                                                                                                                                               assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_Immutable() {
                                                                                                                                               // Verify immutability - changing one instance doesn't affect another
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               CSVFormat format2 = format1.withSkipHeaderRecord(false);
                                                                                                                                               
                                                                                                                                               assertTrue(format1.getSkipHeaderRecord());
                                                                                                                                               assertFalse(format2.getSkipHeaderRecord());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_EqualsAndHashCode() {
                                                                                                                                               // Verify equals and hashCode consistency
                                                                                                                                               CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               CSVFormat differentFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                                                               
                                                                                                                                               assertEquals(format1, format2);
                                                                                                                                               assertEquals(format1.hashCode(), format2.hashCode());
                                                                                                                                               assertNotEquals(format1, differentFormat);
                                                                                                                                               assertNotEquals(format1.hashCode(), differentFormat.hashCode());
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_SameValueReturnsSameInstance() {
                                                                                                                                               // Setup
                                                                                                                                               CSVFormat original = CSVFormat.DEFAULT;
                                                                                                                                               boolean originalSkipHeaderRecord = original.getSkipHeaderRecord();
                                                                                                                                               
                                                                                                                                               // Test
                                                                                                                                               CSVFormat modified = original.withSkipHeaderRecord(originalSkipHeaderRecord);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertSame(original, modified);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testWithSkipHeaderRecord_FromDefaultFormat() {
                                                                                                                                               // Test
                                                                                                                                               CSVFormat modified = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               assertNotSame(CSVFormat.DEFAULT, modified);
                                                                                                                                               assertTrue(modified.getSkipHeaderRecord());
                                                                                                                                               // Verify other properties remain the same as DEFAULT
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getDelimiter(), modified.getDelimiter());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getNullString(), modified.getNullString());
                                                                                                                                               assertArrayEquals(CSVFormat.DEFAULT.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                               assertArrayEquals(CSVFormat.DEFAULT.getHeader(), modified.getHeader());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                               assertEquals(CSVFormat.DEFAULT.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                                           }

 @Test
                                                                                                                                   public void testIsLineBreak_WithNonLineBreakCharacters() throws Exception {
                                                                                                                                       // Test various non-line-break characters
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, ' '));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, 'a'));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '0'));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\t'));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\0'));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, ';'));
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithUnicodeLineBreaks() throws Exception {
                                                                                                                                       // Get the private isLineBreak method using reflection
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Test some Unicode line break characters that shouldn't match
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\u0085')); // NEL
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\u2028')); // Line separator
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\u2029')); // Paragraph separator
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithSpecialCharacters() throws Exception {
                                                                                                                                       // Get the private isLineBreak method via reflection
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Test various special characters
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\b'));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\f'));
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\u001F'));
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithNullCharacter() throws Exception {
                                                                                                                                       Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                       method.setAccessible(true);
                                                                                                                                       assertFalse((Boolean) method.invoke(null, '\0'));
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithMaxCharValue() throws Exception {
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       boolean result = (boolean) isLineBreakMethod.invoke(null, Character.MAX_VALUE);
                                                                                                                                       assertFalse(result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithMinCharValue() throws Exception {
                                                                                                                                       Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                       method.setAccessible(true);
                                                                                                                                       boolean result = (boolean) method.invoke(null, Character.MIN_VALUE);
                                                                                                                                       assertFalse(result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithNullCharacter1() throws Exception {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                                                       method.setAccessible(true);
                                                                                                                                       boolean result = (boolean) method.invoke(format, (Character) null);
                                                                                                                                       assertFalse(result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithNonLineBreakCharacters1() throws Exception {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       // Get the private isLineBreak method that takes char parameter
                                                                                                                                       Method isLineBreakCharMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakCharMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(format, 'a'));
                                                                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(format, ' '));
                                                                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(format, '\t'));
                                                                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(format, '1'));
                                                                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(format, '@'));
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithLineBreakCharacters() throws Exception {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       
                                                                                                                                       // Get private isLineBreak method via reflection
                                                                                                                                       Method isLineBreakCharMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakCharMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Test standard line break characters
                                                                                                                                       assertTrue((boolean) isLineBreakCharMethod.invoke(format, '\n'));  // LF
                                                                                                                                       assertTrue((boolean) isLineBreakCharMethod.invoke(format, '\r'));  // CR
                                                                                                                                       
                                                                                                                                       // Test combination line breaks (though method might treat them separately)
                                                                                                                                       assertTrue((boolean) isLineBreakCharMethod.invoke(format, '\u0085'));  // NEL
                                                                                                                                       assertTrue((boolean) isLineBreakCharMethod.invoke(format, '\u2028'));  // Line Separator
                                                                                                                                       assertTrue((boolean) isLineBreakCharMethod.invoke(format, '\u2029'));  // Paragraph Separator
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithUnicodeLineBreaks1() throws Exception {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       // Get the private isLineBreak method using reflection
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Test various Unicode line break characters
                                                                                                                                       assertTrue((Boolean) isLineBreakMethod.invoke(format, '\u000B'));  // Vertical Tab
                                                                                                                                       assertTrue((Boolean) isLineBreakMethod.invoke(format, '\u000C'));  // Form Feed
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithControlCharacters() throws Exception {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       // Get the private isLineBreak method using reflection
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Test other control characters that aren't line breaks
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u0000'));  // Null
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u0007'));  // Bell
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u001B'));  // Escape
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsLineBreak_WithSurrogatePairs() throws Exception {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                       // Get the private isLineBreak method using reflection
                                                                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Test with surrogate pairs (high and low surrogates)
                                                                                                                                       // These should return false as they're not valid line break characters
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(format, '\uD800'));  // High surrogate
                                                                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(format, '\uDC00'));  // Low surrogate
                                                                                                                                   }

 @Test
                                                                                                                                   public void testToStringArray_NullInput() throws Exception {
                                                                                                                                       // Get the private toStringArray method via reflection
                                                                                                                                       Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                       toStringArrayMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Invoke the method with null input
                                                                                                                                       CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                       Object result = toStringArrayMethod.invoke(csvFormat, (Object) null);
                                                                                                                                       
                                                                                                                                       // Verify the result is null
                                                                                                                                       assertNull(result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testToStringArray_EmptyArray() throws Exception {
                                                                                                                                       CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                       Object[] input = new Object[0];
                                                                                                                                       
                                                                                                                                       // Use reflection to access private method
                                                                                                                                       Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                       toStringArrayMethod.setAccessible(true);
                                                                                                                                       String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                                                                       
                                                                                                                                       assertNotNull(result);
                                                                                                                                       assertEquals(0, result.length);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testToStringArray_AllNonNullValues() throws Exception {
                                                                                                                                       CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                       Object[] input = {123, "test", true, 45.67};
                                                                                                                                       String[] expected = {"123", "test", "true", "45.67"};
                                                                                                                                       
                                                                                                                                       // Use reflection to access private method
                                                                                                                                       Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                       toStringArrayMethod.setAccessible(true);
                                                                                                                                       String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                                                                       
                                                                                                                                       assertArrayEquals(expected, result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testToStringArray_AllNullValues() throws Exception {
                                                                                                                                       CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                       Object[] input = {null, null, null};
                                                                                                                                       String[] expected = {null, null, null};
                                                                                                                                       
                                                                                                                                       // Get the private method using reflection
                                                                                                                                       Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                       toStringArrayMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Invoke the method on the csvFormat instance
                                                                                                                                       String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                                                                       
                                                                                                                                       assertArrayEquals(expected, result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testToStringArray_MixedNullAndNonNullValues() throws Exception {
                                                                                                                                       CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                       Object[] input = {null, "hello", 42, null, false};
                                                                                                                                       String[] expected = {null, "hello", "42", null, "false"};
                                                                                                                                       
                                                                                                                                       // Use reflection to access private method
                                                                                                                                       Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                       toStringArrayMethod.setAccessible(true);
                                                                                                                                       String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                                                                       
                                                                                                                                       assertArrayEquals(expected, result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testToStringArray_ArrayWithDifferentTypes() throws Exception {
                                                                                                                                       CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                                                                       Object[] input = {1, 2L, 3.14f, 4.56d, 'a', "string"};
                                                                                                                                       String[] expected = {"1", "2", "3.14", "4.56", "a", "string"};
                                                                                                                                       
                                                                                                                                       // Use reflection to access private method
                                                                                                                                       Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                                                                       toStringArrayMethod.setAccessible(true);
                                                                                                                                       String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                                                                       
                                                                                                                                       assertArrayEquals(expected, result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetDelimiter_ConstructorInitialization() {
                                                                                                                                       // Test direct constructor initialization
                                                                                                                                       char testDelimiter = '#';
                                                                                                                                       // Use the public factory method to create CSVFormat instance
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(testDelimiter);
                                                                                                                                       
                                                                                                                                       assertEquals(testDelimiter, format.getDelimiter());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetEscapeCharacter_WhenSet() {
                                                                                                                                       // Test with non-null escape character
                                                                                                                                       Character expectedEscape = '\\';
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                               .withQuote('"')
                                                                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                               .withCommentMarker('#')
                                                                                                                                               .withEscape(expectedEscape)
                                                                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                                                                               .withIgnoreEmptyLines(false)
                                                                                                                                               .withRecordSeparator("\r\n")
                                                                                                                                               .withNullString(null)
                                                                                                                                               .withHeaderComments((Object[])null)
                                                                                                                                               .withHeader((String[])null)
                                                                                                                                               .withSkipHeaderRecord(false)
                                                                                                                                               .withAllowMissingColumnNames(false)
                                                                                                                                               .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertEquals(expectedEscape, format.getEscapeCharacter());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetEscapeCharacter_WhenNull() {
                                                                                                                                       // Test with null escape character
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape(null)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader((String[])null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertNull(format.getEscapeCharacter());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeader_WhenHeaderIsNull() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withHeader((String[]) null);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result = format.getHeader();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNull(result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeader_WhenHeaderIsEmptyArray() {
                                                                                                                                       // Arrange
                                                                                                                                       String[] emptyHeader = new String[0];
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withHeader(emptyHeader);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result = format.getHeader();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNotNull(result);
                                                                                                                                       assertEquals(0, result.length);
                                                                                                                                       assertNotSame(emptyHeader, result); // Verify it's a clone
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeader_WhenHeaderHasSingleElement() {
                                                                                                                                       // Arrange
                                                                                                                                       String[] singleHeader = {"Column1"};
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withHeader(singleHeader)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result = format.getHeader();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNotNull(result);
                                                                                                                                       assertEquals(1, result.length);
                                                                                                                                       assertEquals("Column1", result[0]);
                                                                                                                                       assertNotSame(singleHeader, result); // Verify it's a clone
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeader_WhenHeaderHasMultipleElements() {
                                                                                                                                       // Arrange
                                                                                                                                       String[] multiHeader = {"Name", "Age", "Email"};
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                               .withHeader(multiHeader)
                                                                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                                                                               .withIgnoreEmptyLines(false)
                                                                                                                                               .withSkipHeaderRecord(false)
                                                                                                                                               .withAllowMissingColumnNames(false)
                                                                                                                                               .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result = format.getHeader();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNotNull(result);
                                                                                                                                       assertEquals(3, result.length);
                                                                                                                                       assertArrayEquals(multiHeader, result);
                                                                                                                                       assertNotSame(multiHeader, result); // Verify it's a clone
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeader_ReturnsDefensiveCopy() {
                                                                                                                                       // Arrange
                                                                                                                                       String[] originalHeader = {"A", "B", "C"};
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withHeader(originalHeader)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result1 = format.getHeader();
                                                                                                                                       String[] result2 = format.getHeader();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNotSame(originalHeader, result1);
                                                                                                                                       assertNotSame(originalHeader, result2);
                                                                                                                                       assertNotSame(result1, result2); // Each call returns a new copy
                                                                                                                                       
                                                                                                                                       // Modify the returned array
                                                                                                                                       result1[0] = "X";
                                                                                                                                       
                                                                                                                                       // Verify original and other copies are not affected
                                                                                                                                       assertEquals("A", result2[0]);
                                                                                                                                       String[] result3 = format.getHeader();
                                                                                                                                       assertEquals("A", result3[0]);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeaderComments_WhenNull() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote(null)
                                                                                                                                           .withQuoteMode(null)
                                                                                                                                           .withCommentMarker(null)
                                                                                                                                           .withEscape(null)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader((String[])null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result = format.getHeaderComments();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNull(result);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeaderComments_WithValues() {
                                                                                                                                       // Arrange
                                                                                                                                       String[] comments = {"Comment1", "Comment2"};
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote(null)
                                                                                                                                           .withQuoteMode(null)
                                                                                                                                           .withCommentMarker(null)
                                                                                                                                           .withEscape(null)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments(comments)
                                                                                                                                           .withHeader((String[]) null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       String[] result = format.getHeaderComments();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNotNull(result);
                                                                                                                                       assertEquals(2, result.length);
                                                                                                                                       assertArrayEquals(comments, result);
                                                                                                                                       assertNotSame(comments, result); // Verify it's a clone
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetHeaderComments_VerifyImmutability() {
                                                                                                                                       // Arrange
                                                                                                                                       String[] originalComments = {"Original"};
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withRecordSeparator("\n")
                                                                                                                                           .withHeaderComments(originalComments);
                                                                                                                                       
                                                                                                                                       // Act - Get the comments and modify them
                                                                                                                                       String[] result = format.getHeaderComments();
                                                                                                                                       result[0] = "Modified";
                                                                                                                                       
                                                                                                                                       // Assert - Original should remain unchanged
                                                                                                                                       assertEquals("Original", originalComments[0]);
                                                                                                                                       assertEquals("Modified", result[0]);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetAllowMissingColumnNames_WhenTrue() {
                                                                                                                                       // Create format with allowMissingColumnNames set to true using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(true)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertTrue(format.getAllowMissingColumnNames());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetAllowMissingColumnNames_WhenFalse() {
                                                                                                                                       // Create format with allowMissingColumnNames set to false using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertFalse(format.getAllowMissingColumnNames());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetIgnoreEmptyLines_CustomFormatIgnoreEmptyLinesTrue() {
                                                                                                                                       // Test custom format with ignoreEmptyLines set to true
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader((String[])null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertTrue("Custom format with ignoreEmptyLines=true should return true", 
                                                                                                                                                 format.getIgnoreEmptyLines());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetIgnoreEmptyLines_CustomFormatIgnoreEmptyLinesFalse() {
                                                                                                                                       // Test custom format with ignoreEmptyLines set to false
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader((String[])null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertFalse("Custom format with ignoreEmptyLines=false should return false", 
                                                                                                                                                  format.getIgnoreEmptyLines());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetIgnoreSurroundingSpaces_WhenTrue() {
                                                                                                                                       // Create a CSVFormat instance with ignoreSurroundingSpaces set to true using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeaderComments("Comment")
                                                                                                                                           .withHeader("Header")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetIgnoreSurroundingSpaces_WhenFalse() {
                                                                                                                                       // Create a CSVFormat instance with ignoreSurroundingSpaces set to false
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeaderComments("Comment")
                                                                                                                                           .withHeader("Header")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetIgnoreHeaderCase_CustomFormatTrue() {
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                               .withIgnoreHeaderCase(true);
                                                                                                                                       assertTrue("Custom format with ignoreHeaderCase=true should return true", 
                                                                                                                                                 format.getIgnoreHeaderCase());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetIgnoreHeaderCase_CustomFormatFalse() {
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                               .withIgnoreHeaderCase(false);
                                                                                                                                       assertFalse("Custom format with ignoreHeaderCase=false should return false", 
                                                                                                                                                  format.getIgnoreHeaderCase());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetNullString_WhenNullStringIsNull() {
                                                                                                                                       // Create a CSVFormat instance with nullString set to null
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withNullString(null);
                                                                                                                                       
                                                                                                                                       assertNull(format.getNullString());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetNullString_WhenNullStringIsEmpty() {
                                                                                                                                       // Create a CSVFormat instance with empty nullString using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("")
                                                                                                                                           .withHeaderComments("Comment")
                                                                                                                                           .withHeader("Header")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertEquals("", format.getNullString());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetNullString_WhenNullStringIsSet() {
                                                                                                                                       // Create a CSVFormat instance with specific nullString using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeaderComments("Comment")
                                                                                                                                           .withHeader("Header")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertEquals("NULL", format.getNullString());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteCharacter_WhenQuoteCharacterIsSet() {
                                                                                                                                       // Arrange
                                                                                                                                       Character expectedQuote = '"';
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote(expectedQuote)
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act
                                                                                                                                       Character actualQuote = format.getQuoteCharacter();
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertEquals(expectedQuote, actualQuote);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteCharacter_WhenQuoteCharacterIsNull() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote(null)
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                       // Act
                                                                                                                                       Character actualQuote = format.getQuoteCharacter();
                                                                                                                                   
                                                                                                                                       // Assert
                                                                                                                                       assertNull(actualQuote);
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteMode_WhenInitializedWithNull() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',').withQuoteMode(null);
                                                                                                                                       
                                                                                                                                       // Act & Assert
                                                                                                                                       assertNull(format.getQuoteMode());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteMode_WhenInitializedWithAll() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                                                                           .withCommentMarker(null)
                                                                                                                                           .withEscape(null)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader((String[])null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act & Assert
                                                                                                                                       assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteMode_WhenInitializedWithMinimal() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                               .withQuote('"')
                                                                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                                                                               .withIgnoreEmptyLines(false)
                                                                                                                                               .withRecordSeparator("\n")
                                                                                                                                               .withSkipHeaderRecord(false)
                                                                                                                                               .withAllowMissingColumnNames(false)
                                                                                                                                               .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act & Assert
                                                                                                                                       assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteMode_WhenInitializedWithNonNumeric() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                               .withQuote('"')
                                                                                                                                               .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                                                                               .withIgnoreEmptyLines(false)
                                                                                                                                               .withRecordSeparator("\n")
                                                                                                                                               .withSkipHeaderRecord(false)
                                                                                                                                               .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       // Act & Assert
                                                                                                                                       assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetQuoteMode_WhenInitializedWithNone() {
                                                                                                                                       // Arrange
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                                                                                                                       
                                                                                                                                       // Act & Assert
                                                                                                                                       assertEquals(QuoteMode.NONE, format.getQuoteMode());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetRecordSeparator_CustomFormatWithNullSeparator() {
                                                                                                                                       // Test with custom format having null record separator
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                                                                       assertNull(format.getRecordSeparator());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetRecordSeparator_CustomFormatWithEmptySeparator() {
                                                                                                                                       // Test with custom format having empty string as record separator
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("");
                                                                                                                                       assertEquals("", format.getRecordSeparator());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetRecordSeparator_CustomFormatWithSingleCharSeparator() {
                                                                                                                                       // Test with custom format having single character as record separator
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                                                       assertEquals("\n", format.getRecordSeparator());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetRecordSeparator_CustomFormatWithMultiCharSeparator() {
                                                                                                                                       // Test with custom format having multiple characters as record separator
                                                                                                                                       String customSeparator = "|#|";
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator(customSeparator);
                                                                                                                                       assertEquals(customSeparator, format.getRecordSeparator());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetSkipHeaderRecord_WhenTrue() {
                                                                                                                                       // Create a CSVFormat instance with skipHeaderRecord set to true using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader("Header1", "Header2")
                                                                                                                                           .withSkipHeaderRecord(true)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertTrue("Should return true when skipHeaderRecord is true", 
                                                                                                                                                  format.getSkipHeaderRecord());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testGetSkipHeaderRecord_WhenFalse() {
                                                                                                                                       // Create a CSVFormat instance with skipHeaderRecord set to false using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader("Header1", "Header2")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertFalse("Should return false when skipHeaderRecord is false", 
                                                                                                                                                   format.getSkipHeaderRecord());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testHashCode_WithAllFieldsSet() {
                                                                                                                                       String[] header = {"col1", "col2"};
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                               .withDelimiter('|')
                                                                                                                                               .withQuote('"')
                                                                                                                                               .withQuoteMode(QuoteMode.ALL)
                                                                                                                                               .withCommentMarker('#')
                                                                                                                                               .withEscape('\\')
                                                                                                                                               .withIgnoreSurroundingSpaces(true)
                                                                                                                                               .withIgnoreHeaderCase(true)
                                                                                                                                               .withRecordSeparator("\n")
                                                                                                                                               .withNullString("NULL")
                                                                                                                                               .withHeaderComments("comment")
                                                                                                                                               .withHeader(header)
                                                                                                                                               .withSkipHeaderRecord(true)
                                                                                                                                               .withIgnoreEmptyLines(true);
                                                                                                                                       
                                                                                                                                       int expectedHash = 31 * 31 + '|';
                                                                                                                                       expectedHash = 31 * expectedHash + QuoteMode.ALL.hashCode();
                                                                                                                                       expectedHash = 31 * expectedHash + '"';
                                                                                                                                       expectedHash = 31 * expectedHash + '#';
                                                                                                                                       expectedHash = 31 * expectedHash + '\\';
                                                                                                                                       expectedHash = 31 * expectedHash + "NULL".hashCode();
                                                                                                                                       expectedHash = 31 * expectedHash + 1231; // ignoreSurroundingSpaces true
                                                                                                                                       expectedHash = 31 * expectedHash + 1231; // ignoreHeaderCase true
                                                                                                                                       expectedHash = 31 * expectedHash + 1231; // ignoreEmptyLines true
                                                                                                                                       expectedHash = 31 * expectedHash + 1231; // skipHeaderRecord true
                                                                                                                                       expectedHash = 31 * expectedHash + "\n".hashCode();
                                                                                                                                       expectedHash = 31 * expectedHash + Arrays.hashCode(header);
                                                                                                                                       
                                                                                                                                       assertEquals(expectedHash, format.hashCode());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsCommentMarkerSet_WhenCommentMarkerIsSet() {
                                                                                                                                       // Create a basic CSVFormat and set the comment marker
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withCommentMarker('#');
                                                                                                                                       
                                                                                                                                       assertTrue("Should return true when commentMarker is set", 
                                                                                                                                                 format.isCommentMarkerSet());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNull() {
                                                                                                                                       // Create CSVFormat with null escape character using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker(null)
                                                                                                                                           .withEscape(null)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments((Object[])null)
                                                                                                                                           .withHeader((String[])null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertFalse("Should return false when escapeCharacter is null", 
                                                                                                                                                  format.isEscapeCharacterSet());
                                                                                                                                   }

 @Test
                                                                                                                                   public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNotNull() {
                                                                                                                                       // Create CSVFormat with non-null escape character using builder pattern
                                                                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\n")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertTrue("Should return true when escapeCharacter is not null", 
                                                                                                                                                 format.isEscapeCharacterSet());
                                                                                                                                   }

 @Test
                                                                                                                               public void testIsNullStringSet_WhenNullStringIsNull() {
                                                                                                                                   // Create a CSVFormat instance with nullString set to null
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote(null)
                                                                                                                                       .withQuoteMode(null)
                                                                                                                                       .withCommentMarker(null)
                                                                                                                                       .withEscape(null)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withHeaderComments(null)
                                                                                                                                       .withHeader((String[])null)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   assertFalse("Should return false when nullString is null", format.isNullStringSet());
                                                                                                                               }

 @Test
                                                                                                                               public void testIsNullStringSet_WhenNullStringIsNonEmpty() {
                                                                                                                                   // Create a CSVFormat instance with nullString set to a non-empty string
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote(null)
                                                                                                                                       .withQuoteMode(null)
                                                                                                                                       .withCommentMarker(null)
                                                                                                                                       .withEscape(null)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withNullString("NULL")
                                                                                                                                       .withHeaderComments(null)
                                                                                                                                       .withHeader((String[])null)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   assertTrue("Should return true when nullString is non-empty", format.isNullStringSet());
                                                                                                                               }

 @Test
                                                                                                                               public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNull() {
                                                                                                                                   // Arrange
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote((Character) null);
                                                                                                                                   
                                                                                                                                   // Act & Assert
                                                                                                                                   assertFalse(format.isQuoteCharacterSet());
                                                                                                                               }

 @Test
                                                                                                                               public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNotNull() {
                                                                                                                                   // Arrange
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"');
                                                                                                                                   
                                                                                                                                   // Act & Assert
                                                                                                                                   assertTrue(format.isQuoteCharacterSet());
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_LineBreakDelimiter() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                                                   
                                                                                                                                   // Create format with line break as delimiter using public factory method
                                                                                                                                   CSVFormat.newFormat('\n');
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_QuoteCharEqualsDelimiter() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The quoteChar character and the delimiter cannot be the same ('\"')");
                                                                                                                                   
                                                                                                                                   // Create format with quote char same as delimiter using public methods
                                                                                                                                   CSVFormat format = CSVFormat.newFormat('"').withQuote('"');
                                                                                                                                   // This will trigger validate() which should throw the exception
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_EscapeCharEqualsDelimiter() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The escape character and the delimiter cannot be the same ('\\')");
                                                                                                                                   
                                                                                                                                   // Create format with escape char same as delimiter using builder pattern
                                                                                                                                   CSVFormat.newFormat('\\').withEscape('\\');
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_CommentMarkerEqualsDelimiter() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The comment start character and the delimiter cannot be the same ('#')");
                                                                                                                                   
                                                                                                                                   // Create format with comment marker same as delimiter
                                                                                                                                   CSVFormat.newFormat('#').withCommentMarker('#');
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_QuoteCharEqualsCommentMarker() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The comment start character and the quoteChar cannot be the same ('!')");
                                                                                                                                   
                                                                                                                                   // Create format with quote char same as comment marker using builder pattern
                                                                                                                                   CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('!')
                                                                                                                                       .withCommentMarker('!')
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withIgnoreSurroundingSpaces(false);
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_EscapeCharEqualsCommentMarker() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The comment start and the escape character cannot be the same ('@')");
                                                                                                                                   
                                                                                                                                   // Create format with escape char same as comment marker using builder pattern
                                                                                                                                   CSVFormat.newFormat(',')
                                                                                                                                            .withEscape('@')
                                                                                                                                            .withCommentMarker('@');
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_NoEscapeCharWithQuoteModeNone() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("No quotes mode set but no escape character is set");
                                                                                                                                   
                                                                                                                                   // Create format with QuoteMode.NONE and no escape character
                                                                                                                                   CSVFormat.newFormat(',')
                                                                                                                                            .withQuoteMode(QuoteMode.NONE)
                                                                                                                                            .withEscape(null);
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_DuplicateHeaderEntries() {
                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                   thrown.expectMessage("The header contains a duplicate entry: 'name' in [name, age, name]");
                                                                                                                                   
                                                                                                                                   // Create format with duplicate header entries using builder pattern
                                                                                                                                   CSVFormat.newFormat(',')
                                                                                                                                            .withHeader("name", "age", "name")
                                                                                                                                            .withIgnoreEmptyLines(false)
                                                                                                                                            .withIgnoreSurroundingSpaces(false);
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_ValidConfiguration() {
                                                                                                                                   // This should not throw any exceptions
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeaderComments("comment")
                                                                                                                                           .withHeader("name", "age")
                                                                                                                                           .withSkipHeaderRecord(true)
                                                                                                                                           .withAllowMissingColumnNames(true)
                                                                                                                                           .withIgnoreHeaderCase(true);
                                                                                                                                   
                                                                                                                                   // Verify some properties to ensure the format was created correctly
                                                                                                                                   assertEquals(',', format.getDelimiter());
                                                                                                                                   assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                                   assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                                                                   assertArrayEquals(new String[]{"name", "age"}, format.getHeader());
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_NullHeader() {
                                                                                                                                   // Null header should be valid
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withSkipHeaderRecord(true)
                                                                                                                                           .withAllowMissingColumnNames(true)
                                                                                                                                           .withIgnoreHeaderCase(true);
                                                                                                                                   
                                                                                                                                   assertNull(format.getHeader());
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_EmptyHeader() {
                                                                                                                                   // Empty header should be valid
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeader(new String[]{})
                                                                                                                                           .withSkipHeaderRecord(true)
                                                                                                                                           .withAllowMissingColumnNames(true)
                                                                                                                                           .withIgnoreHeaderCase(true);
                                                                                                                                   
                                                                                                                                   assertArrayEquals(new String[]{}, format.getHeader());
                                                                                                                               }

 @Test
                                                                                                                               public void testValidate_HeaderWithEmptyStrings() {
                                                                                                                                   // Header with empty strings should be valid (though perhaps not practical)
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                           .withDelimiter(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeader("", "")
                                                                                                                                           .withSkipHeaderRecord(true)
                                                                                                                                           .withAllowMissingColumnNames(true)
                                                                                                                                           .withIgnoreHeaderCase(true);
                                                                                                                                   
                                                                                                                                   assertArrayEquals(new String[]{"", ""}, format.getHeader());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithCommentMarker_ValidCharacter1() {
                                                                                                                                   // Setup original format with no comment marker using public factory method
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withEscape(null)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withHeaderComments((Object[])null)
                                                                                                                                       .withHeader((String[])null)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Test with valid comment marker
                                                                                                                                   Character commentMarker = '#';
                                                                                                                                   CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                                                                   
                                                                                                                                   // Verify new format has the comment marker set
                                                                                                                                   assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                                   assertTrue(newFormat.isCommentMarkerSet());
                                                                                                                                   
                                                                                                                                   // Verify all other properties remain the same
                                                                                                                                   assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                   assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                   assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                   assertEquals(original.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                   assertEquals(original.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                   assertEquals(original.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                   assertEquals(original.getNullString(), newFormat.getNullString());
                                                                                                                                   assertArrayEquals(original.getHeader(), newFormat.getHeader());
                                                                                                                                   assertArrayEquals(original.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                   assertEquals(original.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                   assertEquals(original.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                   assertEquals(original.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithCommentMarker_NullValue() {
                                                                                                                                   // Setup original format with existing comment marker using public methods
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Test with null comment marker
                                                                                                                                   CSVFormat newFormat = original.withCommentMarker(null);
                                                                                                                                   
                                                                                                                                   // Verify new format has no comment marker
                                                                                                                                   assertNull(newFormat.getCommentMarker());
                                                                                                                                   assertFalse(newFormat.isCommentMarkerSet());
                                                                                                                                   
                                                                                                                                   // Verify all other properties remain the same
                                                                                                                                   assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                                                   assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                   assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithCommentMarker_SameValue() {
                                                                                                                                   // Setup original format with comment marker
                                                                                                                                   Character commentMarker = '#';
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withCommentMarker(commentMarker)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Test with same comment marker
                                                                                                                                   CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                                                                   
                                                                                                                                   // Should return the same instance (immutable pattern)
                                                                                                                                   assertSame(original, newFormat);
                                                                                                                               }

 @Test
                                                                                                                               public void testWithCommentMarker_EqualsOriginalWhenNull() {
                                                                                                                                   // Setup original format with no comment marker using public factory method
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withIgnoreSurroundingSpaces(false);
                                                                                                                                   
                                                                                                                                   // Test with null comment marker
                                                                                                                                   CSVFormat newFormat = original.withCommentMarker(null);
                                                                                                                                   
                                                                                                                                   // Should return the same instance when setting to null and original was null
                                                                                                                                   assertSame(original, newFormat);
                                                                                                                               }

 @Test
                                                                                                                               public void testWithCommentMarker_FromNoMarkerToMarker() {
                                                                                                                                   // Setup original format with no comment marker using public factory method
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false);
                                                                                                                                   
                                                                                                                                   // Test with new comment marker
                                                                                                                                   Character commentMarker = ';';
                                                                                                                                   CSVFormat newFormat = original.withCommentMarker(commentMarker);
                                                                                                                                   
                                                                                                                                   // Verify new format has the comment marker
                                                                                                                                   assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                                   assertTrue(newFormat.isCommentMarkerSet());
                                                                                                                                   
                                                                                                                                   // Verify original remains unchanged
                                                                                                                                   assertNull(original.getCommentMarker());
                                                                                                                                   assertFalse(original.isCommentMarkerSet());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithDelimiter_ValidCharacters() {
                                                                                                                                   // Setup base format with various properties using public methods
                                                                                                                                   CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withCommentMarker('#')
                                                                                                                                       .withEscape('\\')
                                                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                                                       .withRecordSeparator("\n")
                                                                                                                                       .withNullString("NULL")
                                                                                                                                       .withHeaderComments(new Object[]{"comment"})
                                                                                                                                       .withHeader("header1", "header2")
                                                                                                                                       .withSkipHeaderRecord(true)
                                                                                                                                       .withAllowMissingColumnNames(true)
                                                                                                                                       .withIgnoreHeaderCase(true);
                                                                                                                                   
                                                                                                                                   // Test with various valid delimiters
                                                                                                                                   char[] validDelimiters = {';', '\t', '|', ':', ' '};
                                                                                                                                   
                                                                                                                                   for (char delimiter : validDelimiters) {
                                                                                                                                       CSVFormat newFormat = baseFormat.withDelimiter(delimiter);
                                                                                                                                       
                                                                                                                                       // Verify delimiter changed
                                                                                                                                       assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                                                       
                                                                                                                                       // Verify other properties remain the same
                                                                                                                                       assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                                                       assertEquals(baseFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                                                       assertEquals(baseFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                                                       assertEquals(baseFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                                                       assertEquals(baseFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                       assertEquals(baseFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                                                       assertEquals(baseFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                                                       assertEquals(baseFormat.getNullString(), newFormat.getNullString());
                                                                                                                                       assertArrayEquals(baseFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                                                                       assertArrayEquals(baseFormat.getHeader(), newFormat.getHeader());
                                                                                                                                       assertEquals(baseFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                                                       assertEquals(baseFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                                                       assertEquals(baseFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                                                                   }
                                                                                                                               }

 @Test
                                                                                                                               public void testWithQuote_ValidCharacter() {
                                                                                                                                   // Setup
                                                                                                                                   char delimiter = ',';
                                                                                                                                   Character quoteChar = '"';
                                                                                                                                   QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                   Character commentMarker = '#';
                                                                                                                                   Character escapeCharacter = '\\';
                                                                                                                                   boolean ignoreSurroundingSpaces = true;
                                                                                                                                   boolean ignoreEmptyLines = true;
                                                                                                                                   String recordSeparator = "\n";
                                                                                                                                   String nullString = "NULL";
                                                                                                                                   String[] headerComments = {"Comment1", "Comment2"};
                                                                                                                                   String[] header = {"Header1", "Header2"};
                                                                                                                                   boolean skipHeaderRecord = false;
                                                                                                                                   boolean allowMissingColumnNames = true;
                                                                                                                                   boolean ignoreHeaderCase = false;
                                                                                                                                   
                                                                                                                                   // Create original format using public methods
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                                                                           .withQuoteMode(quoteMode)
                                                                                                                                           .withCommentMarker(commentMarker)
                                                                                                                                           .withEscape(escapeCharacter)
                                                                                                                                           .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                           .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                           .withRecordSeparator(recordSeparator)
                                                                                                                                           .withNullString(nullString)
                                                                                                                                           .withHeaderComments(headerComments)
                                                                                                                                           .withHeader(header)
                                                                                                                                           .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                           .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                           .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   CSVFormat newFormat = original.withQuote(quoteChar);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                                                   assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                                                   assertEquals(quoteMode, newFormat.getQuoteMode());
                                                                                                                                   assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                                                                   assertEquals(escapeCharacter, newFormat.getEscapeCharacter());
                                                                                                                                   assertEquals(ignoreSurroundingSpaces, newFormat.getIgnoreSurroundingSpaces());
                                                                                                                                   assertEquals(ignoreEmptyLines, newFormat.getIgnoreEmptyLines());
                                                                                                                                   assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                                                                   assertEquals(nullString, newFormat.getNullString());
                                                                                                                                   assertArrayEquals(header, newFormat.getHeader());
                                                                                                                                   assertArrayEquals(headerComments, newFormat.getHeaderComments());
                                                                                                                                   assertEquals(skipHeaderRecord, newFormat.getSkipHeaderRecord());
                                                                                                                                   assertEquals(allowMissingColumnNames, newFormat.getAllowMissingColumnNames());
                                                                                                                                   assertEquals(ignoreHeaderCase, newFormat.getIgnoreHeaderCase());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithRecordSeparator_String() {
                                                                                                                                   // Setup initial format with all possible parameters using builder pattern
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withHeaderComments("Comment1", "Comment2")
                                                                                                                                           .withHeader("Header1", "Header2")
                                                                                                                                           .withSkipHeaderRecord(true)
                                                                                                                                           .withAllowMissingColumnNames(true)
                                                                                                                                           .withIgnoreHeaderCase(true);
                                                                                                                               
                                                                                                                                   // Test with new record separator
                                                                                                                                   String newSeparator = "|";
                                                                                                                                   CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                                               
                                                                                                                                   // Verify all fields except record separator remain the same
                                                                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                                                   assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                                                   assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                                                   assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                                                   assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                                                   assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                                                   assertEquals(original.getNullString(), modified.getNullString());
                                                                                                                                   assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                                                                   assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                                                   assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                                                   assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                                                                   assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                                                               
                                                                                                                                   // Verify record separator was changed
                                                                                                                                   assertEquals(newSeparator, modified.getRecordSeparator());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithRecordSeparator_FromNullToValue() {
                                                                                                                                   // Create a basic CSVFormat using public methods
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                                                                           .withQuote('"')
                                                                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                           .withCommentMarker('#')
                                                                                                                                           .withEscape('\\')
                                                                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                                                                           .withIgnoreEmptyLines(true)
                                                                                                                                           .withNullString("NULL")
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Verify original has null record separator
                                                                                                                                   assertNull(original.getRecordSeparator());
                                                                                                                                   
                                                                                                                                   // Apply the record separator change
                                                                                                                                   CSVFormat modified = original.withRecordSeparator("\n");
                                                                                                                                   
                                                                                                                                   // Verify the modification
                                                                                                                                   assertEquals("\n", modified.getRecordSeparator());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithSkipHeaderRecord_Chaining() {
                                                                                                                                   // Test method chaining
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                       .withSkipHeaderRecord(true)
                                                                                                                                       .withDelimiter(';')
                                                                                                                                       .withQuote('"');
                                                                                                                                   
                                                                                                                                   assertTrue(format.getSkipHeaderRecord());
                                                                                                                                   assertEquals(';', format.getDelimiter());
                                                                                                                                   assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithSkipHeaderRecord_True1() {
                                                                                                                                   // Setup
                                                                                                                                   char delimiter = ',';
                                                                                                                                   Character quoteCharacter = '"';
                                                                                                                                   QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                                                   Character commentMarker = '#';
                                                                                                                                   Character escapeCharacter = '\\';
                                                                                                                                   boolean ignoreSurroundingSpaces = true;
                                                                                                                                   boolean ignoreEmptyLines = true;
                                                                                                                                   String recordSeparator = "\n";
                                                                                                                                   String nullString = "NULL";
                                                                                                                                   String[] headerComments = {"Comment1", "Comment2"};
                                                                                                                                   String[] header = {"Header1", "Header2"};
                                                                                                                                   boolean skipHeaderRecord = false;
                                                                                                                                   boolean allowMissingColumnNames = false;
                                                                                                                                   boolean ignoreHeaderCase = false;
                                                                                                                                   
                                                                                                                                   // Create original format using builder pattern
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                                                                           .withQuote(quoteCharacter)
                                                                                                                                           .withQuoteMode(quoteMode)
                                                                                                                                           .withCommentMarker(commentMarker)
                                                                                                                                           .withEscape(escapeCharacter)
                                                                                                                                           .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                           .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                           .withRecordSeparator(recordSeparator)
                                                                                                                                           .withNullString(nullString)
                                                                                                                                           .withHeaderComments(headerComments)
                                                                                                                                           .withHeader(header)
                                                                                                                                           .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                           .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                           .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertNotSame(original, modified);
                                                                                                                                   assertEquals(delimiter, modified.getDelimiter());
                                                                                                                                   assertEquals(quoteCharacter, modified.getQuoteCharacter());
                                                                                                                                   assertEquals(quoteMode, modified.getQuoteMode());
                                                                                                                                   assertEquals(commentMarker, modified.getCommentMarker());
                                                                                                                                   assertEquals(escapeCharacter, modified.getEscapeCharacter());
                                                                                                                                   assertEquals(ignoreSurroundingSpaces, modified.getIgnoreSurroundingSpaces());
                                                                                                                                   assertEquals(ignoreEmptyLines, modified.getIgnoreEmptyLines());
                                                                                                                                   assertEquals(recordSeparator, modified.getRecordSeparator());
                                                                                                                                   assertEquals(nullString, modified.getNullString());
                                                                                                                                   assertArrayEquals(headerComments, modified.getHeaderComments());
                                                                                                                                   assertArrayEquals(header, modified.getHeader());
                                                                                                                                   assertEquals(allowMissingColumnNames, modified.getAllowMissingColumnNames());
                                                                                                                                   assertEquals(ignoreHeaderCase, modified.getIgnoreHeaderCase());
                                                                                                                                   assertTrue(modified.getSkipHeaderRecord());
                                                                                                                               }

 @Test
                                                                                                                               public void testWithSkipHeaderRecord_False1() {
                                                                                                                                   // Setup
                                                                                                                                   char delimiter = ';';
                                                                                                                                   Character quoteCharacter = '\'';
                                                                                                                                   QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                                                                   Character commentMarker = null;
                                                                                                                                   Character escapeCharacter = null;
                                                                                                                                   boolean ignoreSurroundingSpaces = false;
                                                                                                                                   boolean ignoreEmptyLines = false;
                                                                                                                                   String recordSeparator = "\r\n";
                                                                                                                                   String nullString = "";
                                                                                                                                   String[] headerComments = null;
                                                                                                                                   String[] header = null;
                                                                                                                                   boolean skipHeaderRecord = true;
                                                                                                                                   boolean allowMissingColumnNames = true;
                                                                                                                                   boolean ignoreHeaderCase = true;
                                                                                                                                   
                                                                                                                                   // Create original CSVFormat using public methods
                                                                                                                                   CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                                                                           .withQuote(quoteCharacter)
                                                                                                                                           .withQuoteMode(quoteMode)
                                                                                                                                           .withCommentMarker(commentMarker)
                                                                                                                                           .withEscape(escapeCharacter)
                                                                                                                                           .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                                                           .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                                                           .withRecordSeparator(recordSeparator)
                                                                                                                                           .withNullString(nullString)
                                                                                                                                           .withHeaderComments(headerComments)
                                                                                                                                           .withHeader(header)
                                                                                                                                           .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                                                           .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                                                                           .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                                                                   
                                                                                                                                   // Test
                                                                                                                                   CSVFormat modified = original.withSkipHeaderRecord(false);
                                                                                                                                   
                                                                                                                                   // Verify
                                                                                                                                   assertNotSame(original, modified);
                                                                                                                                   assertEquals(delimiter, modified.getDelimiter());
                                                                                                                                   assertEquals(quoteCharacter, modified.getQuoteCharacter());
                                                                                                                                   assertEquals(quoteMode, modified.getQuoteMode());
                                                                                                                                   assertEquals(commentMarker, modified.getCommentMarker());
                                                                                                                                   assertEquals(escapeCharacter, modified.getEscapeCharacter());
                                                                                                                                   assertEquals(ignoreSurroundingSpaces, modified.getIgnoreSurroundingSpaces());
                                                                                                                                   assertEquals(ignoreEmptyLines, modified.getIgnoreEmptyLines());
                                                                                                                                   assertEquals(recordSeparator, modified.getRecordSeparator());
                                                                                                                                   assertEquals(nullString, modified.getNullString());
                                                                                                                                   assertArrayEquals(headerComments, modified.getHeaderComments());
                                                                                                                                   assertArrayEquals(header, modified.getHeader());
                                                                                                                                   assertEquals(allowMissingColumnNames, modified.getAllowMissingColumnNames());
                                                                                                                                   assertEquals(ignoreHeaderCase, modified.getIgnoreHeaderCase());
                                                                                                                                   assertFalse(modified.getSkipHeaderRecord());
                                                                                                                               }

 @Test
                                                                                                                               public void testIsLineBreak_WithLineFeed() throws Exception {
                                                                                                                                   final char LF = '\n';
                                                                                                                                   Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                   isLineBreakMethod.setAccessible(true);
                                                                                                                                   boolean result = (boolean) isLineBreakMethod.invoke(null, LF);
                                                                                                                                   assertTrue(result);
                                                                                                                               }

 @Test
                                                                                                                               public void testIsLineBreak_WithCarriageReturn() throws Exception {
                                                                                                                                   final char CR = '\r';
                                                                                                                                   Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                                                   isLineBreakMethod.setAccessible(true);
                                                                                                                                   boolean result = (boolean) isLineBreakMethod.invoke(null, CR);
                                                                                                                                   assertTrue(result);
                                                                                                                               }

 @Test
                                                                                                                               public void testToStringArray_CustomObjects() throws Exception {
                                                                                                                                   Object[] input = {new StringBuilder("builder"), new Object() {
                                                                                                                                       @Override
                                                                                                                                       public String toString() {
                                                                                                                                           return "custom";
                                                                                                                                       }
                                                                                                                                   }};
                                                                                                                                   String[] expected = {"builder", "custom"};
                                                                                                                                   
                                                                                                                                   // Create default format and set header comments
                                                                                                                                   CSVFormat csvFormat = CSVFormat.DEFAULT.withHeaderComments(input);
                                                                                                                                   String[] result = csvFormat.getHeaderComments();
                                                                                                                                   assertArrayEquals(expected, result);
                                                                                                                               }

 @Test
                                                                                                                               public void testFormat_StringWriterException() throws Exception {
                                                                                                                                   // Test the exception handling path (though it should never happen)
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                   Object[] values = {"value1", "value2", "value3"};
                                                                                                                                   
                                                                                                                                   // Mock StringWriter to throw IOException
                                                                                                                                   StringWriter failingWriter = new StringWriter() {
                                                                                                                                       @Override
                                                                                                                                       public void write(String str) {
                                                                                                                                           throw new RuntimeException(new IOException("Simulated IO error"));
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                                   
                                                                                                                                   // Replace the CSVPrinter with one that uses our failing writer
                                                                                                                                   CSVPrinter failingPrinter = new CSVPrinter(failingWriter, format);
                                                                                                                                   
                                                                                                                                   try {
                                                                                                                                       failingPrinter.printRecord(values);
                                                                                                                                       failingWriter.toString().trim();
                                                                                                                                       fail("Expected IllegalStateException to be thrown");
                                                                                                                                   } catch (final IllegalStateException e) {
                                                                                                                                       assertEquals("java.io.IOException: Simulated IO error", e.getMessage());
                                                                                                                                       assertTrue(e.getCause() instanceof IOException);
                                                                                                                                   }
                                                                                                                               }

 @Test
                                                                                                                               public void testGetCommentMarker_WhenCommentMarkerIsSet() {
                                                                                                                                   // Arrange
                                                                                                                                   Character expectedCommentMarker = '#';
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withCommentMarker(expectedCommentMarker)
                                                                                                                                       .withEscape('\\')
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withHeaderComments(null)
                                                                                                                                       .withHeader((String[]) null)  // Explicitly cast to String[]
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Act
                                                                                                                                   Character actualCommentMarker = format.getCommentMarker();
                                                                                                                                   
                                                                                                                                   // Assert
                                                                                                                                   assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                                                               }

 @Test
                                                                                                                               public void testGetCommentMarker_WhenCommentMarkerIsNull() {
                                                                                                                                   // Arrange
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null)
                                                                                                                                       .withDelimiter(',')
                                                                                                                                       .withQuote('"')
                                                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                                       .withEscape('\\')
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withHeaderComments(null)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Act
                                                                                                                                   Character actualCommentMarker = format.getCommentMarker();
                                                                                                                                   
                                                                                                                                   // Assert
                                                                                                                                   assertNull(actualCommentMarker);
                                                                                                                               }

 @Test
                                                                                                                               public void testGetHeader_WithNullElementInHeaderArray() {
                                                                                                                                   // Arrange
                                                                                                                                   String[] headerWithNull = {"Valid", null, "Another"};
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                                                                       .withHeader(headerWithNull)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Act
                                                                                                                                   String[] result = format.getHeader();
                                                                                                                                   
                                                                                                                                   // Assert
                                                                                                                                   assertNotNull(result);
                                                                                                                                   assertEquals(3, result.length);
                                                                                                                                   assertNull(result[1]);
                                                                                                                                   assertArrayEquals(headerWithNull, result);
                                                                                                                               }

 @Test
                                                                                                                               public void testGetHeaderComments_WhenEmptyArray() {
                                                                                                                                   // Arrange
                                                                                                                                   String[] emptyComments = new String[0];
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote(null)
                                                                                                                                       .withQuoteMode(null)
                                                                                                                                       .withCommentMarker(null)
                                                                                                                                       .withEscape(null)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\n")
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withHeaderComments(emptyComments)
                                                                                                                                       .withHeader((String[]) null)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   // Act
                                                                                                                                   String[] result = format.getHeaderComments();
                                                                                                                                   
                                                                                                                                   // Assert
                                                                                                                                   assertNotNull(result);
                                                                                                                                   assertEquals(0, result.length);
                                                                                                                                   assertNotSame(emptyComments, result); // Verify it's a clone
                                                                                                                               }

 @Test
                                                                                                                               public void testHashCode_AllFieldsDefault() {
                                                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                                   int expectedHash = 31 * 31 + (int)','; // delimiter (default is comma)
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getQuoteMode() == null ? 0 : format.getQuoteMode().hashCode());
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getQuoteCharacter() == null ? 0 : (int)format.getQuoteCharacter());
                                                                                                                                   // Other fields are null or false by default
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getIgnoreSurroundingSpaces() ? 1231 : 1237);
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getIgnoreHeaderCase() ? 1231 : 1237);
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getIgnoreEmptyLines() ? 1231 : 1237);
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getSkipHeaderRecord() ? 1231 : 1237);
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getRecordSeparator() == null ? 0 : format.getRecordSeparator().hashCode());
                                                                                                                                   expectedHash = 31 * expectedHash + (format.getHeader() == null ? 0 : Arrays.hashCode(format.getHeader()));
                                                                                                                                   
                                                                                                                                   assertEquals(expectedHash, format.hashCode());
                                                                                                                               }

 @Test
                                                                                                                               public void testIsCommentMarkerSet_WhenCommentMarkerIsNull() {
                                                                                                                                   // Create a CSVFormat with null comment marker using builder pattern
                                                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote(null)
                                                                                                                                       .withQuoteMode(null)
                                                                                                                                       .withCommentMarker(null)
                                                                                                                                       .withEscape(null)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withRecordSeparator("\r\n")
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withHeaderComments(null)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                                                       .withIgnoreHeaderCase(false);
                                                                                                                                   
                                                                                                                                   assertFalse("Should return false when commentMarker is null", 
                                                                                                                                              format.isCommentMarkerSet());
                                                                                                                               }

 @Test
                                                                                                                               public void testIsCommentMarkerSet_WithDifferentCharacterValues() {
                                                                                                                                   // Test with different comment marker characters
                                                                                                                                   char[] testChars = {'#', ';', '/', '*'};
                                                                                                                                   
                                                                                                                                   for (char c : testChars) {
                                                                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                           .withCommentMarker(c)
                                                                                                                                           .withQuote(null)
                                                                                                                                           .withQuoteMode(null)
                                                                                                                                           .withEscape(null)
                                                                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                                                                           .withIgnoreEmptyLines(false)
                                                                                                                                           .withRecordSeparator("\r\n")
                                                                                                                                           .withNullString(null)
                                                                                                                                           .withHeaderComments(null)
                                                                                                                                           .withHeader((String[]) null)
                                                                                                                                           .withSkipHeaderRecord(false)
                                                                                                                                           .withAllowMissingColumnNames(false)
                                                                                                                                           .withIgnoreHeaderCase(false);
                                                                                                                                       
                                                                                                                                       assertTrue("Should return true for comment marker: " + c, 
                                                                                                                                                 format.isCommentMarkerSet());
                                                                                                                                   }
                                                                                                                               }

 @Test
                                                                                                                           public void testIsNullStringSet_WhenNullStringIsEmptyString() {
                                                                                                                               // Create a CSVFormat instance with nullString set to empty string using builder pattern
                                                                                                                               CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                   .withQuote(null)
                                                                                                                                   .withQuoteMode(null)
                                                                                                                                   .withCommentMarker(null)
                                                                                                                                   .withEscape(null)
                                                                                                                                   .withIgnoreSurroundingSpaces(false)
                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                   .withNullString("")
                                                                                                                                   .withHeaderComments(null)
                                                                                                                                   .withHeader((String[]) null)
                                                                                                                                   .withSkipHeaderRecord(false)
                                                                                                                                   .withAllowMissingColumnNames(false)
                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                               
                                                                                                                               assertTrue("Should return true when nullString is empty string", format.isNullStringSet());
                                                                                                                           }

 @Test
                                                                                                                           public void testWithAllowMissingColumnNames() {
                                                                                                                               // Create a base format with all possible configurations using builder pattern
                                                                                                                               CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                                                   .withQuote('"')
                                                                                                                                   .withQuoteMode(QuoteMode.ALL)
                                                                                                                                   .withCommentMarker('#')
                                                                                                                                   .withEscape('\\')
                                                                                                                                   .withIgnoreSurroundingSpaces(true)
                                                                                                                                   .withIgnoreEmptyLines(true)
                                                                                                                                   .withRecordSeparator("\r\n")
                                                                                                                                   .withNullString("NULL")
                                                                                                                                   .withHeaderComments("Comment1")
                                                                                                                                   .withHeader(new String[]{"Header1"})  // Changed to use String array
                                                                                                                                   .withSkipHeaderRecord(true)
                                                                                                                                   .withAllowMissingColumnNames(false)
                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                               
                                                                                                                               // Test enabling allowMissingColumnNames
                                                                                                                               CSVFormat newFormat = baseFormat.withAllowMissingColumnNames();
                                                                                                                               assertTrue("Should allow missing column names", newFormat.getAllowMissingColumnNames());
                                                                                                                               
                                                                                                                               // Verify all other properties remain unchanged
                                                                                                                               assertEquals(',', newFormat.getDelimiter());
                                                                                                                               assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                                               assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                                               assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                                               assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                                               assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                                               assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                                               assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                                               assertEquals("NULL", newFormat.getNullString());
                                                                                                                               assertArrayEquals(new String[]{"Comment1"}, newFormat.getHeaderComments());
                                                                                                                               assertArrayEquals(new String[]{"Header1"}, newFormat.getHeader());
                                                                                                                               assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                                               assertFalse(newFormat.getIgnoreHeaderCase());
                                                                                                                               
                                                                                                                               // Test with allowMissingColumnNames already true
                                                                                                                               CSVFormat alreadyTrueFormat = baseFormat.withAllowMissingColumnNames(true);
                                                                                                                               CSVFormat newFormat2 = alreadyTrueFormat.withAllowMissingColumnNames();
                                                                                                                               assertTrue(newFormat2.getAllowMissingColumnNames());
                                                                                                                               
                                                                                                                               // Test with null values
                                                                                                                               CSVFormat minimalFormat = CSVFormat.newFormat(',')
                                                                                                                                   .withQuote(null)
                                                                                                                                   .withQuoteMode(null)
                                                                                                                                   .withCommentMarker(null)
                                                                                                                                   .withEscape(null)
                                                                                                                                   .withIgnoreSurroundingSpaces(false)
                                                                                                                                   .withIgnoreEmptyLines(false)
                                                                                                                                   .withRecordSeparator(null)
                                                                                                                                   .withNullString(null)
                                                                                                                                   .withHeaderComments(null)
                                                                                                                                   .withHeader((String[])null)  // Changed to explicitly cast null to String array
                                                                                                                                   .withSkipHeaderRecord(false)
                                                                                                                                   .withAllowMissingColumnNames(false)
                                                                                                                                   .withIgnoreHeaderCase(false);
                                                                                                                               
                                                                                                                               CSVFormat newMinimalFormat = minimalFormat.withAllowMissingColumnNames();
                                                                                                                               assertTrue(newMinimalFormat.getAllowMissingColumnNames());
                                                                                                                               assertNull(newMinimalFormat.getQuoteCharacter());
                                                                                                                               assertNull(newMinimalFormat.getQuoteMode());
                                                                                                                               assertNull(newMinimalFormat.getCommentMarker());
                                                                                                                               assertNull(newMinimalFormat.getEscapeCharacter());
                                                                                                                               assertNull(newMinimalFormat.getRecordSeparator());
                                                                                                                               assertNull(newMinimalFormat.getNullString());
                                                                                                                               assertNull(newMinimalFormat.getHeaderComments());
                                                                                                                               assertNull(newMinimalFormat.getHeader());
                                                                                                                           }

 @Test
                                                                                                                           public void testHashCode_WithNullFields() {
                                                                                                                               CSVFormat format = CSVFormat.newFormat(',')
                                                                                                                                       .withQuote(null)
                                                                                                                                       .withQuoteMode(null)
                                                                                                                                       .withCommentMarker(null)
                                                                                                                                       .withEscape(null)
                                                                                                                                       .withNullString(null)
                                                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                                                       .withIgnoreHeaderCase(false)
                                                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                                                       .withSkipHeaderRecord(false)
                                                                                                                                       .withRecordSeparator(null)
                                                                                                                                       .withHeader((String[]) null);
                                                                                                                               
                                                                                                                               int expectedHash = 31 * 31 + ',';
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null quoteMode
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null quoteCharacter
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null commentMarker
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null escapeCharacter
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null nullString
                                                                                                                               expectedHash = 31 * expectedHash + 1237; // ignoreSurroundingSpaces false
                                                                                                                               expectedHash = 31 * expectedHash + 1237; // ignoreHeaderCase false
                                                                                                                               expectedHash = 31 * expectedHash + 1237; // ignoreEmptyLines false
                                                                                                                               expectedHash = 31 * expectedHash + 1237; // skipHeaderRecord false
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null recordSeparator
                                                                                                                               expectedHash = 31 * expectedHash + 0; // null header
                                                                                                                               
                                                                                                                               assertEquals(expectedHash, format.hashCode());
                                                                                                                           }

 @Test
                                                                                                                       public void testGetEscapeCharacter_AfterModification() {
                                                                                                                           // Test that escape character remains unchanged after modification attempts
                                                                                                                           Character originalEscape = '\\';
                                                                                                                           CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                                               .withDelimiter(',')
                                                                                                                               .withQuote('"')
                                                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                                               .withCommentMarker('#')
                                                                                                                               .withEscape(originalEscape)
                                                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                                                               .withIgnoreEmptyLines(false)
                                                                                                                               .withRecordSeparator("\r\n")
                                                                                                                               .withNullString(null)
                                                                                                                               .withHeaderComments((Object[])null)
                                                                                                                               .withHeader((String[])null)
                                                                                                                               .withSkipHeaderRecord(false)
                                                                                                                               .withAllowMissingColumnNames(false)
                                                                                                                               .withIgnoreHeaderCase(false);
                                                                                                                           
                                                                                                                           // Verify original value
                                                                                                                           assertEquals(originalEscape, originalFormat.getEscapeCharacter());
                                                                                                                           
                                                                                                                           // Create modified format
                                                                                                                           CSVFormat modifiedFormat = originalFormat.withEscape('"');
                                                                                                                           
                                                                                                                           // Original format should remain unchanged
                                                                                                                           assertEquals(originalEscape, originalFormat.getEscapeCharacter());
                                                                                                                           
                                                                                                                           // Modified format should have new value
                                                                                                                           assertEquals(Character.valueOf('"'), modifiedFormat.getEscapeCharacter());
                                                                                                                       }

 @Test
                                                                                                                   public void testParse_WithDifferentQuoteModes() throws IOException {
                                                                                                                       // Arrange
                                                                                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT
                                                                                                                           .withQuote('"')
                                                                                                                           .withQuoteMode(org.apache.commons.csv.QuoteMode.ALL);
                                                                                                                       String input = "\"John\",\"30\"\n\"Jane\",\"25\"";
                                                                                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                                                                                       
                                                                                                                       // Act
                                                                                                                       org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                                                       
                                                                                                                       // Assert
                                                                                                                       assertNotNull(parser);
                                                                                                                       java.util.List<org.apache.commons.csv.CSVRecord> records = parser.getRecords();
                                                                                                                       assertEquals(2, records.size());
                                                                                                                       assertEquals("John", records.get(0).get(0));
                                                                                                                       assertEquals("30", records.get(0).get(1));
                                                                                                                       parser.close();
                                                                                                                   }

 @Test
                                                                                                               public void testParse_WithDefaultFormat() throws IOException {
                                                                                                                   // Arrange
                                                                                                                   org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                                                                                   String input = "name,age\\nJohn,30\\nJane,25";
                                                                                                                   java.io.Reader reader = new java.io.StringReader(input);
                                                                                                                   
                                                                                                                   // Act
                                                                                                                   org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                                                   
                                                                                                                   // Assert
                                                                                                                   assertNotNull(parser);
                                                                                                                   
                                                                                                                   // Get iterator once and use it for all records
                                                                                                                   java.util.Iterator<org.apache.commons.csv.CSVRecord> records = parser.iterator();
                                                                                                                   
                                                                                                                   // Verify header
                                                                                                                   org.apache.commons.csv.CSVRecord headerRecord = records.next();
                                                                                                                   assertEquals("name", headerRecord.get(0));
                                                                                                                   assertEquals("age", headerRecord.get(1));
                                                                                                                   
                                                                                                                   // Verify first data record
                                                                                                                   org.apache.commons.csv.CSVRecord firstRecord = records.next();
                                                                                                                   assertEquals("John", firstRecord.get(0));
                                                                                                                   assertEquals("30", firstRecord.get(1));
                                                                                                                   
                                                                                                                   // Verify second data record
                                                                                                                   org.apache.commons.csv.CSVRecord secondRecord = records.next();
                                                                                                                   assertEquals("Jane", secondRecord.get(0));
                                                                                                                   assertEquals("25", secondRecord.get(1));
                                                                                                                   
                                                                                                                   parser.close();
                                                                                                               }

 @Test
                                                                                               public void testPrint_WithDifferentFormats() throws IOException {
                                                                                                   // Arrange
                                                                                                   java.io.Writer writer1 = new java.io.StringWriter();
                                                                                                   java.io.Writer writer2 = new java.io.StringWriter();
                                                                                                   
                                                                                                   // Create two different CSVFormat instances
                                                                                                   org.apache.commons.csv.CSVFormat format1 = org.apache.commons.csv.CSVFormat.newFormat(',')
                                                                                                           .withQuote('"')
                                                                                                           .withRecordSeparator("\n");
                                                                                                   org.apache.commons.csv.CSVFormat format2 = org.apache.commons.csv.CSVFormat.newFormat('\t')
                                                                                                           .withQuote('\'')
                                                                                                           .withRecordSeparator("\r\n");
                                                                                                   
                                                                                                   // Act
                                                                                                   org.apache.commons.csv.CSVPrinter printer1 = new org.apache.commons.csv.CSVPrinter(writer1, format1);
                                                                                                   org.apache.commons.csv.CSVPrinter printer2 = new org.apache.commons.csv.CSVPrinter(writer2, format2);
                                                                                                   
                                                                                                   // Assert
                                                                                               }

 @Test
                                                                                               public void testPrint_VerifyPrinterUsesFormatSettings() throws IOException {
                                                                                                   // Arrange
                                                                                                   org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT
                                                                                                       .withQuoteMode(org.apache.commons.csv.QuoteMode.ALL)
                                                                                                       .withNullString("NULL")
                                                                                                       .withIgnoreEmptyLines(true);
                                                                                                   java.io.StringWriter writer = new java.io.StringWriter();
                                                                                                   
                                                                                                   // Act
                                                                                                   org.apache.commons.csv.CSVPrinter printer = new org.apache.commons.csv.CSVPrinter(writer, format);
                                                                                                   printer.printRecord("test", null, "value");
                                                                                                   
                                                                                                   // Assert
                                                                                                   
                                                                                                   // Verify the output contains the formatted values
                                                                                                   String result = writer.toString();
                                                                                                   assertTrue(result.contains("\"test\""));
                                                                                                   assertTrue(result.contains("NULL"));
                                                                                                   assertTrue(result.contains("\"value\""));
                                                                                               }

 @Test
                                                                                               public void testWithHeader_NewHeaderSetCorrectly() {
                                                                                                   // Setup base format
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT.withDelimiter(';')
                                                                                                       .withIgnoreEmptyLines(true);
                                                                                                   
                                                                                                   // Test with new header
                                                                                                   String[] newHeader = {"Name", "Age", "City"};
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(newHeader);
                                                                                                   
                                                                                                   // Verify header is set correctly
                                                                                                   assertArrayEquals(newHeader, newFormat.getHeader());
                                                                                                   
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(';', newFormat.getDelimiter());
                                                                                                   assertEquals('"', newFormat.getQuoteCharacter().charValue());
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_AllOtherPropertiesPreserved() {
                                                                                                   // Setup base format with all possible properties
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter('|')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeaderComments("Comment1", "Comment2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(true)
                                                                                                       .withIgnoreHeaderCase(true);
                                                                                                   
                                                                                                   // Test with new header
                                                                                                   String[] newHeader = {"Col1", "Col2"};
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(newHeader);
                                                                                                   
                                                                                                   // Verify all other properties remain unchanged
                                                                                                   assertEquals('|', newFormat.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('\''), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                   assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                   assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                                   assertArrayEquals(new String[]{"Comment1", "Comment2"}, newFormat.getHeaderComments());
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                   assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_Chaining() {
                                                                                                   // Test method chaining
                                                                                                   CSVFormat format = CSVFormat.newFormat(',') // Start with default format
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withDelimiter(';');
                                                                                                       
                                                                                                   assertTrue(format.getIgnoreEmptyLines());
                                                                                                   assertEquals(';', format.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                           public void testWithNullString_WithDifferentFormats() {
                                                                                               // Test with various predefined formats
                                                                                               CSVFormat format = CSVFormat.newFormat('\t')
                                                                                                   .withEscape('\\')
                                                                                                   .withRecordSeparator("\n")
                                                                                                   .withNullString("\\N");
                                                                                           }

 @Test
                                                                                       public void testParse_WithHeaderRecord() throws IOException {
                                                                                           // Arrange
                                                                                           org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT
                                                                                                   .withHeader("name", "age")
                                                                                                   .withSkipHeaderRecord(true);
                                                                                           String input = "name,age\nJohn,30\nJane,25";
                                                                                           java.io.Reader reader = new java.io.StringReader(input);
                                                                                           
                                                                                           // Act
                                                                                           org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                           
                                                                                           try {
                                                                                               // Assert
                                                                                               assertNotNull(parser);
                                                                                               List<org.apache.commons.csv.CSVRecord> records = parser.getRecords();
                                                                                               assertEquals(2, records.size());
                                                                                               assertEquals("John", records.get(0).get("name"));
                                                                                               assertEquals("30", records.get(0).get("age"));
                                                                                               assertEquals("Jane", records.get(1).get("name"));
                                                                                               assertEquals("25", records.get(1).get("age"));
                                                                                           } finally {
                                                                                               if (parser != null) {
                                                                                                   parser.close();
                                                                                               }
                                                                                           }
                                                                                       }

 @Test
                                                                                       public void testPrint_WithValidWriter() throws IOException {
                                                                                           // Arrange
                                                                                           CSVFormat format = CSVFormat.newFormat(','); // Create a format with comma delimiter
                                                                                           StringWriter writer = new StringWriter(); // Create a valid writer for testing
                                                                                           
                                                                                           // Act
                                                                                           CSVPrinter printer = format.print(writer);
                                                                                           
                                                                                           // Assert
                                                                                           assertNotNull(printer);
                                                                                           // Verify the printer's format indirectly by checking its behavior
                                                                                           assertEquals(',', format.getDelimiter());
                                                                                       }

 @Test
                                                                                       public void testPrint_WithCustomFormat() throws IOException {
                                                                                           // Arrange
                                                                                           StringWriter writer = new StringWriter();
                                                                                           CSVFormat customFormat = CSVFormat.DEFAULT
                                                                                               .withDelimiter(';')
                                                                                               .withQuote('"')
                                                                                               .withRecordSeparator("\r\n");
                                                                                           
                                                                                           // Act
                                                                                           CSVPrinter printer = new CSVPrinter(writer, customFormat);
                                                                                           printer.print("test");
                                                                                           printer.flush();
                                                                                           printer.close();
                                                                                           
                                                                                           // Assert
                                                                                           String expected = "\"test\"";
                                                                                           assertEquals(expected, writer.toString());
                                                                                       }

 @Test
                                                                                       public void testWithQuoteMode_AfterOtherModifications() {
                                                                                           // Setup complex format
                                                                                           org.apache.commons.csv.CSVFormat original = org.apache.commons.csv.CSVFormat.DEFAULT
                                                                                               .withDelimiter('|')
                                                                                               .withQuote('\'')
                                                                                               .withEscape('!')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withHeader("Col1", "Col2");
                                                                                           
                                                                                           // Define test quote mode
                                                                                           org.apache.commons.csv.QuoteMode newQuoteMode = org.apache.commons.csv.QuoteMode.ALL;
                                                                                           
                                                                                           // Test
                                                                                           org.apache.commons.csv.CSVFormat modified = original.withQuoteMode(newQuoteMode);
                                                                                           
                                                                                           // Verify
                                                                                           assertEquals(newQuoteMode, modified.getQuoteMode());
                                                                                           assertEquals('|', modified.getDelimiter());
                                                                                           assertEquals(Character.valueOf('\''), modified.getQuoteCharacter());
                                                                                           assertEquals(Character.valueOf('!'), modified.getEscapeCharacter());
                                                                                           assertFalse(modified.getIgnoreSurroundingSpaces());
                                                                                           assertArrayEquals(new String[]{"Col1", "Col2"}, modified.getHeader());
                                                                                       }

 @Test
                                                                                   public void testParse_WithNullString() throws IOException {
                                                                                       // Arrange
                                                                                       CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                       String input = "name,age\nJohn,NULL";
                                                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                                                       
                                                                                       // Act & Assert
                                                                                       try (CSVParser parser = new CSVParser(reader, format)) {
                                                                                           assertNotNull(parser);
                                                                                           List<CSVRecord> records = parser.getRecords();
                                                                                           assertEquals(2, records.size());
                                                                                           assertNull(records.get(1).get(1));
                                                                                       }
                                                                                   }

 @Test
                                                                               public void testParse_WithComments() throws IOException {
                                                                                   // Arrange
                                                                                   org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                   String input = "# This is a comment\nname,age\nJohn,30";
                                                                                   java.io.Reader reader = new java.io.StringReader(input);
                                                                                   
                                                                                   // Act
                                                                                   org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                                                   
                                                                                   // Assert
                                                                                   assertNotNull(parser);
                                                                                   assertEquals(1, parser.getRecords().size()); // Comment line should be skipped
                                                                                   assertEquals("name", parser.getRecords().get(0).get(0));
                                                                                   parser.close();
                                                                               }

 @Test
                                                                           public void testParse_WithEscapedCharacters() throws IOException {
                                                                               // Arrange
                                                                               CSVFormat format = CSVFormat.DEFAULT
                                                                                   .withDelimiter(',')
                                                                                   .withQuote('"')
                                                                                   .withEscape('\\')
                                                                                   .withIgnoreSurroundingSpaces(false)
                                                                                   .withIgnoreEmptyLines(false)
                                                                                   .withRecordSeparator("\n");
                                                                               
                                                                               String input = "name,age\n\"John \\\"The Boss\\\"\",30";
                                                                               java.io.Reader reader = new java.io.StringReader(input);
                                                                               
                                                                               // Act
                                                                               CSVParser parser = format.parse(reader);
                                                                               
                                                                               // Assert
                                                                               assertNotNull(parser);
                                                                               assertEquals(2, parser.getRecords().size());
                                                                               assertEquals("John \"The Boss\"", parser.getRecords().get(1).get(0));
                                                                               parser.close();
                                                                           }

 @Test
                                                                       public void testParse_WithQuotedValues() throws IOException {
                                                                           // Arrange
                                                                           org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withQuote('"');
                                                                           String input = "\"John, Smith\",\"30\"\n\"Jane, Doe\",\"25\"";
                                                                           
                                                                           // Act
                                                                           try (java.io.StringReader reader = new java.io.StringReader(input);
                                                                                org.apache.commons.csv.CSVParser parser = format.parse(reader)) {
                                                                               
                                                                               // Assert
                                                                               assertNotNull("Parser should not be null", parser);
                                                                               java.util.List<org.apache.commons.csv.CSVRecord> records = parser.getRecords();
                                                                               assertEquals("Should have 2 records", 2, records.size());
                                                                               assertEquals("First field of first record should match", "John, Smith", records.get(0).get(0));
                                                                               assertEquals("Second field of first record should match", "30", records.get(0).get(1));
                                                                           }
                                                                       }

 @Test
                                                                   public void testParse_WithEmptyInput() throws IOException {
                                                                       // Arrange
                                                                       CSVFormat format = CSVFormat.newFormat(','); // Create basic format with comma delimiter
                                                                       String input = "";
                                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                                       
                                                                       // Act
                                                                       CSVParser parser = format.parse(reader);
                                                                       
                                                                       // Assert
                                                                       assertNotNull(parser);
                                                                       assertFalse(parser.iterator().hasNext()); // Check no records are available
                                                                       parser.close();
                                                                   }

 @Test
                                                               public void testParse_WithCustomFormat() throws IOException {
                                                                   // Arrange
                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                       .withDelimiter(';')
                                                                       .withQuote('"')
                                                                       .withRecordSeparator("\n")
                                                                       .withHeader("Name", "Age");
                                                                   String input = "\"John\";30\n\"Jane\";25";
                                                                   java.io.StringReader reader = new java.io.StringReader(input);
                                                                   
                                                                   // Act
                                                                   CSVParser parser = format.parse(reader);
                                                                   
                                                                   // Assert
                                                                   assertNotNull(parser);
                                                                   List<CSVRecord> records = parser.getRecords();
                                                                   assertEquals(2, records.size());
                                                                   assertEquals("John", records.get(0).get(0));
                                                                   assertEquals("30", records.get(0).get(1));
                                                                   assertEquals("Jane", records.get(1).get(0));
                                                                   assertEquals("25", records.get(1).get(1));
                                                                   parser.close();
                                                               }

}
