package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                public void testInitializeHeader_WithEmptyFormatHeaderAndNoSkip() throws Exception {
                                                    // Setup
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    when(format.getHeader()).thenReturn(new String[0]);
                                                    when(format.getSkipHeaderRecord()).thenReturn(false);
                                                    when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                    
                                                    // Create real parser with mocked format
                                                    CSVParser parser = new CSVParser(new StringReader("col1,col2"), format);
                                                    
                                                    // Use reflection to set the format field since it's private
                                                    Field formatField = CSVParser.class.getDeclaredField("format");
                                                    formatField.setAccessible(true);
                                                    formatField.set(parser, format);
                                                    
                                                    // Use reflection to call private initializeHeader method
                                                    Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                    initializeHeaderMethod.setAccessible(true);
                                                    
                                                    // Execute
                                                    @SuppressWarnings("unchecked")
                                                    Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                    
                                                    // Verify
                                                    assertNotNull(result);
                                                    assertEquals(2, result.size());
                                                    assertEquals(Integer.valueOf(0), result.get("col1"));
                                                    assertEquals(Integer.valueOf(1), result.get("col2"));
                                                }

 @Test
                                                public void testInitializeHeader_WithDuplicateHeaders() throws Exception {
                                                    // Setup
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    when(format.getHeader()).thenReturn(new String[]{"dup", "dup"});
                                                    when(format.getSkipHeaderRecord()).thenReturn(false);
                                                    when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                    
                                                    // Create a real parser instance instead of mocking it
                                                    CSVParser parser = new CSVParser(new StringReader(""), format);
                                                    
                                                    // Use reflection to access private initializeHeader method
                                                    Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                    initializeHeader.setAccessible(true);
                                                    
                                                    // Expect exception
                                                    thrown.expect(IllegalArgumentException.class);
                                                    thrown.expectMessage("The header contains a duplicate name: \"dup\" in [dup, dup]");
                                                    
                                                    // Execute
                                                    initializeHeader.invoke(parser);
                                                }

 @Test
                                                public void testInitializeHeader_WithEmptyHeadersAndIgnoreEmptyEnabled() throws Exception {
                                                    // Setup
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    when(format.getHeader()).thenReturn(new String[]{"", null, "valid"});
                                                    when(format.getSkipHeaderRecord()).thenReturn(false);
                                                    when(format.getIgnoreEmptyHeaders()).thenReturn(true);
                                                    
                                                    // Create real parser with mocked format
                                                    Reader reader = new StringReader("");
                                                    CSVParser parser = new CSVParser(reader, format);
                                                    
                                                    // Use reflection to access private initializeHeader method
                                                    Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                    initializeHeaderMethod.setAccessible(true);
                                                    
                                                    // Execute
                                                    @SuppressWarnings("unchecked")
                                                    Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                    
                                                    // Verify
                                                    assertNotNull(result);
                                                    assertEquals(3, result.size());
                                                    assertTrue(result.containsKey(""));
                                                    assertTrue(result.containsKey(null));
                                                    assertTrue(result.containsKey("valid"));
                                                }

 @Test
                                                public void testInitializeHeader_WithEmptyHeadersAndIgnoreEmptyDisabled() throws Exception {
                                                    // Setup
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    when(format.getHeader()).thenReturn(new String[]{"", "", "valid"});
                                                    when(format.getSkipHeaderRecord()).thenReturn(false);
                                                    when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                    
                                                    // Create real parser with mocked format
                                                    CSVParser parser = new CSVParser(new StringReader(""), format);
                                                    
                                                    // Use reflection to access private format field
                                                    Field formatField = CSVParser.class.getDeclaredField("format");
                                                    formatField.setAccessible(true);
                                                    formatField.set(parser, format);
                                                    
                                                    // Get initializeHeader method via reflection
                                                    Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                    initializeHeader.setAccessible(true);
                                                    
                                                    // Expect exception
                                                    thrown.expect(IllegalArgumentException.class);
                                                    thrown.expectMessage("The header contains a duplicate name: \"\" in [, , valid]");
                                                    
                                                    // Execute
                                                    initializeHeader.invoke(parser);
                                                }

 @Test
                                                public void testInitializeHeader_WithNullFormatHeader() throws Exception {
                                                    // Setup
                                                    CSVFormat format = mock(CSVFormat.class);
                                                    when(format.getHeader()).thenReturn(null);
                                                    
                                                    // Create real parser instance instead of mocking
                                                    CSVParser parser = new CSVParser(new StringReader(""), format);
                                                    
                                                    // Use reflection to access private initializeHeader method
                                                    Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                    initializeHeaderMethod.setAccessible(true);
                                                    
                                                    // Execute
                                                    @SuppressWarnings("unchecked")
                                                    Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                                    
                                                    // Verify
                                                    assertNull(result);
                                                }

 @Test
                                            public void testInitializeHeader_WithEmptyFormatHeaderAndNullNextRecord() throws Exception {
                                                // Setup
                                                CSVFormat format = mock(CSVFormat.class);
                                                when(format.getHeader()).thenReturn(new String[0]);
                                                when(format.getSkipHeaderRecord()).thenReturn(false);
                                                
                                                // Create real parser with empty input
                                                Reader reader = new StringReader("");
                                                CSVParser parser = new CSVParser(reader, format);
                                                
                                                // Use reflection to get the lexer field
                                                Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                                lexerField.setAccessible(true);
                                                Object lexer = lexerField.get(parser);
                                                
                                                // Use reflection to call private method
                                                Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                initializeHeader.setAccessible(true);
                                                
                                                // Execute
                                                @SuppressWarnings("unchecked")
                                                Map<String, Integer> result = (Map<String, Integer>) initializeHeader.invoke(parser);
                                                
                                                // Verify
                                                assertNull(result);
                                            }

 @Test
                                        public void testInitializeHeader_WithNonEmptyFormatHeaderAndSkip() throws Exception {
                                            // Setup
                                            CSVFormat format = mock(CSVFormat.class);
                                            when(format.getHeader()).thenReturn(new String[]{"header1", "header2"});
                                            when(format.getSkipHeaderRecord()).thenReturn(true);
                                            when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                            
                                            // Create real parser with mocked dependencies
                                            Reader reader = new StringReader("");
                                            CSVParser parser = new CSVParser(reader, format);
                                            
                                            // Mock lexer using reflection since Lexer is not public
                                            Class<?> lexerClass = Class.forName("org.apache.commons.csv.Lexer");
                                            Object lexer = mock(lexerClass);
                                            
                                            // Mock Token using reflection since Token is not public
                                            Class<?> tokenClass = Class.forName("org.apache.commons.csv.Token");
                                            Object[] enumConstants = tokenClass.getEnumConstants();
                                            Object tokenEOF = null;
                                            for (Object constant : enumConstants) {
                                                if (constant.toString().equals("TOKEN_EOF")) {
                                                    tokenEOF = constant;
                                                    break;
                                                }
                                            }
                                            
                                            when(lexerClass.getMethod("nextToken").invoke(lexer)).thenReturn(tokenEOF);
                                            
                                            // Use reflection to set private fields
                                            Field formatField = CSVParser.class.getDeclaredField("format");
                                            formatField.setAccessible(true);
                                            formatField.set(parser, format);
                                            
                                            Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                            lexerField.setAccessible(true);
                                            lexerField.set(parser, lexer);
                                            
                                            // Get initializeHeader method via reflection
                                            Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
                                            initializeHeader.setAccessible(true);
                                            
                                            // Execute
                                            @SuppressWarnings("unchecked")
                                            Map<String, Integer> result = (Map<String, Integer>) initializeHeader.invoke(parser);
                                            
                                            // Verify
                                            assertNotNull(result);
                                            assertEquals(2, result.size());
                                            assertEquals(Integer.valueOf(0), result.get("header1"));
                                            assertEquals(Integer.valueOf(1), result.get("header2"));
                                        }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
        public void testInitializeHeader_DetectsArrayBoundsMutant() throws Exception {
            // Setup test data
            final String[] testHeaders = {"header1", "header2"};
            
            // Mock dependencies
            CSVFormat format = mock(CSVFormat.class);
            when(format.getHeader()).thenReturn(testHeaders);
            when(format.getSkipHeaderRecord()).thenReturn(false);
            when(format.getIgnoreEmptyHeaders()).thenReturn(false);
            
            // Create parser with mocked format
            CSVParser parser = new CSVParser(new StringReader(""), format);
            
            // Use reflection to access private method since we're specifically testing mutant detection
            Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
            method.setAccessible(true);
            
            // This should throw ArrayIndexOutOfBoundsException for the mutant
            method.invoke(parser);
        }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
        public void testInitializeHeader_DetectsArrayBoundsMutantThroughPublicAPI() throws Exception {
            // Setup test data
            final String[] testHeaders = {"header1", "header2"};
            final String csvData = "value1,value2\n";
            
            // Mock format
            CSVFormat format = mock(CSVFormat.class);
            when(format.getHeader()).thenReturn(testHeaders);
            when(format.getSkipHeaderRecord()).thenReturn(false);
            when(format.getIgnoreEmptyHeaders()).thenReturn(false);
            
            // Create parser - the mutant will cause exception during initialization
            new CSVParser(new StringReader(csvData), format);
        }

 @Test
       public void testInitializeHeader_ShouldIncludeFirstColumn() throws Exception {
           // Setup test data
           String[] headers = {"First", "Second", "Third"};
           CSVFormat format = mock(CSVFormat.class);
           when(format.getHeader()).thenReturn(headers);
           when(format.getSkipHeaderRecord()).thenReturn(false);
           when(format.getIgnoreEmptyHeaders()).thenReturn(false);
           
           // Create parser (we'll mock the dependencies we don't need to test)
           CSVParser parser = new CSVParser(new StringReader(""), format);
           
           // Use reflection to access private method since it's called in constructor
           Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
           method.setAccessible(true);
           Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
           
           // Verify all headers are present with correct indices
           assertNotNull("Header map should not be null", headerMap);
           assertEquals("Should contain all headers", 3, headerMap.size());
           assertEquals("First header should be at index 0", Integer.valueOf(0), headerMap.get("First"));
           assertEquals("Second header should be at index 1", Integer.valueOf(1), headerMap.get("Second"));
           assertEquals("Third header should be at index 2", Integer.valueOf(2), headerMap.get("Third"));
           
           // Specifically test the mutant would fail this
           assertTrue("Header map must contain first column", headerMap.containsKey("First"));
       }

 @Test
      public void testInitializeHeaderWithDuplicateNonEmptyHeaderShouldThrowException() throws Exception {
          // Setup
          CSVFormat format = mock(CSVFormat.class);
          when(format.getHeader()).thenReturn(new String[]{"name", "name"}); // duplicate header
          when(format.getSkipHeaderRecord()).thenReturn(false);
          when(format.getIgnoreEmptyHeaders()).thenReturn(false);
          
          CSVParser parser = new CSVParser(new StringReader(""), format);
          
          // Test and verify
          try {
              parser.getHeaderMap();
              fail("Expected IllegalArgumentException for duplicate header");
          } catch (IllegalArgumentException e) {
              assertTrue(e.getMessage().contains("The header contains a duplicate name"));
          }
      }

 @Test
      public void testInitializeHeaderWithDuplicateEmptyHeaderWhenNotIgnoredShouldThrowException() throws Exception {
          // Setup
          CSVFormat format = mock(CSVFormat.class);
          when(format.getHeader()).thenReturn(new String[]{"", ""}); // duplicate empty header
          when(format.getSkipHeaderRecord()).thenReturn(false);
          when(format.getIgnoreEmptyHeaders()).thenReturn(false); // empty headers not ignored
          
          CSVParser parser = new CSVParser(new StringReader(""), format);
          
          // Test and verify
          try {
              parser.getHeaderMap();
              fail("Expected IllegalArgumentException for duplicate empty header");
          } catch (IllegalArgumentException e) {
              assertTrue(e.getMessage().contains("The header contains a duplicate name"));
          }
      }

 @Test
      public void testInitializeHeaderWithDuplicateEmptyHeaderWhenIgnoredShouldNotThrowException() throws Exception {
          // Setup
          CSVFormat format = mock(CSVFormat.class);
          when(format.getHeader()).thenReturn(new String[]{"", ""}); // duplicate empty header
          when(format.getSkipHeaderRecord()).thenReturn(false);
          when(format.getIgnoreEmptyHeaders()).thenReturn(true); // empty headers ignored
          
          CSVParser parser = new CSVParser(new StringReader(""), format);
          
          // Test - should not throw exception
          Map<String, Integer> headerMap = parser.getHeaderMap();
          assertNotNull(headerMap);
          assertEquals(2, headerMap.size());
      }

 @Test
     public void testInitializeHeader_DetectsFinalRemovalMutant() throws Exception {
         // Setup
         CSVFormat format = mock(CSVFormat.class);
         when(format.getHeader()).thenReturn(new String[]{"header1", "header2"});
         when(format.getSkipHeaderRecord()).thenReturn(false);
         when(format.getIgnoreEmptyHeaders()).thenReturn(false);
         
         // Create a CSVParser with mocked format
         CSVParser parser = new CSVParser(new StringReader(""), format);
         
         // Use reflection to access private initializeHeader method
         Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
         method.setAccessible(true);
         Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
         
         // Verify the header values weren't modified during processing
         assertNotNull(result);
         assertEquals(2, result.size());
         assertTrue(result.containsKey("header1"));
         assertTrue(result.containsKey("header2"));
         assertEquals(Integer.valueOf(0), result.get("header1"));
         assertEquals(Integer.valueOf(1), result.get("header2"));
         
         // The key test: verify no modification happened to header values
         // If 'final' was removed, a bug could modify the header value between checks
         verify(format, times(2)).getIgnoreEmptyHeaders(); // Called for each header
     }

 @Test
    public void testInitializeHeader_ShouldNotThrowExceptionWithValidHeaders() throws Exception {
        // Setup test data
        String[] headers = {"col1", "col2", "col3"};
        
        // Mock dependencies
        CSVFormat format = mock(CSVFormat.class);
        when(format.getHeader()).thenReturn(headers);
        when(format.getSkipHeaderRecord()).thenReturn(false);
        when(format.getIgnoreEmptyHeaders()).thenReturn(false);
        
        // Mock nextRecord() to return null since we're using format headers
        CSVParser parser = new CSVParser(new StringReader(""), format);
        
        // Use reflection to access private method since it's called in constructor
        Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
        method.setAccessible(true);
        
        // Execute and verify
        Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
        
        // Assertions
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(Integer.valueOf(0), result.get("col1"));
        assertEquals(Integer.valueOf(1), result.get("col2"));
        assertEquals(Integer.valueOf(2), result.get("col3"));
        
        // The mutant would throw ArrayIndexOutOfBoundsException before reaching these assertions
    }

 @Test
   public void testInitializeHeaderWithMultipleHeadersShouldMapCorrectIndices() throws Exception {
       // Setup
       CSVFormat format = CSVFormat.DEFAULT.withHeader("Header1", "Header2", "Header3");
       Reader reader = new StringReader("ignored\nvalue1,value2,value3"); // First line will be skipped
       CSVParser parser = new CSVParser(reader, format);
       
       // Test
       Map<String, Integer> headerMap = parser.getHeaderMap();
       
       // Verify
       assertNotNull(headerMap);
       assertEquals(3, headerMap.size());
       assertEquals(Integer.valueOf(0), headerMap.get("Header1"));
       assertEquals(Integer.valueOf(1), headerMap.get("Header2")); // This would fail with the mutant
       assertEquals(Integer.valueOf(2), headerMap.get("Header3")); // This would fail with the mutant
   }

 @Test
  public void testInitializeHeader_ShouldRejectDuplicateEmptyHeaders_WhenIgnoreEmptyHeadersFalse() throws Exception {
      // Setup
      CSVFormat format = mock(CSVFormat.class);
      when(format.getHeader()).thenReturn(new String[]{"", "   "}); // Two empty headers
      when(format.getSkipHeaderRecord()).thenReturn(false);
      when(format.getIgnoreEmptyHeaders()).thenReturn(false);
      
      CSVParser parser = new CSVParser(new StringReader(""), format);
      
      // Test & Verify
      try {
          parser.getHeaderMap();
          fail("Expected IllegalArgumentException for duplicate empty headers");
      } catch (IllegalArgumentException e) {
          assertTrue(e.getMessage().contains("The header contains a duplicate name"));
      }
  }

 @Test
  public void testInitializeHeader_ShouldRejectDuplicateWhitespaceHeaders_WhenIgnoreEmptyHeadersFalse() throws Exception {
      // Setup
      CSVFormat format = mock(CSVFormat.class);
      when(format.getHeader()).thenReturn(new String[]{"   ", "   "}); // Two whitespace-only headers
      when(format.getSkipHeaderRecord()).thenReturn(false);
      when(format.getIgnoreEmptyHeaders()).thenReturn(false);
      
      CSVParser parser = new CSVParser(new StringReader(""), format);
      
      // Test & Verify
      try {
          parser.getHeaderMap();
          fail("Expected IllegalArgumentException for duplicate whitespace headers");
      } catch (IllegalArgumentException e) {
          assertTrue(e.getMessage().contains("The header contains a duplicate name"));
      }
  }

 @Test
 public void testInitializeHeaderWithDuplicateEmptyHeadersWhenIgnored() throws Exception {
     // Setup
     CSVFormat format = mock(CSVFormat.class);
     when(format.getHeader()).thenReturn(new String[]{"", ""}); // Duplicate empty headers
     when(format.getSkipHeaderRecord()).thenReturn(false);
     when(format.getIgnoreEmptyHeaders()).thenReturn(true); // Configure to ignore empty headers
     
     CSVParser parser = new CSVParser(new StringReader(""), format);
     
     // Test - should not throw exception with original code
     Map<String, Integer> result = parser.getHeaderMap();
     
     // Verify
     assertNotNull(result);
     assertEquals(2, result.size());
     assertEquals(Integer.valueOf(0), result.get(""));
     assertEquals(Integer.valueOf(1), result.get(""));
     
     // Note: The mutant would throw IllegalArgumentException here
 }

}
