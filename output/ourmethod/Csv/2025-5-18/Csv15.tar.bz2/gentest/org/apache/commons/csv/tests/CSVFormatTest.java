package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                               public void testPrintAndQuote_AllQuoteMode() throws IOException {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test";
                                                                   
                                                                   // Execute
                                                                   format.print(value, out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_AllNonNullQuoteMode() throws IOException {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test";
                                                                   
                                                                   // Execute
                                                                   format.print(value, out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_NonNumericQuoteModeWithNumber() throws IOException {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                   StringWriter out = new StringWriter();
                                                                   Integer number = 123;
                                                                   
                                                                   // Execute
                                                                   format.print(number, out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("123", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_NonNumericQuoteModeWithString() throws IOException {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test";
                                                                   
                                                                   // Execute
                                                                   format.print(value, out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_NoneQuoteMode() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test,value";
                                                                   
                                                                   // Get the private method using reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(
                                                                       format, 
                                                                       null, 
                                                                       value, 
                                                                       0, 
                                                                       value.length(), 
                                                                       out, 
                                                                       false
                                                                   );
                                                                   
                                                                   // Verify
                                                                   assertEquals("test,value", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_MinimalQuoteModeWithEmptyStringNewRecord() throws IOException {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "";
                                                                   
                                                                   // Execute
                                                                   format.print(value, out, true);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_MinimalQuoteModeWithSpecialChars() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                                       .withDelimiter(',')
                                                                       .withQuote('"');
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test,value";
                                                                   
                                                                   // Get the private method using reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test,value\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_MinimalQuoteModeWithQuoteChar() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL)
                                                                       .withQuote('"');
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test\"value";
                                                                   
                                                                   // Get the private method via reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(
                                                                       format, 
                                                                       null, 
                                                                       value, 
                                                                       0, 
                                                                       value.length(), 
                                                                       out, 
                                                                       false
                                                                   );
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test\"\"value\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_MinimalQuoteModeWithControlCharsAtStart() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "\u0001test";
                                                                   
                                                                   // Use reflection to access private method
                                                                   Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuote.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuote.invoke(format, null, value, 0, value.length(), out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"\u0001test\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_MinimalQuoteModeWithControlCharsAtEnd() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test\u0001";
                                                                   
                                                                   // Get the private method using reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test\u0001\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_MinimalQuoteModeWithLineBreak() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test\nvalue";
                                                                   
                                                                   // Get the private method using reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("\"test\nvalue\"", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_InvalidQuoteMode() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = mock(CSVFormat.class);
                                                                   when(format.getQuoteMode()).thenReturn(null);
                                                                   when(format.getDelimiter()).thenReturn(',');
                                                                   when(format.getQuoteCharacter()).thenReturn('"');
                                                                   
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "test";
                                                                   
                                                                   thrown.expect(IllegalStateException.class);
                                                                   thrown.expectMessage("Unexpected Quote value: null");
                                                                   
                                                                   // Get the private method via reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                               }

 @Test
                                                               public void testPrintAndQuote_SubstringPortion() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "longtestvalue";
                                                                   
                                                                   // Get the private method using reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute - test substring from index 4 to 8 (4 chars)
                                                                   printAndQuoteMethod.invoke(
                                                                       format, 
                                                                       null, 
                                                                       value, 
                                                                       4, 
                                                                       4, 
                                                                       out, 
                                                                       false
                                                                   );
                                                                   
                                                                   // Verify
                                                                   assertEquals("test", out.toString());
                                                               }

 @Test
                                                               public void testPrintAndQuote_EmptyStringNotNewRecord() throws Exception {
                                                                   // Setup
                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                   StringWriter out = new StringWriter();
                                                                   String value = "";
                                                                   
                                                                   // Get the private method using reflection
                                                                   Method printAndQuoteMethod = CSVFormat.class.getDeclaredMethod(
                                                                       "printAndQuote", 
                                                                       Object.class, 
                                                                       CharSequence.class, 
                                                                       int.class, 
                                                                       int.class, 
                                                                       Appendable.class, 
                                                                       boolean.class
                                                                   );
                                                                   printAndQuoteMethod.setAccessible(true);
                                                                   
                                                                   // Execute
                                                                   printAndQuoteMethod.invoke(format, null, value, 0, value.length(), out, false);
                                                                   
                                                                   // Verify
                                                                   assertEquals("", out.toString());
                                                               }

 @Test
                       public void testPrintAndQuoteDetectsQuoteModeMutation() throws IOException {
                           // Create a format with ALL quote mode (should always quote)
                           CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                           
                           // Prepare test data
                           String testValue = "test";
                           StringBuilder output = new StringBuilder();
                           boolean newRecord = true;
                           
                           // Call the method through the CSVPrinter API which will use printAndQuote
                           CSVPrinter printer = format.printer();
                           printer.print(testValue);
                           printer.flush();
                           
                           // Verify the output is quoted (as ALL mode should do)
                           // If mutation is present, it would use MINIMAL mode and not quote this simple value
                           assertEquals("\"test\"", output.toString());
                           
                           // Additional verification with a different quote mode
                           format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                           output = new StringBuilder();
                           printer = format.printer();
                           printer.print(123); // Number should not be quoted in NON_NUMERIC mode
                           
                           // If mutation is present, it would use MINIMAL mode and might quote numbers
                           assertEquals("123", output.toString());
                       }

 @Test
                      public void testPrintAndQuoteNonNumericModeWithNumberShouldNotQuote() throws IOException {
                          // Setup
                          CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                          Appendable out = mock(Appendable.class);
                          Number numberValue = 123; // Any Number instance
                          String stringValue = "test";
                          
                          // Test with Number - should not be quoted in original
                          format.print(numberValue, out, false);
                          
                          // Verify no quotes were added for Number
                          verify(out).append(any(CharSequence.class), eq(0), eq(3)); // Just the number
                          verify(out, never()).append(eq('"')); // No quote characters
                          
                          // Test with String - should be quoted
                          format.print(stringValue, out, false);
                          
                          // Verify quotes were added for String
                          verify(out).append(eq('"')); // Opening quote
                          verify(out).append(eq(stringValue)); // The content
                          verify(out).append(eq('"')); // Closing quote
                          
                          // This test would fail if the mutation is present because:
                          // 1. The Number would be quoted when it shouldn't be
                          // 2. We would see quote characters in the verification for Number case
                      }

 @Test
                     public void testPrintAndQuoteDetectsControlCharacters() throws IOException {
                         // Setup
                         CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                         StringBuilder out = new StringBuilder();
                         String value = "!"; // ASCII 33, between SP(32) and COMMENT(35)
                         boolean newRecord = true;
                         
                         // Create a spy to access private method
                         CSVFormat spyFormat = spy(format);
                         doCallRealMethod().when(spyFormat).print(any(), any(), anyBoolean());
                         
                         // Execute
                         spyFormat.print(value, out, newRecord);
                         
                         // Verify - original would quote this (since 33 <= 35), mutant wouldn't (33 > 32)
                         assertTrue("Should be quoted due to control character", 
                                    out.toString().startsWith("\"") && out.toString().endsWith("\""));
                         
                         // Additional test with another control character
                         out = new StringBuilder();
                         value = "\""; // ASCII 34
                         spyFormat.print(value, out, newRecord);
                         assertTrue("Should be quoted due to control character", 
                                    out.toString().startsWith("\"") && out.toString().endsWith("\""));
                     }

 @Test
                    public void testPrintAndQuote_MinimalMode_EndsWithSpace() throws IOException {
                        // Setup
                        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                        StringBuilder out = new StringBuilder();
                        String value = "test "; // Ends with space character
                        boolean newRecord = true;
                        
                        // Create a spy to access private method
                        CSVFormat spyFormat = spy(format);
                        doCallRealMethod().when(spyFormat).print(any(), any(), anyBoolean());
                        
                        // Execute
                        spyFormat.print(value, out, newRecord);
                        
                        // Verify
                        // Original would quote (since ends with space <= SP)
                        // Mutant would not quote (since space not < SP)
                        assertTrue("Value ending with space should be quoted", 
                                   out.toString().startsWith("\"") && out.toString().endsWith("\""));
                        
                        // Additional check for exact output
                        assertEquals("\"test \"", out.toString());
                    }

 @Test
                   public void testPrintAndQuoteWithNonCommaDelimiter() throws IOException {
                       // Setup - create format with tab delimiter
                       CSVFormat format = CSVFormat.newFormat('\t')
                               .withQuote('"')
                               .withQuoteMode(QuoteMode.MINIMAL);
                       
                       // Test data containing tab character that should be quoted
                       String input = "value1\tvalue2";
                       StringBuilder output = new StringBuilder();
                       
                       // Call method under test
                       format.print(input, output, false);
                       
                       // Verify - tab should be quoted since it's the delimiter
                       // If mutation survives, it will use comma instead of tab and fail to quote
                       assertEquals("\"value1\tvalue2\"", output.toString());
                       
                       // Additional verification that getDelimiter() was called
                       // This ensures we're not using hardcoded comma
                       assertEquals('\t', format.getDelimiter());
                   }

 @Test
                  public void testPrintAndQuoteWithNonMinimalQuoteMode() throws IOException {
                      // Setup
                      StringBuilder out = new StringBuilder();
                      String value = "test";
                      boolean newRecord = true;
                      
                      // Create format with ALL quote mode (non-minimal)
                      CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                      
                      // Mock the behavior of getQuoteMode() to return ALL
                      // (This would be different in the mutant which would ignore this)
                      when(format.getQuoteMode()).thenReturn(QuoteMode.ALL);
                      
                      // Call the method
                      format.print(value, out, newRecord);
                      
                      // Verify - with ALL mode, everything should be quoted
                      assertEquals("\"" + value + "\"", out.toString());
                      
                      // Additional verification that getQuoteMode() was called
                      verify(format).getQuoteMode();
                  }

 @Test
                 public void testPrintAndQuoteEmptyStringNewRecordShouldQuote() throws IOException {
                     // Setup
                     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                     StringBuilder out = new StringBuilder();
                     String value = "";
                     boolean newRecord = true;
                     
                     // Expected behavior: empty string at start of record should be quoted
                     String expected = "\"\""; // quoted empty string
                     
                     // Execute
                     format.print(value, out, newRecord);
                     
                     // Verify
                     assertEquals("Empty string at start of record should be quoted", 
                                  expected, 
                                  out.toString());
                     
                     // Additional verification that the output is indeed quoted
                     assertTrue("Output should start with quote character", 
                                out.toString().startsWith("\""));
                     assertTrue("Output should end with quote character", 
                                out.toString().endsWith("\""));
                 }

 @Test
                public void testPrintAndQuoteNonNumericModeWithNumberShouldNotQuote1() throws IOException {
                    // Setup CSVFormat with NON_NUMERIC quote mode
                    CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                    
                    // Create test objects - one Number and one non-Number
                    Number numberValue = 123;
                    String nonNumberValue = "abc";
                    
                    // Create output buffers
                    StringBuilder numberOutput = new StringBuilder();
                    StringBuilder nonNumberOutput = new StringBuilder();
                    
                    // Call the method for both cases
                    format.print(numberValue, numberOutput, false);
                    format.print(nonNumberValue, nonNumberOutput, false);
                    
                    // Verify number output is NOT quoted (should fail if mutant is present)
                    assertFalse("Number value should not be quoted in NON_NUMERIC mode", 
                        numberOutput.toString().startsWith("\"") && numberOutput.toString().endsWith("\""));
                    
                    // Verify non-number output IS quoted (should pass in both original and mutant)
                    assertTrue("Non-number value should be quoted in NON_NUMERIC mode",
                        nonNumberOutput.toString().startsWith("\"") && nonNumberOutput.toString().endsWith("\""));
                }

 @Test
               public void testPrintAndQuoteNonNumericMode() throws IOException {
                   // Setup CSVFormat with NON_NUMERIC quote mode
                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                   
                   // Test with a Number (should NOT be quoted in original, WOULD be quoted in mutant)
                   StringBuilder numberOutput = new StringBuilder();
                   format.print(42, numberOutput, false);
                   assertFalse("Number should not be quoted", 
                              numberOutput.toString().startsWith("\"") && numberOutput.toString().endsWith("\""));
                   
                   // Test with a non-Number (should be quoted in original, NOT quoted in mutant)
                   StringBuilder stringOutput = new StringBuilder();
                   format.print("test", stringOutput, false);
                   assertTrue("String should be quoted", 
                             stringOutput.toString().startsWith("\"") && stringOutput.toString().endsWith("\""));
               }

 @Test
              public void testPrintAndQuote_MinimalMode_DetectCommentCharMutation() throws IOException {
                  // Setup
                  CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                  StringBuilder out = new StringBuilder();
                  String value = "#comment";  // '#' is typically the COMMENT char (ASCII 35)
                  boolean newRecord = true;
                  
                  // The character '#' (35) is > SP (32) but <= COMMENT (assuming COMMENT is '#')
                  // Original code would quote it, mutated code wouldn't
                  
                  // Execute
                  format.print(value, out, newRecord);
                  
                  // Verify
                  // Original behavior would quote it (starts with COMMENT char)
                  // Mutated behavior wouldn't quote it (since '#' > SP)
                  assertTrue("Output should be quoted when starting with COMMENT char", 
                             out.toString().startsWith("\"") && out.toString().endsWith("\""));
                  
                  // Additional check for exact output
                  assertEquals("\"#comment\"", out.toString());
              }

 @Test
             public void testPrintAndQuote_MinimalMode_EndsWithSpace1() throws IOException {
                 // Setup
                 CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                 StringBuilder out = new StringBuilder();
                 String value = "test "; // Ends with space character (ASCII 32)
                 
                 // Execute
                 format.print(value, out, false); // false indicates not a new record
                 
                 // Verify
                 // Original behavior would quote it (since it ends with SP which is <= SP)
                 // Mutated behavior would not quote it (since SP is not < SP)
                 assertTrue("Value ending with space should be quoted", 
                            out.toString().startsWith("\"") && out.toString().endsWith("\""));
                 
                 // Additional check for exact output
                 assertEquals("\"test \"", out.toString());
             }

 @Test
            public void testPrintAndQuoteWithNonCommaDelimiter1() throws IOException {
                // Setup - create format with pipe delimiter
                char pipeDelimiter = '|';
                CSVFormat format = CSVFormat.newFormat(pipeDelimiter)
                        .withQuoteMode(QuoteMode.MINIMAL)
                        .withQuote('"');
                
                // Test data contains the pipe delimiter which should trigger quoting
                String testValue = "value1|value2";
                StringBuilder out = new StringBuilder();
                boolean newRecord = true;
                
                // Call the method through the CSVPrinter which will invoke printAndQuote
                CSVPrinter printer = format.printer();
                printer.print(testValue);
                printer.flush();
                
                // Verify the output was properly quoted
                String result = out.toString();
                assertTrue("Output should be quoted when containing delimiter", 
                           result.startsWith("\"") && result.endsWith("\""));
                assertTrue("Output should contain the original value", 
                           result.contains(testValue));
                
                // Additional verification that the pipe was treated as delimiter
                // and not the hardcoded comma from the mutant
                assertFalse("Output should not contain extra commas", 
                            result.contains(","));
            }

 @Test
           public void testPrintAndQuoteNonNumericModeWithNumber() throws IOException {
               // Setup
               CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
               StringBuilder out = new StringBuilder();
               Object numberObj = 123; // Number object
               
               // Call method
               format.print(numberObj, out, false);
               
               // Verify - original would not quote numbers, mutant would
               assertFalse("Number should not be quoted in NON_NUMERIC mode", 
                          out.toString().startsWith("\"") && out.toString().endsWith("\""));
               
               // Additional verification for mutant detection
               assertEquals("123", out.toString());
           }

 @Test
          public void testPrintAndQuoteUsesConfiguredQuoteMode() throws IOException {
              // Setup test data
              final QuoteMode testMode = QuoteMode.ALL;
              final String testValue = "test";
              final StringBuilder output = new StringBuilder();
              
              // Create CSVFormat with specific quote mode
              CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(testMode);
              
              // Mock/spy the format to verify getQuoteMode() is called
              CSVFormat spyFormat = spy(format);
              
              // Call the method
              spyFormat.print(testValue, output, false);
              
              // Verify getQuoteMode() was called (would fail with mutant)
              verify(spyFormat).getQuoteMode();
              
              // Verify output follows the configured quote mode (ALL should always quote)
              assertEquals("\"" + testValue + "\"", output.toString());
          }

 @Test
         public void testPrintAndQuoteEmptyStringNewRecordShouldBeQuoted() throws IOException {
             // Setup
             CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
             StringBuilder out = new StringBuilder();
             String value = "";
             boolean newRecord = true;
             
             // Execute
             format.print(value, out, newRecord);
             
             // Verify
             // Original behavior would quote empty string for new record: ""
             // Mutated behavior would not quote it (empty string)
             assertTrue("Empty string for new record should be quoted", 
                        out.toString().startsWith("\"") && out.toString().endsWith("\""));
             
             // Additional verification that it's exactly two quotes (empty quoted string)
             assertEquals("\"\"", out.toString());
         }

 @Test
        public void testPrintAndQuoteDetectsQuoteModeMutation1() throws IOException {
            // Setup test data
            String testValue = "test";
            StringBuilder out = new StringBuilder();
            boolean newRecord = true;
            
            // Create format with ALL quote mode (should always quote)
            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
            
            // Call the method
            format.print(testValue, out, newRecord);
            
            // Verify output is quoted (original behavior)
            assertEquals("\"test\"", out.toString());
            
            // If the mutant was present, it would use MINIMAL mode and not quote this simple value
            // So this test would fail with mutant, catching it
        }

 @Test
       public void testPrintAndQuoteNonNumericModeWithNumberShouldNotQuote2() throws IOException {
           // Setup
           CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
           StringBuilder out = new StringBuilder();
           boolean newRecord = true;
           
           // Test with Number (should not be quoted)
           Number numberValue = 123;
           format.print(numberValue, out, newRecord);
           assertFalse("Number should not be quoted in NON_NUMERIC mode", 
                      out.toString().startsWith("\"") && out.toString().endsWith("\""));
           
           // Clear output
           out.setLength(0);
           
           // Test with non-Number (should be quoted)
           String stringValue = "abc";
           format.print(stringValue, out, newRecord);
           assertTrue("Non-number should be quoted in NON_NUMERIC mode", 
                     out.toString().startsWith("\"") && out.toString().endsWith("\""));
           
           // The mutant would fail the first assertion by quoting the number
       }

 @Test
      public void testPrintAndQuoteWithNoneQuoteModeAndSpecialCharacters() throws IOException {
          // Setup
          CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NONE);
          StringBuilder output = new StringBuilder();
          
          // Input contains special characters that would need escaping
          String input = "test,value\"with\"quotes";
          int offset = 0;
          int len = input.length();
          boolean newRecord = true;
          
          // Use reflection to access private method
          try {
              Method printAndQuote = CSVFormat.class.getDeclaredMethod(
                  "printAndQuote", 
                  Object.class, 
                  CharSequence.class, 
                  int.class, 
                  int.class, 
                  Appendable.class, 
                  boolean.class
              );
              printAndQuote.setAccessible(true);
              
              // Execute
              printAndQuote.invoke(format, null, input, offset, len, output, newRecord);
              
              // Verify
              // Original behavior would escape the quotes and comma
              // Mutant would just append raw string
              String result = output.toString();
              assertNotEquals("Raw output should not match input when escaping is needed", input, result);
              
              // Additional verification that special characters were handled
              assertTrue("Output should contain escaped characters", 
                  result.contains("\\\"") || result.contains("\\,"));
          } catch (Exception e) {
              fail("Reflection failed: " + e.getMessage());
          }
      }

 @Test
     public void testPrintAndQuote_MinimalMode_EndsWithSpace2() throws IOException {
         // Setup
         CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
         StringBuilder out = new StringBuilder();
         String value = "test "; // Ends with space character
         boolean newRecord = true;
         
         // Create a spy to access private method
         CSVFormat spyFormat = spy(format);
         doCallRealMethod().when(spyFormat).print(any(), any(), anyBoolean());
         
         // Execute
         spyFormat.print(value, out, newRecord);
         
         // Verify
         // Original behavior would quote strings ending with space (<= SP)
         // Mutant behavior would not quote strings ending with space (< SP)
         assertTrue("String ending with space should be quoted", 
                    out.toString().startsWith("\"") && out.toString().endsWith("\""));
         assertTrue("Quoted string should contain original value", 
                    out.toString().contains(value));
         
         // Additional verification that the space was preserved
         assertEquals(' ', out.toString().charAt(out.length() - 2));
     }

 @Test
    public void testPrintAndQuoteWithInternalQuotesDetectsMutant() throws IOException {
        // Setup
        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        StringBuilder out = new StringBuilder();
        String value = "abc\"def"; // String with quote in the middle
        boolean newRecord = true;
        
        // Create a spy to track the append calls
        Appendable spyOut = spy(out);
        
        // Call the method
        format.print(value, spyOut, newRecord);
        
        // Verify the correct portion was appended
        verify(spyOut).append(value, 0, 3); // Should append "abc" portion
        verify(spyOut).append(value, 3, 4); // Should append the quote
        verify(spyOut).append(value, 3, 7); // Should append from quote to end
        
        // Also verify the final output is correct
        assertEquals("\"abc\"\"def\"", out.toString());
        
        // The mutant would fail because:
        // 1. It would use offset (0) instead of start (3) in some append calls
        // 2. The final output would be incorrect
    }

 @Test
   public void testPrintAndQuoteWithNonCommaDelimiter2() throws IOException {
       // Setup
       char testDelimiter = '|'; // Using pipe as non-comma delimiter
       CSVFormat format = CSVFormat.newFormat(testDelimiter)
               .withQuoteMode(QuoteMode.MINIMAL)
               .withQuote('"');
       
       String testValue = "value|with|delimiter";
       StringBuilder out = new StringBuilder();
       boolean newRecord = true;
       
       // Create a spy to verify getDelimiter() is called
       CSVFormat spyFormat = spy(format);
       
       // Test
       spyFormat.print(testValue, out, newRecord);
       
       // Verify
       // 1. Check that getDelimiter() was called (would fail with mutant)
       verify(spyFormat).getDelimiter();
       
       // 2. Check output was properly quoted (contains the delimiter)
       String result = out.toString();
       assertTrue("Output should be quoted", result.startsWith("\""));
       assertTrue("Output should contain original delimiter", result.contains("|"));
       
       // 3. Check the entire quoted output
       assertEquals("\"value|with|delimiter\"", result);
   }

 @Test
  public void testPrintAndQuoteNonNumericModeDetectsMutant() throws IOException {
      // Setup CSVFormat with NON_NUMERIC quote mode
      CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
      
      // Mock Appendable to capture output
      Appendable out = mock(Appendable.class);
      
      // Test case 1: Non-Number object (should be quoted in original, not in mutant)
      Object nonNumberObj = "string";
      format.print(nonNumberObj, out, false);
      
      // Verify quotes were added (original behavior)
      verify(out).append(format.getQuoteCharacter());
      verify(out).append(nonNumberObj.toString());
      verify(out).append(format.getQuoteCharacter());
      
      // Reset mock for next test
      reset(out);
      
      // Test case 2: Number object (should not be quoted in original, not in mutant)
      Object numberObj = 123;
      format.print(numberObj, out, false);
      
      // Verify no quotes were added (original behavior)
      verify(out, never()).append(format.getQuoteCharacter());
      verify(out).append(numberObj.toString());
      verify(out, never()).append(format.getQuoteCharacter());
      
      // Reset mock for next test
      reset(out);
      
      // Test case 3: null object (should be quoted in both original and mutant)
      Object nullObj = null;
      format.print(nullObj, out, false);
      
      // Verify quotes were added (both behaviors)
      verify(out).append(format.getQuoteCharacter());
      verify(out).append("null"); // null gets converted to "null" string
      verify(out).append(format.getQuoteCharacter());
  }

 @Test
 public void testPrintAndQuoteDetectsQuoteModeMutation2() throws IOException {
     // Setup test data
     StringBuilder out = new StringBuilder();
     String value = "test,value";
     boolean newRecord = true;
     
     // Create CSVFormat with ALL quote mode (not MINIMAL)
     CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
     
     // Mock the behavior we expect from getQuoteMode()
     // In original code, this would return ALL
     // In mutated code, this would be ignored (set to null)
     
     // Call the method
     format.print(value, out, newRecord);
     
     // Verify behavior - with ALL mode, everything should be quoted
     // If mutation exists, it would fall back to MINIMAL mode and might not quote
     assertTrue("Output should start with quote character", 
                out.toString().startsWith(String.valueOf(format.getQuoteCharacter())));
     assertTrue("Output should end with quote character", 
                out.toString().endsWith(String.valueOf(format.getQuoteCharacter())));
     
     // Additional check for exact output to catch any partial quoting
     String expected = format.getQuoteCharacter() + value + format.getQuoteCharacter();
     assertEquals("Output should be fully quoted in ALL mode", 
                 expected, out.toString());
 }

}
