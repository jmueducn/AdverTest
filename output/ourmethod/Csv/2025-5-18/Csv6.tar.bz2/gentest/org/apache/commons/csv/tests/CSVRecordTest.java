package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
         public void testPutIn_TypicalCase() throws Exception {
             // Setup
             String[] values = {"val1", "val2", "val3"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             mapping.put("key2", 1);
             mapping.put("key3", 2);
             
             // Get constructor and make it accessible
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Get method and make it accessible
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(3, result.size());
             assertEquals("val1", result.get("key1"));
             assertEquals("val2", result.get("key2"));
             assertEquals("val3", result.get("key3"));
             assertSame(inputMap, result); // Should return the same map instance
         }

    @Test
         public void testPutIn_EmptyMapping() throws Exception {
             // Setup
             String[] values = {"val1", "val2"};
             Map<String, Integer> mapping = new HashMap<>(); // Empty mapping
             
             // Get constructor and make it accessible
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Get method and make it accessible
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertTrue(result.isEmpty());
         }

    @Test
         public void testPutIn_IndexOutOfBounds() throws Exception {
             // Setup
             String[] values = {"val1"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0); // Valid
             mapping.put("key2", 1); // Invalid (out of bounds)
             
             // Get CSVRecord constructor via reflection
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Get putIn method via reflection
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(1, result.size());
             assertEquals("val1", result.get("key1"));
             assertNull(result.get("key2"));
         }

    @Test
         public void testPutIn_NullInputMap() throws Exception {
             // Setup
             String[] values = {"val1"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             
             // Get constructor and make it accessible
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             // Get putIn method and make it accessible
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Expect exception
             thrown.expect(NullPointerException.class);
             
             // Execute
             putInMethod.invoke(record, (Map<String, String>)null);
         }

    @Test
         public void testPutIn_EmptyValuesArray() throws Exception {
             // Setup
             String[] values = {}; // Empty array
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0); // Invalid (out of bounds)
             
             // Use reflection to create CSVRecord instance
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to call putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertTrue(result.isEmpty());
         }

    @Test
         public void testPutIn_MixedValidAndInvalidMappings() throws Exception {
             // Setup
             String[] values = {"val1", "val2"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0); // Valid
             mapping.put("key2", 1); // Valid
             mapping.put("key3", 2); // Invalid
             mapping.put("key4", -1); // Invalid
             
             // Use reflection to access non-public constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access non-public putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(2, result.size());
             assertEquals("val1", result.get("key1"));
             assertEquals("val2", result.get("key2"));
             assertNull(result.get("key3"));
             assertNull(result.get("key4"));
         }

    @Test
         public void testPutIn_PreservesExistingMapEntries() throws Exception {
             // Setup
             String[] values = {"val1"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             
             // Get CSVRecord constructor via reflection
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             inputMap.put("existingKey", "existingValue");
             
             // Get putIn method via reflection
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(2, result.size());
             assertEquals("val1", result.get("key1"));
             assertEquals("existingValue", result.get("existingKey"));
         }

    @Test
    public void testPutInWithNullIntegerValue() throws Exception {
        // Setup
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("key1", null); // This will cause NPE when unboxing
        
        String[] values = {"value1", "value2"};
        
        // Use reflection to access non-public constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
        
        Map<String, String> targetMap = new HashMap<>();
        
        // Use reflection to access non-public putIn method
        Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
        putInMethod.setAccessible(true);
        
        try {
            // This should throw NullPointerException
            putInMethod.invoke(record, targetMap);
            
            // If we get here, the test fails (mutant survived)
            fail("Expected NullPointerException when mapping contains null Integer value");
        } catch (InvocationTargetException e) {
            // Check if the cause is NullPointerException
            if (!(e.getCause() instanceof NullPointerException)) {
                fail("Expected NullPointerException but got " + e.getCause().getClass());
            }
            // Expected exception was thrown, test passes
        }
    }


}
