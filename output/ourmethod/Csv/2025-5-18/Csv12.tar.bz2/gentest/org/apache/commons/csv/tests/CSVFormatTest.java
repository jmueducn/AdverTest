package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                               public void testNewFormat_WithValidDelimiter() {
                                                                                                   // Test with typical delimiter
                                                                                                   char delimiter = ',';
                                                                                                   CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(delimiter, format.getDelimiter());
                                                                                                   assertNull(format.getQuoteCharacter());
                                                                                                   assertNull(format.getQuoteMode());
                                                                                                   assertNull(format.getCommentMarker());
                                                                                                   assertNull(format.getEscapeCharacter());
                                                                                                   assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                   assertFalse(format.getIgnoreEmptyLines());
                                                                                                   assertNull(format.getRecordSeparator());
                                                                                                   assertNull(format.getNullString());
                                                                                                   assertNull(format.getHeader());
                                                                                                   assertFalse(format.getSkipHeaderRecord());
                                                                                                   assertFalse(format.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithTabDelimiter() {
                                                                                                   // Test with tab as delimiter
                                                                                                   char delimiter = '\t';
                                                                                                   CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(delimiter, format.getDelimiter());
                                                                                                   assertNull(format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithPipeDelimiter() {
                                                                                                   // Test with pipe as delimiter
                                                                                                   char delimiter = '|';
                                                                                                   CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(delimiter, format.getDelimiter());
                                                                                                   assertNull(format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithSemicolonDelimiter() {
                                                                                                   // Test with semicolon as delimiter
                                                                                                   char delimiter = ';';
                                                                                                   CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(delimiter, format.getDelimiter());
                                                                                                   assertNull(format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithLineBreakDelimiter_ShouldThrowException() {
                                                                                                   // Test that line break as delimiter throws exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                   
                                                                                                   char delimiter = '\n';
                                                                                                   CSVFormat.newFormat(delimiter);
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithCarriageReturnDelimiter_ShouldThrowException() {
                                                                                                   // Test that carriage return as delimiter throws exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                   
                                                                                                   char delimiter = '\r';
                                                                                                   CSVFormat.newFormat(delimiter);
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithUnicodeDelimiter() {
                                                                                                   // Test with non-ASCII delimiter
                                                                                                   char delimiter = '¶';
                                                                                                   CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(delimiter, format.getDelimiter());
                                                                                                   assertNull(format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_WithZeroDelimiter() {
                                                                                                   // Test with null character as delimiter
                                                                                                   char delimiter = '\0';
                                                                                                   CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(delimiter, format.getDelimiter());
                                                                                                   assertNull(format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_EqualsImplementation() {
                                                                                                   // Test that two instances with same delimiter are equal
                                                                                                   char delimiter = ',';
                                                                                                   CSVFormat format1 = CSVFormat.newFormat(delimiter);
                                                                                                   CSVFormat format2 = CSVFormat.newFormat(delimiter);
                                                                                                   
                                                                                                   assertEquals(format1, format2);
                                                                                                   assertEquals(format1.hashCode(), format2.hashCode());
                                                                                               }

 @Test
                                                                                               public void testNewFormat_NotEqualsWithDifferentDelimiter() {
                                                                                                   // Test that different delimiters create unequal instances
                                                                                                   CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                   CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                                   
                                                                                                   assertNotEquals(format1, format2);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithDefaultFormat() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   Object[] values = {"value1", "value2", "value3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("value1,value2,value3", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithEmptyValues() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   Object[] values = {};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithNullValues() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   Object[] values = {"value1", null, "value3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("value1,NULL,value3", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithCustomDelimiter() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.newFormat('|');
                                                                                                   Object[] values = {"value1", "value2", "value3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("value1|value2|value3", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithQuotes() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                   Object[] values = {"value,1", "value\"2", "value3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("\"value,1\",\"value\"\"2\",value3", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithQuoteModeAll() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                   Object[] values = {"value1", "value2", "value3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("\"value1\",\"value2\",\"value3\"", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithRecordSeparator() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                   Object[] values = {"value1", "value2", "value3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("value1,value2,value3", result); // Note: record separator is only between records
                                                                                               }

 @Test
                                                                                               public void testFormat_WithSpecialCharacters() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   Object[] values = {"value\n1", "value\t2", "value\r3"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("value\n1,value\t2,value\r3", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithSingleValue() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   Object[] values = {"singleValue"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   String result = format.format(values);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("singleValue", result);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithNullInput() {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(NullPointerException.class);
                                                                                                   
                                                                                                   // Execute
                                                                                                   format.format(null);
                                                                                               }

 @Test
                                                                                               public void testFormat_WithMockStringWriterFailure() throws Exception {
                                                                                                   // Setup
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   StringWriter mockWriter = mock(StringWriter.class);
                                                                                                   when(mockWriter.toString()).thenThrow(new IOException("Simulated IO error"));
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalStateException.class);
                                                                                                   
                                                                                                   // Execute - need to use reflection to inject the mock writer
                                                                                                   // This is a simplified version - in real test you'd need to properly inject the mock
                                                                                                   format.format(new Object[]{"value"});
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_WhenUsingDefaultFormat() {
                                                                                                   // Arrange
                                                                                                   CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertNull(defaultFormat.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_WhenUsingExcelFormat() {
                                                                                                   // Arrange
                                                                                                   CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertNull(excelFormat.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_WhenUsingRFC4180Format() {
                                                                                                   // Arrange
                                                                                                   CSVFormat rfcFormat = CSVFormat.RFC4180;
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertNull(rfcFormat.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_WhenUsingTDFFormat() {
                                                                                                   // Arrange
                                                                                                   CSVFormat tdfFormat = CSVFormat.TDF;
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertNull(tdfFormat.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_WhenUsingMySQLFormat() {
                                                                                                   // Arrange
                                                                                                   CSVFormat mysqlFormat = CSVFormat.MYSQL;
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertNull(mysqlFormat.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_AfterSettingWithWithCommentMarker() {
                                                                                                   // Arrange
                                                                                                   Character expectedCommentMarker = '!';
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(expectedCommentMarker);
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertEquals(expectedCommentMarker, format.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetCommentMarker_AfterSettingWithWithCommentMarkerNull() {
                                                                                                   // Arrange
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withCommentMarker((Character) null);
                                                                                                   
                                                                                                   // Act & Assert
                                                                                                   assertNull(format.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_DefaultFormat() {
                                                                                                   // Test with DEFAULT format (comma delimiter)
                                                                                                   assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_ExcelFormat() {
                                                                                                   // Test with EXCEL format (comma delimiter)
                                                                                                   assertEquals(',', CSVFormat.EXCEL.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_TabDelimitedFormat() {
                                                                                                   // Test with TDF format (tab delimiter)
                                                                                                   assertEquals('\t', CSVFormat.TDF.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_MySQLFormat() {
                                                                                                   // Test with MYSQL format (tab delimiter)
                                                                                                   assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_RFC4180Format() {
                                                                                                   // Test with RFC4180 format (comma delimiter)
                                                                                                   assertEquals(',', CSVFormat.RFC4180.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_CustomFormat() {
                                                                                                   // Test with custom format (semicolon delimiter)
                                                                                                   CSVFormat customFormat = CSVFormat.newFormat(';');
                                                                                                   assertEquals(';', customFormat.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_NonStandardCharacter() {
                                                                                                   // Test with non-standard delimiter character
                                                                                                   CSVFormat customFormat = CSVFormat.newFormat('|');
                                                                                                   assertEquals('|', customFormat.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetDelimiter_AfterWithDelimiter() {
                                                                                                   // Test that withDelimiter creates a new format with the specified delimiter
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   CSVFormat modified = original.withDelimiter(';');
                                                                                                   assertEquals(';', modified.getDelimiter());
                                                                                                   // Original should remain unchanged
                                                                                                   assertEquals(',', original.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_UsingDefaultFormat() {
                                                                                                   // Test with the DEFAULT static instance
                                                                                                   assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_UsingRFC4180Format() {
                                                                                                   // Test with the RFC4180 static instance
                                                                                                   assertNull(CSVFormat.RFC4180.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_UsingExcelFormat() {
                                                                                                   // Test with the EXCEL static instance
                                                                                                   assertNull(CSVFormat.EXCEL.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_UsingTDFFormat() {
                                                                                                   // Test with the TDF static instance
                                                                                                   assertEquals(Character.valueOf('\\'), CSVFormat.TDF.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_UsingMySQLFormat() {
                                                                                                   // Test with the MYSQL static instance
                                                                                                   assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_AfterModificationWithWithEscape() {
                                                                                                   // Setup initial format with null escape
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                   
                                                                                                   // Test & Verify
                                                                                                   assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetEscapeCharacter_AfterModificationWithNullEscape() {
                                                                                                   // Setup initial format with escape
                                                                                                   CSVFormat format = CSVFormat.TDF.withEscape(null);
                                                                                                   
                                                                                                   // Test & Verify
                                                                                                   assertNull(format.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_WhenTrue() {
                                                                                                   // Create a CSVFormat instance with allowMissingColumnNames set to true
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   assertTrue("Should return true when allowMissingColumnNames is set to true", 
                                                                                                       format.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_WhenFalse() {
                                                                                                   // Create a CSVFormat instance with allowMissingColumnNames set to false
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withAllowMissingColumnNames(false);
                                                                                                   
                                                                                                   assertFalse("Should return false when allowMissingColumnNames is set to false", 
                                                                                                       format.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_DefaultFormat() {
                                                                                                   // Test with DEFAULT format (should be false by default)
                                                                                                   assertFalse("DEFAULT format should have allowMissingColumnNames as false",
                                                                                                       CSVFormat.DEFAULT.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_ExcelFormat() {
                                                                                                   // Test with EXCEL format (should be false by default)
                                                                                                   assertFalse("EXCEL format should have allowMissingColumnNames as false",
                                                                                                       CSVFormat.EXCEL.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_RFC4180Format() {
                                                                                                   // Test with RFC4180 format (should be false by default)
                                                                                                   assertFalse("RFC4180 format should have allowMissingColumnNames as false",
                                                                                                       CSVFormat.RFC4180.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_AfterModification() {
                                                                                                   // Test that changes to the format are reflected in the getter
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   assertTrue("Initial value should be true", format.getAllowMissingColumnNames());
                                                                                                   
                                                                                                   // Create a new format with different setting
                                                                                                   CSVFormat modifiedFormat = format.withAllowMissingColumnNames(false);
                                                                                                   assertFalse("Modified format should return false", modifiedFormat.getAllowMissingColumnNames());
                                                                                                   
                                                                                                   // Original format should remain unchanged
                                                                                                   assertTrue("Original format should remain unchanged", format.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetAllowMissingColumnNames_WithAllOtherSettings() {
                                                                                                   // Test with all possible settings to ensure getter works in complex scenarios
                                                                                                   CSVFormat format = CSVFormat.newFormat(';')
                                                                                                       .withQuote('"')
                                                                                                       .withEscape('\\')
                                                                                                       .withCommentMarker('#')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("col1", "col2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   assertTrue("Should return true even with all other settings configured",
                                                                                                       format.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_DefaultFormat() {
                                                                                                   // Test with DEFAULT format (should have ignoreEmptyLines = false)
                                                                                                   assertFalse(CSVFormat.DEFAULT.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_RFC4180Format() {
                                                                                                   // Test with RFC4180 format (should have ignoreEmptyLines = false)
                                                                                                   assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_ExcelFormat() {
                                                                                                   // Test with EXCEL format (should have ignoreEmptyLines = false)
                                                                                                   assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_TabDelimitedFormat() {
                                                                                                   // Test with TDF format (should have ignoreEmptyLines = false)
                                                                                                   assertFalse(CSVFormat.TDF.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_MySQLFormat() {
                                                                                                   // Test with MYSQL format (should have ignoreEmptyLines = false)
                                                                                                   assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_WithIgnoreEmptyLinesTrue() {
                                                                                                   // Create a custom format with ignoreEmptyLines = true
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                   assertTrue(format.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreEmptyLines_WithIgnoreEmptyLinesFalse() {
                                                                                                   // Create a custom format with ignoreEmptyLines = false
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                                   assertFalse(format.getIgnoreEmptyLines());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreSurroundingSpaces_DefaultFormat() {
                                                                                                   // Test the DEFAULT format instance
                                                                                                   assertFalse("DEFAULT format should have ignoreSurroundingSpaces set to false", 
                                                                                                       CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreSurroundingSpaces_RFC4180Format() {
                                                                                                   // Test the RFC4180 format instance
                                                                                                   assertFalse("RFC4180 format should have ignoreSurroundingSpaces set to false", 
                                                                                                       CSVFormat.RFC4180.getIgnoreSurroundingSpaces());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreSurroundingSpaces_ExcelFormat() {
                                                                                                   // Test the EXCEL format instance
                                                                                                   assertFalse("EXCEL format should have ignoreSurroundingSpaces set to false", 
                                                                                                       CSVFormat.EXCEL.getIgnoreSurroundingSpaces());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreSurroundingSpaces_TDFFormat() {
                                                                                                   // Test the TDF format instance
                                                                                                   assertFalse("TDF format should have ignoreSurroundingSpaces set to false", 
                                                                                                       CSVFormat.TDF.getIgnoreSurroundingSpaces());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreSurroundingSpaces_MySQLFormat() {
                                                                                                   // Test the MYSQL format instance
                                                                                                   assertFalse("MYSQL format should have ignoreSurroundingSpaces set to false", 
                                                                                                       CSVFormat.MYSQL.getIgnoreSurroundingSpaces());
                                                                                               }

 @Test
                                                                                               public void testGetIgnoreSurroundingSpaces_AfterWithMethod() {
                                                                                                   // Create a format and then modify it using withIgnoreSurroundingSpaces
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   CSVFormat modified = original.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   assertFalse("Original format should remain unchanged", 
                                                                                                       original.getIgnoreSurroundingSpaces());
                                                                                                   assertTrue("Modified format should have ignoreSurroundingSpaces set to true", 
                                                                                                       modified.getIgnoreSurroundingSpaces());
                                                                                               }

 @Test
                                                                                               public void testGetNullString_WithDefaultFormat() {
                                                                                                   // Test with DEFAULT format instance
                                                                                                   assertEquals("Default format should have null as nullString", 
                                                                                                                null, CSVFormat.DEFAULT.getNullString());
                                                                                               }

 @Test
                                                                                               public void testGetNullString_WithRFC4180Format() {
                                                                                                   // Test with RFC4180 format instance
                                                                                                   assertEquals("RFC4180 format should have null as nullString", 
                                                                                                                null, CSVFormat.RFC4180.getNullString());
                                                                                               }

 @Test
                                                                                               public void testGetNullString_WithExcelFormat() {
                                                                                                   // Test with EXCEL format instance
                                                                                                   assertEquals("EXCEL format should have null as nullString", 
                                                                                                                null, CSVFormat.EXCEL.getNullString());
                                                                                               }

 @Test
                                                                                               public void testGetNullString_WithTDFFormat() {
                                                                                                   // Test with TDF format instance
                                                                                                   assertEquals("TDF format should have null as nullString", 
                                                                                                                null, CSVFormat.TDF.getNullString());
                                                                                               }

 @Test
                                                                                               public void testGetNullString_WithMySQLFormat() {
                                                                                                   // Test with MYSQL format instance
                                                                                                   assertEquals("MYSQL format should have null as nullString", 
                                                                                                                null, CSVFormat.MYSQL.getNullString());
                                                                                               }

 @Test
                                                                                               public void testGetNullString_AfterWithNullStringModification() {
                                                                                                   // Create a format and then modify it with withNullString
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   CSVFormat modified = original.withNullString("N/A");
                                                                                                   
                                                                                                   assertEquals("Modified format should have new nullString", 
                                                                                                                "N/A", modified.getNullString());
                                                                                                   assertNull("Original format should remain unchanged", 
                                                                                                              original.getNullString());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteCharacter_WhenUsingDefaultFormat() {
                                                                                                   // Arrange
                                                                                                   Character expectedQuote = CSVFormat.DEFAULT.getQuoteCharacter();
                                                                                                   
                                                                                                   // Act
                                                                                                   Character actualQuote = CSVFormat.DEFAULT.getQuoteCharacter();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertEquals(expectedQuote, actualQuote);
                                                                                               }

 @Test
                                                                                               public void testGetQuoteCharacter_WhenUsingExcelFormat() {
                                                                                                   // Arrange
                                                                                                   Character expectedQuote = CSVFormat.EXCEL.getQuoteCharacter();
                                                                                                   
                                                                                                   // Act
                                                                                                   Character actualQuote = CSVFormat.EXCEL.getQuoteCharacter();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertEquals(expectedQuote, actualQuote);
                                                                                               }

 @Test
                                                                                               public void testGetQuoteCharacter_WhenUsingRFC4180Format() {
                                                                                                   // Arrange
                                                                                                   Character expectedQuote = CSVFormat.RFC4180.getQuoteCharacter();
                                                                                                   
                                                                                                   // Act
                                                                                                   Character actualQuote = CSVFormat.RFC4180.getQuoteCharacter();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertEquals(expectedQuote, actualQuote);
                                                                                               }

 @Test
                                                                                               public void testGetQuoteCharacter_WhenUsingTDFFormat() {
                                                                                                   // Arrange
                                                                                                   Character expectedQuote = CSVFormat.TDF.getQuoteCharacter();
                                                                                                   
                                                                                                   // Act
                                                                                                   Character actualQuote = CSVFormat.TDF.getQuoteCharacter();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertEquals(expectedQuote, actualQuote);
                                                                                               }

 @Test
                                                                                               public void testGetQuoteCharacter_WhenUsingMySQLFormat() {
                                                                                                   // Arrange
                                                                                                   Character expectedQuote = CSVFormat.MYSQL.getQuoteCharacter();
                                                                                                   
                                                                                                   // Act
                                                                                                   Character actualQuote = CSVFormat.MYSQL.getQuoteCharacter();
                                                                                                   
                                                                                                   // Assert
                                                                                                   assertEquals(expectedQuote, actualQuote);
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenDefaultFormat() {
                                                                                                   // Default format should have QuoteMode.MINIMAL
                                                                                                   CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                   assertEquals(QuoteMode.MINIMAL, defaultFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenRFC4180Format() {
                                                                                                   // RFC4180 format should have QuoteMode.MINIMAL
                                                                                                   CSVFormat rfcFormat = CSVFormat.RFC4180;
                                                                                                   assertEquals(QuoteMode.MINIMAL, rfcFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenExcelFormat() {
                                                                                                   // Excel format should have QuoteMode.MINIMAL
                                                                                                   CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                                   assertEquals(QuoteMode.MINIMAL, excelFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenTDFFormat() {
                                                                                                   // TDF format should have QuoteMode.MINIMAL
                                                                                                   CSVFormat tdfFormat = CSVFormat.TDF;
                                                                                                   assertEquals(QuoteMode.MINIMAL, tdfFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenMySQLFormat() {
                                                                                                   // MySQL format should have null quote mode
                                                                                                   CSVFormat mysqlFormat = CSVFormat.MYSQL;
                                                                                                   assertNull(mysqlFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenCustomFormatWithAllQuotes() {
                                                                                                   // Create custom format with ALL quotes
                                                                                                   CSVFormat customFormat = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                   assertEquals(QuoteMode.ALL, customFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenCustomFormatWithNonNumericQuotes() {
                                                                                                   // Create custom format with NON_NUMERIC quotes
                                                                                                   CSVFormat customFormat = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                                   assertEquals(QuoteMode.NON_NUMERIC, customFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenCustomFormatWithNullQuoteMode() {
                                                                                                   // Create custom format with null quote mode
                                                                                                   CSVFormat customFormat = CSVFormat.DEFAULT.withQuoteMode(null);
                                                                                                   assertNull(customFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetQuoteMode_WhenFormatIsImmutableAfterCreation() {
                                                                                                   // Verify that quote mode can't be changed after creation
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                                   CSVFormat modified = original.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                                   
                                                                                                   // Original should remain unchanged
                                                                                                   assertEquals(QuoteMode.ALL, original.getQuoteMode());
                                                                                                   // Modified should have new quote mode
                                                                                                   assertEquals(QuoteMode.NON_NUMERIC, modified.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testGetRecordSeparator_DefaultFormat() {
                                                                                                   // Test with DEFAULT format (which should have system line separator)
                                                                                                   String expected = System.lineSeparator();
                                                                                                   assertEquals(expected, CSVFormat.DEFAULT.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testGetRecordSeparator_RFC4180Format() {
                                                                                                   // Test with RFC4180 format (should use CRLF)
                                                                                                   assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testGetRecordSeparator_ExcelFormat() {
                                                                                                   // Test with EXCEL format (should use CRLF)
                                                                                                   assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testGetRecordSeparator_TabDelimitedFormat() {
                                                                                                   // Test with TDF format (should use system line separator)
                                                                                                   String expected = System.lineSeparator();
                                                                                                   assertEquals(expected, CSVFormat.TDF.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testGetRecordSeparator_MySQLFormat() {
                                                                                                   // Test with MYSQL format (should use LF)
                                                                                                   assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_DefaultFormat() {
                                                                                                   // Test with DEFAULT format (should be false by convention)
                                                                                                   assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_RFC4180Format() {
                                                                                                   // Test with RFC4180 format (should be false by convention)
                                                                                                   assertFalse(CSVFormat.RFC4180.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_ExcelFormat() {
                                                                                                   // Test with EXCEL format (should be false by convention)
                                                                                                   assertFalse(CSVFormat.EXCEL.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_TabDelimitedFormat() {
                                                                                                   // Test with TDF format (should be false by convention)
                                                                                                   assertFalse(CSVFormat.TDF.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_MySQLFormat() {
                                                                                                   // Test with MYSQL format (should be false by convention)
                                                                                                   assertFalse(CSVFormat.MYSQL.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_WithSkipHeaderTrue() {
                                                                                                   // Create a custom format with skipHeaderRecord = true
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                   assertTrue(format.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_WithSkipHeaderFalse() {
                                                                                                   // Create a custom format with skipHeaderRecord = false
                                                                                                   CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                   assertFalse(format.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_NewFormat() {
                                                                                                   // Test with a newly created format
                                                                                                   CSVFormat format = CSVFormat.newFormat(',').withSkipHeaderRecord(true);
                                                                                                   assertTrue(format.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_AfterModification() {
                                                                                                   // Test that modifying skipHeaderRecord creates a new instance
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   assertFalse(original.getSkipHeaderRecord());
                                                                                                   assertTrue(modified.getSkipHeaderRecord());
                                                                                                   assertNotSame(original, modified);
                                                                                               }

 @Test
                                                                                               public void testGetSkipHeaderRecord_WithHeaderAndSkipHeader() {
                                                                                                   // Test with both header and skipHeaderRecord set
                                                                                                   String[] headers = {"col1", "col2"};
                                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                                       .withHeader(headers)
                                                                                                       .withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   assertTrue(format.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testIsEscapeCharacterSet_WithDefaultFormat() {
                                                                                                   // Test with DEFAULT format (which typically has escape character set)
                                                                                                   assertTrue("DEFAULT format should have escape character set", 
                                                                                                             CSVFormat.DEFAULT.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testIsEscapeCharacterSet_WithExcelFormat() {
                                                                                                   // Test with EXCEL format (which typically doesn't have escape character)
                                                                                                   assertFalse("EXCEL format should not have escape character set", 
                                                                                                              CSVFormat.EXCEL.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testIsNullStringSet_WhenUsingDefaultFormat() {
                                                                                                   // Test with DEFAULT format which should have nullString set to null
                                                                                                   assertFalse("DEFAULT format should have nullString not set", 
                                                                                                              CSVFormat.DEFAULT.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testIsNullStringSet_WhenUsingRFC4180Format() {
                                                                                                   // Test with RFC4180 format which should have nullString set to null
                                                                                                   assertFalse("RFC4180 format should have nullString not set", 
                                                                                                              CSVFormat.RFC4180.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testIsNullStringSet_WhenUsingExcelFormat() {
                                                                                                   // Test with EXCEL format which should have nullString set to null
                                                                                                   assertFalse("EXCEL format should have nullString not set", 
                                                                                                              CSVFormat.EXCEL.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testIsQuoteCharacterSet_WithDefaultFormat() {
                                                                                                   // Test with DEFAULT format (which should have quote character set)
                                                                                                   assertTrue("DEFAULT format should have quote character set", 
                                                                                                       CSVFormat.DEFAULT.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testIsQuoteCharacterSet_WithExcelFormat() {
                                                                                                   // Test with EXCEL format (which should have quote character set)
                                                                                                   assertTrue("EXCEL format should have quote character set", 
                                                                                                       CSVFormat.EXCEL.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testIsQuoteCharacterSet_WithTDFFormat() {
                                                                                                   // Test with TDF format (which should have quote character set)
                                                                                                   assertTrue("TDF format should have quote character set", 
                                                                                                       CSVFormat.TDF.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testIsQuoteCharacterSet_WithMySQLFormat() {
                                                                                                   // Test with MYSQL format (which should have quote character set)
                                                                                                   assertTrue("MYSQL format should have quote character set", 
                                                                                                       CSVFormat.MYSQL.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testIsQuoteCharacterSet_WithRFC4180Format() {
                                                                                                   // Test with RFC4180 format (which should have quote character set)
                                                                                                   assertTrue("RFC4180 format should have quote character set", 
                                                                                                       CSVFormat.RFC4180.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testParse_WithNullReader() throws IOException {
                                                                                                   // Arrange
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   Reader reader = null;
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(NullPointerException.class);
                                                                                                   thrown.expectMessage("in");
                                                                                                   
                                                                                                   // Act
                                                                                                   format.parse(reader);
                                                                                               }

 @Test
                                                                                               public void testPrint_WithNullAppendable() throws IOException {
                                                                                                   // Arrange
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("Parameter 'out' must not be null");
                                                                                                   
                                                                                                   // Act
                                                                                                   format.print(null);
                                                                                               }

 @Test
                                                                                               public void testToString_DefaultFormat() {
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   String expected = "Delimiter=<,> QuoteChar=<\"> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:false";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithOnlyDelimiter() {
                                                                                                   CSVFormat format = CSVFormat.newFormat('|');
                                                                                                   String expected = "Delimiter=<|> SkipHeaderRecord:false";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithQuoteAndEscape() {
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withQuote('"')
                                                                                                       .withEscape('\\');
                                                                                                   
                                                                                                   String expected = "Delimiter=<,> Escape=<\\> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithHeaderAndSkipHeader() {
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withHeader("Name", "Age", "City")
                                                                                                       .withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   String expected = "Delimiter=<,> SkipHeaderRecord:true Header:[Name, Age, City]";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithEmptyHeader() {
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withHeader(new String[0]);
                                                                                                   
                                                                                                   String expected = "Delimiter=<,> SkipHeaderRecord:false Header:[]";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithNullString() {
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withNullString("NA");
                                                                                                   
                                                                                                   String expected = "Delimiter=<,> NullString=<NA> SkipHeaderRecord:false";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithCommentMarker() {
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withCommentMarker('#');
                                                                                                   
                                                                                                   String expected = "Delimiter=<,> CommentStart=<#> SkipHeaderRecord:false";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testToString_WithCustomRecordSeparator() {
                                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                                       .withRecordSeparator("|");
                                                                                                   
                                                                                                   String expected = "Delimiter=<,> RecordSeparator=<|> SkipHeaderRecord:false";
                                                                                                   assertEquals(expected, format.toString());
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_LineBreakCharacter() {
                                                                                                   // Setup original format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Expect exception when using line break as comment marker
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The comment start character cannot be a line break");
                                                                                                   
                                                                                                   // Try to set line break as comment marker
                                                                                                   original.withCommentMarker('\n');
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_ValidCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character commentMarker = '#';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withCommentMarker(commentMarker);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(result);
                                                                                                   assertEquals(commentMarker, result.getCommentMarker());
                                                                                                   assertTrue(result.isCommentMarkerSet());
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                                   assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                                   assertEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_NullValue() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withCommentMarker((Character) null);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(result);
                                                                                                   assertNull(result.getCommentMarker());
                                                                                                   assertFalse(result.isCommentMarkerSet());
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_LineBreakCharacter1() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character lineBreak = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   original.withCommentMarker(lineBreak);
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_OtherSpecialCharacters() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character[] validMarkers = {'!', '@', '$', '%', '^', '&', '*'};
                                                                                                   
                                                                                                   for (Character marker : validMarkers) {
                                                                                                       // Execute
                                                                                                       CSVFormat result = original.withCommentMarker(marker);
                                                                                                       
                                                                                                       // Verify
                                                                                                       assertEquals(marker, result.getCommentMarker());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_UnicodeCharacters() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character[] unicodeMarkers = {'§', '©', '¶', '¿'};
                                                                                                   
                                                                                                   for (Character marker : unicodeMarkers) {
                                                                                                       // Execute
                                                                                                       CSVFormat result = original.withCommentMarker(marker);
                                                                                                       
                                                                                                       // Verify
                                                                                                       assertEquals(marker, result.getCommentMarker());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_OriginalInstanceNotModified() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character originalCommentMarker = original.getCommentMarker();
                                                                                                   Character newCommentMarker = '#';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withCommentMarker(newCommentMarker);
                                                                                                   
                                                                                                   // Verify original wasn't modified
                                                                                                   assertEquals(originalCommentMarker, original.getCommentMarker());
                                                                                                   assertNotSame(original, modified);
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_CharOverload() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   char commentMarker = '#';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withCommentMarker(commentMarker);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals(Character.valueOf(commentMarker), result.getCommentMarker());
                                                                                               }

 @Test
                                                                                               public void testWithCommentMarker_CharOverloadLineBreak() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   char lineBreak = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   original.withCommentMarker(lineBreak);
                                                                                               }

 @Test
                                                                                               public void testWithDelimiter_ValidDelimiter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   char newDelimiter = '|';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withDelimiter(newDelimiter);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals(newDelimiter, newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithDelimiter_LineBreakDelimiter_ThrowsException() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   char lineBreakDelimiter = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   originalFormat.withDelimiter(lineBreakDelimiter);
                                                                                               }

 @Test
                                                                                               public void testWithDelimiter_OtherLineBreakDelimiter_ThrowsException() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   char lineBreakDelimiter = '\r';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   originalFormat.withDelimiter(lineBreakDelimiter);
                                                                                               }

 @Test
                                                                                               public void testWithDelimiter_SameDelimiterReturnsSameInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   char sameDelimiter = originalFormat.getDelimiter();
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withDelimiter(sameDelimiter);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertSame(originalFormat, newFormat);
                                                                                               }

 @Test
                                                                                               public void testWithEscape_NonNullCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   Character escapeChar = '\\';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(newFormat);
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertEquals(escapeChar, newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                   
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_NullCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withEscape((Character) null);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(newFormat);
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertNull(newFormat.getEscapeCharacter());
                                                                                                   assertFalse(newFormat.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_LineBreakCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   Character lineBreak = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The escape cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   originalFormat.withEscape(lineBreak);
                                                                                               }

 @Test
                                                                                               public void testWithEscape_SameEscapeCharacter() {
                                                                                                   // Setup
                                                                                                   Character escapeChar = '\\';
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(escapeChar);
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withEscape(escapeChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertSame(originalFormat, newFormat); // Should return same instance when no change
                                                                                               }

 @Test
                                                                                               public void testWithEscape_ChangeFromNullToCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(null);
                                                                                                   Character newEscape = '\\';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withEscape(newEscape);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertEquals(newEscape, newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_ChangeFromCharacterToNull() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withEscape(null);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertNull(newFormat.getEscapeCharacter());
                                                                                                   assertFalse(newFormat.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_ChangeFromOneCharacterToAnother() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                   Character newEscape = '/';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withEscape(newEscape);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertEquals(newEscape, newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_ValidCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   char escape = '\\';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withEscape(escape);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(result);
                                                                                                   assertEquals(Character.valueOf(escape), result.getEscapeCharacter());
                                                                                                   assertTrue(result.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_NullCharacter1() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character escape = null;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withEscape(escape);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(result);
                                                                                                   assertNull(result.getEscapeCharacter());
                                                                                                   assertFalse(result.isEscapeCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_LineBreakCharacter_ShouldThrowException() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   char escape = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The escape character cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   original.withEscape(escape);
                                                                                               }

 @Test
                                                                                               public void testWithEscape_LineBreakCharacterObject_ShouldThrowException() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   Character escape = '\r';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The escape character cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   original.withEscape(escape);
                                                                                               }

 @Test
                                                                                               public void testWithEscape_VerifyOtherPropertiesUnchanged() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.newFormat('|')
                                                                                                       .withQuote('"')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("Header1", "Header2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   char escape = '\\';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withEscape(escape);
                                                                                                   
                                                                                                   // Verify escape was set
                                                                                                   assertEquals(Character.valueOf(escape), result.getEscapeCharacter());
                                                                                                   
                                                                                                   // Verify all other properties remain unchanged
                                                                                                   assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                                   assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                                   assertEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                                   assertEquals(original.getCommentMarker(), result.getCommentMarker());
                                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), result.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(original.getIgnoreEmptyLines(), result.getIgnoreEmptyLines());
                                                                                                   assertEquals(original.getRecordSeparator(), result.getRecordSeparator());
                                                                                                   assertEquals(original.getNullString(), result.getNullString());
                                                                                                   assertArrayEquals(original.getHeader(), result.getHeader());
                                                                                                   assertEquals(original.getSkipHeaderRecord(), result.getSkipHeaderRecord());
                                                                                                   assertEquals(original.getAllowMissingColumnNames(), result.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithEscape_SameEscapeCharacter_ShouldReturnSameInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withEscape('\\');
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertSame(original, result);
                                                                                               }

 @Test
                                                                                               public void testWithEscape_DifferentEscapeCharacter_ShouldReturnNewInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat result = original.withEscape('/');
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(original, result);
                                                                                                   assertEquals(Character.valueOf('/'), result.getEscapeCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_ValidSingleHeader() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                   String header = "Name";
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(header);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertArrayEquals(new String[]{"Name"}, newFormat.getHeader());
                                                                                                   assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_ValidMultipleHeaders() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                   String[] headers = {"Name", "Age", "City"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertArrayEquals(headers, newFormat.getHeader());
                                                                                                   assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_NullHeader() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader((String[]) null);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNull(newFormat.getHeader());
                                                                                                   assertFalse(newFormat.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_EmptyHeader() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                   String[] emptyHeaders = {};
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(emptyHeaders);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertArrayEquals(emptyHeaders, newFormat.getHeader());
                                                                                                   assertFalse(newFormat.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_DuplicateHeaders() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                   String[] duplicateHeaders = {"Name", "Name"};
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The header contains a duplicate entry: 'Name'");
                                                                                                   
                                                                                                   // Execute
                                                                                                   baseFormat.withHeader(duplicateHeaders);
                                                                                               }

 @Test
                                                                                               public void testWithHeader_PreservesOtherSettings() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(';')
                                                                                                       .withQuote('"')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   String[] headers = {"ID", "Value"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertArrayEquals(headers, newFormat.getHeader());
                                                                                                   assertEquals(';', newFormat.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                   assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                   assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_AfterNullString() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   String[] headers = {"Field1", "Field2"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertArrayEquals(headers, newFormat.getHeader());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                               }

 @Test
                                                                                               public void testWithHeader_WithSkipHeaderRecord() {
                                                                                                   // Setup
                                                                                                   CSVFormat baseFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                   String[] headers = {"Col1", "Col2"};
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = baseFormat.withHeader(headers);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertArrayEquals(headers, newFormat.getHeader());
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testWithAllowMissingColumnNames_True() {
                                                                                                   // Setup original format with false for allowMissingColumnNames
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                                   
                                                                                                   // Test setting to true
                                                                                                   CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   // Verify new format has true while original remains false
                                                                                                   assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                   assertFalse(originalFormat.getAllowMissingColumnNames());
                                                                                                   
                                                                                                   // Verify all other properties remain the same
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testWithAllowMissingColumnNames_False() {
                                                                                                   // Setup original format with true for allowMissingColumnNames
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   // Test setting to false
                                                                                                   CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(false);
                                                                                                   
                                                                                                   // Verify new format has false while original remains true
                                                                                                   assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                                   assertTrue(originalFormat.getAllowMissingColumnNames());
                                                                                                   
                                                                                                   // Verify all other properties remain the same
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testWithAllowMissingColumnNames_SameValue() {
                                                                                                   // Setup original format with true for allowMissingColumnNames
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   // Test setting to same value (true)
                                                                                                   CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   // Verify same instance is returned for optimization
                                                                                                   assertSame(originalFormat, newFormat);
                                                                                               }

 @Test
                                                                                               public void testWithAllowMissingColumnNames_AfterOtherModifications() {
                                                                                                   // Create a custom format with various settings
                                                                                                   CSVFormat originalFormat = CSVFormat.newFormat(';')
                                                                                                       .withQuote('"')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("col1", "col2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(false);
                                                                                                   
                                                                                                   // Modify allowMissingColumnNames
                                                                                                   CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   // Verify the change
                                                                                                   assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                                   
                                                                                                   // Verify all other properties remain unchanged
                                                                                                   assertEquals(';', newFormat.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                   assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                   assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                                   assertArrayEquals(new String[]{"col1", "col2"}, newFormat.getHeader());
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_True() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(';')
                                                                                                       .withQuote('"')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(false)  // original value
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("Col1", "Col2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                           
                                                                                                   // Test
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertEquals(';', newFormat.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                   assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                   assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());  // changed value
                                                                                                   assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                                   assertArrayEquals(new String[]{"Col1", "Col2"}, newFormat.getHeader());
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_False() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withIgnoreEmptyLines(true);  // original value
                                                                                           
                                                                                                   // Test
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(false);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertFalse(newFormat.getIgnoreEmptyLines());  // changed value
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_SameValueReturnsSameInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Test
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertSame(originalFormat, newFormat);
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_FromDefaultFormat() {
                                                                                                   // Test with DEFAULT format (which has ignoreEmptyLines=false by default)
                                                                                                   CSVFormat newFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertNotSame(CSVFormat.DEFAULT, newFormat);
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   // Verify other properties match DEFAULT
                                                                                                   assertEquals(CSVFormat.DEFAULT.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_FromExcelFormat() {
                                                                                                   // Test with EXCEL format (which has ignoreEmptyLines=false by default)
                                                                                                   CSVFormat newFormat = CSVFormat.EXCEL.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertNotSame(CSVFormat.EXCEL, newFormat);
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   // Verify other properties match EXCEL
                                                                                                   assertEquals(CSVFormat.EXCEL.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.EXCEL.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_FromTDFFormat() {
                                                                                                   // Test with TDF format (which has ignoreEmptyLines=false by default)
                                                                                                   CSVFormat newFormat = CSVFormat.TDF.withIgnoreEmptyLines(false);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertSame(CSVFormat.TDF, newFormat);  // same instance since value didn't change
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_FromMySQLFormat() {
                                                                                                   // Test with MYSQL format (which has ignoreEmptyLines=false by default)
                                                                                                   CSVFormat newFormat = CSVFormat.MYSQL.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertNotSame(CSVFormat.MYSQL, newFormat);
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   // Verify other properties match MYSQL
                                                                                                   assertEquals(CSVFormat.MYSQL.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.MYSQL.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreEmptyLines_FromRFC4180Format() {
                                                                                                   // Test with RFC4180 format (which has ignoreEmptyLines=false by default)
                                                                                                   CSVFormat newFormat = CSVFormat.RFC4180.withIgnoreEmptyLines(true);
                                                                                           
                                                                                                   // Verify
                                                                                                   assertNotSame(CSVFormat.RFC4180, newFormat);
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   // Verify other properties match RFC4180
                                                                                                   assertEquals(CSVFormat.RFC4180.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.RFC4180.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_True() {
                                                                                                   // Setup initial format with false for ignoreSurroundingSpaces
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                                   
                                                                                                   // Call method under test
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   // Verify new format has the new value
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_False() {
                                                                                                   // Setup initial format with true for ignoreSurroundingSpaces
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   // Call method under test
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(false);
                                                                                                   
                                                                                                   // Verify new format has the new value
                                                                                                   assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_FromDefaultFormat() {
                                                                                                   // Test with DEFAULT format as base
                                                                                                   CSVFormat newFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_FromExcelFormat() {
                                                                                                   // Test with EXCEL format as base
                                                                                                   CSVFormat newFormat = CSVFormat.EXCEL.withIgnoreSurroundingSpaces(false);
                                                                                                   
                                                                                                   assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(CSVFormat.EXCEL.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.EXCEL.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_WithHeader() {
                                                                                                   // Test with a format that has headers
                                                                                                   String[] headers = {"Name", "Age", "City"};
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withHeader(headers).withIgnoreSurroundingSpaces(false);
                                                                                                   
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertArrayEquals(headers, newFormat.getHeader());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_WithNullString() {
                                                                                                   // Test with a format that has null string set
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withNullString("NULL").withIgnoreSurroundingSpaces(false);
                                                                                                   
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                               }

 @Test
                                                                                               public void testWithIgnoreSurroundingSpaces_WithRecordSeparator() {
                                                                                                   // Test with a custom record separator
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withRecordSeparator("\r\n").withIgnoreSurroundingSpaces(false);
                                                                                                   
                                                                                                   CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                                   
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithNullString_ValidString() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withDelimiter(',')
                                                                                                       .withQuote('"')
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL");
                                                                                                   
                                                                                                   // Test with new null string
                                                                                                   CSVFormat modified = original.withNullString("NA");
                                                                                                   
                                                                                                   assertNotNull(modified);
                                                                                                   assertEquals("NA", modified.getNullString());
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                   assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                   assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithNullString_NullInput() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   
                                                                                                   // Test with null string
                                                                                                   CSVFormat modified = original.withNullString(null);
                                                                                                   
                                                                                                   assertNotNull(modified);
                                                                                                   assertNull(modified.getNullString());
                                                                                                   assertFalse(modified.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testWithNullString_EmptyString() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   
                                                                                                   // Test with empty string
                                                                                                   CSVFormat modified = original.withNullString("");
                                                                                                   
                                                                                                   assertNotNull(modified);
                                                                                                   assertEquals("", modified.getNullString());
                                                                                                   assertTrue(modified.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testWithNullString_WhitespaceString() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   
                                                                                                   // Test with whitespace string
                                                                                                   CSVFormat modified = original.withNullString("   ");
                                                                                                   
                                                                                                   assertNotNull(modified);
                                                                                                   assertEquals("   ", modified.getNullString());
                                                                                                   assertTrue(modified.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testWithNullString_SameAsOriginal() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   
                                                                                                   // Test with same null string
                                                                                                   CSVFormat modified = original.withNullString("NULL");
                                                                                                   
                                                                                                   assertNotNull(modified);
                                                                                                   assertEquals("NULL", modified.getNullString());
                                                                                                   assertNotSame(original, modified); // Should return new instance even if value is same
                                                                                               }

 @Test
                                                                                               public void testWithNullString_FromUnset() {
                                                                                                   // Setup format without null string
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withNullString(null);
                                                                                                   
                                                                                                   // Test setting null string
                                                                                                   CSVFormat modified = original.withNullString("NULL");
                                                                                                   
                                                                                                   assertNotNull(modified);
                                                                                                   assertEquals("NULL", modified.getNullString());
                                                                                                   assertTrue(modified.isNullStringSet());
                                                                                               }

 @Test
                                                                                               public void testWithNullString_VerifyImmutability() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                   
                                                                                                   // Modify the format
                                                                                                   CSVFormat modified = original.withNullString("NA");
                                                                                                   
                                                                                                   // Verify original remains unchanged
                                                                                                   assertEquals("NULL", original.getNullString());
                                                                                                   assertEquals("NA", modified.getNullString());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_NonNullCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   Character quoteChar = '"';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(newFormat);
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                   assertTrue(newFormat.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_NullCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   Character quoteChar = null;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(newFormat);
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertNull(newFormat.getQuoteCharacter());
                                                                                                   assertFalse(newFormat.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_SameCharacterReturnsSameInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                   Character quoteChar = '"';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertSame(originalFormat, newFormat);
                                                                                               }

 @Test
                                                                                               public void testWithQuote_DifferentCharacterReturnsNewInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                   Character quoteChar = '\'';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat);
                                                                                                   assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_LineBreakCharacterThrowsException() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   Character lineBreakChar = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   originalFormat.withQuote(lineBreakChar);
                                                                                               }

 @Test
                                                                                               public void testWithQuote_OtherPropertiesPreserved() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(';')
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("Header1", "Header2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   Character quoteChar = '|';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify quote character changed
                                                                                                   assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                                   
                                                                                                   // Verify other properties preserved
                                                                                                   assertEquals(';', newFormat.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                   assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                   assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                   assertEquals("NULL", newFormat.getNullString());
                                                                                                   assertArrayEquals(new String[]{"Header1", "Header2"}, newFormat.getHeader());
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_ValidCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   char quoteChar = '\'';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(newFormat);
                                                                                                   assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_NullCharacter1() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   Character quoteChar = null;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotNull(newFormat);
                                                                                                   assertNull(newFormat.getQuoteCharacter());
                                                                                                   assertFalse(newFormat.isQuoteCharacterSet());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_LineBreakCharacter() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   char lineBreakChar = '\n';
                                                                                                   
                                                                                                   // Expect exception
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                   
                                                                                                   // Execute
                                                                                                   originalFormat.withQuote(lineBreakChar);
                                                                                               }

 @Test
                                                                                               public void testWithQuote_SameCharacterAsOriginal() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                   char sameQuoteChar = '"';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(sameQuoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertSame(originalFormat, newFormat); // Should return same instance when no change
                                                                                               }

 @Test
                                                                                               public void testWithQuote_DifferentFromOriginal() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withQuote('"');
                                                                                                   char newQuoteChar = '\'';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat newFormat = originalFormat.withQuote(newQuoteChar);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(originalFormat, newFormat); // Should return new instance
                                                                                                   assertEquals(Character.valueOf(newQuoteChar), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithQuote_SpecialCharacters() {
                                                                                                   // Test various special characters that are valid as quote characters
                                                                                                   char[] specialChars = {'!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '=', '+', 
                                                                                                                         '[', ']', '{', '}', ';', ':', ',', '.', '<', '>', '/', '?', '|', '\\'};
                                                                                                   
                                                                                                   for (char c : specialChars) {
                                                                                                       CSVFormat newFormat = CSVFormat.DEFAULT.withQuote(c);
                                                                                                       assertEquals(Character.valueOf(c), newFormat.getQuoteCharacter());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testWithQuote_UnicodeCharacters() {
                                                                                                   // Test various Unicode characters that are valid as quote characters
                                                                                                   char[] unicodeChars = {'\u00A1', '\u00BF', '\u00E9', '\u03A9', '\u042F', '\u05D0', '\u3042'};
                                                                                                   
                                                                                                   for (char c : unicodeChars) {
                                                                                                       CSVFormat newFormat = CSVFormat.DEFAULT.withQuote(c);
                                                                                                       assertEquals(Character.valueOf(c), newFormat.getQuoteCharacter());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testWithQuoteMode_NonNullQuoteMode() {
                                                                                                   // Setup initial CSVFormat with default values
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(',')
                                                                                                       .withQuote('"')
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("Header1", "Header2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(false);
                                                                                           
                                                                                                   // Apply withQuoteMode
                                                                                                   CSVFormat newFormat = originalFormat.withQuoteMode(QuoteMode.ALL);
                                                                                           
                                                                                                   // Verify all properties except quoteMode are the same
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithQuoteMode_NullQuoteMode() {
                                                                                                   // Setup initial CSVFormat
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                           
                                                                                                   // Apply withQuoteMode with null
                                                                                                   CSVFormat newFormat = originalFormat.withQuoteMode(null);
                                                                                           
                                                                                                   // Verify quote mode is now null
                                                                                                   assertNull(newFormat.getQuoteMode());
                                                                                                   
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithQuoteMode_FromNullToNonNull() {
                                                                                                   // Setup format with null quote mode
                                                                                                   CSVFormat originalFormat = CSVFormat.newFormat(',').withQuoteMode(null);
                                                                                           
                                                                                                   // Apply withQuoteMode
                                                                                                   CSVFormat newFormat = originalFormat.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                           
                                                                                                   // Verify quote mode is updated
                                                                                                   assertEquals(QuoteMode.NON_NUMERIC, newFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testWithQuoteMode_VerifyImmutability() {
                                                                                                   // Setup initial format
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                                   
                                                                                                   // Create new format with different quote mode
                                                                                                   CSVFormat modifiedFormat = originalFormat.withQuoteMode(QuoteMode.ALL);
                                                                                           
                                                                                                   // Verify original format is unchanged
                                                                                                   assertEquals(QuoteMode.MINIMAL, originalFormat.getQuoteMode());
                                                                                                   assertEquals(QuoteMode.ALL, modifiedFormat.getQuoteMode());
                                                                                               }

 @Test
                                                                                               public void testWithQuoteMode_WithDifferentQuoteModes() {
                                                                                                   // Test all possible QuoteMode values
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   for (QuoteMode mode : QuoteMode.values()) {
                                                                                                       CSVFormat newFormat = originalFormat.withQuoteMode(mode);
                                                                                                       assertEquals(mode, newFormat.getQuoteMode());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_ValidSeparators() {
                                                                                                   // Test with standard record separators
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Test with Unix line ending
                                                                                                   CSVFormat unixFormat = format.withRecordSeparator("\n");
                                                                                                   assertEquals("\n", unixFormat.getRecordSeparator());
                                                                                                   
                                                                                                   // Test with Windows line ending
                                                                                                   CSVFormat windowsFormat = format.withRecordSeparator("\r\n");
                                                                                                   assertEquals("\r\n", windowsFormat.getRecordSeparator());
                                                                                                   
                                                                                                   // Test with custom separator
                                                                                                   CSVFormat customFormat = format.withRecordSeparator("|");
                                                                                                   assertEquals("|", customFormat.getRecordSeparator());
                                                                                                   
                                                                                                   // Test with empty string
                                                                                                   CSVFormat emptyFormat = format.withRecordSeparator("");
                                                                                                   assertEquals("", emptyFormat.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_NullSeparator() {
                                                                                                   // Test that null separator is allowed
                                                                                                   CSVFormat format = CSVFormat.DEFAULT;
                                                                                                   CSVFormat nullFormat = format.withRecordSeparator(null);
                                                                                                   assertNull(nullFormat.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_Immutability() {
                                                                                                   // Verify that the original format is not modified
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   String originalSeparator = original.getRecordSeparator();
                                                                                                   
                                                                                                   CSVFormat modified = original.withRecordSeparator("NEW");
                                                                                                   
                                                                                                   // Original should remain unchanged
                                                                                                   assertEquals(originalSeparator, original.getRecordSeparator());
                                                                                                   // New instance should have the new separator
                                                                                                   assertEquals("NEW", modified.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_OtherPropertiesPreserved() {
                                                                                                   // Verify that other properties are preserved when changing record separator
                                                                                                   CSVFormat original = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(';')
                                                                                                       .withQuote('"')
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withHeader("Header1", "Header2");
                                                                                                   
                                                                                                   CSVFormat modified = original.withRecordSeparator("|||");
                                                                                                   
                                                                                                   // Verify record separator changed
                                                                                                   assertEquals("|||", modified.getRecordSeparator());
                                                                                                   
                                                                                                   // Verify other properties remain the same
                                                                                                   assertEquals(';', modified.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                                   assertTrue(modified.getIgnoreEmptyLines());
                                                                                                   assertArrayEquals(new String[]{"Header1", "Header2"}, modified.getHeader());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_Chaining() {
                                                                                                   // Test method chaining
                                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                                       .withRecordSeparator("\n")
                                                                                                       .withDelimiter(',')
                                                                                                       .withQuote('"');
                                                                                                   
                                                                                                   assertEquals("\n", format.getRecordSeparator());
                                                                                                   assertEquals(',', format.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_String_ShouldCreateNewInstanceWithSeparator() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   String recordSeparator = "\r\n";
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withRecordSeparator(recordSeparator);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(original, modified);
                                                                                                   assertEquals(recordSeparator, modified.getRecordSeparator());
                                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                   assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                   assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                                   assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                                   assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                                   assertEquals(original.getNullString(), modified.getNullString());
                                                                                                   assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                                   assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                                   assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_Char_ShouldCreateNewInstanceWithSeparator() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   char recordSeparator = '\n';
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withRecordSeparator(recordSeparator);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNotSame(original, modified);
                                                                                                   assertEquals(String.valueOf(recordSeparator), modified.getRecordSeparator());
                                                                                                   // Verify other properties remain unchanged
                                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_NullString_ShouldSetNullSeparator() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withRecordSeparator((String) null);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNull(modified.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_EmptyString_ShouldSetEmptySeparator() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withRecordSeparator("");
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("", modified.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_ShouldNotModifyOriginalInstance() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                                   String newSeparator = "\r\n";
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertEquals("\n", original.getRecordSeparator());
                                                                                                   assertEquals("\r\n", modified.getRecordSeparator());
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_ShouldHandleDifferentSeparators() {
                                                                                                   // Setup
                                                                                                   CSVFormat original = CSVFormat.DEFAULT;
                                                                                                   String[] separators = {"\n", "\r\n", "|", "~~~", ""};
                                                                                                   
                                                                                                   for (String separator : separators) {
                                                                                                       // Execute
                                                                                                       CSVFormat modified = original.withRecordSeparator(separator);
                                                                                                       
                                                                                                       // Verify
                                                                                                       assertEquals(separator, modified.getRecordSeparator());
                                                                                                   }
                                                                                               }

 @Test
                                                                                               public void testWithRecordSeparator_ShouldMaintainOtherConfigurations() {
                                                                                                   // Setup complex original format
                                                                                                   CSVFormat original = CSVFormat.newFormat(';')
                                                                                                       .withQuote('"')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("col1", "col2")
                                                                                                       .withSkipHeaderRecord(true)
                                                                                                       .withAllowMissingColumnNames(false);
                                                                                                   
                                                                                                   // Execute
                                                                                                   CSVFormat modified = original.withRecordSeparator("\r\n");
                                                                                                   
                                                                                                   // Verify all other configurations remain unchanged
                                                                                                   assertEquals(';', modified.getDelimiter());
                                                                                                   assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                                   assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                                   assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                                   assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                                   assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                                   assertFalse(modified.getIgnoreEmptyLines());
                                                                                                   assertEquals("NULL", modified.getNullString());
                                                                                                   assertArrayEquals(new String[]{"col1", "col2"}, modified.getHeader());
                                                                                                   assertTrue(modified.getSkipHeaderRecord());
                                                                                                   assertFalse(modified.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithSkipHeaderRecord_True() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(',')
                                                                                                       .withQuote('"')
                                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                       .withCommentMarker('#')
                                                                                                       .withEscape('\\')
                                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                                       .withIgnoreEmptyLines(false)
                                                                                                       .withRecordSeparator("\r\n")
                                                                                                       .withNullString("NULL")
                                                                                                       .withHeader("Name", "Age", "City")
                                                                                                       .withAllowMissingColumnNames(true);
                                                                                                   
                                                                                                   // Test
                                                                                                   CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithSkipHeaderRecord_False() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withDelimiter(';')
                                                                                                       .withQuote('\'')
                                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                                       .withCommentMarker('!')
                                                                                                       .withEscape('^')
                                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                                       .withIgnoreEmptyLines(true)
                                                                                                       .withRecordSeparator("\n")
                                                                                                       .withNullString("NA")
                                                                                                       .withHeader("ID", "Value")
                                                                                                       .withAllowMissingColumnNames(false)
                                                                                                       .withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   // Test
                                                                                                   CSVFormat newFormat = originalFormat.withSkipHeaderRecord(false);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithSkipHeaderRecord_NoHeader() {
                                                                                                   // Setup
                                                                                                   CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                       .withHeader((String[]) null);
                                                                                                   
                                                                                                   // Test
                                                                                                   CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertNull(newFormat.getHeader());
                                                                                               }

 @Test
                                                                                               public void testWithSkipHeaderRecord_FromDefault() {
                                                                                                   // Test with DEFAULT format (which has skipHeaderRecord = false by default)
                                                                                                   CSVFormat newFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(CSVFormat.DEFAULT.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(CSVFormat.DEFAULT.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                               public void testWithSkipHeaderRecord_FromRFC() {
                                                                                                   // Test with RFC4180 format
                                                                                                   CSVFormat newFormat = CSVFormat.RFC4180.withSkipHeaderRecord(false);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                   assertEquals(CSVFormat.RFC4180.getDelimiter(), newFormat.getDelimiter());
                                                                                                   assertEquals(CSVFormat.RFC4180.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                   assertEquals(CSVFormat.RFC4180.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                   assertEquals(CSVFormat.RFC4180.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                   assertEquals(CSVFormat.RFC4180.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                   assertEquals(CSVFormat.RFC4180.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                   assertEquals(CSVFormat.RFC4180.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                   assertEquals(CSVFormat.RFC4180.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                   assertEquals(CSVFormat.RFC4180.getNullString(), newFormat.getNullString());
                                                                                                   assertArrayEquals(CSVFormat.RFC4180.getHeader(), newFormat.getHeader());
                                                                                                   assertEquals(CSVFormat.RFC4180.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                               }

 @Test
                                                                                       public void testParse_WithMockReaderThrowingIOException() throws IOException {
                                                                                           // Arrange
                                                                                           CSVFormat format = CSVFormat.DEFAULT;
                                                                                           Reader mockReader = mock(Reader.class);
                                                                                           when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                                                                                               .thenThrow(new IOException("Simulated IO error"));
                                                                                           
                                                                                           // Expect exception
                                                                                           thrown.expect(IOException.class);
                                                                                           thrown.expectMessage("Simulated IO error");
                                                                                           
                                                                                           // Act
                                                                                           format.parse(mockReader);
                                                                                       }

 @Test
                                                                                   public void testIsLineBreak_WithLF_ReturnsTrue() throws Exception {
                                                                                       // Get the private method using reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Invoke the method with LF character
                                                                                       boolean result = (boolean) isLineBreakMethod.invoke(null, '\n');
                                                                                       
                                                                                       assertTrue(result);  // LF character should be recognized as line break
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithCR_ReturnsTrue() throws Exception {
                                                                                       // Get the private method using reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Invoke the method with CR character
                                                                                       boolean result = (boolean) isLineBreakMethod.invoke(null, '\r');
                                                                                       
                                                                                       // Assert the result
                                                                                       assertTrue(result);  // CR character should be recognized as line break
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithNonLineBreakChars_ReturnsFalse() throws Exception {
                                                                                       // Get the private isLineBreak method via reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Test various non-line-break characters
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, 'a'));
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, ' '));
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\t'));
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '0'));
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '@'));
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithSpecialChars_ReturnsFalse() throws Exception {
                                                                                       // Get the private isLineBreak method via reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Test various special characters that aren't line breaks
                                                                                       assertFalse((boolean) isLineBreakMethod.invoke(null, '\0'));  // null character
                                                                                       assertFalse((boolean) isLineBreakMethod.invoke(null, '\uFFFF'));  // max char value
                                                                                       assertFalse((boolean) isLineBreakMethod.invoke(null, '\u0001'));  // control character
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithNullCharacter_ReturnsFalse() throws Exception {
                                                                                       Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       method.setAccessible(true);
                                                                                       assertFalse((Boolean) method.invoke(null, (Character) null));
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithWrapperLF_ReturnsTrue() throws Exception {
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       boolean result = (boolean) isLineBreakMethod.invoke(null, Character.valueOf('\n'));
                                                                                       assertTrue(result);
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithWrapperCR_ReturnsTrue() throws Exception {
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       assertTrue((Boolean) isLineBreakMethod.invoke(null, Character.valueOf('\r')));
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithWrapperNonLineBreak_ReturnsFalse() throws Exception {
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       boolean result = (boolean) isLineBreakMethod.invoke(null, Character.valueOf('x'));
                                                                                       assertFalse(result);
                                                                                   }

 @Test(expected = IllegalArgumentException.class)
                                                                                   public void testConstructor_WithLineBreakDelimiter_ThrowsException() throws Exception {
                                                                                       // This tests that isLineBreak is properly used in validation
                                                                                       Constructor<CSVFormat> constructor = CSVFormat.class.getDeclaredConstructor(
                                                                                           char.class, Character.class, QuoteMode.class, Character.class, 
                                                                                           Character.class, boolean.class, boolean.class, String.class, 
                                                                                           String.class, String[].class, boolean.class, boolean.class);
                                                                                       constructor.setAccessible(true);
                                                                                       constructor.newInstance('\n', null, null, null, null, false, false, null, null, null, false, false);
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithNullInput() throws Exception {
                                                                                       // Get the private method using reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Invoke the method with null input
                                                                                       boolean result = (boolean) isLineBreakMethod.invoke(null, (Character) null);
                                                                                       
                                                                                       // Assert the result
                                                                                       assertFalse(result);
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithNonLineBreakCharacters() throws Exception {
                                                                                       // Get the private isLineBreak method that takes char parameter
                                                                                       Method isLineBreakCharMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakCharMethod.setAccessible(true);
                                                                                       
                                                                                       // Test various non-line-break characters
                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(null, 'a'));
                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(null, ' '));
                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(null, '\t'));
                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(null, '0'));
                                                                                       assertFalse((boolean) isLineBreakCharMethod.invoke(null, '@'));
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithLineBreakCharacters() throws Exception {
                                                                                       // Get the private isLineBreak methods using reflection
                                                                                       Method isLineBreakChar = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakChar.setAccessible(true);
                                                                                       Method isLineBreakCharacter = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       isLineBreakCharacter.setAccessible(true);
                                                                                       
                                                                                       // Test common line break characters
                                                                                       assertTrue((boolean) isLineBreakChar.invoke(null, '\n'));  // LF (Unix)
                                                                                       assertTrue((boolean) isLineBreakChar.invoke(null, '\r'));  // CR (Mac)
                                                                                       
                                                                                       // Test CRLF (Windows) - since it's two characters, each should be detected individually
                                                                                       assertTrue((boolean) isLineBreakChar.invoke(null, '\r'));
                                                                                       assertTrue((boolean) isLineBreakChar.invoke(null, '\n'));
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithUnicodeLineBreaks() throws Exception {
                                                                                       // Get the private isLineBreak method using reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Test some Unicode line break characters
                                                                                       assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u0085'));  // NEL (Next Line)
                                                                                       assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u2028'));  // Line Separator
                                                                                       assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u2029'));  // Paragraph Separator
                                                                                   }

 @Test
                                                                                   public void testIsLineBreak_WithControlCharacters() throws Exception {
                                                                                       // Get the private isLineBreak method using reflection
                                                                                       Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                       isLineBreakMethod.setAccessible(true);
                                                                                       
                                                                                       // Test other control characters that aren't line breaks
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\b'));  // Backspace
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\f'));  // Form feed
                                                                                       assertFalse((Boolean) isLineBreakMethod.invoke(null, '\0'));  // Null character
                                                                                   }

 @Test
                                                                                   public void testEquals_Reflexive() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       assertTrue(format1.equals(format1));
                                                                                   }

 @Test
                                                                                   public void testEquals_NullObject() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       assertFalse(format1.equals(null));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentClass() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       assertFalse(format1.equals("Not a CSVFormat object"));
                                                                                   }

 @Test
                                                                                   public void testEquals_AllFieldsEqual() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertTrue(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentDelimiter() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                               .withQuote('"')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker('#')
                                                                                               .withEscape('\\')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withNullString("NULL")
                                                                                               .withHeader("Header1", "Header2")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                               
                                                                                       CSVFormat format2 = CSVFormat.newFormat(';')
                                                                                               .withQuote('"')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker('#')
                                                                                               .withEscape('\\')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withNullString("NULL")
                                                                                               .withHeader("Header1", "Header2")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                               
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentCommentMarker() {
                                                                                       CSVFormat format1 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('!')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentEscapeCharacter() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                               .withQuote('"')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker('#')
                                                                                               .withEscape('\\')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withNullString("NULL")
                                                                                               .withHeader("Header1", "Header2")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                               
                                                                                       CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                               .withQuote('"')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker('#')
                                                                                               .withEscape('/')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withNullString("NULL")
                                                                                               .withHeader("Header1", "Header2")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                               
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentIgnoreSurroundingSpaces() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentIgnoreEmptyLines() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(true)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentRecordSeparator() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                               .withQuote('"')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker('#')
                                                                                               .withEscape('\\')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withNullString("NULL")
                                                                                               .withHeader("Header1", "Header2")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                               
                                                                                       CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                               .withQuote('"')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker('#')
                                                                                               .withEscape('\\')
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\r\n")
                                                                                               .withNullString("NULL")
                                                                                               .withHeader("Header1", "Header2")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                               
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentNullString() {
                                                                                       CSVFormat format1 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("null")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentHeaders() {
                                                                                       CSVFormat format1 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header3")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_OneNullHeader() {
                                                                                       CSVFormat format1 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader((String[]) null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_BothNullHeaders() {
                                                                                       CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader((String[]) null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader((String[]) null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertTrue(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testEquals_DifferentSkipHeaderRecord() {
                                                                                       CSVFormat format1 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false);
                                                                                           
                                                                                       CSVFormat format2 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(true);
                                                                                           
                                                                                       assertFalse(format1.equals(format2));
                                                                                   }

 @Test
                                                                                   public void testGetCommentMarker_WhenCommentMarkerIsNull() {
                                                                                       // Arrange
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote(null)
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker(null)
                                                                                           .withEscape(null)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString(null)
                                                                                           .withHeader((String[])null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Act & Assert
                                                                                       assertNull(format.getCommentMarker());
                                                                                   }

 @Test
                                                                                   public void testGetCommentMarker_WhenCommentMarkerIsSet() {
                                                                                       // Arrange
                                                                                       Character expectedCommentMarker = '#';
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                                               .withCommentMarker(expectedCommentMarker)
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\r\n")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Act & Assert
                                                                                       assertEquals(expectedCommentMarker, format.getCommentMarker());
                                                                                   }

 @Test
                                                                                   public void testGetDelimiter_ConstructorInitialization() {
                                                                                       // Test direct constructor initialization with various delimiters
                                                                                       char[] testDelimiters = {'a', '1', '\t', ';', '|'};
                                                                                       for (char delimiter : testDelimiters) {
                                                                                           CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                           assertEquals(delimiter, format.getDelimiter());
                                                                                       }
                                                                                   }

 @Test
                                                                                   public void testGetDelimiter_ConstructorWithLineBreakShouldThrowException() {
                                                                                       // Test that constructor throws exception for line break delimiters
                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                       thrown.expectMessage("The delimiter cannot be a line break");
                                                                                       
                                                                                       // Create a format with a valid delimiter first
                                                                                       CSVFormat format = CSVFormat.newFormat(',');
                                                                                       // Then try to set the delimiter to a line break
                                                                                       format.withDelimiter('\n');
                                                                                   }

 @Test
                                                                                   public void testGetEscapeCharacter_WhenSet() {
                                                                                       // Setup
                                                                                       Character expectedEscape = '\\';
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape(expectedEscape)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Test & Verify
                                                                                       assertEquals(expectedEscape, format.getEscapeCharacter());
                                                                                   }

 @Test
                                                                                   public void testGetEscapeCharacter_WhenNull() {
                                                                                       // Setup
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape(null)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Test & Verify
                                                                                       assertNull(format.getEscapeCharacter());
                                                                                   }

 @Test
                                                                                   public void testGetHeader_WhenHeaderIsEmptyArray() {
                                                                                       // Arrange
                                                                                       String[] emptyHeader = new String[0];
                                                                                       CSVFormat format = CSVFormat.DEFAULT.withHeader(emptyHeader);
                                                                                       
                                                                                       // Act
                                                                                       String[] result = format.getHeader();
                                                                                       
                                                                                       // Assert
                                                                                       assertNotNull(result);
                                                                                       assertEquals(0, result.length);
                                                                                       assertNotSame(emptyHeader, result); // Verify it's a clone
                                                                                   }

 @Test
                                                                                   public void testGetHeader_WhenHeaderHasSingleElement() {
                                                                                       // Arrange
                                                                                       String[] singleHeader = {"Column1"};
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withHeader(singleHeader)
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Act
                                                                                       String[] result = format.getHeader();
                                                                                       
                                                                                       // Assert
                                                                                       assertNotNull(result);
                                                                                       assertEquals(1, result.length);
                                                                                       assertEquals("Column1", result[0]);
                                                                                       assertNotSame(singleHeader, result); // Verify it's a clone
                                                                                   }

 @Test
                                                                                   public void testGetHeader_WhenHeaderHasMultipleElements() {
                                                                                       // Arrange
                                                                                       String[] multiHeader = {"Column1", "Column2", "Column3"};
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withHeader(multiHeader)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Act
                                                                                       String[] result = format.getHeader();
                                                                                       
                                                                                       // Assert
                                                                                       assertNotNull(result);
                                                                                       assertEquals(3, result.length);
                                                                                       assertArrayEquals(multiHeader, result);
                                                                                       assertNotSame(multiHeader, result); // Verify it's a clone
                                                                                   }

 @Test
                                                                                   public void testGetHeader_VerifyImmutability() {
                                                                                       // Arrange
                                                                                       String[] originalHeader = {"Column1", "Column2"};
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withHeader(originalHeader)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withSkipHeaderRecord(false)
                                                                                               .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       // Act - Get header and modify it
                                                                                       String[] headerCopy = format.getHeader();
                                                                                       headerCopy[0] = "Modified";
                                                                                       
                                                                                       // Assert - Original should remain unchanged
                                                                                       String[] currentHeader = format.getHeader();
                                                                                       assertEquals("Column1", currentHeader[0]);
                                                                                       assertEquals("Column2", currentHeader[1]);
                                                                                   }

 @Test
                                                                                   public void testGetHeader_WithDuplicateHeadersInConstructor_ShouldThrowException() {
                                                                                       // Arrange
                                                                                       String[] duplicateHeader = {"Column1", "Column1"};
                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                       thrown.expectMessage(org.hamcrest.CoreMatchers.containsString("The header contains a duplicate entry"));
                                                                                       
                                                                                       // Act - Should throw exception
                                                                                       CSVFormat.newFormat(',')
                                                                                                .withHeader(duplicateHeader)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                   }

 @Test
                                                                                   public void testGetIgnoreEmptyLines_NewFormatConstructorTrue() {
                                                                                       // Test with constructor setting ignoreEmptyLines to true
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withIgnoreEmptyLines(true)
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withRecordSeparator("\r\n")
                                                                                               .withAllowMissingColumnNames(false)
                                                                                               .withSkipHeaderRecord(false);
                                                                                       assertTrue(format.getIgnoreEmptyLines());
                                                                                   }

 @Test
                                                                                   public void testGetIgnoreEmptyLines_NewFormatConstructorFalse() {
                                                                                       // Test with constructor setting ignoreEmptyLines to false
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withIgnoreEmptyLines(false);
                                                                                       assertFalse(format.getIgnoreEmptyLines());
                                                                                   }

 @Test
                                                                                   public void testGetIgnoreSurroundingSpaces_WhenTrue() {
                                                                                       // Create a CSVFormat instance with ignoreSurroundingSpaces set to true
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertTrue("Should return true when ignoreSurroundingSpaces is true", 
                                                                                           format.getIgnoreSurroundingSpaces());
                                                                                   }

 @Test
                                                                                   public void testGetIgnoreSurroundingSpaces_WhenFalse() {
                                                                                       // Create a CSVFormat instance with ignoreSurroundingSpaces set to false
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertFalse("Should return false when ignoreSurroundingSpaces is false", 
                                                                                           format.getIgnoreSurroundingSpaces());
                                                                                   }

 @Test
                                                                                   public void testGetNullString_WhenNullStringIsNull() {
                                                                                       // Create a CSVFormat instance with null as nullString using builder pattern
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker(null)
                                                                                           .withEscape(null)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString(null)
                                                                                           .withHeader((String[]) null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertNull("Null string should be null", format.getNullString());
                                                                                   }

 @Test
                                                                                   public void testGetNullString_WhenNullStringIsEmpty() {
                                                                                       // Create a CSVFormat instance with empty string as nullString
                                                                                       CSVFormat format = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker(null)
                                                                                           .withEscape(null)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("")
                                                                                           .withHeader((String[]) null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertEquals("Null string should be empty", "", format.getNullString());
                                                                                   }

 @Test
                                                                                   public void testGetNullString_WhenNullStringIsCustomValue() {
                                                                                       // Create a CSVFormat instance with custom nullString using builder pattern
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("NULL")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                       
                                                                                       assertEquals("Null string should be 'NULL'", "NULL", format.getNullString());
                                                                                   }

 @Test
                                                                                   public void testGetQuoteCharacter_WhenQuoteCharacterIsSet() {
                                                                                       // Arrange
                                                                                       Character expectedQuote = '"';
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                               .withQuote(expectedQuote)
                                                                                               .withIgnoreEmptyLines(false)
                                                                                               .withIgnoreSurroundingSpaces(false)
                                                                                               .withRecordSeparator("\n")
                                                                                               .withAllowMissingColumnNames(false)
                                                                                               .withSkipHeaderRecord(false);
                                                                                       
                                                                                       // Act
                                                                                       Character actualQuote = format.getQuoteCharacter();
                                                                                       
                                                                                       // Assert
                                                                                       assertEquals(expectedQuote, actualQuote);
                                                                                   }

 @Test
                                                                                   public void testGetQuoteCharacter_WhenQuoteCharacterIsNull() {
                                                                                       // Arrange
                                                                                       CSVFormat format = CSVFormat.newFormat(',').withQuote((Character) null);
                                                                                       
                                                                                       // Act
                                                                                       Character actualQuote = format.getQuoteCharacter();
                                                                                       
                                                                                       // Assert
                                                                                       assertNull(actualQuote);
                                                                                   }

 @Test
                                                                                   public void testGetQuoteCharacter_AfterModifyingWithQuote() {
                                                                                       // Arrange
                                                                                       Character initialQuote = '"';
                                                                                       Character newQuote = '\'';
                                                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote(initialQuote)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withAllowMissingColumnNames(false)
                                                                                           .withSkipHeaderRecord(false);
                                                                                       
                                                                                       // Act - modify the quote character
                                                                                       CSVFormat modifiedFormat = format.withQuote(newQuote);
                                                                                       Character actualQuote = modifiedFormat.getQuoteCharacter();
                                                                                       
                                                                                       // Assert
                                                                                       assertEquals(newQuote, actualQuote);
                                                                                       // Verify original format wasn't modified (since withQuote should return new instance)
                                                                                       assertEquals(initialQuote, format.getQuoteCharacter());
                                                                                   }

 @Test
                                                                               public void testGetQuoteMode_WhenNewFormatCreatedWithSpecificQuoteMode() {
                                                                                   // Create new format with specific quote mode using builder pattern
                                                                                   CSVFormat newFormat = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withAllowMissingColumnNames(false)
                                                                                           .withSkipHeaderRecord(false);
                                                                                   assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                               }

 @Test
                                                                               public void testGetRecordSeparator_CustomFormatWithNullSeparator() {
                                                                                   // Test with custom format where separator is null
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withRecordSeparator(null);
                                                                                   assertNull(format.getRecordSeparator());
                                                                               }

 @Test
                                                                               public void testGetRecordSeparator_CustomFormatWithEmptySeparator() {
                                                                                   // Test with custom format where separator is empty string
                                                                                   CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("");
                                                                                   assertEquals("", format.getRecordSeparator());
                                                                               }

 @Test
                                                                               public void testGetRecordSeparator_CustomFormatWithCR() {
                                                                                   // Test with custom format where separator is CR
                                                                                   CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r");
                                                                                   assertEquals("\r", format.getRecordSeparator());
                                                                               }

 @Test
                                                                               public void testGetRecordSeparator_CustomFormatWithLF() {
                                                                                   // Test with custom format where separator is LF
                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   assertEquals("\n", format.getRecordSeparator());
                                                                               }

 @Test
                                                                               public void testGetRecordSeparator_CustomFormatWithCRLF() {
                                                                                   // Test with custom format where separator is CRLF
                                                                                   CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                   assertEquals("\r\n", format.getRecordSeparator());
                                                                               }

 @Test
                                                                               public void testGetRecordSeparator_CustomFormatWithCustomString() {
                                                                                   // Test with custom format where separator is a custom string
                                                                                   String customSeparator = "|END|";
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator(customSeparator)
                                                                                       .withAllowMissingColumnNames(false)
                                                                                       .withSkipHeaderRecord(false);
                                                                                   assertEquals(customSeparator, format.getRecordSeparator());
                                                                               }

 @Test
                                                                               public void testHashCode() {
                                                                                   // Test with all fields set to non-null values
                                                                                   CSVFormat format1 = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("NULL")
                                                                                       .withHeader("Header1", "Header2")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Same values as format1 - should have same hash code
                                                                                   CSVFormat format2 = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("NULL")
                                                                                       .withHeader("Header1", "Header2")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertEquals(format1.hashCode(), format2.hashCode());
                                                                                   
                                                                                   // Test with null values for object fields
                                                                                   CSVFormat format3 = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withQuote(null)
                                                                                       .withQuoteMode(null)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(true)
                                                                                       .withRecordSeparator(null)
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(true);
                                                                                   
                                                                                   // Should not throw NPE and should produce consistent hash code
                                                                                   int hash3 = format3.hashCode();
                                                                                   assertEquals(hash3, format3.hashCode());
                                                                                   
                                                                                   // Test with empty header array
                                                                                   CSVFormat format4 = CSVFormat.DEFAULT
                                                                                       .withDelimiter('\t')
                                                                                       .withQuote('\'')
                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                       .withCommentMarker('!')
                                                                                       .withEscape('|')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withNullString("")
                                                                                       .withHeader(new String[]{})
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Test with different boolean combinations
                                                                                   CSVFormat format5 = CSVFormat.DEFAULT
                                                                                       .withDelimiter(';')
                                                                                       .withQuote(null)
                                                                                       .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                       .withIgnoreEmptyLines(true)
                                                                                       .withRecordSeparator(null)
                                                                                       .withNullString("null")
                                                                                       .withHeader("Col1")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(true);
                                                                                   
                                                                                   // Verify different formats have different hash codes
                                                                                   assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                   assertNotEquals(format1.hashCode(), format4.hashCode());
                                                                                   assertNotEquals(format1.hashCode(), format5.hashCode());
                                                                                   assertNotEquals(format3.hashCode(), format4.hashCode());
                                                                                   assertNotEquals(format3.hashCode(), format5.hashCode());
                                                                                   assertNotEquals(format4.hashCode(), format5.hashCode());
                                                                                   
                                                                                   // Test with same values but different header order - should have different hash codes
                                                                                   CSVFormat format6 = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("NULL")
                                                                                       .withHeader("Header2", "Header1")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertNotEquals(format1.hashCode(), format6.hashCode());
                                                                                   
                                                                                   // Test with different delimiter
                                                                                   CSVFormat format7 = CSVFormat.DEFAULT
                                                                                       .withDelimiter('|')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("NULL")
                                                                                       .withHeader("Header1", "Header2")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertNotEquals(format1.hashCode(), format7.hashCode());
                                                                                   
                                                                                   // Test with different boolean flags
                                                                                   CSVFormat format8 = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(false)  // different ignoreSurroundingSpaces
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("NULL")
                                                                                       .withHeader("Header1", "Header2")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertNotEquals(format1.hashCode(), format8.hashCode());
                                                                               }

 @Test
                                                                               public void testIsCommentMarkerSet_WhenCommentMarkerIsNull() {
                                                                                   // Create CSVFormat with null comment marker using public methods
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withCommentMarker(null)
                                                                                       .withQuote(null)
                                                                                       .withQuoteMode(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertFalse("Should return false when commentMarker is null", 
                                                                                              format.isCommentMarkerSet());
                                                                               }

 @Test
                                                                               public void testIsCommentMarkerSet_WhenCommentMarkerIsNotNull() {
                                                                                   // Create CSVFormat with non-null comment marker using builder pattern
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withCommentMarker('#')
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertTrue("Should return true when commentMarker is not null", 
                                                                                              format.isCommentMarkerSet());
                                                                               }

 @Test
                                                                               public void testIsCommentMarkerSet_AfterSettingCommentMarker() {
                                                                                   // Create basic CSVFormat with comma delimiter and no comment marker
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuote(null)                      // quoteChar
                                                                                       .withQuoteMode(null)                  // quoteMode
                                                                                       .withCommentMarker(null)              // commentStart
                                                                                       .withEscape(null)                     // escape
                                                                                       .withIgnoreSurroundingSpaces(false)   // ignoreSurroundingSpaces
                                                                                       .withIgnoreEmptyLines(false)          // ignoreEmptyLines
                                                                                       .withRecordSeparator("\r\n")          // recordSeparator
                                                                                       .withNullString(null)                 // nullString
                                                                                       .withHeader((String[]) null)          // header
                                                                                       .withSkipHeaderRecord(false)          // skipHeaderRecord
                                                                                       .withAllowMissingColumnNames(false);  // allowMissingColumnNames
                                                                                   
                                                                                   assertFalse("Initial state should be false", format.isCommentMarkerSet());
                                                                                   
                                                                                   // Set comment marker and verify
                                                                                   CSVFormat withComment = format.withCommentMarker('#');
                                                                                   assertTrue("Should return true after setting comment marker", 
                                                                                             withComment.isCommentMarkerSet());
                                                                               }

 @Test
                                                                               public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNull() {
                                                                                   // Create a CSVFormat instance with null escape character
                                                                                   CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                           .withQuote('"')                     // quoteChar
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)   // quoteMode
                                                                                           .withEscape(null)                   // escape
                                                                                           .withIgnoreSurroundingSpaces(false) // ignoreSurroundingSpaces
                                                                                           .withIgnoreEmptyLines(false)       // ignoreEmptyLines
                                                                                           .withRecordSeparator("\r\n")        // recordSeparator
                                                                                           .withSkipHeaderRecord(false)        // skipHeaderRecord
                                                                                           .withAllowMissingColumnNames(false);// allowMissingColumnNames
                                                                                   
                                                                                   assertFalse("Should return false when escapeCharacter is null", 
                                                                                              format.isEscapeCharacterSet());
                                                                               }

 @Test
                                                                               public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNotNull() {
                                                                                   // Create a CSVFormat instance with non-null escape character using builder pattern
                                                                                   CSVFormat format = CSVFormat.newFormat(',') // delimiter
                                                                                           .withQuote('"')                    // quoteChar
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)  // quoteMode
                                                                                           .withEscape('\\')                 // escape
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertTrue("Should return true when escapeCharacter is not null", 
                                                                                             format.isEscapeCharacterSet());
                                                                               }

 @Test
                                                                               public void testIsEscapeCharacterSet_AfterModifyingEscapeCharacter() {
                                                                                   // Create initial format with null escape character using public factory method
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertFalse("Initial state should be false", format.isEscapeCharacterSet());
                                                                                   
                                                                                   // Create new format with escape character set
                                                                                   CSVFormat newFormat = format.withEscape('\\');
                                                                                   assertTrue("After setting escape character, should return true", 
                                                                                             newFormat.isEscapeCharacterSet());
                                                                                   
                                                                                   // Create another format with escape character removed
                                                                                   CSVFormat noEscapeFormat = newFormat.withEscape(null);
                                                                                   assertFalse("After removing escape character, should return false", 
                                                                                             noEscapeFormat.isEscapeCharacterSet());
                                                                               }

 @Test
                                                                               public void testIsNullStringSet_WhenNullStringIsNull() {
                                                                                   // Create CSVFormat with nullString set to null using builder pattern
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuote(null)
                                                                                       .withQuoteMode(null)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertFalse("Should return false when nullString is null", 
                                                                                              format.isNullStringSet());
                                                                               }

 @Test
                                                                               public void testIsNullStringSet_WhenNullStringIsEmptyString() {
                                                                                   // Create CSVFormat with empty string as nullString using builder pattern
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuote(null)
                                                                                       .withQuoteMode(null)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withNullString("")
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertTrue("Should return true when nullString is empty string", 
                                                                                             format.isNullStringSet());
                                                                               }

 @Test
                                                                               public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNull() {
                                                                                   // Create format with null quote character
                                                                                   CSVFormat format = CSVFormat.newFormat(',').withQuote((Character) null);
                                                                                   
                                                                                   assertFalse("Should return false when quoteCharacter is null", 
                                                                                       format.isQuoteCharacterSet());
                                                                               }

 @Test
                                                                               public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNotNull() {
                                                                                   // Create format with non-null quote character using public methods
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString(null)
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   assertTrue("Should return true when quoteCharacter is not null", 
                                                                                           format.isQuoteCharacterSet());
                                                                               }

 @Test
                                                                               public void testIsQuoteCharacterSet_AfterWithQuoteChar() {
                                                                                   // Create basic format using public factory method
                                                                                   CSVFormat format = CSVFormat.newFormat(',');
                                                                                   
                                                                                   // Modify with withQuote method
                                                                                   CSVFormat modifiedFormat = format.withQuote('"');
                                                                                   
                                                                                   assertTrue("Should return true after setting quote character", 
                                                                                       modifiedFormat.isQuoteCharacterSet());
                                                                               }

 @Test
                                                                               public void testIsQuoteCharacterSet_AfterWithQuoteCharacter() {
                                                                                   // Create basic format using public factory method
                                                                                   CSVFormat format = CSVFormat.newFormat(',');
                                                                                   
                                                                                   // Modify with withQuote method using Character object
                                                                                   CSVFormat modifiedFormat = format.withQuote(Character.valueOf('"'));
                                                                                   
                                                                                   assertTrue("Should return true after setting quote character", 
                                                                                       modifiedFormat.isQuoteCharacterSet());
                                                                               }

 @Test
                                                                               public void testToString_WithAllOptions() {
                                                                                   CSVFormat format = CSVFormat.newFormat(';')
                                                                                       .withQuote('\'')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(true)
                                                                                       .withIgnoreEmptyLines(true)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("NULL")
                                                                                       .withHeader("col1", "col2")
                                                                                       .withSkipHeaderRecord(true)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   String expected = "Delimiter=<;> Escape=<\\> QuoteChar=<'> CommentStart=<#> " +
                                                                                                    "NullString=<NULL> RecordSeparator=<\\r\\n> EmptyLines:ignored " +
                                                                                                    "SurroundingSpaces:ignored SkipHeaderRecord:true Header:[col1, col2]";
                                                                                   assertEquals(expected, format.toString());
                                                                               }

 @Test
                                                                               public void testToString_WithNullValues() {
                                                                                   CSVFormat format = CSVFormat.newFormat('\t')  // delimiter
                                                                                           .withQuote(null)                     // quoteChar
                                                                                           .withQuoteMode(null)                 // quoteMode
                                                                                           .withCommentMarker(null)             // commentMarker
                                                                                           .withEscape(null)                    // escape
                                                                                           .withIgnoreSurroundingSpaces(false)  // ignoreSurroundingSpaces
                                                                                           .withIgnoreEmptyLines(false)         // ignoreEmptyLines
                                                                                           .withRecordSeparator(null)           // recordSeparator
                                                                                           .withNullString(null)               // nullString
                                                                                           .withHeader((String[]) null)         // header
                                                                                           .withSkipHeaderRecord(false)         // skipHeaderRecord
                                                                                           .withAllowMissingColumnNames(false);  // allowMissingColumnNames
                                                                                   
                                                                                   String expected = "Delimiter=<\\t> SkipHeaderRecord:false";
                                                                                   assertEquals(expected, format.toString());
                                                                               }

 @Test
                                                                               public void testValidate_QuoteCharSameAsDelimiter() {
                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                   thrown.expectMessage("The quoteChar character and the delimiter cannot be the same ('\"')");
                                                                                   
                                                                                   CSVFormat format = CSVFormat.newFormat('"');
                                                                                   format.withQuote('"');
                                                                               }

 @Test
                                                                               public void testValidate_EscapeCharSameAsDelimiter() {
                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                   thrown.expectMessage("The escape character and the delimiter cannot be the same ('\\')");
                                                                                   
                                                                                   CSVFormat.newFormat('\\').withEscape('\\');
                                                                               }

 @Test
                                                                               public void testValidate_CommentMarkerSameAsDelimiter() {
                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                   thrown.expectMessage("The comment start character and the delimiter cannot be the same ('#')");
                                                                                   
                                                                                   CSVFormat.newFormat('#')
                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                            .withCommentMarker('#')
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\n")
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false);
                                                                               }

 @Test
                                                                               public void testValidate_QuoteCharSameAsCommentMarker() {
                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                   thrown.expectMessage("The comment start character and the quoteChar cannot be the same ('\"')");
                                                                                   
                                                                                   CSVFormat format = CSVFormat.DEFAULT
                                                                                       .withDelimiter(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('"');
                                                                               }

 @Test
                                                                               public void testValidate_EscapeCharSameAsCommentMarker() {
                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                   thrown.expectMessage("The comment start and the escape character cannot be the same ('!')");
                                                                                   
                                                                                   CSVFormat.newFormat(',')
                                                                                            .withEscape('!')
                                                                                            .withCommentMarker('!')
                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\n")
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false);
                                                                               }

 @Test
                                                                               public void testValidate_ValidConfigurationWithQuoteModeNone() {
                                                                                   // Should not throw any exception
                                                                                   CSVFormat.newFormat(',')
                                                                                            .withQuoteMode(QuoteMode.NONE)
                                                                                            .withEscape('\\')
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\n")
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false);
                                                                               }

 @Test
                                                                               public void testValidate_ValidConfigurationWithAllParameters() {
                                                                                   // Should not throw any exception
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.ALL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                               }

 @Test
                                                                               public void testValidate_ValidMinimalConfiguration() {
                                                                                   // Should not throw any exception
                                                                                   CSVFormat.newFormat(',')
                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                               }

 @Test
                                                                               public void testValidate_NullParameters() {
                                                                                   // Should not throw any exception when optional parameters are null
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                       .withQuote(null)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                               }

 @Test
                                                                               public void testWithCommentMarker_NonNullValue() {
                                                                                   // Setup original format with no comment marker using public methods
                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("null")
                                                                                       .withHeader("header1", "header2")
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Test with new comment marker
                                                                                   Character newCommentMarker = '#';
                                                                                   CSVFormat modified = original.withCommentMarker(newCommentMarker);
                                                                                   
                                                                                   // Verify new format has the new comment marker
                                                                                   assertEquals(newCommentMarker, modified.getCommentMarker());
                                                                                   assertTrue(modified.isCommentMarkerSet());
                                                                                   
                                                                                   // Verify other properties remain unchanged
                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                   assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                   assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                   assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                   assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                   assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                   assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                               }

 @Test
                                                                               public void testWithCommentMarker_NullValue1() {
                                                                                   // Setup original format with comment marker
                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("null")
                                                                                           .withHeader("header1", "header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Test with null comment marker
                                                                                   CSVFormat modified = original.withCommentMarker(null);
                                                                                   
                                                                                   // Verify new format has no comment marker
                                                                                   assertNull(modified.getCommentMarker());
                                                                                   assertFalse(modified.isCommentMarkerSet());
                                                                                   
                                                                                   // Verify other properties remain unchanged
                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                   assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                   assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                   assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                   assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                   assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                   assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                               }

 @Test
                                                                               public void testWithCommentMarker_SameValue() {
                                                                                   // Setup original format with comment marker
                                                                                   Character commentMarker = '#';
                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker(commentMarker)
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("null")
                                                                                           .withHeader("header1", "header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Test with same comment marker
                                                                                   CSVFormat modified = original.withCommentMarker(commentMarker);
                                                                                   
                                                                                   // Should return the same instance (immutable pattern optimization)
                                                                                   assertSame(original, modified);
                                                                               }

 @Test
                                                                               public void testWithCommentMarker_EqualsAndHashCode() {
                                                                                   // Setup two identical formats using public methods
                                                                                   CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                       .withQuote('"')
                                                                                       .withQuoteMode(QuoteMode.MINIMAL)
                                                                                       .withCommentMarker('#')
                                                                                       .withEscape('\\')
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\r\n")
                                                                                       .withNullString("null")
                                                                                       .withHeader("header1", "header2")
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   CSVFormat format2 = format1.withCommentMarker('!');
                                                                                   CSVFormat format3 = format2.withCommentMarker('#');
                                                                                   
                                                                                   // Verify equals and hashCode consistency
                                                                                   assertNotEquals(format1, format2);
                                                                                   assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                   
                                                                                   assertEquals(format1, format3);
                                                                                   assertEquals(format1.hashCode(), format3.hashCode());
                                                                               }

 @Test
                                                                               public void testWithNullString_WithAllOtherProperties() {
                                                                                   // Setup format with all properties
                                                                                   String[] headers = {"col1", "col2"};
                                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(true)
                                                                                           .withIgnoreEmptyLines(true)
                                                                                           .withRecordSeparator("\r\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader(headers)
                                                                                           .withSkipHeaderRecord(true)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Test with new null string
                                                                                   CSVFormat modified = original.withNullString("NA");
                                                                                   
                                                                                   assertNotNull(modified);
                                                                                   assertEquals("NA", modified.getNullString());
                                                                                   // Verify all other properties remain unchanged
                                                                                   assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                   assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                   assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                   assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                   assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                   assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                   assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                   assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                   assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                   assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                   assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                               }

 @Test
                                                                               public void testIsLineBreak_WithSpecialCharacters() {
                                                                                   // Test various special characters by trying to use them as delimiters
                                                                                   // The constructor throws IllegalArgumentException if delimiter is a line break
                                                                                   try {
                                                                                       CSVFormat.newFormat(';');
                                                                                       // No exception means it's not a line break
                                                                                   } catch (IllegalArgumentException e) {
                                                                                       fail("Semicolon should not be considered a line break");
                                                                                   }
                                                                                   
                                                                                   try {
                                                                                       CSVFormat.newFormat(',');
                                                                                       // No exception means it's not a line break
                                                                                   } catch (IllegalArgumentException e) {
                                                                                       fail("Comma should not be considered a line break");
                                                                                   }
                                                                                   
                                                                                   try {
                                                                                       CSVFormat.newFormat('.');
                                                                                       // No exception means it's not a line break
                                                                                   } catch (IllegalArgumentException e) {
                                                                                       fail("Period should not be considered a line break");
                                                                                   }
                                                                                   
                                                                                   try {
                                                                                       CSVFormat.newFormat('!');
                                                                                       // No exception means it's not a line break
                                                                                   } catch (IllegalArgumentException e) {
                                                                                       fail("Exclamation mark should not be considered a line break");
                                                                                   }
                                                                               }

 @Test
                                                                               public void testEquals_DifferentQuoteCharacter() {
                                                                                   CSVFormat format1 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('"')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                   CSVFormat format2 = CSVFormat.DEFAULT
                                                                                           .withDelimiter(',')
                                                                                           .withQuote('\'')
                                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                                           .withCommentMarker('#')
                                                                                           .withEscape('\\')
                                                                                           .withIgnoreSurroundingSpaces(false)
                                                                                           .withIgnoreEmptyLines(false)
                                                                                           .withRecordSeparator("\n")
                                                                                           .withNullString("NULL")
                                                                                           .withHeader("Header1", "Header2")
                                                                                           .withSkipHeaderRecord(false)
                                                                                           .withAllowMissingColumnNames(false);
                                                                                           
                                                                                   assertFalse(format1.equals(format2));
                                                                               }

 @Test
                                                                               public void testGetHeader_WhenHeaderIsNull() {
                                                                                   // Arrange
                                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                                       .withQuote(null)
                                                                                       .withQuoteMode(null)
                                                                                       .withCommentMarker(null)
                                                                                       .withEscape(null)
                                                                                       .withIgnoreSurroundingSpaces(false)
                                                                                       .withIgnoreEmptyLines(false)
                                                                                       .withRecordSeparator("\n")
                                                                                       .withNullString(null)
                                                                                       .withHeader((String[]) null)
                                                                                       .withSkipHeaderRecord(false)
                                                                                       .withAllowMissingColumnNames(false);
                                                                                   
                                                                                   // Act
                                                                                   String[] result = format.getHeader();
                                                                                   
                                                                                   // Assert
                                                                                   assertNull(result);
                                                                               }

 @Test
                                                                       public void testWithQuoteMode_SameQuoteMode() {
                                                                           // Setup format with specific quote mode
                                                                           CSVFormat originalFormat = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                           
                                                                           // Apply withQuoteMode with same value
                                                                           CSVFormat newFormat = originalFormat.withQuoteMode(QuoteMode.ALL);
                                                                           
                                                                           // Verify it's the same instance (optimization)
                                                                           assertSame(originalFormat, newFormat);
                                                                       }

 @Test
                                                                       public void testEquals_BothNullQuoteCharacter() {
                                                                           CSVFormat format1 = CSVFormat.newFormat(',')
                                                                               .withQuote(null)
                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                               .withCommentMarker('#')
                                                                               .withEscape('\\')
                                                                               .withIgnoreSurroundingSpaces(false)
                                                                               .withIgnoreEmptyLines(false)
                                                                               .withRecordSeparator("\n")
                                                                               .withNullString("NULL")
                                                                               .withHeader("Header1", "Header2")
                                                                               .withSkipHeaderRecord(false)
                                                                               .withAllowMissingColumnNames(false);
                                                                           
                                                                           CSVFormat format2 = CSVFormat.newFormat(',')
                                                                               .withQuote(null)
                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                               .withCommentMarker('#')
                                                                               .withEscape('\\')
                                                                               .withIgnoreSurroundingSpaces(false)
                                                                               .withIgnoreEmptyLines(false)
                                                                               .withRecordSeparator("\n")
                                                                               .withNullString("NULL")
                                                                               .withHeader("Header1", "Header2")
                                                                               .withSkipHeaderRecord(false)
                                                                               .withAllowMissingColumnNames(false);
                                                                           
                                                                           assertTrue(format1.equals(format2));
                                                                       }

 @Test
                                                                       public void testEquals_OneNullQuoteCharacter() {
                                                                           CSVFormat format1 = CSVFormat.DEFAULT
                                                                               .withDelimiter(',')
                                                                               .withQuote(null)
                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                               .withCommentMarker('#')
                                                                               .withEscape('\\')
                                                                               .withIgnoreSurroundingSpaces(false)
                                                                               .withIgnoreEmptyLines(false)
                                                                               .withRecordSeparator("\n")
                                                                               .withNullString("NULL")
                                                                               .withHeader("Header1", "Header2")
                                                                               .withSkipHeaderRecord(false)
                                                                               .withAllowMissingColumnNames(false);
                                                                               
                                                                           CSVFormat format2 = CSVFormat.DEFAULT
                                                                               .withDelimiter(',')
                                                                               .withQuote('"')
                                                                               .withQuoteMode(QuoteMode.MINIMAL)
                                                                               .withCommentMarker('#')
                                                                               .withEscape('\\')
                                                                               .withIgnoreSurroundingSpaces(false)
                                                                               .withIgnoreEmptyLines(false)
                                                                               .withRecordSeparator("\n")
                                                                               .withNullString("NULL")
                                                                               .withHeader("Header1", "Header2")
                                                                               .withSkipHeaderRecord(false)
                                                                               .withAllowMissingColumnNames(false);
                                                                               
                                                                           assertFalse(format1.equals(format2));
                                                                       }

 @Test
                                                                   public void testEquals_DifferentQuoteMode() {
                                                                       CSVFormat format1 = CSVFormat.DEFAULT
                                                                           .withDelimiter(',')
                                                                           .withQuote('"')
                                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                                           .withCommentMarker('#')
                                                                           .withEscape('\\')
                                                                           .withIgnoreSurroundingSpaces(false)
                                                                           .withIgnoreEmptyLines(false)
                                                                           .withRecordSeparator("\n")
                                                                           .withNullString("NULL")
                                                                           .withHeader("Header1", "Header2")
                                                                           .withSkipHeaderRecord(false)
                                                                           .withAllowMissingColumnNames(false);
                                                                       
                                                                       CSVFormat format2 = CSVFormat.DEFAULT
                                                                           .withDelimiter(',')
                                                                           .withQuote('"')
                                                                           .withQuoteMode(QuoteMode.ALL)
                                                                           .withCommentMarker('#')
                                                                           .withEscape('\\')
                                                                           .withIgnoreSurroundingSpaces(false)
                                                                           .withIgnoreEmptyLines(false)
                                                                           .withRecordSeparator("\n")
                                                                           .withNullString("NULL")
                                                                           .withHeader("Header1", "Header2")
                                                                           .withSkipHeaderRecord(false)
                                                                           .withAllowMissingColumnNames(false);
                                                                       
                                                                       assertFalse(format1.equals(format2));
                                                                   }

 @Test
                                                               public void testIsNullStringSet_WhenNullStringIsNonEmptyString() {
                                                                   // Create CSVFormat with non-empty nullString using builder pattern
                                                                   CSVFormat format = CSVFormat.newFormat(',')
                                                                       .withQuote(null)
                                                                       .withQuoteMode(null)
                                                                       .withCommentMarker(null)
                                                                       .withEscape(null)
                                                                       .withIgnoreSurroundingSpaces(false)
                                                                       .withIgnoreEmptyLines(false)
                                                                       .withRecordSeparator("\n")
                                                                       .withNullString("NULL")
                                                                       .withHeader((String[])null)
                                                                       .withSkipHeaderRecord(false)
                                                                       .withAllowMissingColumnNames(false);
                                                                   
                                                                   assertTrue("Should return true when nullString is non-empty", 
                                                                             format.isNullStringSet());
                                                               }

 @Test
                                                               public void testIsNullStringSet_AfterWithNullStringModification() {
                                                                   // Create format with null nullString, then modify it
                                                                   CSVFormat original = CSVFormat.newFormat(',')
                                                                       .withQuote((Character) null)
                                                                       .withQuoteMode(null)
                                                                       .withCommentMarker((Character) null)
                                                                       .withEscape((Character) null)
                                                                       .withIgnoreSurroundingSpaces(false)
                                                                       .withIgnoreEmptyLines(false)
                                                                       .withRecordSeparator("\n")
                                                                       .withNullString(null)
                                                                       .withHeader((String[])null)
                                                                       .withSkipHeaderRecord(false)
                                                                       .withAllowMissingColumnNames(false);
                                                                   
                                                                   assertFalse("Original should have nullString not set", 
                                                                              original.isNullStringSet());
                                                                   
                                                                   // Modify with non-null nullString
                                                                   CSVFormat modified = original.withNullString("NULL");
                                                                   assertTrue("Modified should have nullString set", 
                                                                             modified.isNullStringSet());
                                                                   
                                                                   // Modify back to null
                                                                   CSVFormat modifiedBack = modified.withNullString(null);
                                                                   assertFalse("Modified back should have nullString not set", 
                                                                              modifiedBack.isNullStringSet());
                                                               }

 @Test
                                                       public void testWithDelimiter_NonDefaultFormat() {
                                                           // Setup
                                                           CSVFormat originalFormat = CSVFormat.newFormat(';')
                                                               .withQuote('"')
                                                               .withQuoteMode(QuoteMode.ALL)
                                                               .withCommentMarker('#')
                                                               .withEscape('\\')
                                                               .withIgnoreSurroundingSpaces(true)
                                                               .withIgnoreEmptyLines(false)
                                                               .withRecordSeparator("\r\n")
                                                               .withNullString("NULL")
                                                               .withHeader("col1", "col2")
                                                               .withSkipHeaderRecord(true)
                                                               .withAllowMissingColumnNames(false);
                                                           
                                                           char newDelimiter = '\t';
                                                           
                                                           // Execute
                                                           CSVFormat newFormat = originalFormat.withDelimiter(newDelimiter);
                                                           
                                                           // Verify
                                                           assertEquals(newDelimiter, newFormat.getDelimiter());
                                                           assertEquals('"', newFormat.getQuoteCharacter().charValue());
                                                           assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                           assertEquals('#', newFormat.getCommentMarker().charValue());
                                                           assertEquals('\\', newFormat.getEscapeCharacter().charValue());
                                                           assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                           assertFalse(newFormat.getIgnoreEmptyLines());
                                                           assertEquals("\r\n", newFormat.getRecordSeparator());
                                                           assertEquals("NULL", newFormat.getNullString());
                                                           assertArrayEquals(new String[]{"col1", "col2"}, newFormat.getHeader());
                                                           assertTrue(newFormat.getSkipHeaderRecord());
                                                           assertFalse(newFormat.getAllowMissingColumnNames());
                                                       }

 @Test
                                                   public void testIsCommentMarkerSet_AfterRemovingCommentMarker() {
                                                       // Create CSVFormat with comment marker using builder pattern
                                                       CSVFormat format = CSVFormat.newFormat(',')
                                                           .withQuoteMode(QuoteMode.ALL)
                                                           .withCommentMarker('#')
                                                           .withEscape(null)
                                                           .withIgnoreSurroundingSpaces(false)
                                                           .withIgnoreEmptyLines(false)
                                                           .withRecordSeparator("\r\n")
                                                           .withNullString(null)
                                                           .withHeader((String[]) null)
                                                           .withSkipHeaderRecord(false)
                                                           .withAllowMissingColumnNames(false);
                                                       
                                                       assertTrue("Initial state should be true", format.isCommentMarkerSet());
                                                       
                                                       // Remove comment marker and verify
                                                       CSVFormat withoutComment = format.withCommentMarker((Character) null);
                                                       assertFalse("Should return false after removing comment marker", 
                                                                  withoutComment.isCommentMarkerSet());
                                                   }

 @Test
                                                   public void testParse_WithDefaultFormat() throws IOException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.RFC4180;
                                                       String input = "name,age,city\nJohn,30,New York";
                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                       
                                                       // Assert
                                                       org.junit.Assert.assertNotNull(parser);
                                                   }

 @Test
                                                   public void testParse_WithExcelFormat() throws IOException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.EXCEL;
                                                       String input = "name,age,city\nJohn,30,New York";
                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                       
                                                       // Assert
                                                       assertNotNull(parser);
                                                   }

 @Test
                                                   public void testParse_WithEmptyInput() throws IOException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                       String input = "";
                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                       
                                                       // Assert
                                                       org.junit.Assert.assertNotNull(parser);
                                                   }

 @Test
                                                   public void testParse_WithHeader() throws IOException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withHeader("name", "age", "city");
                                                       String input = "name,age,city\nJohn,30,New York";
                                                       java.io.Reader reader = new java.io.StringReader(input);
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                                       
                                                       // Assert
                                                       org.junit.Assert.assertNotNull(parser);
                                               {}
                                                   }

 @Test
                                                   public void testPrint_WithDefaultFormat() throws IOException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(',');
                                                       java.io.StringWriter writer = new java.io.StringWriter();
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                       
                                                       // Assert
                                                       assertNotNull(printer);
                                                       printer.print("test");
                                                       printer.flush();
                                                       assertEquals("test", writer.toString());
                                                   }

 @Test
                                                   public void testPrint_WithCustomFormat() throws java.io.IOException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(';')
                                                           .withQuote('"')  // Using char literal for quote character
                                                           .withQuoteMode(org.apache.commons.csv.QuoteMode.ALL)
                                                           .withRecordSeparator("\r\n");
                                                       java.io.StringWriter writer = new java.io.StringWriter();
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                       
                                                       // Assert
                                                       org.junit.Assert.assertNotNull(printer);
                                                       org.junit.Assert.assertSame(writer, printer.getOut());
                                                   }

 @Test
                                                   public void testPrint_WithMockedAppendable() throws IOException {
                                                       // Arrange
                                                       CSVFormat format = CSVFormat.newFormat(','); // Create a format with comma delimiter
                                                       Appendable mockAppendable = mock(Appendable.class);
                                                       
                                                       // Act
                                                       CSVPrinter printer = format.print(mockAppendable);
                                                       
                                                       // Assert
                                                       assertNotNull(printer);
                                                       assertSame(mockAppendable, printer.getOut());
                                                   }

 @Test
                                                   public void testPrint_WithAllFormatOptions() throws IOException {
                                                       // Arrange
                                                       CSVFormat format = CSVFormat.newFormat('|')
                                                           .withQuote('"')
                                                           .withQuoteMode(QuoteMode.MINIMAL)
                                                           .withCommentMarker('#')
                                                           .withEscape('\\')
                                                           .withIgnoreSurroundingSpaces(true)
                                                           .withIgnoreEmptyLines(true)
                                                           .withRecordSeparator("\n")
                                                           .withNullString("NULL")
                                                           .withHeader("Name", "Age", "City")
                                                           .withSkipHeaderRecord(true);
                                                       StringWriter writer = new StringWriter();
                                                       
                                                       // Act
                                                       CSVPrinter printer = format.print(writer);
                                                       
                                                       // Assert
                                                       assertNotNull(printer);
                                                       assertSame(writer, printer.getOut());
                                                   }

 @Test
                                                   public void testPrint_WithRFC4180Format() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.RFC4180;
                                                       java.io.StringWriter writer = new java.io.StringWriter();
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                       
                                                       // Assert
                                                       org.junit.Assert.assertNotNull(printer);
                                                       
                                                       // Use reflection to access private "out" field of CSVPrinter
                                                       Field outField = org.apache.commons.csv.CSVPrinter.class.getDeclaredField("out");
                                                       outField.setAccessible(true);
                                                       Appendable printerOutput = (Appendable) outField.get(printer);
                                                       org.junit.Assert.assertSame(writer, printerOutput);
                                                   }

 @Test
                                                   public void testPrint_WithExcelFormat() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                       // Arrange
                                                       org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.EXCEL;
                                                       java.io.StringWriter writer = new java.io.StringWriter();
                                                       
                                                       // Act
                                                       org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                       
                                                       // Assert
                                                       org.junit.Assert.assertNotNull(printer);
                                                       
                                                       // Use reflection to access the private 'out' field
                                                       java.lang.reflect.Field outField = org.apache.commons.csv.CSVPrinter.class.getDeclaredField("out");
                                                       outField.setAccessible(true);
                                                       java.lang.Appendable actualOut = (java.lang.Appendable) outField.get(printer);
                                                       org.junit.Assert.assertSame(writer, actualOut);
                                                   }

 @Test
                                                   public void testValidate_NoEscapeCharWithQuoteModeNone() {
                                                       try {
                                                           org.apache.commons.csv.CSVFormat.newFormat(',')
                                                                .withQuoteMode(org.apache.commons.csv.QuoteMode.NONE)
                                                                .withEscape(null)
                                                                .withQuote(null);
                                                           fail("Expected IllegalArgumentException to be thrown");
                                                       } catch (IllegalArgumentException e) {
                                                           assertEquals("No quotes mode set but no escape character is set", e.getMessage());
                                                       }
                                                   }

 @Test
                                           public void testParse_WithNullString() throws IOException {
                                               // Arrange
                                               CSVFormat format = CSVFormat.newFormat(',').withNullString("NULL");
                                               String input = "name,age,city\nNULL,30,New York";
                                               java.io.Reader reader = new java.io.StringReader(input);
                                               
                                               // Act
                                               CSVParser parser = format.parse(reader);
                                               
                                               // Assert
                                               assertNotNull(parser);
                                           }

 @Test
                           public void testParse_WithSkipHeaderRecord() throws IOException {
                               // Arrange
                               org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                               String input = "name,age,city" + System.lineSeparator() + "John,30,New York";
                               java.io.Reader reader = new java.io.StringReader(input);
                               
                               // Act
                               org.apache.commons.csv.CSVParser parser = format.parse(reader);
                               
                               // Assert
                               assertNotNull(parser);
                               
                               // Verify header was skipped by checking first record is data, not header
                               java.util.List<org.apache.commons.csv.CSVRecord> records = parser.getRecords();
                               assertFalse(records.isEmpty());
                               assertEquals("John", records.get(0).get(0));
                               assertEquals("30", records.get(0).get(1));
                               assertEquals("New York", records.get(0).get(2));
                           }

 @Test
           public void testParse_WithCustomFormat() throws java.io.IOException {
               // Arrange
               org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(';')
                   .withQuote('"')
                   .withRecordSeparator("\r\n")
                   .withIgnoreEmptyLines(true);
               String input = "name;age;city\r\n\"John\";30;\"New York\"";
               java.io.Reader reader = new java.io.StringReader(input);
               
               // Act
               org.apache.commons.csv.CSVParser parser = format.parse(reader);
               
               // Assert
               org.junit.Assert.assertNotNull(parser);
               
               // Verify the parsed content
               java.util.List<org.apache.commons.csv.CSVRecord> records = parser.getRecords();
               org.junit.Assert.assertEquals(1, records.size());
               org.apache.commons.csv.CSVRecord record = records.get(0);
               org.junit.Assert.assertEquals("John", record.get(0));
               org.junit.Assert.assertEquals("30", record.get(1));
               org.junit.Assert.assertEquals("New York", record.get(2));
           }

 @Test
           public void testParse_WithQuotedFields() throws IOException {
               // Arrange
               CSVFormat format = CSVFormat.newFormat(',')
                       .withQuote('"')
                       .withIgnoreSurroundingSpaces(false)
                       .withIgnoreEmptyLines(false)
                       .withRecordSeparator("\n");
               String input = "\"name\",\"age\",\"city\"\n\"John\",\"30\",\"New York\"";
               
               // Act
               
               // Assert
           }

 @Test
           public void testParse_WithCommentMarker() throws IOException {
               // Arrange
               CSVFormat format = CSVFormat.newFormat(',')
                   .withCommentMarker('#')
                   .withIgnoreEmptyLines(false)
                   .withIgnoreSurroundingSpaces(false)
                   .withRecordSeparator("\n");
               String input = "# This is a comment\nname,age,city\nJohn,30,New York";
               
               // Act
               
               // Assert
               assertEquals(',', format.getDelimiter());
               assertEquals(Character.valueOf('#'), format.getCommentMarker());
               assertFalse(format.getIgnoreEmptyLines());
               assertFalse(format.getIgnoreSurroundingSpaces());
               assertEquals("\n", format.getRecordSeparator());
           }

 @Test
           public void testParse_WithEscapeCharacter() throws IOException {
               // Arrange
               CSVFormat format = CSVFormat.newFormat(',').withEscape('\\').withQuote('"');
               String input = "\"name\",\"age\",\"city\"\n\"John\\\\\\\\\\\\\\\\\\\\\\\"Doe\",\"30\",\"New York\"";
               
               // Act
               
               // Assert
           }

}
