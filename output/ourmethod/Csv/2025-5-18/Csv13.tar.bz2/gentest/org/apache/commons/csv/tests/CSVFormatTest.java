package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testNewFormat_WithStandardDelimiter() {
                                                                                            // Test with comma delimiter (common case)
                                                                                            char delimiter = ',';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            assertNull(format.getQuoteMode());
                                                                                            assertNull(format.getCommentMarker());
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                            assertNull(format.getRecordSeparator());
                                                                                            assertNull(format.getNullString());
                                                                                            assertNull(format.getHeader());
                                                                                            assertNull(format.getHeaderComments());
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testNewFormat_WithTabDelimiter() {
                                                                                            // Test with tab delimiter (another common case)
                                                                                            char delimiter = '\t';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            assertNull(format.getQuoteMode());
                                                                                            assertNull(format.getCommentMarker());
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                            assertNull(format.getRecordSeparator());
                                                                                            assertNull(format.getNullString());
                                                                                            assertNull(format.getHeader());
                                                                                            assertNull(format.getHeaderComments());
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testNewFormat_WithPipeDelimiter() {
                                                                                            // Test with pipe delimiter (less common case)
                                                                                            char delimiter = '|';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            assertNull(format.getQuoteMode());
                                                                                            assertNull(format.getCommentMarker());
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                            assertNull(format.getRecordSeparator());
                                                                                            assertNull(format.getNullString());
                                                                                            assertNull(format.getHeader());
                                                                                            assertNull(format.getHeaderComments());
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testNewFormat_WithNonPrintableDelimiter() {
                                                                                            // Test with non-printable character as delimiter
                                                                                            char delimiter = '\u0001';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            assertNull(format.getQuoteMode());
                                                                                            assertNull(format.getCommentMarker());
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                            assertNull(format.getRecordSeparator());
                                                                                            assertNull(format.getNullString());
                                                                                            assertNull(format.getHeader());
                                                                                            assertNull(format.getHeaderComments());
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testNewFormat_WithSpaceDelimiter() {
                                                                                            // Test with space as delimiter (edge case)
                                                                                            char delimiter = ' ';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            assertEquals(delimiter, format.getDelimiter());
                                                                                            assertNull(format.getQuoteCharacter());
                                                                                            assertNull(format.getQuoteMode());
                                                                                            assertNull(format.getCommentMarker());
                                                                                            assertNull(format.getEscapeCharacter());
                                                                                            assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                            assertNull(format.getRecordSeparator());
                                                                                            assertNull(format.getNullString());
                                                                                            assertNull(format.getHeader());
                                                                                            assertNull(format.getHeaderComments());
                                                                                            assertFalse(format.getSkipHeaderRecord());
                                                                                            assertFalse(format.getAllowMissingColumnNames());
                                                                                            assertFalse(format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testNewFormat_EqualsAndHashCode() {
                                                                                            // Test that two instances with same delimiter are equal
                                                                                            char delimiter1 = ';';
                                                                                            char delimiter2 = ';';
                                                                                            
                                                                                            CSVFormat format1 = CSVFormat.newFormat(delimiter1);
                                                                                            CSVFormat format2 = CSVFormat.newFormat(delimiter2);
                                                                                            
                                                                                            assertEquals(format1, format2);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testNewFormat_NotEquals() {
                                                                                            // Test that two instances with different delimiters are not equal
                                                                                            char delimiter1 = ',';
                                                                                            char delimiter2 = ';';
                                                                                            
                                                                                            CSVFormat format1 = CSVFormat.newFormat(delimiter1);
                                                                                            CSVFormat format2 = CSVFormat.newFormat(delimiter2);
                                                                                            
                                                                                            assertNotEquals(format1, format2);
                                                                                        }

    @Test
                                                                                        public void testNewFormat_ToString() {
                                                                                            // Test toString method contains the delimiter
                                                                                            char delimiter = '~';
                                                                                            CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                            
                                                                                            String toString = format.toString();
                                                                                            assertTrue(toString.contains("delimiter=" + delimiter));
                                                                                        }

    @Test
                                                                                        public void testValueOf_AllPredefinedFormats() {
                                                                                            // Test all predefined formats
                                                                                            assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.valueOf("DEFAULT").getFormat());
                                                                                            assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.valueOf("RFC4180").getFormat());
                                                                                            assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.valueOf("EXCEL").getFormat());
                                                                                            assertEquals(CSVFormat.TDF, CSVFormat.Predefined.valueOf("TDF").getFormat());
                                                                                            assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.valueOf("MYSQL").getFormat());
                                                                                        }

    @Test
                                                                                        public void testValueOf_CaseInsensitive() {
                                                                                            // Test case insensitivity (assuming implementation is case-insensitive)
                                                                                            assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.valueOf("default").getFormat());
                                                                                            assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.valueOf("rfc4180").getFormat());
                                                                                            assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.valueOf("excel").getFormat());
                                                                                        }

    @Test
                                                                                        public void testValueOf_InvalidFormat() {
                                                                                            // Test with invalid format name
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("No enum constant");
                                                                                            CSVFormat.Predefined.valueOf("INVALID_FORMAT").getFormat();
                                                                                        }

    @Test
                                                                                        public void testValueOf_NullInput() {
                                                                                            // Test with null input
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            CSVFormat.Predefined.valueOf(null).getFormat();
                                                                                        }

    @Test
                                                                                        public void testValueOf_EmptyString() {
                                                                                            // Test with empty string
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("No enum constant");
                                                                                            CSVFormat.Predefined.valueOf("").getFormat();
                                                                                        }

    @Test
                                                                                        public void testValueOf_WhitespaceString() {
                                                                                            // Test with whitespace string
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("No enum constant");
                                                                                            CSVFormat.Predefined.valueOf("   ").getFormat();
                                                                                        }

    @Test
                                                                                        public void testEquals_Reflexive() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertTrue(format.equals(format));
                                                                                        }

    @Test
                                                                                        public void testEquals_Symmetric() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT;
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT;
                                                                                            assertTrue(format1.equals(format2));
                                                                                            assertTrue(format2.equals(format1));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullComparison() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse(format.equals(null));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentClass() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse(format.equals("Not a CSVFormat object"));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentDelimiter() {
                                                                                            CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                            CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentQuoteCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote('"');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('\'');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullQuoteCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote('"');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_BothNullQuoteCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuote(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuote(null);
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentQuoteMode() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentCommentMarker() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('!');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullCommentMarker() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker('#');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_BothNullCommentMarker() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentEscapeCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('/');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullEscapeCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_BothNullEscapeCharacter() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withEscape(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withEscape(null);
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentNullString() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString("null");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullNullString() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_BothNullNullString() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withNullString(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withNullString(null);
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentHeader() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader("col1", "col2");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("col1", "col3");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullHeader() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader("col1", "col2");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_BothNullHeader() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader((String[]) null);
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentIgnoreSurroundingSpaces() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentIgnoreEmptyLines() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentSkipHeaderRecord() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_DifferentRecordSeparator() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_NullRecordSeparator() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            assertFalse(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_BothNullRecordSeparator() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator(null);
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testEquals_AllFieldsEqual() {
                                                                                            CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withSkipHeaderRecord(true);
                                                                                    
                                                                                            CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withSkipHeaderRecord(true);
                                                                                    
                                                                                            assertTrue(format1.equals(format2));
                                                                                        }

    @Test
                                                                                        public void testFormat_SimpleValues() {
                                                                                            // Test with basic values
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Object[] values = {"value1", "value2", "value3"};
                                                                                            String expected = "value1,value2,value3";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_EmptyValues() {
                                                                                            // Test with empty array
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Object[] values = {};
                                                                                            String expected = "";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_NullValues() {
                                                                                            // Test with null values in array
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                            Object[] values = {"value1", null, "value3"};
                                                                                            String expected = "value1,NULL,value3";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithQuotes() {
                                                                                            // Test with values that need quoting
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                            Object[] values = {"value,1", "value\"2", "value3"};
                                                                                            String expected = "\"value,1\",\"value\"\"2\",value3";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithCustomDelimiter() {
                                                                                            // Test with custom delimiter
                                                                                            CSVFormat format = CSVFormat.newFormat(';');
                                                                                            Object[] values = {"value1", "value2", "value3"};
                                                                                            String expected = "value1;value2;value3";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithRecordSeparator() {
                                                                                            // Test with record separator
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                            Object[] values = {"value1", "value2", "value3"};
                                                                                            String expected = "value1,value2,value3";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithDifferentTypes() {
                                                                                            // Test with different value types
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Object[] values = {1, 2.5, true, "string"};
                                                                                            String expected = "1,2.5,true,string";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithEmptyStrings() {
                                                                                            // Test with empty strings
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Object[] values = {"", "", ""};
                                                                                            String expected = ",,";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithSpaces() {
                                                                                            // Test with spaces in values
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            Object[] values = {" value1 ", " value2 ", " value3 "};
                                                                                            String expected = " value1 , value2 , value3 ";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testFormat_WithSpecialCharacters() {
                                                                                            // Test with special characters
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            Object[] values = {"valüe1", "价值2", "😊"};
                                                                                            String expected = "valüe1,价值2,😊";
                                                                                            assertEquals(expected, format.format(values));
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarker_UsingDefaultFormat() {
                                                                                            // Arrange - Using the DEFAULT static instance
                                                                                            CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                    
                                                                                            // Act
                                                                                            Character commentMarker = defaultFormat.getCommentMarker();
                                                                                    
                                                                                            // Assert
                                                                                            assertNull(commentMarker); // DEFAULT format typically has no comment marker
                                                                                        }

    @Test
                                                                                        public void testGetCommentMarker_UsingExcelFormat() {
                                                                                            // Arrange - Using the EXCEL static instance
                                                                                            CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                    
                                                                                            // Act
                                                                                            Character commentMarker = excelFormat.getCommentMarker();
                                                                                    
                                                                                            // Assert
                                                                                            assertNull(commentMarker); // EXCEL format typically has no comment marker
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_DefaultFormat() {
                                                                                            // Test with DEFAULT format (comma delimiter)
                                                                                            assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_ExcelFormat() {
                                                                                            // Test with EXCEL format (comma delimiter)
                                                                                            assertEquals(',', CSVFormat.EXCEL.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_TabDelimitedFormat() {
                                                                                            // Test with TDF format (tab delimiter)
                                                                                            assertEquals('\t', CSVFormat.TDF.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_MySQLFormat() {
                                                                                            // Test with MYSQL format (tab delimiter)
                                                                                            assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_RFC4180Format() {
                                                                                            // Test with RFC4180 format (comma delimiter)
                                                                                            assertEquals(',', CSVFormat.RFC4180.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_CustomFormat() {
                                                                                            // Test with custom delimiter
                                                                                            char customDelimiter = '|';
                                                                                            CSVFormat customFormat = CSVFormat.newFormat(customDelimiter);
                                                                                            assertEquals(customDelimiter, customFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_WithDifferentDelimiters() {
                                                                                            // Test various delimiter characters
                                                                                            char[] delimiters = {';', ':', ' ', '\0', 'a', '1', '~'};
                                                                                            
                                                                                            for (char delimiter : delimiters) {
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                assertEquals(delimiter, format.getDelimiter());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testGetDelimiter_AfterWithDelimiterModification() {
                                                                                            // Test that withDelimiter creates a new instance with the correct delimiter
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char newDelimiter = ';';
                                                                                            CSVFormat modified = original.withDelimiter(newDelimiter);
                                                                                            
                                                                                            assertEquals(newDelimiter, modified.getDelimiter());
                                                                                            // Original should remain unchanged
                                                                                            assertEquals(',', original.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacter_UsingDefaultFormat() {
                                                                                            // Arrange - Using the DEFAULT static instance
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                    
                                                                                            // Act
                                                                                            Character actualEscape = format.getEscapeCharacter();
                                                                                    
                                                                                            // Assert - Verify DEFAULT format has null escape character
                                                                                            assertNull(actualEscape);
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacter_UsingRFC4180Format() {
                                                                                            // Arrange - Using the RFC4180 static instance
                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                    
                                                                                            // Act
                                                                                            Character actualEscape = format.getEscapeCharacter();
                                                                                    
                                                                                            // Assert - Verify RFC4180 format has null escape character
                                                                                            assertNull(actualEscape);
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacter_UsingExcelFormat() {
                                                                                            // Arrange - Using the EXCEL static instance
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                    
                                                                                            // Act
                                                                                            Character actualEscape = format.getEscapeCharacter();
                                                                                    
                                                                                            // Assert - Verify EXCEL format has null escape character
                                                                                            assertNull(actualEscape);
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacter_UsingTDFFormat() {
                                                                                            // Arrange - Using the TDF static instance
                                                                                            CSVFormat format = CSVFormat.TDF;
                                                                                    
                                                                                            // Act
                                                                                            Character actualEscape = format.getEscapeCharacter();
                                                                                    
                                                                                            // Assert - Verify TDF format has null escape character
                                                                                            assertNull(actualEscape);
                                                                                        }

    @Test
                                                                                        public void testGetEscapeCharacter_UsingMySQLFormat() {
                                                                                            // Arrange - Using the MYSQL static instance
                                                                                            CSVFormat format = CSVFormat.MYSQL;
                                                                                    
                                                                                            // Act
                                                                                            Character actualEscape = format.getEscapeCharacter();
                                                                                    
                                                                                            // Assert - Verify MYSQL format has escape character set to backslash
                                                                                            assertEquals(Character.valueOf('\\'), actualEscape);
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNames_DefaultFormat() {
                                                                                            // Test the DEFAULT static instance
                                                                                            assertFalse("DEFAULT format should have allowMissingColumnNames set to false", 
                                                                                                CSVFormat.DEFAULT.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNames_RFC4180Format() {
                                                                                            // Test the RFC4180 static instance
                                                                                            assertFalse("RFC4180 format should have allowMissingColumnNames set to false", 
                                                                                                CSVFormat.RFC4180.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNames_ExcelFormat() {
                                                                                            // Test the EXCEL static instance
                                                                                            assertFalse("EXCEL format should have allowMissingColumnNames set to false", 
                                                                                                CSVFormat.EXCEL.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNames_TabDelimitedFormat() {
                                                                                            // Test the TDF static instance
                                                                                            assertFalse("TDF format should have allowMissingColumnNames set to false", 
                                                                                                CSVFormat.TDF.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetAllowMissingColumnNames_MySQLFormat() {
                                                                                            // Test the MYSQL static instance
                                                                                            assertFalse("MYSQL format should have allowMissingColumnNames set to false", 
                                                                                                CSVFormat.MYSQL.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_DefaultFormat() {
                                                                                            // Test with DEFAULT format (should have ignoreEmptyLines = false)
                                                                                            assertFalse(CSVFormat.DEFAULT.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_RFC4180Format() {
                                                                                            // Test with RFC4180 format (should have ignoreEmptyLines = false)
                                                                                            assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_ExcelFormat() {
                                                                                            // Test with EXCEL format (should have ignoreEmptyLines = false)
                                                                                            assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_TabDelimitedFormat() {
                                                                                            // Test with TDF format (should have ignoreEmptyLines = false)
                                                                                            assertFalse(CSVFormat.TDF.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_MySQLFormat() {
                                                                                            // Test with MYSQL format (should have ignoreEmptyLines = false)
                                                                                            assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_WithIgnoreEmptyLinesTrue() {
                                                                                            // Create a custom format with ignoreEmptyLines = true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_WithIgnoreEmptyLinesFalse() {
                                                                                            // Create a custom format with ignoreEmptyLines = false
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
                                                                                            assertFalse(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreEmptyLines_AfterModification() {
                                                                                            // Test that the value doesn't change after format modifications
                                                                                            CSVFormat format = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withIgnoreEmptyLines(true);
                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                    
                                                                                            // Modify again and verify
                                                                                            CSVFormat modifiedFormat = format.withIgnoreEmptyLines(false);
                                                                                            assertFalse(modifiedFormat.getIgnoreEmptyLines());
                                                                                            // Original format should remain unchanged
                                                                                            assertTrue(format.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpaces_DefaultFormat() {
                                                                                            // Default format should have ignoreSurroundingSpaces set to false
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse("DEFAULT format should have ignoreSurroundingSpaces=false", 
                                                                                                       format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpaces_ExcelFormat() {
                                                                                            // EXCEL format should have ignoreSurroundingSpaces set to false
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                            assertFalse("EXCEL format should have ignoreSurroundingSpaces=false", 
                                                                                                       format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpaces_RFC4180Format() {
                                                                                            // RFC4180 format should have ignoreSurroundingSpaces set to false
                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                            assertFalse("RFC4180 format should have ignoreSurroundingSpaces=false", 
                                                                                                       format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpaces_WhenTrue() {
                                                                                            // Create a custom format with ignoreSurroundingSpaces=true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            assertTrue("Custom format with ignoreSurroundingSpaces=true should return true", 
                                                                                                     format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpaces_WhenFalse() {
                                                                                            // Create a custom format with ignoreSurroundingSpaces=false
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false);
                                                                                            assertFalse("Custom format with ignoreSurroundingSpaces=false should return false", 
                                                                                                      format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreSurroundingSpaces_AfterModification() {
                                                                                            // Test that modifying the value through withIgnoreSurroundingSpaces works
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse("Initial value should be false", format.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            CSVFormat modifiedFormat = format.withIgnoreSurroundingSpaces(true);
                                                                                            assertTrue("Modified format should have ignoreSurroundingSpaces=true", 
                                                                                                     modifiedFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Original format should remain unchanged
                                                                                            assertFalse("Original format should remain unchanged", 
                                                                                                      format.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreHeaderCase_DefaultFormat() {
                                                                                            // Test with DEFAULT format (should be false by default)
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            assertFalse("DEFAULT format should have ignoreHeaderCase false", 
                                                                                                       format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreHeaderCase_ExcelFormat() {
                                                                                            // Test with EXCEL format (should be false by default)
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                            assertFalse("EXCEL format should have ignoreHeaderCase false", 
                                                                                                       format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreHeaderCase_RFC4180Format() {
                                                                                            // Test with RFC4180 format (should be false by default)
                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                            assertFalse("RFC4180 format should have ignoreHeaderCase false", 
                                                                                                       format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreHeaderCase_WithIgnoreHeaderCaseTrue() {
                                                                                            // Test with custom format where ignoreHeaderCase is true
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                            assertTrue("Format with ignoreHeaderCase set to true should return true", 
                                                                                                      format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreHeaderCase_WithIgnoreHeaderCaseFalse() {
                                                                                            // Test with custom format where ignoreHeaderCase is explicitly false
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
                                                                                            assertFalse("Format with ignoreHeaderCase set to false should return false", 
                                                                                                       format.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testGetIgnoreHeaderCase_AfterModification() {
                                                                                            // Test that modifying a copy doesn't affect the original
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                            
                                                                                            assertFalse("Original format should remain unchanged", 
                                                                                                       original.getIgnoreHeaderCase());
                                                                                            assertTrue("Modified format should have new value", 
                                                                                                      modified.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testGetNullString_UsingDefaultFormat() {
                                                                                            // Test with DEFAULT format which should have nullString as null
                                                                                            assertEquals(null, CSVFormat.DEFAULT.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullString_UsingExcelFormat() {
                                                                                            // Test with EXCEL format which should have nullString as null
                                                                                            assertEquals(null, CSVFormat.EXCEL.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullString_UsingRFC4180Format() {
                                                                                            // Test with RFC4180 format which should have nullString as null
                                                                                            assertEquals(null, CSVFormat.RFC4180.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullString_UsingTDFFormat() {
                                                                                            // Test with TDF format which should have nullString as null
                                                                                            assertEquals(null, CSVFormat.TDF.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullString_UsingMySQLFormat() {
                                                                                            // Test with MYSQL format which should have nullString as "\\N"
                                                                                            assertEquals("\\N", CSVFormat.MYSQL.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetNullString_AfterWithNullStringModification() {
                                                                                            // Create a format and then modify it with withNullString
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withNullString("NA");
                                                                                            
                                                                                            assertEquals("NA", modified.getNullString());
                                                                                            // Original should remain unchanged
                                                                                            assertNull(original.getNullString());
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacter_WhenUsingDefaultFormat() {
                                                                                            // Arrange
                                                                                            Character expectedQuote = CSVFormat.DEFAULT.getQuoteCharacter();
                                                                                            
                                                                                            // Act
                                                                                            Character actualQuote = CSVFormat.DEFAULT.getQuoteCharacter();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals(expectedQuote, actualQuote);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacter_WhenUsingRFC4180Format() {
                                                                                            // Arrange
                                                                                            Character expectedQuote = CSVFormat.RFC4180.getQuoteCharacter();
                                                                                            
                                                                                            // Act
                                                                                            Character actualQuote = CSVFormat.RFC4180.getQuoteCharacter();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals(expectedQuote, actualQuote);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacter_WhenUsingExcelFormat() {
                                                                                            // Arrange
                                                                                            Character expectedQuote = CSVFormat.EXCEL.getQuoteCharacter();
                                                                                            
                                                                                            // Act
                                                                                            Character actualQuote = CSVFormat.EXCEL.getQuoteCharacter();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals(expectedQuote, actualQuote);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacter_WhenUsingTDFFormat() {
                                                                                            // Arrange
                                                                                            Character expectedQuote = CSVFormat.TDF.getQuoteCharacter();
                                                                                            
                                                                                            // Act
                                                                                            Character actualQuote = CSVFormat.TDF.getQuoteCharacter();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals(expectedQuote, actualQuote);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteCharacter_WhenUsingMySQLFormat() {
                                                                                            // Arrange
                                                                                            Character expectedQuote = CSVFormat.MYSQL.getQuoteCharacter();
                                                                                            
                                                                                            // Act
                                                                                            Character actualQuote = CSVFormat.MYSQL.getQuoteCharacter();
                                                                                            
                                                                                            // Assert
                                                                                            assertEquals(expectedQuote, actualQuote);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteMode_OnDefaultInstance() {
                                                                                            // Arrange & Act
                                                                                            QuoteMode mode = CSVFormat.DEFAULT.getQuoteMode();
                                                                                    
                                                                                            // Assert
                                                                                            assertNotNull("Default instance should have non-null quote mode", mode);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteMode_OnRFC4180Instance() {
                                                                                            // Arrange & Act
                                                                                            QuoteMode mode = CSVFormat.RFC4180.getQuoteMode();
                                                                                    
                                                                                            // Assert
                                                                                            assertNotNull("RFC4180 instance should have non-null quote mode", mode);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteMode_OnExcelInstance() {
                                                                                            // Arrange & Act
                                                                                            QuoteMode mode = CSVFormat.EXCEL.getQuoteMode();
                                                                                    
                                                                                            // Assert
                                                                                            assertNotNull("EXCEL instance should have non-null quote mode", mode);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteMode_OnTDFInstance() {
                                                                                            // Arrange & Act
                                                                                            QuoteMode mode = CSVFormat.TDF.getQuoteMode();
                                                                                    
                                                                                            // Assert
                                                                                            assertNotNull("TDF instance should have non-null quote mode", mode);
                                                                                        }

    @Test
                                                                                        public void testGetQuoteMode_OnMySQLInstance() {
                                                                                            // Arrange & Act
                                                                                            QuoteMode mode = CSVFormat.MYSQL.getQuoteMode();
                                                                                    
                                                                                            // Assert
                                                                                            assertNotNull("MYSQL instance should have non-null quote mode", mode);
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_DefaultFormat() {
                                                                                            // Test with default format (should be system line separator)
                                                                                            String expected = System.lineSeparator();
                                                                                            assertEquals(expected, CSVFormat.DEFAULT.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_ExcelFormat() {
                                                                                            // Test with Excel format (should be CRLF)
                                                                                            assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_RFC4180Format() {
                                                                                            // Test with RFC4180 format (should be CRLF)
                                                                                            assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_TabDelimitedFormat() {
                                                                                            // Test with TDF format (should be system line separator)
                                                                                            String expected = System.lineSeparator();
                                                                                            assertEquals(expected, CSVFormat.TDF.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_MySQLFormat() {
                                                                                            // Test with MySQL format (should be system line separator)
                                                                                            String expected = System.lineSeparator();
                                                                                            assertEquals(expected, CSVFormat.MYSQL.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_CustomSeparator() {
                                                                                            // Test with custom record separator
                                                                                            String customSeparator = "|||";
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator(customSeparator);
                                                                                            assertEquals(customSeparator, format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_NullSeparator() {
                                                                                            // Test with null record separator (should return null)
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator((String) null);
                                                                                            assertNull(format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_EmptyStringSeparator() {
                                                                                            // Test with empty string as separator
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("");
                                                                                            assertEquals("", format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_CharSeparator() {
                                                                                            // Test with character record separator (converted to String)
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
                                                                                            assertEquals("\n", format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetRecordSeparator_UnicodeSeparator() {
                                                                                            // Test with Unicode separator
                                                                                            String unicodeSeparator = "\u2029"; // Paragraph separator
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator(unicodeSeparator);
                                                                                            assertEquals(unicodeSeparator, format.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecord_DefaultFormat() {
                                                                                            // Test with the DEFAULT static instance
                                                                                            assertFalse("DEFAULT format should have skipHeaderRecord as false",
                                                                                                       CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecord_RFC4180Format() {
                                                                                            // Test with the RFC4180 static instance
                                                                                            assertFalse("RFC4180 format should have skipHeaderRecord as false",
                                                                                                       CSVFormat.RFC4180.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecord_ExcelFormat() {
                                                                                            // Test with the EXCEL static instance
                                                                                            assertFalse("EXCEL format should have skipHeaderRecord as false",
                                                                                                       CSVFormat.EXCEL.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecord_TabDelimitedFormat() {
                                                                                            // Test with the TDF (Tab Delimited) static instance
                                                                                            assertFalse("TDF format should have skipHeaderRecord as false",
                                                                                                       CSVFormat.TDF.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testGetSkipHeaderRecord_MySQLFormat() {
                                                                                            // Test with the MYSQL static instance
                                                                                            assertFalse("MYSQL format should have skipHeaderRecord as false",
                                                                                                       CSVFormat.MYSQL.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testHashCode_DefaultFormat() {
                                                                                            // Test with default values (most fields null or default)
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            int expectedHash = 31 * (31 + format.getDelimiter());
                                                                                            expectedHash = 31 * expectedHash + (format.getQuoteMode() == null ? 0 : format.getQuoteMode().hashCode());
                                                                                            expectedHash = 31 * expectedHash + (format.getQuoteCharacter() == null ? 0 : format.getQuoteCharacter().hashCode());
                                                                                            expectedHash = 31 * expectedHash + (format.getCommentMarker() == null ? 0 : format.getCommentMarker().hashCode());
                                                                                            expectedHash = 31 * expectedHash + (format.getEscapeCharacter() == null ? 0 : format.getEscapeCharacter().hashCode());
                                                                                            expectedHash = 31 * expectedHash + (format.getNullString() == null ? 0 : format.getNullString().hashCode());
                                                                                            expectedHash = 31 * expectedHash + (format.getIgnoreSurroundingSpaces() ? 1231 : 1237);
                                                                                            expectedHash = 31 * expectedHash + (format.getIgnoreHeaderCase() ? 1231 : 1237);
                                                                                            expectedHash = 31 * expectedHash + (format.getIgnoreEmptyLines() ? 1231 : 1237);
                                                                                            expectedHash = 31 * expectedHash + (format.getSkipHeaderRecord() ? 1231 : 1237);
                                                                                            expectedHash = 31 * expectedHash + (format.getRecordSeparator() == null ? 0 : format.getRecordSeparator().hashCode());
                                                                                            expectedHash = 31 * expectedHash + (format.getHeader() == null ? 0 : Arrays.hashCode(format.getHeader()));
                                                                                            
                                                                                            assertEquals(expectedHash, format.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCode_HeaderVariations() {
                                                                                            // Test different header configurations
                                                                                            String[] header1 = {"col1", "col2"};
                                                                                            String[] header2 = {"COL1", "COL2"};
                                                                                            String[] header3 = {"col1", "col2", "col3"};
                                                                                            
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withHeader(header1);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withHeader(header2);
                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withHeader(header3);
                                                                                            CSVFormat format4 = CSVFormat.DEFAULT.withHeader((String[])null);
                                                                                            
                                                                                            assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                            assertNotEquals(format1.hashCode(), format4.hashCode());
                                                                                            assertNotEquals(format3.hashCode(), format4.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCode_BooleanFieldsVariations() {
                                                                                            // Test different combinations of boolean fields
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreHeaderCase(false)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withSkipHeaderRecord(false);
                                                                                                
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreHeaderCase(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withSkipHeaderRecord(true);
                                                                                                
                                                                                            assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCode_Consistency() {
                                                                                            // Test that hash code is consistent for same object
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                            int firstHash = format.hashCode();
                                                                                            assertEquals(firstHash, format.hashCode());
                                                                                            assertEquals(firstHash, format.hashCode());
                                                                                        }

    @Test
                                                                                        public void testHashCode_EqualsObjectsHaveSameHashCode() {
                                                                                            // Test that equal objects have same hash code
                                                                                            CSVFormat format1 = CSVFormat.newFormat(',').withQuote('"');
                                                                                            CSVFormat format2 = CSVFormat.newFormat(',').withQuote('"');
                                                                                            
                                                                                            assertEquals(format1, format2);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet_AfterModificationWithWithCommentMarker() {
                                                                                            // Start with null comment marker
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            assertFalse("Initial state should have no comment marker", 
                                                                                                       format.isCommentMarkerSet());
                                                                                            
                                                                                            // Set comment marker
                                                                                            format = format.withCommentMarker('#');
                                                                                            assertTrue("Should return true after setting comment marker", 
                                                                                                     format.isCommentMarkerSet());
                                                                                            
                                                                                            // Remove comment marker
                                                                                            format = format.withCommentMarker(null);
                                                                                            assertFalse("Should return false after removing comment marker", 
                                                                                                       format.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet_OnDefaultFormat() {
                                                                                            // Test on the DEFAULT format instance
                                                                                            assertFalse("DEFAULT format should have no comment marker by default", 
                                                                                                       CSVFormat.DEFAULT.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet_OnRFC4180Format() {
                                                                                            // Test on the RFC4180 format instance
                                                                                            assertFalse("RFC4180 format should have no comment marker by default", 
                                                                                                       CSVFormat.RFC4180.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet_OnEXCELFormat() {
                                                                                            // Test on the EXCEL format instance
                                                                                            assertFalse("EXCEL format should have no comment marker by default", 
                                                                                                       CSVFormat.EXCEL.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet_OnTDFFormat() {
                                                                                            // Test on the TDF format instance
                                                                                            assertFalse("TDF format should have no comment marker by default", 
                                                                                                       CSVFormat.TDF.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsCommentMarkerSet_OnMYSQLFormat() {
                                                                                            // Test on the MYSQL format instance
                                                                                            assertFalse("MYSQL format should have no comment marker by default", 
                                                                                                       CSVFormat.MYSQL.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testIsEscapeCharacterSet_UsingPredefinedFormats() {
                                                                                            // Test with DEFAULT format (which typically has escape character set)
                                                                                            assertTrue("DEFAULT format should have escape character set", 
                                                                                                      CSVFormat.DEFAULT.isEscapeCharacterSet());
                                                                                            
                                                                                            // Test with RFC4180 format (which typically has escape character set)
                                                                                            assertTrue("RFC4180 format should have escape character set", 
                                                                                                      CSVFormat.RFC4180.isEscapeCharacterSet());
                                                                                            
                                                                                            // Test with EXCEL format (which typically has escape character set)
                                                                                            assertTrue("EXCEL format should have escape character set", 
                                                                                                      CSVFormat.EXCEL.isEscapeCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSet_WithDefaultFormat() {
                                                                                            // Test with the DEFAULT static instance
                                                                                            assertFalse("DEFAULT format should have nullString not set", 
                                                                                                       CSVFormat.DEFAULT.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSet_WithExcelFormat() {
                                                                                            // Test with the EXCEL static instance
                                                                                            assertFalse("EXCEL format should have nullString not set", 
                                                                                                       CSVFormat.EXCEL.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSet_WithRFC4180Format() {
                                                                                            // Test with the RFC4180 static instance
                                                                                            assertFalse("RFC4180 format should have nullString not set", 
                                                                                                       CSVFormat.RFC4180.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsNullStringSet_AfterWithNullString() {
                                                                                            // Create a format and then modify it with withNullString
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withNullString("NULL");
                                                                                            
                                                                                            assertTrue("Should return true after setting nullString", 
                                                                                                      modified.isNullStringSet());
                                                                                        }

    @Test
                                                                                        public void testIsQuoteCharacterSet_UsingPredefinedFormats() {
                                                                                            // Test with DEFAULT format (which typically has a quote character)
                                                                                            assertTrue("DEFAULT format should have quote character set", 
                                                                                                      CSVFormat.DEFAULT.isQuoteCharacterSet());
                                                                                            
                                                                                            // Test with RFC4180 format (which typically has a quote character)
                                                                                            assertTrue("RFC4180 format should have quote character set", 
                                                                                                      CSVFormat.RFC4180.isQuoteCharacterSet());
                                                                                            
                                                                                            // Test with EXCEL format (which typically has a quote character)
                                                                                            assertTrue("EXCEL format should have quote character set", 
                                                                                                      CSVFormat.EXCEL.isQuoteCharacterSet());
                                                                                            
                                                                                            // Test with TDF format (which might not have a quote character)
                                                                                            // Note: Actual behavior depends on implementation, adjust as needed
                                                                                            assertTrue("TDF format should have quote character set", 
                                                                                                      CSVFormat.TDF.isQuoteCharacterSet());
                                                                                            
                                                                                            // Test with MYSQL format (which might not have a quote character)
                                                                                            // Note: Actual behavior depends on implementation, adjust as needed
                                                                                            assertTrue("MYSQL format should have quote character set", 
                                                                                                      CSVFormat.MYSQL.isQuoteCharacterSet());
                                                                                        }

    @Test
                                                                                        public void testParse_WithNullReader() throws IOException {
                                                                                            // Setup
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            thrown.expectMessage("in");
                                                                                            
                                                                                            // Execute
                                                                                            format.parse(null);
                                                                                        }

    @Test
                                                                                        public void testPrint_WithNullAppendable_ShouldThrowException() throws IOException {
                                                                                            // Arrange
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Parameter 'out' must not be null!");
                                                                                            
                                                                                            // Act
                                                                                            format.print(null);
                                                                                        }

    @Test
                                                                                        public void testToString_DefaultFormat() {
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            String expected = "Delimiter=<,> QuoteChar=<\"> EmptyLines:ignored SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_WithAllOptionalFieldsSet() {
                                                                                            CSVFormat format = CSVFormat.newFormat(';')
                                                                                                .withQuote('\'')
                                                                                                .withEscape('\\')
                                                                                                .withCommentMarker('#')
                                                                                                .withNullString("NULL")
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withIgnoreEmptyLines()
                                                                                                .withIgnoreSurroundingSpaces()
                                                                                                .withIgnoreHeaderCase()
                                                                                                .withSkipHeaderRecord()
                                                                                                .withHeaderComments("Comment1", "Comment2")
                                                                                                .withHeader("Col1", "Col2", "Col3");
                                                                                            
                                                                                            String expected = "Delimiter=<;> Escape=<\\> QuoteChar=<'> CommentStart=<#> " +
                                                                                                             "NullString=<NULL> RecordSeparator=<\r\n> EmptyLines:ignored " +
                                                                                                             "SurroundingSpaces:ignored IgnoreHeaderCase:ignored SkipHeaderRecord:true " +
                                                                                                             "HeaderComments:[Comment1, Comment2] Header:[Col1, Col2, Col3]";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_WithOnlyDelimiter() {
                                                                                            CSVFormat format = CSVFormat.newFormat('\t');
                                                                                            String expected = "Delimiter=<\t> SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_WithQuoteAndEscape() {
                                                                                            CSVFormat format = CSVFormat.newFormat('|')
                                                                                                .withQuote('"')
                                                                                                .withEscape('\\');
                                                                                            
                                                                                            String expected = "Delimiter=<|> Escape=<\\> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_WithNullStringAndRecordSeparator() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withNullString("N/A")
                                                                                                .withRecordSeparator("\n");
                                                                                            
                                                                                            String expected = "Delimiter=<,> NullString=<N/A> RecordSeparator=<\n> SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_WithHeaderAndComments() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withHeaderComments("File version 1.0")
                                                                                                .withHeader("Name", "Age", "City");
                                                                                            
                                                                                            String expected = "Delimiter=<,> SkipHeaderRecord:false " +
                                                                                                             "HeaderComments:[File version 1.0] Header:[Name, Age, City]";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_WithBooleanFlags() {
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withIgnoreEmptyLines()
                                                                                                .withIgnoreSurroundingSpaces()
                                                                                                .withIgnoreHeaderCase()
                                                                                                .withSkipHeaderRecord();
                                                                                            
                                                                                            String expected = "Delimiter=<,> EmptyLines:ignored SurroundingSpaces:ignored " +
                                                                                                             "IgnoreHeaderCase:ignored SkipHeaderRecord:true";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_RFC4180Format() {
                                                                                            CSVFormat format = CSVFormat.RFC4180;
                                                                                            String expected = "Delimiter=<,> QuoteChar=<\"> RecordSeparator=<\r\n> SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_ExcelFormat() {
                                                                                            CSVFormat format = CSVFormat.EXCEL;
                                                                                            String expected = "Delimiter=<,> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testToString_TabDelimitedFormat() {
                                                                                            CSVFormat format = CSVFormat.TDF;
                                                                                            String expected = "Delimiter=<\t> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                            assertEquals(expected, format.toString());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_NonNullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertTrue(newFormat.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_NullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNull(newFormat.getCommentMarker());
                                                                                            assertFalse(newFormat.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_SameCharacterReturnsSameInstance() {
                                                                                            // Setup
                                                                                            Character commentMarker = '#';
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertSame(originalFormat, newFormat);
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_DifferentCharacterCreatesNewInstance() {
                                                                                            // Setup
                                                                                            Character originalCommentMarker = '#';
                                                                                            Character newCommentMarker = '!';
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker(originalCommentMarker);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(newCommentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(newCommentMarker, newFormat.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_FromNullToNonNull() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker(null);
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertTrue(newFormat.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_FromNonNullToNull() {
                                                                                            // Setup
                                                                                            Character originalCommentMarker = '#';
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker(originalCommentMarker);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNull(newFormat.getCommentMarker());
                                                                                            assertFalse(newFormat.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_ValidCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(modified);
                                                                                            assertEquals(commentMarker, modified.getCommentMarker());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_NullValue() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withCommentMarker((Character) null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(modified);
                                                                                            assertNull(modified.getCommentMarker());
                                                                                            assertFalse(modified.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_LineBreakCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character lineBreak = '\n';
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                            
                                                                                            // Execute
                                                                                            original.withCommentMarker(lineBreak);
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_CarriageReturnCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character carriageReturn = '\r';
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                            
                                                                                            // Execute
                                                                                            original.withCommentMarker(carriageReturn);
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_FromNullToValid() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.newFormat(',').withCommentMarker(null);
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(commentMarker, modified.getCommentMarker());
                                                                                            assertTrue(modified.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_FromValidToNull() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.newFormat(',').withCommentMarker('#');
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withCommentMarker(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNull(modified.getCommentMarker());
                                                                                            assertFalse(modified.isCommentMarkerSet());
                                                                                        }

    @Test
                                                                                        public void testWithCommentMarker_VerifyImmutability() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character commentMarker = '#';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify immutability
                                                                                            assertNotSame(original, modified);
                                                                                            assertNull(original.getCommentMarker());
                                                                                            assertEquals(commentMarker, modified.getCommentMarker());
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter_LineBreakDelimiter() {
                                                                                            // Setup expectation for exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The delimiter cannot be a line break");
                                                                                    
                                                                                            // Create a basic format
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Try with line break delimiter (should throw exception)
                                                                                            format.withDelimiter('\n');
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter_NullCharacter() {
                                                                                            // Null character (ASCII 0) should be valid
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = original.withDelimiter('\0');
                                                                                            
                                                                                            assertEquals('\0', newFormat.getDelimiter());
                                                                                            // Verify other properties are preserved
                                                                                            assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithDelimiter_SpecialCharacters() {
                                                                                            // Test with various special characters that are not line breaks
                                                                                            char[] specialChars = {'\u0001', '\u007F', '\u00A0', '€'};
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            for (char c : specialChars) {
                                                                                                CSVFormat newFormat = original.withDelimiter(c);
                                                                                                assertEquals(c, newFormat.getDelimiter());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithEscape_NonNullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character escapeChar = '\\';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withEscape(escapeChar);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(modified);
                                                                                            assertEquals(escapeChar, modified.getEscapeCharacter());
                                                                                            assertTrue(modified.isEscapeCharacterSet());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_NullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withEscape(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(modified);
                                                                                            assertNull(modified.getEscapeCharacter());
                                                                                            assertFalse(modified.isEscapeCharacterSet());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_SameCharacterReturnsSameInstance() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withEscape('\\');
                                                                                            
                                                                                            // Verify
                                                                                            assertSame(original, modified);
                                                                                        }

    @Test
                                                                                        public void testWithEscape_DifferentCharacterReturnsNewInstance() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withEscape('/');
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(original, modified);
                                                                                            assertEquals(Character.valueOf('/'), modified.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_FromNullToNonNull() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withEscape(null);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withEscape('\\');
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(original, modified);
                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_FromNonNullToNull() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withEscape('\\');
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withEscape(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(original, modified);
                                                                                            assertNull(modified.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_InvalidEscapeCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character invalidEscape = '\n'; // line break character
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The escape character cannot be a line break");
                                                                                            
                                                                                            // Execute
                                                                                            original.withEscape(invalidEscape);
                                                                                        }

    @Test
                                                                                        public void testWithEscape_ValidCharacters() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            char backslash = '\\';
                                                                                            char pipe = '|';
                                                                                            char tab = '\t';
                                                                                            
                                                                                            // Test with char parameter
                                                                                            CSVFormat result1 = originalFormat.withEscape(backslash);
                                                                                            assertEquals(Character.valueOf(backslash), result1.getEscapeCharacter());
                                                                                            
                                                                                            // Test with Character parameter
                                                                                            CSVFormat result2 = originalFormat.withEscape(pipe);
                                                                                            assertEquals(Character.valueOf(pipe), result2.getEscapeCharacter());
                                                                                            
                                                                                            // Test with tab character
                                                                                            CSVFormat result3 = originalFormat.withEscape(tab);
                                                                                            assertEquals(Character.valueOf(tab), result3.getEscapeCharacter());
                                                                                            
                                                                                            // Test with null (should be allowed to unset escape character)
                                                                                            CSVFormat result4 = originalFormat.withEscape((Character)null);
                                                                                            assertNull(result4.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithEscape_LineBreakCharacters() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Expect exception for newline
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The escape character cannot be a line break");
                                                                                            originalFormat.withEscape('\n');
                                                                                        }

    @Test
                                                                                        public void testWithEscape_CarriageReturn() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Expect exception for carriage return
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The escape character cannot be a line break");
                                                                                            originalFormat.withEscape('\r');
                                                                                        }

    @Test
                                                                                        public void testWithEscape_ReturnsNewInstance() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Act
                                                                                            CSVFormat newFormat = originalFormat.withEscape('\\');
                                                                                            
                                                                                            // Assert
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNull(originalFormat.getEscapeCharacter());
                                                                                            assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithNullHeader() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader((String[]) null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNull(result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), result.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), result.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), result.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), result.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), result.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), result.getNullString());
                                                                                            assertArrayEquals(original.getHeaderComments(), result.getHeaderComments());
                                                                                            assertEquals(original.getSkipHeaderRecord(), result.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), result.getAllowMissingColumnNames());
                                                                                            assertEquals(original.getIgnoreHeaderCase(), result.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithEmptyHeader() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] emptyHeader = new String[0];
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(emptyHeader);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(emptyHeader, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithSingleHeader() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] singleHeader = {"Name"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(singleHeader);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(singleHeader, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithMultipleHeaders() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] multipleHeaders = {"Name", "Age", "Email"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(multipleHeaders);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(multipleHeaders, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithDuplicateHeaders() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] duplicateHeaders = {"Name", "Name", "Email"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(duplicateHeaders);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(duplicateHeaders, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithNullElementInHeader() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] headerWithNull = {"Name", null, "Email"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(headerWithNull);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(headerWithNull, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_VerifyHeaderIsCloned() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] originalHeader = {"Name", "Age"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(originalHeader);
                                                                                            
                                                                                            // Modify the original array
                                                                                            originalHeader[0] = "Modified";
                                                                                            
                                                                                            // Verify the header in the result wasn't affected
                                                                                            assertEquals("Name", result.getHeader()[0]);
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithSpecialCharacters() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] specialHeader = {"Name", "Age,", "\"Email\"", "Address\nLine"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(specialHeader);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(specialHeader, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithVeryLongHeader() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] longHeader = new String[1000];
                                                                                            for (int i = 0; i < longHeader.length; i++) {
                                                                                                longHeader[i] = "Header" + i;
                                                                                            }
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeader(longHeader);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(longHeader, result.getHeader());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeader_ResultSet_NonNullResultSet() throws Exception {
                                                                                            // Setup
                                                                                            ResultSet mockResultSet = mock(ResultSet.class);
                                                                                            ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);
                                                                                            when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
                                                                                            
                                                                                            // Create a sample CSVFormat instance
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat result = format.withHeader(mockResultSet);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNotSame(format, result); // Should return a new instance
                                                                                            verify(mockResultSet).getMetaData();
                                                                                        }

    @Test
                                                                                        public void testWithHeader_ResultSet_ResultSetThrowsException() throws Exception {
                                                                                            // Setup
                                                                                            ResultSet mockResultSet = mock(ResultSet.class);
                                                                                            when(mockResultSet.getMetaData()).thenThrow(new RuntimeException("Test exception"));
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(RuntimeException.class);
                                                                                            thrown.expectMessage("Test exception");
                                                                                            
                                                                                            // Test
                                                                                            format.withHeader(mockResultSet);
                                                                                        }

    @Test
                                                                                        public void testWithHeader_ResultSet_VerifyHeaderPropagation() throws Exception {
                                                                                            // Setup
                                                                                            ResultSet mockResultSet = mock(ResultSet.class);
                                                                                            ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);
                                                                                            when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
                                                                                            when(mockMetaData.getColumnCount()).thenReturn(2);
                                                                                            when(mockMetaData.getColumnLabel(1)).thenReturn("Column1");
                                                                                            when(mockMetaData.getColumnLabel(2)).thenReturn("Column2");
                                                                                            
                                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat result = format.withHeader(mockResultSet);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(new String[]{"Column1", "Column2"}, result.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_ResultSet_VerifyOtherPropertiesPreserved() throws Exception {
                                                                                            // Setup
                                                                                            ResultSet mockResultSet = mock(ResultSet.class);
                                                                                            ResultSetMetaData mockMetaData = mock(ResultSetMetaData.class);
                                                                                            when(mockResultSet.getMetaData()).thenReturn(mockMetaData);
                                                                                            
                                                                                            // Create format with non-default properties
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withIgnoreHeaderCase(true);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat result = originalFormat.withHeader(mockResultSet);
                                                                                            
                                                                                            // Verify original properties are preserved
                                                                                            assertEquals(';', result.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), result.getQuoteCharacter());
                                                                                            assertEquals("\r\n", result.getRecordSeparator());
                                                                                            assertEquals("NULL", result.getNullString());
                                                                                            assertTrue(result.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WhenMetaDataIsNull() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withHeader((ResultSetMetaData) null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNull(newFormat.getHeader());
                                                                                            assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            // Verify other properties are preserved
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithSingleColumn() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenReturn(1);
                                                                                            when(metaData.getColumnLabel(1)).thenReturn("id");
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withHeader(metaData);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(new String[]{"id"}, newFormat.getHeader());
                                                                                            assertEquals(1, newFormat.getHeader().length);
                                                                                            assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithMultipleColumns() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenReturn(3);
                                                                                            when(metaData.getColumnLabel(1)).thenReturn("id");
                                                                                            when(metaData.getColumnLabel(2)).thenReturn("name");
                                                                                            when(metaData.getColumnLabel(3)).thenReturn("age");
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withHeader(metaData);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(new String[]{"id", "name", "age"}, newFormat.getHeader());
                                                                                            assertEquals(3, newFormat.getHeader().length);
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithEmptyColumnLabels() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                            when(metaData.getColumnLabel(1)).thenReturn("");
                                                                                            when(metaData.getColumnLabel(2)).thenReturn("");
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withHeader(metaData);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(new String[]{"", ""}, newFormat.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WithNullColumnLabels() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenReturn(2);
                                                                                            when(metaData.getColumnLabel(1)).thenReturn(null);
                                                                                            when(metaData.getColumnLabel(2)).thenReturn(null);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withHeader(metaData);
                                                                                            
                                                                                            // Verify
                                                                                            assertArrayEquals(new String[]{null, null}, newFormat.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_PreservesOtherFormatSettings() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat('|')
                                                                                                .withQuote('"')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenReturn(1);
                                                                                            when(metaData.getColumnLabel(1)).thenReturn("test");
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withHeader(metaData);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals('|', newFormat.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                            assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                            assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertArrayEquals(new String[]{"test"}, newFormat.getHeader());
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WhenMetaDataThrowsException() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenThrow(new SQLException("Test exception"));
                                                                                            
                                                                                            thrown.expect(SQLException.class);
                                                                                            thrown.expectMessage("Test exception");
                                                                                            
                                                                                            // Execute
                                                                                            baseFormat.withHeader(metaData);
                                                                                        }

    @Test
                                                                                        public void testWithHeader_WhenColumnLabelThrowsException() throws Exception {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            ResultSetMetaData metaData = mock(ResultSetMetaData.class);
                                                                                            when(metaData.getColumnCount()).thenReturn(1);
                                                                                            when(metaData.getColumnLabel(1)).thenThrow(new SQLException("Label error"));
                                                                                            
                                                                                            thrown.expect(SQLException.class);
                                                                                            thrown.expectMessage("Label error");
                                                                                            
                                                                                            // Execute
                                                                                            baseFormat.withHeader(metaData);
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_NullInput() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeaderComments((Object[]) null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNull(result.getHeaderComments());
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), result.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), result.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), result.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), result.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), result.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), result.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), result.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), result.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), result.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), result.getAllowMissingColumnNames());
                                                                                            assertEquals(original.getIgnoreHeaderCase(), result.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_EmptyArray() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeaderComments(new Object[0]);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNotNull(result.getHeaderComments());
                                                                                            assertEquals(0, result.getHeaderComments().length);
                                                                                            assertEquals(original.getDelimiter(), result.getDelimiter());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_SingleString() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String comment = "Test Comment";
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeaderComments(comment);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNotNull(result.getHeaderComments());
                                                                                            assertEquals(1, result.getHeaderComments().length);
                                                                                            assertEquals(comment, result.getHeaderComments()[0]);
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_MultipleStrings() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] comments = {"Comment1", "Comment2", "Comment3"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeaderComments((Object[]) comments);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNotNull(result.getHeaderComments());
                                                                                            assertEquals(comments.length, result.getHeaderComments().length);
                                                                                            assertArrayEquals(comments, result.getHeaderComments());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_MixedObjects() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Object[] comments = {"String", 123, true};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeaderComments(comments);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNotNull(result.getHeaderComments());
                                                                                            assertEquals(comments.length, result.getHeaderComments().length);
                                                                                            assertEquals("String", result.getHeaderComments()[0]);
                                                                                            assertEquals("123", result.getHeaderComments()[1]);
                                                                                            assertEquals("true", result.getHeaderComments()[2]);
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_VerifyImmutability() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            String[] comments = {"Comment1", "Comment2"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result1 = original.withHeaderComments((Object[]) comments);
                                                                                            CSVFormat result2 = original.withHeaderComments((Object[]) comments);
                                                                                            
                                                                                            // Verify they are equal but not same instance
                                                                                            assertEquals(result1, result2);
                                                                                            assertNotSame(result1, result2);
                                                                                            
                                                                                            // Verify original remains unchanged
                                                                                            assertNull(original.getHeaderComments());
                                                                                        }

    @Test
                                                                                        public void testWithHeaderComments_WithExistingHeaderComments() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withHeaderComments("Existing");
                                                                                            String[] newComments = {"New1", "New2"};
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withHeaderComments((Object[]) newComments);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNotNull(result.getHeaderComments());
                                                                                            assertEquals(newComments.length, result.getHeaderComments().length);
                                                                                            assertArrayEquals(newComments, result.getHeaderComments());
                                                                                            // Other properties should remain the same as original
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames_NoParameter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames();
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames_True() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames_False() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames_Immutable() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            CSVFormat modifiedFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Execute - modify the original after creating new format
                                                                                            originalFormat.withDelimiter('|');
                                                                                            
                                                                                            // Verify that original format remains unchanged
                                                                                            assertEquals(',', originalFormat.getDelimiter());
                                                                                            assertFalse(originalFormat.getAllowMissingColumnNames());
                                                                                            // Verify modified format has the expected changes
                                                                                            assertTrue(modifiedFormat.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames_EqualsAndHashCode() {
                                                                                            // Setup
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withAllowMissingColumnNames(true);
                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(format1, format2);
                                                                                            assertNotEquals(format1, format3);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                        }

    @Test
                                                                                        public void testWithAllowMissingColumnNames_OriginalUnchanged() {
                                                                                            // Setup original CSVFormat
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat modified = original.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Verify original remains unchanged
                                                                                            assertFalse(original.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_Default() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreEmptyLines();
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_True() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(true);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_False() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(false);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_Chaining() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute & Verify
                                                                                            assertTrue(originalFormat.withIgnoreEmptyLines().getIgnoreEmptyLines());
                                                                                            assertTrue(originalFormat.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
                                                                                            assertFalse(originalFormat.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_Immutable() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreEmptyLines();
                                                                                            
                                                                                            // Verify immutability
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNotEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_True1() {
                                                                                            // Setup original format with default values
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("Name", "Age")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false)
                                                                                                .withIgnoreHeaderCase(false);
                                                                                    
                                                                                            // Call method under test
                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                    
                                                                                            // Verify new setting is applied
                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                            
                                                                                            // Verify all other properties remain unchanged
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_False1() {
                                                                                            // Setup original format with ignoreEmptyLines true
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withIgnoreEmptyLines(true);
                                                                                    
                                                                                            // Call method under test
                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(false);
                                                                                    
                                                                                            // Verify new setting is applied
                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_NoArg() {
                                                                                            // Setup original format with ignoreEmptyLines false
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withIgnoreEmptyLines(false);
                                                                                    
                                                                                            // Call method under test (no-arg version)
                                                                                            CSVFormat modified = original.withIgnoreEmptyLines();
                                                                                    
                                                                                            // Verify default true value is set
                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_Immutable1() {
                                                                                            // Verify that original format is not modified
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                            
                                                                                            assertNotSame(original, modified);
                                                                                            assertFalse(original.getIgnoreEmptyLines());
                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreEmptyLines_NullOriginal() {
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            thrown.expectMessage("original");
                                                                                            
                                                                                            CSVFormat original = null;
                                                                                            original.withIgnoreEmptyLines(true);
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_True() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat); // Should return a new instance
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_False() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(false);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat); // Should return a new instance
                                                                                            assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_DefaultInstance() {
                                                                                            // Verify that DEFAULT instance has ignoreSurroundingSpaces set to false
                                                                                            assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_NoParameter() {
                                                                                            // Test the no-parameter version which should default to true
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces();
                                                                                            
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_True1() {
                                                                                            // Setup initial format with default values
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                .withDelimiter(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("Name", "Age", "City")
                                                                                                .withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Apply withIgnoreSurroundingSpaces(true)
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Verify the new format has ignoreSurroundingSpaces set to true
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_False1() {
                                                                                            // Setup initial format with ignoreSurroundingSpaces true
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                .withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Apply withIgnoreSurroundingSpaces(false)
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(false);
                                                                                            
                                                                                            // Verify the new format has ignoreSurroundingSpaces set to false
                                                                                            assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Verify the original format remains unchanged
                                                                                            assertTrue(originalFormat.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_NoArg() {
                                                                                            // Setup initial format with ignoreSurroundingSpaces false
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                .withIgnoreSurroundingSpaces(false);
                                                                                            
                                                                                            // Apply withIgnoreSurroundingSpaces() (no-arg version)
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces();
                                                                                            
                                                                                            // Verify the new format has ignoreSurroundingSpaces set to true
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Verify the original format remains unchanged
                                                                                            assertFalse(originalFormat.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_Immutable() {
                                                                                            // Verify that the original format remains unchanged after modification
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            CSVFormat modifiedFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            assertNotSame(originalFormat, modifiedFormat);
                                                                                            assertFalse(originalFormat.getIgnoreSurroundingSpaces());
                                                                                            assertTrue(modifiedFormat.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_FromDefault() {
                                                                                            // Test starting from DEFAULT format
                                                                                            CSVFormat newFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(CSVFormat.DEFAULT.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_FromExcelFormat() {
                                                                                            // Test starting from EXCEL format
                                                                                            CSVFormat newFormat = CSVFormat.EXCEL.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(CSVFormat.EXCEL.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(CSVFormat.EXCEL.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_FromRFC4180Format() {
                                                                                            // Test starting from RFC4180 format
                                                                                            CSVFormat newFormat = CSVFormat.RFC4180.withIgnoreSurroundingSpaces(false);
                                                                                            
                                                                                            assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(CSVFormat.RFC4180.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(CSVFormat.RFC4180.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_True() {
                                                                                            // Create a base format with ignoreHeaderCase false
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
                                                                                            
                                                                                            // Call the method under test
                                                                                            CSVFormat newFormat = baseFormat.withIgnoreHeaderCase(true);
                                                                                            
                                                                                            // Verify the new format has ignoreHeaderCase set to true
                                                                                            assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                            
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(baseFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_False() {
                                                                                            // Create a base format with ignoreHeaderCase true
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT.withIgnoreHeaderCase(true);
                                                                                            
                                                                                            // Call the method under test
                                                                                            CSVFormat newFormat = baseFormat.withIgnoreHeaderCase(false);
                                                                                            
                                                                                            // Verify the new format has ignoreHeaderCase set to false
                                                                                            assertFalse(newFormat.getIgnoreHeaderCase());
                                                                                            
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(baseFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_Default() {
                                                                                            // Test the no-arg version which should default to true
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
                                                                                            
                                                                                            // Call the method under test
                                                                                            CSVFormat newFormat = baseFormat.withIgnoreHeaderCase();
                                                                                            
                                                                                            // Verify the new format has ignoreHeaderCase set to true
                                                                                            assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                            
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(baseFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_Immutable() {
                                                                                            // Verify that the original format is not modified
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withIgnoreHeaderCase(false);
                                                                                            CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                            
                                                                                            assertNotSame(original, modified);
                                                                                            assertFalse(original.getIgnoreHeaderCase());
                                                                                            assertTrue(modified.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_NullInput() {
                                                                                            // This test is for defensive programming - though the method doesn't take null
                                                                                            // We'll test with a mocked format to ensure no NPE occurs
                                                                                            CSVFormat mockFormat = mock(CSVFormat.class);
                                                                                            when(mockFormat.withIgnoreHeaderCase(anyBoolean())).thenCallRealMethod();
                                                                                            
                                                                                            // This should work fine as the parameter is primitive boolean
                                                                                            CSVFormat result = mockFormat.withIgnoreHeaderCase(false);
                                                                                            assertNotNull(result);
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_SameValue() {
                                                                                            // Setup original CSVFormat
                                                                                            boolean originalIgnoreHeaderCase = true;
                                                                                            CSVFormat original = CSVFormat.DEFAULT.withIgnoreHeaderCase(originalIgnoreHeaderCase);
                                                                                            
                                                                                            // Test with same value
                                                                                            CSVFormat modified = original.withIgnoreHeaderCase(originalIgnoreHeaderCase);
                                                                                            
                                                                                            // Should return the same instance since value didn't change
                                                                                            assertSame(original, modified);
                                                                                        }

    @Test
                                                                                        public void testWithIgnoreHeaderCase_DefaultFormat() {
                                                                                            // Get default format
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            boolean originalIgnoreHeaderCase = original.getIgnoreHeaderCase();
                                                                                            
                                                                                            // Test changing the value
                                                                                            CSVFormat modified = original.withIgnoreHeaderCase(!originalIgnoreHeaderCase);
                                                                                            
                                                                                            // Verify the change
                                                                                            assertEquals(!originalIgnoreHeaderCase, modified.getIgnoreHeaderCase());
                                                                                            
                                                                                            // Verify all other properties remain the same as DEFAULT
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                        }

    @Test
                                                                                        public void testWithNullString() {
                                                                                            // Create a base format with some default values
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                .withDelimiter(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false);
                                                                                            
                                                                                            // Test setting a regular null string
                                                                                            String nullString = "NULL";
                                                                                            CSVFormat newFormat = baseFormat.withNullString(nullString);
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertEquals(',', newFormat.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                            assertEquals(QuoteMode.MINIMAL, newFormat.getQuoteMode());
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            
                                                                                            // Test setting empty string as null string
                                                                                            CSVFormat emptyNullFormat = baseFormat.withNullString("");
                                                                                            assertEquals("", emptyNullFormat.getNullString());
                                                                                            
                                                                                            // Test setting null as null string
                                                                                            CSVFormat nullNullFormat = baseFormat.withNullString(null);
                                                                                            assertNull(nullNullFormat.getNullString());
                                                                                            
                                                                                            // Verify that original format remains unchanged
                                                                                            assertNull(baseFormat.getNullString());
                                                                                            
                                                                                            // Test with special characters in null string
                                                                                            String specialNullString = "\\N\t\n";
                                                                                            CSVFormat specialFormat = baseFormat.withNullString(specialNullString);
                                                                                            assertEquals(specialNullString, specialFormat.getNullString());
                                                                                            
                                                                                            // Test with very long null string
                                                                                            String longNullString = new String(new char[1000]).replace('\0', 'X');
                                                                                            CSVFormat longFormat = baseFormat.withNullString(longNullString);
                                                                                            assertEquals(longNullString, longFormat.getNullString());
                                                                                        }

    @Test
                                                                                        public void testWithNullStringPreservesOtherProperties() {
                                                                                            // Create a complex format with all properties set
                                                                                            CSVFormat complexFormat = CSVFormat.DEFAULT
                                                                                                .withDelimiter('|')
                                                                                                .withQuote('\'')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withHeaderComments("File Header")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true)
                                                                                                .withIgnoreHeaderCase(true);
                                                                                            
                                                                                            // Apply withNullString and verify all other properties remain the same
                                                                                            CSVFormat newFormat = complexFormat.withNullString("NA");
                                                                                            
                                                                                            assertEquals('|', newFormat.getDelimiter());
                                                                                            assertEquals(Character.valueOf('\''), newFormat.getQuoteCharacter());
                                                                                            assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                            assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                            assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                            assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                            assertArrayEquals(new String[]{"col1", "col2"}, newFormat.getHeader());
                                                                                            assertArrayEquals(new String[]{"File Header"}, newFormat.getHeaderComments());
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            assertTrue(newFormat.getIgnoreHeaderCase());
                                                                                            assertEquals("NA", newFormat.getNullString());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_ValidCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            char quoteChar = '\'';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_NullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            char quoteChar = '\0'; // null character
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNull(newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_SameCharacterAsOriginal() {
                                                                                            // Setup
                                                                                            char quoteChar = '"';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',').withQuote(quoteChar);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withQuote(quoteChar);
                                                                                            
                                                                                            // Verify
                                                                                            assertSame(originalFormat, newFormat); // Should return same instance when no change
                                                                                        }

    @Test
                                                                                        public void testWithQuote_SpecialCharacters() {
                                                                                            // Test various special characters
                                                                                            char[] specialChars = {'"', '\'', '|', '\t', '\\', ' '};
                                                                                            
                                                                                            for (char c : specialChars) {
                                                                                                CSVFormat newFormat = CSVFormat.DEFAULT.withQuote(c);
                                                                                                assertEquals(Character.valueOf(c), newFormat.getQuoteCharacter());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithQuote_UnicodeCharacters() {
                                                                                            // Test various Unicode characters
                                                                                            char[] unicodeChars = {'©', '€', '字', '☺'};
                                                                                            
                                                                                            for (char c : unicodeChars) {
                                                                                                CSVFormat newFormat = CSVFormat.DEFAULT.withQuote(c);
                                                                                                assertEquals(Character.valueOf(c), newFormat.getQuoteCharacter());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithQuote_WhenQuoteCharacterSameAsDelimiter() {
                                                                                            // Setup
                                                                                            char quoteChar = ',';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(quoteChar); // delimiter same as quote char
                                                                                            
                                                                                            // Expect validation exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            
                                                                                            // Execute
                                                                                            originalFormat.withQuote(quoteChar);
                                                                                        }

    @Test
                                                                                        public void testWithQuote_WhenQuoteCharacterSameAsCommentMarker() {
                                                                                            // Setup
                                                                                            char quoteChar = '#';
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withCommentMarker(quoteChar);
                                                                                            
                                                                                            // Expect validation exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            
                                                                                            // Execute
                                                                                            originalFormat.withQuote(quoteChar);
                                                                                        }

    @Test
                                                                                        public void testWithQuote_WhenQuoteCharacterSameAsEscapeCharacter() {
                                                                                            // Setup
                                                                                            char quoteChar = '\\';
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withEscape(quoteChar);
                                                                                            
                                                                                            // Expect validation exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            
                                                                                            // Execute
                                                                                            originalFormat.withQuote(quoteChar);
                                                                                        }

    @Test
                                                                                        public void testWithQuote_VerifyImmutability() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            char originalQuote = originalFormat.getQuoteCharacter() != null ? 
                                                                                                                originalFormat.getQuoteCharacter().charValue() : '\0';
                                                                                            char newQuote = originalQuote == '"' ? '\'' : '"';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = originalFormat.withQuote(newQuote);
                                                                                            
                                                                                            // Verify original unchanged
                                                                                            if (originalFormat.getQuoteCharacter() != null) {
                                                                                                assertEquals(originalQuote, originalFormat.getQuoteCharacter().charValue());
                                                                                            } else {
                                                                                                assertNull(originalFormat.getQuoteCharacter());
                                                                                            }
                                                                                            // Verify new format has new quote
                                                                                            assertEquals(Character.valueOf(newQuote), newFormat.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_ValidCharacter1() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char quoteChar = '\'';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuote(quoteChar);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(quoteChar, modified.getQuoteCharacter().charValue());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_NullCharacter1() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            Character quoteChar = null;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuote(quoteChar);
                                                                                            
                                                                                            // Verify
                                                                                            assertNull(modified.getQuoteCharacter());
                                                                                            assertFalse(modified.isQuoteCharacterSet());
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_LineBreakCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char lineBreak = '\n';
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                            
                                                                                            // Execute
                                                                                            original.withQuote(lineBreak);
                                                                                        }

    @Test
                                                                                        public void testWithQuote_SameCharacterAsOriginal1() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.newFormat(',').withQuote('"');
                                                                                            char sameQuoteChar = '"';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuote(sameQuoteChar);
                                                                                            
                                                                                            // Verify it returns the same instance (optimization)
                                                                                            assertSame(original, modified);
                                                                                        }

    @Test
                                                                                        public void testWithQuote_ChangesOnlyQuoteCharacter() {
                                                                                            // Setup complex original format
                                                                                            CSVFormat original = CSVFormat.newFormat(';')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withSkipHeaderRecord(true);
                                                                                            
                                                                                            char newQuoteChar = '\'';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuote(newQuoteChar);
                                                                                            
                                                                                            // Verify only quote character changed
                                                                                            assertEquals(newQuoteChar, modified.getQuoteCharacter().charValue());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithQuote_CharacterObjectVsPrimitive() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            char primitiveQuote = '|';
                                                                                            Character objectQuote = '|';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat fromPrimitive = original.withQuote(primitiveQuote);
                                                                                            CSVFormat fromObject = original.withQuote(objectQuote);
                                                                                            
                                                                                            // Verify both produce same result
                                                                                            assertEquals(fromPrimitive.getQuoteCharacter(), fromObject.getQuoteCharacter());
                                                                                            assertEquals(fromPrimitive.hashCode(), fromObject.hashCode());
                                                                                            assertTrue(fromPrimitive.equals(fromObject));
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode_NonNullQuoteMode() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeaderComments("HeaderComment")
                                                                                                .withHeader("Header1", "Header2")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true)
                                                                                                .withIgnoreHeaderCase(false);
                                                                                    
                                                                                            QuoteMode newQuoteMode = QuoteMode.ALL;
                                                                                    
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuoteMode(newQuoteMode);
                                                                                    
                                                                                            // Verify
                                                                                            assertEquals(newQuoteMode, modified.getQuoteMode());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                            assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                            assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                            assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                            assertEquals(original.getNullString(), modified.getNullString());
                                                                                            assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                            assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                            assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                            assertEquals(original.getAllowMissingColumnNames(), modified.getAllowMissingColumnNames());
                                                                                            assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode_NullQuoteMode() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            QuoteMode nullQuoteMode = null;
                                                                                    
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("quoteMode");
                                                                                    
                                                                                            // Execute
                                                                                            original.withQuoteMode(nullQuoteMode);
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode_VerifyImmutability() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.EXCEL;
                                                                                            QuoteMode newQuoteMode = QuoteMode.MINIMAL;
                                                                                    
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuoteMode(newQuoteMode);
                                                                                    
                                                                                            // Verify original unchanged
                                                                                            assertNotEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                            assertEquals(QuoteMode.MINIMAL, modified.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode_DifferentQuoteModes() {
                                                                                            // Test all possible QuoteMode values
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            
                                                                                            for (QuoteMode mode : QuoteMode.values()) {
                                                                                                CSVFormat modified = original.withQuoteMode(mode);
                                                                                                assertEquals(mode, modified.getQuoteMode());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode_FromNoQuoteToQuoteMode() {
                                                                                            // Setup - format with no quote character
                                                                                            CSVFormat original = CSVFormat.newFormat(',').withQuote(null);
                                                                                            
                                                                                            // Execute - should still work even without quote character
                                                                                            CSVFormat modified = original.withQuoteMode(QuoteMode.NON_NUMERIC);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(QuoteMode.NON_NUMERIC, modified.getQuoteMode());
                                                                                            assertNull(modified.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithQuoteMode_WithAllNullFields() {
                                                                                            // Setup - minimal format
                                                                                            CSVFormat original = CSVFormat.newFormat(',');
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat modified = original.withQuoteMode(QuoteMode.ALL);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                            assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                            assertNull(modified.getQuoteCharacter());
                                                                                            assertNull(modified.getCommentMarker());
                                                                                            assertNull(modified.getEscapeCharacter());
                                                                                            assertFalse(modified.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                            assertNull(modified.getRecordSeparator());
                                                                                            assertNull(modified.getNullString());
                                                                                            assertNull(modified.getHeaderComments());
                                                                                            assertNull(modified.getHeader());
                                                                                            assertFalse(modified.getSkipHeaderRecord());
                                                                                            assertFalse(modified.getAllowMissingColumnNames());
                                                                                            assertFalse(modified.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_ValidCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            char recordSeparator = '\n';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withRecordSeparator(recordSeparator);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertEquals(String.valueOf(recordSeparator), newFormat.getRecordSeparator());
                                                                                            assertNotSame(baseFormat, newFormat); // Should return a new instance
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_SpecialCharacters() {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            char[] specialChars = {'\r', '\t', '\f', '\b'};
                                                                                            
                                                                                            for (char c : specialChars) {
                                                                                                // Execute
                                                                                                CSVFormat newFormat = baseFormat.withRecordSeparator(c);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(String.valueOf(c), newFormat.getRecordSeparator());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_PrintableCharacters() {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            char[] printableChars = {'|', ';', ':', '~'};
                                                                                            
                                                                                            for (char c : printableChars) {
                                                                                                // Execute
                                                                                                CSVFormat newFormat = baseFormat.withRecordSeparator(c);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(String.valueOf(c), newFormat.getRecordSeparator());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_UnicodeCharacters() {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                            char[] unicodeChars = {'\u2028', '\u2029', 'Ω', '∑'};
                                                                                            
                                                                                            for (char c : unicodeChars) {
                                                                                                // Execute
                                                                                                CSVFormat newFormat = baseFormat.withRecordSeparator(c);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(String.valueOf(c), newFormat.getRecordSeparator());
                                                                                            }
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_OtherPropertiesPreserved() {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreEmptyLines(true);
                                                                                            char recordSeparator = '|';
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat newFormat = baseFormat.withRecordSeparator(recordSeparator);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(String.valueOf(recordSeparator), newFormat.getRecordSeparator());
                                                                                            assertEquals(baseFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(baseFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(baseFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_NullBaseFormat() {
                                                                                            // Setup
                                                                                            CSVFormat baseFormat = null;
                                                                                            char recordSeparator = '\n';
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(NullPointerException.class);
                                                                                            
                                                                                            // Execute
                                                                                            baseFormat.withRecordSeparator(recordSeparator);
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_FromDefaultFormat() {
                                                                                            // Test with DEFAULT format
                                                                                            CSVFormat modified = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                            assertEquals("\r\n", modified.getRecordSeparator());
                                                                                            assertEquals(CSVFormat.DEFAULT.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            // Add more assertions for other DEFAULT properties if needed
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_FromExcelFormat() {
                                                                                            // Test with EXCEL format
                                                                                            CSVFormat modified = CSVFormat.EXCEL.withRecordSeparator("\n");
                                                                                            assertEquals("\n", modified.getRecordSeparator());
                                                                                            assertEquals(CSVFormat.EXCEL.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.EXCEL.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            // Add more assertions for other EXCEL properties if needed
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_FromRfc4180Format() {
                                                                                            // Test with RFC4180 format
                                                                                            CSVFormat modified = CSVFormat.RFC4180.withRecordSeparator("\r");
                                                                                            assertEquals("\r", modified.getRecordSeparator());
                                                                                            assertEquals(CSVFormat.RFC4180.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.RFC4180.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            // Add more assertions for other RFC4180 properties if needed
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_Immutable() {
                                                                                            // Verify that original format remains unchanged
                                                                                            CSVFormat original = CSVFormat.DEFAULT;
                                                                                            CSVFormat modified = original.withRecordSeparator("\r\n");
                                                                                            
                                                                                            assertNotSame(original, modified);
                                                                                            assertNull(original.getRecordSeparator()); // DEFAULT has null record separator
                                                                                            assertEquals("\r\n", modified.getRecordSeparator());
                                                                                        }

    @Test
                                                                                        public void testWithRecordSeparator_EqualsAndHashCode() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withRecordSeparator("\n");
                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                            
                                                                                            assertEquals(format1, format2);
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                            assertNotEquals(format1, format3);
                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_True() {
                                                                                            // Given
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // When
                                                                                            CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Then
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                            assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                            assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_False() {
                                                                                            // Given
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // When
                                                                                            CSVFormat newFormat = originalFormat.withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Then
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertFalse(newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertArrayEquals(originalFormat.getHeaderComments(), newFormat.getHeaderComments());
                                                                                            assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                            assertEquals(originalFormat.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_Chaining() {
                                                                                            // Given
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // When
                                                                                            CSVFormat newFormat = originalFormat
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Then
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_DefaultInstance() {
                                                                                            // Given
                                                                                            CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // Then
                                                                                            assertFalse(defaultFormat.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_Immutable() {
                                                                                            // Given
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                                            
                                                                                            // When
                                                                                            originalFormat.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Then - original format should remain unchanged
                                                                                            assertFalse(originalFormat.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_True1() {
                                                                                            // Setup initial format with all possible parameters
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withDelimiter(';')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeaderComments("Comment1", "Comment2")
                                                                                                .withHeader("Col1", "Col2")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(true)
                                                                                                .withIgnoreHeaderCase(true);
                                                                                    
                                                                                            // Test setting skipHeaderRecord to true
                                                                                            CSVFormat modified = original.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Verify all properties except skipHeaderRecord remain the same
                                                                                            assertEquals(';', modified.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                            assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                            assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                            assertTrue(modified.getIgnoreEmptyLines());
                                                                                            assertEquals("\r\n", modified.getRecordSeparator());
                                                                                            assertEquals("NULL", modified.getNullString());
                                                                                            assertArrayEquals(new String[]{"Comment1", "Comment2"}, modified.getHeaderComments());
                                                                                            assertArrayEquals(new String[]{"Col1", "Col2"}, modified.getHeader());
                                                                                            assertTrue(modified.getAllowMissingColumnNames());
                                                                                            assertTrue(modified.getIgnoreHeaderCase());
                                                                                            
                                                                                            // Verify skipHeaderRecord was changed
                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_False1() {
                                                                                            // Setup initial format with skipHeaderRecord true
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withSkipHeaderRecord(true);
                                                                                    
                                                                                            // Test setting skipHeaderRecord to false
                                                                                            CSVFormat modified = original.withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Verify skipHeaderRecord was changed
                                                                                            assertFalse(modified.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_NoArg() {
                                                                                            // Setup initial format with skipHeaderRecord false
                                                                                            CSVFormat original = CSVFormat.DEFAULT
                                                                                                .withSkipHeaderRecord(false);
                                                                                    
                                                                                            // Test no-arg version which should set to true
                                                                                            CSVFormat modified = original.withSkipHeaderRecord();
                                                                                            
                                                                                            // Verify skipHeaderRecord was set to true
                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_FromDefault() {
                                                                                            // Test starting from DEFAULT format
                                                                                            CSVFormat modified = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Verify skipHeaderRecord was set
                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                            
                                                                                            // Verify other DEFAULT properties remain unchanged
                                                                                            assertEquals(CSVFormat.DEFAULT.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                            assertEquals(CSVFormat.DEFAULT.getQuoteMode(), modified.getQuoteMode());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_FromExcelFormat() {
                                                                                            // Test starting from EXCEL format
                                                                                            CSVFormat modified = CSVFormat.EXCEL.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Verify skipHeaderRecord was set
                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                            
                                                                                            // Verify other EXCEL properties remain unchanged
                                                                                            assertEquals(CSVFormat.EXCEL.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.EXCEL.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_FromTDFFormat() {
                                                                                            // Test starting from TDF format
                                                                                            CSVFormat modified = CSVFormat.TDF.withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Verify skipHeaderRecord was set
                                                                                            assertFalse(modified.getSkipHeaderRecord());
                                                                                            
                                                                                            // Verify other TDF properties remain unchanged
                                                                                            assertEquals(CSVFormat.TDF.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.TDF.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_FromMYSQLFormat() {
                                                                                            // Test starting from MYSQL format
                                                                                            CSVFormat modified = CSVFormat.MYSQL.withSkipHeaderRecord(true);
                                                                                            
                                                                                            // Verify skipHeaderRecord was set
                                                                                            assertTrue(modified.getSkipHeaderRecord());
                                                                                            
                                                                                            // Verify other MYSQL properties remain unchanged
                                                                                            assertEquals(CSVFormat.MYSQL.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.MYSQL.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_FromRFC4180Format() {
                                                                                            // Test starting from RFC4180 format
                                                                                            CSVFormat modified = CSVFormat.RFC4180.withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Verify skipHeaderRecord was set
                                                                                            assertFalse(modified.getSkipHeaderRecord());
                                                                                            
                                                                                            // Verify other RFC4180 properties remain unchanged
                                                                                            assertEquals(CSVFormat.RFC4180.getDelimiter(), modified.getDelimiter());
                                                                                            assertEquals(CSVFormat.RFC4180.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                        }

    @Test
                                                                                        public void testWithSkipHeaderRecord_EqualsAndHashCode() {
                                                                                            CSVFormat format1 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            CSVFormat format2 = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            CSVFormat format3 = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Test equals
                                                                                            assertEquals(format1, format2);
                                                                                            assertNotEquals(format1, format3);
                                                                                            
                                                                                            // Test hashCode
                                                                                            assertEquals(format1.hashCode(), format2.hashCode());
                                                                                            assertNotEquals(format1.hashCode(), format3.hashCode());
                                                                                        }

    @Test
                                                                                public void testIsLineBreak_WithNonLineBreakCharacters() throws Exception {
                                                                                    // Get the private isLineBreak method using reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Test various non-line-break characters
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, 'a'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, ' '));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\t'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\0'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '1'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '@'));
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithUnicodeLineSeparators() throws Exception {
                                                                                    // Get the private isLineBreak method via reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Test Unicode line separators (should return false since method only checks for LF/CR)
                                                                                    assertFalse((boolean) isLineBreakMethod.invoke(null, '\u2028')); // LINE SEPARATOR
                                                                                    assertFalse((boolean) isLineBreakMethod.invoke(null, '\u2029')); // PARAGRAPH SEPARATOR
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithControlCharacters() throws Exception {
                                                                                    // Get the private isLineBreak method via reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Test other control characters
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\b'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\f'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\u001F'));
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithNullCharacter() throws Exception {
                                                                                    Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                    method.setAccessible(true);
                                                                                    assertFalse((Boolean) method.invoke(null, '\0'));
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithMaxCharValue() throws Exception {
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    boolean result = (boolean) isLineBreakMethod.invoke(null, Character.MAX_VALUE);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithMinCharValue() throws Exception {
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    boolean result = (boolean) isLineBreakMethod.invoke(null, Character.MIN_VALUE);
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithNullCharacter1() throws Exception {
                                                                                    // Get the private method using reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Invoke the method with null parameter
                                                                                    boolean result = (boolean) isLineBreakMethod.invoke(null, (Character) null);
                                                                                    
                                                                                    // Assert the result
                                                                                    assertFalse(result);
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithNonLineBreakCharacters1() throws Exception {
                                                                                    // Get the private isLineBreak method that takes char parameter
                                                                                    Method isLineBreakCharMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakCharMethod.setAccessible(true);
                                                                                    
                                                                                    // Test various non-line-break characters
                                                                                    assertFalse((boolean) isLineBreakCharMethod.invoke(null, 'a'));
                                                                                    assertFalse((boolean) isLineBreakCharMethod.invoke(null, ' '));
                                                                                    assertFalse((boolean) isLineBreakCharMethod.invoke(null, '\t'));
                                                                                    assertFalse((boolean) isLineBreakCharMethod.invoke(null, '0'));
                                                                                    assertFalse((boolean) isLineBreakCharMethod.invoke(null, '@'));
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithLineBreakCharacters() throws Exception {
                                                                                    // Get the private isLineBreak method using reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Test standard line break characters
                                                                                    assertTrue((Boolean) isLineBreakMethod.invoke(null, '\n'));  // Line feed
                                                                                    assertTrue((Boolean) isLineBreakMethod.invoke(null, '\r'));  // Carriage return
                                                                                    
                                                                                    // Test Unicode line break characters
                                                                                    assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u0085'));  // Next line
                                                                                    assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u2028'));  // Line separator
                                                                                    assertTrue((Boolean) isLineBreakMethod.invoke(null, '\u2029'));  // Paragraph separator
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithControlCharacters1() throws Exception {
                                                                                    // Get the private isLineBreak method using reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Test other control characters that aren't line breaks
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\b'));  // Backspace
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\f'));  // Form feed
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '\0'));  // Null character
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithSurrogatePairs() throws Exception {
                                                                                    // Test with surrogate pairs (should return false as they're not line breaks)
                                                                                    Method isLineBreakChar = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakChar.setAccessible(true);
                                                                                    assertFalse((Boolean) isLineBreakChar.invoke(null, '\uD800'));  // High surrogate
                                                                                    assertFalse((Boolean) isLineBreakChar.invoke(null, '\uDC00'));  // Low surrogate
                                                                                }

    @Test
                                                                                public void testIsLineBreak_WithExtendedAscii() throws Exception {
                                                                                    // Get the private isLineBreak method using reflection
                                                                                    Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                    isLineBreakMethod.setAccessible(true);
                                                                                    
                                                                                    // Test extended ASCII characters
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, 'é'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '©'));
                                                                                    assertFalse((Boolean) isLineBreakMethod.invoke(null, '€'));
                                                                                }

    @Test
                                                                                public void testToStringArray_NullInput() throws Exception {
                                                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                    Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                    toStringArrayMethod.setAccessible(true);
                                                                                    Object result = toStringArrayMethod.invoke(csvFormat, (Object) null);
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testToStringArray_EmptyArray() throws Exception {
                                                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                    Object[] input = new Object[0];
                                                                                    
                                                                                    // Use reflection to access private method
                                                                                    Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                    toStringArrayMethod.setAccessible(true);
                                                                                    String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                    
                                                                                    assertNotNull(result);
                                                                                    assertEquals(0, result.length);
                                                                                }

    @Test
                                                                                public void testToStringArray_AllNonNullValues() throws Exception {
                                                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                    Object[] input = {123, "test", true, 45.67};
                                                                                    String[] expected = {"123", "test", "true", "45.67"};
                                                                                    
                                                                                    // Use reflection to access private method
                                                                                    Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                    toStringArrayMethod.setAccessible(true);
                                                                                    String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                    
                                                                                    assertArrayEquals(expected, result);
                                                                                }

    @Test
                                                                                public void testToStringArray_WithNullValues() throws Exception {
                                                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                    Object[] input = {"hello", null, 42, null};
                                                                                    String[] expected = {"hello", null, "42", null};
                                                                                    
                                                                                    // Use reflection to access private method
                                                                                    Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                    toStringArrayMethod.setAccessible(true);
                                                                                    String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                    
                                                                                    assertArrayEquals(expected, result);
                                                                                }

    @Test
                                                                                public void testToStringArray_MixedTypes() throws Exception {
                                                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                    Object[] input = {new StringBuilder("builder"), Integer.valueOf(100), Boolean.TRUE};
                                                                                    String[] expected = {"builder", "100", "true"};
                                                                                    
                                                                                    // Use reflection to access private method
                                                                                    Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                    toStringArrayMethod.setAccessible(true);
                                                                                    String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                    
                                                                                    assertArrayEquals(expected, result);
                                                                                }

    @Test
                                                                                public void testToStringArray_CustomObjects() throws Exception {
                                                                                    // Define a simple CustomObject class for testing
                                                                                    class CustomObject {
                                                                                        private String value;
                                                                                        public CustomObject(String value) { this.value = value; }
                                                                                        @Override public String toString() { return "Custom: " + value; }
                                                                                    }
                                                                                    
                                                                                    CSVFormat csvFormat = CSVFormat.DEFAULT;
                                                                                    Object[] input = {new CustomObject("test1"), new CustomObject("test2")};
                                                                                    String[] expected = {"Custom: test1", "Custom: test2"};
                                                                                    
                                                                                    // Use reflection to access private toStringArray method
                                                                                    Method toStringArrayMethod = CSVFormat.class.getDeclaredMethod("toStringArray", Object[].class);
                                                                                    toStringArrayMethod.setAccessible(true);
                                                                                    String[] result = (String[]) toStringArrayMethod.invoke(csvFormat, (Object) input);
                                                                                    
                                                                                    assertArrayEquals(expected, result);
                                                                                }

    @Test
                                                                                public void testGetCommentMarker_WhenCommentMarkerIsSet() {
                                                                                    // Arrange
                                                                                    Character expectedCommentMarker = '#';
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker(expectedCommentMarker)
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader((String[])null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    Character actualCommentMarker = format.getCommentMarker();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                }

    @Test
                                                                                public void testGetDelimiter_WithAllConstructorParameters() {
                                                                                    // Test with all constructor parameters specified
                                                                                    char delimiter = '^';
                                                                                    Character quoteChar = '"';
                                                                                    QuoteMode quoteMode = QuoteMode.ALL;
                                                                                    Character commentStart = '#';
                                                                                    Character escape = '\\';
                                                                                    boolean ignoreSurroundingSpaces = true;
                                                                                    boolean ignoreEmptyLines = true;
                                                                                    String recordSeparator = "\n";
                                                                                    String nullString = "NULL";
                                                                                    Object[] headerComments = new Object[]{"Comment1", "Comment2"};
                                                                                    String[] header = new String[]{"Header1", "Header2"};
                                                                                    boolean skipHeaderRecord = true;
                                                                                    boolean allowMissingColumnNames = true;
                                                                                    boolean ignoreHeaderCase = true;
                                                                                    
                                                                                    // Use builder pattern to create CSVFormat instance
                                                                                    CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                            .withQuote(quoteChar)
                                                                                            .withQuoteMode(quoteMode)
                                                                                            .withCommentMarker(commentStart)
                                                                                            .withEscape(escape)
                                                                                            .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                            .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                            .withRecordSeparator(recordSeparator)
                                                                                            .withNullString(nullString)
                                                                                            .withHeaderComments(headerComments)
                                                                                            .withHeader(header)
                                                                                            .withSkipHeaderRecord(skipHeaderRecord)
                                                                                            .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                            .withIgnoreHeaderCase(ignoreHeaderCase);
                                                                                    
                                                                                    assertEquals(delimiter, format.getDelimiter());
                                                                                }

    @Test
                                                                                public void testGetEscapeCharacter_WhenEscapeCharacterIsNull() {
                                                                                    // Arrange
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader((String[])null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    Character actualEscape = format.getEscapeCharacter();
                                                                                    
                                                                                    // Assert
                                                                                    assertNull(actualEscape);
                                                                                }

    @Test
                                                                                public void testGetHeader_WhenHeaderIsNull() {
                                                                                    // Arrange
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withHeader((String[]) null);
                                                                                    
                                                                                    // Act
                                                                                    String[] result = format.getHeader();
                                                                                    
                                                                                    // Assert
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testGetHeader_WhenHeaderIsEmptyArray() {
                                                                                    // Arrange
                                                                                    String[] emptyHeader = new String[0];
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote(null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments(null)
                                                                                        .withHeader(emptyHeader)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    String[] result = format.getHeader();
                                                                                    
                                                                                    // Assert
                                                                                    assertNotNull(result);
                                                                                    assertEquals(0, result.length);
                                                                                    assertNotSame(emptyHeader, result); // Verify it's a clone
                                                                                }

    @Test
                                                                                public void testGetHeader_WhenHeaderHasValues() {
                                                                                    // Arrange
                                                                                    String[] header = {"Name", "Age", "Email"};
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                            .withQuote(null)
                                                                                            .withQuoteMode(null)
                                                                                            .withCommentMarker(null)
                                                                                            .withEscape(null)
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString(null)
                                                                                            .withHeaderComments(null)
                                                                                            .withHeader(header)
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false)
                                                                                            .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    String[] result = format.getHeader();
                                                                                    
                                                                                    // Assert
                                                                                    assertNotNull(result);
                                                                                    assertEquals(3, result.length);
                                                                                    assertArrayEquals(header, result);
                                                                                    assertNotSame(header, result); // Verify it's a clone
                                                                                    
                                                                                    // Verify modifying the result doesn't affect original
                                                                                    result[0] = "Modified";
                                                                                    assertEquals("Name", header[0]);
                                                                                }

    @Test
                                                                                public void testGetHeader_ReturnsDefensiveCopy() {
                                                                                    // Arrange
                                                                                    String[] header = {"Col1", "Col2"};
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote(null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments(null)
                                                                                        .withHeader(header)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    String[] firstCall = format.getHeader();
                                                                                    String[] secondCall = format.getHeader();
                                                                                    
                                                                                    // Assert
                                                                                    assertNotSame(firstCall, secondCall); // Each call returns new clone
                                                                                    assertArrayEquals(firstCall, secondCall);
                                                                                }

    @Test
                                                                                public void testGetHeaderComments_WhenNull() {
                                                                                    // Arrange
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote(null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader((String[])null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    String[] result = format.getHeaderComments();
                                                                                    
                                                                                    // Assert
                                                                                    assertNull(result);
                                                                                }

    @Test
                                                                                public void testGetHeaderComments_WhenEmptyArray() {
                                                                                    // Arrange
                                                                                    String[] emptyComments = new String[0];
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote(null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments(emptyComments)
                                                                                        .withHeader((String[])null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    String[] result = format.getHeaderComments();
                                                                                    
                                                                                    // Assert
                                                                                    assertNotNull(result);
                                                                                    assertEquals(0, result.length);
                                                                                    assertNotSame(emptyComments, result); // Verify it's a clone
                                                                                }

    @Test
                                                                                public void testGetHeaderComments_WithValues() {
                                                                                    // Arrange
                                                                                    String[] comments = {"Comment1", "Comment2"};
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote(null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments(comments)
                                                                                        .withHeader((String[]) null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    String[] result = format.getHeaderComments();
                                                                                    
                                                                                    // Assert
                                                                                    assertNotNull(result);
                                                                                    assertEquals(2, result.length);
                                                                                    assertEquals("Comment1", result[0]);
                                                                                    assertEquals("Comment2", result[1]);
                                                                                    assertNotSame(comments, result); // Verify it's a clone
                                                                                }

    @Test
                                                                                public void testGetAllowMissingColumnNames_WhenTrue() {
                                                                                    // Create a CSVFormat instance with allowMissingColumnNames set to true using builder pattern
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader("Header1", "Header2")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(true)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    assertTrue("Should return true when allowMissingColumnNames is true", 
                                                                                        format.getAllowMissingColumnNames());
                                                                                }

    @Test
                                                                                public void testGetAllowMissingColumnNames_WhenFalse() {
                                                                                    // Create a CSVFormat instance with allowMissingColumnNames set to false using builder pattern
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader("Header1", "Header2")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    assertFalse("Should return false when allowMissingColumnNames is false", 
                                                                                        format.getAllowMissingColumnNames());
                                                                                }

    @Test
                                                                                public void testGetIgnoreEmptyLines_NewFormat() {
                                                                                    // Test with newly created format
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(true)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader((String[])null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    assertTrue(format.getIgnoreEmptyLines());
                                                                                }

    @Test
                                                                                public void testGetIgnoreSurroundingSpaces_WithConstructor() {
                                                                                    // Test with direct constructor setting ignoreSurroundingSpaces to true
                                                                                    CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
                                                                                    assertTrue("Constructor-set ignoreSurroundingSpaces=true should return true", 
                                                                                             format.getIgnoreSurroundingSpaces());
                                                                                }

    @Test
                                                                                public void testGetIgnoreHeaderCase_NewFormatWithIgnoreHeaderCase() {
                                                                                    // Test with newly created format with ignoreHeaderCase set
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(true);
                                                                                    
                                                                                    assertTrue("New format with ignoreHeaderCase true should return true", 
                                                                                              format.getIgnoreHeaderCase());
                                                                                }

    @Test
                                                                                public void testGetNullString_WhenNullStringIsCustomValue() {
                                                                                    // Create a CSVFormat instance with custom nullString using builder pattern
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                            .withDelimiter(',')
                                                                                            .withQuoteMode(QuoteMode.MINIMAL)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString("NULL");
                                                                                    
                                                                                    assertEquals("NULL", format.getNullString());
                                                                                }

    @Test
                                                                                public void testGetQuoteCharacter_WhenQuoteCharacterIsSet() {
                                                                                    // Arrange
                                                                                    Character expectedQuote = '"';
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                            .withQuote(expectedQuote)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withRecordSeparator("\n")
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false)
                                                                                            .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    Character actualQuote = format.getQuoteCharacter();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(expectedQuote, actualQuote);
                                                                                }

    @Test
                                                                                public void testGetQuoteCharacter_WhenQuoteCharacterIsNull() {
                                                                                    // Arrange
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote((Character) null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[]) null)
                                                                                        .withHeader((String[]) null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    Character actualQuote = format.getQuoteCharacter();
                                                                                    
                                                                                    // Assert
                                                                                    assertNull(actualQuote);
                                                                                }

    @Test
                                                                                public void testGetQuoteCharacter_AfterModifyingFormatWithWithQuote() {
                                                                                    // Arrange
                                                                                    Character originalQuote = '"';
                                                                                    Character newQuote = '\'';
                                                                                    CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                        .withQuote(originalQuote)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\n")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    CSVFormat modifiedFormat = originalFormat.withQuote(newQuote);
                                                                                    Character actualQuote = modifiedFormat.getQuoteCharacter();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals(newQuote, actualQuote);
                                                                                    // Verify original format wasn't modified (immutability)
                                                                                    assertEquals(originalQuote, originalFormat.getQuoteCharacter());
                                                                                }

    @Test
                                                                                public void testGetQuoteMode_WhenInitializedWithNonNullQuoteMode() {
                                                                                    // Arrange
                                                                                    QuoteMode expectedMode = QuoteMode.ALL;
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(expectedMode)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader("Header1", "Header2")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    QuoteMode actualMode = format.getQuoteMode();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals("Quote mode should match initialized value", expectedMode, actualMode);
                                                                                }

    @Test
                                                                                public void testGetQuoteMode_WhenInitializedWithNullQuoteMode() {
                                                                                    // Arrange
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader("Header1", "Header2")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    QuoteMode actualMode = format.getQuoteMode();
                                                                                    
                                                                                    // Assert
                                                                                    assertNull("Quote mode should be null when initialized with null", actualMode);
                                                                                }

    @Test
                                                                                public void testGetQuoteMode_AfterWithQuoteModeModification() {
                                                                                    // Arrange
                                                                                    QuoteMode originalMode = QuoteMode.MINIMAL;
                                                                                    QuoteMode newMode = QuoteMode.NON_NUMERIC;
                                                                                    
                                                                                    CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(originalMode)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments((Object[])null)
                                                                                        .withHeader("Header1", "Header2")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    // Act
                                                                                    CSVFormat modifiedFormat = originalFormat.withQuoteMode(newMode);
                                                                                    QuoteMode actualMode = modifiedFormat.getQuoteMode();
                                                                                    
                                                                                    // Assert
                                                                                    assertEquals("Quote mode should be updated after withQuoteMode", newMode, actualMode);
                                                                                    assertEquals("Original format should remain unchanged", originalMode, originalFormat.getQuoteMode());
                                                                                }

    @Test
                                                                                public void testGetSkipHeaderRecord_WhenTrue() {
                                                                                    // Create a CSVFormat instance with skipHeaderRecord set to true using builder pattern
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                            .withDelimiter(',')
                                                                                            .withQuote('"')
                                                                                            .withQuoteMode(QuoteMode.MINIMAL)
                                                                                            .withCommentMarker('#')
                                                                                            .withEscape('\\')
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\r\n")
                                                                                            .withNullString(null)
                                                                                            .withHeaderComments("Comment1")
                                                                                            .withHeader("Header1")
                                                                                            .withSkipHeaderRecord(true)
                                                                                            .withAllowMissingColumnNames(false)
                                                                                            .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    assertTrue("Should return true when skipHeaderRecord is true", 
                                                                                              format.getSkipHeaderRecord());
                                                                                }

    @Test
                                                                                public void testGetSkipHeaderRecord_WhenFalse() {
                                                                                    // Create a CSVFormat instance with skipHeaderRecord set to false using builder pattern
                                                                                    CSVFormat format = CSVFormat.DEFAULT
                                                                                        .withDelimiter(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape('\\')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments("Comment1")
                                                                                        .withHeader("Header1")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    assertFalse("Should return false when skipHeaderRecord is false", 
                                                                                               format.getSkipHeaderRecord());
                                                                                }

    @Test
                                                                                public void testHashCode_AllFieldsSet() {
                                                                                    // Test with all fields set to non-default values
                                                                                    Character quoteChar = '"';
                                                                                    Character commentMarker = '#';
                                                                                    Character escapeChar = '\\';
                                                                                    String nullString = "NULL";
                                                                                    String recordSeparator = "\r\n";
                                                                                    String[] header = {"col1", "col2"};
                                                                                    
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote(quoteChar)
                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                        .withCommentMarker(commentMarker)
                                                                                        .withEscape(escapeChar)
                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                        .withIgnoreHeaderCase(true)
                                                                                        .withRecordSeparator(recordSeparator)
                                                                                        .withNullString(nullString)
                                                                                        .withHeader(header)
                                                                                        .withSkipHeaderRecord(true)
                                                                                        .withIgnoreEmptyLines(true)
                                                                                        .withAllowMissingColumnNames(false);
                                                                                    
                                                                                    int expectedHash = 31 * (31 + ',');
                                                                                    expectedHash = 31 * expectedHash + QuoteMode.ALL.hashCode();
                                                                                    expectedHash = 31 * expectedHash + quoteChar.hashCode();
                                                                                    expectedHash = 31 * expectedHash + commentMarker.hashCode();
                                                                                    expectedHash = 31 * expectedHash + escapeChar.hashCode();
                                                                                    expectedHash = 31 * expectedHash + nullString.hashCode();
                                                                                    expectedHash = 31 * expectedHash + 1231; // ignoreSurroundingSpaces = true
                                                                                    expectedHash = 31 * expectedHash + 1231; // ignoreHeaderCase = true
                                                                                    expectedHash = 31 * expectedHash + 1231; // ignoreEmptyLines = true
                                                                                    expectedHash = 31 * expectedHash + 1231; // skipHeaderRecord = true
                                                                                    expectedHash = 31 * expectedHash + 1237; // allowMissingColumnNames = false
                                                                                    expectedHash = 31 * expectedHash + recordSeparator.hashCode();
                                                                                    expectedHash = 31 * expectedHash + Arrays.hashCode(header);
                                                                                    
                                                                                    assertEquals(expectedHash, format.hashCode());
                                                                                }

    @Test
                                                                                public void testIsCommentMarkerSet_WhenCommentMarkerIsSet() {
                                                                                    // Create format with comment marker set using builder pattern
                                                                                    CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withCommentMarker('#')
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    assertTrue("Should return true when commentMarker is set", 
                                                                                              format.isCommentMarkerSet());
                                                                                }

    @Test
                                                                                public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNull() {
                                                                                    // Create a CSVFormat instance with null escape character
                                                                                    CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                            .withEscape(null)  // set escape to null
                                                                                            .withQuote(null)  // quoteChar
                                                                                            .withQuoteMode(null)  // quoteMode
                                                                                            .withCommentMarker(null)  // commentStart
                                                                                            .withIgnoreSurroundingSpaces(false)
                                                                                            .withIgnoreEmptyLines(false)
                                                                                            .withRecordSeparator("\n")  // recordSeparator
                                                                                            .withNullString(null)  // nullString
                                                                                            .withHeaderComments(null)  // headerComments
                                                                                            .withHeader((String[]) null)  // header
                                                                                            .withSkipHeaderRecord(false)
                                                                                            .withAllowMissingColumnNames(false)
                                                                                            .withIgnoreHeaderCase(false);
                                                                                    
                                                                                    assertFalse("Should return false when escapeCharacter is null", 
                                                                                               format.isEscapeCharacterSet());
                                                                                }

    @Test
                                                                                public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNotNull() {
                                                                                    // Create a CSVFormat instance with non-null escape character
                                                                                    CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                            .withEscape('\\')  // escape
                                                                                            .withQuote(null)  // quoteChar
                                                                                            .withQuoteMode(null)  // quoteMode
                                                                                            .withCommentMarker(null)  // commentStart
                                                                                            .withIgnoreSurroundingSpaces(false)  // ignoreSurroundingSpaces
                                                                                            .withIgnoreEmptyLines(false)  // ignoreEmptyLines
                                                                                            .withRecordSeparator("\n")  // recordSeparator
                                                                                            .withNullString(null)  // nullString
                                                                                            .withHeaderComments(null)  // headerComments
                                                                                            .withHeader((String[]) null)  // header
                                                                                            .withSkipHeaderRecord(false)  // skipHeaderRecord
                                                                                            .withAllowMissingColumnNames(false)  // allowMissingColumnNames
                                                                                            .withIgnoreHeaderCase(false);  // ignoreHeaderCase
                                                                                    
                                                                                    assertTrue("Should return true when escapeCharacter is not null", 
                                                                                              format.isEscapeCharacterSet());
                                                                                }

    @Test
                                                                                public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNull() {
                                                                                    // Create a CSVFormat instance with null quote character
                                                                                    CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                            .withQuote(null)                    // quoteChar
                                                                                            .withQuoteMode(null)               // quoteMode
                                                                                            .withCommentMarker(null)           // commentStart
                                                                                            .withEscape(null)                  // escape
                                                                                            .withIgnoreSurroundingSpaces(false) // ignoreSurroundingSpaces
                                                                                            .withIgnoreEmptyLines(false)        // ignoreEmptyLines
                                                                                            .withRecordSeparator("\r\n")        // recordSeparator
                                                                                            .withNullString(null)              // nullString
                                                                                            .withHeaderComments(null)          // headerComments
                                                                                            .withHeader((String[]) null)       // header
                                                                                            .withSkipHeaderRecord(false)       // skipHeaderRecord
                                                                                            .withAllowMissingColumnNames(false) // allowMissingColumnNames
                                                                                            .withIgnoreHeaderCase(false);      // ignoreHeaderCase
                                                                                    
                                                                                    assertFalse("Should return false when quoteCharacter is null", 
                                                                                               format.isQuoteCharacterSet());
                                                                                }

    @Test
                                                                                public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNotNull() {
                                                                                    // Create a CSVFormat instance with non-null quote character
                                                                                    CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                                               .withQuote('"')   // quoteChar
                                                                                                               .withRecordSeparator("\r\n"); // recordSeparator
                                                                                    
                                                                                    assertTrue("Should return true when quoteCharacter is not null", 
                                                                                              format.isQuoteCharacterSet());
                                                                                }

    @Test
                                                                            public void testPrint_WithDefaultFormat() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                // Arrange
                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                StringWriter writer = new StringWriter();
                                                                                
                                                                                // Act
                                                                                CSVPrinter printer = format.print(writer);
                                                                                
                                                                                // Assert
                                                                                assertNotNull(printer);
                                                                                
                                                                                // Use reflection to access private format field
                                                                                Field formatField = CSVPrinter.class.getDeclaredField("format");
                                                                                formatField.setAccessible(true);
                                                                                CSVFormat actualFormat = (CSVFormat) formatField.get(printer);
                                                                                assertEquals(format, actualFormat);
                                                                                
                                                                                assertSame(writer, printer.getOut());
                                                                            }

    @Test
                                                                            public void testPrint_WithMockAppendable() throws IOException {
                                                                                // Arrange
                                                                                CSVFormat format = CSVFormat.EXCEL;
                                                                                Appendable mockAppendable = mock(Appendable.class);
                                                                                
                                                                                // Act
                                                                                CSVPrinter printer = format.print(mockAppendable);
                                                                                
                                                                                // Assert
                                                                                assertNotNull(printer);
                                                                                // Verify the printer was created with the correct Appendable
                                                                                assertSame(mockAppendable, printer.getOut());
                                                                            }

    @Test
                                                                            public void testValidate_LineBreakDelimiter() {
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("The delimiter cannot be a line break");
                                                                                
                                                                                // Create format with line break as delimiter using public factory method
                                                                                CSVFormat.newFormat('\n');
                                                                            }

    @Test
                                                                            public void testValidate_DelimiterEqualsQuoteChar() {
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("The quoteChar character and the delimiter cannot be the same ('\"')");
                                                                                
                                                                                // Create format with delimiter same as quote character using public methods
                                                                                CSVFormat format = CSVFormat.newFormat('"').withQuote('"');
                                                                                // The validation happens when we try to modify the format
                                                                            }

    @Test
                                                                            public void testValidate_DelimiterEqualsCommentMarker() {
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("The comment start character and the delimiter cannot be the same ('#')");
                                                                                
                                                                                // Create format with delimiter same as comment marker using builder methods
                                                                                CSVFormat.newFormat('#').withCommentMarker('#');
                                                                            }

    @Test
                                                                            public void testValidate_EscapeCharEqualsCommentMarker() {
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("The comment start and the escape character cannot be the same ('*')");
                                                                                
                                                                                // Create format with escape character same as comment marker using builder pattern
                                                                                CSVFormat.newFormat(',')
                                                                                         .withEscape('*')
                                                                                         .withCommentMarker('*');
                                                                            }

    @Test
                                                                            public void testValidate_NoEscapeWithQuoteModeNone() {
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("No quotes mode set but no escape character is set");
                                                                                
                                                                                // Create format with QuoteMode.NONE and no escape character using builder pattern
                                                                                CSVFormat.newFormat(',')
                                                                                         .withQuoteMode(QuoteMode.NONE)
                                                                                         .withQuote(null)
                                                                                         .withEscape(null);
                                                                            }

    @Test
                                                                            public void testValidate_ValidConfiguration() {
                                                                                // This should not throw any exceptions
                                                                                String[] headers = {"id", "name", "age"};
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote('"')
                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                    .withCommentMarker('#')
                                                                                    .withEscape('\\')
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withHeader(headers)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Verify some properties to ensure the object was created correctly
                                                                                assertEquals(',', format.getDelimiter());
                                                                                assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                assertArrayEquals(headers, format.getHeader());
                                                                            }

    @Test
                                                                            public void testValidate_EmptyHeader() {
                                                                                // Empty header should be allowed
                                                                                String[] emptyHeaders = {};
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(null)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator(null)
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(null)
                                                                                    .withHeader(emptyHeaders)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertArrayEquals(emptyHeaders, format.getHeader());
                                                                            }

    @Test
                                                                            public void testWithDelimiter_ValidDelimiters() {
                                                                                // Setup original format with various properties using builder pattern
                                                                                CSVFormat original = CSVFormat.DEFAULT
                                                                                    .withDelimiter(',')
                                                                                    .withQuote('"')
                                                                                    .withQuoteMode(QuoteMode.ALL)
                                                                                    .withCommentMarker('#')
                                                                                    .withEscape('\\')
                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString("NULL")
                                                                                    .withHeaderComments("HeaderComment")
                                                                                    .withHeader("Header1", "Header2")
                                                                                    .withSkipHeaderRecord(true)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(true);
                                                                                
                                                                                // Test with various valid delimiters
                                                                                char[] validDelimiters = {'|', '\t', ';', ':'};
                                                                                
                                                                                for (char delimiter : validDelimiters) {
                                                                                    CSVFormat newFormat = original.withDelimiter(delimiter);
                                                                                    
                                                                                    // Assert new delimiter is set
                                                                                    assertEquals(delimiter, newFormat.getDelimiter());
                                                                                    
                                                                                    // Assert all other properties remain unchanged
                                                                                    assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                    assertEquals(original.getQuoteMode(), newFormat.getQuoteMode());
                                                                                    assertEquals(original.getCommentMarker(), newFormat.getCommentMarker());
                                                                                    assertEquals(original.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                    assertEquals(original.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                    assertEquals(original.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                    assertEquals(original.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                    assertEquals(original.getNullString(), newFormat.getNullString());
                                                                                    assertArrayEquals(original.getHeaderComments(), newFormat.getHeaderComments());
                                                                                    assertArrayEquals(original.getHeader(), newFormat.getHeader());
                                                                                    assertEquals(original.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                    assertEquals(original.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                    assertEquals(original.getIgnoreHeaderCase(), newFormat.getIgnoreHeaderCase());
                                                                                }
                                                                            }

    @Test
                                                                            public void testWithHeader_ResultSet_NullResultSet() {
                                                                                // Setup
                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                
                                                                                // Test
                                                                                
                                                                                // Verify
                                                                            }

    @Test
                                                                            public void testWithAllowMissingColumnNames_True1() {
                                                                                // Setup original CSVFormat with allowMissingColumnNames = false using builder pattern
                                                                                CSVFormat original = CSVFormat.DEFAULT
                                                                                    .withDelimiter(',')
                                                                                    .withQuote('"')
                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                    .withCommentMarker('#')
                                                                                    .withEscape('\\')
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\n")
                                                                                    .withNullString("NULL")
                                                                                    .withHeaderComments("comment")
                                                                                    .withHeader("header1", "header2")
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withIgnoreHeaderCase(false)
                                                                                    .withAllowMissingColumnNames(false);
                                                                                
                                                                                // Call method under test
                                                                                CSVFormat modified = original.withAllowMissingColumnNames(true);
                                                                                
                                                                                // Verify new instance has allowMissingColumnNames = true
                                                                                assertTrue(modified.getAllowMissingColumnNames());
                                                                                
                                                                                // Verify all other properties remain the same
                                                                                assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                assertEquals(original.getNullString(), modified.getNullString());
                                                                                assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                            }

    @Test
                                                                            public void testWithAllowMissingColumnNames_False1() {
                                                                                // Setup original CSVFormat with allowMissingColumnNames = true using builder pattern
                                                                                CSVFormat original = CSVFormat.newFormat('\t')
                                                                                        .withQuote('\'')
                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                        .withCommentMarker('!')
                                                                                        .withEscape('|')
                                                                                        .withIgnoreSurroundingSpaces(true)
                                                                                        .withIgnoreEmptyLines(true)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString("NA")
                                                                                        .withHeaderComments("note")
                                                                                        .withHeader("col1", "col2")
                                                                                        .withSkipHeaderRecord(true)
                                                                                        .withIgnoreHeaderCase(true)
                                                                                        .withAllowMissingColumnNames(true);
                                                                                
                                                                                // Call method under test
                                                                                CSVFormat modified = original.withAllowMissingColumnNames(false);
                                                                                
                                                                                // Verify new instance has allowMissingColumnNames = false
                                                                                assertFalse(modified.getAllowMissingColumnNames());
                                                                                
                                                                                // Verify all other properties remain the same
                                                                                assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                assertEquals(original.getNullString(), modified.getNullString());
                                                                                assertArrayEquals(original.getHeaderComments(), modified.getHeaderComments());
                                                                                assertArrayEquals(original.getHeader(), modified.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                            }

    @Test
                                                                            public void testWithAllowMissingColumnNames_NoParameter1() {
                                                                                // Setup original CSVFormat with allowMissingColumnNames = false
                                                                                CSVFormat original = CSVFormat.DEFAULT
                                                                                    .withDelimiter(';')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments((Object[])null)
                                                                                    .withHeader((String[])null)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Call method under test (no-arg version)
                                                                                CSVFormat modified = original.withAllowMissingColumnNames();
                                                                                
                                                                                // Verify new instance has allowMissingColumnNames = true
                                                                                assertTrue(modified.getAllowMissingColumnNames());
                                                                                
                                                                                // Verify all other properties remain the same
                                                                                assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                assertNull(modified.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                                                assertNull(modified.getCommentMarker());
                                                                                assertNull(modified.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified.getIgnoreEmptyLines());
                                                                                assertEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                assertNull(modified.getNullString());
                                                                                assertNull(modified.getHeaderComments());
                                                                                assertNull(modified.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified.getSkipHeaderRecord());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified.getIgnoreHeaderCase());
                                                                            }

    @Test
                                                                            public void testWithAllowMissingColumnNames_NullHeader() {
                                                                                // Setup original CSVFormat with null header using public factory method
                                                                                CSVFormat original = CSVFormat.newFormat(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments(null)
                                                                                        .withHeader((String[]) null)
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withIgnoreHeaderCase(false)
                                                                                        .withAllowMissingColumnNames(false);
                                                                                
                                                                                // Call method under test
                                                                                CSVFormat modified = original.withAllowMissingColumnNames(true);
                                                                                
                                                                                // Verify properties
                                                                                assertTrue(modified.getAllowMissingColumnNames());
                                                                                assertNull(modified.getHeader());
                                                                            }

    @Test
                                                                            public void testWithIgnoreHeaderCase_True1() {
                                                                                // Setup original CSVFormat with all possible parameters
                                                                                char delimiter = ',';
                                                                                Character quoteCharacter = '"';
                                                                                QuoteMode quoteMode = QuoteMode.ALL;
                                                                                Character commentMarker = '#';
                                                                                Character escapeCharacter = '\\';
                                                                                boolean ignoreSurroundingSpaces = true;
                                                                                boolean ignoreEmptyLines = true;
                                                                                String recordSeparator = "\n";
                                                                                String nullString = "NULL";
                                                                                String[] headerComments = {"Comment1", "Comment2"};
                                                                                String[] header = {"Name", "Age"};
                                                                                boolean skipHeaderRecord = false;
                                                                                boolean allowMissingColumnNames = true;
                                                                                boolean originalIgnoreHeaderCase = false;
                                                                                
                                                                                // Create CSVFormat using builder pattern
                                                                                CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                        .withQuote(quoteCharacter)
                                                                                        .withQuoteMode(quoteMode)
                                                                                        .withCommentMarker(commentMarker)
                                                                                        .withEscape(escapeCharacter)
                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                        .withRecordSeparator(recordSeparator)
                                                                                        .withNullString(nullString)
                                                                                        .withHeaderComments(headerComments)
                                                                                        .withHeader(header)
                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                        .withIgnoreHeaderCase(originalIgnoreHeaderCase);
                                                                                
                                                                                // Test with true
                                                                                CSVFormat modified = original.withIgnoreHeaderCase(true);
                                                                                
                                                                                // Verify all properties except ignoreHeaderCase remain the same
                                                                                assertEquals(delimiter, modified.getDelimiter());
                                                                                assertEquals(quoteCharacter, modified.getQuoteCharacter());
                                                                                assertEquals(quoteMode, modified.getQuoteMode());
                                                                                assertEquals(commentMarker, modified.getCommentMarker());
                                                                                assertEquals(escapeCharacter, modified.getEscapeCharacter());
                                                                                assertEquals(ignoreSurroundingSpaces, modified.getIgnoreSurroundingSpaces());
                                                                                assertEquals(ignoreEmptyLines, modified.getIgnoreEmptyLines());
                                                                                assertEquals(recordSeparator, modified.getRecordSeparator());
                                                                                assertEquals(nullString, modified.getNullString());
                                                                                assertArrayEquals(headerComments, modified.getHeaderComments());
                                                                                assertArrayEquals(header, modified.getHeader());
                                                                                assertEquals(skipHeaderRecord, modified.getSkipHeaderRecord());
                                                                                assertEquals(allowMissingColumnNames, modified.getAllowMissingColumnNames());
                                                                                
                                                                                // Verify ignoreHeaderCase is updated
                                                                                assertTrue(modified.getIgnoreHeaderCase());
                                                                            }

    @Test
                                                                            public void testWithIgnoreHeaderCase_False1() {
                                                                                // Setup original CSVFormat with all possible parameters
                                                                                char delimiter = ';';
                                                                                Character quoteCharacter = '\'';
                                                                                QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                Character commentMarker = '!';
                                                                                Character escapeCharacter = '/';
                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                boolean ignoreEmptyLines = false;
                                                                                String recordSeparator = "\r\n";
                                                                                String nullString = "NA";
                                                                                String[] headerComments = {"Header1"};
                                                                                String[] header = {"ID", "Value"};
                                                                                boolean skipHeaderRecord = true;
                                                                                boolean allowMissingColumnNames = false;
                                                                                boolean originalIgnoreHeaderCase = true;
                                                                                
                                                                                // Create CSVFormat using builder pattern
                                                                                CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                        .withQuote(quoteCharacter)
                                                                                        .withQuoteMode(quoteMode)
                                                                                        .withCommentMarker(commentMarker)
                                                                                        .withEscape(escapeCharacter)
                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                        .withRecordSeparator(recordSeparator)
                                                                                        .withNullString(nullString)
                                                                                        .withHeaderComments(headerComments)
                                                                                        .withHeader(header)
                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames)
                                                                                        .withIgnoreHeaderCase(originalIgnoreHeaderCase);
                                                                                
                                                                                // Test with false
                                                                                CSVFormat modified = original.withIgnoreHeaderCase(false);
                                                                                
                                                                                // Verify all properties except ignoreHeaderCase remain the same
                                                                                assertEquals(delimiter, modified.getDelimiter());
                                                                                assertEquals(quoteCharacter, modified.getQuoteCharacter());
                                                                                assertEquals(quoteMode, modified.getQuoteMode());
                                                                                assertEquals(commentMarker, modified.getCommentMarker());
                                                                                assertEquals(escapeCharacter, modified.getEscapeCharacter());
                                                                                assertEquals(ignoreSurroundingSpaces, modified.getIgnoreSurroundingSpaces());
                                                                                assertEquals(ignoreEmptyLines, modified.getIgnoreEmptyLines());
                                                                                assertEquals(recordSeparator, modified.getRecordSeparator());
                                                                                assertEquals(nullString, modified.getNullString());
                                                                                assertArrayEquals(headerComments, modified.getHeaderComments());
                                                                                assertArrayEquals(header, modified.getHeader());
                                                                                assertEquals(skipHeaderRecord, modified.getSkipHeaderRecord());
                                                                                assertEquals(allowMissingColumnNames, modified.getAllowMissingColumnNames());
                                                                                
                                                                                // Verify ignoreHeaderCase is updated
                                                                                assertFalse(modified.getIgnoreHeaderCase());
                                                                            }

    @Test
                                                                            public void testWithRecordSeparator_String() {
                                                                                // Setup initial format with various properties
                                                                                CSVFormat original = CSVFormat.DEFAULT
                                                                                    .withDelimiter(';')
                                                                                    .withQuote('"')
                                                                                    .withQuoteMode(QuoteMode.ALL)
                                                                                    .withCommentMarker('#')
                                                                                    .withEscape('\\')
                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withNullString("NULL")
                                                                                    .withHeader("Col1", "Col2")
                                                                                    .withHeaderComments("HeaderComment")
                                                                                    .withSkipHeaderRecord(true)
                                                                                    .withAllowMissingColumnNames(true)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Test with different record separators
                                                                                String recordSeparator1 = "\r\n";
                                                                                CSVFormat modified1 = original.withRecordSeparator(recordSeparator1);
                                                                                assertEquals(recordSeparator1, modified1.getRecordSeparator());
                                                                                assertEquals(original.getDelimiter(), modified1.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified1.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified1.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified1.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified1.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified1.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified1.getIgnoreEmptyLines());
                                                                                assertEquals(original.getNullString(), modified1.getNullString());
                                                                                assertArrayEquals(original.getHeader(), modified1.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified1.getSkipHeaderRecord());
                                                                                assertEquals(original.getAllowMissingColumnNames(), modified1.getAllowMissingColumnNames());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified1.getIgnoreHeaderCase());
                                                                            
                                                                                String recordSeparator2 = "\n";
                                                                                CSVFormat modified2 = original.withRecordSeparator(recordSeparator2);
                                                                                assertEquals(recordSeparator2, modified2.getRecordSeparator());
                                                                                assertEquals(original.getDelimiter(), modified2.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified2.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified2.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified2.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified2.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified2.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified2.getIgnoreEmptyLines());
                                                                                assertEquals(original.getNullString(), modified2.getNullString());
                                                                                assertArrayEquals(original.getHeader(), modified2.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified2.getSkipHeaderRecord());
                                                                                assertEquals(original.getAllowMissingColumnNames(), modified2.getAllowMissingColumnNames());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified2.getIgnoreHeaderCase());
                                                                            
                                                                                String recordSeparator3 = "|";
                                                                                CSVFormat modified3 = original.withRecordSeparator(recordSeparator3);
                                                                                assertEquals(recordSeparator3, modified3.getRecordSeparator());
                                                                                assertEquals(original.getDelimiter(), modified3.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified3.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified3.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified3.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified3.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified3.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified3.getIgnoreEmptyLines());
                                                                                assertEquals(original.getNullString(), modified3.getNullString());
                                                                                assertArrayEquals(original.getHeader(), modified3.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified3.getSkipHeaderRecord());
                                                                                assertEquals(original.getAllowMissingColumnNames(), modified3.getAllowMissingColumnNames());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified3.getIgnoreHeaderCase());
                                                                            
                                                                                // Test with empty string
                                                                                String recordSeparator4 = "";
                                                                                CSVFormat modified4 = original.withRecordSeparator(recordSeparator4);
                                                                                assertEquals(recordSeparator4, modified4.getRecordSeparator());
                                                                                assertEquals(original.getDelimiter(), modified4.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified4.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified4.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified4.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified4.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified4.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified4.getIgnoreEmptyLines());
                                                                                assertEquals(original.getNullString(), modified4.getNullString());
                                                                                assertArrayEquals(original.getHeader(), modified4.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified4.getSkipHeaderRecord());
                                                                                assertEquals(original.getAllowMissingColumnNames(), modified4.getAllowMissingColumnNames());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified4.getIgnoreHeaderCase());
                                                                            
                                                                                // Test with null (should be allowed)
                                                                                CSVFormat modified5 = original.withRecordSeparator((String) null);
                                                                                assertNull(modified5.getRecordSeparator());
                                                                                assertEquals(original.getDelimiter(), modified5.getDelimiter());
                                                                                assertEquals(original.getQuoteCharacter(), modified5.getQuoteCharacter());
                                                                                assertEquals(original.getQuoteMode(), modified5.getQuoteMode());
                                                                                assertEquals(original.getCommentMarker(), modified5.getCommentMarker());
                                                                                assertEquals(original.getEscapeCharacter(), modified5.getEscapeCharacter());
                                                                                assertEquals(original.getIgnoreSurroundingSpaces(), modified5.getIgnoreSurroundingSpaces());
                                                                                assertEquals(original.getIgnoreEmptyLines(), modified5.getIgnoreEmptyLines());
                                                                                assertEquals(original.getNullString(), modified5.getNullString());
                                                                                assertArrayEquals(original.getHeader(), modified5.getHeader());
                                                                                assertEquals(original.getSkipHeaderRecord(), modified5.getSkipHeaderRecord());
                                                                                assertEquals(original.getAllowMissingColumnNames(), modified5.getAllowMissingColumnNames());
                                                                                assertEquals(original.getIgnoreHeaderCase(), modified5.getIgnoreHeaderCase());
                                                                            }

    @Test
                                                                            public void testWithRecordSeparator_Char() {
                                                                                // Setup initial format
                                                                                CSVFormat original = CSVFormat.EXCEL
                                                                                    .withDelimiter('\t')
                                                                                    .withQuote('\'')
                                                                                    .withIgnoreHeaderCase(true);
                                                                                
                                                                                // Helper method to compare properties except record separator
                                                                                java.util.function.BiConsumer<CSVFormat, CSVFormat> assertSamePropertiesExceptRecordSeparator = (expected, actual) -> {
                                                                                    assertEquals(expected.getDelimiter(), actual.getDelimiter());
                                                                                    assertEquals(expected.getQuoteCharacter(), actual.getQuoteCharacter());
                                                                                    assertEquals(expected.getQuoteMode(), actual.getQuoteMode());
                                                                                    assertEquals(expected.getCommentMarker(), actual.getCommentMarker());
                                                                                    assertEquals(expected.getEscapeCharacter(), actual.getEscapeCharacter());
                                                                                    assertEquals(expected.getIgnoreSurroundingSpaces(), actual.getIgnoreSurroundingSpaces());
                                                                                    assertEquals(expected.getIgnoreEmptyLines(), actual.getIgnoreEmptyLines());
                                                                                    assertEquals(expected.getNullString(), actual.getNullString());
                                                                                    assertArrayEquals(expected.getHeaderComments(), actual.getHeaderComments());
                                                                                    assertArrayEquals(expected.getHeader(), actual.getHeader());
                                                                                    assertEquals(expected.getSkipHeaderRecord(), actual.getSkipHeaderRecord());
                                                                                    assertEquals(expected.getAllowMissingColumnNames(), actual.getAllowMissingColumnNames());
                                                                                    assertEquals(expected.getIgnoreHeaderCase(), actual.getIgnoreHeaderCase());
                                                                                };
                                                                            
                                                                                // Test with different record separator characters
                                                                                char recordSeparator1 = '\n';
                                                                                CSVFormat modified1 = original.withRecordSeparator(recordSeparator1);
                                                                                assertEquals(String.valueOf(recordSeparator1), modified1.getRecordSeparator());
                                                                                assertSamePropertiesExceptRecordSeparator.accept(original, modified1);
                                                                            
                                                                                char recordSeparator2 = '\r';
                                                                                CSVFormat modified2 = original.withRecordSeparator(recordSeparator2);
                                                                                assertEquals(String.valueOf(recordSeparator2), modified2.getRecordSeparator());
                                                                                assertSamePropertiesExceptRecordSeparator.accept(original, modified2);
                                                                            
                                                                                char recordSeparator3 = '|';
                                                                                CSVFormat modified3 = original.withRecordSeparator(recordSeparator3);
                                                                                assertEquals(String.valueOf(recordSeparator3), modified3.getRecordSeparator());
                                                                                assertSamePropertiesExceptRecordSeparator.accept(original, modified3);
                                                                            }

    @Test
                                                                            public void testIsLineBreak_WithLineFeed() throws Exception {
                                                                                final char LF = '\n';
                                                                                Class<?> csvFormatClass = Class.forName("org.apache.commons.csv.CSVFormat");
                                                                                Method isLineBreakMethod = csvFormatClass.getDeclaredMethod("isLineBreak", char.class);
                                                                                isLineBreakMethod.setAccessible(true);
                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, LF);
                                                                                assertTrue(result);
                                                                            }

    @Test
                                                                            public void testIsLineBreak_WithCarriageReturn() throws Exception {
                                                                                final char CR = '\r';
                                                                                Class<?> csvFormatClass = Class.forName("org.apache.commons.csv.CSVFormat");
                                                                                Method isLineBreakMethod = csvFormatClass.getDeclaredMethod("isLineBreak", char.class);
                                                                                isLineBreakMethod.setAccessible(true);
                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, CR);
                                                                                assertTrue(result);
                                                                            }

    @Test
                                                                            public void testIsLineBreak_WithCombinedLineEndings() throws Exception {
                                                                                // Define line ending characters
                                                                                final char CR = '\r'; // Carriage Return
                                                                                final char LF = '\n'; // Line Feed
                                                                                
                                                                                // Get the private isLineBreak method via reflection
                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                isLineBreakMethod.setAccessible(true);
                                                                                
                                                                                // Test combined line endings (Windows style)
                                                                                assertTrue((boolean) isLineBreakMethod.invoke(null, CR));
                                                                                assertTrue((boolean) isLineBreakMethod.invoke(null, LF));
                                                                                // The method checks individual characters, so combined CRLF would be checked separately
                                                                            }

    @Test
                                                                            public void testGetCommentMarker_WhenCommentMarkerIsNull() {
                                                                                // Arrange
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote('"')
                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape('\\')
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(null)
                                                                                    .withHeader((String[]) null)  // Explicitly cast to String array
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Act
                                                                                Character actualCommentMarker = format.getCommentMarker();
                                                                                
                                                                                // Assert
                                                                                assertNull(actualCommentMarker);
                                                                            }

    @Test
                                                                            public void testGetCommentMarker_AfterModificationWithWithCommentMarker() {
                                                                                // Arrange
                                                                                Character initialCommentMarker = '#';
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote('"')
                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                    .withCommentMarker(initialCommentMarker)
                                                                                    .withEscape('\\')
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(null)
                                                                                    .withHeader((String[]) null)  // Explicitly cast null to String[]
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Act - Modify the comment marker
                                                                                Character newCommentMarker = ';';
                                                                                CSVFormat modifiedFormat = format.withCommentMarker(newCommentMarker);
                                                                                
                                                                                // Assert
                                                                                assertEquals(newCommentMarker, modifiedFormat.getCommentMarker());
                                                                                // Original format should remain unchanged
                                                                                assertEquals(initialCommentMarker, format.getCommentMarker());
                                                                            }

    @Test
                                                                            public void testGetEscapeCharacter_WhenEscapeCharacterIsSet() {
                                                                                // Arrange
                                                                                Character expectedEscape = '\\';
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote('"')
                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                        .withCommentMarker('#')
                                                                                        .withEscape(expectedEscape)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString(null)
                                                                                        .withHeaderComments(null)
                                                                                        .withHeader((String) null)  // Explicitly cast to String
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Act
                                                                                Character actualEscape = format.getEscapeCharacter();
                                                                                
                                                                                // Assert
                                                                                assertEquals(expectedEscape, actualEscape);
                                                                            }

    @Test
                                                                            public void testGetHeaderComments_VerifyCloneNotAffectingOriginal() {
                                                                                // Arrange
                                                                                String[] originalComments = {"Original"};
                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                    .withDelimiter(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(null)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(originalComments)
                                                                                    .withHeader((String[]) null)  // Explicitly cast to String[]
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                // Act
                                                                                String[] result = format.getHeaderComments();
                                                                                result[0] = "Modified";
                                                                                
                                                                                // Assert
                                                                                assertEquals("Original", originalComments[0]); // Original unchanged
                                                                                assertEquals("Modified", result[0]); // Clone was modified
                                                                            }

    @Test
                                                                            public void testGetNullString_WhenNullStringIsNull() {
                                                                                // Create a CSVFormat instance with nullString set to null using builder pattern
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(null)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertNull(format.getNullString());
                                                                            }

    @Test
                                                                            public void testGetNullString_WhenNullStringIsEmpty() {
                                                                                // Create a CSVFormat instance with empty nullString using builder pattern
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString("")
                                                                                    .withHeaderComments(null)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertEquals("", format.getNullString());
                                                                            }

    @Test
                                                                            public void testIsCommentMarkerSet_WhenCommentMarkerIsNull() {
                                                                                // Create format with null comment marker using builder pattern
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(null)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(null)
                                                                                    .withHeader((String[]) null)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertFalse("Should return false when commentMarker is null", 
                                                                                           format.isCommentMarkerSet());
                                                                            }

    @Test
                                                                            public void testIsNullStringSet_WhenNullStringIsNull() {
                                                                                // Create a CSVFormat instance with nullString set to null
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(null)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString(null)
                                                                                    .withHeaderComments(null)
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertFalse("Should return false when nullString is null", 
                                                                                           format.isNullStringSet());
                                                                            }

    @Test
                                                                            public void testIsNullStringSet_WhenNullStringIsEmptyString() {
                                                                                // Create a CSVFormat instance with nullString set to empty string
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                    .withQuote(null)
                                                                                    .withQuoteMode(null)
                                                                                    .withCommentMarker(null)
                                                                                    .withEscape(null)
                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                    .withIgnoreEmptyLines(false)
                                                                                    .withRecordSeparator("\r\n")
                                                                                    .withNullString("")
                                                                                    .withHeaderComments(null)
                                                                                    .withHeader((String[])null)  // Explicitly cast to String[]
                                                                                    .withSkipHeaderRecord(false)
                                                                                    .withAllowMissingColumnNames(false)
                                                                                    .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertTrue("Should return true when nullString is empty string", 
                                                                                           format.isNullStringSet());
                                                                            }

    @Test
                                                                            public void testIsNullStringSet_WhenNullStringIsNonEmptyString() {
                                                                                // Create a CSVFormat instance with nullString set to "NULL"
                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                        .withQuote(null)
                                                                                        .withQuoteMode(null)
                                                                                        .withCommentMarker(null)
                                                                                        .withEscape(null)
                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                        .withIgnoreEmptyLines(false)
                                                                                        .withRecordSeparator("\r\n")
                                                                                        .withNullString("NULL")
                                                                                        .withHeaderComments(null)
                                                                                        .withHeader((String[]) null)  // Explicitly cast null to String[]
                                                                                        .withSkipHeaderRecord(false)
                                                                                        .withAllowMissingColumnNames(false)
                                                                                        .withIgnoreHeaderCase(false);
                                                                                
                                                                                assertTrue("Should return true when nullString is non-empty string", 
                                                                                           format.isNullStringSet());
                                                                            }

    @Test
                                                                            public void testParse_WithEmptyReader() throws IOException {
                                                                                // Setup
                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                java.io.Reader reader = new java.io.StringReader("");
                                                                                
                                                                                // Execute
                                                                                CSVParser parser = format.parse(reader);
                                                                                
                                                                                // Verify
                                                                                assertNotNull(parser);
                                                                                
                                                                                // Cleanup
                                                                                parser.close();
                                                                            }

    @Test
                                                                        public void testPrint_WithDifferentFormatVariants() throws IOException {
                                                                            // Test with various format configurations
                                                                            // Create DEFAULT format (comma delimiter, double quote quotes)
                                                                            CSVFormat defaultFormat = CSVFormat.newFormat(',').withQuote('"');
                                                                            
                                                                            // Create RFC4180 format (similar to DEFAULT but with CRLF record separator)
                                                                            CSVFormat rfc4180Format = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n");
                                                                            
                                                                            // Create EXCEL format (similar to DEFAULT but handling nulls differently)
                                                                            CSVFormat excelFormat = CSVFormat.newFormat(',').withQuote('"').withNullString("");
                                                                            
                                                                            // Create TDF format (tab delimiter)
                                                                            CSVFormat tdfFormat = CSVFormat.newFormat('\t').withQuote('"');
                                                                            
                                                                            // Create MYSQL format (tab delimiter, escaped quotes, null as \N)
                                                                            CSVFormat mysqlFormat = CSVFormat.newFormat('\t').withEscape('\\').withNullString("\\N");
                                                                            
                                                                            // Test with all created formats by printing sample data
                                                                            StringWriter writer = new StringWriter();
                                                                            CSVPrinter printer = defaultFormat.print(writer);
                                                                            printer.print("test");
                                                                            printer.close();
                                                                            assertEquals("\"test\"", writer.toString().trim());
                                                                            
                                                                            writer = new StringWriter();
                                                                            printer = rfc4180Format.print(writer);
                                                                            printer.print("test");
                                                                            printer.close();
                                                                            assertEquals("\"test\"", writer.toString().trim());
                                                                            
                                                                            writer = new StringWriter();
                                                                            printer = excelFormat.print(writer);
                                                                            printer.print("test");
                                                                            printer.close();
                                                                            assertEquals("\"test\"", writer.toString().trim());
                                                                            
                                                                            writer = new StringWriter();
                                                                            printer = tdfFormat.print(writer);
                                                                            printer.print("test");
                                                                            printer.close();
                                                                            assertEquals("\"test\"", writer.toString().trim());
                                                                            
                                                                            writer = new StringWriter();
                                                                            printer = mysqlFormat.print(writer);
                                                                            printer.print("test");
                                                                            printer.close();
                                                                            assertEquals("\"test\"", writer.toString().trim());
                                                                        }

    @Test
                                                                        public void testValidate_DelimiterEqualsEscapeChar() {
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            thrown.expectMessage("The escape character and the delimiter cannot be the same ('\\')");
                                                                            
                                                                            // Create format with delimiter same as escape character
                                                                            // This will trigger validation in the constructor
                                                                            CSVFormat.newFormat('\\').withEscape('\\');
                                                                        }

    @Test
                                                                        public void testValidate_DuplicateHeader() {
                                                                            thrown.expect(IllegalArgumentException.class);
                                                                            thrown.expectMessage("The header contains a duplicate entry: 'name' in [name, age, name]");
                                                                            
                                                                            // Create format with duplicate header entries
                                                                            String[] headers = {"name", "age", "name"};
                                                                            CSVFormat.newFormat(',')
                                                                                     .withHeader(headers);
                                                                            // Validation happens automatically during construction
                                                                        }

    @Test
                                                                        public void testFormat_ThrowsIllegalStateExceptionOnIOError() throws Exception {
                                                                            // Test that IllegalStateException is thrown when IOException occurs
                                                                            thrown.expect(IllegalStateException.class);
                                                                            
                                                                            // Create a mock Appendable that throws IOException
                                                                            Appendable failingWriter = mock(Appendable.class);
                                                                            doThrow(new IOException("Simulated IO error")).when(failingWriter).append(anyChar());
                                                                            
                                                                            // Create a CSVFormat with default settings
                                                                            CSVFormat format = CSVFormat.DEFAULT;
                                                                            
                                                                            Object[] values = {"value1", "value2"};
                                                                            
                                                                            // This should trigger the exception when trying to write to failingWriter
                                                                            format.print(failingWriter).print(values);
                                                                        }

    @Test
                                                                        public void testHashCode_NullFields() {
                                                                            // Test with all nullable fields set to null
                                                                            org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(',')
                                                                                .withQuote(null)
                                                                                .withQuoteMode(null)
                                                                                .withCommentMarker(null)
                                                                                .withEscape(null)
                                                                                .withNullString(null)
                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                .withIgnoreHeaderCase(false)
                                                                                .withIgnoreEmptyLines(false)
                                                                                .withSkipHeaderRecord(false)
                                                                                .withRecordSeparator(null)
                                                                                .withHeader((String[]) null);
                                                                            
                                                                            int expectedHash = 31 * (31 + ',');
                                                                            expectedHash = 31 * expectedHash + 0; // quoteMode = null
                                                                            expectedHash = 31 * expectedHash + 0; // quoteCharacter = null
                                                                            expectedHash = 31 * expectedHash + 0; // commentMarker = null
                                                                            expectedHash = 31 * expectedHash + 0; // escapeCharacter = null
                                                                            expectedHash = 31 * expectedHash + 0; // nullString = null
                                                                            expectedHash = 31 * expectedHash + 1237; // ignoreSurroundingSpaces = false
                                                                            expectedHash = 31 * expectedHash + 1237; // ignoreHeaderCase = false
                                                                            expectedHash = 31 * expectedHash + 1237; // ignoreEmptyLines = false
                                                                            expectedHash = 31 * expectedHash + 1237; // skipHeaderRecord = false
                                                                            expectedHash = 31 * expectedHash + 0; // recordSeparator = null
                                                                            expectedHash = 31 * expectedHash + 0; // header = null
                                                                            
                                                                            assertEquals(expectedHash, format.hashCode());
                                                                        }

    @Test
                                                                    public void testWithAllowMissingColumnNames_Chaining() {
                                                                        // Setup
                                                                        CSVFormat originalFormat = CSVFormat.DEFAULT;
                                                                        
                                                                        // Execute and Verify
                                                                        CSVFormat newFormat = originalFormat
                                                                            .withAllowMissingColumnNames()
                                                                            .withDelimiter(';')
                                                                            .withQuote('"');
                                                                        
                                                                        assertTrue(newFormat.getAllowMissingColumnNames());
                                                                        assertEquals(';', newFormat.getDelimiter());
                                                                        assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                    }

    @Test
                                        public void testWithIgnoreEmptyLines_FromDifferentInitialState() {
                                            // Test with different initial formats
                                            CSVFormat defaultFormat = CSVFormat.newFormat(',').withIgnoreEmptyLines(true);
                                            assertTrue(defaultFormat.getIgnoreEmptyLines());
                                            
                                            CSVFormat rfc4180Format = CSVFormat.newFormat(',')
                                                .withQuote('"')
                                                .withRecordSeparator("\r\n")
                                                .withIgnoreEmptyLines(true);
                                            assertTrue(rfc4180Format.getIgnoreEmptyLines());
                                            
                                            CSVFormat excelFormat = CSVFormat.newFormat(',')
                                                .withQuote('"')
                                                .withNullString("")
                                                .withIgnoreEmptyLines(true);
                                            assertTrue(excelFormat.getIgnoreEmptyLines());
                                            
                                            CSVFormat tdfFormat = CSVFormat.newFormat('\t')
                                                .withIgnoreEmptyLines(true);
                                            assertTrue(tdfFormat.getIgnoreEmptyLines());
                                            
                                            CSVFormat mysqlFormat = CSVFormat.newFormat('\t')
                                                .withEscape('\\')
                                                .withNullString("\\N")
                                                .withIgnoreEmptyLines(true);
                                            assertTrue(mysqlFormat.getIgnoreEmptyLines());
                                        }

    @Test
                                    public void testParse_WithClosedReader() throws IOException {
                                        // Setup
                                        org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                        java.io.Reader reader = new java.io.StringReader("test");
                                        reader.close();
                                        
                                        try {
                                            // Execute
                                            format.parse(reader);
                                            org.junit.Assert.fail("Expected IOException to be thrown");
                                        } catch (IOException e) {
                                            // Expected exception
                                            return;
                                        }
                                    }

    @Test
                                    public void testValidate_NullHeader() {
                                        // Null header should be allowed
                                        CSVFormat format = CSVFormat.newFormat(',')
                                            .withQuote(null)
                                            .withQuoteMode(null)
                                            .withCommentMarker(null)
                                            .withEscape(null)
                                            .withIgnoreSurroundingSpaces(false)
                                            .withIgnoreEmptyLines(false)
                                            .withRecordSeparator(null)
                                            .withNullString(null)
                                            .withHeaderComments((Object) null)
                                            .withHeader((String[]) null)
                                            .withIgnoreHeaderCase(false);
                                        
                                        assertNull(format.getHeader());
                                    }

    @Test
                                    public void testParse_WithValidReader() throws IOException {
                                        // Setup
                                        org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                        String input = "header1,header2\nvalue1,value2";
                                        java.io.Reader reader = new java.io.StringReader(input);
                                        
                                        // Execute
                                        org.apache.commons.csv.CSVParser parser = format.parse(reader);
                                        
                                        // Verify
                                        assertNotNull(parser);
                                        // Verify we can read records correctly
                                        assertEquals(2, parser.getRecords().size());
                                        
                                        // Cleanup
                                        parser.close();
                                    }

    @Test
                                public void testWithIgnoreSurroundingSpaces_Chaining() {
                                    // Test method chaining
                                    CSVFormat format = CSVFormat.newFormat(',') // Start with default format
                                        .withIgnoreSurroundingSpaces(true)
                                        .withDelimiter(';')
                                        .withQuote('"');
                                    
                                    assertTrue(format.getIgnoreSurroundingSpaces());
                                    assertEquals(';', format.getDelimiter());
                                    assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                }

    @Test
                        public void testWithCommentMarker_OtherPropertiesPreserved() {
                            // Setup
                            CSVFormat originalFormat = CSVFormat.newFormat(';')
                                .withQuote('"')
                                .withIgnoreSurroundingSpaces(true)
                                .withRecordSeparator("\r\n");
                            Character commentMarker = '#';
                            
                            // Execute
                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                            
                            // Verify
                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                            assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                        }

    @Test
                    public void testValidate_QuoteCharEqualsCommentMarker() {
                        try {
                            // Create format with quote character same as comment marker using builder pattern
                            org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.newFormat(',')
                                .withQuote('!')
                                .withCommentMarker('!');
                            
                            // Use reflection to access the private validate method
                            java.lang.reflect.Method validateMethod = org.apache.commons.csv.CSVFormat.class.getDeclaredMethod("validate");
                            validateMethod.setAccessible(true);
                            validateMethod.invoke(format);
                            
                            fail("Expected IllegalArgumentException to be thrown");
                        } catch (IllegalArgumentException e) {
                            assertEquals("The comment start character and the quoteChar cannot be the same ('!')", e.getMessage());
                        } catch (Exception e) {
                            fail("Unexpected exception: " + e.getClass().getName());
                        }
                    }

    @Test
                public void testWithEscape_PreservesOtherProperties() {
                    // Setup
                    CSVFormat originalFormat = CSVFormat.newFormat(';')
                        .withQuote('\"')
                        .withCommentMarker('#')
                        .withIgnoreSurroundingSpaces(true)
                        .withIgnoreEmptyLines(false)
                        .withRecordSeparator("\r\n")
                        .withNullString("NULL")
                        .withHeader("Header1", "Header2")
                        .withSkipHeaderRecord(true);
                    
                    // Act
                    CSVFormat newFormat = originalFormat.withEscape('\\');
                    
                    // Assert
                    assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                    assertEquals(';', newFormat.getDelimiter());
                    assertEquals(Character.valueOf('\"'), newFormat.getQuoteCharacter());
                    assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                    assertTrue(newFormat.getIgnoreSurroundingSpaces());
                    assertFalse(newFormat.getIgnoreEmptyLines());
                    assertEquals("\r\n", newFormat.getRecordSeparator());
                    assertEquals("NULL", newFormat.getNullString());
                    assertArrayEquals(new String[]{"Header1", "Header2"}, newFormat.getHeader());
                    assertTrue(newFormat.getSkipHeaderRecord());
                }

    @Test
            public void testPrint_WithAllFormatOptions() throws IOException {
                // Arrange
                CSVFormat format = CSVFormat.newFormat('|')
                    .withQuote('\'')
                    .withEscape('\\')
                    .withCommentMarker('#')
                    .withNullString("N/A")
                    .withIgnoreSurroundingSpaces(true)
                    .withIgnoreEmptyLines(true)
                    .withRecordSeparator("\r\n")
                    .withHeader("Col1", "Col2", "Col3")
                    .withSkipHeaderRecord(true)
                    .withIgnoreHeaderCase(true);
                StringWriter writer = new StringWriter();
                
                // Act
                CSVPrinter printer = format.print(writer);
                
                // Assert
                assertNotNull(printer);
                assertSame(writer, printer.getOut());
            }

    @Test
        public void testPrint_WithCustomFormat() throws IOException {
            // Arrange
            CSVFormat format = CSVFormat.newFormat(';')
                .withQuote('"')  // Using char literal instead of String
                .withQuoteMode(QuoteMode.ALL)
                .withNullString("NULL")
                .withIgnoreEmptyLines()
                .withHeader("Name", "Age", "City");
            StringWriter writer = new StringWriter();
            
            // Act
            CSVPrinter printer = format.print(writer);
            
            // Assert
            assertNotNull(printer);
            assertSame(writer, printer.getOut());
        }

    @Test
    public void testParse_WithCustomFormat() throws IOException {
        // Setup
        CSVFormat format = CSVFormat.newFormat(';')
            .withQuote('"')
            .withRecordSeparator("\r\n")
            .withIgnoreEmptyLines(true);
        String input = "header1;header2\r\nvalue1;value2";
        
        // Execute
        
        // Verify
        
        // Verify the parsed records
        
        // Cleanup
    }

    @Test
    public void testParse_WithHeader() throws IOException {
        // Setup
        String[] headers = {"col1", "col2"};
        org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withHeader(headers);
        String input = "value1,value2";
        java.io.Reader reader = new java.io.StringReader(input);
        
        // Execute
        org.apache.commons.csv.CSVParser parser = format.parse(reader);
        
        // Verify
        org.junit.Assert.assertNotNull(parser);
        
        // Cleanup
        parser.close();
    }

    @Test
    public void testParse_WithCommentMarker() throws IOException {
        // Setup
        CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        String input = "# This is a comment\nheader1,header2\nvalue1,value2";
        
        // Execute
        
        // Verify
        
        // Cleanup
    }

    @Test
    public void testParse_WithDifferentFormatConfigurations() throws IOException {
        // Test various format configurations
        org.apache.commons.csv.CSVFormat[] formats = {
            org.apache.commons.csv.CSVFormat.DEFAULT,
            org.apache.commons.csv.CSVFormat.RFC4180,
            org.apache.commons.csv.CSVFormat.EXCEL,
            org.apache.commons.csv.CSVFormat.TDF,
            org.apache.commons.csv.CSVFormat.MYSQL,
            org.apache.commons.csv.CSVFormat.newFormat('|'),
            org.apache.commons.csv.CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true),
            org.apache.commons.csv.CSVFormat.DEFAULT.withNullString("NULL"),
            org.apache.commons.csv.CSVFormat.DEFAULT.withQuoteMode(org.apache.commons.csv.QuoteMode.ALL)
        };
        
        for (org.apache.commons.csv.CSVFormat format : formats) {
            String input = "a,b,c\n1,2,3"; // More complete test input
            java.io.Reader reader = new java.io.StringReader(input);
            
            // Execute
            org.apache.commons.csv.CSVParser parser = format.parse(reader);
            
            // Verify
            org.junit.Assert.assertNotNull(parser);
            
            // Verify the parser implements the format by checking the first record
            org.apache.commons.csv.CSVRecord record = parser.iterator().next();
            org.junit.Assert.assertEquals("1", record.get(0));
            org.junit.Assert.assertEquals("2", record.get(1));
            org.junit.Assert.assertEquals("3", record.get(2));
            
            // Cleanup
            parser.close();
        }
    }


}
