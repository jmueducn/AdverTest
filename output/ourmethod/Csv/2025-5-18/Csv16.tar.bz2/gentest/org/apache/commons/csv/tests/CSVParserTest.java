package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.TreeMap;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                             public void testIterator_ReturnsNonNullIterator() throws IOException {
                                                                                                                                 // Setup
                                                                                                                                 Reader reader = new StringReader("header1,header2\nvalue1,value2");
                                                                                                                                 CSVFormat format = CSVFormat.DEFAULT.withHeader();
                                                                                                                                 CSVParser csvParser = new CSVParser(reader, format);
                                                                                                                                 
                                                                                                                                 // Test
                                                                                                                                 Iterator<CSVRecord> iterator = csvParser.iterator();
                                                                                                                                 
                                                                                                                                 // Verify
                                                                                                                                 assertNotNull("Iterator should not be null", iterator);
                                                                                                                                 
                                                                                                                                 // Cleanup
                                                                                                                                 csvParser.close();
                                                                                                                             }

 @Test
                                                                                                                             public void testIterator_ReturnsSameInstanceOnMultipleCalls() throws IOException {
                                                                                                                                 // Setup test data and parser
                                                                                                                                 String testData = "header1,header2\nvalue1,value2";
                                                                                                                                 Reader reader = new StringReader(testData);
                                                                                                                                 CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
                                                                                                                                 
                                                                                                                                 // Test iterator calls
                                                                                                                                 Iterator<CSVRecord> firstIterator = csvParser.iterator();
                                                                                                                                 Iterator<CSVRecord> secondIterator = csvParser.iterator();
                                                                                                                                 
                                                                                                                                 // Verify same instance is returned
                                                                                                                                 assertSame("Subsequent calls to iterator() should return the same instance", 
                                                                                                                                           firstIterator, secondIterator);
                                                                                                                                 
                                                                                                                                 // Clean up
                                                                                                                                 csvParser.close();
                                                                                                                             }

 @Test
                                                                                                                             public void testIterator_ThrowsNoSuchElementExceptionWhenNoMoreRecords() throws IOException {
                                                                                                                                 // Setup test data with exactly one record
                                                                                                                                 String testData = "header1,header2\nvalue1,value2";
                                                                                                                                 CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
                                                                                                                                 CSVParser csvParser = CSVParser.parse(testData, format);
                                                                                                                                 
                                                                                                                                 // Initialize exception rule
                                                                                                                                 ExpectedException thrown = ExpectedException.none();
                                                                                                                                 
                                                                                                                                 // Test logic
                                                                                                                                 Iterator<CSVRecord> iterator = csvParser.iterator();
                                                                                                                                 iterator.next(); // consume the only record
                                                                                                                                 
                                                                                                                                 thrown.expect(NoSuchElementException.class);
                                                                                                                                 iterator.next();
                                                                                                                             }

 @Test
                                                                                                                             public void testIterator_WorksAfterParserIsClosed() throws IOException {
                                                                                                                                 // Create sample CSV input
                                                                                                                                 String csvData = "header1,header2\nvalue1,value2";
                                                                                                                                 // Create parser with the sample data
                                                                                                                                 CSVParser csvParser = CSVParser.parse(csvData, CSVFormat.DEFAULT);
                                                                                                                                 
                                                                                                                                 Iterator<CSVRecord> iterator = csvParser.iterator();
                                                                                                                                 csvParser.close();
                                                                                                                                 
                                                                                                                                 // Should still be able to access the iterator after closing
                                                                                                                                 assertTrue("Iterator should still work after parser is closed", iterator.hasNext());
                                                                                                                                 assertNotNull("next() should still work after parser is closed", iterator.next());
                                                                                                                             }

 @Test
                                                                                                                         public void testIterator_NextReturnsCorrectRecord() throws IOException {
                                                                                                                             // Setup test CSV data
                                                                                                                             String csvData = "value1,value2";
                                                                                                                             Reader reader = new StringReader(csvData);
                                                                                                                             
                                                                                                                             // Configure CSV format (using default format without header)
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             
                                                                                                                             // Create parser with test data
                                                                                                                             CSVParser csvParser = new CSVParser(reader, format);
                                                                                                                             
                                                                                                                             // Test iterator functionality
                                                                                                                             Iterator<CSVRecord> iterator = csvParser.iterator();
                                                                                                                             CSVRecord record = iterator.next();
                                                                                                                             
                                                                                                                             // Verify results
                                                                                                                             assertNotNull("next() should return a non-null record", record);
                                                                                                                             assertEquals("Record should have correct number of values", 2, record.size());
                                                                                                                             assertEquals("First value should match", "value1", record.get(0));
                                                                                                                             assertEquals("Second value should match", "value2", record.get(1));
                                                                                                                             
                                                                                                                             // Clean up
                                                                                                                             csvParser.close();
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNextRecord_NoMoreRecords() throws Exception {
                                                                                                                             // Create test input with exactly 2 records
                                                                                                                             String testInput = "header1,header2\nvalue1,value2\nvalue3,value4";
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
                                                                                                                             CSVParser parser = CSVParser.parse(testInput, format);
                                                                                                                             
                                                                                                                             // Get iterator and read all records (2 records in our test input)
                                                                                                                             Iterator<CSVRecord> iterator = parser.iterator();
                                                                                                                             iterator.next();
                                                                                                                             iterator.next();
                                                                                                                             
                                                                                                                             // Next call should return false for hasNext() (no more records)
                                                                                                                             assertFalse(iterator.hasNext());
                                                                                                                             
                                                                                                                             // Close the parser
                                                                                                                             parser.close();
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNextRecord_EmptyInput() throws Exception {
                                                                                                                             // Create parser with empty input
                                                                                                                             CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                             CSVParser emptyParser = new CSVParser(new StringReader(""), format);
                                                                                                                             
                                                                                                                             // Get the private getNextRecord method via reflection
                                                                                                                             Method getNextRecordMethod = CSVParser.class.getDeclaredMethod("getNextRecord");
                                                                                                                             getNextRecordMethod.setAccessible(true);
                                                                                                                             
                                                                                                                             // Should return null for empty input
                                                                                                                             assertNull(getNextRecordMethod.invoke(emptyParser));
                                                                                                                         }

 @Test
                                                                                                                         public void testGetNextRecord_OnlyHeader() throws Exception {
                                                                                                                             // Create parser with only header line
                                                                                                                             java.io.StringReader reader = new java.io.StringReader("name,age\\n");
                                                                                                                             org.apache.commons.csv.CSVParser headerOnlyParser = new org.apache.commons.csv.CSVParser(
                                                                                                                                 reader, org.apache.commons.csv.CSVFormat.DEFAULT);
                                                                                                                             
                                                                                                                             try {
                                                                                                                                 // Get the private getNextRecord method via reflection
                                                                                                                                 Method getNextRecordMethod = org.apache.commons.csv.CSVParser.class
                                                                                                                                     .getDeclaredMethod("getNextRecord");
                                                                                                                                 getNextRecordMethod.setAccessible(true);
                                                                                                                                 
                                                                                                                                 // First call should return null (no data records)
                                                                                                                                 assertNull(getNextRecordMethod.invoke(headerOnlyParser));
                                                                                                                             } finally {
                                                                                                                                 headerOnlyParser.close();
                                                                                                                             }
                                                                                                                         }

 @Test
                                                                                                                     public void testGetNextRecord_SuccessfulRead() throws Exception {
                                                                                                                         // Setup test CSV data
                                                                                                                         String csvData = "John,30\nJane,25";
                                                                                                                         Reader reader = new StringReader(csvData);
                                                                                                                         CSVFormat format = CSVFormat.DEFAULT;
                                                                                                                         
                                                                                                                         // Create parser
                                                                                                                         CSVParser parser = new CSVParser(reader, format);
                                                                                                                         
                                                                                                                         try {
                                                                                                                             // Get iterator
                                                                                                                             Iterator<CSVRecord> iterator = parser.iterator();
                                                                                                                             
                                                                                                                             // First call should return first record
                                                                                                                             assertTrue(iterator.hasNext());
                                                                                                                             CSVRecord firstRecord = iterator.next();
                                                                                                                             assertNotNull(firstRecord);
                                                                                                                             assertEquals("John", firstRecord.get(0));
                                                                                                                             assertEquals("30", firstRecord.get(1));
                                                                                                                             
                                                                                                                             // Second call should return second record
                                                                                                                             assertTrue(iterator.hasNext());
                                                                                                                             CSVRecord secondRecord = iterator.next();
                                                                                                                             assertNotNull(secondRecord);
                                                                                                                             assertEquals("Jane", secondRecord.get(0));
                                                                                                                             assertEquals("25", secondRecord.get(1));
                                                                                                                             
                                                                                                                             // Third call should have no more records
                                                                                                                             assertFalse(iterator.hasNext());
                                                                                                                         } finally {
                                                                                                                             // Clean up
                                                                                                                             parser.close();
                                                                                                                         }
                                                                                                                     }

 @Test
                                                                                                                     public void testGetNextRecord_IOException() throws Exception {
                                                                                                                         // Setup test objects
                                                                                                                         Reader mockReader = mock(Reader.class);
                                                                                                                         CSVFormat mockFormat = mock(CSVFormat.class);
                                                                                                                         
                                                                                                                         // Make the reader throw IOException when read
                                                                                                                         when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                                                                                                                             .thenThrow(new IOException("Test IO Exception"));
                                                                                                                         
                                                                                                                         CSVParser parser = new CSVParser(mockReader, mockFormat);
                                                                                                                         
                                                                                                                         try {
                                                                                                                             // Use reflection to access private method
                                                                                                                             Method getNextRecord = CSVParser.class.getDeclaredMethod("getNextRecord");
                                                                                                                             getNextRecord.setAccessible(true);
                                                                                                                             getNextRecord.invoke(parser);
                                                                                                                             fail("Expected IllegalStateException to be thrown");
                                                                                                                         } catch (InvocationTargetException e) {
                                                                                                                             Throwable cause = e.getCause();
                                                                                                                             assertTrue(cause instanceof IllegalStateException);
                                                                                                                             assertEquals("IOException reading next record: java.io.IOException: Test IO Exception", 
                                                                                                                                 cause.getMessage());
                                                                                                                         }
                                                                                                                     }

 @Test
                                                                                                                     public void testGetNextRecord_AfterClose() throws Exception {
                                                                                                                         // Setup test data
                                                                                                                         String testData = "header1,header2\nvalue1,value2";
                                                                                                                         CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
                                                                                                                         CSVParser parser = new CSVParser(new StringReader(testData), format);
                                                                                                                         
                                                                                                                         // Create spy parser
                                                                                                                         CSVParser spyParser = spy(parser);
                                                                                                                         
                                                                                                                         // Setup expected exception
                                                                                                                         ExpectedException thrown = ExpectedException.none();
                                                                                                                         
                                                                                                                         // Close the parser first
                                                                                                                         spyParser.close();
                                                                                                                         
                                                                                                                         // Verify closed state
                                                                                                                         assertTrue(spyParser.isClosed());
                                                                                                                         
                                                                                                                         // Expect IllegalStateException when trying to read after close
                                                                                                                         thrown.expect(IllegalStateException.class);
                                                                                                                         
                                                                                                                         // Use reflection to access private getNextRecord method
                                                                                                                         Method getNextRecordMethod = CSVParser.class.getDeclaredMethod("getNextRecord");
                                                                                                                         getNextRecordMethod.setAccessible(true);
                                                                                                                         getNextRecordMethod.invoke(spyParser);
                                                                                                                     }

 @Test
                                                                                     public void testIterator_HasNextReturnsTrueWhenRecordsExist() {
                                                                                         // Setup test CSV data
                                                                                         String csvData = "header1,header2\nvalue1,value2";
                                                                                         Reader reader = new StringReader(csvData);
                                                                                         CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
                                                                                         
                                                                                         try {
                                                                                             // Create parser with test data
                                                                                             CSVParser csvParser = new CSVParser(reader, format);
                                                                                             
                                                                                             // Test iterator
                                                                                             Iterator<CSVRecord> iterator = csvParser.iterator();
                                                                                             assertTrue("hasNext() should return true when records exist", iterator.hasNext());
                                                                                             
                                                                                             // Clean up
                                                                                             csvParser.close();
                                                                                         } catch (IOException e) {
                                                                                             fail("Unexpected IOException: " + e.getMessage());
                                                                                         }
                                                                                     }

 @Test
                                                                                     public void testIterator_RemoveThrowsUnsupportedOperationException() throws IOException {
                                                                                         // Setup test data
                                                                                         String testData = "header1,header2\nvalue1,value2";
                                                                                         Reader reader = new StringReader(testData);
                                                                                         CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
                                                                                         
                                                                                         // Create parser instance
                                                                                         CSVParser csvParser = new CSVParser(reader, format);
                                                                                         
                                                                                         // Get iterator and test remove operation
                                                                                         Iterator<CSVRecord> iterator = csvParser.iterator();
                                                                                         
                                                                                         thrown.expect(UnsupportedOperationException.class);
                                                                                         iterator.remove();
                                                                                     }

 @Test
                                                                                     public void testIterator_WorksWithEmptyInput() throws IOException {
                                                                                         CSVFormat format = CSVFormat.DEFAULT;
                                                                                         CSVParser emptyParser = new CSVParser(new StringReader(""), format);
                                                                                         Iterator<CSVRecord> iterator = emptyParser.iterator();
                                                                                         assertFalse("hasNext() should return false for empty input", iterator.hasNext());
                                                                                     }

 @Test
                                                                                     public void testIterator_WorksWithOnlyHeaders() throws IOException {
                                                                                         CSVFormat format = CSVFormat.DEFAULT.withHeader("header1", "header2");
                                                                                         CSVParser headersOnlyParser = new CSVParser(new StringReader("header1,header2"), format);
                                                                                         Iterator<CSVRecord> iterator = headersOnlyParser.iterator();
                                                                                         assertFalse("hasNext() should return false when only headers exist", iterator.hasNext());
                                                                                     }

 @Test
                                                                                     public void testRemove_ShouldThrowUnsupportedOperationException() throws IOException {
                                                                                         // Arrange
                                                                                         CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
                                                                                         Iterator<CSVRecord> iterator = parser.iterator();
                                                                                         
                                                                                         // Expect the exception
                                                                                         ExpectedException expectedException = ExpectedException.none();
                                                                                         expectedException.expect(UnsupportedOperationException.class);
                                                                                         
                                                                                         // Act
                                                                                         iterator.remove();
                                                                                     }

}
