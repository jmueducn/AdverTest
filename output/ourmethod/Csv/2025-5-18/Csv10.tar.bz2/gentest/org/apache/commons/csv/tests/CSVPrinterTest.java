package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class CSVPrinterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                             public void testConstructor_NullOutParameter_ThrowsException() throws IOException {
                                                                 // Arrange
                                                                 CSVFormat format = mock(CSVFormat.class);
                                                                 thrown.expect(NullPointerException.class);
                                                                 thrown.expectMessage("out");
                                                                 
                                                                 // Act
                                                                 new CSVPrinter(null, format);
                                                             }

 @Test
                                                             public void testConstructor_HeaderPrintingFails_ThrowsIOException() throws IOException {
                                                                 // Arrange
                                                                 Appendable out = mock(Appendable.class);
                                                                 CSVFormat format = mock(CSVFormat.class);
                                                                 String[] header = {"Name", "Age"};
                                                                 when(format.getHeader()).thenReturn(header);
                                                                 doThrow(new IOException("Write failed")).when(out).append(any(CharSequence.class));
                                                                 thrown.expect(IOException.class);
                                                                 thrown.expectMessage("Write failed");
                                                                 
                                                                 // Act
                                                                 new CSVPrinter(out, format);
                                                             }

 @Test
                                                     public void testConstructor_NullFormatParameter_ThrowsException() throws IOException {
                                                         // Arrange
                                                         org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                         Appendable out = new java.io.StringWriter();
                                                         thrown.expect(NullPointerException.class);
                                                         thrown.expectMessage("format");
                                                         
                                                         // Act
                                                         new CSVPrinter(out, null);
                                                     }

 @Test
                                                 public void testConstructor_FormatValidationFails_ThrowsException() throws IOException {
                                                     // Arrange
                                                     Appendable out = new java.io.StringWriter();
                                                     // Create a format that will fail validation
                                                     CSVFormat format = CSVFormat.DEFAULT.withDelimiter('\0'); // Null delimiter is invalid
                                                     thrown.expect(IllegalArgumentException.class);
                                                     thrown.expectMessage("Invalid format");
                                                     
                                                     // Act
                                                     new CSVPrinter(out, format);
                                                 }

 @Test
                                             public void testConstructor_WithHeader_PrintsHeaderImmediately() throws IOException {
                                                 // Arrange
                                                 java.io.StringWriter out = new java.io.StringWriter();
                                                 org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withHeader("Name", "Age", "City");
                                                 
                                                 // Act
                                                 new org.apache.commons.csv.CSVPrinter(out, format);
                                                 
                                                 // Assert
                                                 String result = out.toString();
                                                 org.junit.Assert.assertTrue(result.contains("Name"));
                                                 org.junit.Assert.assertTrue(result.contains("Age"));
                                                 org.junit.Assert.assertTrue(result.contains("City"));
                                             }

 @Test
                                     public void testConstructor_ValidParameters_InitializesFields() throws IOException {
                                         // Arrange
                                         java.io.StringWriter out = new java.io.StringWriter();
                                         org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                         
                                         // Act
                                         org.apache.commons.csv.CSVPrinter printer = new org.apache.commons.csv.CSVPrinter(out, format);
                                         
                                         // Assert
                                         assertSame(out, printer.getOut());
                                     }

 @Test
                public void testConstructorPrintsHeaderAsObjectArray() throws IOException {
                    // Setup mocks
                    Appendable mockAppendable = mock(Appendable.class);
                    CSVFormat mockFormat = mock(CSVFormat.class);
                    
                    // Configure format to return a header
                    String[] header = {"col1", "col2"};
                    when(mockFormat.getHeader()).thenReturn(header);
                    
                    // Create spy to verify method calls
                    CSVPrinter printerSpy = spy(new CSVPrinter(mockAppendable, mockFormat));
                    
                    // Verify printRecord was called with Object[] (not raw Object)
                    verify(printerSpy).printRecord((Object[]) header);
                    
                    // Additional verification that it wasn't called with raw Object
                    verify(printerSpy, never()).printRecord((Object) header);
                }

 @Test
               public void testCloseShouldCloseUnderlyingCloseableStream() throws IOException {
                   // Create a mock Appendable that is also Closeable
                   Appendable mockOut = mock(Appendable.class);
                   when(mockOut instanceof Closeable).thenReturn(true); // Make it act as Closeable
                   
                   // Mock CSVFormat with no header
                   CSVFormat mockFormat = mock(CSVFormat.class);
                   when(mockFormat.getHeader()).thenReturn(null);
                   
                   // Create CSVPrinter with our mock objects
                   CSVPrinter printer = new CSVPrinter(mockOut, mockFormat);
                   
                   // Call close() which should propagate to the underlying Closeable
                   printer.close();
                   
                   // Verify close() was called on our mock Appendable (since it's Closeable)
                   verify((Closeable)mockOut).close();
               }

 @Test
              public void testCloseShouldCallCloseOnAppendable() throws IOException {
                  // Create a mock Appendable that also implements Closeable
                  Appendable mockOut = mock(Appendable.class);
                  when(mockOut.toString()).thenReturn("mock");
                  
                  // Create a mock CSVFormat
                  CSVFormat mockFormat = mock(CSVFormat.class);
                  when(mockFormat.getHeader()).thenReturn(null);
                  
                  // Create CSVPrinter instance
                  CSVPrinter printer = new CSVPrinter(mockOut, mockFormat);
                  
                  // Call close() which should trigger out.close()
                  printer.close();
                  
                  // Verify that close() was called on the Appendable
                  // This will fail if the mutant is present (which calls toString() instead)
                  verify((Closeable)mockOut).close();
                  
                  // Also verify toString() was NOT called (just to be thorough)
                  verify(mockOut, never()).toString();
              }

 @Test
        public void testCloseShouldCloseCloseableOutput() throws Exception {
            // Create a mock Appendable that also implements Closeable
            Appendable mockOut = mock(Appendable.class);
            Closeable closeableOut = (Closeable) mockOut;
            
            // Create a simple CSVFormat without header
            CSVFormat format = CSVFormat.DEFAULT;
            
            // Create CSVPrinter instance
            CSVPrinter printer = new CSVPrinter(mockOut, format);
            
            // Close the printer - should close the underlying Closeable
            printer.close();
            
            // Verify close() was called on our Closeable output
            verify(closeableOut).close();
        }

 @Test
       public void testConstructorClosesOutputWhenAppendableIsCloseable() throws Exception {
           // Create a mock Appendable that also implements Closeable
           Appendable mockOut = mock(Appendable.class);
           Closeable closeableOut = (Closeable) mockOut;
           
           // Mock CSVFormat with no header to simplify test
           CSVFormat mockFormat = mock(CSVFormat.class);
           when(mockFormat.getHeader()).thenReturn(null);
           
           // Create CSVPrinter instance - should close the output if unmutated
           new CSVPrinter(mockOut, mockFormat);
           
           // Verify close was called on the output
           verify(closeableOut).close();
       }

 @Test
         public void testConstructorShouldThrowExceptionWhenOutIsNull() throws IOException {
             // Prepare
             CSVFormat mockFormat = mock(CSVFormat.class);
             when(mockFormat.getHeader()).thenReturn(null);
             
             // Expect exception
             thrown.expect(NullPointerException.class);
             thrown.expectMessage("out");
             
             // Test
             new CSVPrinter(null, mockFormat);
         }

 @Test
         public void testConstructorShouldNotThrowExceptionWhenFormatIsNull() throws IOException {
             // Prepare
             Appendable mockOut = mock(Appendable.class);
             
             // Expect exception
             thrown.expect(NullPointerException.class);
             thrown.expectMessage("format");
             
             // Test
             new CSVPrinter(mockOut, null);
         }

 @Test
        public void testConstructorWithNullFormatShouldThrowException() throws Exception {
            // Setup
            Appendable mockAppendable = mock(Appendable.class);
            
            // Expect exception
            thrown.expect(NullPointerException.class);
            thrown.expectMessage("format");
            
            // Test - this should throw NPE due to null format
            new CSVPrinter(mockAppendable, null);
            
            // If the test reaches here without throwing exception, the mutant survives
        }

 @Test
        public void testConstructorWithNullOutShouldThrowException() throws Exception {
            // Setup
            CSVFormat mockFormat = mock(CSVFormat.class);
            
            // Expect exception
            thrown.expect(NullPointerException.class);
            thrown.expectMessage("out");
            
            // Test - this should throw NPE due to null Appendable
            new CSVPrinter(null, mockFormat);
        }

 @Test(expected = ClassCastException.class)
       public void testCloseWithNonCloseableOutput() throws IOException {
           // Setup
           Appendable nonCloseableOutput = mock(Appendable.class);
           CSVFormat format = mock(CSVFormat.class);
           
           // Create CSVPrinter with non-Closeable output
           CSVPrinter printer = new CSVPrinter(nonCloseableOutput, format);
           
           // This should throw ClassCastException with the mutant (if (true))
           // but pass normally with original code
           printer.close();
           
           // Verify no interaction with output (original behavior)
           verifyZeroInteractions(nonCloseableOutput);
       }

 @Test
       public void testCloseWithCloseableOutput() throws IOException {
           // Setup
           Appendable closeableOutput = mock(Appendable.class, withSettings().extraInterfaces(Closeable.class));
           CSVFormat format = mock(CSVFormat.class);
           
           // Create CSVPrinter with Closeable output
           CSVPrinter printer = new CSVPrinter(closeableOutput, format);
           
           // This should work in both original and mutated code
           printer.close();
           
           // Verify close was called
           ((Closeable)closeableOutput).close();
       }

 @Test
      public void testConstructorClosesOutputWhenCloseable() throws IOException {
          // Create a mock Appendable that also implements Closeable
          Appendable mockOut = mock(Appendable.class);
          Closeable closeableOut = (Closeable) mockOut;
          
          // Mock CSVFormat with no header to simplify test
          CSVFormat mockFormat = mock(CSVFormat.class);
          when(mockFormat.getHeader()).thenReturn(null);
          
          // Create CSVPrinter instance - should close the output if unmutated
          new CSVPrinter(mockOut, mockFormat);
          
          // Verify close() was called on the Closeable output
          verify(closeableOut).close();
      }

 @Test
      public void testConstructorDoesNotCloseNonCloseableOutput() throws IOException {
          // Create a mock Appendable that doesn't implement Closeable
          Appendable mockOut = mock(Appendable.class);
          
          // Mock CSVFormat with no header to simplify test
          CSVFormat mockFormat = mock(CSVFormat.class);
          when(mockFormat.getHeader()).thenReturn(null);
          
          // Create CSVPrinter instance - should not try to close non-Closeable
          new CSVPrinter(mockOut, mockFormat);
          
          // Verify no close-related methods were called
          verify(mockOut, never()).append(anyChar());
          verify(mockOut, never()).append(any(CharSequence.class));
      }

 @Test
     public void testCloseProperlyClosesStream() throws IOException {
         // Create a mock Appendable that is also Closeable
         Appendable mockOut = mock(Appendable.class);
         when(mockOut instanceof Closeable).thenReturn(true);
         
         // Create a simple CSVFormat without header
         CSVFormat format = CSVFormat.DEFAULT;
         
         // Create CSVPrinter and immediately close it
         CSVPrinter printer = new CSVPrinter(mockOut, format);
         printer.close();
         
         // Verify that close() was called on the underlying stream
         verify((Closeable)mockOut).close();
     }

}
