package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                               public void testInitializeHeader_WithPredefinedHeaders_NoSkip() throws Exception {
                                                   // Setup
                                                   CSVFormat format = mock(CSVFormat.class);
                                                   when(format.getHeader()).thenReturn(new String[]{"header1", "header2"});
                                                   when(format.getSkipHeaderRecord()).thenReturn(false);
                                                   when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                   
                                                   Reader reader = new StringReader("");
                                                   CSVParser parser = new CSVParser(reader, format);
                                                   
                                                   // Use reflection to access private method
                                                   Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                   method.setAccessible(true);
                                                   
                                                   // Execute
                                                   @SuppressWarnings("unchecked")
                                                   Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
                                                   
                                                   // Verify
                                                   assertNotNull(result);
                                                   assertEquals(2, result.size());
                                                   assertEquals(Integer.valueOf(0), result.get("header1"));
                                                   assertEquals(Integer.valueOf(1), result.get("header2"));
                                               }

 @Test
                                               public void testInitializeHeader_WithEmptyHeaders_IgnoreEmptyEnabled() throws Exception {
                                                   // Setup
                                                   CSVFormat format = mock(CSVFormat.class);
                                                   when(format.getHeader()).thenReturn(new String[]{"", null, "valid"});
                                                   when(format.getSkipHeaderRecord()).thenReturn(false);
                                                   when(format.getIgnoreEmptyHeaders()).thenReturn(true);
                                                   
                                                   // Create real parser with mocked reader
                                                   Reader reader = new StringReader("");
                                                   CSVParser parser = new CSVParser(reader, format);
                                                   
                                                   // Use reflection to access private method
                                                   Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                   method.setAccessible(true);
                                                   
                                                   // Execute
                                                   @SuppressWarnings("unchecked")
                                                   Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
                                                   
                                                   // Verify
                                                   assertNotNull(result);
                                                   assertEquals(3, result.size()); // Still contains all entries, just won't throw exception
                                                   assertEquals(Integer.valueOf(0), result.get(""));
                                                   assertEquals(Integer.valueOf(1), result.get(null));
                                                   assertEquals(Integer.valueOf(2), result.get("valid"));
                                               }

 @Test
                                               public void testInitializeHeader_WithDuplicateHeaders_ThrowsException() throws Exception {
                                                   // Setup
                                                   CSVFormat format = mock(CSVFormat.class);
                                                   when(format.getHeader()).thenReturn(new String[]{"dup", "dup"});
                                                   when(format.getSkipHeaderRecord()).thenReturn(false);
                                                   when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                   
                                                   // Create a real parser with mocked input that will trigger the private initializeHeader()
                                                   Reader reader = new StringReader("");
                                                   CSVParser parser = new CSVParser(reader, format);
                                                   
                                                   thrown.expect(IllegalArgumentException.class);
                                                   thrown.expectMessage("The header contains a duplicate name: \"dup\" in [dup, dup]");
                                                   
                                                   // Execute - this will internally call initializeHeader()
                                                   parser.getHeaderMap();
                                               }

 @Test
                                               public void testInitializeHeader_WithEmptyHeaders_IgnoreEmptyDisabled_ThrowsException() throws Exception {
                                                   // Setup
                                                   CSVFormat format = mock(CSVFormat.class);
                                                   when(format.getHeader()).thenReturn(new String[]{"", ""});
                                                   when(format.getSkipHeaderRecord()).thenReturn(false);
                                                   when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                                   
                                                   // Create a real parser with mocked input
                                                   Reader reader = new StringReader("");
                                                   CSVParser parser = new CSVParser(reader, format);
                                                   
                                                   // Use reflection to access private method
                                                   Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                   method.setAccessible(true);
                                                   
                                                   thrown.expect(IllegalArgumentException.class);
                                                   thrown.expectMessage("The header contains a duplicate name: \"\" in [, ]");
                                                   
                                                   // Execute
                                                   method.invoke(parser);
                                               }

 @Test
                                               public void testInitializeHeader_WithNullFormatHeader_ReturnsNull() throws Exception {
                                                   // Setup
                                                   CSVFormat format = mock(CSVFormat.class);
                                                   when(format.getHeader()).thenReturn(null);
                                                   
                                                   // Create real parser with mocked format
                                                   Reader reader = new StringReader("");
                                                   CSVParser parser = new CSVParser(reader, format);
                                                   
                                                   // Use reflection to access private method
                                                   Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
                                                   method.setAccessible(true);
                                                   
                                                   // Execute
                                                   @SuppressWarnings("unchecked")
                                                   Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
                                                   
                                                   // Verify
                                                   assertNull(result);
                                               }

 @Test
                                           public void testInitializeHeader_WithPredefinedHeaders_WithSkip() throws Exception {
                                               // Setup
                                               CSVFormat format = mock(CSVFormat.class);
                                               when(format.getHeader()).thenReturn(new String[]{"header1", "header2"});
                                               when(format.getSkipHeaderRecord()).thenReturn(true);
                                               when(format.getIgnoreEmptyHeaders()).thenReturn(false);
                                               
                                               // Create a real parser with mocked format
                                               Reader reader = new StringReader("");
                                               CSVParser parser = new CSVParser(reader, format);
                                               
                                               // Use reflection to get the header map directly
                                               Field headerMapField = CSVParser.class.getDeclaredField("headerMap");
                                               headerMapField.setAccessible(true);
                                               Map<String, Integer> result = (Map<String, Integer>) headerMapField.get(parser);
                                               
                                               // Verify
                                               assertNotNull(result);
                                               assertEquals(2, result.size());
                                               assertEquals(Integer.valueOf(0), result.get("header1"));
                                               assertEquals(Integer.valueOf(1), result.get("header2"));
                                           }

 @Test
                                           public void testInitializeHeader_WithEmptyFormatHeader_AndNoRecords_ReturnsNull() throws Exception {
                                               // Setup
                                               CSVFormat format = mock(CSVFormat.class);
                                               when(format.getHeader()).thenReturn(new String[0]);
                                               when(format.getSkipHeaderRecord()).thenReturn(false);
                                               
                                               // Empty reader will result in no records being parsed
                                               Reader reader = new StringReader("");
                                               CSVParser parser = new CSVParser(reader, format);
                                               
                                               // Use reflection to access private method
                                               Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
                                               initializeHeader.setAccessible(true);
                                               
                                               // Execute
                                               @SuppressWarnings("unchecked")
                                               Map<String, Integer> result = (Map<String, Integer>) initializeHeader.invoke(parser);
                                               
                                               // Verify
                                               assertNull(result);
                                           }

 @Test
           public void testInitializeHeader_WithEmptyFormatHeader_ReadsFromFirstRecord() throws Exception {
               // Setup
               CSVFormat format = mock(CSVFormat.class);
               when(format.getHeader()).thenReturn(new String[0]);
               when(format.getSkipHeaderRecord()).thenReturn(false);
               when(format.getIgnoreEmptyHeaders()).thenReturn(false);
               
               // Create a real parser with mocked reader
               Reader reader = mock(Reader.class);
               CSVParser parser = new CSVParser(reader, format);
               
               // Mock record values
               CSVRecord record = mock(CSVRecord.class);
               when(record.size()).thenReturn(2);
               when(record.get(0)).thenReturn("col1");
               when(record.get(1)).thenReturn("col2");
               
               // Create spy and mock nextRecord behavior
               CSVParser spyParser = spy(parser);
               
               // Use reflection to test private method
               Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
               initializeHeader.setAccessible(true);
               
               // Execute
               @SuppressWarnings("unchecked")
               Map<String, Integer> result = (Map<String, Integer>) initializeHeader.invoke(spyParser);
               
               // Verify
               assertNotNull(result);
               assertEquals(2, result.size());
               assertEquals(Integer.valueOf(0), result.get("col1"));
               assertEquals(Integer.valueOf(1), result.get("col2"));
           }

 @Test(expected = IllegalArgumentException.class)
       public void testInitializeHeader_ShouldThrowExceptionForDuplicateNonEmptyHeaders() throws Exception {
           // Setup test data
           final String[] headers = {"Name", "Age", "Name"}; // Duplicate non-empty header
           CSVFormat format = mock(CSVFormat.class);
           
           // Mock behavior
           when(format.getHeader()).thenReturn(headers);
           when(format.getSkipHeaderRecord()).thenReturn(false);
           when(format.getIgnoreEmptyHeaders()).thenReturn(false); // Not relevant for this test
           
           // Create parser with mocked format
           CSVParser parser = new CSVParser(new StringReader(""), format);
           
           // Use reflection to access private method since it's called in constructor
           Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
           method.setAccessible(true);
           
           // This should throw IllegalArgumentException for original code
           // But mutant will let it pass since header is not empty
           method.invoke(parser);
       }

 @Test(expected = IllegalArgumentException.class)
       public void testInitializeHeader_ShouldThrowExceptionForDuplicateNonEmptyHeaders1() throws Exception {
           // Create CSV data with duplicate headers
           String csvData = "Name,Age,Name\nJohn,30,Engineer";
           
           // Create format with duplicate headers and skipHeaderRecord false
           CSVFormat format = CSVFormat.DEFAULT.withHeader("Name", "Age", "Name").withSkipHeaderRecord(false);
           
           // Parse should throw exception due to duplicate headers
           CSVParser parser = CSVParser.parse(csvData, format);
           parser.getHeaderMap(); // Force header initialization
       }

 @Test
      public void testInitializeHeaderReturnsNonNullMap() throws Exception {
          // Setup CSVFormat with headers
          CSVFormat format = CSVFormat.DEFAULT.withHeader("col1", "col2", "col3");
          
          // Create a mock reader that would return records if needed
          Reader reader = new StringReader("col1,col2,col3\nval1,val2,val3");
          
          // Create parser instance
          CSVParser parser = new CSVParser(reader, format);
          
          // Call initializeHeader through reflection since it's private
          Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
          method.setAccessible(true);
          Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
          
          // Assert the result is not null
          assertNotNull("Header map should not be null", result);
          
          // Additional verification that the map contains expected headers
          assertTrue("Header map should contain col1", result.containsKey("col1"));
          assertTrue("Header map should contain col2", result.containsKey("col2"));
          assertTrue("Header map should contain col3", result.containsKey("col3"));
          
          // Verify indices
          assertEquals("col1 should have index 0", Integer.valueOf(0), result.get("col1"));
          assertEquals("col2 should have index 1", Integer.valueOf(1), result.get("col2"));
          assertEquals("col3 should have index 2", Integer.valueOf(2), result.get("col3"));
      }

 @Test
     public void testInitializeHeader_duplicateHeader_shouldShowFullHeaderInErrorMessage() throws Exception {
         // Setup test data with duplicate headers
         final String[] headers = {"Name", "Age", "Name"};
         
         // Mock CSVFormat behavior
         CSVFormat format = mock(CSVFormat.class);
         when(format.getHeader()).thenReturn(headers);
         when(format.getSkipHeaderRecord()).thenReturn(false);
         when(format.getIgnoreEmptyHeaders()).thenReturn(false);
         
         // Create parser instance with mocked format
         CSVParser parser = new CSVParser(new StringReader(""), format);
         
         try {
             // Use reflection to access private method
             Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
             method.setAccessible(true);
             method.invoke(parser);
             fail("Expected IllegalArgumentException");
         } catch (InvocationTargetException e) {
             // Verify the exception and its message
             Throwable cause = e.getCause();
             assertTrue(cause instanceof IllegalArgumentException);
             String errorMessage = cause.getMessage();
             assertTrue("Error message should contain full header record", 
                       errorMessage.contains(Arrays.toString(headers)));
         }
     }

 @Test
    public void testIsClosedReturnsTrueWhenLexerIsClosed() throws Exception {
        // Setup
        Reader reader = new StringReader("test");
        CSVFormat format = CSVFormat.DEFAULT;
        CSVParser parser = new CSVParser(reader, format);
        
        // Exercise - close the parser (which should close the lexer)
        parser.close();
        
        // Verify
        assertTrue("isClosed() should return true when lexer is closed", parser.isClosed());
        
        // Cleanup
        reader.close();
    }

 @Test
   public void testInitializeHeader_ValuesShouldBeIntegerObjects() throws Exception {
       // Setup test data
       String[] headers = {"header1", "header2", "header3"};
       CSVFormat format = CSVFormat.DEFAULT.withHeader(headers).withSkipHeaderRecord(false);
       
       // Create parser with mocked reader (we don't need actual file I/O)
       Reader reader = new StringReader("");
       CSVParser parser = new CSVParser(reader, format);
       
       // Get the header map
       Map<String, Integer> headerMap = parser.getHeaderMap();
       
       // Verify all values are proper Integer objects (not just auto-boxed primitives)
       for (Map.Entry<String, Integer> entry : headerMap.entrySet()) {
           Integer value = entry.getValue();
           // This assertion will fail if the value was put as primitive (due to auto-boxing)
           // because getClass() on an auto-boxed primitive returns Integer.class
           // But we add it to be explicit about our expectations
           assertEquals(Integer.class, value.getClass());
           
           // More importantly, verify the value can be properly used as an Integer
           // This would catch if the value was stored incorrectly
           assertNotNull(Integer.valueOf(value.toString()));
       }
       
       // Verify specific indices
       assertEquals(Integer.valueOf(0), headerMap.get("header1"));
       assertEquals(Integer.valueOf(1), headerMap.get("header2"));
       assertEquals(Integer.valueOf(2), headerMap.get("header3"));
   }

 @Test
  public void testInitializeHeader_DetectsMutantForNonEmptyHeaders() throws Exception {
      // Setup test data
      String[] headers = {"validHeader", "anotherHeader"};
      
      // Mock CSVFormat behavior
      CSVFormat format = mock(CSVFormat.class);
      when(format.getHeader()).thenReturn(headers);
      when(format.getSkipHeaderRecord()).thenReturn(false);
      when(format.getIgnoreEmptyHeaders()).thenReturn(false);
      
      // Create parser with mocked format
      CSVParser parser = new CSVParser(new StringReader(""), format);
      
      // Use reflection to access private method since it's called in constructor
      Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
      method.setAccessible(true);
      Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
      
      // Verify the mapping contains our headers (would fail with mutant)
      assertEquals(2, result.size());
      assertEquals(Integer.valueOf(0), result.get("validHeader"));
      assertEquals(Integer.valueOf(1), result.get("anotherHeader"));
      
      // Test duplicate detection with non-empty headers
      String[] duplicateHeaders = {"duplicate", "duplicate"};
      when(format.getHeader()).thenReturn(duplicateHeaders);
      
      try {
          method.invoke(parser);
          fail("Expected IllegalArgumentException for duplicate headers");
      } catch (InvocationTargetException e) {
          assertEquals(IllegalArgumentException.class, e.getCause().getClass());
      }
  }

 @Test
 public void testIsClosedReflectsLexerState() throws Exception {
     // Setup
     Reader reader = new StringReader("test");
     CSVFormat format = CSVFormat.DEFAULT;
     CSVParser parser = new CSVParser(reader, format);
     
     // Test before closing
     assertFalse("Parser should not be closed initially", parser.isClosed());
     
     // Close and test again
     parser.close();
     assertTrue("Parser should be closed after close()", parser.isClosed());
 }

}
