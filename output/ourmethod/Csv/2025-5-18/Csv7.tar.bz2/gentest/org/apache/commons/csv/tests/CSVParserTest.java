package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
 
public class CSVParserTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                           public void testInitializeHeader_WithEmptyFormatHeader_EmptyFirstRecord_ReturnsNull() throws Exception {
                                               // Setup
                                               CSVFormat format = mock(CSVFormat.class);
                                               when(format.getHeader()).thenReturn(new String[0]);
                                               when(format.getSkipHeaderRecord()).thenReturn(false);
                                               
                                               // Create parser with null reader (since we're mocking the lexer)
                                               CSVParser parser = new CSVParser(new StringReader(""), format);
                                               
                                               // Mock lexer behavior using reflection since Lexer is not public
                                               Class<?> lexerClass = Class.forName("org.apache.commons.csv.Lexer");
                                               Object lexer = mock(lexerClass);
                                               Class<?> tokenClass = Class.forName("org.apache.commons.csv.Token");
                                               Class<?> tokenTypeClass = Class.forName("org.apache.commons.csv.Token$Type");
                                               
                                               when(lexerClass.getMethod("nextToken", tokenClass).invoke(lexer, any()))
                                                   .thenAnswer(invocation -> {
                                                       Object token = tokenClass.newInstance();
                                                       Field typeField = tokenClass.getDeclaredField("type");
                                                       typeField.setAccessible(true);
                                                       typeField.set(token, Enum.valueOf((Class<Enum>) tokenTypeClass, "TOKEN"));
                                                       
                                                       Field contentField = tokenClass.getDeclaredField("content");
                                                       contentField.setAccessible(true);
                                                       contentField.set(token, new String[0]);
                                                       return token;
                                                   });
                                               
                                               // Set lexer field using reflection
                                               Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                               lexerField.setAccessible(true);
                                               lexerField.set(parser, lexer);
                                               
                                               // Test
                                               Map<String, Integer> result = (Map<String, Integer>) 
                                                   CSVParser.class.getDeclaredMethod("initializeHeader").invoke(parser);
                                               
                                               // Verify
                                               assertNull(result);
                                           }

 @Test
                                       public void testInitializeHeader_WithNonEmptyFormatHeader_NoSkipHeader() throws Exception {
                                           // Setup
                                           CSVFormat format = mock(CSVFormat.class);
                                           when(format.getHeader()).thenReturn(new String[] {"field1", "field2"});
                                           when(format.getSkipHeaderRecord()).thenReturn(false);
                                           
                                           // Create parser with null reader since we're testing header initialization only
                                           CSVParser parser = new CSVParser(null, format);
                                           
                                           // Get the private method using reflection
                                           Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                           initializeHeaderMethod.setAccessible(true);
                                           
                                           // Test
                                           @SuppressWarnings("unchecked")
                                           Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                           
                                           // Verify
                                           assertNotNull(result);
                                           assertEquals(2, result.size());
                                           assertEquals(Integer.valueOf(0), result.get("field1"));
                                           assertEquals(Integer.valueOf(1), result.get("field2"));
                                       }

 @Test
                                       public void testInitializeHeader_WithNonEmptyFormatHeader_SkipHeader() throws Exception {
                                           // Setup
                                           CSVFormat format = mock(CSVFormat.class);
                                           when(format.getHeader()).thenReturn(new String[] {"fieldA", "fieldB"});
                                           when(format.getSkipHeaderRecord()).thenReturn(true);
                                           
                                           // Create parser with null reader since we're testing header initialization only
                                           CSVParser parser = new CSVParser(new StringReader(""), format);
                                           
                                           // Mock the lexer behavior using reflection since it's not accessible
                                           Field lexerField = parser.getClass().getDeclaredField("lexer");
                                           lexerField.setAccessible(true);
                                           Object lexer = mock(lexerField.getType());
                                           when(lexer.getClass().getMethod("nextToken").invoke(lexer)).thenReturn(null); // Simulate record skip
                                           
                                           // Set the mock lexer using reflection
                                           lexerField.set(parser, lexer);
                                           
                                           // Get the initializeHeader method using reflection
                                           Method initializeHeaderMethod = parser.getClass().getDeclaredMethod("initializeHeader");
                                           initializeHeaderMethod.setAccessible(true);
                                           
                                           // Test
                                           @SuppressWarnings("unchecked")
                                           Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                           
                                           // Verify
                                           assertNotNull(result);
                                           assertEquals(2, result.size());
                                           assertEquals(Integer.valueOf(0), result.get("fieldA"));
                                           assertEquals(Integer.valueOf(1), result.get("fieldB"));
                                           
                                           // Verify record was skipped
                                           verify(lexer, times(1)).getClass().getMethod("nextToken").invoke(lexer);
                                       }

 @Test
                                       public void testInitializeHeader_WithNullFormatHeader_ReturnsNull() throws Exception {
                                           // Setup
                                           CSVFormat format = mock(CSVFormat.class);
                                           when(format.getHeader()).thenReturn(null);
                                           
                                           Reader reader = mock(Reader.class);
                                           CSVParser parser = new CSVParser(reader, format);
                                           
                                           // Use reflection to access private method
                                           Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
                                           method.setAccessible(true);
                                           
                                           // Test
                                           @SuppressWarnings("unchecked")
                                           Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
                                           
                                           // Verify
                                           assertNull(result);
                                       }

 @Test
                                       public void testInitializeHeader_WithEmptyFormatHeader_NoRecords_ReturnsNull() throws Exception {
                                           // Setup
                                           CSVFormat format = mock(CSVFormat.class);
                                           when(format.getHeader()).thenReturn(new String[0]);
                                           when(format.getSkipHeaderRecord()).thenReturn(false);
                                           
                                           // Create parser with null reader
                                           CSVParser parser = new CSVParser(new StringReader(""), format);
                                           
                                           // Mock lexer behavior using reflection since it's private
                                           Class<?> lexerClass = Class.forName("org.apache.commons.csv.Lexer");
                                           Object lexer = mock(lexerClass);
                                           Class<?> tokenClass = Class.forName("org.apache.commons.csv.Token");
                                           Object token = tokenClass.getDeclaredConstructor().newInstance();
                                           Field typeField = tokenClass.getDeclaredField("type");
                                           typeField.setAccessible(true);
                                           typeField.set(token, Enum.valueOf((Class<Enum>) tokenClass.getDeclaredField("type").getType(), "EOF"));
                                           
                                           when(lexerClass.getMethod("nextToken", tokenClass).invoke(lexer, any(tokenClass))).thenReturn(token);
                                           
                                           // Set lexer field using reflection
                                           Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                           lexerField.setAccessible(true);
                                           lexerField.set(parser, lexer);
                                           
                                           // Get the private initializeHeader method using reflection
                                           Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                           initializeHeaderMethod.setAccessible(true);
                                           
                                           // Test
                                           @SuppressWarnings("unchecked")
                                           Map<String, Integer> result = (Map<String, Integer>) initializeHeaderMethod.invoke(parser);
                                           
                                           // Verify
                                           assertNull(result);
                                       }

 @Test
                                       public void testInitializeHeader_WithDuplicateHeaderNames_ThrowsException() throws Exception {
                                           // Setup
                                           CSVFormat format = mock(CSVFormat.class);
                                           when(format.getHeader()).thenReturn(new String[] {"dup", "dup"});
                                           when(format.getSkipHeaderRecord()).thenReturn(false);
                                           
                                           CSVParser parser = new CSVParser(new StringReader(""), format);
                                           
                                           // Expect exception
                                           ExpectedException thrown = ExpectedException.none();
                                           thrown.expect(IllegalStateException.class);
                                           thrown.expectMessage("The header contains duplicate names: [dup, dup]");
                                           
                                           // Get the private method using reflection
                                           Method initializeHeaderMethod = CSVParser.class.getDeclaredMethod("initializeHeader");
                                           initializeHeaderMethod.setAccessible(true);
                                           
                                           // Test
                                           initializeHeaderMethod.invoke(parser);
                                       }

 @Test
                                   public void testInitializeHeader_WithEmptyFormatHeader_ReadsFromFirstRecord() throws Exception {
                                       // Setup
                                       CSVFormat format = mock(CSVFormat.class);
                                       when(format.getHeader()).thenReturn(new String[0]);
                                       when(format.getSkipHeaderRecord()).thenReturn(false);
                                       
                                       // Create parser with empty input
                                       CSVParser parser = new CSVParser(new StringReader(""), format);
                                       
                                       // Get lexer field via reflection
                                       Field lexerField = CSVParser.class.getDeclaredField("lexer");
                                       lexerField.setAccessible(true);
                                       Object lexer = lexerField.get(parser);
                                       
                                       // Mock lexer's nextToken method
                                       Class<?> lexerClass = Class.forName("org.apache.commons.csv.Lexer");
                                       Class<?> tokenClass = Class.forName("org.apache.commons.csv.Token");
                                       Method nextTokenMethod = lexerClass.getDeclaredMethod("nextToken", tokenClass);
                                       nextTokenMethod.setAccessible(true);
                                       
                                       // Create a mock Token
                                       Object token = tokenClass.getDeclaredConstructor().newInstance();
                                       Field typeField = tokenClass.getDeclaredField("type");
                                       typeField.setAccessible(true);
                                       typeField.set(token, Enum.valueOf((Class<Enum>) tokenClass.getDeclaredClasses()[0], "TOKEN"));
                                       
                                       Field contentField = tokenClass.getDeclaredField("content");
                                       contentField.setAccessible(true);
                                       contentField.set(token, new String[] {"col1", "col2", "col3"});
                                       
                                       // Stub nextToken to return our token
                                       when(nextTokenMethod.invoke(lexer, any(tokenClass))).thenReturn(token);
                                       
                                       // Test by invoking private initializeHeader via reflection
                                       Method initializeHeader = CSVParser.class.getDeclaredMethod("initializeHeader");
                                       initializeHeader.setAccessible(true);
                                       @SuppressWarnings("unchecked")
                                       Map<String, Integer> result = (Map<String, Integer>) initializeHeader.invoke(parser);
                                       
                                       // Verify
                                       assertNotNull(result);
                                       assertEquals(3, result.size());
                                       assertEquals(Integer.valueOf(0), result.get("col1"));
                                       assertEquals(Integer.valueOf(1), result.get("col2"));
                                       assertEquals(Integer.valueOf(2), result.get("col3"));
                                   }

 @Test
       public void testInitializeHeaderWithNonNullHeaderButNullHdrMap() throws Exception {
           // Setup test data
           CSVFormat format = mock(CSVFormat.class);
           when(format.getHeader()).thenReturn(new String[]{"col1", "col2"});
           when(format.getSkipHeaderRecord()).thenReturn(false);
           
           CSVParser parser = new CSVParser(new StringReader(""), format);
           
           // Use reflection to test the private method
           Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
           method.setAccessible(true);
           
           // Get the header map
           Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
           
           // Verify the result
           assertNotNull(result);
           assertEquals(2, result.size());
           assertEquals(Integer.valueOf(0), result.get("col1"));
           assertEquals(Integer.valueOf(1), result.get("col2"));
           
           // This test will fail on the mutant because:
           // Original: processes headers since header is not null
           // Mutant: skips processing since hdrMap is null in the condition
       }

 @Test
      public void testIsClosedWithNullLexer() throws Exception {
          // Create a parser with null lexer using reflection
          CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
          
          // Use reflection to set lexer to null
          Field lexerField = CSVParser.class.getDeclaredField("lexer");
          lexerField.setAccessible(true);
          lexerField.set(parser, null);
          
          // Test the behavior
          try {
              parser.isClosed();
              // If we get here, the mutant survived (returned false instead of throwing)
              fail("Expected NullPointerException but none was thrown");
          } catch (NullPointerException e) {
              // This is the expected behavior for original code
          }
      }

 @Test
     public void testInitializeHeader_ShouldIncludeFirstHeaderElement() throws Exception {
         // Setup test data
         String[] headers = {"First", "Second", "Third"};
         
         // Mock the CSVFormat and its behavior
         CSVFormat format = mock(CSVFormat.class);
         when(format.getHeader()).thenReturn(headers);
         when(format.getSkipHeaderRecord()).thenReturn(false);
         
         // Create parser instance with mocked format
         // Note: We need to use reflection to test private method
         CSVParser parser = new CSVParser(new StringReader(""), format);
         
         // Get the header map using reflection since initializeHeader is private
         Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
         method.setAccessible(true);
         Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
         
         // Verify all headers are present with correct indices
         assertNotNull("Header map should not be null", headerMap);
         assertEquals("Should contain all headers", headers.length, headerMap.size());
         
         // Specifically test that first header is included (would fail with mutant)
         assertTrue("First header should be present", headerMap.containsKey("First"));
         assertEquals("First header should have index 0", 0, (int)headerMap.get("First"));
         
         // Verify other headers for completeness
         assertTrue("Second header should be present", headerMap.containsKey("Second"));
         assertEquals("Second header should have index 1", 1, (int)headerMap.get("Second"));
         assertTrue("Third header should be present", headerMap.containsKey("Third"));
         assertEquals("Third header should have index 2", 2, (int)headerMap.get("Third"));
     }

 @Test
    public void testInitializeHeader_DetectsIndexMutation() throws Exception {
        // Setup test data
        String[] headers = {"Name", "Age", "City"};
        
        // Mock CSVFormat behavior
        CSVFormat format = mock(CSVFormat.class);
        when(format.getHeader()).thenReturn(headers);
        when(format.getSkipHeaderRecord()).thenReturn(false);
        
        // Create parser with mocked format
        Reader reader = new StringReader(""); // empty since we're using format headers
        CSVParser parser = new CSVParser(reader, format);
        
        // Use reflection to access private method since it's called in constructor
        Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
        method.setAccessible(true);
        Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
        
        // Verify header mappings are correct (would fail with mutant)
        assertEquals(0, headerMap.get("Name").intValue());
        assertEquals(1, headerMap.get("Age").intValue());
        assertEquals(2, headerMap.get("City").intValue());
        
        // Verify all indices are correct
        for (int i = 0; i < headers.length; i++) {
            assertEquals(i, headerMap.get(headers[i]).intValue());
        }
    }

 @Test
   public void testInitializeHeader_ValuesShouldBeIntegerObjects() throws Exception {
       // Setup test data
       String[] headers = {"col1", "col2", "col3"};
       CSVFormat format = mock(CSVFormat.class);
       when(format.getHeader()).thenReturn(headers);
       when(format.getSkipHeaderRecord()).thenReturn(false);
       
       CSVParser parser = new CSVParser(new StringReader(""), format);
       
       // Use reflection to access private method
       Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
       method.setAccessible(true);
       Map<String, Integer> headerMap = (Map<String, Integer>) method.invoke(parser);
       
       // Verify the values are proper Integer objects (not just auto-boxed ints)
       for (Integer value : headerMap.values()) {
           // This will fail if the values were put as primitives (auto-boxed)
           assertEquals(Integer.class, value.getClass());
       }
       
       // Verify the mapping is correct
       assertEquals(Integer.valueOf(0), headerMap.get("col1"));
       assertEquals(Integer.valueOf(1), headerMap.get("col2"));
       assertEquals(Integer.valueOf(2), headerMap.get("col3"));
   }

 @Test(expected = IllegalStateException.class)
  public void testInitializeHeader_ShouldDetectReverseIterationMutant() throws Exception {
      // Setup test data with duplicate headers
      String[] headersWithDuplicate = {"col1", "col2", "col1", "col3"};
      
      // Mock CSVFormat behavior
      CSVFormat format = mock(CSVFormat.class);
      when(format.getHeader()).thenReturn(headersWithDuplicate);
      when(format.getSkipHeaderRecord()).thenReturn(false);
      
      // Create parser with mocked format
      Reader reader = new StringReader(""); // empty reader since we're using format headers
      CSVParser parser = new CSVParser(reader, format);
      
      try {
          // This should throw IllegalStateException
          parser.getHeaderMap();
      } catch (IllegalStateException e) {
          // Verify the exception message shows the correct duplicate position
          // Original would show first occurrence (index 0), mutant would show last (index 2)
          assertTrue("Exception message should indicate first duplicate position", 
                    e.getMessage().contains("\"col1\" at index 0"));
          throw e;
      }
  }

 @Test
 public void testInitializeHeader_ShouldProcessHeadersWhenHdrMapIsNull() throws Exception {
     // Setup test data
     String[] headers = {"col1", "col2"};
     
     // Mock CSVFormat behavior
     CSVFormat format = mock(CSVFormat.class);
     when(format.getHeader()).thenReturn(headers);
     when(format.getSkipHeaderRecord()).thenReturn(false);
     
     // Create parser with mocked format
     CSVParser parser = new CSVParser(new StringReader(""), format);
     
     // Use reflection to test private method
     Method method = CSVParser.class.getDeclaredMethod("initializeHeader");
     method.setAccessible(true);
     
     // Invoke the method and get result
     @SuppressWarnings("unchecked")
     Map<String, Integer> result = (Map<String, Integer>) method.invoke(parser);
     
     // Verify the result
     assertNotNull("Header map should not be null", result);
     assertEquals("Header map size should match header count", headers.length, result.size());
     assertEquals("First header should map to index 0", Integer.valueOf(0), result.get("col1"));
     assertEquals("Second header should map to index 1", Integer.valueOf(1), result.get("col2"));
 }

}
