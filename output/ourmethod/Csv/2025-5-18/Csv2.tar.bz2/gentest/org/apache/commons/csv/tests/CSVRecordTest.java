package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                              public void testGet_WhenMappingIsNull_ThrowsIllegalStateException() throws Exception {
                                                                                                  // Setup
                                                                                                  String[] values = {"value1", "value2"};
                                                                                                  
                                                                                                  // Use reflection to access the private constructor
                                                                                                  Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                      String[].class, Map.class, String.class, long.class);
                                                                                                  constructor.setAccessible(true);
                                                                                                  CSVRecord record = constructor.newInstance(values, null, null, 1L);
                                                                                                  
                                                                                                  // Expect exception
                                                                                                  thrown.expect(IllegalStateException.class);
                                                                                                  thrown.expectMessage("No header mapping was specified, the record values can't be accessed by name");
                                                                                                  
                                                                                                  // Test
                                                                                                  record.get("anyName");
                                                                                              }

    @Test
                                                                                              public void testGet_WithNullValuesArray_HandlesCorrectly() {
                                                                                                  // Setup
                                                                                                  java.util.HashMap<String, Integer> mapping = new java.util.HashMap<>();
                                                                                                  mapping.put("header", 0);
                                                                                                  
                                                                                                  // Create CSVRecord instance using reflection since constructor is not public
                                                                                                  CSVRecord record;
                                                                                                  try {
                                                                                                      java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                                                          String[].class, Map.class, String.class, long.class);
                                                                                                      constructor.setAccessible(true);
                                                                                                      record = constructor.newInstance(null, mapping, null, 1L);
                                                                                                  } catch (Exception e) {
                                                                                                      throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                                                                  }
                                                                                                  
                                                                                                  // Expect exception
                                                                                                  thrown.expect(IllegalArgumentException.class);
                                                                                                  thrown.expectMessage("Index for header 'header' is 0 but CSVRecord only has 0 values!");
                                                                                                  
                                                                                                  // Test
                                                                                                  record.get("header");
                                                                                              }

    @Test
                                                      public void testGet_ValidIndex() throws Exception {
                                                          // Arrange
                                                          String[] testValues = {"value1", "value2", "value3"};
                                                          
                                                          // Use reflection to access non-public constructor
                                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                              String[].class, Map.class, String.class, long.class);
                                                          constructor.setAccessible(true);
                                                          CSVRecord record = constructor.newInstance(
                                                              testValues, 
                                                              null, 
                                                              1L);
                                                          
                                                          // Act & Assert
                                                          assertEquals("value1", record.get(0));
                                                          assertEquals("value2", record.get(1));
                                                          assertEquals("value3", record.get(2));
                                                      }

    @Test
                                                      public void testGet_EmptyValuesArray() throws Exception {
                                                          // Arrange
                                                          String[] emptyValues = {};
                                                          
                                                          // Use reflection to access the package-private constructor
                                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                              String[].class, Map.class, String.class, long.class);
                                                          constructor.setAccessible(true);
                                                          
                                                          // Expect exception
                                                          
                                                          // Act
                                                      }

    @Test
                                                      public void testGet_NegativeIndex() throws Exception {
                                                          // Arrange
                                                          String[] testValues = {"value1", "value2"};
                                                          
                                                          // Create instance using reflection since constructor is not public
                                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                              String[].class, Map.class, String.class, long.class);
                                                          constructor.setAccessible(true);
                                                          
                                                          // Expect exception
                                                          
                                                          // Act
                                                      }

    @Test
                                                      public void testGet_IndexOutOfBounds() throws Exception {
                                                          // Arrange
                                                          String[] testValues = {"value1", "value2"};
                                                          
                                                          // Use reflection to access package-private constructor
                                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                              String[].class, Map.class, String.class, long.class);
                                                          constructor.setAccessible(true);
                                                          
                                                          // Expect exception
                                                          thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                          
                                                          // Act
                                                      }

    @Test
                                                      public void testGet_NullValuesArrayUsesEmptyArray() throws Exception {
                                                          // Arrange
                                                          String[] EMPTY_STRING_ARRAY = new String[0];
                                                          
                                                          // Use reflection to access the private constructor
                                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                              String[].class, Map.class, String.class, long.class);
                                                          constructor.setAccessible(true);
                                                          
                                                          // Expect exception (since EMPTY_STRING_ARRAY has length 0)
                                                          thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                          
                                                          // Act
                                                      }

    @Test
                                                      public void testGet_WithNullValuesInArray() throws Exception {
                                                          // Arrange
                                                          String[] testValues = {null, "value2", null};
                                                          
                                                          // Use reflection to access non-public constructor
                                                          Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                              String[].class, Map.class, String.class, long.class);
                                                          constructor.setAccessible(true);
                                                          
                                                          // Act & Assert
                                                      }

    @Test
                                                      public void testGet_WhenNameNotInMapping_ReturnsNull() {
                                                          // Setup
                                                          String[] values = {"value1", "value2"};
                                                          
                                                          // Use reflection to access package-private constructor
                                                          CSVRecord record;
                                                          try {
                                                              Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                  String[].class, Map.class, String.class, long.class);
                                                              constructor.setAccessible(true);
                                                          } catch (Exception e) {
                                                              throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                          }
                                                          
                                                          // Test
                                                      }

    @Test
                                                      public void testGet_WhenNameExists_ReturnsCorrectValue() throws Exception {
                                                          // Setup
                                                          String[] values = {"value1", "value2"};
                                                          java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
                                                          mapping.put("header1", 0);
                                                          mapping.put("header2", 1);
                                                          
                                                          // Use reflection to access the private constructor
                                                          java.lang.reflect.Constructor<org.apache.commons.csv.CSVRecord> constructor = 
                                                              org.apache.commons.csv.CSVRecord.class.getDeclaredConstructor(
                                                                  String[].class, 
                                                                  java.util.Map.class, 
                                                                  String.class, 
                                                                  long.class);
                                                          constructor.setAccessible(true);
                                                          org.apache.commons.csv.CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                          
                                                          // Test
                                                          assertEquals("value1", record.get("header1"));
                                                          assertEquals("value2", record.get("header2"));
                                                      }

    @Test
                                                      public void testGet_WithEmptyValuesArray_HandlesCorrectly() {
                                                          // Setup
                                                          String[] values = {};
                                                          java.util.Map<String, Integer> mapping = new java.util.HashMap<String, Integer>();
                                                          mapping.put("header", 0);
                                                          
                                                          // Use reflection to access the package-private constructor
                                                          try {
                                                              Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                                                                  String[].class, java.util.Map.class, String.class, long.class);
                                                              constructor.setAccessible(true);
                                                              CSVRecord record = constructor.newInstance(values, mapping, null, 1L);
                                                              
                                                              // Expect exception
                                                              thrown.expect(IllegalArgumentException.class);
                                                              thrown.expectMessage("Index for header 'header' is 0 but CSVRecord only has 0 values!");
                                                              
                                                              // Test
                                                              record.get("header");
                                                          } catch (Exception e) {
                                                              throw new RuntimeException("Failed to create CSVRecord instance", e);
                                                          }
                                                      }

    @Test
             public void testGetShouldNotCatchGeneralException() throws Exception {
                 // Create a mock array that throws something other than ArrayIndexOutOfBoundsException
                 String[] mockValues = mock(String[].class);
                 when(mockValues[0]).thenThrow(new RuntimeException("Test exception"));
             
                 // Get the CSVRecord constructor using reflection
                 Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                     String[].class, Map.class, String.class, long.class);
                 constructor.setAccessible(true);
                 
                 // Create CSVRecord with our mock array using reflection
                 CSVRecord record = constructor.newInstance(mockValues, null, null, 0L);
             
                 // Expect the RuntimeException to be thrown (original behavior)
                 thrown.expect(RuntimeException.class);
                 thrown.expectMessage("Test exception");
             
                 // Call get(0) which should throw
                 record.get(0);
                 
                 // If the mutant is present (catching Exception), this test will fail
                 // because the RuntimeException would be caught instead of propagated
             }

    @Test(expected = NullPointerException.class)
             public void testGetShouldNotCatchOtherExceptions() throws Exception {
                 // Setup
                 Map<String, Integer> mockMapping = mock(Map.class);
                 when(mockMapping.get(anyString())).thenReturn(0); // Return index 0
                 
                 // Create a values array that will throw NPE when accessed
                 String[] values = new String[1];
                 values[0] = null;
                 
                 // Use reflection to access the private constructor
                 Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                     String[].class, Map.class, String.class, long.class);
                 constructor.setAccessible(true);
                 
                 // Create CSVRecord with our test data
                 CSVRecord record = constructor.newInstance(values, mockMapping, null, 1L);
                 
                 // This should throw NPE in original code (which we expect)
                 // But would be caught and converted to IAE in mutant
                 values[0].toString(); // This will throw NPE when accessed
                 record.get("anyHeader");
             }

    @Test
        public void testGet_ShouldThrowExceptionWithCorrectIndexInMessage_WhenIndexIsOutOfBounds() {
            // Arrange
            String[] values = {"value1", "value2"};
            java.util.Map<String, Integer> mapping = new java.util.HashMap<>();
            mapping.put("header1", 5); // This index is out of bounds
            
            // Use reflection to access the non-public constructor
            CSVRecord record;
            try {
                java.lang.reflect.Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                    String[].class, java.util.Map.class, String.class, long.class);
                constructor.setAccessible(true);
                record = constructor.newInstance(values, mapping, null, 1);
            } catch (Exception e) {
                throw new RuntimeException("Failed to create CSVRecord instance", e);
            }
            
            // Act
            try {
                record.get("header1");
                fail("Expected IllegalArgumentException to be thrown");
            } catch (IllegalArgumentException e) {
                // Assert
                String expectedMessage = "Index for header 'header1' is 5 but CSVRecord only has 2 values!";
                assertTrue("Exception message should contain correct index", 
                          e.getMessage().contains("5"));
                assertFalse("Exception message should not show index as 0", 
                           e.getMessage().contains("0 but CSVRecord"));
                throw e;
            }
        }

    @Test
    public void testGetIntShouldReturnCorrectValueAtIndex() throws Exception {
        // Setup test data
        String[] testValues = {"first", "second", "third"};
        java.util.Map<String, Integer> testMapping = new java.util.HashMap<String, Integer>();
        
        // Get the constructor using reflection
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, java.util.Map.class, String.class, long.class);
        constructor.setAccessible(true);
        
        // Create record instance
        CSVRecord record = constructor.newInstance(testValues, testMapping, null, 1L);
     
        // Test getting each value by index
        assertEquals("first", record.get(0));  // Would pass for both original and mutant
        assertEquals("second", record.get(1)); // Would fail for mutant (returns "first")
        assertEquals("third", record.get(2));  // Would fail for mutant (returns "first")
        
        // Additional edge case - empty array
        CSVRecord emptyRecord = constructor.newInstance(new String[0], testMapping, null, 2L);
        try {
            emptyRecord.get(0);
            fail("Expected IndexOutOfBoundsException");
        } catch (IndexOutOfBoundsException e) {
            // Expected behavior
        }
    }


}
