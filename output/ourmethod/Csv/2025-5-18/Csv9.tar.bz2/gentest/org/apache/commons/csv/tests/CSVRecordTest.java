package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                   public void testPutIn_NullMapping() throws Exception {
                       // Setup
                       String[] values = {"val1", "val2"};
                       Map<String, Integer> mapping = null;
                       Map<String, String> inputMap = new HashMap<>();
                       
                       // Get constructor via reflection
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       // Get method via reflection
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       
                       // Execute
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertTrue(result.isEmpty());
                   }

    @Test
                   public void testPutIn_EmptyMapping() throws Exception {
                       // Setup
                       String[] values = {"val1", "val2"};
                       Map<String, Integer> mapping = new HashMap<>();
                       
                       // Get constructor via reflection and make it accessible
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       Map<String, String> inputMap = new HashMap<>();
                       
                       // Get method via reflection and make it accessible
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       
                       // Execute
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertTrue(result.isEmpty());
                   }

    @Test
                   public void testPutIn_ValidMappings() throws Exception {
                       // Setup
                       String[] values = {"val1", "val2", "val3"};
                       Map<String, Integer> mapping = new HashMap<>();
                       mapping.put("key1", 0);
                       mapping.put("key2", 1);
                       mapping.put("key3", 2);
                       
                       // Use reflection to access non-public constructor
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       Map<String, String> inputMap = new HashMap<>();
                       
                       // Use reflection to access non-public putIn method
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       
                       // Execute
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertEquals(3, result.size());
                       assertEquals("val1", result.get("key1"));
                       assertEquals("val2", result.get("key2"));
                       assertEquals("val3", result.get("key3"));
                   }

    @Test
                   public void testPutIn_OutOfBoundsMappings() throws Exception {
                       // Setup
                       String[] values = {"val1", "val2"};
                       Map<String, Integer> mapping = new HashMap<>();
                       mapping.put("key1", 0);
                       mapping.put("key2", 1);
                       mapping.put("key3", 2);  // Out of bounds
                       mapping.put("key4", -1); // Invalid index
                       
                       // Use reflection to access non-public constructor
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       Map<String, String> inputMap = new HashMap<>();
                       
                       // Use reflection to access non-public method
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertEquals(2, result.size()); // Only valid mappings should be added
                       assertEquals("val1", result.get("key1"));
                       assertEquals("val2", result.get("key2"));
                       assertFalse(result.containsKey("key3"));
                       assertFalse(result.containsKey("key4"));
                   }

    @Test
                   public void testPutIn_NullValuesArray() throws Exception {
                       // Setup
                       String[] values = null;
                       Map<String, Integer> mapping = new HashMap<>();
                       mapping.put("key1", 0);
                       mapping.put("key2", 1);
                       
                       // Use reflection to access private constructor
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       Map<String, String> inputMap = new HashMap<>();
                       
                       // Use reflection to access private putIn method
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       
                       // Execute
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertTrue(result.isEmpty()); // Shouldn't add anything with null values array
                   }

    @Test
                   public void testPutIn_MixedValidAndInvalidMappings() throws Exception {
                       // Setup
                       String[] values = {"val1", "val2", "val3"};
                       Map<String, Integer> mapping = new HashMap<>();
                       mapping.put("key1", 0);  // valid
                       mapping.put("key2", 1);  // valid
                       mapping.put("key3", 3);  // invalid (out of bounds)
                       mapping.put("key4", -1); // invalid
                       mapping.put("key5", 2);  // valid
                       
                       // Get CSVRecord constructor via reflection
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       Map<String, String> inputMap = new HashMap<>();
                       
                       // Get putIn method via reflection
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       
                       // Execute
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertEquals(3, result.size());
                       assertEquals("val1", result.get("key1"));
                       assertEquals("val2", result.get("key2"));
                       assertEquals("val3", result.get("key5"));
                       assertFalse(result.containsKey("key3"));
                       assertFalse(result.containsKey("key4"));
                   }

    @Test
                   public void testPutIn_PreservesExistingMapEntries() throws Exception {
                       // Setup
                       String[] values = {"val1", "val2"};
                       Map<String, Integer> mapping = new HashMap<>();
                       mapping.put("key1", 0);
                       mapping.put("key2", 1);
                       
                       // Use reflection to create CSVRecord instance
                       Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                           String[].class, Map.class, String.class, long.class);
                       constructor.setAccessible(true);
                       CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
                       
                       Map<String, String> inputMap = new HashMap<>();
                       inputMap.put("existingKey", "existingValue");
                       
                       // Use reflection to invoke putIn method
                       Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
                       putInMethod.setAccessible(true);
                       @SuppressWarnings("unchecked")
                       Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
                       
                       // Verify
                       assertSame(inputMap, result);
                       assertEquals(3, result.size());
                       assertEquals("val1", result.get("key1"));
                       assertEquals("val2", result.get("key2"));
                       assertEquals("existingValue", result.get("existingKey"));
                   }

    @Test
              public void testIterator_ShouldReturnNonNullIterator() throws Exception {
                  // Arrange
                  String[] testValues = {"value1", "value2", "value3"};
                  Map<String, Integer> mapping = new HashMap<>();
                  mapping.put("col1", 0);
                  mapping.put("col2", 1);
                  mapping.put("col3", 2);
                  
                  // Use reflection to access package-private constructor
                  Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                      String[].class, Map.class, String.class, long.class);
                  constructor.setAccessible(true);
                  CSVRecord record = constructor.newInstance(testValues, mapping, "comment", 1L);
                  
                  // Act
                  Iterator<String> iterator = record.iterator();
                  
                  // Assert
                  assertNotNull("Iterator should not be null", iterator);
                  assertTrue("Iterator should have next value", iterator.hasNext());
                  assertEquals("First value should match", "value1", iterator.next());
                  assertEquals("Second value should match", "value2", iterator.next());
                  assertEquals("Third value should match", "value3", iterator.next());
                  assertFalse("Iterator should be exhausted", iterator.hasNext());
              }

    @Test
              public void testIterator_WithEmptyValues_ShouldReturnEmptyIterator() throws Exception {
                  // Arrange
                  String[] testValues = {};
                  Map<String, Integer> mapping = new HashMap<>();
                  
                  // Use reflection to access private constructor
                  Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                      String[].class, Map.class, String.class, long.class);
                  constructor.setAccessible(true);
                  CSVRecord record = constructor.newInstance(testValues, mapping, "comment", 1L);
                  
                  // Act
                  Iterator<String> iterator = record.iterator();
                  
                  // Assert
                  assertNotNull("Iterator should not be null even for empty values", iterator);
                  assertFalse("Iterator should be empty", iterator.hasNext());
              }

    @Test
         public void testIteratorReturnsBasicIteratorNotListIterator() {
             // Setup test data
             String[] values = {"value1", "value2", "value3"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("col1", 0);
             mapping.put("col2", 1);
             mapping.put("col3", 2);
             
             // Create test object using reflection since constructor is not public
             CSVRecord record;
             try {
                 Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                     String[].class, Map.class, String.class, long.class);
                 constructor.setAccessible(true);
                 record = constructor.newInstance(values, mapping, null, 1L);
             } catch (Exception e) {
                 throw new RuntimeException("Failed to create CSVRecord instance", e);
             }
             
             // Get the iterator
             Iterator<String> iterator = record.iterator();
             
             // Verify it's not a ListIterator
             assertFalse("Iterator should not be a ListIterator", 
                        iterator instanceof java.util.ListIterator);
             
             // Verify it's exactly an Iterator
             assertEquals("Returned object should be exactly an Iterator",
                         java.util.Iterator.class, 
                         iterator.getClass().getInterfaces()[0]);
         }

    @Test
    public void testIterator_ShouldReturnNonNullIterator1() throws Exception {
        // Arrange
        String[] testValues = {"value1", "value2", "value3"};
        Map<String, Integer> testMapping = new HashMap<>();
        testMapping.put("col1", 0);
        testMapping.put("col2", 1);
        testMapping.put("col3", 2);
        
        // Use reflection to access the package-private constructor
        Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
            String[].class, Map.class, String.class, long.class);
        constructor.setAccessible(true);
        CSVRecord record = constructor.newInstance(testValues, testMapping, "test comment", 1L);
        
        // Act
        Iterator<String> iterator = record.iterator();
        
        // Assert
        assertNotNull("Iterator should not be null", iterator);
        
        // Verify we can actually iterate through the values
        assertTrue("Iterator should have first element", iterator.hasNext());
        assertEquals("value1", iterator.next());
        assertTrue("Iterator should have second element", iterator.hasNext());
        assertEquals("value2", iterator.next());
        assertTrue("Iterator should have third element", iterator.hasNext());
        assertEquals("value3", iterator.next());
        assertFalse("Iterator should have no more elements", iterator.hasNext());
    }


}
