package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
 
public class CSVFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                    public void testNewFormat_WithValidDelimiter() {
                                                                                                        // Test with typical delimiter
                                                                                                        char delimiter = ',';
                                                                                                        CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                                        assertNull(format.getQuoteCharacter());
                                                                                                        assertNull(format.getQuoteMode());
                                                                                                        assertNull(format.getCommentMarker());
                                                                                                        assertNull(format.getEscapeCharacter());
                                                                                                        assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                                        assertFalse(format.getIgnoreEmptyLines());
                                                                                                        assertNull(format.getRecordSeparator());
                                                                                                        assertNull(format.getNullString());
                                                                                                        assertNull(format.getHeader());
                                                                                                        assertFalse(format.getSkipHeaderRecord());
                                                                                                        assertFalse(format.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_WithTabDelimiter() {
                                                                                                        // Test with tab character as delimiter
                                                                                                        char delimiter = '\t';
                                                                                                        CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                                        assertNull(format.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_WithPipeDelimiter() {
                                                                                                        // Test with pipe character as delimiter
                                                                                                        char delimiter = '|';
                                                                                                        CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                                        assertNull(format.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_WithSemicolonDelimiter() {
                                                                                                        // Test with semicolon character as delimiter
                                                                                                        char delimiter = ';';
                                                                                                        CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                                        assertNull(format.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_WithNonPrintableDelimiter() {
                                                                                                        // Test with non-printable character as delimiter (but not line break)
                                                                                                        char delimiter = '\u0001';
                                                                                                        CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        assertEquals(delimiter, format.getDelimiter());
                                                                                                        assertNull(format.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_WithLineBreakDelimiter_ShouldThrowException() {
                                                                                                        // Test that line break delimiter throws IllegalArgumentException
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                        
                                                                                                        char delimiter = '\n';
                                                                                                        CSVFormat.newFormat(delimiter);
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_WithCarriageReturnDelimiter_ShouldThrowException() {
                                                                                                        // Test that carriage return delimiter throws IllegalArgumentException
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                        
                                                                                                        char delimiter = '\r';
                                                                                                        CSVFormat.newFormat(delimiter);
                                                                                                    }

 @Test
                                                                                                    public void testNewFormat_DefaultValues() {
                                                                                                        // Verify all default values when only delimiter is specified
                                                                                                        char delimiter = ',';
                                                                                                        CSVFormat format = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        // Verify all other fields are set to defaults (null or false)
                                                                                                        assertNull("Quote character should be null", format.getQuoteCharacter());
                                                                                                        assertNull("Quote mode should be null", format.getQuoteMode());
                                                                                                        assertNull("Comment marker should be null", format.getCommentMarker());
                                                                                                        assertNull("Escape character should be null", format.getEscapeCharacter());
                                                                                                        assertFalse("Ignore surrounding spaces should be false", format.getIgnoreSurroundingSpaces());
                                                                                                        assertFalse("Ignore empty lines should be false", format.getIgnoreEmptyLines());
                                                                                                        assertNull("Record separator should be null", format.getRecordSeparator());
                                                                                                        assertNull("Null string should be null", format.getNullString());
                                                                                                        assertNull("Header should be null", format.getHeader());
                                                                                                        assertFalse("Skip header record should be false", format.getSkipHeaderRecord());
                                                                                                        assertFalse("Allow missing column names should be false", format.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testEquals_SameObject() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        assertTrue(format.equals(format));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_NullObject() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        assertFalse(format.equals(null));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentClass() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        assertFalse(format.equals("Not a CSVFormat object"));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_AllFieldsEqual() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withQuote('"')
                                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                                            .withCommentMarker('#')
                                                                                                            .withEscape('\\')
                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                            .withRecordSeparator("\r\n")
                                                                                                            .withNullString("NULL")
                                                                                                            .withHeader("col1", "col2")
                                                                                                            .withSkipHeaderRecord(true);
                                                                                                
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withQuote('"')
                                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                                            .withCommentMarker('#')
                                                                                                            .withEscape('\\')
                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                            .withRecordSeparator("\r\n")
                                                                                                            .withNullString("NULL")
                                                                                                            .withHeader("col1", "col2")
                                                                                                            .withSkipHeaderRecord(true);
                                                                                                
                                                                                                        assertTrue(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentDelimiter() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',');
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(';');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentQuoteCharacter() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withQuote('"');
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withQuote('\'');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNullQuoteCharacter() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withQuote(null);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withQuote('"');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentQuoteMode() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withQuoteMode(QuoteMode.ALL);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withQuoteMode(QuoteMode.MINIMAL);
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentCommentMarker() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withCommentMarker('#');
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withCommentMarker('!');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNullCommentMarker() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withCommentMarker(null);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withCommentMarker('#');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentEscapeCharacter() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withEscape('\\');
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withEscape('/');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNullEscapeCharacter() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withEscape(null);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withEscape('\\');
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentNullString() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withNullString("NULL");
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withNullString("NA");
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNullNullString() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withNullString(null);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withNullString("NULL");
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentHeader() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withHeader("col1", "col2");
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withHeader("colA", "colB");
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNullHeader() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withHeader(null);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withHeader("col1", "col2");
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentIgnoreSurroundingSpaces() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withIgnoreSurroundingSpaces(true);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withIgnoreSurroundingSpaces(false);
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentIgnoreEmptyLines() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withIgnoreEmptyLines(true);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withIgnoreEmptyLines(false);
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentSkipHeaderRecord() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withSkipHeaderRecord(true);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withSkipHeaderRecord(false);
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_DifferentRecordSeparator() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withRecordSeparator("\r\n");
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withRecordSeparator("\n");
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testEquals_OneNullRecordSeparator() {
                                                                                                        CSVFormat format1 = CSVFormat.newFormat(',').withRecordSeparator(null);
                                                                                                        CSVFormat format2 = CSVFormat.newFormat(',').withRecordSeparator("\r\n");
                                                                                                        assertFalse(format1.equals(format2));
                                                                                                    }

 @Test
                                                                                                    public void testFormat_TypicalValues() {
                                                                                                        // Setup CSVFormat with default configuration
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        Object[] values = {"John", "Doe", 30, "New York"};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("John,Doe,30,New York", result);
                                                                                                    }

 @Test
                                                                                                    public void testFormat_EmptyValues() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        Object[] values = {};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("", result);
                                                                                                    }

 @Test
                                                                                                    public void testFormat_NullValues() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
                                                                                                        Object[] values = {"Alice", null, "Bob"};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("Alice,NULL,Bob", result);
                                                                                                    }

 @Test
                                                                                                    public void testFormat_WithQuotes() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withQuote('"').withQuoteMode(QuoteMode.ALL);
                                                                                                        Object[] values = {"Hello", "World"};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("\"Hello\",\"World\"", result);
                                                                                                    }

 @Test
                                                                                                    public void testFormat_WithCustomDelimiter() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(';');
                                                                                                        Object[] values = {"A", "B", "C"};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("A;B;C", result);
                                                                                                    }

 @Test
                                                                                                    public void testFormat_WithSpecialCharacters() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
                                                                                                        Object[] values = {"Line\nBreak", "Quote\"Me"};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("Line\\nBreak,Quote\\\"Me", result);
                                                                                                    }

 @Test
                                                                                                    public void testFormat_TrimsOutput() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        Object[] values = {"  Value  ", "Another  "};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("  Value  ,Another  ", result); // Note: Only trailing whitespace from the entire string is trimmed
                                                                                                    }

 @Test
                                                                                                    public void testFormat_ThrowsIllegalStateExceptionOnIOError() throws IOException {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        CSVPrinter mockPrinter = mock(CSVPrinter.class);
                                                                                                        doThrow(new IOException("Test exception")).when(mockPrinter).printRecord(any(Object[].class));
                                                                                                        
                                                                                                        // Replace the real printer with our mock
                                                                                                        CSVFormat spyFormat = spy(format);
                                                                                                        when(spyFormat.print(any(Appendable.class))).thenReturn(mockPrinter);
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(IllegalStateException.class);
                                                                                                        thrown.expectMessage("java.io.IOException: Test exception");
                                                                                                        
                                                                                                        // Test
                                                                                                        spyFormat.format(new Object[]{"test"});
                                                                                                    }

 @Test
                                                                                                    public void testFormat_WithRecordSeparator() {
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
                                                                                                        Object[] values = {"First", "Second"};
                                                                                                        
                                                                                                        String result = format.format(values);
                                                                                                        assertEquals("First,Second", result); // Note: Record separator only affects multi-record printing
                                                                                                    }

 @Test
                                                                                                    public void testGetCommentMarker_UsingDefaultFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character commentMarker = defaultFormat.getCommentMarker();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNull(commentMarker);
                                                                                                    }

 @Test
                                                                                                    public void testGetCommentMarker_UsingExcelFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat excelFormat = CSVFormat.EXCEL;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character commentMarker = excelFormat.getCommentMarker();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNull(commentMarker);
                                                                                                    }

 @Test
                                                                                                    public void testGetCommentMarker_UsingTDFFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat tdfFormat = CSVFormat.TDF;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character commentMarker = tdfFormat.getCommentMarker();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNull(commentMarker);
                                                                                                    }

 @Test
                                                                                                    public void testGetCommentMarker_UsingMySQLFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat mysqlFormat = CSVFormat.MYSQL;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character commentMarker = mysqlFormat.getCommentMarker();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNull(commentMarker);
                                                                                                    }

 @Test
                                                                                                    public void testGetCommentMarker_UsingRFC4180Format() {
                                                                                                        // Arrange
                                                                                                        CSVFormat rfc4180Format = CSVFormat.RFC4180;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character commentMarker = rfc4180Format.getCommentMarker();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNull(commentMarker);
                                                                                                    }

 @Test
                                                                                                    public void testGetCommentMarker_AfterSettingWithMethod() {
                                                                                                        // Arrange
                                                                                                        Character expectedCommentMarker = '!';
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withCommentMarker(expectedCommentMarker);
                                                                                                        
                                                                                                        // Act
                                                                                                        Character actualCommentMarker = format.getCommentMarker();
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_DefaultFormat() {
                                                                                                        // Test with DEFAULT format (comma delimiter)
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        assertEquals(',', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_TabDelimitedFormat() {
                                                                                                        // Test with TDF format (tab delimiter)
                                                                                                        CSVFormat format = CSVFormat.TDF;
                                                                                                        assertEquals('\t', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_CustomFormat() {
                                                                                                        // Test with custom format (semicolon delimiter)
                                                                                                        CSVFormat format = CSVFormat.newFormat(';');
                                                                                                        assertEquals(';', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_ExcelFormat() {
                                                                                                        // Test with EXCEL format (comma delimiter)
                                                                                                        CSVFormat format = CSVFormat.EXCEL;
                                                                                                        assertEquals(',', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_RFC4180Format() {
                                                                                                        // Test with RFC4180 format (comma delimiter)
                                                                                                        CSVFormat format = CSVFormat.RFC4180;
                                                                                                        assertEquals(',', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_MySQLFormat() {
                                                                                                        // Test with MYSQL format (tab delimiter)
                                                                                                        CSVFormat format = CSVFormat.MYSQL;
                                                                                                        assertEquals('\t', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_NewFormatWithPipe() {
                                                                                                        // Test with new format using pipe delimiter
                                                                                                        CSVFormat format = CSVFormat.newFormat('|');
                                                                                                        assertEquals('|', format.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetDelimiter_AfterWithDelimiterModification() {
                                                                                                        // Test that withDelimiter creates a new instance with the correct delimiter
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        CSVFormat modified = original.withDelimiter(';');
                                                                                                        assertEquals(';', modified.getDelimiter());
                                                                                                        // Original should remain unchanged
                                                                                                        assertEquals(',', original.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testGetEscapeCharacter_UsingDefaultFormat() {
                                                                                                        // Arrange - Using the predefined DEFAULT format
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character actualEscape = format.getEscapeCharacter();
                                                                                                        
                                                                                                        // Assert - Verify the default escape character is null
                                                                                                        assertNull(actualEscape);
                                                                                                    }

 @Test
                                                                                                    public void testGetEscapeCharacter_UsingExcelFormat() {
                                                                                                        // Arrange - Using the predefined EXCEL format
                                                                                                        CSVFormat format = CSVFormat.EXCEL;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character actualEscape = format.getEscapeCharacter();
                                                                                                        
                                                                                                        // Assert - Verify Excel format uses double quote as escape
                                                                                                        assertEquals(Character.valueOf('"'), actualEscape);
                                                                                                    }

 @Test
                                                                                                    public void testGetEscapeCharacter_UsingRFC4180Format() {
                                                                                                        // Arrange - Using the predefined RFC4180 format
                                                                                                        CSVFormat format = CSVFormat.RFC4180;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character actualEscape = format.getEscapeCharacter();
                                                                                                        
                                                                                                        // Assert - Verify RFC4180 format uses double quote as escape
                                                                                                        assertEquals(Character.valueOf('"'), actualEscape);
                                                                                                    }

 @Test
                                                                                                    public void testGetEscapeCharacter_UsingTDFFormat() {
                                                                                                        // Arrange - Using the predefined TDF format
                                                                                                        CSVFormat format = CSVFormat.TDF;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character actualEscape = format.getEscapeCharacter();
                                                                                                        
                                                                                                        // Assert - Verify TDF format has null escape character
                                                                                                        assertNull(actualEscape);
                                                                                                    }

 @Test
                                                                                                    public void testGetEscapeCharacter_UsingMySQLFormat() {
                                                                                                        // Arrange - Using the predefined MySQL format
                                                                                                        CSVFormat format = CSVFormat.MYSQL;
                                                                                                        
                                                                                                        // Act
                                                                                                        Character actualEscape = format.getEscapeCharacter();
                                                                                                        
                                                                                                        // Assert - Verify MySQL format has null escape character
                                                                                                        assertNull(actualEscape);
                                                                                                    }

 @Test
                                                                                                    public void testGetEscapeCharacter_AfterModificationWithWithEscape() {
                                                                                                        // Arrange - Start with default format
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Act - Modify the escape character
                                                                                                        Character newEscape = '\\';
                                                                                                        format = format.withEscape(newEscape);
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertEquals(newEscape, format.getEscapeCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testGetAllowMissingColumnNames_DefaultFormat() {
                                                                                                        // Test with the DEFAULT format instance
                                                                                                        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testGetAllowMissingColumnNames_RFC4180Format() {
                                                                                                        // Test with the RFC4180 format instance
                                                                                                        assertFalse(CSVFormat.RFC4180.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testGetAllowMissingColumnNames_ExcelFormat() {
                                                                                                        // Test with the EXCEL format instance
                                                                                                        assertFalse(CSVFormat.EXCEL.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testGetAllowMissingColumnNames_TDFFormat() {
                                                                                                        // Test with the TDF format instance
                                                                                                        assertFalse(CSVFormat.TDF.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testGetAllowMissingColumnNames_MySQLFormat() {
                                                                                                        // Test with the MYSQL format instance
                                                                                                        assertFalse(CSVFormat.MYSQL.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testGetAllowMissingColumnNames_AfterWithMethod() {
                                                                                                        // Test that withAllowMissingColumnNames modifies the value correctly
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        CSVFormat modified = original.withAllowMissingColumnNames(true);
                                                                                                        
                                                                                                        assertFalse(original.getAllowMissingColumnNames());
                                                                                                        assertTrue(modified.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreEmptyLines_DefaultFormat() {
                                                                                                        // Test with the DEFAULT format instance
                                                                                                        assertFalse("DEFAULT format should have ignoreEmptyLines false by default", 
                                                                                                                   CSVFormat.DEFAULT.getIgnoreEmptyLines());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreEmptyLines_ExcelFormat() {
                                                                                                        // Test with the EXCEL format instance
                                                                                                        assertFalse("EXCEL format should have ignoreEmptyLines false by default", 
                                                                                                                   CSVFormat.EXCEL.getIgnoreEmptyLines());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreEmptyLines_RFC4180Format() {
                                                                                                        // Test with the RFC4180 format instance
                                                                                                        assertFalse("RFC4180 format should have ignoreEmptyLines false by default", 
                                                                                                                   CSVFormat.RFC4180.getIgnoreEmptyLines());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreEmptyLines_AfterWithIgnoreEmptyLines() {
                                                                                                        // Test that withIgnoreEmptyLines modifies the setting
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        CSVFormat modified = original.withIgnoreEmptyLines(true);
                                                                                                        
                                                                                                        assertFalse("Original format should remain unchanged", 
                                                                                                                   original.getIgnoreEmptyLines());
                                                                                                        assertTrue("Modified format should have ignoreEmptyLines true", 
                                                                                                                  modified.getIgnoreEmptyLines());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreSurroundingSpaces_DefaultFormat() {
                                                                                                        // Test with the DEFAULT format instance
                                                                                                        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreSurroundingSpaces_ExcelFormat() {
                                                                                                        // Test with the EXCEL format instance
                                                                                                        assertFalse(CSVFormat.EXCEL.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreSurroundingSpaces_RFC4180Format() {
                                                                                                        // Test with the RFC4180 format instance
                                                                                                        assertFalse(CSVFormat.RFC4180.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreSurroundingSpaces_TDFFormat() {
                                                                                                        // Test with the TDF format instance
                                                                                                        assertFalse(CSVFormat.TDF.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreSurroundingSpaces_MySQLFormat() {
                                                                                                        // Test with the MYSQL format instance
                                                                                                        assertFalse(CSVFormat.MYSQL.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testGetIgnoreSurroundingSpaces_AfterWithIgnoreSurroundingSpaces() {
                                                                                                        // Test that withIgnoreSurroundingSpaces modifies the value correctly
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        CSVFormat modified = original.withIgnoreSurroundingSpaces(true);
                                                                                                        
                                                                                                        assertFalse(original.getIgnoreSurroundingSpaces());
                                                                                                        assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testGetNullString_UsingPredefinedFormats() {
                                                                                                        // Test with DEFAULT format
                                                                                                        assertNull(CSVFormat.DEFAULT.getNullString());
                                                                                                        
                                                                                                        // Test with RFC4180 format
                                                                                                        assertNull(CSVFormat.RFC4180.getNullString());
                                                                                                        
                                                                                                        // Test with EXCEL format
                                                                                                        assertNull(CSVFormat.EXCEL.getNullString());
                                                                                                        
                                                                                                        // Test with TDF format
                                                                                                        assertNull(CSVFormat.TDF.getNullString());
                                                                                                        
                                                                                                        // Test with MYSQL format
                                                                                                        assertNull(CSVFormat.MYSQL.getNullString());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteCharacter_WithPredefinedFormats() {
                                                                                                        // Test DEFAULT format
                                                                                                        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
                                                                                                        
                                                                                                        // Test RFC4180 format
                                                                                                        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
                                                                                                        
                                                                                                        // Test EXCEL format
                                                                                                        assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
                                                                                                        
                                                                                                        // Test TDF format (tab-delimited)
                                                                                                        assertEquals(null, CSVFormat.TDF.getQuoteCharacter());
                                                                                                        
                                                                                                        // Test MYSQL format
                                                                                                        assertEquals(null, CSVFormat.MYSQL.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteCharacter_AfterWithQuote() {
                                                                                                        // Test that withQuote modifies the quote character
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        Character newQuote = '\'';
                                                                                                        CSVFormat modified = original.withQuote(newQuote);
                                                                                                        
                                                                                                        assertEquals(newQuote, modified.getQuoteCharacter());
                                                                                                        // Original should remain unchanged
                                                                                                        assertEquals(Character.valueOf('"'), original.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteMode_DefaultFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteMode_RFC4180Format() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.RFC4180;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteMode_ExcelFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.EXCEL;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteMode_TDFFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.TDF;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                                    }

 @Test
                                                                                                    public void testGetQuoteMode_MySQLFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.MYSQL;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertNull(format.getQuoteMode());
                                                                                                    }

 @Test
                                                                                                    public void testGetRecordSeparator_DefaultConstructor() {
                                                                                                        // Test with default record separator (likely system line separator)
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        String expected = System.lineSeparator();
                                                                                                        assertEquals(expected, format.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testGetRecordSeparator_RFC4180Format() {
                                                                                                        // Test with RFC4180 standard format
                                                                                                        String expected = "\r\n"; // RFC4180 specifies CRLF
                                                                                                        assertEquals(expected, CSVFormat.RFC4180.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testGetRecordSeparator_ExcelFormat() {
                                                                                                        // Test with Excel format
                                                                                                        String expected = "\r\n"; // Excel typically uses CRLF
                                                                                                        assertEquals(expected, CSVFormat.EXCEL.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testGetRecordSeparator_TabDelimitedFormat() {
                                                                                                        // Test with TDF format
                                                                                                        String expected = "\r\n"; // Typically uses CRLF
                                                                                                        assertEquals(expected, CSVFormat.TDF.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testGetRecordSeparator_MySQLFormat() {
                                                                                                        // Test with MySQL format
                                                                                                        String expected = "\n"; // MySQL typically uses LF
                                                                                                        assertEquals(expected, CSVFormat.MYSQL.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testGetSkipHeaderRecord_DefaultFormat() {
                                                                                                        // Act & Assert
                                                                                                        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
                                                                                                    }

 @Test
                                                                                                    public void testGetSkipHeaderRecord_RFC4180Format() {
                                                                                                        // Act & Assert
                                                                                                        assertFalse(CSVFormat.RFC4180.getSkipHeaderRecord());
                                                                                                    }

 @Test
                                                                                                    public void testGetSkipHeaderRecord_ExcelFormat() {
                                                                                                        // Act & Assert
                                                                                                        assertFalse(CSVFormat.EXCEL.getSkipHeaderRecord());
                                                                                                    }

 @Test
                                                                                                    public void testGetSkipHeaderRecord_TabDelimitedFormat() {
                                                                                                        // Act & Assert
                                                                                                        assertFalse(CSVFormat.TDF.getSkipHeaderRecord());
                                                                                                    }

 @Test
                                                                                                    public void testGetSkipHeaderRecord_MySQLFormat() {
                                                                                                        // Act & Assert
                                                                                                        assertFalse(CSVFormat.MYSQL.getSkipHeaderRecord());
                                                                                                    }

 @Test
                                                                                                    public void testHashCode_DefaultFormat() {
                                                                                                        // Get default format
                                                                                                        CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Calculate hash code of default format
                                                                                                        int hashCode1 = defaultFormat.hashCode();
                                                                                                        
                                                                                                        // Should be consistent
                                                                                                        assertEquals(hashCode1, defaultFormat.hashCode());
                                                                                                    }

 @Test
                                                                                                    public void testIsCommentMarkerSet_WithDefaultFormat() {
                                                                                                        // Test with DEFAULT format (which typically has no comment marker)
                                                                                                        assertFalse("DEFAULT format should have no comment marker", 
                                                                                                                   CSVFormat.DEFAULT.isCommentMarkerSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsCommentMarkerSet_WithOtherPredefinedFormats() {
                                                                                                        // Test with various predefined formats
                                                                                                        assertFalse("RFC4180 format should have no comment marker", 
                                                                                                                   CSVFormat.RFC4180.isCommentMarkerSet());
                                                                                                        assertFalse("EXCEL format should have no comment marker", 
                                                                                                                   CSVFormat.EXCEL.isCommentMarkerSet());
                                                                                                        assertFalse("TDF format should have no comment marker", 
                                                                                                                   CSVFormat.TDF.isCommentMarkerSet());
                                                                                                        assertFalse("MYSQL format should have no comment marker", 
                                                                                                                   CSVFormat.MYSQL.isCommentMarkerSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsEscapeCharacterSet_UsingPredefinedFormats() {
                                                                                                        // Test with predefined formats
                                                                                                        assertFalse("DEFAULT format should not have escape character set", 
                                                                                                                   CSVFormat.DEFAULT.isEscapeCharacterSet());
                                                                                                        
                                                                                                        assertTrue("RFC4180 format should have escape character set", 
                                                                                                                  CSVFormat.RFC4180.isEscapeCharacterSet());
                                                                                                        
                                                                                                        assertFalse("EXCEL format should not have escape character set", 
                                                                                                                   CSVFormat.EXCEL.isEscapeCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsQuoteCharacterSet_WithDefaultFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertTrue(format.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsQuoteCharacterSet_WithExcelFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.EXCEL;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertTrue(format.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsQuoteCharacterSet_WithTDFFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.TDF;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertTrue(format.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsQuoteCharacterSet_WithMySQLFormat() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.MYSQL;
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertFalse(format.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsQuoteCharacterSet_AfterWithQuoteChar() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertTrue(format.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testIsQuoteCharacterSet_AfterWithQuoteNull() {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withQuote(null);
                                                                                                        
                                                                                                        // Act & Assert
                                                                                                        assertFalse(format.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testParse_WithNullReader() throws Exception {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        Reader in = null;
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(NullPointerException.class);
                                                                                                        thrown.expectMessage("in");
                                                                                                        
                                                                                                        // Act
                                                                                                        format.parse(in);
                                                                                                    }

 @Test
                                                                                                    public void testPrint_WithNullAppendable() throws IOException {
                                                                                                        // Arrange
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("Parameter 'out' must not be null");
                                                                                                        
                                                                                                        // Act
                                                                                                        format.print(null);
                                                                                                    }

 @Test
                                                                                                    public void testPrint_WithMockedAppendable() throws IOException {
                                                                                                        // Arrange
                                                                                                        Appendable mockAppendable = mock(Appendable.class);
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Act
                                                                                                        CSVPrinter printer = format.print(mockAppendable);
                                                                                                        
                                                                                                        // Assert
                                                                                                        assertNotNull(printer);
                                                                                                        assertSame(mockAppendable, printer.getOut());
                                                                                                    }

 @Test
                                                                                                    public void testToString_DefaultFormat() {
                                                                                                        // Default format has minimal configuration
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        String expected = "Delimiter=<,> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithAllFeatures() {
                                                                                                        // Create format with all possible features set
                                                                                                        CSVFormat format = CSVFormat.newFormat(';')
                                                                                                            .withQuote('"')
                                                                                                            .withEscape('\\')
                                                                                                            .withCommentMarker('#')
                                                                                                            .withNullString("NULL")
                                                                                                            .withRecordSeparator("\r\n")
                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                            .withSkipHeaderRecord(true)
                                                                                                            .withHeader("col1", "col2", "col3");
                                                                                                        
                                                                                                        String expected = "Delimiter=<;> Escape=<\\> QuoteChar=<\"> CommentStart=<#> " +
                                                                                                                         "NullString=<NULL> RecordSeparator=<\r\n> EmptyLines:ignored " +
                                                                                                                         "SurroundingSpaces:ignored SkipHeaderRecord:true " +
                                                                                                                         "Header:[col1, col2, col3]";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithQuoteCharacterOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat('\t')
                                                                                                            .withQuote('\'');
                                                                                                        
                                                                                                        String expected = "Delimiter=<	> QuoteChar=<'> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithEscapeCharacterOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat('|')
                                                                                                            .withEscape('\\');
                                                                                                        
                                                                                                        String expected = "Delimiter=<|> Escape=<\\> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithCommentMarkerOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                            .withCommentMarker('!');
                                                                                                        
                                                                                                        String expected = "Delimiter=<,> CommentStart=<!> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithNullStringOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                            .withNullString("NA");
                                                                                                        
                                                                                                        String expected = "Delimiter=<,> NullString=<NA> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithRecordSeparatorOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                            .withRecordSeparator("\n");
                                                                                                        
                                                                                                        String expected = "Delimiter=<,> RecordSeparator=<\n> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithHeaderOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                            .withHeader("id", "name", "value");
                                                                                                        
                                                                                                        String expected = "Delimiter=<,> SkipHeaderRecord:false Header:[id, name, value]";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithEmptyLinesAndSurroundingSpaces() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                            .withIgnoreSurroundingSpaces(true);
                                                                                                        
                                                                                                        String expected = "Delimiter=<,> EmptyLines:ignored SurroundingSpaces:ignored SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_WithSkipHeaderRecordOnly() {
                                                                                                        CSVFormat format = CSVFormat.newFormat(',')
                                                                                                            .withSkipHeaderRecord(true);
                                                                                                        
                                                                                                        String expected = "Delimiter=<,> SkipHeaderRecord:true";
                                                                                                        assertEquals(expected, format.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_RFC4180Format() {
                                                                                                        String expected = "Delimiter=<,> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, CSVFormat.RFC4180.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_ExcelFormat() {
                                                                                                        String expected = "Delimiter=<,> QuoteChar=<\"> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, CSVFormat.EXCEL.toString());
                                                                                                    }

 @Test
                                                                                                    public void testToString_TabDelimitedFormat() {
                                                                                                        String expected = "Delimiter=<	> SkipHeaderRecord:false";
                                                                                                        assertEquals(expected, CSVFormat.TDF.toString());
                                                                                                    }

 @Test
                                                                                                    public void testWithDelimiter_LineBreakDelimiters() {
                                                                                                        // Setup base format
                                                                                                        CSVFormat baseFormat = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Test with various line break characters
                                                                                                        char[] lineBreaks = {'\n', '\r', '\u2028', '\u2029'};
                                                                                                        
                                                                                                        for (char lineBreak : lineBreaks) {
                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                            thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                            baseFormat.withDelimiter(lineBreak);
                                                                                                        }
                                                                                                    }

 @Test
                                                                                                    public void testWithDelimiter_FromDefaultFormat() {
                                                                                                        // Test with default format as base
                                                                                                        CSVFormat newFormat = CSVFormat.DEFAULT.withDelimiter('|');
                                                                                                        
                                                                                                        assertEquals('|', newFormat.getDelimiter());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getNullString(), newFormat.getNullString());
                                                                                                        assertArrayEquals(CSVFormat.DEFAULT.getHeader(), newFormat.getHeader());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testWithEscape_ValidCharacter() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        Character escapeChar = '\\';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = original.withEscape(escapeChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(escapeChar, newFormat.getEscapeCharacter());
                                                                                                        assertTrue(newFormat.isEscapeCharacterSet());
                                                                                                        // Verify original remains unchanged
                                                                                                        assertNotEquals(original.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithEscape_NullCharacter() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = original.withEscape(null);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertNull(newFormat.getEscapeCharacter());
                                                                                                        assertFalse(newFormat.isEscapeCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithEscape_LineBreakCharacterShouldThrowException() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        Character lineBreak = '\n';
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("The escape character cannot be a line break");
                                                                                                        
                                                                                                        // Execute
                                                                                                        original.withEscape(lineBreak);
                                                                                                    }

 @Test
                                                                                                    public void testWithEscape_VerifyImmutability() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        Character originalEscape = original.getEscapeCharacter();
                                                                                                        Character newEscape = '|';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat modified = original.withEscape(newEscape);
                                                                                                        
                                                                                                        // Verify original unchanged
                                                                                                        assertEquals(originalEscape, original.getEscapeCharacter());
                                                                                                        // Verify new format has new escape
                                                                                                        assertEquals(newEscape, modified.getEscapeCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithEscape_SameCharacterReturnsSameInstance() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.newFormat(',')
                                                                                                            .withEscape('\\')
                                                                                                            .withQuote('"');
                                                                                                        Character sameEscape = '\\';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat result = original.withEscape(sameEscape);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertSame(original, result);
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_ValidHeader() {
                                                                                                        // Setup original CSVFormat with default values
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Test with single header
                                                                                                        String[] singleHeader = {"Name"};
                                                                                                        CSVFormat newFormat = original.withHeader(singleHeader);
                                                                                                        assertArrayEquals(singleHeader, newFormat.getHeader());
                                                                                                        assertEquals(original.getDelimiter(), newFormat.getDelimiter());
                                                                                                        assertEquals(original.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                        
                                                                                                        // Test with multiple headers
                                                                                                        String[] multiHeader = {"Name", "Age", "Email"};
                                                                                                        newFormat = original.withHeader(multiHeader);
                                                                                                        assertArrayEquals(multiHeader, newFormat.getHeader());
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_NullHeader() {
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        CSVFormat newFormat = original.withHeader((String[]) null);
                                                                                                        assertNull(newFormat.getHeader());
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_EmptyHeader() {
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        String[] emptyHeader = {};
                                                                                                        CSVFormat newFormat = original.withHeader(emptyHeader);
                                                                                                        assertArrayEquals(emptyHeader, newFormat.getHeader());
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_DuplicateHeaders() {
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        String[] duplicateHeader = {"Name", "Name"};
                                                                                                        
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("The header contains a duplicate entry: 'Name'");
                                                                                                        
                                                                                                        original.withHeader(duplicateHeader);
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_PreservesOtherProperties() {
                                                                                                        // Create a custom format with various properties
                                                                                                        CSVFormat original = CSVFormat.newFormat(';')
                                                                                                            .withQuote('"')
                                                                                                            .withQuoteMode(QuoteMode.ALL)
                                                                                                            .withCommentMarker('#')
                                                                                                            .withEscape('\\')
                                                                                                            .withIgnoreSurroundingSpaces(true)
                                                                                                            .withIgnoreEmptyLines(false)
                                                                                                            .withRecordSeparator("\r\n")
                                                                                                            .withNullString("NULL")
                                                                                                            .withSkipHeaderRecord(true)
                                                                                                            .withAllowMissingColumnNames(false);
                                                                                                        
                                                                                                        String[] header = {"ID", "Value"};
                                                                                                        CSVFormat newFormat = original.withHeader(header);
                                                                                                        
                                                                                                        // Verify header was set
                                                                                                        assertArrayEquals(header, newFormat.getHeader());
                                                                                                        
                                                                                                        // Verify all other properties remain unchanged
                                                                                                        assertEquals(';', newFormat.getDelimiter());
                                                                                                        assertEquals(Character.valueOf('"'), newFormat.getQuoteCharacter());
                                                                                                        assertEquals(QuoteMode.ALL, newFormat.getQuoteMode());
                                                                                                        assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                                        assertEquals(Character.valueOf('\\'), newFormat.getEscapeCharacter());
                                                                                                        assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                        assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                                        assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                        assertEquals("NULL", newFormat.getNullString());
                                                                                                        assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                        assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_FromExistingHeader() {
                                                                                                        // Original with existing header
                                                                                                        String[] originalHeader = {"A", "B"};
                                                                                                        CSVFormat original = CSVFormat.DEFAULT.withHeader(originalHeader);
                                                                                                        
                                                                                                        // Change to new header
                                                                                                        String[] newHeader = {"X", "Y", "Z"};
                                                                                                        CSVFormat newFormat = original.withHeader(newHeader);
                                                                                                        
                                                                                                        assertArrayEquals(newHeader, newFormat.getHeader());
                                                                                                        assertNotSame(originalHeader, newFormat.getHeader());
                                                                                                    }

 @Test
                                                                                                    public void testWithHeader_HeaderWithEmptyStrings() {
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        String[] headerWithEmpty = {"", "Value", ""};
                                                                                                        
                                                                                                        // Should not throw exception for empty strings in header
                                                                                                        CSVFormat newFormat = original.withHeader(headerWithEmpty);
                                                                                                        assertArrayEquals(headerWithEmpty, newFormat.getHeader());
                                                                                                    }

 @Test
                                                                                                    public void testWithIgnoreEmptyLines_SameValueReturnsSameInstance() {
                                                                                                        // Setup
                                                                                                        boolean originalIgnoreEmptyLines = true;
                                                                                                        CSVFormat originalFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(originalIgnoreEmptyLines);
                                                                                                        
                                                                                                        // Test
                                                                                                        CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(originalIgnoreEmptyLines);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertSame(originalFormat, newFormat);
                                                                                                    }

 @Test
                                                                                                    public void testWithIgnoreEmptyLines_FromDefaultFormat() {
                                                                                                        // Test with DEFAULT format (which may have different default values)
                                                                                                        CSVFormat newFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(true);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getDelimiter(), newFormat.getDelimiter());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getNullString(), newFormat.getNullString());
                                                                                                        assertArrayEquals(CSVFormat.DEFAULT.getHeader(), newFormat.getHeader());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                        assertEquals(CSVFormat.DEFAULT.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testWithIgnoreSurroundingSpaces_FromDefaultFormat() {
                                                                                                        // Get default format
                                                                                                        CSVFormat defaultFormat = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Call method under test
                                                                                                        CSVFormat newFormat = defaultFormat.withIgnoreSurroundingSpaces(true);
                                                                                                        
                                                                                                        // Verify new setting
                                                                                                        assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                        
                                                                                                        // Verify it's not the same instance
                                                                                                        assertNotSame(defaultFormat, newFormat);
                                                                                                        
                                                                                                        // Verify other properties match default
                                                                                                        assertEquals(defaultFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                        assertEquals(defaultFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                        assertEquals(defaultFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                    }

 @Test
                                                                                                    public void testWithNullString_NullInput() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Test
                                                                                                        CSVFormat result = original.withNullString(null);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertNull(result.getNullString());
                                                                                                        assertFalse(result.isNullStringSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithNullString_EmptyString() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        // Test
                                                                                                        CSVFormat result = original.withNullString("");
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals("", result.getNullString());
                                                                                                        assertTrue(result.isNullStringSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithNullString_VerifyImmutability() {
                                                                                                        // Setup
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        String originalNullString = original.getNullString();
                                                                                                        
                                                                                                        // Test
                                                                                                        CSVFormat modified = original.withNullString("NEW");
                                                                                                        
                                                                                                        // Verify original wasn't modified
                                                                                                        assertEquals(originalNullString, original.getNullString());
                                                                                                        assertEquals("NEW", modified.getNullString());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_StandardQuoteCharacter() {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        char quoteChar = '"';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = format.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                        assertTrue(newFormat.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_SingleQuoteCharacter() {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        char quoteChar = '\'';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = format.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                        assertTrue(newFormat.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_NonPrintableCharacter() {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        char quoteChar = '\u0001'; // ASCII control character
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = format.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                        assertTrue(newFormat.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_LineBreakCharacterShouldThrowException() {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        char quoteChar = '\n';
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                        
                                                                                                        // Execute
                                                                                                        format.withQuote(quoteChar);
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_ZeroCharacter() {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        char quoteChar = '\0';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = format.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                        assertTrue(newFormat.isQuoteCharacterSet());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_VerifyOtherPropertiesUnchanged() {
                                                                                                        // Setup
                                                                                                        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';')
                                                                                                                                          .withRecordSeparator("\r\n")
                                                                                                                                          .withNullString("NULL");
                                                                                                        char quoteChar = '|';
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = format.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify quote character changed
                                                                                                        assertEquals(Character.valueOf(quoteChar), newFormat.getQuoteCharacter());
                                                                                                        
                                                                                                        // Verify other properties remain the same
                                                                                                        assertEquals(';', newFormat.getDelimiter());
                                                                                                        assertEquals("\r\n", newFormat.getRecordSeparator());
                                                                                                        assertEquals("NULL", newFormat.getNullString());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_ValidCharacter() {
                                                                                                        // Setup
                                                                                                        char delimiter = ',';
                                                                                                        char quoteChar = '"';
                                                                                                        CSVFormat baseFormat = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = baseFormat.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(quoteChar, newFormat.getQuoteCharacter().charValue());
                                                                                                        assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                        assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_NullCharacter() {
                                                                                                        // Setup
                                                                                                        char delimiter = ',';
                                                                                                        CSVFormat baseFormat = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = baseFormat.withQuote((Character) null);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertNull(newFormat.getQuoteCharacter());
                                                                                                        assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_LineBreakCharacter() {
                                                                                                        // Setup
                                                                                                        char delimiter = ',';
                                                                                                        char lineBreak = '\n';
                                                                                                        CSVFormat baseFormat = CSVFormat.newFormat(delimiter);
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                        thrown.expectMessage("The quoteChar cannot be a line break");
                                                                                                        
                                                                                                        // Execute
                                                                                                        baseFormat.withQuote(lineBreak);
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_PreservesOtherSettings() {
                                                                                                        // Setup
                                                                                                        char delimiter = '|';
                                                                                                        char quoteChar = '\'';
                                                                                                        String recordSeparator = "\r\n";
                                                                                                        String[] header = {"col1", "col2"};
                                                                                                        CSVFormat baseFormat = CSVFormat.newFormat(delimiter)
                                                                                                            .withRecordSeparator(recordSeparator)
                                                                                                            .withHeader(header)
                                                                                                            .withIgnoreEmptyLines(true)
                                                                                                            .withIgnoreSurroundingSpaces(true);
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = baseFormat.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals(quoteChar, newFormat.getQuoteCharacter().charValue());
                                                                                                        assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                        assertArrayEquals(header, newFormat.getHeader());
                                                                                                        assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                                        assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                                        assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_SameCharacterReturnsSameInstance() {
                                                                                                        // Setup
                                                                                                        char delimiter = ',';
                                                                                                        char quoteChar = '"';
                                                                                                        CSVFormat baseFormat = CSVFormat.newFormat(delimiter).withQuote(quoteChar);
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = baseFormat.withQuote(quoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertSame(baseFormat, newFormat);
                                                                                                    }

 @Test
                                                                                                    public void testWithQuote_DifferentCharacterReturnsNewInstance() {
                                                                                                        // Setup
                                                                                                        char delimiter = ',';
                                                                                                        char oldQuoteChar = '"';
                                                                                                        char newQuoteChar = '\'';
                                                                                                        CSVFormat baseFormat = CSVFormat.newFormat(delimiter).withQuote(oldQuoteChar);
                                                                                                        
                                                                                                        // Execute
                                                                                                        CSVFormat newFormat = baseFormat.withQuote(newQuoteChar);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertNotSame(baseFormat, newFormat);
                                                                                                        assertEquals(newQuoteChar, newFormat.getQuoteCharacter().charValue());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_ValidInput() {
                                                                                                        // Test with typical record separator characters
                                                                                                        char separator1 = '\n';
                                                                                                        char separator2 = '\r';
                                                                                                        char separator3 = '|';
                                                                                                        
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        CSVFormat result1 = format.withRecordSeparator(separator1);
                                                                                                        assertEquals(String.valueOf(separator1), result1.getRecordSeparator());
                                                                                                        
                                                                                                        CSVFormat result2 = format.withRecordSeparator(separator2);
                                                                                                        assertEquals(String.valueOf(separator2), result2.getRecordSeparator());
                                                                                                        
                                                                                                        CSVFormat result3 = format.withRecordSeparator(separator3);
                                                                                                        assertEquals(String.valueOf(separator3), result3.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_NullCharacter() {
                                                                                                        // Test with null character (0)
                                                                                                        char nullChar = '\0';
                                                                                                        
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        CSVFormat result = format.withRecordSeparator(nullChar);
                                                                                                        
                                                                                                        assertEquals(String.valueOf(nullChar), result.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_UnicodeCharacter() {
                                                                                                        // Test with Unicode character
                                                                                                        char unicodeChar = '\u2029'; // Paragraph separator
                                                                                                        
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        CSVFormat result = format.withRecordSeparator(unicodeChar);
                                                                                                        
                                                                                                        assertEquals(String.valueOf(unicodeChar), result.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_VerifyImmutability() {
                                                                                                        // Verify that the original format is not modified
                                                                                                        char separator = ';';
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        
                                                                                                        CSVFormat modified = original.withRecordSeparator(separator);
                                                                                                        
                                                                                                        assertNotSame(original, modified);
                                                                                                        assertNotEquals(original.getRecordSeparator(), modified.getRecordSeparator());
                                                                                                        assertEquals(String.valueOf(separator), modified.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_EmptyStringEquivalent() {
                                                                                                        // Test that passing a character that would result in empty string when converted
                                                                                                        // (though technically impossible as all chars convert to at least one char string)
                                                                                                        // This is more of a theoretical test
                                                                                                        char emptyChar = '\0'; // converts to "\0" which is not empty
                                                                                                        
                                                                                                        CSVFormat format = CSVFormat.DEFAULT;
                                                                                                        CSVFormat result = format.withRecordSeparator(emptyChar);
                                                                                                        
                                                                                                        assertEquals("\0", result.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_FromDifferentFormat() {
                                                                                                        // Test starting from a non-DEFAULT format
                                                                                                        char separator = '~';
                                                                                                        CSVFormat customFormat = CSVFormat.newFormat(',')
                                                                                                            .withQuote('"')
                                                                                                            .withRecordSeparator("\n");
                                                                                                        
                                                                                                        CSVFormat result = customFormat.withRecordSeparator(separator);
                                                                                                        
                                                                                                        assertEquals(String.valueOf(separator), result.getRecordSeparator());
                                                                                                        assertEquals(',', result.getDelimiter());
                                                                                                        assertEquals(Character.valueOf('"'), result.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_String_EmptySeparator() {
                                                                                                        CSVFormat original = CSVFormat.DEFAULT;
                                                                                                        String emptySeparator = "";
                                                                                                        CSVFormat modified = original.withRecordSeparator(emptySeparator);
                                                                                                        
                                                                                                        assertEquals(emptySeparator, modified.getRecordSeparator());
                                                                                                        // Verify other properties remain unchanged from DEFAULT
                                                                                                        assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                        assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_String_NullSeparator() {
                                                                                                        CSVFormat original = CSVFormat.EXCEL;
                                                                                                        String nullSeparator = null;
                                                                                                        CSVFormat modified = original.withRecordSeparator(nullSeparator);
                                                                                                        
                                                                                                        assertNull(modified.getRecordSeparator());
                                                                                                        // Verify other properties remain unchanged from EXCEL
                                                                                                        assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                        assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_ValidSeparator() {
                                                                                                        CSVFormat original = CSVFormat.RFC4180;
                                                                                                        char newSeparator = ';';
                                                                                                        CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                        
                                                                                                        assertEquals(String.valueOf(newSeparator), modified.getRecordSeparator());
                                                                                                        // Verify other properties remain unchanged from RFC4180
                                                                                                        assertEquals(original.getDelimiter(), modified.getDelimiter());
                                                                                                        assertEquals(original.getQuoteCharacter(), modified.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_Char_LineBreakSeparator() {
                                                                                                        CSVFormat original = CSVFormat.TDF;
                                                                                                        char lineBreak = '\n';
                                                                                                        CSVFormat modified = original.withRecordSeparator(lineBreak);
                                                                                                        
                                                                                                        // Line breaks are allowed as record separators (only delimiters can't be line breaks)
                                                                                                        assertEquals(String.valueOf(lineBreak), modified.getRecordSeparator());
                                                                                                    }

 @Test
                                                                                                    public void testWithRecordSeparator_ConsistencyBetweenCharAndStringVersions() {
                                                                                                        CSVFormat original = CSVFormat.MYSQL;
                                                                                                        char separatorChar = '|';
                                                                                                        String separatorString = "|";
                                                                                                        
                                                                                                        CSVFormat fromChar = original.withRecordSeparator(separatorChar);
                                                                                                        CSVFormat fromString = original.withRecordSeparator(separatorString);
                                                                                                        
                                                                                                        assertEquals(fromChar.getRecordSeparator(), fromString.getRecordSeparator());
                                                                                                        // All other properties should be equal
                                                                                                        assertEquals(fromChar.getDelimiter(), fromString.getDelimiter());
                                                                                                        assertEquals(fromChar.getQuoteCharacter(), fromString.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithSkipHeaderRecord_True() {
                                                                                                        // Setup initial CSVFormat with skipHeaderRecord = false
                                                                                                        CSVFormat originalFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(false);
                                                                                                        
                                                                                                        // Call method under test
                                                                                                        CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                        
                                                                                                        // Verify skipHeaderRecord was changed
                                                                                                        assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                        
                                                                                                        // Verify all other properties remain the same
                                                                                                        assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                        assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                        assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                        assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                        assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                        assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                        assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                        assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                        assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                        assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                        assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testWithSkipHeaderRecord_False() {
                                                                                                        // Setup initial CSVFormat with skipHeaderRecord = true
                                                                                                        CSVFormat originalFormat = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                                        
                                                                                                        // Call method under test
                                                                                                        CSVFormat newFormat = originalFormat.withSkipHeaderRecord(false);
                                                                                                        
                                                                                                        // Verify skipHeaderRecord was changed
                                                                                                        assertFalse(newFormat.getSkipHeaderRecord());
                                                                                                        
                                                                                                        // Verify all other properties remain the same
                                                                                                        assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                        assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                        assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                        assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                        assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                        assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                        assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                        assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                        assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                                        assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                                        assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                                    }

 @Test
                                                                                                    public void testWithSkipHeaderRecord_WithHeaders() {
                                                                                                        // Setup initial CSVFormat with headers
                                                                                                        String[] headers = {"Name", "Age", "City"};
                                                                                                        CSVFormat originalFormat = CSVFormat.DEFAULT.withHeader(headers).withSkipHeaderRecord(false);
                                                                                                        
                                                                                                        // Call method under test
                                                                                                        CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                        
                                                                                                        // Verify changes
                                                                                                        assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                        assertArrayEquals(headers, newFormat.getHeader());
                                                                                                        
                                                                                                        // Verify other properties unchanged
                                                                                                        assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                                        assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithSkipHeaderRecord_FromDifferentBaseFormat() {
                                                                                                        // Use a different base format (TDF - tab delimited)
                                                                                                        CSVFormat originalFormat = CSVFormat.TDF.withSkipHeaderRecord(false);
                                                                                                        
                                                                                                        // Call method under test
                                                                                                        CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                        
                                                                                                        // Verify changes
                                                                                                        assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                        
                                                                                                        // Verify it's still TDF format
                                                                                                        assertEquals('\t', newFormat.getDelimiter());
                                                                                                        assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                    }

 @Test
                                                                                                    public void testWithSkipHeaderRecord_NoHeader() {
                                                                                                        // Format with no headers
                                                                                                        CSVFormat originalFormat = CSVFormat.DEFAULT.withHeader((String[]) null).withSkipHeaderRecord(false);
                                                                                                        
                                                                                                        // Call method under test
                                                                                                        CSVFormat newFormat = originalFormat.withSkipHeaderRecord(true);
                                                                                                        
                                                                                                        // Verify changes
                                                                                                        assertTrue(newFormat.getSkipHeaderRecord());
                                                                                                        assertNull(newFormat.getHeader());
                                                                                                    }

 @Test
                                                                                            public void testIsLineBreak_WithLF_ReturnsTrue() throws Exception {
                                                                                                // Arrange
                                                                                                char input = '\n'; // LF character
                                                                                                
                                                                                                // Get the private method via reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertTrue(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithCR_ReturnsTrue() throws Exception {
                                                                                                // Arrange
                                                                                                char input = '\r'; // CR character
                                                                                                
                                                                                                // Get the private method via reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertTrue(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithNonLineBreakChar_ReturnsFalse() throws Exception {
                                                                                                // Arrange
                                                                                                char input = 'a'; // Regular character
                                                                                                
                                                                                                // Get the private method via reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithSpace_ReturnsFalse() throws Exception {
                                                                                                // Arrange
                                                                                                char input = ' '; // Space character
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithTab_ReturnsFalse() throws Exception {
                                                                                                // Arrange
                                                                                                char input = '\t'; // Tab character
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithNullCharacter_ReturnsFalse() throws Exception {
                                                                                                // Arrange
                                                                                                char input = '\0'; // Null character
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithUnicodeLineSeparator_ReturnsFalse() throws Exception {
                                                                                                // Arrange
                                                                                                char input = '\u2028'; // Unicode line separator
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", char.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithCharacterObjectLF_ReturnsTrue() throws Exception {
                                                                                                // Arrange
                                                                                                Character input = '\n'; // LF as Character object
                                                                                                
                                                                                                // Get the private method via reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertTrue(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithCharacterObjectCR_ReturnsTrue() throws Exception {
                                                                                                // Arrange
                                                                                                Character input = '\r'; // CR as Character object
                                                                                                
                                                                                                // Get the private method via reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) isLineBreakMethod.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertTrue(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_WithNullCharacterObject_ReturnsFalse() throws Exception {
                                                                                                // Arrange
                                                                                                Character input = null; // Null Character object
                                                                                                
                                                                                                // Get the private method using reflection
                                                                                                Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                method.setAccessible(true);
                                                                                                
                                                                                                // Act
                                                                                                boolean result = (boolean) method.invoke(null, input);
                                                                                                
                                                                                                // Assert
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testConstructor_WithLineBreakDelimiter_ThrowsException() {
                                                                                                // Arrange
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                
                                                                                                // Act
                                                                                                CSVFormat.newFormat('\n');
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_Character_NullInput() throws Exception {
                                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                                Method method = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                method.setAccessible(true);
                                                                                                boolean result = (boolean) method.invoke(format, (Character) null);
                                                                                                assertFalse(result);
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_Character_NonLineBreakChars() throws Exception {
                                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, 'a'));
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, ' '));
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '\t'));
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '0'));
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '@'));
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_Character_LineBreakChars() throws Exception {
                                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                                
                                                                                                // Get the private isLineBreak method using reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Test common line break characters
                                                                                                assertTrue((Boolean) isLineBreakMethod.invoke(format, '\n'));
                                                                                                assertTrue((Boolean) isLineBreakMethod.invoke(format, '\r'));
                                                                                                
                                                                                                // Test less common line break characters
                                                                                                assertTrue((Boolean) isLineBreakMethod.invoke(format, '\u0085'));  // Next line
                                                                                                assertTrue((Boolean) isLineBreakMethod.invoke(format, '\u2028'));  // Line separator
                                                                                                assertTrue((Boolean) isLineBreakMethod.invoke(format, '\u2029'));  // Paragraph separator
                                                                                            }

 @Test
                                                                                            public void testIsLineBreak_Character_BoundaryCases() throws Exception {
                                                                                                CSVFormat format = CSVFormat.DEFAULT;
                                                                                                // Get the private isLineBreak method using reflection
                                                                                                Method isLineBreakMethod = CSVFormat.class.getDeclaredMethod("isLineBreak", Character.class);
                                                                                                isLineBreakMethod.setAccessible(true);
                                                                                                
                                                                                                // Test control characters around line break ranges
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u0000'));  // Null character
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u0007'));  // Bell
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u001F'));  // Unit separator
                                                                                                assertFalse((Boolean) isLineBreakMethod.invoke(format, '\u007F'));  // Delete
                                                                                            }

 @Test
                                                                                            public void testGetCommentMarker_WhenCommentMarkerIsSet() {
                                                                                                // Arrange
                                                                                                Character expectedCommentMarker = '#';
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                        .withCommentMarker(expectedCommentMarker)
                                                                                                        .withEscape('\\')
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\r\n")
                                                                                                        .withNullString(null)
                                                                                                        .withHeader((String[]) null)
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                Character actualCommentMarker = format.getCommentMarker();
                                                                                                
                                                                                                // Assert
                                                                                                assertEquals(expectedCommentMarker, actualCommentMarker);
                                                                                            }

 @Test
                                                                                            public void testGetCommentMarker_WhenCommentMarkerIsNull() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                Character actualCommentMarker = format.getCommentMarker();
                                                                                                
                                                                                                // Assert
                                                                                                assertNull(actualCommentMarker);
                                                                                            }

 @Test
                                                                                            public void testGetDelimiter_ConstructorWithCustomDelimiter() {
                                                                                                // Test with custom constructor
                                                                                                CSVFormat format = CSVFormat.newFormat(':');
                                                                                                assertEquals(':', format.getDelimiter());
                                                                                            }

 @Test
                                                                                            public void testGetDelimiter_ConstructorWithLineBreakShouldThrowException() {
                                                                                                // Test that constructor throws exception for line break delimiter
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                thrown.expectMessage("The delimiter cannot be a line break");
                                                                                                
                                                                                                // Use the public factory method which should perform the same validation
                                                                                                CSVFormat.newFormat('\n');
                                                                                            }

 @Test
                                                                                            public void testGetEscapeCharacter_WhenEscapeCharacterIsSet() {
                                                                                                // Arrange
                                                                                                Character expectedEscape = '\\';
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                        .withCommentMarker('#')
                                                                                                        .withEscape(expectedEscape)
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\r\n")
                                                                                                        .withNullString(null)
                                                                                                        .withHeader("Header1")
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                Character actualEscape = format.getEscapeCharacter();
                                                                                                
                                                                                                // Assert
                                                                                                assertEquals(expectedEscape, actualEscape);
                                                                                            }

 @Test
                                                                                            public void testGetEscapeCharacter_WhenEscapeCharacterIsNull() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader("Header1")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                Character actualEscape = format.getEscapeCharacter();
                                                                                                
                                                                                                // Assert
                                                                                                assertNull(actualEscape);
                                                                                            }

 @Test
                                                                                            public void testGetEscapeCharacter_AfterSettingToNullWithWithEscape() {
                                                                                                // Arrange - Start with a format that has an escape character
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader("Header1")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act - Set escape to null
                                                                                                format = format.withEscape(null);
                                                                                                
                                                                                                // Assert
                                                                                                assertNull(format.getEscapeCharacter());
                                                                                            }

 @Test
                                                                                            public void testGetHeader_WhenHeaderIsNull() {
                                                                                                // Arrange
                                                                                                CSVFormat csvFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote(null)
                                                                                                    .withQuoteMode(null)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                String[] result = csvFormat.getHeader();
                                                                                                
                                                                                                // Assert
                                                                                                assertNull(result);
                                                                                            }

 @Test
                                                                                            public void testGetHeader_WhenHeaderIsNotNull() {
                                                                                                // Arrange
                                                                                                String[] originalHeader = {"Name", "Age", "City"};
                                                                                                CSVFormat csvFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote(null)
                                                                                                    .withQuoteMode(null)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader(originalHeader)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                String[] result = csvFormat.getHeader();
                                                                                                
                                                                                                // Assert
                                                                                                assertNotNull(result);
                                                                                                assertArrayEquals(originalHeader, result);
                                                                                                assertNotSame(originalHeader, result); // Verify it's a clone
                                                                                            }

 @Test
                                                                                            public void testGetHeader_VerifyCloneBehavior() {
                                                                                                // Arrange
                                                                                                String[] originalHeader = {"Name", "Age", "City"};
                                                                                                CSVFormat csvFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote(null)
                                                                                                    .withQuoteMode(null)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader(originalHeader)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                String[] result = csvFormat.getHeader();
                                                                                                result[1] = "Modified"; // Modify the returned array
                                                                                                
                                                                                                // Assert
                                                                                                assertNotEquals(originalHeader[1], result[1]); // Verify modification doesn't affect original
                                                                                                assertEquals("Age", originalHeader[1]); // Original should remain unchanged
                                                                                            }

 @Test
                                                                                            public void testGetHeader_WithEmptyHeaderArray() {
                                                                                                // Arrange
                                                                                                String[] originalHeader = {};
                                                                                                CSVFormat csvFormat = CSVFormat.newFormat(',')
                                                                                                        .withQuote(null)
                                                                                                        .withQuoteMode(null)
                                                                                                        .withCommentMarker(null)
                                                                                                        .withEscape(null)
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withNullString(null)
                                                                                                        .withHeader(originalHeader)
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act
                                                                                                String[] result = csvFormat.getHeader();
                                                                                                
                                                                                                // Assert
                                                                                                assertNotNull(result);
                                                                                                assertEquals(0, result.length);
                                                                                                assertNotSame(originalHeader, result); // Verify it's a clone
                                                                                            }

 @Test
                                                                                            public void testGetAllowMissingColumnNames_WhenTrue() {
                                                                                                // Create a CSVFormat instance with allowMissingColumnNames set to true
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("Header1", "Header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                                
                                                                                                assertTrue(format.getAllowMissingColumnNames());
                                                                                            }

 @Test
                                                                                            public void testGetAllowMissingColumnNames_WhenFalse() {
                                                                                                // Create a CSVFormat instance with allowMissingColumnNames set to false using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("Header1", "Header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse(format.getAllowMissingColumnNames());
                                                                                            }

 @Test
                                                                                            public void testGetIgnoreEmptyLines_WhenTrue() {
                                                                                                // Create a CSVFormat with ignoreEmptyLines set to true using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(true)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader("Header1", "Header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertTrue("Should return true when ignoreEmptyLines is true", 
                                                                                                          format.getIgnoreEmptyLines());
                                                                                            }

 @Test
                                                                                            public void testGetIgnoreEmptyLines_WhenFalse() {
                                                                                                // Create a CSVFormat with ignoreEmptyLines set to false using builder pattern
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader("Header1", "Header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse("Should return false when ignoreEmptyLines is false", 
                                                                                                           format.getIgnoreEmptyLines());
                                                                                            }

 @Test
                                                                                            public void testGetIgnoreSurroundingSpaces_WhenTrue() {
                                                                                                // Create a CSVFormat instance with ignoreSurroundingSpaces set to true using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader("Header1", "Header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertTrue(format.getIgnoreSurroundingSpaces());
                                                                                            }

 @Test
                                                                                            public void testGetIgnoreSurroundingSpaces_WhenFalse() {
                                                                                                // Create a CSVFormat instance with ignoreSurroundingSpaces set to false using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader("Header1", "Header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse(format.getIgnoreSurroundingSpaces());
                                                                                            }

 @Test
                                                                                            public void testGetNullString_WhenNullStringIsNull() {
                                                                                                // Create a CSVFormat instance with nullString set to null
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertNull(format.getNullString());
                                                                                            }

 @Test
                                                                                            public void testGetNullString_WhenNullStringIsEmpty() {
                                                                                                // Create a CSVFormat instance with empty nullString
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("")
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertEquals("", format.getNullString());
                                                                                            }

 @Test
                                                                                            public void testGetNullString_WhenNullStringIsSet() {
                                                                                                // Create a CSVFormat instance with specific nullString
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertEquals("NULL", format.getNullString());
                                                                                            }

 @Test
                                                                                            public void testGetNullString_AfterModificationWithWithNullString() {
                                                                                                // Create a base CSVFormat instance using the builder pattern
                                                                                                CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Create a modified format with new nullString
                                                                                                CSVFormat modifiedFormat = baseFormat.withNullString("NA");
                                                                                                
                                                                                                assertEquals("NA", modifiedFormat.getNullString());
                                                                                                assertNull(baseFormat.getNullString()); // Original should remain unchanged
                                                                                            }

 @Test
                                                                                            public void testGetQuoteCharacter_WhenSet() {
                                                                                                // Test with a specific quote character
                                                                                                Character expectedQuote = '"';
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote(expectedQuote)
                                                                                                        .withQuoteMode(null)
                                                                                                        .withCommentMarker(null)
                                                                                                        .withEscape(null)
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withNullString(null)
                                                                                                        .withHeader((String[]) null)
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertEquals(expectedQuote, format.getQuoteCharacter());
                                                                                            }

 @Test
                                                                                            public void testGetQuoteCharacter_WhenNull() {
                                                                                                // Test with null quote character
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote((Character) null);
                                                                                                
                                                                                                assertNull(format.getQuoteCharacter());
                                                                                            }

 @Test
                                                                                            public void testGetQuoteCharacter_WithDifferentCharacters() {
                                                                                                // Test with single quote
                                                                                                Character singleQuote = '\'';
                                                                                                CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                        .withQuote(singleQuote)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                        .withSkipHeaderRecord(false);
                                                                                                assertEquals(singleQuote, format1.getQuoteCharacter());
                                                                                            
                                                                                                // Test with pipe character
                                                                                                Character pipe = '|';
                                                                                                CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                        .withQuote(pipe)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                        .withSkipHeaderRecord(false);
                                                                                                assertEquals(pipe, format2.getQuoteCharacter());
                                                                                            }

 @Test
                                                                                            public void testGetQuoteMode_WhenAll() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.ALL)
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                        .withSkipHeaderRecord(false);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertEquals(QuoteMode.ALL, format.getQuoteMode());
                                                                                            }

 @Test
                                                                                            public void testGetQuoteMode_WhenNonNumeric() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                        .withSkipHeaderRecord(false);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertEquals(QuoteMode.NON_NUMERIC, format.getQuoteMode());
                                                                                            }

 @Test
                                                                                            public void testGetQuoteMode_WhenNone() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',').withQuoteMode(QuoteMode.NONE);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertEquals(QuoteMode.NONE, format.getQuoteMode());
                                                                                            }

 @Test
                                                                                            public void testGetQuoteMode_WhenMinimal() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator("\n")
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
                                                                                            }

 @Test
                                                                                            public void testGetRecordSeparator_CustomSeparator() {
                                                                                                // Test with custom record separator
                                                                                                String customSeparator = "|||";
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator(customSeparator)
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                assertEquals(customSeparator, format.getRecordSeparator());
                                                                                            }

 @Test
                                                                                            public void testGetRecordSeparator_EmptySeparator() {
                                                                                                // Test with empty string as separator
                                                                                                String emptySeparator = "";
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator(emptySeparator)
                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                        .withSkipHeaderRecord(false);
                                                                                                assertEquals(emptySeparator, format.getRecordSeparator());
                                                                                            }

 @Test
                                                                                            public void testGetRecordSeparator_NullSeparator() {
                                                                                                // Test with null separator
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote(null)
                                                                                                    .withQuoteMode(null)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator(null)
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                assertNull(format.getRecordSeparator());
                                                                                            }

 @Test
                                                                                            public void testGetRecordSeparator_AfterWithRecordSeparator() {
                                                                                                // Test after using withRecordSeparator to modify the separator
                                                                                                String originalSeparator = "\n";
                                                                                                String newSeparator = "NEW_SEP";
                                                                                                
                                                                                                // Create basic format with newFormat() and then set the record separator
                                                                                                CSVFormat original = CSVFormat.newFormat(',')
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withRecordSeparator(originalSeparator)
                                                                                                        .withAllowMissingColumnNames(false)
                                                                                                        .withSkipHeaderRecord(false);
                                                                                                
                                                                                                CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                                
                                                                                                assertEquals(newSeparator, modified.getRecordSeparator());
                                                                                                // Original should remain unchanged
                                                                                                assertEquals(originalSeparator, original.getRecordSeparator());
                                                                                            }

 @Test
                                                                                            public void testGetSkipHeaderRecord_WhenTrue() {
                                                                                                // Arrange
                                                                                                char delimiter = ',';
                                                                                                Character quoteChar = '"';
                                                                                                QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                                Character commentStart = null;
                                                                                                Character escape = null;
                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                boolean ignoreEmptyLines = false;
                                                                                                String recordSeparator = "\r\n";
                                                                                                String nullString = null;
                                                                                                String[] header = new String[]{"col1", "col2"};
                                                                                                boolean skipHeaderRecord = true;
                                                                                                boolean allowMissingColumnNames = false;
                                                                                                
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                        .withQuote(quoteChar)
                                                                                                        .withQuoteMode(quoteMode)
                                                                                                        .withCommentMarker(commentStart)
                                                                                                        .withEscape(escape)
                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                        .withNullString(nullString)
                                                                                                        .withHeader(header)
                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertTrue(format.getSkipHeaderRecord());
                                                                                            }

 @Test
                                                                                            public void testGetSkipHeaderRecord_WhenFalse() {
                                                                                                // Arrange
                                                                                                char delimiter = ',';
                                                                                                Character quoteChar = '"';
                                                                                                QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                                Character commentStart = null;
                                                                                                Character escape = null;
                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                boolean ignoreEmptyLines = false;
                                                                                                String recordSeparator = "\r\n";
                                                                                                String nullString = null;
                                                                                                String[] header = new String[]{"col1", "col2"};
                                                                                                boolean skipHeaderRecord = false;
                                                                                                boolean allowMissingColumnNames = false;
                                                                                                
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                        .withQuote(quoteChar)
                                                                                                        .withQuoteMode(quoteMode)
                                                                                                        .withCommentMarker(commentStart)
                                                                                                        .withEscape(escape)
                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                        .withNullString(nullString)
                                                                                                        .withHeader(header)
                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertFalse(format.getSkipHeaderRecord());
                                                                                            }

 @Test
                                                                                            public void testGetSkipHeaderRecord_WithHeaderButSkipFalse() {
                                                                                                // Arrange
                                                                                                char delimiter = ',';
                                                                                                Character quoteChar = '"';
                                                                                                QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                                Character commentStart = null;
                                                                                                Character escape = null;
                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                boolean ignoreEmptyLines = false;
                                                                                                String recordSeparator = "\r\n";
                                                                                                String nullString = null;
                                                                                                String[] header = new String[]{"col1", "col2"};
                                                                                                boolean skipHeaderRecord = false;
                                                                                                boolean allowMissingColumnNames = false;
                                                                                                
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                        .withQuote(quoteChar)
                                                                                                        .withQuoteMode(quoteMode)
                                                                                                        .withCommentMarker(commentStart)
                                                                                                        .withEscape(escape)
                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                        .withNullString(nullString)
                                                                                                        .withHeader(header)
                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertFalse(format.getSkipHeaderRecord());
                                                                                            }

 @Test
                                                                                            public void testGetSkipHeaderRecord_NoHeaderButSkipTrue() {
                                                                                                // Arrange
                                                                                                char delimiter = ',';
                                                                                                Character quoteChar = '"';
                                                                                                QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                                Character commentStart = null;
                                                                                                Character escape = null;
                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                boolean ignoreEmptyLines = false;
                                                                                                String recordSeparator = "\r\n";
                                                                                                String nullString = null;
                                                                                                String[] header = null;
                                                                                                boolean skipHeaderRecord = true;
                                                                                                boolean allowMissingColumnNames = false;
                                                                                                
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                        .withQuote(quoteChar)
                                                                                                        .withQuoteMode(quoteMode)
                                                                                                        .withCommentMarker(commentStart)
                                                                                                        .withEscape(escape)
                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                        .withNullString(nullString)
                                                                                                        .withHeader(header)
                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertTrue(format.getSkipHeaderRecord());
                                                                                            }

 @Test
                                                                                            public void testHashCode_AllFieldsSet() {
                                                                                                // Setup
                                                                                                char delimiter = ',';
                                                                                                Character quoteCharacter = '"';
                                                                                                QuoteMode quoteMode = QuoteMode.ALL;
                                                                                                Character commentMarker = '#';
                                                                                                Character escapeCharacter = '\\';
                                                                                                boolean ignoreSurroundingSpaces = true;
                                                                                                boolean ignoreEmptyLines = true;
                                                                                                boolean skipHeaderRecord = true;
                                                                                                String recordSeparator = "\n";
                                                                                                String nullString = "NULL";
                                                                                                String[] header = {"col1", "col2"};
                                                                                                boolean allowMissingColumnNames = false;
                                                                                                
                                                                                                // Create instance with all fields set using builder pattern
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                        .withQuote(quoteCharacter)
                                                                                                        .withQuoteMode(quoteMode)
                                                                                                        .withCommentMarker(commentMarker)
                                                                                                        .withEscape(escapeCharacter)
                                                                                                        .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                        .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                        .withRecordSeparator(recordSeparator)
                                                                                                        .withNullString(nullString)
                                                                                                        .withHeader(header)
                                                                                                        .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                        .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                                
                                                                                                // Calculate expected hash code manually
                                                                                                int expected = 31;
                                                                                                expected = 31 * expected + delimiter;
                                                                                                expected = 31 * expected + quoteMode.hashCode();
                                                                                                expected = 31 * expected + quoteCharacter.hashCode();
                                                                                                expected = 31 * expected + commentMarker.hashCode();
                                                                                                expected = 31 * expected + escapeCharacter.hashCode();
                                                                                                expected = 31 * expected + nullString.hashCode();
                                                                                                expected = 31 * expected + (ignoreSurroundingSpaces ? 1231 : 1237);
                                                                                                expected = 31 * expected + (ignoreEmptyLines ? 1231 : 1237);
                                                                                                expected = 31 * expected + (skipHeaderRecord ? 1231 : 1237);
                                                                                                expected = 31 * expected + recordSeparator.hashCode();
                                                                                                expected = 31 * expected + Arrays.hashCode(header);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(expected, format.hashCode());
                                                                                            }

 @Test
                                                                                            public void testHashCode_WithNullFields() {
                                                                                                // Setup with null fields
                                                                                                char delimiter = '\t';
                                                                                                Character quoteCharacter = null;
                                                                                                QuoteMode quoteMode = null;
                                                                                                Character commentMarker = null;
                                                                                                Character escapeCharacter = null;
                                                                                                boolean ignoreSurroundingSpaces = false;
                                                                                                boolean ignoreEmptyLines = false;
                                                                                                boolean skipHeaderRecord = false;
                                                                                                String recordSeparator = null;
                                                                                                String nullString = null;
                                                                                                String[] header = null;
                                                                                                
                                                                                                // Create instance using builder pattern
                                                                                                CSVFormat format = CSVFormat.newFormat(delimiter)
                                                                                                    .withQuote(quoteCharacter)
                                                                                                    .withQuoteMode(quoteMode)
                                                                                                    .withCommentMarker(commentMarker)
                                                                                                    .withEscape(escapeCharacter)
                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                    .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                    .withNullString(nullString)
                                                                                                    .withHeader(header);
                                                                                                
                                                                                                // Calculate expected hash code manually
                                                                                                int expected = 31;
                                                                                                expected = 31 * expected + delimiter;
                                                                                                expected = 31 * expected + 0; // quoteMode null
                                                                                                expected = 31 * expected + 0; // quoteCharacter null
                                                                                                expected = 31 * expected + 0; // commentMarker null
                                                                                                expected = 31 * expected + 0; // escapeCharacter null
                                                                                                expected = 31 * expected + 0; // nullString null
                                                                                                expected = 31 * expected + (ignoreSurroundingSpaces ? 1231 : 1237);
                                                                                                expected = 31 * expected + (ignoreEmptyLines ? 1231 : 1237);
                                                                                                expected = 31 * expected + (skipHeaderRecord ? 1231 : 1237);
                                                                                                expected = 31 * expected + 0; // recordSeparator null
                                                                                                expected = 31 * expected + Arrays.hashCode(header); // header null
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(expected, format.hashCode());
                                                                                            }

 @Test
                                                                                            public void testHashCode_EqualsObjectsHaveSameHashCode() {
                                                                                                // Create two identical formats using builder pattern
                                                                                                CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("a", "b")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                                
                                                                                                CSVFormat format2 = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("a", "b")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                                
                                                                                                // Verify equals() returns true
                                                                                                assertTrue(format1.equals(format2));
                                                                                                
                                                                                                // Verify hash codes are equal
                                                                                                assertEquals(format1.hashCode(), format2.hashCode());
                                                                                            }

 @Test
                                                                                            public void testHashCode_DifferentDelimiter() {
                                                                                                // Create formats with different delimiters using public factory method
                                                                                                CSVFormat format1 = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withAllowMissingColumnNames(false)
                                                                                                    .withSkipHeaderRecord(false);
                                                                                                
                                                                                                CSVFormat format2 = CSVFormat.newFormat(';')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withAllowMissingColumnNames(false)
                                                                                                    .withSkipHeaderRecord(false);
                                                                                                
                                                                                                // Verify hash codes are different
                                                                                                assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                            }

 @Test
                                                                                            public void testHashCode_DifferentBooleanFlags() {
                                                                                                // Create formats with different boolean flags using builder pattern
                                                                                                CSVFormat format1 = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                                    .withIgnoreEmptyLines(true)
                                                                                                    .withSkipHeaderRecord(true)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                CSVFormat format2 = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Verify hash codes are different
                                                                                                assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                            }

 @Test
                                                                                            public void testHashCode_DifferentHeaders() {
                                                                                                // Create formats with different headers using builder pattern
                                                                                                CSVFormat format1 = CSVFormat.DEFAULT.withDelimiter(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                        .withHeader("a")
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                        
                                                                                                CSVFormat format2 = CSVFormat.DEFAULT.withDelimiter(',')
                                                                                                        .withQuote('"')
                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                        .withHeader("b")
                                                                                                        .withIgnoreSurroundingSpaces(false)
                                                                                                        .withIgnoreEmptyLines(false)
                                                                                                        .withSkipHeaderRecord(false)
                                                                                                        .withAllowMissingColumnNames(false);
                                                                                                        
                                                                                                // Verify hash codes are different
                                                                                                assertNotEquals(format1.hashCode(), format2.hashCode());
                                                                                            }

 @Test
                                                                                            public void testIsCommentMarkerSet_WhenCommentMarkerIsNull() {
                                                                                                // Create CSVFormat with null comment marker using builder pattern
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)  // explicitly set comment marker to null
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse("Should return false when commentMarker is null", 
                                                                                                           format.isCommentMarkerSet());
                                                                                            }

 @Test
                                                                                            public void testIsCommentMarkerSet_WhenCommentMarkerIsSet() {
                                                                                                // Create CSVFormat with a comment marker using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertTrue("Should return true when commentMarker is set", 
                                                                                                          format.isCommentMarkerSet());
                                                                                            }

 @Test
                                                                                            public void testIsCommentMarkerSet_AfterChangingCommentMarker() {
                                                                                                // Create initial format with null comment marker using public factory method
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse("Initial state should have no comment marker", 
                                                                                                           format.isCommentMarkerSet());
                                                                                                
                                                                                                // Change comment marker
                                                                                                CSVFormat newFormat = format.withCommentMarker('#');
                                                                                                assertTrue("After setting comment marker, should return true", 
                                                                                                          newFormat.isCommentMarkerSet());
                                                                                                
                                                                                                // Remove comment marker
                                                                                                CSVFormat noCommentFormat = newFormat.withCommentMarker(null);
                                                                                                assertFalse("After removing comment marker, should return false", 
                                                                                                           noCommentFormat.isCommentMarkerSet());
                                                                                            }

 @Test
                                                                                            public void testIsEscapeCharacterSet_WhenEscapeCharacterIsSet() {
                                                                                                // Create format with escape character set
                                                                                                Character escapeChar = '\\';
                                                                                                CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                                        .withQuote('"')                     // quoteChar
                                                                                                        .withQuoteMode(QuoteMode.MINIMAL)   // quoteMode
                                                                                                        .withCommentMarker('#')             // commentStart
                                                                                                        .withEscape(escapeChar)            // escape
                                                                                                        .withIgnoreSurroundingSpaces(false) // ignoreSurroundingSpaces
                                                                                                        .withIgnoreEmptyLines(false)       // ignoreEmptyLines
                                                                                                        .withRecordSeparator("\r\n")       // recordSeparator
                                                                                                        .withNullString(null)              // nullString
                                                                                                        .withHeader((String[]) null)       // header
                                                                                                        .withSkipHeaderRecord(false)       // skipHeaderRecord
                                                                                                        .withAllowMissingColumnNames(false); // allowMissingColumnNames
                                                                                                
                                                                                                assertTrue("Should return true when escape character is set", 
                                                                                                           format.isEscapeCharacterSet());
                                                                                            }

 @Test
                                                                                            public void testIsEscapeCharacterSet_WhenEscapeCharacterIsNull() {
                                                                                                // Create format without escape character using builder pattern
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse("Should return false when escape character is null", 
                                                                                                            format.isEscapeCharacterSet());
                                                                                            }

 @Test
                                                                                            public void testIsNullStringSet_WhenNullStringIsNull() {
                                                                                                // Create CSVFormat with nullString = null using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse(format.isNullStringSet());
                                                                                            }

 @Test
                                                                                            public void testIsNullStringSet_WhenNullStringIsEmpty() {
                                                                                                // Create CSVFormat with empty nullString using builder pattern
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("")
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertTrue(format.isNullStringSet());
                                                                                            }

 @Test
                                                                                            public void testIsNullStringSet_WhenNullStringIsNonEmpty() {
                                                                                                // Create CSVFormat with non-empty nullString using builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertTrue(format.isNullStringSet());
                                                                                            }

 @Test
                                                                                            public void testIsNullStringSet_AfterModifyingNullString() {
                                                                                                // Create CSVFormat with nullString = null using the builder pattern
                                                                                                CSVFormat format = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                assertFalse(format.isNullStringSet());
                                                                                                
                                                                                                // Create a new format with non-null nullString
                                                                                                CSVFormat modifiedFormat = format.withNullString("NULL");
                                                                                                assertTrue(modifiedFormat.isNullStringSet());
                                                                                            }

 @Test
                                                                                            public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNull() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')
                                                                                                    .withQuote(null)        // quoteChar (null)
                                                                                                    .withQuoteMode(null)    // quoteMode
                                                                                                    .withCommentMarker(null) // commentStart
                                                                                                    .withEscape(null)       // escape
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertFalse(format.isQuoteCharacterSet());
                                                                                            }

 @Test
                                                                                            public void testIsQuoteCharacterSet_WhenQuoteCharacterIsNotNull() {
                                                                                                // Arrange
                                                                                                CSVFormat format = CSVFormat.newFormat(',')  // delimiter
                                                                                                        .withQuote('"')                     // quoteChar (not null)
                                                                                                        .withQuoteMode(null)                // quoteMode
                                                                                                        .withCommentMarker(null)             // commentStart
                                                                                                        .withEscape(null)                    // escape
                                                                                                        .withIgnoreSurroundingSpaces(false)  // ignoreSurroundingSpaces
                                                                                                        .withIgnoreEmptyLines(false)        // ignoreEmptyLines
                                                                                                        .withRecordSeparator("\r\n")        // recordSeparator
                                                                                                        .withNullString(null)               // nullString
                                                                                                        .withHeader((String[]) null)         // header
                                                                                                        .withSkipHeaderRecord(false)         // skipHeaderRecord
                                                                                                        .withAllowMissingColumnNames(false); // allowMissingColumnNames
                                                                                                
                                                                                                // Act & Assert
                                                                                                assertTrue(format.isQuoteCharacterSet());
                                                                                            }

 @Test
                                                                                        public void testParse_WithSkipHeaderRecord() throws Exception {
                                                                                            // Arrange
                                                                                            org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withSkipHeaderRecord(true);
                                                                                            java.io.Reader in = new java.io.StringReader("Name,Age,City\nJohn,25,New York");
                                                                                            
                                                                                            // Act
                                                                                            org.apache.commons.csv.CSVParser parser = format.parse(in);
                                                                                            
                                                                                            // Assert
                                                                                            org.junit.Assert.assertNotNull(parser);
                                                                                            org.junit.Assert.assertEquals(1, parser.getRecords().size()); // Should skip header
                                                                                        }

 @Test
                                                                                        public void testPrint_WithHeader() throws IOException {
                                                                                            // Arrange
                                                                                            StringWriter writer = new StringWriter();
                                                                                            String[] headers = {"Name", "Age", "City"};
                                                                                            CSVFormat format = CSVFormat.DEFAULT.withHeader(headers);
                                                                                            
                                                                                            // Act
                                                                                            CSVPrinter printer = format.print(writer);
                                                                                            
                                                                                            // Assert
                                                                                            assertNotNull(printer);
                                                                                            assertArrayEquals(headers, format.getHeader());
                                                                                        }

 @Test
                                                                                        public void testValidate_QuoteCharSameAsDelimiter() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The quoteChar character and the delimiter cannot be the same (\'a\')");
                                                                                            
                                                                                            CSVFormat.newFormat('a').withQuote('a');
                                                                                        }

 @Test
                                                                                        public void testValidate_EscapeCharSameAsDelimiter() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The escape character and the delimiter cannot be the same ('b')");
                                                                                            
                                                                                            CSVFormat format = CSVFormat.newFormat('b')
                                                                                                    .withEscape('b')
                                                                                                    .withQuoteMode(QuoteMode.ALL)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                        }

 @Test
                                                                                        public void testValidate_CommentMarkerSameAsDelimiter() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start character and the delimiter cannot be the same ('c')");
                                                                                            
                                                                                            CSVFormat format = CSVFormat.newFormat('c')
                                                                                                    .withQuoteMode(QuoteMode.ALL)
                                                                                                    .withCommentMarker('c');
                                                                                        }

 @Test
                                                                                        public void testValidate_QuoteCharSameAsCommentMarker() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start character and the quoteChar cannot be the same ('d')");
                                                                                            
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuote('d')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('d');
                                                                                        }

 @Test
                                                                                        public void testValidate_EscapeCharSameAsCommentMarker() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start and the escape character cannot be the same ('e')");
                                                                                            
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withEscape('e')
                                                                                                .withCommentMarker('e');
                                                                                        }

 @Test
                                                                                        public void testValidate_NoEscapeCharWithQuoteModeNone() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("No quotes mode set but no escape character is set");
                                                                                            
                                                                                            CSVFormat.newFormat(',')
                                                                                                .withQuoteMode(QuoteMode.NONE)
                                                                                                .withEscape(null)
                                                                                                .withQuote(null);
                                                                                        }

 @Test
                                                                                        public void testValidate_ValidConfigurationWithQuoteModeNone() {
                                                                                            // Should not throw any exception
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuote(null)
                                                                                                .withQuoteMode(QuoteMode.NONE)
                                                                                                .withCommentMarker(null)
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                        }

 @Test
                                                                                        public void testValidate_ValidConfigurationWithAllParameters() {
                                                                                            // Should not throw any exception
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true);
                                                                                        }

 @Test
                                                                                        public void testValidate_ValidConfigurationWithMinimalParameters() {
                                                                                            // Should not throw any exception
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withAllowMissingColumnNames(false)
                                                                                                .withSkipHeaderRecord(false);
                                                                                        }

 @Test
                                                                                        public void testValidate_NullParameters() {
                                                                                            // Should not throw any exception when optional parameters are null
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuote(null)
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker(null)
                                                                                                .withEscape(null)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                        }

 @Test
                                                                                        public void testValidate_LineBreakDelimiter() {
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The delimiter cannot be a line break");
                                                                                            
                                                                                            CSVFormat.newFormat('\n')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withRecordSeparator("\n");
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_NonNullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker('*');
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(Character.valueOf('*'), newFormat.getCommentMarker());
                                                                                            assertTrue(newFormat.isCommentMarkerSet());
                                                                                            
                                                                                            // Verify other properties remain unchanged
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_NullCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker((Character) null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNull(newFormat.getCommentMarker());
                                                                                            assertFalse(newFormat.isCommentMarkerSet());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_LineBreakCharacter() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment marker cannot be a line break");
                                                                                            
                                                                                            // Test
                                                                                            originalFormat.withCommentMarker('\n');
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_SameAsOriginal() {
                                                                                            // Setup
                                                                                            Character commentMarker = '#';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker(commentMarker)
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_FromNullToNonNull() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker(null)
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker('#');
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertEquals(Character.valueOf('#'), newFormat.getCommentMarker());
                                                                                            assertTrue(newFormat.isCommentMarkerSet());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_FromNonNullToNull() {
                                                                                            // Setup
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker((Character) null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(newFormat);
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertNull(newFormat.getCommentMarker());
                                                                                            assertFalse(newFormat.isCommentMarkerSet());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_ValidCharacters() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            Character quoteChar = '"';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                .withQuote(quoteChar)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withAllowMissingColumnNames(false)
                                                                                                .withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Test various valid comment markers
                                                                                            Character poundSign = '#';
                                                                                            CSVFormat format1 = originalFormat.withCommentMarker(poundSign);
                                                                                            assertEquals(poundSign, format1.getCommentMarker());
                                                                                            
                                                                                            Character semicolon = ';';
                                                                                            CSVFormat format2 = originalFormat.withCommentMarker(semicolon);
                                                                                            assertEquals(semicolon, format2.getCommentMarker());
                                                                                            
                                                                                            Character nullMarker = null;
                                                                                            CSVFormat format3 = originalFormat.withCommentMarker(nullMarker);
                                                                                            assertNull(format3.getCommentMarker());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_LineBreakCharacters() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            Character quoteChar = '"';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                .withQuote(quoteChar);
                                                                                            
                                                                                            // Expect exception for line break characters
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                            
                                                                                            // Test with newline character
                                                                                            originalFormat.withCommentMarker('\n');
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_CarriageReturnCharacter() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            Character quoteChar = '"';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                .withQuote(quoteChar)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withAllowMissingColumnNames(false)
                                                                                                .withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The comment start marker character cannot be a line break");
                                                                                            
                                                                                            // Test with carriage return character
                                                                                            originalFormat.withCommentMarker('\r');
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_PreservesOtherProperties() {
                                                                                            // Setup original format with various properties
                                                                                            char delimiter = '|';
                                                                                            Character quoteChar = '\'';
                                                                                            QuoteMode quoteMode = QuoteMode.ALL;
                                                                                            Character escapeChar = '\\';
                                                                                            boolean ignoreSpaces = true;
                                                                                            boolean ignoreEmptyLines = true;
                                                                                            String recordSeparator = "\r\n";
                                                                                            String nullString = "NULL";
                                                                                            String[] header = {"col1", "col2"};
                                                                                            boolean skipHeader = true;
                                                                                            boolean allowMissing = true;
                                                                                            
                                                                                            // Build CSVFormat using public builder methods
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                .withQuote(quoteChar)
                                                                                                .withQuoteMode(quoteMode)
                                                                                                .withEscape(escapeChar)
                                                                                                .withIgnoreSurroundingSpaces(ignoreSpaces)
                                                                                                .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                .withRecordSeparator(recordSeparator)
                                                                                                .withNullString(nullString)
                                                                                                .withHeader(header)
                                                                                                .withSkipHeaderRecord(skipHeader)
                                                                                                .withAllowMissingColumnNames(allowMissing);
                                                                                            
                                                                                            // Apply withCommentMarker
                                                                                            Character commentMarker = '!';
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                            
                                                                                            // Verify comment marker changed
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(delimiter, newFormat.getDelimiter());
                                                                                            assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                            assertEquals(quoteMode, newFormat.getQuoteMode());
                                                                                            assertEquals(escapeChar, newFormat.getEscapeCharacter());
                                                                                            assertEquals(ignoreSpaces, newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(ignoreEmptyLines, newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertEquals(skipHeader, newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(allowMissing, newFormat.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithCommentMarker_PrimitiveCharParameter() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                .withQuote('"')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withAllowMissingColumnNames(false)
                                                                                                .withSkipHeaderRecord(false);
                                                                                            
                                                                                            // Test with primitive char
                                                                                            char commentMarker = '#';
                                                                                            CSVFormat newFormat = originalFormat.withCommentMarker(commentMarker);
                                                                                            
                                                                                            assertEquals(Character.valueOf(commentMarker), newFormat.getCommentMarker());
                                                                                        }

 @Test
                                                                                        public void testWithDelimiter_ValidNonLineBreak() {
                                                                                            // Setup base format with known values using public factory method
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header1", "header2")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test with various valid delimiters
                                                                                            char[] testDelimiters = {';', '|', '\t', 'a', '1'};
                                                                                            
                                                                                            for (char delimiter : testDelimiters) {
                                                                                                CSVFormat newFormat = baseFormat.withDelimiter(delimiter);
                                                                                                
                                                                                                // Verify delimiter changed
                                                                                                assertEquals(delimiter, newFormat.getDelimiter());
                                                                                                
                                                                                                // Verify other properties remain unchanged
                                                                                                assertEquals(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                                assertEquals(baseFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                                assertEquals(baseFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                                assertEquals(baseFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                                assertEquals(baseFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                                assertEquals(baseFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                                assertEquals(baseFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                                assertEquals(baseFormat.getNullString(), newFormat.getNullString());
                                                                                                assertArrayEquals(baseFormat.getHeader(), newFormat.getHeader());
                                                                                                assertEquals(baseFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                                assertEquals(baseFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                            }
                                                                                        }

 @Test
                                                                                        public void testWithEscape_ValidCharacter1() {
                                                                                            // Setup base format using public factory method
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test with valid escape character
                                                                                            char escape = '|';
                                                                                            CSVFormat newFormat = baseFormat.withEscape(escape);
                                                                                            
                                                                                            assertNotNull(newFormat);
                                                                                            assertEquals(Character.valueOf(escape), newFormat.getEscapeCharacter());
                                                                                            assertEquals(',', newFormat.getDelimiter()); // other properties should remain same
                                                                                            assertEquals('"', newFormat.getQuoteCharacter().charValue());
                                                                                        }

 @Test
                                                                                        public void testWithEscape_NullCharacter1() {
                                                                                            // Setup base format using public factory method
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.ALL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("header")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test with null escape character
                                                                                            CSVFormat newFormat = baseFormat.withEscape((Character)null);
                                                                                            
                                                                                            assertNotNull(newFormat);
                                                                                            assertNull(newFormat.getEscapeCharacter());
                                                                                            assertFalse(newFormat.isEscapeCharacterSet());
                                                                                        }

 @Test
                                                                                        public void testWithEscape_LineBreakCharacter_NewLine() {
                                                                                            // Setup base format using public factory method
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The escape character cannot be a line break");
                                                                                            
                                                                                            // Test with newline character
                                                                                            baseFormat.withEscape('\n');
                                                                                        }

 @Test
                                                                                        public void testWithEscape_LineBreakCharacter_CarriageReturn() {
                                                                                            // Setup base format using public factory method
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The escape character cannot be a line break");
                                                                                            
                                                                                            // Test with carriage return character
                                                                                            baseFormat.withEscape('\r');
                                                                                        }

 @Test
                                                                                        public void testWithEscape_SameCharacterAsExisting() {
                                                                                            // Setup base format with specific escape
                                                                                            char existingEscape = '\\';
                                                                                            CSVFormat baseFormat = CSVFormat.DEFAULT
                                                                                                .withDelimiter(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape(existingEscape)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test with same escape character
                                                                                            CSVFormat newFormat = baseFormat.withEscape(existingEscape);
                                                                                            
                                                                                            assertNotNull(newFormat);
                                                                                            assertEquals(Character.valueOf(existingEscape), newFormat.getEscapeCharacter());
                                                                                            assertSame(baseFormat.getQuoteCharacter(), newFormat.getQuoteCharacter()); // other properties same
                                                                                        }

 @Test
                                                                                        public void testWithEscape_SpecialCharacters() {
                                                                                            // Setup base format using public factory method
                                                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test with various special characters
                                                                                            char[] specialChars = {'!', '@', '#', '$', '%', '^', '&', '*', '(', ')'};
                                                                                            
                                                                                            for (char c : specialChars) {
                                                                                                CSVFormat newFormat = baseFormat.withEscape(c);
                                                                                                assertEquals(Character.valueOf(c), newFormat.getEscapeCharacter());
                                                                                            }
                                                                                        }

 @Test
                                                                                        public void testWithAllowMissingColumnNames_True() {
                                                                                            // Setup initial CSVFormat with false for allowMissingColumnNames using builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("header1", "header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Verify new format has the new value
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                        }

 @Test
                                                                                        public void testWithAllowMissingColumnNames_False() {
                                                                                            // Setup initial CSVFormat with true for allowMissingColumnNames using builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("header1", "header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Verify new format has the new value
                                                                                            assertFalse(newFormat.getAllowMissingColumnNames());
                                                                                            
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreSurroundingSpaces(), newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                        }

 @Test
                                                                                        public void testWithAllowMissingColumnNames_SameValue() {
                                                                                            // Setup initial CSVFormat with true for allowMissingColumnNames using builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.DEFAULT
                                                                                                    .withDelimiter(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("header1", "header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Call method under test with same value
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Verify it's the same instance (should be for immutability optimization)
                                                                                            assertSame(originalFormat, newFormat);
                                                                                        }

 @Test
                                                                                        public void testWithAllowMissingColumnNames_NoHeader() {
                                                                                            // Setup initial CSVFormat with no headers using public factory method
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Verify new format has the new value
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            assertNull(newFormat.getHeader());
                                                                                        }

 @Test
                                                                                        public void testWithAllowMissingColumnNames_EmptyHeader() {
                                                                                            // Setup initial CSVFormat with empty headers using builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader(new String[]{})
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Verify new format has the new value
                                                                                            assertTrue(newFormat.getAllowMissingColumnNames());
                                                                                            assertArrayEquals(new String[]{}, newFormat.getHeader());
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreEmptyLines_True() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            Character quoteChar = '"';
                                                                                            QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                            Character commentMarker = '#';
                                                                                            Character escape = '\\';
                                                                                            boolean ignoreSurroundingSpaces = true;
                                                                                            boolean originalIgnoreEmptyLines = false;
                                                                                            String recordSeparator = "\n";
                                                                                            String nullString = "NULL";
                                                                                            String[] header = {"Name", "Age"};
                                                                                            boolean skipHeaderRecord = false;
                                                                                            boolean allowMissingColumnNames = false;
                                                                                            
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                    .withQuote(quoteChar)
                                                                                                    .withQuoteMode(quoteMode)
                                                                                                    .withCommentMarker(commentMarker)
                                                                                                    .withEscape(escape)
                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                    .withIgnoreEmptyLines(originalIgnoreEmptyLines)
                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                    .withNullString(nullString)
                                                                                                    .withHeader(header)
                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                    .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(true);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertTrue(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(delimiter, newFormat.getDelimiter());
                                                                                            assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                            assertEquals(quoteMode, newFormat.getQuoteMode());
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                            assertEquals(ignoreSurroundingSpaces, newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertEquals(skipHeaderRecord, newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(allowMissingColumnNames, newFormat.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreEmptyLines_False() {
                                                                                            // Setup
                                                                                            char delimiter = '\t';
                                                                                            Character quoteChar = '\'';
                                                                                            QuoteMode quoteMode = QuoteMode.ALL;
                                                                                            Character commentMarker = null;
                                                                                            Character escape = null;
                                                                                            boolean ignoreSurroundingSpaces = false;
                                                                                            boolean originalIgnoreEmptyLines = true;
                                                                                            String recordSeparator = "\r\n";
                                                                                            String nullString = "";
                                                                                            String[] header = null;
                                                                                            boolean skipHeaderRecord = true;
                                                                                            boolean allowMissingColumnNames = true;
                                                                                            
                                                                                            // Create format using builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(delimiter)
                                                                                                    .withQuote(quoteChar)
                                                                                                    .withQuoteMode(quoteMode)
                                                                                                    .withCommentMarker(commentMarker)
                                                                                                    .withEscape(escape)
                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                    .withIgnoreEmptyLines(originalIgnoreEmptyLines)
                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                    .withNullString(nullString)
                                                                                                    .withHeader(header)
                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                    .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreEmptyLines(false);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotSame(originalFormat, newFormat);
                                                                                            assertFalse(newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(delimiter, newFormat.getDelimiter());
                                                                                            assertEquals(quoteChar, newFormat.getQuoteCharacter());
                                                                                            assertEquals(quoteMode, newFormat.getQuoteMode());
                                                                                            assertEquals(commentMarker, newFormat.getCommentMarker());
                                                                                            assertEquals(escape, newFormat.getEscapeCharacter());
                                                                                            assertEquals(ignoreSurroundingSpaces, newFormat.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(recordSeparator, newFormat.getRecordSeparator());
                                                                                            assertEquals(nullString, newFormat.getNullString());
                                                                                            assertArrayEquals(header, newFormat.getHeader());
                                                                                            assertEquals(skipHeaderRecord, newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(allowMissingColumnNames, newFormat.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreEmptyLines_WithDuplicateHeaders() {
                                                                                            // Setup - create a format with duplicate headers (should throw exception)
                                                                                            String[] duplicateHeaders = {"Name", "Name"};
                                                                                            
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("The header contains a duplicate entry: 'Name'");
                                                                                            
                                                                                            CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader(duplicateHeaders)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_True() {
                                                                                            // Setup original format with false for ignoreSurroundingSpaces using public factory method
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker('#')
                                                                                                .withEscape('\\')
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString("NULL")
                                                                                                .withHeader("header1", "header2")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Verify new format has the new setting
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_False() {
                                                                                            // Setup original format with true for ignoreSurroundingSpaces using builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(';')
                                                                                                .withQuote('\'')
                                                                                                .withQuoteMode(QuoteMode.ALL)
                                                                                                .withCommentMarker('!')
                                                                                                .withEscape('/')
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(true)
                                                                                                .withRecordSeparator("\r\n")
                                                                                                .withNullString("null")
                                                                                                .withHeader("col1", "col2")
                                                                                                .withSkipHeaderRecord(true)
                                                                                                .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(false);
                                                                                            
                                                                                            // Verify new format has the new setting
                                                                                            assertFalse(newFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Verify all other properties remain the same
                                                                                            assertEquals(originalFormat.getDelimiter(), newFormat.getDelimiter());
                                                                                            assertEquals(originalFormat.getQuoteCharacter(), newFormat.getQuoteCharacter());
                                                                                            assertEquals(originalFormat.getQuoteMode(), newFormat.getQuoteMode());
                                                                                            assertEquals(originalFormat.getCommentMarker(), newFormat.getCommentMarker());
                                                                                            assertEquals(originalFormat.getEscapeCharacter(), newFormat.getEscapeCharacter());
                                                                                            assertEquals(originalFormat.getIgnoreEmptyLines(), newFormat.getIgnoreEmptyLines());
                                                                                            assertEquals(originalFormat.getRecordSeparator(), newFormat.getRecordSeparator());
                                                                                            assertEquals(originalFormat.getNullString(), newFormat.getNullString());
                                                                                            assertArrayEquals(originalFormat.getHeader(), newFormat.getHeader());
                                                                                            assertEquals(originalFormat.getSkipHeaderRecord(), newFormat.getSkipHeaderRecord());
                                                                                            assertEquals(originalFormat.getAllowMissingColumnNames(), newFormat.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_SameValueReturnsSameInstance() {
                                                                                            // Setup original format using public factory method and builder pattern
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat('\t')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.NON_NUMERIC)
                                                                                                .withIgnoreSurroundingSpaces(true)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\r")
                                                                                                .withNullString("NA")
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Call method with same value
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Should return same instance since value didn't change
                                                                                            assertSame(originalFormat, newFormat);
                                                                                        }

 @Test
                                                                                        public void testWithIgnoreSurroundingSpaces_WithNullHeader() {
                                                                                            // Setup format with null header using public factory method
                                                                                            CSVFormat originalFormat = CSVFormat.newFormat(',')
                                                                                                .withQuote('"')
                                                                                                .withQuoteMode(QuoteMode.MINIMAL)
                                                                                                .withCommentMarker(null)
                                                                                                .withEscape(null)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Call method under test
                                                                                            CSVFormat newFormat = originalFormat.withIgnoreSurroundingSpaces(true);
                                                                                            
                                                                                            // Verify new setting
                                                                                            assertTrue(newFormat.getIgnoreSurroundingSpaces());
                                                                                            
                                                                                            // Verify header remains null
                                                                                            assertNull(newFormat.getHeader());
                                                                                        }

 @Test
                                                                                        public void testWithNullString_ValidString() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            Character quoteChar = '"';
                                                                                            QuoteMode quoteMode = QuoteMode.ALL;
                                                                                            Character commentMarker = '#';
                                                                                            Character escape = '\\';
                                                                                            boolean ignoreSurroundingSpaces = true;
                                                                                            boolean ignoreEmptyLines = false;
                                                                                            String recordSeparator = "\n";
                                                                                            String originalNullString = "NULL";
                                                                                            String[] header = {"col1", "col2"};
                                                                                            boolean skipHeaderRecord = false;
                                                                                            boolean allowMissingColumnNames = true;
                                                                                            
                                                                                            // Create CSVFormat using builder pattern
                                                                                            CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                                    .withQuote(quoteChar)
                                                                                                    .withQuoteMode(quoteMode)
                                                                                                    .withCommentMarker(commentMarker)
                                                                                                    .withEscape(escape)
                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                    .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                    .withNullString(originalNullString)
                                                                                                    .withHeader(header)
                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                    .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                            
                                                                                            // Test
                                                                                            String newNullString = "NA";
                                                                                            CSVFormat result = original.withNullString(newNullString);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(newNullString, result.getNullString());
                                                                                            assertEquals(delimiter, result.getDelimiter());
                                                                                            assertEquals(quoteChar, result.getQuoteCharacter());
                                                                                            assertEquals(quoteMode, result.getQuoteMode());
                                                                                            assertEquals(commentMarker, result.getCommentMarker());
                                                                                            assertEquals(escape, result.getEscapeCharacter());
                                                                                            assertEquals(ignoreSurroundingSpaces, result.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(ignoreEmptyLines, result.getIgnoreEmptyLines());
                                                                                            assertEquals(recordSeparator, result.getRecordSeparator());
                                                                                            assertArrayEquals(header, result.getHeader());
                                                                                            assertEquals(skipHeaderRecord, result.getSkipHeaderRecord());
                                                                                            assertEquals(allowMissingColumnNames, result.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithNullString_FromNonNullToNull() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.newFormat(',')
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Test
                                                                                            CSVFormat result = original.withNullString(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNull(result.getNullString());
                                                                                            assertFalse(result.isNullStringSet());
                                                                                        }

 @Test
                                                                                        public void testWithQuoteMode_NonNullQuoteMode() {
                                                                                            // Setup
                                                                                            char delimiter = ',';
                                                                                            Character quoteChar = '"';
                                                                                            QuoteMode originalQuoteMode = QuoteMode.ALL;
                                                                                            Character commentMarker = '#';
                                                                                            Character escape = '\\';
                                                                                            boolean ignoreSurroundingSpaces = true;
                                                                                            boolean ignoreEmptyLines = false;
                                                                                            String recordSeparator = "\n";
                                                                                            String nullString = "NULL";
                                                                                            String[] header = {"Name", "Age"};
                                                                                            boolean skipHeaderRecord = true;
                                                                                            boolean allowMissingColumnNames = false;
                                                                                            
                                                                                            // Create format using builder pattern
                                                                                            CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                                    .withQuote(quoteChar)
                                                                                                    .withQuoteMode(originalQuoteMode)
                                                                                                    .withCommentMarker(commentMarker)
                                                                                                    .withEscape(escape)
                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                    .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                    .withNullString(nullString)
                                                                                                    .withHeader(header)
                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                    .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                            
                                                                                            QuoteMode newQuoteMode = QuoteMode.MINIMAL;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withQuoteMode(newQuoteMode);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertEquals(newQuoteMode, result.getQuoteMode());
                                                                                            assertEquals(delimiter, result.getDelimiter());
                                                                                            assertEquals(quoteChar, result.getQuoteCharacter());
                                                                                            assertEquals(commentMarker, result.getCommentMarker());
                                                                                            assertEquals(escape, result.getEscapeCharacter());
                                                                                            assertEquals(ignoreSurroundingSpaces, result.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(ignoreEmptyLines, result.getIgnoreEmptyLines());
                                                                                            assertEquals(recordSeparator, result.getRecordSeparator());
                                                                                            assertEquals(nullString, result.getNullString());
                                                                                            assertArrayEquals(header, result.getHeader());
                                                                                            assertEquals(skipHeaderRecord, result.getSkipHeaderRecord());
                                                                                            assertEquals(allowMissingColumnNames, result.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithQuoteMode_NullQuoteMode() {
                                                                                            // Setup
                                                                                            char delimiter = '\t';
                                                                                            Character quoteChar = '\'';
                                                                                            QuoteMode originalQuoteMode = QuoteMode.NON_NUMERIC;
                                                                                            Character commentMarker = null;
                                                                                            Character escape = null;
                                                                                            boolean ignoreSurroundingSpaces = false;
                                                                                            boolean ignoreEmptyLines = true;
                                                                                            String recordSeparator = "\r\n";
                                                                                            String nullString = null;
                                                                                            String[] header = null;
                                                                                            boolean skipHeaderRecord = false;
                                                                                            boolean allowMissingColumnNames = true;
                                                                                            
                                                                                            // Create CSVFormat using public methods
                                                                                            CSVFormat original = CSVFormat.newFormat(delimiter)
                                                                                                    .withQuote(quoteChar)
                                                                                                    .withQuoteMode(originalQuoteMode)
                                                                                                    .withCommentMarker(commentMarker)
                                                                                                    .withEscape(escape)
                                                                                                    .withIgnoreSurroundingSpaces(ignoreSurroundingSpaces)
                                                                                                    .withIgnoreEmptyLines(ignoreEmptyLines)
                                                                                                    .withRecordSeparator(recordSeparator)
                                                                                                    .withNullString(nullString)
                                                                                                    .withHeader(header)
                                                                                                    .withSkipHeaderRecord(skipHeaderRecord)
                                                                                                    .withAllowMissingColumnNames(allowMissingColumnNames);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withQuoteMode(null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertNull(result.getQuoteMode());
                                                                                            assertEquals(delimiter, result.getDelimiter());
                                                                                            assertEquals(quoteChar, result.getQuoteCharacter());
                                                                                            assertNull(result.getCommentMarker());
                                                                                            assertNull(result.getEscapeCharacter());
                                                                                            assertEquals(ignoreSurroundingSpaces, result.getIgnoreSurroundingSpaces());
                                                                                            assertEquals(ignoreEmptyLines, result.getIgnoreEmptyLines());
                                                                                            assertEquals(recordSeparator, result.getRecordSeparator());
                                                                                            assertNull(result.getNullString());
                                                                                            assertNull(result.getHeader());
                                                                                            assertEquals(skipHeaderRecord, result.getSkipHeaderRecord());
                                                                                            assertEquals(allowMissingColumnNames, result.getAllowMissingColumnNames());
                                                                                        }

 @Test
                                                                                        public void testWithQuoteMode_FromNullToNonNull() {
                                                                                            // Setup
                                                                                            CSVFormat original = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(null)
                                                                                                    .withCommentMarker(null)
                                                                                                    .withEscape(null)
                                                                                                    .withIgnoreSurroundingSpaces(false)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\n")
                                                                                                    .withNullString(null)
                                                                                                    .withHeader((String[]) null)
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(false);
                                                                                            QuoteMode newQuoteMode = QuoteMode.ALL;
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withQuoteMode(newQuoteMode);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(newQuoteMode, result.getQuoteMode());
                                                                                            assertNotEquals(original.getQuoteMode(), result.getQuoteMode());
                                                                                        }

 @Test
                                                                                        public void testWithQuoteMode_SameQuoteMode() {
                                                                                            // Setup
                                                                                            QuoteMode quoteMode = QuoteMode.MINIMAL;
                                                                                            CSVFormat original = CSVFormat.newFormat(';')
                                                                                                    .withQuote('\'')
                                                                                                    .withQuoteMode(quoteMode)
                                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                                    .withIgnoreEmptyLines(true)
                                                                                                    .withRecordSeparator("\r")
                                                                                                    .withNullString("NA")
                                                                                                    .withHeader("Col1", "Col2")
                                                                                                    .withSkipHeaderRecord(true)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Execute
                                                                                            CSVFormat result = original.withQuoteMode(quoteMode);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(quoteMode, result.getQuoteMode());
                                                                                            assertNotSame(original, result); // Should return new instance even when same value
                                                                                        }

 @Test
                                                                                        public void testWithRecordSeparator_String_ValidSeparator() {
                                                                                            // Setup original format with known values using public methods
                                                                                            CSVFormat original = CSVFormat.newFormat(',')
                                                                                                    .withQuote('"')
                                                                                                    .withQuoteMode(QuoteMode.ALL)
                                                                                                    .withCommentMarker('#')
                                                                                                    .withEscape('\\')
                                                                                                    .withIgnoreSurroundingSpaces(true)
                                                                                                    .withIgnoreEmptyLines(false)
                                                                                                    .withRecordSeparator("\r\n")
                                                                                                    .withNullString("NULL")
                                                                                                    .withHeader("header1", "header2")
                                                                                                    .withSkipHeaderRecord(false)
                                                                                                    .withAllowMissingColumnNames(true);
                                                                                            
                                                                                            // Test with new record separator
                                                                                            String newSeparator = "|";
                                                                                            CSVFormat modified = original.withRecordSeparator(newSeparator);
                                                                                            
                                                                                            // Verify all properties except record separator remain the same
                                                                                            assertEquals(',', modified.getDelimiter());
                                                                                            assertEquals(Character.valueOf('"'), modified.getQuoteCharacter());
                                                                                            assertEquals(QuoteMode.ALL, modified.getQuoteMode());
                                                                                            assertEquals(Character.valueOf('#'), modified.getCommentMarker());
                                                                                            assertEquals(Character.valueOf('\\'), modified.getEscapeCharacter());
                                                                                            assertTrue(modified.getIgnoreSurroundingSpaces());
                                                                                            assertFalse(modified.getIgnoreEmptyLines());
                                                                                            assertEquals("NULL", modified.getNullString());
                                                                                            assertArrayEquals(new String[]{"header1", "header2"}, modified.getHeader());
                                                                                            assertFalse(modified.getSkipHeaderRecord());
                                                                                            assertTrue(modified.getAllowMissingColumnNames());
                                                                                            
                                                                                            // Verify record separator was updated
                                                                                            assertEquals(newSeparator, modified.getRecordSeparator());
                                                                                        }

 @Test
                                                                                        public void testGetQuoteMode_WhenNull() {
                                                                                            // Arrange
                                                                                            CSVFormat format = CSVFormat.newFormat(',')
                                                                                                .withQuote(null)
                                                                                                .withQuoteMode(null)
                                                                                                .withCommentMarker(null)
                                                                                                .withEscape(null)
                                                                                                .withIgnoreSurroundingSpaces(false)
                                                                                                .withIgnoreEmptyLines(false)
                                                                                                .withRecordSeparator("\n")
                                                                                                .withNullString(null)
                                                                                                .withHeader((String[]) null)
                                                                                                .withSkipHeaderRecord(false)
                                                                                                .withAllowMissingColumnNames(false);
                                                                                            
                                                                                            // Act & Assert
                                                                                            assertNull(format.getQuoteMode());
                                                                                        }

 @Test
                                                                                public void testParse_WithQuotedValues() throws Exception {
                                                                                    // Arrange
                                                                                    org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.RFC4180;
                                                                                    java.io.Reader in = new java.io.StringReader("\"a\",\"b\",\"c\"\n\"1\",\"2\",\"3\"");
                                                                                    
                                                                                    // Act
                                                                                    org.apache.commons.csv.CSVParser parser = format.parse(in);
                                                                                    
                                                                                    // Assert
                                                                                    org.junit.Assert.assertNotNull(parser);
                                                                                    org.junit.Assert.assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                                                                }

 @Test
                                                                                public void testPrint_WithDifferentFormatInstances() throws IOException {
                                                                                    // Arrange
                                                                                    StringWriter writer1 = new StringWriter();
                                                                                    StringWriter writer2 = new StringWriter();
                                                                                    CSVFormat format1 = CSVFormat.DEFAULT.withDelimiter('|');
                                                                                    CSVFormat format2 = CSVFormat.RFC4180;
                                                                                    
                                                                                    // Act
                                                                                    CSVPrinter printer1 = new CSVPrinter(writer1, format1);
                                                                                    CSVPrinter printer2 = new CSVPrinter(writer2, format2);
                                                                                    
                                                                                    // Assert
                                                                                    assertNotEquals(format1, format2);
                                                                                    assertEquals('|', format1.getDelimiter());
                                                                                    assertEquals(',', format2.getDelimiter());
                                                                                }

 @Test
                                                                            public void testParse_WithEmptyInput() throws Exception {
                                                                                // Arrange
                                                                                org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                                                java.io.Reader in = new java.io.StringReader("");
                                                                                
                                                                                // Act
                                                                                org.apache.commons.csv.CSVParser parser = format.parse(in);
                                                                                
                                                                                // Assert
                                                                                org.junit.Assert.assertNotNull(parser);
                                                                                org.junit.Assert.assertFalse(parser.iterator().hasNext());
                                                                            }

 @Test
                                                        public void testWithNullString_FromNullToNonNull() {
                                                            // Setup
                                                            CSVFormat original = CSVFormat.newFormat(',')
                                                                    .withQuoteMode(null)
                                                                    .withCommentMarker(null)
                                                                    .withEscape(null)
                                                                    .withIgnoreSurroundingSpaces(false)
                                                                    .withIgnoreEmptyLines(false)
                                                                    .withRecordSeparator("\n")
                                                                    .withNullString(null)
                                                                    .withHeader((String[]) null)
                                                                    .withSkipHeaderRecord(false)
                                                                    .withAllowMissingColumnNames(false);
                                                            
                                                            // Test
                                                            CSVFormat result = original.withNullString("null");
                                                            
                                                            // Verify
                                                            assertEquals("null", result.getNullString());
                                                            assertTrue(result.isNullStringSet());
                                                        }

 @Test
                                                        public void testParse_WithHeader() throws Exception {
                                                            // Arrange
                                                            org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withHeader("Name", "Age", "City");
                                                            java.io.Reader in = new java.io.StringReader("Name,Age,City\nJohn,25,New York\nAlice,30,London");
                                                            
                                                            // Act
                                                            org.apache.commons.csv.CSVParser parser = format.parse(in);
                                                            
                                                            // Assert
                                                            org.junit.Assert.assertNotNull(parser);
                                                            org.junit.Assert.assertArrayEquals(new String[]{"Name", "Age", "City"}, format.getHeader());
                                                        }

 @Test
                                                        public void testPrint_WithValidAppendable() throws IOException {
                                                            // Arrange
                                                            java.io.StringWriter writer = new java.io.StringWriter();
                                                            org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                            
                                                            // Act
                                                            org.apache.commons.csv.CSVPrinter printer = format.print(writer);
                                                            
                                                            // Assert
                                                            org.junit.Assert.assertNotNull(printer);
                                                            org.junit.Assert.assertSame(writer, printer.getOut());
                                                        }

 @Test
                                                        public void testPrint_WithQuoteMode() throws IOException {
                                                            // Arrange
                                                            StringWriter writer = new StringWriter();
                                                            CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
                                                            
                                                            // Act
                                                            CSVPrinter printer = format.print(writer);
                                                            
                                                            // Assert
                                                            assertNotNull(printer);
                                                        }

 @Test
                                                        public void testWithDelimiter_NullStringHeaderPreserved() {
                                                            // Setup format with null string and null header
                                                            CSVFormat baseFormat = CSVFormat.newFormat(',')
                                                                .withQuoteMode(null)
                                                                .withCommentMarker(null)
                                                                .withEscape((Character) null)
                                                                .withRecordSeparator((String) null)
                                                                .withNullString(null)
                                                                .withHeader((String[]) null)
                                                                .withIgnoreSurroundingSpaces(false)
                                                                .withIgnoreEmptyLines(false)
                                                                .withSkipHeaderRecord(false)
                                                                .withAllowMissingColumnNames(false);
                                                            
                                                            CSVFormat newFormat = baseFormat.withDelimiter(';');
                                                            
                                                            assertEquals(';', newFormat.getDelimiter());
                                                            assertNull(newFormat.getQuoteCharacter());
                                                            assertNull(newFormat.getQuoteMode());
                                                            assertNull(newFormat.getCommentMarker());
                                                            assertNull(newFormat.getEscapeCharacter());
                                                            assertNull(newFormat.getRecordSeparator());
                                                            assertNull(newFormat.getNullString());
                                                            assertNull(newFormat.getHeader());
                                                        }

 @Test
                                                        public void testParse_WithDefaultFormat() throws Exception {
                                                            // Arrange
                                                            org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                            java.io.Reader in = new java.io.StringReader("a,b,c\n1,2,3");
                                                            
                                                            // Act
                                                            org.apache.commons.csv.CSVParser parser = format.parse(in);
                                                            
                                                            // Assert
                                                            org.junit.Assert.assertNotNull(parser);
                                                            org.junit.Assert.assertFalse(parser.isClosed());
                                                        }

 @Test
                                                    public void testWithQuoteMode_VerifyImmutability() {
                                                        // Setup
                                                        org.apache.commons.csv.CSVFormat original = org.apache.commons.csv.CSVFormat.DEFAULT;
                                                        org.apache.commons.csv.QuoteMode newQuoteMode = org.apache.commons.csv.QuoteMode.ALL;
                                                        
                                                        // Execute
                                                        org.apache.commons.csv.CSVFormat modified = original.withQuoteMode(newQuoteMode);
                                                        
                                                        // Verify original is unchanged
                                                        org.junit.Assert.assertNotEquals(original.getQuoteMode(), modified.getQuoteMode());
                                                        org.junit.Assert.assertEquals(newQuoteMode, modified.getQuoteMode());
                                                    }

 @Test
                                                public void testParse_WithNullString() throws Exception {
                                                    // Arrange
                                                    org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withNullString("NULL");
                                                    String input = "test,data,NULL";
                                                    java.io.Reader in = new java.io.StringReader(input);
                                                    
                                                    // Act
                                                    org.apache.commons.csv.CSVParser parser = format.parse(in);
                                                    
                                                    // Assert
                                                    org.junit.Assert.assertNotNull(parser);
                                                }

 @Test
                                                public void testParse_WithCustomFormat() throws Exception {
                                                    // Arrange
                                                    CSVFormat format = CSVFormat.newFormat(';')
                                                        .withQuote('"')
                                                        .withQuoteMode(QuoteMode.ALL)
                                                        .withIgnoreEmptyLines(true);
                                                    String csvData = "header1;header2\nvalue1;value2";
                                                    java.io.Reader in = new java.io.StringReader(csvData);
                                                    
                                                    // Act
                                                    CSVParser parser = format.parse(in);
                                                    
                                                    // Assert
                                                    assertNotNull(parser);
                                                }

 @Test
                                            public void testParse_WithCommentMarker() throws Exception {
                                                // Arrange
                                                org.apache.commons.csv.CSVFormat format = org.apache.commons.csv.CSVFormat.DEFAULT.withCommentMarker('#');
                                                String input = "# This is a comment\\na,b,c\\n1,2,3";
                                                
                                                // Act
                                                org.apache.commons.csv.CSVParser parser = format.parse(new java.io.StringReader(input));
                                                
                                                // Assert
                                                assertNotNull(parser);
                                                assertEquals(Character.valueOf('#'), format.getCommentMarker());
                                                assertEquals(2, parser.getRecords().size()); // Should skip comment line
                                            }

 @Test
                                        public void testParse_WithDifferentDelimiters() throws Exception {
                                            // Arrange
                                            CSVFormat tabFormat = CSVFormat.newFormat('\t');
                                            String input = "header1\theader2\nvalue1\tvalue2";
                                            java.io.Reader in = new java.io.StringReader(input);
                                            
                                            // Act
                                            org.apache.commons.csv.CSVParser parser = tabFormat.parse(in);
                                            
                                            // Assert
                                            org.junit.Assert.assertNotNull(parser);
                                            org.junit.Assert.assertEquals('\t', tabFormat.getDelimiter());
                                        }

 @Test
                                    public void testPrint_WithCustomFormatSettings() throws IOException {
                                        // Arrange
                                        StringWriter writer = new StringWriter();
                                        CSVFormat format = CSVFormat.DEFAULT
                                            .withDelimiter(';')
                                            .withQuote('"')
                                            .withRecordSeparator("\r\n")
                                            .withNullString("NULL");
                                        
                                        // Act
                                        CSVPrinter printer = format.print(writer);
                                        
                                        // Assert
                                        assertNotNull(printer);
                                        assertEquals(';', format.getDelimiter());
                                        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
                                        assertEquals("\r\n", format.getRecordSeparator());
                                        assertEquals("NULL", format.getNullString());
                                    }

}
