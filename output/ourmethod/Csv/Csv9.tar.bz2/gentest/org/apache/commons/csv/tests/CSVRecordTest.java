package gentest.org.apache.commons.csv.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.csv.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
 
public class CSVRecordTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
         public void testPutIn_NullMapping() throws Exception {
             // Setup
             String[] values = {"a", "b", "c"};
             Map<String, Integer> mapping = null;
             
             // Use reflection to access non-public constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             inputMap.put("existing", "value");
             
             // Use reflection to access non-public putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(1, result.size());
             assertEquals("value", result.get("existing"));
             assertSame(inputMap, result); // should return same map instance
         }

    @Test
         public void testPutIn_EmptyMapping() throws Exception {
             // Setup
             String[] values = {"a", "b", "c"};
             Map<String, Integer> mapping = new HashMap<>();
             
             // Get constructor via reflection
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Get method via reflection
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertTrue(result.isEmpty());
         }

    @Test
         public void testPutIn_NormalCase() throws Exception {
             // Setup
             String[] values = {"val1", "val2", "val3"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key1", 0);
             mapping.put("key2", 1);
             mapping.put("key3", 2);
             
             // Use reflection to access package-private constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access package-private method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(3, result.size());
             assertEquals("val1", result.get("key1"));
             assertEquals("val2", result.get("key2"));
             assertEquals("val3", result.get("key3"));
         }

    @Test
         public void testPutIn_OutOfBoundsColumns() throws Exception {
             // Setup
             String[] values = {"val1", "val2"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("valid", 1);      // in bounds
             mapping.put("invalid", 2);    // out of bounds
             
             // Get constructor and make it accessible
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Get putIn method and make it accessible
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(1, result.size());
             assertEquals("val2", result.get("valid"));
             assertFalse(result.containsKey("invalid"));
         }

    @Test
         public void testPutIn_NullValuesArray() throws Exception {
             // Setup
             String[] values = null;
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("key", 0);
             
             // Use reflection to access non-public constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Use reflection to access non-public putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertTrue(result.isEmpty()); // values becomes EMPTY_STRING_ARRAY in constructor
         }

    @Test
         public void testPutIn_MixedValidInvalidColumns() throws Exception {
             // Setup
             String[] values = {"a", "b", "c", "d"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("valid1", 0);
             mapping.put("invalid", 4);    // out of bounds
             mapping.put("valid2", 3);
             mapping.put("invalid2", -1);  // negative index
             
             // Create CSVRecord instance using reflection
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             
             // Access putIn method using reflection
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             
             // Execute
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(2, result.size());
             assertEquals("a", result.get("valid1"));
             assertEquals("d", result.get("valid2"));
             assertFalse(result.containsKey("invalid"));
             assertFalse(result.containsKey("invalid2"));
         }

    @Test
         public void testPutIn_PreservesExistingMapEntries() throws Exception {
             // Setup
             String[] values = {"new1", "new2"};
             Map<String, Integer> mapping = new HashMap<>();
             mapping.put("newKey", 1);
             
             // Use reflection to access non-public constructor
             Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                 String[].class, Map.class, String.class, long.class);
             constructor.setAccessible(true);
             CSVRecord record = constructor.newInstance(values, mapping, "comment", 1L);
             
             Map<String, String> inputMap = new HashMap<>();
             inputMap.put("existingKey", "existingValue");
             
             // Use reflection to access non-public putIn method
             Method putInMethod = CSVRecord.class.getDeclaredMethod("putIn", Map.class);
             putInMethod.setAccessible(true);
             @SuppressWarnings("unchecked")
             Map<String, String> result = (Map<String, String>) putInMethod.invoke(record, inputMap);
             
             // Verify
             assertEquals(2, result.size());
             assertEquals("existingValue", result.get("existingKey"));
             assertEquals("new2", result.get("newKey"));
         }

    @Test
    public void testIteratorReturnsRegularIteratorNotListIterator() {
        // Setup test data
        String[] values = {"value1", "value2"};
        Map<String, Integer> mapping = new HashMap<>();
        mapping.put("col1", 0);
        mapping.put("col2", 1);
        
        // Create test record using reflection since constructor is not public
        CSVRecord record;
        try {
            Constructor<CSVRecord> constructor = CSVRecord.class.getDeclaredConstructor(
                String[].class, Map.class, String.class, long.class);
            constructor.setAccessible(true);
            record = constructor.newInstance(values, mapping, "comment", 1L);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create CSVRecord instance", e);
        }
        
        // Get the iterator
        Iterator<String> iterator = record.iterator();
        
        // Verify it's not a ListIterator
        assertFalse("Iterator should not be a ListIterator", 
                   iterator instanceof java.util.ListIterator);
        
        // Verify basic iterator functionality works
        assertTrue(iterator.hasNext());
        assertEquals("value1", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("value2", iterator.next());
        assertFalse(iterator.hasNext());
    }


}
