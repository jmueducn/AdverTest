package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
 
public class UnsafeAllocatorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                       public void testNewInstance_WithConcreteClass() throws Exception {
                                                                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                           Object result = allocator.newInstance(Object.class);
                                                                                                                                                                                           assertNotNull(result);
                                                                                                                                                                                           assertEquals(Object.class, result.getClass());
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                       public void testNewInstance_WithInterfaceShouldFail() throws Exception {
                                                                                                                                                                                           thrown.expect(InstantiationException.class);
                                                                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                           allocator.newInstance(Runnable.class);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                       public void testNewInstance_WithNullClassShouldFail() throws Exception {
                                                                                                                                                                                           thrown.expect(NullPointerException.class);
                                                                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                           allocator.newInstance(null);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                       public void testNewInstance_WithArrayClassShouldFail() throws Exception {
                                                                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                           allocator.newInstance(int[].class);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                       public void testNewInstance_WithPrimitiveClassShouldFail() throws Exception {
                                                                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                           allocator.newInstance(int.class);
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                               public void testNewInstance_WithAbstractClassShouldFail() throws Exception {
                                                                                                                                                                                   abstract class AbstractClass {} // Local abstract class definition
                                                                                                                                                                                   
                                                                                                                                                                                   ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                   thrown.expect(InstantiationException.class);
                                                                                                                                                                                   UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                   allocator.newInstance(AbstractClass.class);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                               public void testNewInstance_WithPrivateConstructorClass() throws Exception {
                                                                                                                                                                                   // Define a local class with private constructor for testing
                                                                                                                                                                                   class PrivateConstructorClass {
                                                                                                                                                                                       private PrivateConstructorClass() {}
                                                                                                                                                                                   }
                                                                                                                                                                                   
                                                                                                                                                                                   UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                   Object result = allocator.newInstance(PrivateConstructorClass.class);
                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                   assertEquals(PrivateConstructorClass.class, result.getClass());
                                                                                                                                                                               }

    @Test
                                                                                                                                                                               public void testAssertInstantiable_WithConcreteClass() throws Exception {
                                                                                                                                                                                   // Arrange
                                                                                                                                                                                   Class<?> concreteClass = String.class; // String is a concrete class
                                                                                                                                                                                   Class<?> allocatorClass = Class.forName("com.google.gson.internal.UnsafeAllocator");
                                                                                                                                                                                   Method assertInstantiableMethod = allocatorClass.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                   assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Act & Assert - should not throw any exception
                                                                                                                                                                                   assertInstantiableMethod.invoke(null, concreteClass);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                               public void testAssertInstantiable_WithAbstractClass() throws Exception {
                                                                                                                                                                                   // Arrange
                                                                                                                                                                                   Class<?> abstractClass = mock(Class.class);
                                                                                                                                                                                   when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                                                                                                                   when(abstractClass.getName()).thenReturn("com.example.AbstractTest");
                                                                                                                                                                                   
                                                                                                                                                                                   // Get private method via reflection
                                                                                                                                                                                   Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                   assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Create ExpectedException rule
                                                                                                                                                                                   ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                                                                   exceptionRule.expect(UnsupportedOperationException.class);
                                                                                                                                                                                   exceptionRule.expectMessage("Abstract class can't be instantiated! Class name: com.example.AbstractTest");
                                                                                                                                                                                   
                                                                                                                                                                                   // Act
                                                                                                                                                                                   assertInstantiableMethod.invoke(null, abstractClass);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                               public void testAssertInstantiable_WithPublicConcreteClass() throws Exception {
                                                                                                                                                                                   // Arrange
                                                                                                                                                                                   Class<?> publicClass = mock(Class.class);
                                                                                                                                                                                   when(publicClass.getModifiers()).thenReturn(Modifier.PUBLIC);
                                                                                                                                                                                   when(publicClass.getName()).thenReturn("com.example.PublicClass");
                                                                                                                                                                                   
                                                                                                                                                                                   // Get the private assertInstantiable method via reflection
                                                                                                                                                                                   Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                   assertInstantiable.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Act & Assert - should not throw any exception
                                                                                                                                                                                   assertInstantiable.invoke(null, publicClass);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                               public void testAssertInstantiable_WithFinalClass() throws Exception {
                                                                                                                                                                                   // Arrange
                                                                                                                                                                                   Class<?> finalClass = mock(Class.class);
                                                                                                                                                                                   when(finalClass.getModifiers()).thenReturn(Modifier.FINAL);
                                                                                                                                                                                   when(finalClass.getName()).thenReturn("com.example.FinalClass");
                                                                                                                                                                                   
                                                                                                                                                                                   // Get the private method via reflection
                                                                                                                                                                                   Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                   assertInstantiable.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Act & Assert - should not throw any exception (final classes can be instantiated)
                                                                                                                                                                                   assertInstantiable.invoke(null, finalClass);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                           public void testAssertInstantiable_WithInterface() throws Exception {
                                                                                                                                                                               // Arrange
                                                                                                                                                                               Class<?> interfaceClass = mock(Class.class);
                                                                                                                                                                               when(interfaceClass.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                                               when(interfaceClass.getName()).thenReturn("com.example.TestInterface");
                                                                                                                                                                               
                                                                                                                                                                               // Get private method via reflection
                                                                                                                                                                               Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                               assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               try {
                                                                                                                                                                                   // Act
                                                                                                                                                                                   assertInstantiableMethod.invoke(null, interfaceClass);
                                                                                                                                                                                   fail("Expected UnsupportedOperationException");
                                                                                                                                                                               } catch (InvocationTargetException e) {
                                                                                                                                                                                   // Assert
                                                                                                                                                                                   assertEquals(UnsupportedOperationException.class, e.getCause().getClass());
                                                                                                                                                                                   assertEquals("Interface can't be instantiated! Interface name: com.example.TestInterface", 
                                                                                                                                                                                       e.getCause().getMessage());
                                                                                                                                                                               }
                                                                                                                                                                           }

    @Test
                                                                                                                                                                           public void testAssertInstantiable_WithInterfaceAndAbstractModifier() throws Exception {
                                                                                                                                                                               // Arrange
                                                                                                                                                                               Class<?> interfaceClass = mock(Class.class);
                                                                                                                                                                               when(interfaceClass.getModifiers()).thenReturn(Modifier.INTERFACE | Modifier.ABSTRACT);
                                                                                                                                                                               when(interfaceClass.getName()).thenReturn("com.example.AbstractInterface");
                                                                                                                                                                               
                                                                                                                                                                               // Get private method via reflection
                                                                                                                                                                               Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                               assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                               
                                                                                                                                                                               // Expect exception (should prioritize interface check)
                                                                                                                                                                               ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                               expectedException.expect(UnsupportedOperationException.class);
                                                                                                                                                                               expectedException.expectMessage("Interface can't be instantiated! Interface name: com.example.AbstractInterface");
                                                                                                                                                                               
                                                                                                                                                                               // Act
                                                                                                                                                                               assertInstantiableMethod.invoke(null, interfaceClass);
                                                                                                                                                                           }

    @Test
                                                                                                                                                                      public void testAssertInstantiable_ShouldThrowExceptionForInterface() throws Exception {
                                                                                                                                                                          // Create a mock interface class
                                                                                                                                                                          Class<?> interfaceClass = new Object() {}.getClass().getInterfaces()[0];
                                                                                                                                                                          
                                                                                                                                                                          // Get the private assertInstantiable method
                                                                                                                                                                          Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                          assertInstantiable.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Expect the exception with the correct message
                                                                                                                                                                          thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                                          thrown.expectMessage("Interface can't be instantiated! Interface name: " + interfaceClass.getName());
                                                                                                                                                                          
                                                                                                                                                                          // Call the method which should throw the exception
                                                                                                                                                                          assertInstantiable.invoke(null, interfaceClass);
                                                                                                                                                                      }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                                                 public void testAssertInstantiable_ShouldThrowForInterface() throws Exception {
                                                                                                                                                                     // Arrange
                                                                                                                                                                     Class<?> mockInterface = mock(Class.class);
                                                                                                                                                                     when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                                     when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                                                                                     
                                                                                                                                                                     // Get the private method via reflection
                                                                                                                                                                     Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                     assertInstantiable.setAccessible(true);
                                                                                                                                                                     
                                                                                                                                                                     // Act
                                                                                                                                                                     assertInstantiable.invoke(null, mockInterface);
                                                                                                                                                                     
                                                                                                                                                                     // Assert - exception expected (handled by @Test annotation)
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testAssertInstantiable_ShouldThrowCorrectMessageForInterface() {
                                                                                                                                                                     // Arrange
                                                                                                                                                                     Class<?> mockInterface = mock(Class.class);
                                                                                                                                                                     when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                                     when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                                                                                     
                                                                                                                                                                     try {
                                                                                                                                                                         // Act
                                                                                                                                                                         Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                         assertInstantiable.setAccessible(true);
                                                                                                                                                                         assertInstantiable.invoke(null, mockInterface);
                                                                                                                                                                         fail("Expected UnsupportedOperationException");
                                                                                                                                                                     } catch (NoSuchMethodException | IllegalAccessException e) {
                                                                                                                                                                         fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                     } catch (InvocationTargetException e) {
                                                                                                                                                                         // Assert
                                                                                                                                                                         Throwable cause = e.getCause();
                                                                                                                                                                         assertEquals(UnsupportedOperationException.class, cause.getClass());
                                                                                                                                                                         assertEquals("Interface can't be instantiated! Interface name: TestInterface", cause.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testAssertInstantiable_Interface_ThrowsUnsupportedOperationException() throws Exception {
                                                                                                                                                                // Arrange
                                                                                                                                                                Class<?> mockInterface = mock(Class.class);
                                                                                                                                                                when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                                when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                                                                            
                                                                                                                                                                // Set expectation for the exact exception type and message
                                                                                                                                                                thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                                thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                                                                                                                                            
                                                                                                                                                                // Get the private method via reflection
                                                                                                                                                                Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                assertInstantiable.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                                // Act
                                                                                                                                                                assertInstantiable.invoke(null, mockInterface);
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testAssertInstantiable_ShouldThrowExceptionForInterface1() throws Exception {
                                                                                                                                                           // Arrange
                                                                                                                                                           Class<?> mockInterface = mock(Class.class);
                                                                                                                                                           when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                           when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                                                                       
                                                                                                                                                           // Set expectation for the exception
                                                                                                                                                           thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                           thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                                                                                                                                       
                                                                                                                                                           // Get the private method via reflection
                                                                                                                                                           Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                           assertInstantiableMethod.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Act
                                                                                                                                                           assertInstantiableMethod.invoke(null, mockInterface);
                                                                                                                                                           
                                                                                                                                                           // Assertion is handled by the ExpectedException rule
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testAssertInstantiable_ShouldNotThrowForConcreteClass() throws Exception {
                                                                                                                                                           // Arrange
                                                                                                                                                           Class<?> mockClass = mock(Class.class);
                                                                                                                                                           when(mockClass.getModifiers()).thenReturn(0); // No modifiers = concrete class
                                                                                                                                                           when(mockClass.getName()).thenReturn("TestClass");
                                                                                                                                                           
                                                                                                                                                           // Get the private method via reflection
                                                                                                                                                           Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                           assertInstantiableMethod.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Act - should not throw any exception
                                                                                                                                                           assertInstantiableMethod.invoke(null, mockClass);
                                                                                                                                                           
                                                                                                                                                           // No exception means test passes
                                                                                                                                                       }

    @Test
                                                                                                                                                       public void testAssertInstantiable_ShouldThrowExceptionForAbstractClass() throws Exception {
                                                                                                                                                           // Arrange
                                                                                                                                                           Class<?> mockAbstractClass = mock(Class.class);
                                                                                                                                                           when(mockAbstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                                                                                           when(mockAbstractClass.getName()).thenReturn("AbstractTestClass");
                                                                                                                                                       
                                                                                                                                                           // Set expectation for the exception
                                                                                                                                                           thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                           thrown.expectMessage("Abstract class can't be instantiated! Class name: AbstractTestClass");
                                                                                                                                                       
                                                                                                                                                           // Use reflection to access private method
                                                                                                                                                           Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                           assertInstantiableMethod.setAccessible(true);
                                                                                                                                                           
                                                                                                                                                           // Act
                                                                                                                                                           assertInstantiableMethod.invoke(null, mockAbstractClass);
                                                                                                                                                       }

    @Test
                                                                                                                                              public void testAssertInstantiable_ThrowsExceptionForInterface() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  Class<?> mockInterface = mock(Class.class);
                                                                                                                                                  when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                  when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                                                                  
                                                                                                                                                  // Get private method via reflection
                                                                                                                                                  Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                  assertInstantiableMethod.setAccessible(true);
                                                                                                                                                  
                                                                                                                                                  try {
                                                                                                                                                      // Act
                                                                                                                                                      assertInstantiableMethod.invoke(null, mockInterface);
                                                                                                                                                      fail("Expected UnsupportedOperationException to be thrown");
                                                                                                                                                  } catch (InvocationTargetException e) {
                                                                                                                                                      // Assert
                                                                                                                                                      Throwable actualException = e.getCause();
                                                                                                                                                      assertEquals(UnsupportedOperationException.class, actualException.getClass());
                                                                                                                                                      assertEquals("Interface can't be instantiated! Interface name: TestInterface", 
                                                                                                                                                          actualException.getMessage());
                                                                                                                                                  }
                                                                                                                                              }

    @Test
                                                                                                                                         public void testAssertInstantiableWithAbstractClassThrowsCorrectException() throws Exception {
                                                                                                                                             // Create ExpectedException rule
                                                                                                                                             ExpectedException exceptionRule = ExpectedException.none();
                                                                                                                                             
                                                                                                                                             // Create a mock abstract class
                                                                                                                                             Class<?> abstractClass = mock(Class.class);
                                                                                                                                             when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                                                                             when(abstractClass.getName()).thenReturn("TestAbstractClass");
                                                                                                                                         
                                                                                                                                             // Expect UnsupportedOperationException with specific message
                                                                                                                                             exceptionRule.expect(UnsupportedOperationException.class);
                                                                                                                                             exceptionRule.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                                                                                                                                         
                                                                                                                                             // Get private method via reflection
                                                                                                                                             Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                             assertInstantiableMethod.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Call the method - should throw UnsupportedOperationException
                                                                                                                                             // If mutant is present, it will throw RuntimeException instead
                                                                                                                                             assertInstantiableMethod.invoke(null, abstractClass);
                                                                                                                                         }

    @Test
                                                                                                                                         public void testAssertInstantiableShouldRemainPrivate() throws Exception {
                                                                                                                                             // Get the method using reflection
                                                                                                                                             Method method = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                             
                                                                                                                                             // Verify the method is private
                                                                                                                                             assertTrue("Method should be private", Modifier.isPrivate(method.getModifiers()));
                                                                                                                                             
                                                                                                                                             // Verify the method is static
                                                                                                                                             assertTrue("Method should be static", Modifier.isStatic(method.getModifiers()));
                                                                                                                                         }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                         public void testAssertInstantiableWithInterface() throws Exception {
                                                                                                                                             // Get the private method and make it accessible
                                                                                                                                             Method method = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                             method.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Test with an interface
                                                                                                                                             method.invoke(null, Runnable.class);
                                                                                                                                         }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                         public void testAssertInstantiableWithAbstractClass() throws Exception {
                                                                                                                                             // Get the private method and make it accessible
                                                                                                                                             Method method = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                             method.setAccessible(true);
                                                                                                                                             
                                                                                                                                             // Test with an abstract class
                                                                                                                                             method.invoke(null, Number.class);
                                                                                                                                         }

    @Test
                                                                                                                                   public void testAssertInstantiable_Interface_ShouldThrowWithCorrectMessage() throws Exception {
                                                                                                                                       // Arrange
                                                                                                                                       Class<?> mockInterface = mock(Class.class);
                                                                                                                                       when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                       when(mockInterface.getName()).thenReturn("com.example.TestInterface");
                                                                                                                                   
                                                                                                                                       // Set up expected exception
                                                                                                                                       ExpectedException expectedException = ExpectedException.none();
                                                                                                                                       expectedException.expect(UnsupportedOperationException.class);
                                                                                                                                       expectedException.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
                                                                                                                                   
                                                                                                                                       // Use reflection to access private method
                                                                                                                                       Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                       assertInstantiableMethod.setAccessible(true);
                                                                                                                                   
                                                                                                                                       // Act
                                                                                                                                       assertInstantiableMethod.invoke(null, mockInterface);
                                                                                                                                   }

    @Test
                                                                                                                              public void testAssertInstantiable_AbstractClass_ShouldThrowWithCorrectMessage() throws Exception {
                                                                                                                                  // Arrange
                                                                                                                                  Class<?> abstractClass = mock(Class.class);
                                                                                                                                  when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                                                                  when(abstractClass.getName()).thenReturn("TestAbstractClass");
                                                                                                                                  
                                                                                                                                  // Set up expected exception
                                                                                                                                  ExpectedException expectedException = ExpectedException.none();
                                                                                                                                  expectedException.expect(UnsupportedOperationException.class);
                                                                                                                                  expectedException.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                                                                                                                                  
                                                                                                                                  // Use reflection to access private method
                                                                                                                                  Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                  assertInstantiableMethod.setAccessible(true);
                                                                                                                                  
                                                                                                                                  // Act
                                                                                                                                  assertInstantiableMethod.invoke(null, abstractClass);
                                                                                                                              }

    @Test
                                                                                                                     public void testAssertInstantiable_Interface_ShouldThrowWithSpecificMessage() throws Exception {
                                                                                                                         // Arrange
                                                                                                                         Class<?> mockInterface = mock(Class.class);
                                                                                                                         when(mockInterface.isInterface()).thenReturn(true);
                                                                                                                         when(mockInterface.getName()).thenReturn("com.example.TestInterface");
                                                                                                                         
                                                                                                                         // Set expectation for the exception
                                                                                                                         org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                         exception.expect(UnsupportedOperationException.class);
                                                                                                                         exception.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
                                                                                                                         
                                                                                                                         // Get private method via reflection
                                                                                                                         java.lang.reflect.Method assertInstantiableMethod = com.google.gson.internal.UnsafeAllocator.class
                                                                                                                                 .getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                         assertInstantiableMethod.setAccessible(true);
                                                                                                                         
                                                                                                                         // Act
                                                                                                                         assertInstantiableMethod.invoke(null, mockInterface);
                                                                                                                     }

    @Test
                                                                                                                public void testAssertInstantiable_AbstractClass_OriginalErrorMessage() throws Exception {
                                                                                                                    // Create a mock abstract class
                                                                                                                    Class<?> abstractClass = mock(Class.class);
                                                                                                                    when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                                                    when(abstractClass.getName()).thenReturn("TestAbstractClass");
                                                                                                                
                                                                                                                    // Get the private method via reflection
                                                                                                                    Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                    assertInstantiable.setAccessible(true);
                                                                                                                
                                                                                                                    try {
                                                                                                                        // Call the method under test
                                                                                                                        assertInstantiable.invoke(null, abstractClass);
                                                                                                                        fail("Expected UnsupportedOperationException");
                                                                                                                    } catch (InvocationTargetException e) {
                                                                                                                        // Verify the exception type and message
                                                                                                                        Throwable cause = e.getCause();
                                                                                                                        assertEquals(UnsupportedOperationException.class, cause.getClass());
                                                                                                                        assertEquals("Abstract class can't be instantiated! Class name: TestAbstractClass", cause.getMessage());
                                                                                                                    }
                                                                                                                }

    @Test
                                                                                                           public void testAssertInstantiable_ShouldNotThrowForConcreteClass1() throws Exception {
                                                                                                               // Use a concrete class that we know is not abstract or interface
                                                                                                               Class<?> concreteClass = String.class;
                                                                                                               
                                                                                                               // Get the private assertInstantiable method using reflection
                                                                                                               Class<?> allocatorClass = Class.forName("com.google.gson.internal.UnsafeAllocator");
                                                                                                               Method assertInstantiableMethod = allocatorClass.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                               assertInstantiableMethod.setAccessible(true);
                                                                                                               
                                                                                                               // This should not throw any exception
                                                                                                               assertInstantiableMethod.invoke(null, concreteClass);
                                                                                                           }

    @Test
                                                                                                           public void testAssertInstantiable_ShouldThrowForAbstractClass() throws Exception {
                                                                                                               // Create an abstract class for testing
                                                                                                               abstract class TestAbstractClass {}
                                                                                                               Class<?> abstractClass = TestAbstractClass.class;
                                                                                                           
                                                                                                               // Get the private method using reflection
                                                                                                               Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                               assertInstantiableMethod.setAccessible(true);
                                                                                                           
                                                                                                               // Expect the exception with specific message
                                                                                                               thrown.expect(UnsupportedOperationException.class);
                                                                                                               thrown.expectMessage("Abstract class can't be instantiated! Class name: " + abstractClass.getName());
                                                                                                           
                                                                                                               // Call the method via reflection
                                                                                                               assertInstantiableMethod.invoke(null, abstractClass);
                                                                                                           }

    @Test
                                                                                                       public void testAssertInstantiable_ShouldThrowForInterface1() throws Exception {
                                                                                                           // Use existing interface for testing
                                                                                                           Class<?> interfaceClass = Runnable.class;
                                                                                                           
                                                                                                           // Get the private assertInstantiable method
                                                                                                           Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                           assertInstantiableMethod.setAccessible(true);
                                                                                                           
                                                                                                           // Expect the exception with specific message
                                                                                                           thrown.expect(UnsupportedOperationException.class);
                                                                                                           thrown.expectMessage("Interface can't be instantiated! Interface name: " + interfaceClass.getName());
                                                                                                           
                                                                                                           // Call the method via reflection
                                                                                                           assertInstantiableMethod.invoke(null, interfaceClass);
                                                                                                       }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                  public void testAssertInstantiable_WithInterface_ShouldThrowException() throws Exception {
                                                                                                      // Arrange
                                                                                                      Class<?> mockInterface = mock(Class.class);
                                                                                                      when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                      when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                  
                                                                                                      // Get the private method via reflection
                                                                                                      Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                      assertInstantiableMethod.setAccessible(true);
                                                                                                      
                                                                                                      // Act
                                                                                                      // The method is static, so we can pass null as the instance
                                                                                                      assertInstantiableMethod.invoke(null, mockInterface);
                                                                                                      
                                                                                                      // Assert - Exception expected
                                                                                                      // The @Test(expected) annotation will verify the exception is thrown
                                                                                                  }

    @Test
                                                                                                  public void testAssertInstantiable_WithInterface_VerifyExceptionMessage() throws Exception {
                                                                                                      // Arrange
                                                                                                      Class<?> mockInterface = mock(Class.class);
                                                                                                      when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                      when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                                      String expectedMessage = "Interface can't be instantiated! Interface name: TestInterface";
                                                                                                  
                                                                                                      // Get the private method via reflection
                                                                                                      Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                      assertInstantiableMethod.setAccessible(true);
                                                                                                  
                                                                                                      // Act & Assert
                                                                                                      try {
                                                                                                          assertInstantiableMethod.invoke(null, mockInterface);
                                                                                                          // If we get here, the mutant survived (no exception thrown for interface)
                                                                                                          fail("Expected UnsupportedOperationException for interface");
                                                                                                      } catch (InvocationTargetException e) {
                                                                                                          // Original behavior would reach here
                                                                                                          Throwable cause = e.getCause();
                                                                                                          assertEquals(UnsupportedOperationException.class, cause.getClass());
                                                                                                          assertEquals(expectedMessage, cause.getMessage());
                                                                                                      }
                                                                                                  }

    @Test
                                                                                             public void testAssertInstantiable_Interface_ShouldThrowUnsupportedOperationException() throws Exception {
                                                                                                 // Arrange
                                                                                                 Class<?> interfaceMock = mock(Class.class);
                                                                                                 when(interfaceMock.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                 when(interfaceMock.getName()).thenReturn("TestInterface");
                                                                                                 
                                                                                                 // Get the private method via reflection
                                                                                                 Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                 assertInstantiableMethod.setAccessible(true);
                                                                                                 
                                                                                                 try {
                                                                                                     // Act
                                                                                                     assertInstantiableMethod.invoke(null, interfaceMock);
                                                                                                     // If we reach here, no exception was thrown - which is a failure
                                                                                                     fail("Expected UnsupportedOperationException for interface");
                                                                                                 } catch (InvocationTargetException e) {
                                                                                                     // Assert
                                                                                                     assertTrue(e.getCause() instanceof UnsupportedOperationException);
                                                                                                     assertEquals("Interface can't be instantiated! Interface name: TestInterface", 
                                                                                                         e.getCause().getMessage());
                                                                                                 }
                                                                                             }

    @Test
                                                                                         public void testAssertInstantiable_Interface_VerifyExceptionType() {
                                                                                             // Arrange
                                                                                             Class<?> interfaceMock = mock(Class.class);
                                                                                             when(interfaceMock.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                             when(interfaceMock.getName()).thenReturn("TestInterface");
                                                                                             
                                                                                             try {
                                                                                                 // Act
                                                                                                 Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                 assertInstantiableMethod.setAccessible(true);
                                                                                                 assertInstantiableMethod.invoke(null, interfaceMock);
                                                                                                 fail("Expected exception to be thrown");
                                                                                             } catch (Exception e) {
                                                                                                 // Assert
                                                                                                 if (e instanceof InvocationTargetException) {
                                                                                                     Throwable targetException = ((InvocationTargetException) e).getTargetException();
                                                                                                     assertEquals("Exception type should be UnsupportedOperationException", 
                                                                                                                  UnsupportedOperationException.class, targetException.getClass());
                                                                                                     assertTrue("Exception message should contain interface name", 
                                                                                                               targetException.getMessage().contains("TestInterface"));
                                                                                                 } else {
                                                                                                     fail("Expected InvocationTargetException but got " + e.getClass());
                                                                                                 }
                                                                                             }
                                                                                         }

    @Test
                                                                                    public void testAssertInstantiable_ShouldThrowExceptionForInterface2() throws Exception {
                                                                                        // Arrange
                                                                                        Class<?> mockInterface = mock(Class.class);
                                                                                        when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                        when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                        
                                                                                        // Set expectation
                                                                                        thrown.expect(UnsupportedOperationException.class);
                                                                                        thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                                                                        
                                                                                        // Get the private method via reflection
                                                                                        Class<?> allocatorClass = Class.forName("com.google.gson.internal.UnsafeAllocator");
                                                                                        Method assertInstantiableMethod = allocatorClass.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                        assertInstantiableMethod.setAccessible(true);
                                                                                        
                                                                                        // Act - This should throw the expected exception
                                                                                        assertInstantiableMethod.invoke(null, mockInterface);
                                                                                    }

    @Test
                                                                               public void testAssertInstantiableWithInterfaceShouldThrowException() throws Exception {
                                                                                   // Arrange
                                                                                   Class<?> mockInterface = mock(Class.class);
                                                                                   when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                   when(mockInterface.getName()).thenReturn("TestInterface");
                                                                                   
                                                                                   // Get the private method via reflection
                                                                                   Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                   assertInstantiableMethod.setAccessible(true);
                                                                                   
                                                                                   // Set expectation for the original behavior
                                                                                   thrown.expect(UnsupportedOperationException.class);
                                                                                   thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                                                                   
                                                                                   // Act
                                                                                   assertInstantiableMethod.invoke(null, mockInterface);
                                                                                   
                                                                                   // Assert - handled by ExpectedException rule
                                                                                   // For the mutant version, this test would fail because no exception would be thrown
                                                                                   // Instead, the mutant would just print to System.out
                                                                               }

    @Test
                                                                               public void testAssertInstantiableWithAbstractClassShouldThrowException() throws Exception {
                                                                                   // Arrange
                                                                                   Class<?> mockAbstractClass = mock(Class.class);
                                                                                   when(mockAbstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                   when(mockAbstractClass.getName()).thenReturn("TestAbstractClass");
                                                                                   
                                                                                   // Get private method via reflection
                                                                                   Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                   assertInstantiableMethod.setAccessible(true);
                                                                                   
                                                                                   // Set expectation
                                                                                   thrown.expect(UnsupportedOperationException.class);
                                                                                   thrown.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                                                                                   
                                                                                   // Act
                                                                                   assertInstantiableMethod.invoke(null, mockAbstractClass);
                                                                               }

    @Test
                                                                               public void testAssertInstantiableWithConcreteClassShouldNotThrow() throws Exception {
                                                                                   // Arrange
                                                                                   Class<?> mockConcreteClass = mock(Class.class);
                                                                                   when(mockConcreteClass.getModifiers()).thenReturn(0); // No modifiers
                                                                                   
                                                                                   // Get the private method via reflection
                                                                                   Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                   assertInstantiableMethod.setAccessible(true);
                                                                                   
                                                                                   // Act - should not throw any exception
                                                                                   assertInstantiableMethod.invoke(null, mockConcreteClass);
                                                                                   
                                                                                   // No assertion needed as we're just verifying no exception is thrown
                                                                               }

    @Test
                                                                          public void testAssertInstantiable_AbstractClass_ThrowsUnsupportedOperationException() throws Exception {
                                                                              // Arrange
                                                                              Class<?> abstractClass = mock(Class.class);
                                                                              when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                              when(abstractClass.getName()).thenReturn("TestAbstractClass");
                                                                              
                                                                              // Get the private method via reflection
                                                                              Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                              assertInstantiableMethod.setAccessible(true);
                                                                              
                                                                              // Set expectation for the original behavior
                                                                              thrown.expect(UnsupportedOperationException.class);
                                                                              thrown.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                                                                              
                                                                              // Act
                                                                              assertInstantiableMethod.invoke(null, abstractClass);
                                                                          }

    @Test
                                                                          public void testAssertInstantiable_Interface_ThrowsUnsupportedOperationException1() throws Exception {
                                                                              // Arrange
                                                                              Class<?> interfaceClass = mock(Class.class);
                                                                              when(interfaceClass.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                              when(interfaceClass.getName()).thenReturn("TestInterface");
                                                                          
                                                                              // Set expectation
                                                                              thrown.expect(UnsupportedOperationException.class);
                                                                              thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                                                          
                                                                              // Use reflection to access private method
                                                                              Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                              assertInstantiableMethod.setAccessible(true);
                                                                              
                                                                              // Act
                                                                              assertInstantiableMethod.invoke(null, interfaceClass);
                                                                          }

    @Test
                                                                          public void testAssertInstantiable_ConcreteClass_NoExceptionThrown() throws Exception {
                                                                              // Arrange
                                                                              Class<?> concreteClass = mock(Class.class);
                                                                              when(concreteClass.getModifiers()).thenReturn(0); // No modifiers (concrete class)
                                                                              
                                                                              // Get the private method via reflection
                                                                              Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                              assertInstantiableMethod.setAccessible(true);
                                                                              
                                                                              // Act (should not throw exception)
                                                                              assertInstantiableMethod.invoke(null, concreteClass);
                                                                          }

    @Test
                                                                     public void testAssertInstantiable_Interface_ShouldThrowWithCorrectMessage1() throws Exception {
                                                                         // Arrange
                                                                         Class<?> mockInterface = mock(Class.class);
                                                                         when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                         when(mockInterface.getName()).thenReturn("com.example.TestInterface");
                                                                     
                                                                         // Set expectation for the exception and its message
                                                                         thrown.expect(UnsupportedOperationException.class);
                                                                         thrown.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
                                                                     
                                                                         // Get the private method via reflection
                                                                         Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                         assertInstantiableMethod.setAccessible(true);
                                                                         
                                                                         // Act
                                                                         assertInstantiableMethod.invoke(null, mockInterface);
                                                                     }

    @Test
                                                                public void testAssertInstantiable_AbstractClass_ShouldThrowWithDescriptiveMessage() throws Exception {
                                                                    // Arrange
                                                                    Class<?> abstractClass = mock(Class.class);
                                                                    when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                    when(abstractClass.getName()).thenReturn("TestAbstractClass");
                                                                    
                                                                    // Set up expected exception
                                                                    ExpectedException expectedException = ExpectedException.none();
                                                                    expectedException.expect(UnsupportedOperationException.class);
                                                                    expectedException.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                                                                
                                                                    // Get private method via reflection
                                                                    Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                    assertInstantiable.setAccessible(true);
                                                                    
                                                                    // Act
                                                                    assertInstantiable.invoke(null, abstractClass);
                                                                }

    @Test
                                                           public void testAssertInstantiable_Interface_ShouldThrowWithSpecificMessage1() throws Exception {
                                                               // Arrange
                                                               Class<?> mockInterface = mock(Class.class);
                                                               when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                               when(mockInterface.getName()).thenReturn("com.example.TestInterface");
                                                           
                                                               // Set expectation for the exception
                                                               ExpectedException expectedException = ExpectedException.none();
                                                               expectedException.expect(UnsupportedOperationException.class);
                                                               expectedException.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
                                                           
                                                               // Use reflection to access private method
                                                               Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                               assertInstantiableMethod.setAccessible(true);
                                                           
                                                               // Act
                                                               assertInstantiableMethod.invoke(null, mockInterface);
                                                           }

    @Test
                                                      public void testAssertInstantiable_AbstractClass_OriginalErrorMessage1() throws Exception {
                                                          // Create a mock Class object for an abstract class
                                                          Class<?> abstractClass = mock(Class.class);
                                                          when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                          when(abstractClass.getName()).thenReturn("TestAbstractClass");
                                                      
                                                          // Set up expectation for the exception and its message
                                                          ExpectedException expectedException = ExpectedException.none();
                                                          expectedException.expect(UnsupportedOperationException.class);
                                                          expectedException.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                                                      
                                                          // Get the private assertInstantiable method via reflection
                                                          Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                          assertInstantiable.setAccessible(true);
                                                      
                                                          // Call the method under test
                                                          assertInstantiable.invoke(null, abstractClass);
                                                      }

    @Test
                                                 public void testAssertInstantiable_ShouldThrowForInterface2() throws Exception {
                                                     // Create a mock Class object that represents an interface
                                                     Class<?> mockInterface = mock(Class.class);
                                                     when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                     when(mockInterface.getName()).thenReturn("TestInterface");
                                                 
                                                     // Get the private assertInstantiable method via reflection
                                                     Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                     assertInstantiable.setAccessible(true);
                                                 
                                                     // Expect the exception with specific message
                                                     thrown.expect(UnsupportedOperationException.class);
                                                     thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                                 
                                                     // Call the method using reflection
                                                     assertInstantiable.invoke(null, mockInterface);
                                                 }

    @Test(expected = UnsupportedOperationException.class)
                                            public void testAssertInstantiable_WithInterface_ShouldThrowException1() throws Exception {
                                                // Arrange
                                                Class<?> mockInterface = mock(Class.class);
                                                when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                when(mockInterface.getName()).thenReturn("TestInterface");
                                                
                                                // Get the private assertInstantiable method via reflection
                                                Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                assertInstantiableMethod.setAccessible(true);
                                                
                                                // Act
                                                assertInstantiableMethod.invoke(null, mockInterface);
                                            }

    @Test
                                            public void testAssertInstantiable_WithInterface_ShouldThrowCorrectExceptionMessage() {
                                                // Arrange
                                                Class<?> mockInterface = mock(Class.class);
                                                when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                when(mockInterface.getName()).thenReturn("TestInterface");
                                                
                                                try {
                                                    // Get the private method via reflection
                                                    Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                    assertInstantiable.setAccessible(true);
                                                    
                                                    // Act
                                                    assertInstantiable.invoke(null, mockInterface);
                                                    fail("Expected UnsupportedOperationException");
                                                } catch (NoSuchMethodException | IllegalAccessException e) {
                                                    fail("Reflection failed: " + e.getMessage());
                                                } catch (InvocationTargetException e) {
                                                    // Assert
                                                    assertEquals("Interface can't be instantiated! Interface name: TestInterface", 
                                                        ((UnsupportedOperationException)e.getTargetException()).getMessage());
                                                }
                                            }

    @Test
                                       public void testAssertInstantiable_Interface_ThrowsUnsupportedOperationException2() throws Exception {
                                           // Arrange
                                           Class<?> mockInterface = mock(Class.class);
                                           when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                           when(mockInterface.getName()).thenReturn("TestInterface");
                                       
                                           // Get the private method via reflection
                                           Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                           assertInstantiableMethod.setAccessible(true);
                                       
                                           // Expect specific exception type (original behavior)
                                           thrown.expect(UnsupportedOperationException.class);
                                           thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                       
                                           // Act
                                           assertInstantiableMethod.invoke(null, mockInterface);
                                       }

    @Test
                                  public void testAssertInstantiable_ShouldThrowExceptionForInterface3() throws Exception {
                                      // Arrange
                                      Class<?> mockInterface = mock(Class.class);
                                      when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                      when(mockInterface.getName()).thenReturn("TestInterface");
                                      
                                      // Set expectation
                                      thrown.expect(UnsupportedOperationException.class);
                                      thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                                  
                                      // Get private method via reflection
                                      Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                      assertInstantiable.setAccessible(true);
                                      
                                      // Act
                                      assertInstantiable.invoke(null, mockInterface);
                                      
                                      // Assert - handled by ExpectedException rule
                                  }

    @Test
                             public void testAssertInstantiable_ShouldThrowExceptionForInterface4() throws Exception {
                                 // Arrange
                                 Class<?> mockInterface = mock(Class.class);
                                 when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                 when(mockInterface.getName()).thenReturn("TestInterface");
                             
                                 // Get the private method via reflection
                                 Method assertInstantiable = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                 assertInstantiable.setAccessible(true);
                             
                                 // Set expectation for the exception
                                 thrown.expect(UnsupportedOperationException.class);
                                 thrown.expectMessage("Interface can't be instantiated! Interface name: TestInterface");
                             
                                 // Act
                                 assertInstantiable.invoke(null, mockInterface);
                             }

    @Test
                        public void testAssertInstantiable_AbstractClass_ThrowsUnsupportedOperationException1() throws Exception {
                            // Arrange
                            abstract class AbstractTestClass {}
                            Class<?> abstractClass = AbstractTestClass.class;
                            
                            // Get private method via reflection
                            Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                            assertInstantiableMethod.setAccessible(true);
                            
                            // Expect specific exception type and message
                            thrown.expect(UnsupportedOperationException.class);
                            thrown.expectMessage("Abstract class can't be instantiated! Class name: " + abstractClass.getName());
                            
                            // Act
                            assertInstantiableMethod.invoke(null, abstractClass);
                        }

    @Test
                   public void testAssertInstantiable_Interface_ShouldThrowWithDescriptiveMessage() throws Exception {
                       // Arrange
                       Class<?> mockInterface = mock(Class.class);
                       when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                       when(mockInterface.getName()).thenReturn("com.example.TestInterface");
                   
                       // Get the private method via reflection
                       Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                       assertInstantiableMethod.setAccessible(true);
                   
                       // Set expectation for the exception
                       thrown.expect(UnsupportedOperationException.class);
                       thrown.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
                   
                       // Act
                       assertInstantiableMethod.invoke(null, mockInterface);
                   }

    @Test
              public void testAssertInstantiable_AbstractClass_ShouldThrowWithSpecificMessage() throws Exception {
                  // Arrange
                  Class<?> abstractClass = mock(Class.class);
                  when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                  when(abstractClass.getName()).thenReturn("TestAbstractClass");
                  
                  // Get the private method via reflection
                  Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                  assertInstantiableMethod.setAccessible(true);
                  
                  // Set expectation for exception and its message
                  thrown.expect(UnsupportedOperationException.class);
                  thrown.expectMessage("Abstract class can't be instantiated! Class name: TestAbstractClass");
                  
                  // Act
                  assertInstantiableMethod.invoke(null, abstractClass);
              }

    @Test
         public void testAssertInstantiable_Interface_ShouldThrowWithSpecificMessage2() throws Exception {
             // Arrange
             Class<?> mockInterface = mock(Class.class);
             when(mockInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
             when(mockInterface.getName()).thenReturn("com.example.TestInterface");
         
             // Set expectation for the exception and its message
             thrown.expect(UnsupportedOperationException.class);
             thrown.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
         
             // Get the private method via reflection
             Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
             assertInstantiableMethod.setAccessible(true);
             
             // Act
             assertInstantiableMethod.invoke(null, mockInterface);
         }

    @Test
    public void testAssertInstantiable_AbstractClass_OriginalErrorMessage2() throws Exception {
        // Create a mock Class object for an abstract class
        Class<?> abstractClass = mock(Class.class);
        when(abstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
        when(abstractClass.getName()).thenReturn("TestAbstractClass");
    
        // Get the private assertInstantiable method via reflection
        Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
        assertInstantiableMethod.setAccessible(true);
    
        // Set up expectation for the exception and its message
        try {
            assertInstantiableMethod.invoke(null, abstractClass);
            fail("Expected UnsupportedOperationException");
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            assertEquals(UnsupportedOperationException.class, cause.getClass());
            assertEquals("Abstract class can't be instantiated! Class name: TestAbstractClass", cause.getMessage());
        }
    }


}
