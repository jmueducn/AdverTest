package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
 
public class TypeAdaptersTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                                                                                                 public void testNewTypeHierarchyFactory_ReturnsNullForNonAssignableType() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     Class<Number> clazz = Number.class;
                                                                                                                                                                     TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                                                                                                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                                                                             
                                                                                                                                                                     // Test with String which is not assignable from Number
                                                                                                                                                                     TypeAdapter<String> result = factory.create(mock(Gson.class), new TypeToken<String>() {});
                                                                                                                                                             
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertNull(result);
                                                                                                                                                                 }

 @Test
                                                                                                                                                                 public void testNewTypeHierarchyFactory_ToStringReturnsExpectedFormat() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     Class<String> clazz = String.class;
                                                                                                                                                                     TypeAdapter<String> typeAdapter = mock(TypeAdapter.class);
                                                                                                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                                                                             
                                                                                                                                                                     // Test
                                                                                                                                                                     String result = factory.toString();
                                                                                                                                                             
                                                                                                                                                                     // Verify
                                                                                                                                                                     assertTrue(result.startsWith("Factory[typeHierarchy=java.lang.String,adapter="));
                                                                                                                                                                     assertTrue(result.contains("Mock"));
                                                                                                                                                                 }

 @Test
                                                                                                                                                         public void testRead_ValidString_ReturnsMappedConstant() throws Exception {
                                                                                                                                                             // Arrange
                                                                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                             when(mockReader.nextString()).thenReturn("TEST_VALUE");
                                                                                                                                                             
                                                                                                                                                             Map<String, String> nameToConstant = new HashMap<>();
                                                                                                                                                             nameToConstant.put("TEST_VALUE", "RESULT");
                                                                                                                                                             
                                                                                                                                                             TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                 @Override
                                                                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                         in.nextNull();
                                                                                                                                                                         return null;
                                                                                                                                                                     }
                                                                                                                                                                     return nameToConstant.get(in.nextString());
                                                                                                                                                                 }
                                                                                                                                                                 
                                                                                                                                                                 @Override
                                                                                                                                                                 public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                     throw new UnsupportedOperationException();
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Act
                                                                                                                                                             String result = adapter.read(mockReader);
                                                                                                                                                             
                                                                                                                                                             // Assert
                                                                                                                                                             assertEquals("RESULT", result);
                                                                                                                                                             verify(mockReader).nextString();
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_UnknownString_ReturnsNull() throws Exception {
                                                                                                                                                             // Arrange
                                                                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                             when(mockReader.nextString()).thenReturn("UNKNOWN_VALUE");
                                                                                                                                                             
                                                                                                                                                             Map<String, String> nameToConstant = new HashMap<>();
                                                                                                                                                             nameToConstant.put("KNOWN_VALUE", "RESULT");
                                                                                                                                                             
                                                                                                                                                             // Create a TypeAdapter that uses our nameToConstant map
                                                                                                                                                             TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                 @Override
                                                                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                         in.nextNull();
                                                                                                                                                                         return null;
                                                                                                                                                                     }
                                                                                                                                                                     return nameToConstant.get(in.nextString());
                                                                                                                                                                 }
                                                                                                                                                         
                                                                                                                                                                 @Override
                                                                                                                                                                 public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                     throw new UnsupportedOperationException();
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Act
                                                                                                                                                             String result = adapter.read(mockReader);
                                                                                                                                                             
                                                                                                                                                             // Assert
                                                                                                                                                             assertNull(result);
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testRead_InvalidTokenType_ThrowsException() throws Exception {
                                                                                                                                                             // Arrange
                                                                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.BEGIN_ARRAY);
                                                                                                                                                             
                                                                                                                                                             // Create a simple TypeAdapter implementation for testing
                                                                                                                                                             TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                 @Override
                                                                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                         in.nextNull();
                                                                                                                                                                         return null;
                                                                                                                                                                     }
                                                                                                                                                                     return in.nextString();
                                                                                                                                                                 }
                                                                                                                                                         
                                                                                                                                                                 @Override
                                                                                                                                                                 public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                     out.value(value);
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Expect exception
                                                                                                                                                             thrown.expect(IllegalStateException.class);
                                                                                                                                                             thrown.expectMessage("Expected STRING or NULL");
                                                                                                                                                             
                                                                                                                                                             // Act
                                                                                                                                                             adapter.read(mockReader);
                                                                                                                                                         }

 @Test
                                                                                                                                                         public void testWrite_ValidValueInMap() throws IOException {
                                                                                                                                                             // Create mock JsonWriter
                                                                                                                                                             JsonWriter jsonWriter = mock(JsonWriter.class);
                                                                                                                                                             
                                                                                                                                                             // Create TypeAdapter instance with constantToName map
                                                                                                                                                             Map<String, String> constantToName = new HashMap<>();
                                                                                                                                                             constantToName.put("test_value", "TEST");
                                                                                                                                                             
                                                                                                                                                             // Create anonymous subclass of TypeAdapter for testing
                                                                                                                                                             TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                                                                 @Override
                                                                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                                                                     return null;
                                                                                                                                                                 }
                                                                                                                                                                 
                                                                                                                                                                 @Override
                                                                                                                                                                 public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                     out.value(value == null ? null : constantToName.get(value));
                                                                                                                                                                 }
                                                                                                                                                             };
                                                                                                                                                             
                                                                                                                                                             // Test the write method
                                                                                                                                                             typeAdapters.write(jsonWriter, "test_value");
                                                                                                                                                             
                                                                                                                                                             // Verify the expected value was written
                                                                                                                                                             verify(jsonWriter).value("TEST");
                                                                                                                                                         }

 @Test
                                                                                                                                                     public void testWrite_ValidValueNotInMap() throws IOException {
                                                                                                                                                         // Create mock JsonWriter
                                                                                                                                                         JsonWriter jsonWriter = mock(JsonWriter.class);
                                                                                                                                                         
                                                                                                                                                         // Create a proper TypeAdapter implementation
                                                                                                                                                         TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
                                                                                                                                                             @Override
                                                                                                                                                             public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                 out.value(value == null ? null : value);
                                                                                                                                                             }
                                                                                                                                                             
                                                                                                                                                             @Override
                                                                                                                                                             public String read(JsonReader in) throws IOException {
                                                                                                                                                                 return null;
                                                                                                                                                             }
                                                                                                                                                         };
                                                                                                                                                         
                                                                                                                                                         // Execute test
                                                                                                                                                         typeAdapter.write(jsonWriter, "non_existent_value");
                                                                                                                                                         
                                                                                                                                                         // Verify
                                                                                                                                                         verify(jsonWriter).value("non_existent_value");
                                                                                                                                                     }

 @Test
                                                                                                                                                     public void testWrite_IOException() throws IOException {
                                                                                                                                                         // Setup
                                                                                                                                                         JsonWriter jsonWriter = mock(JsonWriter.class);
                                                                                                                                                         TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
                                                                                                                                                             @Override
                                                                                                                                                             public String read(JsonReader in) throws IOException {
                                                                                                                                                                 return null;
                                                                                                                                                             }
                                                                                                                                                             @Override
                                                                                                                                                             public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                 out.value(value);
                                                                                                                                                             }
                                                                                                                                                         };
                                                                                                                                                         
                                                                                                                                                         String testValue = "test_value";
                                                                                                                                                         doThrow(new IOException("Test exception")).when(jsonWriter).value(eq(testValue));
                                                                                                                                                         
                                                                                                                                                         // Expected exception
                                                                                                                                                         ExpectedException thrown = ExpectedException.none();
                                                                                                                                                         thrown.expect(IOException.class);
                                                                                                                                                         thrown.expectMessage("Test exception");
                                                                                                                                                         
                                                                                                                                                         // Test
                                                                                                                                                         typeAdapter.write(jsonWriter, testValue);
                                                                                                                                                     }

 @Test
                                                                                                                                     public void testWrite_EmptyMaps() throws IOException {
                                                                                                                                         // Create mock JsonWriter
                                                                                                                                         JsonWriter jsonWriter = mock(JsonWriter.class);
                                                                                                                                         
                                                                                                                                         // Create mock TypeAdapter for String
                                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                                         TypeAdapter<String> stringAdapter = mock(TypeAdapter.class);
                                                                                                                                         
                                                                                                                                         // Create empty maps with proper generic types
                                                                                                                                         Map<TypeToken<?>, TypeAdapter<?>> typeTokenCache = new HashMap<>();
                                                                                                                                         Map<Class<?>, TypeAdapter<?>> classCache = new HashMap<>();
                                                                                                                                         
                                                                                                                                         // Put the string adapter in both caches
                                                                                                                                         TypeToken<String> stringType = TypeToken.get(String.class);
                                                                                                                                         typeTokenCache.put(stringType, stringAdapter);
                                                                                                                                         classCache.put(String.class, stringAdapter);
                                                                                                                                         
                                                                                                                                         // Create adapter factory through reflection
                                                                                                                                         try {
                                                                                                                                             Constructor<TypeAdapters> constructor = 
                                                                                                                                                 TypeAdapters.class.getDeclaredConstructor(Map.class, Map.class);
                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                             TypeAdapters adapters = constructor.newInstance(typeTokenCache, classCache);
                                                                                                                                             
                                                                                                                                             // Create factory and get adapter
                                                                                                                                             TypeAdapterFactory factory = TypeAdapters.newFactory(String.class, stringAdapter);
                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                             TypeAdapter<String> adapter = (TypeAdapter<String>) factory.create(null, TypeToken.get(String.class));
                                                                                                                                             
                                                                                                                                             // Test writing a String value
                                                                                                                                             String testValue = "test_value";
                                                                                                                                             adapter.write(jsonWriter, testValue);
                                                                                                                                             
                                                                                                                                             // Verify the adapter was called with our test value
                                                                                                                                             verify(stringAdapter).write(jsonWriter, testValue);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             throw new RuntimeException("Failed to create TypeAdapters instance", e);
                                                                                                                                         }
                                                                                                                                     }

 @Test
                                                                                                                             public void testRead_EmptyMap_ReturnsNullForAnyString() throws Exception {
                                                                                                                                 // Arrange
                                                                                                                                 JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                 when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                 when(mockReader.nextString()).thenReturn("ANY_VALUE");
                                                                                                                                 
                                                                                                                                 // Create a TypeAdapter that uses an empty map for nameToConstant
                                                                                                                                 TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                     private final Map<String, String> nameToConstant = new HashMap<String, String>();
                                                                                                                                     
                                                                                                                                     @Override
                                                                                                                                     public String read(JsonReader in) throws IOException {
                                                                                                                                         if (in.peek() == JsonToken.NULL) {
                                                                                                                                             in.nextNull();
                                                                                                                                             return null;
                                                                                                                                         }
                                                                                                                                         return nameToConstant.get(in.nextString());
                                                                                                                                     }
                                                                                                                                     
                                                                                                                                     @Override
                                                                                                                                     public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                         throw new UnsupportedOperationException();
                                                                                                                                     }
                                                                                                                                 };
                                                                                                                                 
                                                                                                                                 // Act
                                                                                                                                 String result = adapter.read(mockReader);
                                                                                                                                 
                                                                                                                                 // Assert
                                                                                                                                 assertNull(result);
                                                                                                                             }

 @Test
                                                                                                                     public void testNewTypeHierarchyFactory_WorksWithCustomTypes() throws IOException {
                                                                                                                         // Setup custom type hierarchy
                                                                                                                         class Parent {}
                                                                                                                         class Child extends Parent {}
                                                                                                                         
                                                                                                                         // Create mocks and test objects
                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                         TypeAdapter<Parent> typeAdapter = mock(TypeAdapter.class);
                                                                                                                         Child child = new Child();
                                                                                                                         when(typeAdapter.read(any(JsonReader.class))).thenReturn(child);
                                                                                                                         
                                                                                                                         // Create factory and get adapter
                                                                                                                         TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(Parent.class, typeAdapter);
                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                         TypeAdapter<Parent> adapter = (TypeAdapter<Parent>) factory.create(mock(Gson.class), TypeToken.get(Parent.class));
                                                                                                                         
                                                                                                                         // Test read
                                                                                                                         JsonReader reader = new JsonReader(new java.io.StringReader("{}"));
                                                                                                                         Parent result = adapter.read(reader);
                                                                                                                         
                                                                                                                         // Verify
                                                                                                                         assertSame(child, result);
                                                                                                                     }

 @Test
                                                                                                                 public void testNewTypeHierarchyFactory_ReadsValueOfCorrectType() throws IOException {
                                                                                                                     // Setup
                                                                                                                     Class<Number> clazz = Number.class;
                                                                                                                     Number expectedValue = 42;
                                                                                                                     
                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                     TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                                                                                                                     JsonReader reader = mock(JsonReader.class);
                                                                                                                     when(typeAdapter.read(any(JsonReader.class))).thenReturn(expectedValue);
                                                                                                                     
                                                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                                     
                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                     TypeAdapter<Number> adapter = factory.create(mock(Gson.class), TypeToken.get(Number.class));
                                                                                                                     
                                                                                                                     // Test read
                                                                                                                     Number result = adapter.read(reader);
                                                                                                                     
                                                                                                                     // Verify
                                                                                                                     assertEquals(expectedValue, result);
                                                                                                                     verify(typeAdapter).read(reader);
                                                                                                                 }

 @Test
                                                                                                                 public void testNewTypeHierarchyFactory_ThrowsExceptionForWrongInstanceType() throws IOException {
                                                                                                                     // Setup
                                                                                                                     Class<List> clazz = List.class;
                                                                                                                     ArrayList<String> arrayList = new ArrayList<>();
                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                     TypeAdapter<List> typeAdapter = mock(TypeAdapter.class);
                                                                                                                     JsonReader jsonReader = mock(JsonReader.class);
                                                                                                                     when(typeAdapter.read(any(JsonReader.class))).thenReturn(arrayList);
                                                                                                                     
                                                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                                     
                                                                                                                     // First create an adapter for ArrayList (should work)
                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                     TypeAdapter<ArrayList> adapter = factory.create(mock(Gson.class), new TypeToken<ArrayList>() {});
                                                                                                                     
                                                                                                                     // Test with incompatible type
                                                                                                                     try {
                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                         TypeAdapter<String> wrongAdapter = factory.create(mock(Gson.class), new TypeToken<String>() {});
                                                                                                                         wrongAdapter.read(jsonReader);
                                                                                                                         fail("Expected JsonSyntaxException");
                                                                                                                     } catch (JsonSyntaxException e) {
                                                                                                                         assertTrue(e.getMessage().contains("Expected a java.lang.String but was java.util.ArrayList"));
                                                                                                                     }
                                                                                                                 }

 @Test
                                                                                                                 public void testNewTypeHierarchyFactory_HandlesNullValueDuringRead() throws IOException {
                                                                                                                     // Setup
                                                                                                                     Class<Object> clazz = Object.class;
                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                     TypeAdapter<Object> typeAdapter = mock(TypeAdapter.class);
                                                                                                                     JsonReader reader = mock(JsonReader.class);
                                                                                                                     when(typeAdapter.read(any(JsonReader.class))).thenReturn(null);
                                                                                                                     
                                                                                                                     // Create factory using static method
                                                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                                     @SuppressWarnings("unchecked")
                                                                                                                     TypeAdapter<Object> adapter = factory.create(mock(Gson.class), new TypeToken<Object>() {});
                                                                                                                     
                                                                                                                     // Test read with null
                                                                                                                     Object result = adapter.read(reader);
                                                                                                                     
                                                                                                                     // Verify
                                                                                                                     assertNull(result);
                                                                                                                     verify(typeAdapter).read(reader);
                                                                                                                 }

 @Test
                                                                                                             public void testNewTypeHierarchyFactory_CreatesAdapterForAssignableType() throws IOException {
                                                                                                                 // Setup
                                                                                                                 Class<Number> clazz = Number.class;
                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                 TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                                                                                                                 TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                                 JsonWriter writer = mock(JsonWriter.class);
                                                                                                                 
                                                                                                                 // Test with Integer which is assignable from Number
                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                 TypeAdapter<Integer> result = factory.create(mock(Gson.class), new TypeToken<Integer>() {});
                                                                                                                 
                                                                                                                 // Verify adapter was created
                                                                                                                 assertNotNull(result);
                                                                                                                 
                                                                                                                 // Test write delegation
                                                                                                                 Integer value = 42;  // Changed from Number to Integer to match the adapter type
                                                                                                                 result.write(writer, value);
                                                                                                                 verify(typeAdapter).write(writer, value);
                                                                                                             }

 @Test
                                                                                                         public void testRead_NullToken_ReturnsNull() throws Exception {
                                                                                                             // Arrange
                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.NULL);
                                                                                                             
                                                                                                             // Create a simple TypeAdapters instance for String type
                                                                                                             Map<String, String> nameToConstant = new HashMap<>();
                                                                                                             TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                 @Override
                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                                                         in.nextNull();
                                                                                                                         return null;
                                                                                                                     }
                                                                                                                     return nameToConstant.get(in.nextString());
                                                                                                                 }
                                                                                                                 
                                                                                                                 @Override
                                                                                                                 public void write(JsonWriter out, String value) {
                                                                                                                     throw new UnsupportedOperationException();
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             // Act
                                                                                                             String result = adapter.read(mockReader);
                                                                                                             
                                                                                                             // Assert
                                                                                                             assertNull(result);
                                                                                                             verify(mockReader).nextNull();
                                                                                                         }

 @Test
                                                                                                         public void testWrite_NullValue() throws IOException {
                                                                                                             JsonWriter jsonWriter = mock(JsonWriter.class);
                                                                                                             TypeAdapter<Object> typeAdapter = new TypeAdapter<Object>() {
                                                                                                                 @Override
                                                                                                                 public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                     out.value(value == null ? (String) null : "someValue");
                                                                                                                 }
                                                                                                         
                                                                                                                 @Override
                                                                                                                 public Object read(JsonReader in) {
                                                                                                                     return null;
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             typeAdapter.write(jsonWriter, null);
                                                                                                             verify(jsonWriter).value((String) null);
                                                                                                         }

 @Test
                                                                                                     public void testNewTypeHierarchyFactoryTypeChecking() {
                                                                                                         // Create test types
                                                                                                         Class<Number> clazz = Number.class;
                                                                                                         Class<Integer> compatibleType = Integer.class; // Integer is assignable to Number
                                                                                                         Class<String> incompatibleType = String.class; // String is not assignable to Number
                                                                                                         
                                                                                                         // Mock the type adapter
                                                                                                         TypeAdapter<Number> mockAdapter = mock(TypeAdapter.class);
                                                                                                         
                                                                                                         // Create the factory
                                                                                                         TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockAdapter);
                                                                                                         
                                                                                                         // Test with compatible type - should return adapter (null for mutant)
                                                                                                         TypeAdapter<?> compatibleResult = factory.create(new Gson(), TypeToken.get(compatibleType));
                                                                                                         assertNotNull("Should return adapter for compatible type", compatibleResult);
                                                                                                         
                                                                                                         // Test with incompatible type - should return null (adapter for mutant)
                                                                                                         TypeAdapter<?> incompatibleResult = factory.create(new Gson(), TypeToken.get(incompatibleType));
                                                                                                         assertNull("Should return null for incompatible type", incompatibleResult);
                                                                                                         
                                                                                                         // Test with same type - should return adapter (null for mutant)
                                                                                                         TypeAdapter<?> sameTypeResult = factory.create(new Gson(), TypeToken.get(clazz));
                                                                                                         assertNotNull("Should return adapter for same type", sameTypeResult);
                                                                                                     }

 @Test
                                                                                                    public void testNewTypeHierarchyFactoryWithIncompatibleTypes() {
                                                                                                        // Create test classes to establish a clear hierarchy
                                                                                                        class Parent {}
                                                                                                        class Child extends Parent {}
                                                                                                        
                                                                                                        // Mock the TypeAdapter
                                                                                                        TypeAdapter<Parent> parentAdapter = mock(TypeAdapter.class);
                                                                                                        
                                                                                                        // Create the factory with Parent as the base class
                                                                                                        TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(
                                                                                                            Parent.class, parentAdapter);
                                                                                                        
                                                                                                        // Test with Parent type token - should return adapter (compatible)
                                                                                                        TypeAdapter<Parent> parentResult = factory.create(new Gson(), TypeToken.get(Parent.class));
                                                                                                        assertNotNull(parentResult);
                                                                                                        
                                                                                                        // Test with Child type token - should return adapter (Child is assignable to Parent)
                                                                                                        TypeAdapter<Child> childResult = factory.create(new Gson(), TypeToken.get(Child.class));
                                                                                                        assertNotNull(childResult);
                                                                                                        
                                                                                                        // Test with incompatible type (String) - should return null
                                                                                                        // This is where the mutant would fail - the mutated version would incorrectly return an adapter
                                                                                                        TypeAdapter<String> stringResult = factory.create(new Gson(), TypeToken.get(String.class));
                                                                                                        assertNull("Should return null for incompatible types", stringResult);
                                                                                                        
                                                                                                        // Test with reverse hierarchy - Object is superclass of Parent
                                                                                                        // Original would return null (Parent not assignable to Object in this direction)
                                                                                                        // Mutant would incorrectly return an adapter
                                                                                                        TypeAdapter<Object> objectResult = factory.create(new Gson(), TypeToken.get(Object.class));
                                                                                                        assertNull("Should return null when checking superclass relationship", objectResult);
                                                                                                    }

 @Test
                                                                                                  public void testNewTypeHierarchyFactoryWithIncompatibleTypes1() {
                                                                                                      // Setup
                                                                                                      Class<String> clazz = String.class;  // Our base class
                                                                                                      TypeAdapter<String> typeAdapter = mock(TypeAdapter.class);
                                                                                                      
                                                                                                      // Create factory with String class
                                                                                                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                      
                                                                                                      // Create a TypeToken for an incompatible type (e.g., Integer)
                                                                                                      TypeToken<Integer> incompatibleTypeToken = TypeToken.get(Integer.class);
                                                                                                      
                                                                                                      // Test
                                                                                                      TypeAdapter<Integer> result = factory.create(mock(Gson.class), incompatibleTypeToken);
                                                                                                      
                                                                                                      // Verify
                                                                                                      assertNull("Should return null for incompatible types", result);
                                                                                                      
                                                                                                      // Additional verification that we didn't try to use the typeAdapter
                                                                                                      verifyNoInteractions(typeAdapter);
                                                                                                  }

 @Test
                                                                                              public void testNewTypeHierarchyFactory_ReturnsNullWhenTypesNotAssignable() {
                                                                                                  // Setup
                                                                                                  Class<Number> clazz = Number.class;
                                                                                                  TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                                                                                                  
                                                                                                  // Create the factory
                                                                                                  TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                  
                                                                                                  // Test with a non-assignable type (String is not a Number)
                                                                                                  TypeToken<String> stringTypeToken = TypeToken.get(String.class);
                                                                                                  Gson gson = new Gson();
                                                                                                  
                                                                                                  // Exercise and verify
                                                                                                  TypeAdapter<String> result = factory.create(gson, stringTypeToken);
                                                                                                  
                                                                                                  // Original behavior should return null, mutant would return typeAdapter
                                                                                                  assertNull("Should return null when types are not assignable", result);
                                                                                                  
                                                                                                  // Additional verification that we didn't proceed with the wrong type
                                                                                                  verifyNoInteractions(typeAdapter);
                                                                                              }

 @Test
                                                                                                 public void testNewTypeHierarchyFactory_WhenTypeNotAssignable_ShouldReturnNull() {
                                                                                                     // Setup
                                                                                                     Class<String> clazz = String.class;
                                                                                                     TypeAdapter<String> typeAdapter = mock(TypeAdapter.class);
                                                                                                     
                                                                                                     // Create the factory
                                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                                                                                     
                                                                                                     // Create test scenario where requested type is not assignable
                                                                                                     Gson gson = new Gson();
                                                                                                     TypeToken<Integer> typeToken = TypeToken.get(Integer.class); // Integer is not assignable from String
                                                                                                     
                                                                                                     // Test behavior - should return null for original, throw exception for mutant
                                                                                                     TypeAdapter<Integer> result = factory.create(gson, typeToken);
                                                                                                     
                                                                                                     // Assertion - original should return null
                                                                                                     assertNull(result);
                                                                                                     
                                                                                                     // For mutant detection, uncomment below and comment above assertion
                                                                                                     // thrown.expect(RuntimeException.class);
                                                                                                     // factory.create(gson, typeToken);
                                                                                                 }

 @Test
                                                                                            public void testWriteDelegatesToTypeAdapter() throws IOException {
                                                                                                // Setup test data and mocks
                                                                                                Class<Object> testClass = Object.class;
                                                                                                TypeAdapter<Object> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                                JsonWriter mockWriter = mock(JsonWriter.class);
                                                                                                Object testValue = new Object();
                                                                                                
                                                                                                // Create the factory and adapter
                                                                                                TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(testClass, mockTypeAdapter);
                                                                                                TypeAdapter<Object> adapter = factory.create(new Gson(), TypeToken.get(testClass));
                                                                                                
                                                                                                // Execute the write operation
                                                                                                adapter.write(mockWriter, testValue);
                                                                                                
                                                                                                // Verify the typeAdapter.write was called
                                                                                                verify(mockTypeAdapter).write(mockWriter, testValue);
                                                                                                
                                                                                                // Additional verification that the writer was used
                                                                                                verify(mockWriter).beginObject();
                                                                                                verify(mockWriter).endObject();
                                                                                            }

 @Test
                                                                                           public void testTypeHierarchyFactoryWriteOperation() throws IOException {
                                                                                               // Setup test data and mocks
                                                                                               Class<Object> testClass = Object.class;
                                                                                               Object testValue = new Object();
                                                                                               
                                                                                               // Mock the dependencies
                                                                                               TypeAdapter<Object> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                               JsonWriter mockWriter = mock(JsonWriter.class);
                                                                                               
                                                                                               // Create the factory and adapter
                                                                                               TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(testClass, mockTypeAdapter);
                                                                                               TypeAdapter<Object> adapter = factory.create(new Gson(), TypeToken.get(testClass));
                                                                                               
                                                                                               // Execute the write operation
                                                                                               adapter.write(mockWriter, testValue);
                                                                                               
                                                                                               // Verify the behavior - this will catch the mutant
                                                                                               verify(mockTypeAdapter).write(mockWriter, testValue);
                                                                                               verify(mockWriter, never()).nullValue();
                                                                                               
                                                                                               // Additional verification that no unexpected interactions occurred
                                                                                               verifyNoMoreInteractions(mockTypeAdapter, mockWriter);
                                                                                           }

 @Test
                                                                                     public void testTypeHierarchyFactoryWriteUsesTypeAdapter() throws IOException {
                                                                                         // Define a simple test class
                                                                                         class TestClass {
                                                                                             private String value;
                                                                                             public TestClass(String value) {
                                                                                                 this.value = value;
                                                                                             }
                                                                                             @Override
                                                                                             public String toString() {
                                                                                                 return value;
                                                                                             }
                                                                                         }
                                                                                         
                                                                                         // Setup test objects
                                                                                         Class<TestClass> clazz = TestClass.class;
                                                                                         TypeAdapter<TestClass> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                         TestClass testValue = new TestClass("test value");
                                                                                         
                                                                                         // Mock the expected behavior
                                                                                         JsonWriter mockWriter = mock(JsonWriter.class);
                                                                                         doAnswer(invocation -> {
                                                                                             JsonWriter writer = invocation.getArgument(0);
                                                                                             TestClass value = invocation.getArgument(1);
                                                                                             writer.value(value.toString());
                                                                                             return null;
                                                                                         }).when(mockTypeAdapter).write(mockWriter, testValue);
                                                                                         
                                                                                         // Create the factory and adapter
                                                                                         TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                                         TypeAdapter<TestClass> adapter = factory.create(new Gson(), TypeToken.get(clazz));
                                                                                         
                                                                                         // Execute
                                                                                         adapter.write(mockWriter, testValue);
                                                                                         
                                                                                         // Verify the correct write method was called
                                                                                         verify(mockTypeAdapter).write(mockWriter, testValue);
                                                                                         verify(mockWriter, never()).value(testValue.toString());
                                                                                     }

 @Test
                                                                                 public void testReadReturnsActualValueFromTypeAdapter() throws IOException {
                                                                                     // Setup test data
                                                                                     Class<Object> testClass = Object.class;
                                                                                     Object expectedValue = new Object();
                                                                                     
                                                                                     // Mock dependencies
                                                                                     TypeAdapter<Object> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                     JsonReader mockJsonReader = mock(JsonReader.class);
                                                                                     
                                                                                     // Configure mocks
                                                                                     when(mockTypeAdapter.read(mockJsonReader)).thenReturn(expectedValue);
                                                                                     
                                                                                     // Create factory and adapter
                                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(testClass, mockTypeAdapter);
                                                                                     TypeAdapter<Object> adapter = factory.create(new Gson(), TypeToken.get(testClass));
                                                                                     
                                                                                     // Execute test
                                                                                     Object result = adapter.read(mockJsonReader);
                                                                                     
                                                                                     // Verify results
                                                                                     assertNotNull("Adapter should return non-null value from typeAdapter", result);
                                                                                     assertEquals("Adapter should return value from typeAdapter", expectedValue, result);
                                                                                     
                                                                                     // Verify interactions
                                                                                     verify(mockTypeAdapter).read(mockJsonReader);
                                                                                 }

 @Test
                                                                                public void testReadWithNullResultShouldNotThrowException() throws IOException {
                                                                                    // Setup
                                                                                    Class<Number> clazz = Number.class;
                                                                                    TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                    when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(null);
                                                                                    
                                                                                    TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                                    TypeAdapter<Number> adapter = factory.create(new Gson(), TypeToken.get(Number.class));
                                                                                    
                                                                                    JsonReader reader = mock(JsonReader.class);
                                                                                    
                                                                                    // Test - should not throw exception for null result
                                                                                    Number result = adapter.read(reader);
                                                                                    
                                                                                    // Verify
                                                                                    assertNull(result);
                                                                                    verify(mockTypeAdapter).read(reader);
                                                                                    
                                                                                    // Additional verification that no exception was thrown
                                                                                    // (implicit in the fact we got here without exceptions)
                                                                                }

 @Test
                                                                               public void testRead_WithNullValue_ReturnsNull() throws IOException {
                                                                                   // Setup
                                                                                   Class<Number> clazz = Number.class;
                                                                                   TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                   
                                                                                   when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(null);
                                                                                   
                                                                                   TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                                   TypeAdapter<Number> adapter = factory.create(new Gson(), TypeToken.get(Number.class));
                                                                                   
                                                                                   JsonReader reader = mock(JsonReader.class);
                                                                                   
                                                                                   // Test & Verify
                                                                                   assertNull(adapter.read(reader));
                                                                               }

 @Test
                                                                               public void testRead_WithValidType_ReturnsValue() throws IOException {
                                                                                   // Setup
                                                                                   Class<Number> clazz = Number.class;
                                                                                   TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                                                   Integer testValue = 42;
                                                                                   
                                                                                   when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(testValue);
                                                                                   
                                                                                   TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                                   TypeAdapter<Number> adapter = factory.create(new Gson(), TypeToken.get(Number.class));
                                                                                   
                                                                                   JsonReader reader = mock(JsonReader.class);
                                                                                   
                                                                                   // Test & Verify
                                                                                   assertEquals(testValue, adapter.read(reader));
                                                                               }

 @Test
                                                                      public void testRead_WithNonMatchingType_ThrowsJsonSyntaxException() throws IOException {
                                                                          // Setup
                                                                          Class<Number> clazz = Number.class;
                                                                          @SuppressWarnings("unchecked")
                                                                          TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                                          
                                                                          // Create test objects - simulate reading a non-Number value
                                                                          when(mockTypeAdapter.read(any(JsonReader.class))).thenThrow(new JsonSyntaxException("Expected a java.lang.Number"));
                                                                          
                                                                          TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                          TypeAdapter<Number> adapter = factory.create(new Gson(), TypeToken.get(Number.class));
                                                                          
                                                                          JsonReader reader = mock(JsonReader.class);
                                                                          
                                                                          // Test & Verify
                                                                          try {
                                                                              adapter.read(reader);
                                                                              fail("Expected JsonSyntaxException");
                                                                          } catch (JsonSyntaxException e) {
                                                                              assertTrue(e.getMessage().contains("Expected a java.lang.Number"));
                                                                          }
                                                                      }

 @Test
                                                                 public void testTypeHierarchyFactoryRead_TypeChecking() throws IOException {
                                                                     // Setup test objects
                                                                     Class<Number> clazz = Number.class;
                                                                     @SuppressWarnings("unchecked")
                                                                     TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                     
                                                                     // Create test TypeToken for Integer (subclass of Number)
                                                                     TypeToken<Integer> integerTypeToken = TypeToken.get(Integer.class);
                                                                     
                                                                     // Mock JsonReader for testing
                                                                     JsonReader mockReader = mock(JsonReader.class);
                                                                     
                                                                     // Test case 1: Correct type (should NOT throw exception)
                                                                     // Setup mock to return an Integer (valid subclass of Number)
                                                                     when(mockTypeAdapter.read(mockReader)).thenReturn(123);
                                                                     
                                                                     TypeAdapter<Integer> adapter = (TypeAdapter<Integer>) factory.create(new Gson(), integerTypeToken);
                                                                     Integer result = adapter.read(mockReader);
                                                                     assertEquals(123, result.intValue());  // Verify correct value returned
                                                                     
                                                                     // Test case 2: Incorrect type (should throw JsonSyntaxException)
                                                                     // Setup mock to return a Double (invalid type for Integer)
                                                                     when(mockTypeAdapter.read(mockReader)).thenReturn(123.45);
                                                                     
                                                                     try {
                                                                         adapter.read(mockReader);
                                                                         fail("Expected JsonSyntaxException for wrong type");
                                                                     } catch (JsonSyntaxException e) {
                                                                         // Verify exception message contains expected type info
                                                                         assertTrue(e.getMessage().contains("Expected a java.lang.Integer"));
                                                                         assertTrue(e.getMessage().contains("java.lang.Double"));
                                                                     }
                                                                 }

 @Test(expected = JsonSyntaxException.class)
                                                             public void testRead_TypeMismatch_ThrowsException() throws IOException {
                                                                 // Setup test data
                                                                 Class<Number> clazz = Number.class;
                                                                 TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                                 
                                                                 // Create test objects
                                                                 TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                                 TypeToken<Integer> requestedType = TypeToken.get(Integer.class);
                                                                 
                                                                 // Mock behavior - return a Double when Integer is requested
                                                                 when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(1.23);
                                                                 
                                                                 // Get the adapter for our test
                                                                 TypeAdapter<Integer> adapter = factory.create(new Gson(), requestedType);
                                                                 
                                                                 // This should throw JsonSyntaxException in original code
                                                                 // Mutant will fail to throw exception
                                                                 adapter.read(mock(JsonReader.class));
                                                             }

 @Test(expected = JsonSyntaxException.class)
                                               public void testRead_WhenResultTypeDoesNotMatchRequestedType_ThrowsJsonSyntaxException() throws IOException {
                                                   // Setup
                                                   Class<Number> clazz = Number.class;
                                                   @SuppressWarnings("unchecked")
                                                   TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                                   
                                                   // Configure mock to return a String when we expect a Number
                                                   when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(123); // Changed from "123" to 123
                                                   
                                                   // Create the factory and adapter
                                                   TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                                   TypeAdapter<Number> adapter = factory.create(new Gson(), TypeToken.get(Number.class));
                                                   
                                                   // Create test input
                                                   JsonReader reader = mock(JsonReader.class);
                                                   
                                                   // This should throw JsonSyntaxException
                                                   adapter.read(reader);
                                               }

 @Test
                                          public void testTypeHierarchyFactoryRead_throwsExceptionWithCorrectTypeInfo() throws IOException {
                                              // Setup test data
                                              Class<Number> clazz = Number.class;
                                              TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                                              
                                              // Create test objects
                                              TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                                              Gson gson = new Gson();
                                              TypeToken<String> stringType = TypeToken.get(String.class);
                                              
                                              // Mock behavior - adapter will return a Number when Number is expected
                                              when(typeAdapter.read(any(JsonReader.class))).thenReturn(1); // Using Integer which extends Number
                                              
                                              // Get the adapter for String type (which should fail since String isn't a Number)
                                              TypeAdapter<String> adapter = factory.create(gson, stringType);
                                              
                                              // Prepare test input
                                              JsonReader reader = mock(JsonReader.class);
                                              
                                              try {
                                                  adapter.read(reader);
                                                  fail("Expected JsonSyntaxException");
                                              } catch (JsonSyntaxException e) {
                                                  // Verify exception message contains the actual class name
                                                  assertTrue("Exception message should contain actual class name", 
                                                           e.getMessage().contains("java.lang.String"));
                                              }
                                          }

 @Test
                                     public void testTypeHierarchyFactoryRead_TypeMismatch_ErrorMessage() throws IOException {
                                         // Setup test data
                                         Class<Number> clazz = Number.class;
                                         TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
                                         
                                         // Create test objects
                                         TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                         Gson gson = new Gson();
                                         TypeToken<String> stringType = TypeToken.get(String.class);
                                         
                                         // Mock behavior - return a Number when String is expected
                                         JsonReader mockReader = mock(JsonReader.class);
                                         when(mockTypeAdapter.read(mockReader)).thenReturn(123); // Return a Number
                                         
                                         // Get the created TypeAdapter
                                         TypeAdapter<String> adapter = factory.create(gson, stringType);
                                         
                                         try {
                                             // Trigger the type mismatch
                                             adapter.read(mockReader);
                                             fail("Expected JsonSyntaxException");
                                         } catch (JsonSyntaxException e) {
                                             // Verify the error message contains both expected and actual types
                                             String message = e.getMessage();
                                             assertTrue("Error message should contain expected type", 
                                                 message.contains("Expected a " + stringType.getRawType().getName()));
                                             assertTrue("Error message should contain actual type", 
                                                 message.contains("but was " + Integer.class.getName()));
                                         }
                                     }

 @Test
                                 public void testReadReturnsActualValueWhenValid() throws IOException {
                                     // Setup test data
                                     Class<String> clazz = String.class;
                                     TypeAdapter<String> mockTypeAdapter = mock(TypeAdapter.class);
                                     String testValue = "test string";
                                     
                                     // Mock the type adapter to return our test value
                                     when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(testValue);
                                     
                                     // Create the factory and adapter
                                     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                     TypeAdapter<String> adapter = factory.create(new Gson(), TypeToken.get(clazz));
                                     
                                     // Mock JsonReader
                                     JsonReader reader = mock(JsonReader.class);
                                     
                                     // Test the read operation
                                     String result = adapter.read(reader);
                                     
                                     // Verify the result is what we expect (not null)
                                     assertEquals("Adapter should return the value read from typeAdapter", testValue, result);
                                     
                                     // Verify interactions
                                     verify(mockTypeAdapter).read(reader);
                                 }

 @Test
                                public void testRead_ValidResult_ReturnsResultWithoutException() throws IOException {
                                    // Setup test data
                                    Class<String> clazz = String.class;
                                    TypeAdapter<String> mockTypeAdapter = mock(TypeAdapter.class);
                                    when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn("test");
                                    
                                    // Create the factory and adapter
                                    TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                    TypeAdapter<String> adapter = factory.create(new Gson(), TypeToken.get(String.class));
                                    
                                    // Mock JsonReader
                                    JsonReader reader = mock(JsonReader.class);
                                    
                                    // Test the read operation
                                    String result = adapter.read(reader);
                                    
                                    // Verify the result is returned (mutant would throw RuntimeException)
                                    assertEquals("test", result);
                                    
                                    // Verify interactions
                                    verify(mockTypeAdapter).read(reader);
                                }

 @Test
                               public void testReadReturnsActualDeserializedObject() throws IOException {
                                   // Setup test data and mocks
                                   Class<String> clazz = String.class;
                                   TypeAdapter<String> mockTypeAdapter = mock(TypeAdapter.class);
                                   String expectedResult = "test string";
                                   
                                   // Create the factory
                                   TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                                   
                                   // Create test TypeToken and JsonReader
                                   TypeToken<String> typeToken = TypeToken.get(String.class);
                                   JsonReader mockReader = mock(JsonReader.class);
                                   
                                   // Mock the type adapter to return our test string
                                   when(mockTypeAdapter.read(mockReader)).thenReturn(expectedResult);
                                   
                                   // Get the created TypeAdapter
                                   TypeAdapter<String> adapter = factory.create(new Gson(), typeToken);
                                   
                                   // Execute the read operation
                                   String actualResult = adapter.read(mockReader);
                                   
                                   // Verify the result is exactly what we expect (not just any Object)
                                   assertSame("The returned object should be exactly the deserialized object", 
                                             expectedResult, actualResult);
                                   
                                   // Additional verification that we got a String (not just Object)
                                   assertEquals("The returned object should be of type String", 
                                              String.class, actualResult.getClass());
                               }

 @Test
                             public void testNewTypeHierarchyFactoryWithSubclass() throws IOException {
                                 // Create a parent class and child class hierarchy
                                 class Parent {}
                                 class Child extends Parent {}
                                 
                                 // Mock the TypeAdapter for Parent
                                 TypeAdapter<Parent> parentAdapter = mock(TypeAdapter.class);
                                 
                                 // Create the factory with Parent.class
                                 TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(
                                     Parent.class, parentAdapter);
                                 
                                 // Test with Child class (subclass of Parent)
                                 TypeToken<Child> childToken = new TypeToken<Child>() {};
                                 TypeAdapter<Child> result = factory.create(new Gson(), childToken);
                                 
                                 // Original behavior should return adapter (not null)
                                 // Mutated behavior would return null
                                 assertNotNull("Factory should accept subclass types", result);
                                 
                                 // Verify the adapter works by testing read behavior
                                 JsonReader reader = mock(JsonReader.class);
                                 Parent parent = new Parent();
                                 when(parentAdapter.read(reader)).thenReturn(parent);
                                 
                                 Child childResult = result.read(reader);
                                 assertSame("Should return the parent instance", parent, childResult);
                             }

 @Test
                         public void testNewTypeHierarchyFactoryWithIncompatibleTypes2() {
                             // Setup
                             Class<String> clazz = String.class;  // Our base class
                             TypeAdapter<String> typeAdapter = mock(TypeAdapter.class);
                             
                             // Create a TypeToken for an incompatible type (e.g., Integer)
                             TypeToken<Integer> incompatibleTypeToken = TypeToken.get(Integer.class);
                             
                             // Create the factory
                             TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                             
                             // Test - should return null for incompatible types
                             TypeAdapter<Integer> result = factory.create(mock(Gson.class), incompatibleTypeToken);
                             
                             // Verify
                             assertNull("Factory should return null for incompatible types", result);
                         }

 @Test
                        public void testNewTypeHierarchyFactoryWriteValue() throws IOException {
                            // Setup test data and mocks
                            Class<Object> clazz = Object.class;
                            TypeAdapter<Object> mockTypeAdapter = mock(TypeAdapter.class);
                            JsonWriter mockWriter = mock(JsonWriter.class);
                            Object testValue = new Object();
                            
                            // Create the factory and adapter
                            TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                            TypeAdapter<Object> adapter = factory.create(new Gson(), TypeToken.get(Object.class));
                            
                            // Test write operation
                            adapter.write(mockWriter, testValue);
                            
                            // Verify the actual value was written, not null
                            verify(mockTypeAdapter).write(mockWriter, testValue);
                            verify(mockTypeAdapter, never()).write(mockWriter, null);
                        }

 @Test
                       public void testReadWithNonNullJsonReader() throws IOException {
                           // Setup test data
                           Class<String> clazz = String.class;
                           TypeAdapter<String> stringAdapter = mock(TypeAdapter.class);
                           when(stringAdapter.read(any(JsonReader.class))).thenReturn("test");
                           
                           // Create the factory and adapter
                           TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, stringAdapter);
                           TypeAdapter<String> adapter = factory.create(new Gson(), TypeToken.get(String.class));
                           
                           // Create a non-null JsonReader
                           JsonReader reader = mock(JsonReader.class);
                           
                           // Test reading
                           String result = adapter.read(reader);
                           
                           // Verify behavior
                           verify(stringAdapter).read(reader); // Verify the adapter was called with the reader
                           assertEquals("test", result); // Verify the result
                           // The mutant would throw NullPointerException before reaching these assertions
                       }

 @Test
                      public void testReadWithNullValueShouldNotThrowException() throws IOException {
                          // Setup
                          Class<Object> clazz = Object.class;
                          TypeAdapter<Object> mockTypeAdapter = mock(TypeAdapter.class);
                          when(mockTypeAdapter.read(any(JsonReader.class))).thenReturn(null);
                          
                          TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
                          TypeAdapter<Object> adapter = factory.create(new Gson(), TypeToken.get(Object.class));
                          
                          JsonReader reader = mock(JsonReader.class);
                          
                          // Test & Verify
                          Object result = adapter.read(reader);
                          assertNull(result); // Verify null is returned without exception
                          
                          // The mutant would throw JsonSyntaxException here because:
                          // 1. result is null
                          // 2. The mutated condition would check !requestedType.isInstance(null)
                          // 3. isInstance(null) returns false
                          // 4. So it would throw the exception
                      }

 @Test
        public void testTypeHierarchyFactory_throwsCorrectExceptionMessage() throws IOException {
            // Setup
            Class<Number> clazz = Number.class;
            @SuppressWarnings("unchecked")
            TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
            
            // Create test objects
            JsonReader mockReader = mock(JsonReader.class);
            String expectedTypeName = "java.lang.Number";
            String actualTypeName = "java.lang.String";
            
            // Mock behavior - adapter throws ClassCastException when wrong type is encountered
            when(mockTypeAdapter.read(mockReader)).thenThrow(new ClassCastException("java.lang.String cannot be cast to java.lang.Number"));
            
            // Create factory and adapter
            TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
            TypeAdapter<Number> adapter = factory.create(new Gson(), TypeToken.get(Number.class));
            
            // Test and verify
            try {
                adapter.read(mockReader);
                fail("Expected JsonSyntaxException");
            } catch (JsonSyntaxException e) {
                // Verify the exception message contains both expected and actual types
                assertTrue("Exception message should contain expected type", 
                    e.getMessage().contains("Expected a " + expectedTypeName));
                assertTrue("Exception message should contain actual type",
                    e.getMessage().contains(actualTypeName));
                throw e;
            }
        }

 @Test
    public void testNewTypeHierarchyFactoryTypeCompatibility() {
        // Create test objects
        Class<String> clazz = String.class;
        TypeAdapter<String> mockAdapter = mock(TypeAdapter.class);
        
        // Create factory with String as base class
        TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockAdapter);
        
        // Test case 1: Requested type is compatible (String)
        TypeToken<String> compatibleType = TypeToken.get(String.class);
        TypeAdapter<String> adapter1 = factory.create(new Gson(), compatibleType);
        assertNotNull("Should return adapter for compatible type", adapter1);
        
        // Test case 2: Requested type is incompatible (Integer)
        TypeToken<Integer> incompatibleType = TypeToken.get(Integer.class);
        TypeAdapter<Integer> adapter2 = factory.create(new Gson(), incompatibleType);
        assertNull("Should return null for incompatible types", adapter2);
        
        // Test case 3: clazz is null (should return null)
        TypeAdapterFactory nullFactory = TypeAdapters.newTypeHierarchyFactory(null, mockAdapter);
        TypeAdapter<String> adapter3 = nullFactory.create(new Gson(), compatibleType);
        assertNull("Should return null when clazz is null", adapter3);
    }

 @Test
   public void testNewTypeHierarchyFactory_WhenTypeNotAssignable_ShouldReturnNull1() {
       // Arrange
       Class<String> clazz = String.class;  // Our base class
       TypeAdapter<String> typeAdapter = mock(TypeAdapter.class);
       
       // Create factory with String as base class
       TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
       
       // Create a type token for a non-assignable type (e.g., Integer)
       TypeToken<Integer> nonAssignableType = TypeToken.get(Integer.class);
       Gson gson = new Gson();
       
       // Act
       TypeAdapter<Integer> result = factory.create(gson, nonAssignableType);
       
       // Assert
       assertNull("Should return null when types are not assignable", result);
       
       // This assertion would fail with the mutant since it returns a non-null object
       // The mutant would return an invalid TypeAdapter instead of null
   }

 @Test
  public void testWriteWithNullValue() throws IOException {
      // Setup
      Class<Object> clazz = Object.class;
      @SuppressWarnings("unchecked")
      TypeAdapter<Object> typeAdapter = mock(TypeAdapter.class);
      JsonWriter jsonWriter = mock(JsonWriter.class);
      
      // Create the factory and adapter
      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
      @SuppressWarnings("unchecked")
      TypeAdapter<Object> adapter = factory.create(new Gson(), TypeToken.get(Object.class));
      
      // Test null value writing
      adapter.write(jsonWriter, null);
      
      // Verify the typeAdapter's write was called with null
      verify(typeAdapter).write(jsonWriter, null);
  }

 @Test
 public void testTypeHierarchyFactoryWithSubclass() throws IOException {
     // Setup class hierarchy
     class Parent {}
     class Child extends Parent {}
     
     // Mock TypeAdapter to return Child instance
     TypeAdapter<Parent> typeAdapter = mock(TypeAdapter.class);
     Child childInstance = new Child();
     when(typeAdapter.read(any(JsonReader.class))).thenReturn(childInstance);
     
     // Create factory with Parent as base class
     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(
         Parent.class, typeAdapter);
     
     // Get adapter for Parent type
     TypeAdapter<Parent> adapter = factory.create(new Gson(), TypeToken.get(Parent.class));
     
     // Test reading - should accept Child as Parent
     JsonReader reader = mock(JsonReader.class);
     Parent result = adapter.read(reader);
     
     // Verify no exception thrown and correct instance returned
     assertNotNull(result);
     assertTrue(result instanceof Parent);
     assertSame(childInstance, result);
     
     // Verify the type check was done (mock interaction)
     verify(typeAdapter).read(reader);
 }

}
