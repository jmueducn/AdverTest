package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
 
public class $Gson$TypesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testResolve_WithTypeVariable() throws Exception {
                                                                                            // Setup
                                                                                            Type context = mock(Type.class);
                                                                                            Class<?> contextRawType = Object.class;
                                                                                            TypeVariable<?> toResolve = mock(TypeVariable.class);
                                                                                            
                                                                                            // Mock behavior
                                                                                            when(toResolve.getBounds()).thenReturn(new Type[]{Object.class});
                                                                                            when(toResolve.getGenericDeclaration()).thenReturn(Object.class);
                                                                                            
                                                                                            // Test
                                                                                            Type result = $Gson$Types.resolve(context, contextRawType, toResolve);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertEquals(Object.class, result);
                                                                                        }

    @Test
                                                                                        public void testResolve_WithParameterizedType() throws Exception {
                                                                                            // Setup
                                                                                            Type context = mock(Type.class);
                                                                                            Class<?> contextRawType = ArrayList.class;
                                                                                            ParameterizedType toResolve = mock(ParameterizedType.class);
                                                                                            
                                                                                            // Mock behavior
                                                                                            when(toResolve.getRawType()).thenReturn((Type)List.class);
                                                                                            when(toResolve.getActualTypeArguments()).thenReturn(new Type[]{String.class});
                                                                                            
                                                                                            // Test
                                                                                            Type result = $Gson$Types.resolve(context, contextRawType, toResolve);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertEquals(toResolve, result);
                                                                                        }

    @Test
                                                                                        public void testResolve_WithWildcardType() throws Exception {
                                                                                            // Setup
                                                                                            Type context = mock(Type.class);
                                                                                            Class<?> contextRawType = Object.class;
                                                                                            WildcardType toResolve = mock(WildcardType.class);
                                                                                            
                                                                                            // Mock behavior
                                                                                            when(toResolve.getUpperBounds()).thenReturn(new Type[]{Object.class});
                                                                                            when(toResolve.getLowerBounds()).thenReturn(new Type[0]);
                                                                                            
                                                                                            // Test
                                                                                            Type result = $Gson$Types.resolve(context, contextRawType, toResolve);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertEquals(toResolve, result);
                                                                                        }

    @Test
                                                                                        public void testResolve_WithClass() throws Exception {
                                                                                            // Setup
                                                                                            Type context = mock(Type.class);
                                                                                            Class<?> contextRawType = Object.class;
                                                                                            Class<?> toResolve = String.class;
                                                                                            
                                                                                            // Test
                                                                                            Type result = $Gson$Types.resolve(context, contextRawType, toResolve);
                                                                                            
                                                                                            // Verify
                                                                                            assertNotNull(result);
                                                                                            assertEquals(String.class, result);
                                                                                        }

    @Test
                                                                                        public void testResolve_WithNullType() throws Exception {
                                                                                            // Setup
                                                                                            Type context = mock(Type.class);
                                                                                            Class<?> contextRawType = Object.class;
                                                                                            
                                                                                            // Test
                                                                                            Type result = $Gson$Types.resolve(context, contextRawType, null);
                                                                                            
                                                                                            // Verify
                                                                                            assertNull(result);
                                                                                        }

    @Test
                                                                                        public void testResolve_WithUnsupportedType() throws Exception {
                                                                                            // Setup
                                                                                            Type context = mock(Type.class);
                                                                                            Class<?> contextRawType = Object.class;
                                                                                            Type toResolve = mock(Type.class);
                                                                                            
                                                                                            // Expect exception
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            
                                                                                            // Test
                                                                                            $Gson$Types.resolve(context, contextRawType, toResolve);
                                                                                        }

    @Test
                                                                        public void testResolve_SimpleType() throws Exception {
                                                                            Class<?> simpleType = String.class;
                                                                            Class<?> contextRawType = Object.class;
                                                                            java.util.Collection<java.lang.reflect.TypeVariable<?>> visited = new java.util.HashSet<>();
                                                                            
                                                                            // Get the $Gson$Types class
                                                                            Class<?> gsonTypesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                                                            // Get the private resolve method
                                                                            java.lang.reflect.Method resolveMethod = gsonTypesClass.getDeclaredMethod(
                                                                                "resolve", 
                                                                                Type.class, 
                                                                                Class.class, 
                                                                                Type.class, 
                                                                                java.util.Collection.class
                                                                            );
                                                                            // Make the method accessible
                                                                            resolveMethod.setAccessible(true);
                                                                            // Invoke the method (null for static method)
                                                                            Type result = (Type) resolveMethod.invoke(
                                                                                null, 
                                                                                null, 
                                                                                contextRawType, 
                                                                                simpleType, 
                                                                                visited
                                                                            );
                                                                            
                                                                            assertEquals(simpleType, result);
                                                                        }

    @Test
                                                                public void testResolve_TypeVariable_NoRecursion() throws Exception {
                                                                    // Setup mocks
                                                                    java.lang.reflect.TypeVariable<?> typeVariable = mock(java.lang.reflect.TypeVariable.class);
                                                                    java.lang.reflect.Type resolvedType = mock(java.lang.reflect.Type.class);
                                                                    Class<?> contextRawType = Object.class;
                                                                    java.util.Set<java.lang.reflect.TypeVariable<?>> visited = new java.util.HashSet<java.lang.reflect.TypeVariable<?>>();
                                                                    
                                                                    // Get private resolve method via reflection
                                                                    java.lang.reflect.Method resolveMethod = com.google.gson.internal.$Gson$Types.class.getDeclaredMethod(
                                                                        "resolve", java.lang.reflect.Type.class, Class.class, java.lang.reflect.Type.class, java.util.Collection.class);
                                                                    resolveMethod.setAccessible(true);
                                                                    
                                                                    // Mock behavior of resolveTypeVariable which will be called internally
                                                                    java.lang.reflect.Method resolveTypeVariableMethod = com.google.gson.internal.$Gson$Types.class.getDeclaredMethod(
                                                                        "resolveTypeVariable", java.lang.reflect.Type.class, Class.class, java.lang.reflect.TypeVariable.class);
                                                                    resolveTypeVariableMethod.setAccessible(true);
                                                                    
                                                                    // Setup mock behavior
                                                                    when(resolveTypeVariableMethod.invoke(null, (java.lang.reflect.Type)null, contextRawType, typeVariable))
                                                                        .thenReturn(resolvedType);
                                                                    
                                                                    // Call the private resolve method
                                                                    java.lang.reflect.Type result = (java.lang.reflect.Type) resolveMethod.invoke(
                                                                        null, (java.lang.reflect.Type)null, contextRawType, typeVariable, visited);
                                                                    
                                                                    // Verify results
                                                                    assertEquals(resolvedType, result);
                                                                    assertTrue(visited.contains(typeVariable));
                                                                }

    @Test
                                                                public void testResolve_TypeVariable_RecursionDetected() {
                                                                    // Mock the TypeVariable
                                                                    java.lang.reflect.TypeVariable<?> typeVariable = mock(java.lang.reflect.TypeVariable.class);
                                                                    Class<?> contextRawType = Object.class;
                                                                    java.util.Collection<java.lang.reflect.TypeVariable<?>> visited = 
                                                                        new java.util.HashSet<java.lang.reflect.TypeVariable<?>>();
                                                                    visited.add(typeVariable); // Already visited
                                                                    
                                                                    try {
                                                                        // Get the private resolve method via reflection
                                                                        java.lang.reflect.Method resolveMethod = com.google.gson.internal.$Gson$Types.class.getDeclaredMethod(
                                                                            "resolve", 
                                                                            java.lang.reflect.Type.class, 
                                                                            Class.class, 
                                                                            java.lang.reflect.Type.class, 
                                                                            java.util.Collection.class);
                                                                        resolveMethod.setAccessible(true);
                                                                        
                                                                        // Invoke the method
                                                                        java.lang.reflect.Type result = (java.lang.reflect.Type) resolveMethod.invoke(
                                                                            null, 
                                                                            null, 
                                                                            contextRawType, 
                                                                            typeVariable, 
                                                                            visited);
                                                                        
                                                                        assertEquals(typeVariable, result); // Should return original when recursion detected
                                                                    } catch (Exception e) {
                                                                        fail("Reflection failed: " + e.getMessage());
                                                                    }
                                                                }

    @Test
                                                                public void testResolve_ClassArray() throws Exception {
                                                                    Class<?> arrayType = String[].class;
                                                                    Class<?> contextRawType = Object.class;
                                                                    java.util.Collection<java.lang.reflect.TypeVariable<?>> visited = new java.util.HashSet<>();
                                                                    
                                                                    // Get the private resolve method via reflection
                                                                    Class<?> typesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                                                    Method resolveMethod = typesClass.getDeclaredMethod("resolve", 
                                                                        java.lang.reflect.Type.class, Class.class, java.lang.reflect.Type.class, java.util.Collection.class);
                                                                    resolveMethod.setAccessible(true);
                                                                    
                                                                    // Invoke the method
                                                                    java.lang.reflect.Type result = (java.lang.reflect.Type) resolveMethod.invoke(
                                                                        null, null, contextRawType, arrayType, visited);
                                                                    
                                                                    assertEquals(arrayType, result); // Should return same array type when component type unchanged
                                                                }

    @Test
                                                public void testResolve_WildcardType() throws Exception {
                                                    // Import required classes
                                                    Type lowerBound = mock(Type.class);
                                                    Type resolvedLower = mock(Type.class);
                                                    Type upperBound = mock(Type.class);
                                                    Type resolvedUpper = mock(Type.class);
                                                    WildcardType wildcard = mock(WildcardType.class);
                                                    Class<?> contextRawType = Object.class;
                                                    java.util.Collection<java.lang.reflect.TypeVariable<?>> visited = new java.util.HashSet<java.lang.reflect.TypeVariable<?>>();
                                                    
                                                    // Create our own empty type array
                                                    Type[] emptyTypeArray = new Type[0];
                                                    
                                                    // Get private resolve method via reflection
                                                    Method resolveMethod = $Gson$Types.class.getDeclaredMethod(
                                                        "resolve", Type.class, Class.class, Type.class, java.util.Collection.class);
                                                    resolveMethod.setAccessible(true);
                                                    
                                                    // Test lower bound resolution
                                                    when(wildcard.getLowerBounds()).thenReturn(new Type[]{lowerBound});
                                                    when(wildcard.getUpperBounds()).thenReturn(emptyTypeArray);
                                                    when(resolveMethod.invoke(null, null, contextRawType, lowerBound, visited))
                                                        .thenReturn(resolvedLower);
                                                    when($Gson$Types.supertypeOf(resolvedLower))
                                                        .thenReturn(mock(WildcardType.class));
                                                    
                                                    Type result1 = (Type) resolveMethod.invoke(null, null, contextRawType, wildcard, visited);
                                                    assertNotEquals(wildcard, result1);
                                                    
                                                    // Test upper bound resolution
                                                    when(wildcard.getLowerBounds()).thenReturn(emptyTypeArray);
                                                    when(wildcard.getUpperBounds()).thenReturn(new Type[]{upperBound});
                                                    when(resolveMethod.invoke(null, null, contextRawType, upperBound, visited))
                                                        .thenReturn(resolvedUpper);
                                                    when($Gson$Types.subtypeOf(resolvedUpper))
                                                        .thenReturn(mock(WildcardType.class));
                                                    
                                                    Type result2 = (Type) resolveMethod.invoke(null, null, contextRawType, wildcard, visited);
                                                    assertNotEquals(wildcard, result2);
                                                    
                                                    // Test no changes
                                                    when(resolveMethod.invoke(null, null, contextRawType, upperBound, visited))
                                                        .thenReturn(upperBound);
                                                    Type result3 = (Type) resolveMethod.invoke(null, null, contextRawType, wildcard, visited);
                                                    assertEquals(wildcard, result3);
                                                }

    @Test
                                        public void testResolve_WithGenericArrayType() throws Exception {
                                            // Setup
                                            Class<?> contextRawType = Object.class;
                                            Type componentType = String.class;
                                            Type toResolve = com.google.gson.internal.$Gson$Types.arrayOf(componentType);
                                            
                                            // Test
                                            Type result = com.google.gson.internal.$Gson$Types.resolve(
                                                null, contextRawType, toResolve);
                                            
                                            // Verify
                                            assertNotNull(result);
                                            assertTrue(result instanceof java.lang.reflect.GenericArrayType);
                                            
                                            Type resolvedComponentType = ((java.lang.reflect.GenericArrayType)result).getGenericComponentType();
                                            assertNotNull(resolvedComponentType);
                                            assertEquals(String.class, resolvedComponentType);
                                        }

    @Test
                            public void testResolve_ParameterizedType() throws Exception {
                                // Setup mocks
                                java.lang.reflect.ParameterizedType parameterizedType = mock(java.lang.reflect.ParameterizedType.class);
                                java.lang.reflect.Type ownerType = mock(java.lang.reflect.Type.class);
                                java.lang.reflect.Type resolvedOwner = mock(java.lang.reflect.Type.class);
                                java.lang.reflect.Type rawType = Object.class;
                                java.lang.reflect.Type typeArg = mock(java.lang.reflect.Type.class);
                                java.lang.reflect.Type[] typeArgs = new java.lang.reflect.Type[]{typeArg};
                                java.lang.reflect.Type resolvedArg = mock(java.lang.reflect.Type.class);
                                java.lang.reflect.Type[] resolvedArgs = new java.lang.reflect.Type[]{resolvedArg};
                                Class<?> contextRawType = Object.class;
                                java.util.Collection<java.lang.reflect.TypeVariable<?>> visited = new java.util.HashSet<>();
                                
                                // Configure parameterizedType mock
                                when(parameterizedType.getOwnerType()).thenReturn(ownerType);
                                when(parameterizedType.getRawType()).thenReturn(rawType);
                                when(parameterizedType.getActualTypeArguments()).thenReturn(typeArgs);
                                
                                // Get private resolve method via reflection
                                Method resolveMethod = com.google.gson.internal.$Gson$Types.class.getDeclaredMethod(
                                    "resolve", 
                                    java.lang.reflect.Type.class, 
                                    Class.class, 
                                    java.lang.reflect.Type.class, 
                                    java.util.Collection.class);
                                resolveMethod.setAccessible(true);
                                
                                // First test with no changes
                                when(resolveMethod.invoke(null, null, contextRawType, ownerType, visited))
                                    .thenReturn(ownerType);
                                when(resolveMethod.invoke(null, null, contextRawType, typeArgs[0], visited))
                                    .thenReturn(typeArgs[0]);
                                
                                java.lang.reflect.Type result1 = (java.lang.reflect.Type) resolveMethod.invoke(
                                    null, null, contextRawType, parameterizedType, visited);
                                assertEquals(parameterizedType, result1);
                                
                                // Second test with changed owner and arguments
                                when(resolveMethod.invoke(null, null, contextRawType, ownerType, visited))
                                    .thenReturn(resolvedOwner);
                                when(resolveMethod.invoke(null, null, contextRawType, typeArgs[0], visited))
                                    .thenReturn(resolvedArgs[0]);
                                when(com.google.gson.internal.$Gson$Types.newParameterizedTypeWithOwner(resolvedOwner, rawType, resolvedArgs))
                                    .thenReturn(mock(java.lang.reflect.ParameterizedType.class));
                                
                                java.lang.reflect.Type result2 = (java.lang.reflect.Type) resolveMethod.invoke(
                                    null, null, contextRawType, parameterizedType, visited);
                                assertNotEquals(parameterizedType, result2);
                            }

    @Test
    public void testResolve_GenericArrayType() {
        // Import required classes
        java.lang.reflect.GenericArrayType genericArray = mock(java.lang.reflect.GenericArrayType.class);
        java.lang.reflect.Type componentType = mock(java.lang.reflect.Type.class);
        java.lang.reflect.Type resolvedComponent = mock(java.lang.reflect.Type.class);
        Class<?> contextRawType = Object.class;
        
        // Mock getGenericComponentType to return componentType
        when(genericArray.getGenericComponentType()).thenReturn(componentType);
        
        // Initialize Mockito for static mocking
{
            // First case: component doesn't change
            // Mock resolve to return same component type
            
            // Mock arrayOf to return original genericArray when component doesn't change
            
            java.lang.reflect.Type result1 = com.google.gson.internal.$Gson$Types.resolve(null, contextRawType, genericArray);
            assertEquals(genericArray, result1);
            
            // Second case: component changes
            // Mock resolve to return different component type
            
            // Create new mock for changed array type
            java.lang.reflect.GenericArrayType changedArray = mock(java.lang.reflect.GenericArrayType.class);
            
            java.lang.reflect.Type result2 = com.google.gson.internal.$Gson$Types.resolve(null, contextRawType, genericArray);
            assertNotEquals(genericArray, result2);
        }
    }


}
