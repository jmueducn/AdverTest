package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
 
public class $Gson$TypesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testGetSupertype_WithWildcardType() throws Exception {
                                            // Setup
                                            WildcardType wildcardType = mock(WildcardType.class);
                                            Type upperBound = Object.class;
                                            when(wildcardType.getUpperBounds()).thenReturn(new Type[]{upperBound});
                                            
                                            Class<?> contextRawType = ArrayList.class;
                                            Class<?> supertype = List.class;
                                            
                                            // Get the method via reflection
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Test
                                            Type result = (Type) getSupertypeMethod.invoke(
                                                null, wildcardType, contextRawType, supertype);
                                            
                                            // Verify
                                            assertNotNull(result);
                                            verify(wildcardType).getUpperBounds();
                                            
                                            // Additional verification that the result is as expected
                                            Method getGenericSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getGenericSupertype", Type.class, Class.class, Class.class);
                                            getGenericSupertypeMethod.setAccessible(true);
                                            Type expectedGenericSupertype = (Type) getGenericSupertypeMethod.invoke(
                                                null, upperBound, contextRawType, supertype);
                                            
                                            Method resolveMethod = $Gson$Types.class.getDeclaredMethod(
                                                "resolve", Type.class, Class.class, Type.class);
                                            resolveMethod.setAccessible(true);
                                            Type expectedResult = (Type) resolveMethod.invoke(
                                                null, upperBound, contextRawType, expectedGenericSupertype);
                                            
                                            assertEquals(expectedResult, result);
                                        }

    @Test
                                        public void testGetSupertype_WithRegularType() throws Exception {
                                            // Setup
                                            Type context = ArrayList.class;
                                            Class<?> contextRawType = ArrayList.class;
                                            Class<?> supertype = List.class;
                                            
                                            // Get the methods via reflection
                                            Method getGenericSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getGenericSupertype", Type.class, Class.class, Class.class);
                                            getGenericSupertypeMethod.setAccessible(true);
                                            
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            Method resolveMethod = $Gson$Types.class.getDeclaredMethod(
                                                "resolve", Type.class, Class.class, Type.class);
                                            resolveMethod.setAccessible(true);
                                            
                                            // Mock the internal call to getGenericSupertype
                                            Type resolvedType = mock(Type.class);
                                            when(getGenericSupertypeMethod.invoke(null, context, contextRawType, supertype))
                                                .thenReturn(resolvedType);
                                            
                                            // Mock the final resolve call
                                            Type expectedResult = mock(Type.class);
                                            when(resolveMethod.invoke(null, context, contextRawType, resolvedType))
                                                .thenReturn(expectedResult);
                                            
                                            // Test
                                            Type result = (Type) getSupertypeMethod.invoke(null, context, contextRawType, supertype);
                                            
                                            // Verify
                                            assertEquals(expectedResult, result);
                                        }

    @Test
                                        public void testGetSupertype_WithInvalidSupertype() throws Exception {
                                            // Setup
                                            Type context = String.class;
                                            Class<?> contextRawType = String.class;
                                            Class<?> supertype = List.class; // String is not assignable to List
                                            
                                            // Get the method via reflection
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(IllegalArgumentException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, context, contextRawType, supertype);
                                        }

    @Test
                                        public void testGetSupertype_WithSameType() throws Exception {
                                            // Setup
                                            Type context = ArrayList.class;
                                            Class<?> contextRawType = ArrayList.class;
                                            Class<?> supertype = ArrayList.class;
                                            
                                            // Get the methods via reflection
                                            Class<?> typesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                            Method getGenericSupertypeMethod = typesClass.getDeclaredMethod(
                                                "getGenericSupertype", Type.class, Class.class, Class.class);
                                            getGenericSupertypeMethod.setAccessible(true);
                                            
                                            Method getSupertypeMethod = typesClass.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            Method resolveMethod = typesClass.getDeclaredMethod(
                                                "resolve", Type.class, Class.class, Type.class);
                                            resolveMethod.setAccessible(true);
                                            
                                            // Mock the internal call to getGenericSupertype
                                            Type resolvedType = mock(Type.class);
                                            when(getGenericSupertypeMethod.invoke(null, context, contextRawType, supertype)).thenReturn(resolvedType);
                                            
                                            // Mock the final resolve call
                                            Type expectedResult = mock(Type.class);
                                            when(resolveMethod.invoke(null, context, contextRawType, resolvedType)).thenReturn(expectedResult);
                                            
                                            // Test
                                            Type result = (Type) getSupertypeMethod.invoke(null, context, contextRawType, supertype);
                                            
                                            // Verify
                                            assertEquals(expectedResult, result);
                                        }

    @Test
                                        public void testGetSupertype_WithInterfaceSupertype() throws Exception {
                                            // Setup
                                            Type context = ArrayList.class;
                                            Class<?> contextRawType = ArrayList.class;
                                            Class<?> supertype = Serializable.class; // ArrayList implements Serializable
                                            
                                            // Get the private methods via reflection
                                            Class<?> typesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                            Method getGenericSupertypeMethod = typesClass.getDeclaredMethod(
                                                "getGenericSupertype", Type.class, Class.class, Class.class);
                                            getGenericSupertypeMethod.setAccessible(true);
                                            
                                            Method getSupertypeMethod = typesClass.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Mock the internal call to getGenericSupertype
                                            Type resolvedType = mock(Type.class);
                                            when(getGenericSupertypeMethod.invoke(null, context, contextRawType, supertype)).thenReturn(resolvedType);
                                            
                                            // Mock the final resolve call
                                            Type expectedResult = mock(Type.class);
                                            Method resolveMethod = typesClass.getDeclaredMethod(
                                                "resolve", Type.class, Class.class, Type.class);
                                            resolveMethod.setAccessible(true);
                                            when(resolveMethod.invoke(null, context, contextRawType, resolvedType)).thenReturn(expectedResult);
                                            
                                            // Test
                                            Type result = (Type) getSupertypeMethod.invoke(null, context, contextRawType, supertype);
                                            
                                            // Verify
                                            assertEquals(expectedResult, result);
                                        }

    @Test
                                        public void testGetSupertype_WithNullContext() throws Exception {
                                            // Setup
                                            Class<?> contextRawType = ArrayList.class;
                                            Class<?> supertype = List.class;
                                            
                                            // Get the method via reflection
                                            Class<?> typesClass = Class.forName("com.google.gson.internal.$Gson$Types");
                                            Method getSupertypeMethod = typesClass.getDeclaredMethod("getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, null, contextRawType, supertype);
                                        }

    @Test
                                        public void testGetSupertype_WithNullContextRawType() throws Exception {
                                            // Setup
                                            Type context = ArrayList.class;
                                            Class<?> supertype = List.class;
                                            
                                            // Get the method via reflection
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, context, null, supertype);
                                        }

    @Test
                                        public void testGetSupertype_WithNullSupertype() throws Exception {
                                            // Setup
                                            Type context = ArrayList.class;
                                            Class<?> contextRawType = ArrayList.class;
                                            
                                            // Get the method via reflection
                                            Method getSupertypeMethod = $Gson$Types.class.getDeclaredMethod(
                                                "getSupertype", Type.class, Class.class, Class.class);
                                            getSupertypeMethod.setAccessible(true);
                                            
                                            // Expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            // Test
                                            getSupertypeMethod.invoke(null, context, contextRawType, null);
                                        }


}
