package gentest.com.google.gson.stream.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.stream.*;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.internal.bind.JsonTreeReader;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
 
public class JsonReaderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                            public void testNextLong_SingleQuotedString() throws Exception {
                                                                // Create reader with single-quoted string
                                                                java.io.StringReader stringReader = new java.io.StringReader("'12345'");
                                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                                
                                                                // Use reflection to set private fields
                                                                try {
                                                                    Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                                    peekedField.setAccessible(true);
                                                                    peekedField.setInt(reader, 9); // PEEKED_SINGLE_QUOTED is typically 9
                                                                    
                                                                    Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                                    stackSizeField.setAccessible(true);
                                                                    stackSizeField.setInt(reader, 1);
                                                                    
                                                                    Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                                    pathIndicesField.setAccessible(true);
                                                                    pathIndicesField.set(reader, new int[1]);
                                                                } catch (Exception e) {
                                                                    throw new RuntimeException("Failed to set up test via reflection", e);
                                                                }
                                                                
                                                                long result = reader.nextLong();
                                                                assertEquals(12345L, result);
                                                                
                                                                // Verify peeked state through reflection
                                                                try {
                                                                    Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                                    peekedField.setAccessible(true);
                                                                    assertEquals(0, peekedField.getInt(reader)); // PEEKED_NONE is typically 0
                                                                    
                                                                    Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                                    pathIndicesField.setAccessible(true);
                                                                    int[] pathIndices = (int[]) pathIndicesField.get(reader);
                                                                    assertEquals(1, pathIndices[0]);
                                                                } catch (Exception e) {
                                                                    throw new RuntimeException("Failed to verify test via reflection", e);
                                                                }
                                                            }

    @Test
                                                            public void testNextLong_MaxLongValue() throws Exception {
                                                                // Create required readers
                                                                java.io.StringReader stringReader = new java.io.StringReader("");
                                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                                
                                                                // Use reflection to access private fields
                                                                java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                                peekedField.setAccessible(true);
                                                                java.lang.reflect.Field peekedLongField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedLong");
                                                                peekedLongField.setAccessible(true);
                                                                java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                                stackSizeField.setAccessible(true);
                                                                java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                                pathIndicesField.setAccessible(true);
                                                                
                                                                // Get PEEKED_LONG constant value via reflection
                                                                java.lang.reflect.Field peekedLongConstant = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_LONG");
                                                                peekedLongConstant.setAccessible(true);
                                                                int PEEKED_LONG = peekedLongConstant.getInt(null);
                                                                
                                                                // Set the private fields
                                                                peekedField.set(reader, PEEKED_LONG);
                                                                peekedLongField.set(reader, Long.MAX_VALUE);
                                                                stackSizeField.set(reader, 1);
                                                                pathIndicesField.set(reader, new int[1]);
                                                                
                                                                long result = reader.nextLong();
                                                                assertEquals(Long.MAX_VALUE, result);
                                                            }

    @Test
                                                            public void testNextLong_Zero() throws Exception {
                                                                java.io.StringReader stringReader = new java.io.StringReader("0");
                                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                                long result = reader.nextLong();
                                                                assertEquals(0L, result);
                                                            }

    @Test
                                                            public void testNextLong_NegativeNumber() throws Exception {
                                                                java.io.StringReader stringReader = new java.io.StringReader("-12345");
                                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                                
                                                                // Use reflection to set private fields
                                                                try {
                                                                    Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                                    peekedField.setAccessible(true);
                                                                    Field peekedNumberField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NUMBER");
                                                                    peekedNumberField.setAccessible(true);
                                                                    peekedField.set(reader, peekedNumberField.getInt(null));
                                                                    
                                                                    Field posField = com.google.gson.stream.JsonReader.class.getDeclaredField("pos");
                                                                    posField.setAccessible(true);
                                                                    posField.set(reader, 0);
                                                                    
                                                                    Field bufferField = com.google.gson.stream.JsonReader.class.getDeclaredField("buffer");
                                                                    bufferField.setAccessible(true);
                                                                    bufferField.set(reader, "-12345".toCharArray());
                                                                    
                                                                    Field peekedNumberLengthField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedNumberLength");
                                                                    peekedNumberLengthField.setAccessible(true);
                                                                    peekedNumberLengthField.set(reader, 6);
                                                                    
                                                                    Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                                    stackSizeField.setAccessible(true);
                                                                    stackSizeField.set(reader, 1);
                                                                    
                                                                    Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                                    pathIndicesField.setAccessible(true);
                                                                    pathIndicesField.set(reader, new int[1]);
                                                                } catch (Exception e) {
                                                                    throw new RuntimeException("Failed to set up JsonReader for testing", e);
                                                                }
                                                                
                                                                long result = reader.nextLong();
                                                                assertEquals(-12345L, result);
                                                            }

    @Test
                                                        public void testNextInt_EdgeCases() throws Exception {
                                                            // Test Integer.MAX_VALUE
                                                            java.io.StringReader maxStringReader = new java.io.StringReader(String.valueOf(Integer.MAX_VALUE));
                                                            com.google.gson.stream.JsonReader maxReader = new com.google.gson.stream.JsonReader(maxStringReader);
                                                            assertEquals(Integer.MAX_VALUE, maxReader.nextInt());
                                                            
                                                            // Test Integer.MIN_VALUE
                                                            java.io.StringReader minStringReader = new java.io.StringReader(String.valueOf(Integer.MIN_VALUE));
                                                            com.google.gson.stream.JsonReader minReader = new com.google.gson.stream.JsonReader(minStringReader);
                                                            assertEquals(Integer.MIN_VALUE, minReader.nextInt());
                                                            
                                                            // Test zero
                                                            java.io.StringReader zeroStringReader = new java.io.StringReader("0");
                                                            com.google.gson.stream.JsonReader zeroReader = new com.google.gson.stream.JsonReader(zeroStringReader);
                                                            assertEquals(0, zeroReader.nextInt());
                                                        }

    @Test
                                                        public void testNextLong_PeekedNumber() throws Exception {
                                                            // Create JsonReader with test input
                                                            java.io.StringReader stringReader = new java.io.StringReader("12345");
                                                            com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                            
                                                            // Use reflection to access private fields
                                                            Class<?> readerClass = com.google.gson.stream.JsonReader.class;
                                                            java.lang.reflect.Field peekedField = readerClass.getDeclaredField("peeked");
                                                            peekedField.setAccessible(true);
                                                            java.lang.reflect.Field posField = readerClass.getDeclaredField("pos");
                                                            posField.setAccessible(true);
                                                            java.lang.reflect.Field bufferField = readerClass.getDeclaredField("buffer");
                                                            bufferField.setAccessible(true);
                                                            java.lang.reflect.Field peekedNumberLengthField = readerClass.getDeclaredField("peekedNumberLength");
                                                            peekedNumberLengthField.setAccessible(true);
                                                            java.lang.reflect.Field stackSizeField = readerClass.getDeclaredField("stackSize");
                                                            stackSizeField.setAccessible(true);
                                                            java.lang.reflect.Field pathIndicesField = readerClass.getDeclaredField("pathIndices");
                                                            pathIndicesField.setAccessible(true);
                                                            
                                                            // Get PEEKED_NUMBER and PEEKED_NONE constants via reflection
                                                            java.lang.reflect.Field peekedNumberField = readerClass.getDeclaredField("PEEKED_NUMBER");
                                                            peekedNumberField.setAccessible(true);
                                                            int PEEKED_NUMBER = peekedNumberField.getInt(null);
                                                            java.lang.reflect.Field peekedNoneField = readerClass.getDeclaredField("PEEKED_NONE");
                                                            peekedNoneField.setAccessible(true);
                                                            int PEEKED_NONE = peekedNoneField.getInt(null);
                                                            
                                                            // Set up reader state
                                                            peekedField.setInt(reader, PEEKED_NUMBER);
                                                            posField.setInt(reader, 0);
                                                            bufferField.set(reader, "12345".toCharArray());
                                                            peekedNumberLengthField.setInt(reader, 5);
                                                            stackSizeField.setInt(reader, 1);
                                                            pathIndicesField.set(reader, new int[1]);
                                                            
                                                            // Test nextLong() method
                                                            long result = reader.nextLong();
                                                            assertEquals(12345L, result);
                                                            assertEquals(PEEKED_NONE, peekedField.getInt(reader));
                                                            int[] pathIndices = (int[]) pathIndicesField.get(reader);
                                                            assertEquals(1, pathIndices[0]);
                                                        }

    @Test
                                                        public void testNextLong_MinLongValue() throws Exception {
                                                            // Create reader with valid JSON content (empty object)
                                                            com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("{}"));
                                                            
                                                            // Use reflection to access private fields
                                                            java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                            peekedField.setAccessible(true);
                                                            java.lang.reflect.Field peekedLongField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedLong");
                                                            peekedLongField.setAccessible(true);
                                                            java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                            stackSizeField.setAccessible(true);
                                                            java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                            pathIndicesField.setAccessible(true);
                                                            
                                                            // Get PEEKED_LONG value via reflection
                                                            java.lang.reflect.Field peekedLongValueField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_LONG");
                                                            peekedLongValueField.setAccessible(true);
                                                            int PEEKED_LONG = peekedLongValueField.getInt(null);
                                                            
                                                            // Set up the reader state
                                                            peekedField.setInt(reader, PEEKED_LONG);
                                                            peekedLongField.setLong(reader, Long.MIN_VALUE);
                                                            stackSizeField.setInt(reader, 1);
                                                            pathIndicesField.set(reader, new int[1]);
                                                            
                                                            long result = reader.nextLong();
                                                            assertEquals(Long.MIN_VALUE, result);
                                                        }

    @Test
                                                    public void testNextInt_PeekedNumber_ValidInt() throws Exception {
                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("123"));
                                                        
                                                        // Use reflection to access private fields
                                                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                        peekedField.setAccessible(true);
                                                        java.lang.reflect.Field bufferField = com.google.gson.stream.JsonReader.class.getDeclaredField("buffer");
                                                        bufferField.setAccessible(true);
                                                        java.lang.reflect.Field posField = com.google.gson.stream.JsonReader.class.getDeclaredField("pos");
                                                        posField.setAccessible(true);
                                                        java.lang.reflect.Field peekedNumberLengthField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedNumberLength");
                                                        peekedNumberLengthField.setAccessible(true);
                                                        
                                                        // Get PEEKED_NUMBER and PEEKED_NONE constants via reflection
                                                        java.lang.reflect.Field peekedNumberField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NUMBER");
                                                        peekedNumberField.setAccessible(true);
                                                        int PEEKED_NUMBER = peekedNumberField.getInt(null);
                                                        
                                                        java.lang.reflect.Field peekedNoneField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NONE");
                                                        peekedNoneField.setAccessible(true);
                                                        int PEEKED_NONE = peekedNoneField.getInt(null);
                                                        
                                                        // Set up the reader state
                                                        peekedField.set(reader, PEEKED_NUMBER);
                                                        bufferField.set(reader, "123".toCharArray());
                                                        posField.set(reader, 0);
                                                        peekedNumberLengthField.set(reader, 3);
                                                        
                                                        int result = reader.nextInt();
                                                        org.junit.Assert.assertEquals(123, result);
                                                        org.junit.Assert.assertEquals(PEEKED_NONE, peekedField.get(reader));
                                                    }

    @Test
                                                    public void testNextInt_InvalidPeekedState() throws Exception {
                                                        // Setup expected exception rule
                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                        
                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("true"));
                                                        
                                                        // Get PEEKED_TRUE value via reflection
                                                        java.lang.reflect.Field peekedTrueField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_TRUE");
                                                        peekedTrueField.setAccessible(true);
                                                        int PEEKED_TRUE = peekedTrueField.getInt(null);
                                                        
                                                        // Set peeked field via reflection
                                                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                        peekedField.setAccessible(true);
                                                        peekedField.setInt(reader, PEEKED_TRUE);
                                                        
                                                        thrown.expect(IllegalStateException.class);
                                                        thrown.expectMessage("Expected an int but was ");
                                                        reader.nextInt();
                                                    }

    @Test
                                                    public void testNextInt_PeekedNone_CallsDoPeek() throws Exception {
                                                        java.io.StringReader stringReader = new java.io.StringReader("123");
                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                        
                                                        int result = reader.nextInt();
                                                        assertEquals(123, result);
                                                        
                                                        // Verify the reader advanced to the end by trying to read again
                                                        try {
                                                            reader.nextInt();
                                                            fail("Expected exception");
                                                        } catch (IllegalStateException expected) {
                                                            // Expected
                                                        }
                                                    }

    @Test
                                                    public void testNextLong_WithDecimal_PrecisionLoss_ThrowsException() throws Exception {
                                                        java.io.StringReader stringReader = new java.io.StringReader("12345.5");
                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                        
                                                        // Use reflection to set private fields
                                                        try {
                                                            Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                            peekedField.setAccessible(true);
                                                            Field peekedNumberField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NUMBER");
                                                            peekedNumberField.setAccessible(true);
                                                            int PEEKED_NUMBER = peekedNumberField.getInt(null);
                                                            peekedField.setInt(reader, PEEKED_NUMBER);
                                                            
                                                            Field posField = com.google.gson.stream.JsonReader.class.getDeclaredField("pos");
                                                            posField.setAccessible(true);
                                                            posField.setInt(reader, 0);
                                                            
                                                            Field bufferField = com.google.gson.stream.JsonReader.class.getDeclaredField("buffer");
                                                            bufferField.setAccessible(true);
                                                            bufferField.set(reader, "12345.5".toCharArray());
                                                            
                                                            Field peekedNumberLengthField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedNumberLength");
                                                            peekedNumberLengthField.setAccessible(true);
                                                            peekedNumberLengthField.setInt(reader, 7);
                                                            
                                                            Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                            stackSizeField.setAccessible(true);
                                                            stackSizeField.setInt(reader, 1);
                                                            
                                                            Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                            pathIndicesField.setAccessible(true);
                                                            pathIndicesField.set(reader, new int[1]);
                                                        } catch (Exception e) {
                                                            throw new RuntimeException("Failed to set up test using reflection", e);
                                                        }
                                                        
                                                        try {
                                                            reader.nextLong();
                                                            fail("Expected NumberFormatException");
                                                        } catch (NumberFormatException e) {
                                                            assertEquals("Expected a long but was 12345.5", e.getMessage());
                                                        }
                                                    }

    @Test
                                                public void testNextInt_PeekedBuffered_ValidDouble() throws Exception {
                                                    // Create JsonReader with test input
                                                    java.io.StringReader stringReader = new java.io.StringReader("123.0");
                                                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                    
                                                    // Use reflection to set private fields
                                                    java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                    peekedField.setAccessible(true);
                                                    peekedField.set(reader, 5); // PEEKED_NUMBER is typically 5
                                                    
                                                    java.lang.reflect.Field peekedStringField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedString");
                                                    peekedStringField.setAccessible(true);
                                                    peekedStringField.set(reader, "123.0");
                                                    
                                                    // Test nextInt() and verify results
                                                    int result = reader.nextInt();
                                                    assertEquals(123, result);
                                                    
                                                    // Verify peeked was reset to PEEKED_NONE (typically 0)
                                                    assertEquals(0, peekedField.get(reader));
                                                    assertNull(peekedStringField.get(reader));
                                                }

    @Test
                                                public void testNextLong_InvalidString_ThrowsNumberFormatException() throws Exception {
                                                    java.io.StringReader stringReader = new java.io.StringReader("abc");
                                                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                    
                                                    // Use reflection to set private fields
                                                    java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                    peekedField.setAccessible(true);
                                                    java.lang.reflect.Field peekedUnquotedField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_UNQUOTED");
                                                    peekedUnquotedField.setAccessible(true);
                                                    java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                    stackSizeField.setAccessible(true);
                                                    java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                    pathIndicesField.setAccessible(true);
                                                    
                                                    // Set the values
                                                    int peekedUnquotedValue = peekedUnquotedField.getInt(null);
                                                    peekedField.setInt(reader, peekedUnquotedValue);
                                                    stackSizeField.setInt(reader, 1);
                                                    pathIndicesField.set(reader, new int[1]);
                                                    
                                                    try {
                                                        reader.nextLong();
                                                        fail("Expected NumberFormatException");
                                                    } catch (NumberFormatException expected) {
                                                        // Expected exception
                                                    }
                                                }

    @Test
                                            public void testNextLong_InvalidPeekedValue_ThrowsIllegalStateException() throws Exception {
                                                // Setup ExpectedException rule
                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                
                                                // Create JsonReader with empty object
                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("{}"));
                                                
                                                // Use reflection to access private fields
                                                java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                peekedField.setAccessible(true);
                                                java.lang.reflect.Field peekedBeginObjectField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_BEGIN_OBJECT");
                                                peekedBeginObjectField.setAccessible(true);
                                                java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                stackSizeField.setAccessible(true);
                                                java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                pathIndicesField.setAccessible(true);
                                                
                                                // Set the private fields to simulate BEGIN_OBJECT state
                                                int peekedBeginObjectValue = peekedBeginObjectField.getInt(null);
                                                peekedField.setInt(reader, peekedBeginObjectValue);
                                                stackSizeField.setInt(reader, 1);
                                                pathIndicesField.set(reader, new int[1]);
                                                
                                                // Expect exception
                                                thrown.expect(IllegalStateException.class);
                                                thrown.expectMessage("Expected a long but was BEGIN_OBJECT");
                                                reader.nextLong();
                                            }

    @Test
                                            public void testNextInt_PeekedDoubleQuoted_ValidInt() throws Exception {
                                                // Arrange
                                                java.io.StringReader stringReader = new java.io.StringReader("\"123\"");
                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                
                                                // Use reflection to access private fields
                                                Class<?> jsonReaderClass = com.google.gson.stream.JsonReader.class;
                                                Field peekedField = jsonReaderClass.getDeclaredField("peeked");
                                                peekedField.setAccessible(true);
                                                
                                                // Get the PEEKED_DOUBLE_QUOTED constant value
                                                int PEEKED_DOUBLE_QUOTED = 0;
                                                for (Field field : jsonReaderClass.getDeclaredFields()) {
                                                    if (field.getName().equals("PEEKED_DOUBLE_QUOTED")) {
                                                        field.setAccessible(true);
                                                        PEEKED_DOUBLE_QUOTED = field.getInt(null);
                                                        // Set peeked state
                                                        peekedField.setInt(reader, PEEKED_DOUBLE_QUOTED);
                                                        break;
                                                    }
                                                }
                                                
                                                // Act
                                                int result = reader.nextInt();
                                                
                                                // Assert
                                                org.junit.Assert.assertEquals(123, result);
                                                
                                                // Verify peeked is reset to NONE
                                                int PEEKED_NONE = 0;
                                                for (Field field : jsonReaderClass.getDeclaredFields()) {
                                                    if (field.getName().equals("PEEKED_NONE")) {
                                                        field.setAccessible(true);
                                                        PEEKED_NONE = field.getInt(null);
                                                        org.junit.Assert.assertEquals(PEEKED_NONE, peekedField.getInt(reader));
                                                        break;
                                                    }
                                                }
                                            }

    @Test
                                            public void testNextLong_UnquotedString() throws Exception {
                                                java.io.StringReader stringReader = new java.io.StringReader("12345");
                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                
                                                try {
                                                    // Use reflection to set private fields
                                                    java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                    peekedField.setAccessible(true);
                                                    
                                                    // Get the peeked value constants via reflection
                                                    Class<?>[] declaredClasses = com.google.gson.stream.JsonReader.class.getDeclaredClasses();
                                                    Class<?> peekedClass = null;
                                                    for (Class<?> clazz : declaredClasses) {
                                                        if (clazz.getSimpleName().equals("Peeked")) {
                                                            peekedClass = clazz;
                                                            break;
                                                        }
                                                    }
                                                    if (peekedClass == null) {
                                                        fail("Could not find Peeked class");
                                                    }
                                                    
                                                    java.lang.reflect.Field PEEKED_UNQUOTED = peekedClass.getDeclaredField("PEEKED_UNQUOTED");
                                                    PEEKED_UNQUOTED.setAccessible(true);
                                                    peekedField.set(reader, PEEKED_UNQUOTED.getInt(null));
                                                    
                                                    java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                    stackSizeField.setAccessible(true);
                                                    stackSizeField.set(reader, 1);
                                                    
                                                    java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                    pathIndicesField.setAccessible(true);
                                                    pathIndicesField.set(reader, new int[1]);
                                                    
                                                    long result = reader.nextLong();
                                                    assertEquals(12345L, result);
                                                    
                                                    java.lang.reflect.Field PEEKED_NONE = peekedClass.getDeclaredField("PEEKED_NONE");
                                                    PEEKED_NONE.setAccessible(true);
                                                    assertEquals(PEEKED_NONE.getInt(null), peekedField.getInt(reader));
                                                    assertEquals(1, ((int[])pathIndicesField.get(reader))[0]);
                                                } catch (Exception e) {
                                                    fail("Reflection failed: " + e.getMessage());
                                                }
                                            }

    @Test
                                            public void testNextLong_WithDecimal_NoPrecisionLoss() throws Exception {
                                                java.io.StringReader stringReader = new java.io.StringReader("12345.0");
                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                
                                                // Use reflection to set private fields needed for the test
                                                try {
                                                    // Set peeked to PEEKED_NUMBER (assuming value is 16 based on common implementations)
                                                    Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                    peekedField.setAccessible(true);
                                                    peekedField.setInt(reader, 16); // PEEKED_NUMBER is often 16
                                                    
                                                    // Set peekedNumberLength
                                                    Field peekedNumberLengthField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedNumberLength");
                                                    peekedNumberLengthField.setAccessible(true);
                                                    peekedNumberLengthField.setInt(reader, 7);
                                                    
                                                    // Set buffer with the number content
                                                    Field bufferField = com.google.gson.stream.JsonReader.class.getDeclaredField("buffer");
                                                    bufferField.setAccessible(true);
                                                    char[] buffer = new char[1024];
                                                    "12345.0".getChars(0, 7, buffer, 0);
                                                    bufferField.set(reader, buffer);
                                                    
                                                    // Set pos to 0
                                                    Field posField = com.google.gson.stream.JsonReader.class.getDeclaredField("pos");
                                                    posField.setAccessible(true);
                                                    posField.setInt(reader, 0);
                                                    
                                                    // Set limit to length of number
                                                    Field limitField = com.google.gson.stream.JsonReader.class.getDeclaredField("limit");
                                                    limitField.setAccessible(true);
                                                    limitField.setInt(reader, 7);
                                                    
                                                    // Initialize stack
                                                    Field stackField = com.google.gson.stream.JsonReader.class.getDeclaredField("stack");
                                                    stackField.setAccessible(true);
                                                    stackField.set(reader, new int[32]);
                                                    
                                                    // Initialize pathIndices
                                                    Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                    pathIndicesField.setAccessible(true);
                                                    pathIndicesField.set(reader, new int[32]);
                                                    
                                                    // Set stackSize
                                                    Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                    stackSizeField.setAccessible(true);
                                                    stackSizeField.setInt(reader, 1);
                                                } catch (Exception e) {
                                                    throw new RuntimeException("Failed to set up test via reflection", e);
                                                }
                                                
                                                long result = reader.nextLong();
                                                assertEquals(12345L, result);
                                                
                                                // Verify peeked state is reset
                                                try {
                                                    Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                    peekedField.setAccessible(true);
                                                    assertEquals(0, peekedField.getInt(reader)); // PEEKED_NONE is often 0
                                                    
                                                    // Verify pathIndices was incremented
                                                    Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                    pathIndicesField.setAccessible(true);
                                                    int[] pathIndices = (int[]) pathIndicesField.get(reader);
                                                    assertEquals(1, pathIndices[0]);
                                                } catch (Exception e) {
                                                    throw new RuntimeException("Failed to verify test via reflection", e);
                                                }
                                            }

    @Test
                                        public void testNextLong_DoubleQuotedString() throws Exception {
                                            // Create JsonReader with test input
                                            com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("\"12345\""));
                                            
                                            // Use reflection to set private fields
                                            try {
                                                // Set peeked to PEEKED_DOUBLE_QUOTED (assuming value is 9 based on common implementations)
                                                java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                peekedField.setAccessible(true);
                                                peekedField.set(reader, 9); // PEEKED_DOUBLE_QUOTED is typically 9
                                                
                                                // Set stack size to 1
                                                java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                stackSizeField.setAccessible(true);
                                                stackSizeField.set(reader, 1);
                                                
                                                // Initialize path indices array
                                                java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                pathIndicesField.setAccessible(true);
                                                pathIndicesField.set(reader, new int[1]);
                                                
                                                // Initialize path names array
                                                java.lang.reflect.Field pathNamesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathNames");
                                                pathNamesField.setAccessible(true);
                                                pathNamesField.set(reader, new String[1]);
                                            } catch (Exception e) {
                                                throw new RuntimeException("Failed to set up test state via reflection", e);
                                            }
                                            
                                            // Test nextLong() with the prepared state
                                            long result = reader.nextLong();
                                            assertEquals(12345L, result);
                                            
                                            // Verify peeked state through public peek() method
                                            assertEquals(com.google.gson.stream.JsonToken.END_DOCUMENT, reader.peek());
                                            
                                            // Verify path index through getPath()
                                            assertTrue(reader.getPath().endsWith("[1]"));
                                        }

    @Test
                                    public void testNextInt_PeekedLong_ValidInt() throws Exception {
                                        // Create JsonReader with test input
                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("42"));
                                        
                                        try {
                                            // Use reflection to access private fields and constants
                                            Class<?> readerClass = com.google.gson.stream.JsonReader.class;
                                            java.lang.reflect.Field peekedField = readerClass.getDeclaredField("peeked");
                                            peekedField.setAccessible(true);
                                            java.lang.reflect.Field peekedLongField = readerClass.getDeclaredField("peekedLong");
                                            peekedLongField.setAccessible(true);
                                            
                                            // Get PEEKED_LONG and PEEKED_NONE constants via reflection
                                            java.lang.reflect.Field peekedLongConst = readerClass.getDeclaredField("PEEKED_LONG");
                                            peekedLongConst.setAccessible(true);
                                            java.lang.reflect.Field peekedNoneConst = readerClass.getDeclaredField("PEEKED_NONE");
                                            peekedNoneConst.setAccessible(true);
                                            
                                            // Set up test state
                                            int PEEKED_LONG = peekedLongConst.getInt(null);
                                            int PEEKED_NONE = peekedNoneConst.getInt(null);
                                            
                                            peekedField.setInt(reader, PEEKED_LONG);
                                            peekedLongField.setLong(reader, 42L);
                                            
                                            // Test the method
                                            int result = reader.nextInt();
                                            org.junit.Assert.assertEquals(42, result);
                                            org.junit.Assert.assertEquals(PEEKED_NONE, peekedField.getInt(reader));
                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                            org.junit.Assert.fail("Reflection failed: " + e.getMessage());
                                        }
                                    }

    @Test
                                    public void testNextLong_PeekedLong() throws Exception {
                                        // Create a reader with a valid long value
                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("12345"));
                                        
                                        // Use reflection to access and modify private fields for testing
                                        Class<?> readerClass = reader.getClass();
                                        
                                        try {
                                            // Get and set peeked field
                                            Field peekedField = readerClass.getDeclaredField("peeked");
                                            peekedField.setAccessible(true);
                                            
                                            // Get PEEKED_LONG constant value
                                            Field peekedLongField = readerClass.getDeclaredField("PEEKED_LONG");
                                            peekedLongField.setAccessible(true);
                                            int peekedLongValue = peekedLongField.getInt(null);
                                            peekedField.set(reader, peekedLongValue);
                                            
                                            // Get and set peekedLong field
                                            Field peekedLongValueField = readerClass.getDeclaredField("peekedLong");
                                            peekedLongValueField.setAccessible(true);
                                            peekedLongValueField.set(reader, 12345L);
                                            
                                            // Get and set stackSize field
                                            Field stackSizeField = readerClass.getDeclaredField("stackSize");
                                            stackSizeField.setAccessible(true);
                                            stackSizeField.set(reader, 1);
                                            
                                            // Get and set pathIndices field
                                            Field pathIndicesField = readerClass.getDeclaredField("pathIndices");
                                            pathIndicesField.setAccessible(true);
                                            pathIndicesField.set(reader, new int[1]);
                                            
                                            long result = reader.nextLong();
                                            assertEquals(12345L, result);
                                            
                                            // Verify peeked is reset to PEEKED_NONE
                                            Field peekedNoneField = readerClass.getDeclaredField("PEEKED_NONE");
                                            peekedNoneField.setAccessible(true);
                                            assertEquals(peekedNoneField.getInt(null), peekedField.getInt(reader));
                                            
                                            // Verify pathIndices was incremented
                                            int[] pathIndices = (int[]) pathIndicesField.get(reader);
                                            assertEquals(1, pathIndices[0]);
                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                            fail("Reflection failed: " + e.getMessage());
                                        }
                                    }

    @Test
                                public void testNextInt_PeekedBuffered_InvalidDouble() throws Exception {
                                    java.io.StringReader stringReader = new java.io.StringReader("123.5");
                                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                    
                                    // Use reflection to access private fields
                                    java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                    peekedField.setAccessible(true);
                                    java.lang.reflect.Field peekedStringField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedString");
                                    peekedStringField.setAccessible(true);
                                    
                                    // Get PEEKED_NUMBER value via reflection
                                    java.lang.reflect.Field peekedNumberField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NUMBER");
                                    peekedNumberField.setAccessible(true);
                                    int PEEKED_NUMBER = peekedNumberField.getInt(null);
                                    
                                    // Set up the test scenario
                                    peekedField.setInt(reader, PEEKED_NUMBER);
                                    peekedStringField.set(reader, "123.5");
                                    
                                    try {
                                        reader.nextInt();
                                        fail("Expected NumberFormatException");
                                    } catch (NumberFormatException e) {
                                        assertEquals("Expected an int but was 123.5", e.getMessage());
                                    }
                                }

    @Test
                            public void testNextInt_PeekedQuoted_InvalidInt() throws Exception {
                                java.io.StringReader stringReader = new java.io.StringReader("\"abc\"");
                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                
                                // Use reflection to access private PEEKED_DOUBLE_QUOTED constant
                                Field peekedDoubleQuotedField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_DOUBLE_QUOTED");
                                peekedDoubleQuotedField.setAccessible(true);
                                int PEEKED_DOUBLE_QUOTED = peekedDoubleQuotedField.getInt(null);
                                
                                // Use reflection to set private peeked field
                                Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                peekedField.setAccessible(true);
                                peekedField.setInt(reader, PEEKED_DOUBLE_QUOTED);
                                
                                try {
                                    reader.nextInt();
                                    fail("Expected NumberFormatException");
                                } catch (NumberFormatException e) {
                                    assertEquals("Expected an int but was abc", e.getMessage());
                                }
                            }

    @Test
                public void testNextInt_PeekedUnquoted_ValidInt() throws Exception {
                    // Create JsonReader with test input
                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("123"));
                    
                    try {
                        // Use reflection to access private peeked field
                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                        peekedField.setAccessible(true);
                        
                        // Access peeked constants through the class
                        Class<?>[] declaredClasses = com.google.gson.stream.JsonReader.class.getDeclaredClasses();
                        Class<?> peekedClass = null;
                        for (Class<?> clazz : declaredClasses) {
                            if (clazz.getName().contains("JsonReader$Peeked")) {
                                peekedClass = clazz;
                                break;
                            }
                        }
                        
                        if (peekedClass == null) {
                            fail("Could not find Peeked enum class");
                        }
                        
                        // Get PEEKED_UNQUOTED and PEEKED_NONE values
                        Object PEEKED_UNQUOTED = Enum.valueOf((Class<Enum>)peekedClass, "PEEKED_UNQUOTED");
                        Object PEEKED_NONE = Enum.valueOf((Class<Enum>)peekedClass, "PEEKED_NONE");
                        
                        // Set the peeked state
                        peekedField.set(reader, PEEKED_UNQUOTED);
                        
                        // Test nextInt()
                        int result = reader.nextInt();
                        assertEquals(123, result);
                        assertEquals(PEEKED_NONE, peekedField.get(reader));
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        fail("Reflection failed: " + e.getMessage());
                    } catch (IllegalArgumentException e) {
                        fail("Enum value not found: " + e.getMessage());
                    }
                }

    @Test
            public void testNextInt_PeekedSingleQuoted_ValidInt() throws Exception {
                // Create a JsonReader with a StringReader containing the test data
                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader("\"123\""));
                
                try {
                    // Use reflection to set peeked field to PEEKED_SINGLE_QUOTED
                    Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                    peekedField.setAccessible(true);
                    
                    // Get the PEEKED_SINGLE_QUOTED constant value
                    Class<?>[] declaredClasses = com.google.gson.stream.JsonReader.class.getDeclaredClasses();
                    Class<?> peekedClass = null;
                    for (Class<?> clazz : declaredClasses) {
                        if (clazz.getName().contains("JsonScope")) {
                            peekedClass = clazz;
                            break;
                        }
                    }
                    
                    Field peekedSingleQuotedField = peekedClass.getDeclaredField("PEEKED_SINGLE_QUOTED");
                    peekedSingleQuotedField.setAccessible(true);
                    int PEEKED_SINGLE_QUOTED = peekedSingleQuotedField.getInt(null);
                    
                    // Set the peeked state
                    peekedField.setInt(reader, PEEKED_SINGLE_QUOTED);
                    
                    // Test the nextInt() method
                    int result = reader.nextInt();
                    assertEquals(123, result);
                    
                    // Verify peeked is reset to PEEKED_NONE
                    Field peekedNoneField = peekedClass.getDeclaredField("PEEKED_NONE");
                    peekedNoneField.setAccessible(true);
                    int PEEKED_NONE = peekedNoneField.getInt(null);
                    assertEquals(PEEKED_NONE, peekedField.getInt(reader));
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    fail("Reflection failed: " + e.getMessage());
                }
            }

    @Test
    public void testNextInt_PeekedLong_InvalidInt() throws Exception {
        // Create reader with empty input since we'll manipulate its state directly
        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(new java.io.StringReader(""));
        
        // Use reflection to access private fields
        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        java.lang.reflect.Field peekedLongField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedLong");
        peekedLongField.setAccessible(true);
        
        // Get PEEKED_LONG constant value via reflection
        // Note: Some implementations might use different constant names
        // If PEEKED_LONG doesn't exist, we might need to use the actual value
        int PEEKED_LONG;
        try {
            java.lang.reflect.Field peekedLongConstant = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_LONG");
            peekedLongConstant.setAccessible(true);
            PEEKED_LONG = peekedLongConstant.getInt(null);
        } catch (NoSuchFieldException e) {
            // If PEEKED_LONG constant doesn't exist, use the likely value (16 in some implementations)
            PEEKED_LONG = 16;
        }
        
        // Set the peeked values to simulate having read a long value
        peekedField.setInt(reader, PEEKED_LONG);
        peekedLongField.setLong(reader, Long.MAX_VALUE);
        
        try {
            reader.nextInt();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            assertEquals("Expected an int but was " + Long.MAX_VALUE + " at line 1 column 1 path $", e.getMessage());
        }
    }


}
