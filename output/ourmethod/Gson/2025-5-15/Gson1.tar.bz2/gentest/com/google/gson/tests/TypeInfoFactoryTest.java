package gentest.com.google.gson.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.*;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
 
public class TypeInfoFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                        public void testGetActualType_ClassType() throws Exception {
                                            // Test with Class type
                                            Class<?> stringClass = String.class;
                                            
                                            // Get the private getActualType method via reflection
                                            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                            Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                "getActualType", 
                                                Type.class, 
                                                Type.class, 
                                                Class.class
                                            );
                                            getActualTypeMethod.setAccessible(true);
                                            
                                            // Invoke the method with null for parentType and rawParentClass
                                            Type result = (Type) getActualTypeMethod.invoke(
                                                null, 
                                                stringClass, 
                                                (Type) null, 
                                                (Class<?>) null
                                            );
                                            
                                            assertSame(stringClass, result);
                                        }

    @Test
                                        public void testGetActualType_ParameterizedType() throws Exception {
                                            // Create mock ParameterizedType
                                            ParameterizedType parameterizedType = mock(ParameterizedType.class);
                                            Type rawType = ArrayList.class;
                                            Type[] typeArgs = new Type[]{String.class};
                                            Type ownerType = null;
                                            
                                            when(parameterizedType.getOwnerType()).thenReturn(ownerType);
                                            when(parameterizedType.getRawType()).thenReturn(rawType);
                                            when(parameterizedType.getActualTypeArguments()).thenReturn(typeArgs);
                                            
                                            // Use reflection to access private getActualType method
                                            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                            Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                "getActualType", Type.class, Type.class, Class.class);
                                            getActualTypeMethod.setAccessible(true);
                                            
                                            // Invoke the method with null for parentType and rawParentClass
                                            Type result = (Type) getActualTypeMethod.invoke(
                                                null, parameterizedType, null, null);
                                            
                                            assertTrue(result instanceof ParameterizedType);
                                            ParameterizedType resultType = (ParameterizedType) result;
                                            assertEquals(rawType, resultType.getRawType());
                                            assertArrayEquals(typeArgs, resultType.getActualTypeArguments());
                                            assertEquals(ownerType, resultType.getOwnerType());
                                        }

    @Test
                                        public void testGetActualType_WildcardType() throws Exception {
                                            // Create mock WildcardType
                                            WildcardType wildcardType = mock(WildcardType.class);
                                            Type upperBound = String.class;
                                            Type[] upperBounds = new Type[]{upperBound};
                                            
                                            when(wildcardType.getUpperBounds()).thenReturn(upperBounds);
                                            
                                            // Use reflection to access private method
                                            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                            Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                "getActualType", Type.class, Type.class, Class.class);
                                            getActualTypeMethod.setAccessible(true);
                                            
                                            Type result = (Type) getActualTypeMethod.invoke(null, wildcardType, null, null);
                                            assertEquals(upperBound, result);
                                        }

    @Test
                                        public void testGetActualType_UnknownType() throws Exception {
                                            // Test with unknown type
                                            Type unknownType = mock(Type.class);
                                            
                                            // Get the private method via reflection
                                            Class<?> clazz = Class.forName("com.google.gson.TypeInfoFactory");
                                            Method method = clazz.getDeclaredMethod("getActualType", Type.class, Type.class, Class.class);
                                            method.setAccessible(true);
                                            
                                            thrown.expect(IllegalArgumentException.class);
                                            thrown.expectMessage("Type '");
                                            thrown.expectMessage("' is not a Class, ParameterizedType, GenericArrayType or TypeVariable");
                                            
                                            // Invoke the method with null parentType and rawParentClass
                                            method.invoke(null, unknownType, null, null);
                                        }

    @Test
                                    public void testGetActualType_GenericArrayType_SameComponentType() throws Exception {
                                        // Create mock GenericArrayType
                                        GenericArrayType genericArrayType = mock(GenericArrayType.class);
                                        Type componentType = String.class;
                                        
                                        when(genericArrayType.getGenericComponentType()).thenReturn(componentType);
                                        
                                        // Use reflection to access private method
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                            "getActualType", Type.class, Type.class, Class.class);
                                        getActualTypeMethod.setAccessible(true);
                                        
                                        Type result = (Type) getActualTypeMethod.invoke(
                                            null, genericArrayType, null, null);
                                        
                                        assertSame(genericArrayType, result);
                                    }

    @Test
                                    public void testGetActualType_GenericArrayType_DifferentComponentType() throws Exception {
                                        // Create mock GenericArrayType
                                        GenericArrayType genericArrayType = mock(GenericArrayType.class);
                                        Type componentType = mock(Type.class);
                                        Type actualType = String.class;
                                        
                                        when(genericArrayType.getGenericComponentType()).thenReturn(componentType);
                                        
                                        // Get the private getActualType method via reflection
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                            "getActualType", Type.class, Type.class, Class.class);
                                        getActualTypeMethod.setAccessible(true);
                                        
                                        // Mock the behavior of getActualType for component type
                                        when(componentType.equals(actualType)).thenReturn(false);
                                        
                                        // Invoke the method
                                        Type result = (Type) getActualTypeMethod.invoke(
                                            null, genericArrayType, null, null);
                                        
                                        assertTrue(result instanceof Class<?>);
                                        assertEquals(String[].class, result);
                                    }

    @Test
                                    public void testGetActualType_TypeVariable_WithNonParameterizedParent() throws Exception {
                                        // Test TypeVariable with non-Parameterized parent type
                                        TypeVariable<?> typeVariable = mock(TypeVariable.class);
                                        Class<?> parentType = ArrayList.class;
                                        Class<?> rawParentClass = ArrayList.class;
                                        
                                        thrown.expect(UnsupportedOperationException.class);
                                        thrown.expectMessage("Expecting parameterized type");
                                        
                                        // Use reflection to access private method
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                            "getActualType", Type.class, Type.class, Class.class);
                                        getActualTypeMethod.setAccessible(true);
                                        
                                        // Invoke the method on a null instance since it's static
                                        getActualTypeMethod.invoke(null, typeVariable, parentType, rawParentClass);
                                    }

    @Test
                                    public void testExtractTypeForHierarchy_WithParameterizedParentType() throws Exception {
                                        // Setup parameterized test classes
                                        class GenericParent<T> {}
                                        class GenericChild extends GenericParent<String> {}
                                        
                                        ParameterizedType parentType = (ParameterizedType) GenericChild.class.getGenericSuperclass();
                                        TypeVariable<?> typeToEvaluate = GenericParent.class.getTypeParameters()[0];
                                        
                                        // Use reflection to access private method
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                        extractTypeForHierarchy.setAccessible(true);
                                        
                                        // Invoke the method
                                        Type result = (Type) extractTypeForHierarchy.invoke(null, parentType, typeToEvaluate);
                                        assertEquals(String.class, result);
                                    }

    @Test
                                    public void testExtractTypeForHierarchy_WithArrayTypeParent() throws Exception {
                                        TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                        Type arrayType = String[].class;
                                        
                                        // Get the class via reflection since it's not public
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        
                                        // Get the method via reflection since it's private
                                        Method method = typeInfoFactoryClass.getDeclaredMethod(
                                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                        method.setAccessible(true);
                                        
                                        // Invoke the static method
                                        Type result = (Type) method.invoke(null, arrayType, typeToEvaluate);
                                        assertNull(result);
                                    }

    @Test
                                    public void testExtractRealTypes_NullInput() throws Exception {
                                        // Get the class object using reflection
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        
                                        // Get the private method via reflection
                                        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                            "extractRealTypes", 
                                            Type[].class, 
                                            Type.class, 
                                            Class.class
                                        );
                                        extractRealTypesMethod.setAccessible(true);
                                        
                                        // Create mock Type object
                                        Type mockType = mock(Type.class);
                                        
                                        // Invoke the method with null input
                                        extractRealTypesMethod.invoke(
                                            null,  // static method
                                            null,  // null Type[] input
                                            mockType, 
                                            Object.class
                                        );
                                    }

    @Test
                                    public void testExtractRealTypes_EmptyArray() throws Exception {
                                        Type[] input = new Type[0];
                                        Type parentType = mock(Type.class);
                                        
                                        // Get the class via reflection
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        
                                        // Get the private method via reflection
                                        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                            "extractRealTypes", 
                                            Type[].class, 
                                            Type.class, 
                                            Class.class
                                        );
                                        extractRealTypesMethod.setAccessible(true);
                                        
                                        // Invoke the method
                                        Type[] result = (Type[]) extractRealTypesMethod.invoke(
                                            null, 
                                            input, 
                                            parentType, 
                                            Object.class
                                        );
                                        
                                        assertNotNull(result);
                                        assertEquals(0, result.length);
                                    }

    @Test
                                    public void testExtractRealTypes_WithNullElementsInArray() throws Exception {
                                        // Create mock objects
                                        Type mockType = mock(Type.class);
                                        Type mockParentType = mock(Type.class);
                                        Class<?> rawParentClass = Object.class;
                                        Type[] input = new Type[]{null, mockType, null};
                                        
                                        // Get the TypeInfoFactory class via reflection
                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                        
                                        // Get the extractRealTypes method via reflection
                                        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                            "extractRealTypes", Type[].class, Type.class, Class.class);
                                        extractRealTypesMethod.setAccessible(true);
                                        
                                        // Invoke the method
                                        Type[] result = (Type[]) extractRealTypesMethod.invoke(null, input, mockParentType, rawParentClass);
                                        
                                        // Assertions
                                        assertNotNull(result);
                                        assertEquals(3, result.length);
                                        assertNull(result[0]);
                                        assertNotNull(result[1]);
                                        assertNull(result[2]);
                                    }

    @Test
                                public void testExtractTypeForHierarchy_WithNullParentType() throws Exception {
                                    // Get the class via reflection
                                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                    
                                    // Get the private method via reflection
                                    Method extractTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                        "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                    extractTypeMethod.setAccessible(true);
                                    
                                    // Mock TypeVariable
                                    TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                    Method[] objectMethods = Object.class.getDeclaredMethods();
                                    when(typeToEvaluate.getGenericDeclaration()).thenReturn(objectMethods[0]);
                                    
                                    // Invoke the method with null parent type
                                    Type result = (Type) extractTypeMethod.invoke(null, null, typeToEvaluate);
                                    assertNull(result);
                                }

    @Test
                                public void testExtractTypeForHierarchy_WithUnsupportedType() throws Exception {
                                    TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                    Type unsupportedType = mock(Type.class); // Neither Class nor ParameterizedType
                                    
                                    // Get the private method via reflection using fully qualified class name
                                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                    Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                                        "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                    extractTypeForHierarchy.setAccessible(true);
                                    
                                    // Invoke the method
                                    Type result = (Type) extractTypeForHierarchy.invoke(null, unsupportedType, typeToEvaluate);
                                    assertNull(result);
                                }

    @Test
                                public void testExtractTypeForHierarchy_WithNoMatchingSuperclass() throws Exception {
                                    class Parent {}
                                    class Child extends Parent {}
                                    
                                    Type parentType = Child.class;
                                    TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                    
                                    // Get the private static method via reflection using class name
                                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                    Method method = typeInfoFactoryClass.getDeclaredMethod(
                                        "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                    method.setAccessible(true);
                                    
                                    // Invoke the static method directly (pass null as instance for static method)
                                    Type result = (Type) method.invoke(null, parentType, typeToEvaluate);
                                    
                                    assertNull(result);
                                }

    @Test
                                public void testExtractRealTypes_MultipleTypes() throws Exception {
                                    Type mockType1 = mock(Type.class);
                                    Type mockType2 = mock(Type.class);
                                    Type mockParentType = mock(Type.class);
                                    Class<?> rawParentClass = Object.class;
                                    Type[] input = new Type[]{mockType1, mockType2};
                                    
                                    // Get the TypeInfoFactory class via reflection
                                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                    
                                    // Get the extractRealTypes method via reflection
                                    Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                        "extractRealTypes", Type[].class, Type.class, Class.class);
                                    extractRealTypesMethod.setAccessible(true);
                                    
                                    // Invoke the static method directly
                                    Type[] result = (Type[]) extractRealTypesMethod.invoke(null, input, mockParentType, rawParentClass);
                                    
                                    // Verify the basic behavior
                                    assertNotNull(result);
                                    assertEquals(2, result.length);
                                    
                                    // Since we can't mock the internal getActualType calls, we can only verify:
                                    // 1. The method doesn't throw exceptions
                                    // 2. It returns an array of the same length as input
                                    // 3. The returned array contains Type objects
                                    assertTrue(result[0] instanceof Type);
                                    assertTrue(result[1] instanceof Type);
                                }

    @Test
                            public void testExtractTypeForHierarchy_WithDeepHierarchy() throws Exception {
                                class GrandParent<T> {}
                                class Parent<U> extends GrandParent<U> {}
                                class Child extends Parent<String> {}
                                
                                ParameterizedType parentType = (ParameterizedType) Child.class.getGenericSuperclass();
                                TypeVariable<?> typeToEvaluate = GrandParent.class.getTypeParameters()[0];
                                
                                // Use reflection to access the private constructor
                                Class<?> factoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                Constructor<?> constructor = factoryClass.getDeclaredConstructor();
                                constructor.setAccessible(true);
                                Object factory = constructor.newInstance();
                                
                                // Create a spy of the factory
                                Object spyFactory = spy(factory);
                                
                                // Mock the getIndex method
                                Method getIndexMethod = factoryClass.getDeclaredMethod("getIndex", TypeVariable[].class, TypeVariable.class);
                                getIndexMethod.setAccessible(true);
                                when(getIndexMethod.invoke(
                                    spyFactory,
                                    any(TypeVariable[].class),
                                    eq(typeToEvaluate)
                                )).thenReturn(0);
                                
                                // Call the extractTypeForHierarchy method through reflection
                                Method method = factoryClass.getDeclaredMethod("extractTypeForHierarchy", Type.class, TypeVariable.class);
                                method.setAccessible(true);
                                
                                // Need to set up the static method call - this requires more complex mocking
                                // Since we can't easily mock static methods without PowerMock, we'll just test the actual implementation
                                Type result = (Type) method.invoke(null, parentType, typeToEvaluate);
                                
                                assertEquals(String.class, result);
                            }

    @Test
                            public void testExtractTypeForHierarchy_WithWildcardTypeParent() throws Exception {
                                // Create mock objects
                                TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                WildcardType wildcardType = mock(WildcardType.class);
                                
                                // Mock getGenericDeclaration() which is called in the tested method
                                when(typeToEvaluate.getGenericDeclaration()).thenReturn(Object.class);
                                
                                // Use reflection to get the class and method
                                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                                    "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                extractTypeForHierarchy.setAccessible(true);
                                
                                Type result = (Type) extractTypeForHierarchy.invoke(null, wildcardType, typeToEvaluate);
                                assertNull(result);
                            }

    @Test
                        public void testExtractTypeForHierarchy_WithClassParentType() throws Exception {
                            // Setup test classes
                            class Parent<T> {}
                            class Child extends Parent<String> {}
                            
                            // Get actual type variables
                            Type parentType = Child.class.getGenericSuperclass();
                            TypeVariable<?> typeToEvaluate = Parent.class.getTypeParameters()[0];
                            
                            // Use reflection to create TypeInfoFactory instance
                            Class<?> factoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                            Constructor<?> constructor = factoryClass.getDeclaredConstructor();
                            constructor.setAccessible(true);
                            Object factory = constructor.newInstance();
                            
                            // Create spy of the factory
                            Object spyFactory = spy(factory);
                            
                            // Mock the getIndex method behavior
                            Method getIndexMethod = factoryClass.getDeclaredMethod("getIndex", TypeVariable[].class, TypeVariable.class);
                            getIndexMethod.setAccessible(true);
                            when(getIndexMethod.invoke(
                                spyFactory,
                                any(TypeVariable[].class),
                                eq(typeToEvaluate))).thenReturn(0);
                            
                            // Call the method under test
                            Method extractMethod = factoryClass.getDeclaredMethod("extractTypeForHierarchy", Type.class, TypeVariable.class);
                            extractMethod.setAccessible(true);
                            Type result = (Type) extractMethod.invoke(spyFactory, parentType, typeToEvaluate);
                            
                            assertNotNull(result);
                            assertEquals(String.class, result);
                        }

    @Test
    public void testGetActualType_TypeVariable_WithParameterizedParent() throws Exception {
        // Create test scenario with TypeVariable and ParameterizedType parent
        TypeVariable<?> typeVariable = mock(TypeVariable.class);
        ParameterizedType parentType = mock(ParameterizedType.class);
        Class<?> rawParentClass = mock(Class.class);
        
        // Mock type variables and actual type arguments
        TypeVariable<?>[] classTypeVariables = new TypeVariable<?>[1];
        classTypeVariables[0] = typeVariable;
        Type[] actualTypeArguments = new Type[]{String.class};
        
        when(parentType.getRawType()).thenReturn(rawParentClass);
        when(parentType.getActualTypeArguments()).thenReturn(actualTypeArguments);
        when(rawParentClass.getTypeParameters()).thenReturn((TypeVariable[])classTypeVariables);
        
        // Use reflection to access private getActualType method
        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
            "getActualType", Type.class, Type.class, Class.class);
        getActualTypeMethod.setAccessible(true);
        
        Type result = (Type) getActualTypeMethod.invoke(
            null, typeVariable, parentType, rawParentClass);
        assertEquals(String.class, result);
    }

    @Test
    public void testExtractRealTypes_SingleType() throws Exception {
        // Create mock objects
        Type mockType = mock(Type.class);
        Type mockParentType = mock(Type.class);
        Class<?> rawParentClass = Object.class;
        Type[] input = new Type[]{mockType};
        
        // Mock the behavior of getActualType
        Type expectedResult = mock(Type.class);
        
        // Get the extractRealTypes method via reflection
        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
            "extractRealTypes", Type[].class, Type.class, Class.class);
        extractRealTypesMethod.setAccessible(true);
        
        // Get the getActualType method via reflection
        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
            "getActualType", Type.class, Type.class, Class.class);
        getActualTypeMethod.setAccessible(true);
        
        // Mock the behavior of getActualType using PowerMockito
        when(getActualTypeMethod.invoke(null, mockType, mockParentType, rawParentClass))
            .thenReturn(expectedResult);
        
        // Call the method under test
        Type[] result = (Type[]) extractRealTypesMethod.invoke(null, input, mockParentType, rawParentClass);
        
        // Verify results
        assertNotNull(result);
        assertEquals(1, result.length);
        assertSame(expectedResult, result[0]);
    }


}
