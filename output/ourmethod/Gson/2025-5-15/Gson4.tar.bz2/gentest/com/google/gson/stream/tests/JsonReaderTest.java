package gentest.com.google.gson.stream.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.stream.*;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.internal.bind.JsonTreeReader;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
 
public class JsonReaderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                        public void testSetLenient_True() {
                                                                                                                                                                            // When
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            // Then
                                                                                                                                                                            assertTrue(jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_False() {
                                                                                                                                                                            // When
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            
                                                                                                                                                                            // Then
                                                                                                                                                                            assertFalse(jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_ToggleMultipleTimes() {
                                                                                                                                                                            // When
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            assertTrue(jsonReader.isLenient());
                                                                                                                                                                            
                                                                                                                                                                            jsonReader.setLenient(false);
                                                                                                                                                                            assertFalse(jsonReader.isLenient());
                                                                                                                                                                            
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            assertTrue(jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_DefaultValue() {
                                                                                                                                                                            // The default value should be false based on the class structure
                                                                                                                                                                            assertFalse(jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_WithNullReader() {
                                                                                                                                                                            thrown.expect(NullPointerException.class);
                                                                                                                                                                            thrown.expectMessage("in == null");
                                                                                                                                                                            
                                                                                                                                                                            // This tests that the constructor properly validates input
                                                                                                                                                                            new JsonReader(null).setLenient(true);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_AfterReadingStarted() {
                                                                                                                                                                            // Given - read something to move the position
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader("{\"key\":\"value\"}"));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            // When
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            // Then - should still work
                                                                                                                                                                            assertTrue(jsonReader.isLenient());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testSetLenient_InteractionWithLenientParsing() {
                                                                                                                                                                            // Given a malformed JSON that would fail in strict mode
                                                                                                                                                                            String malformedJson = "{key: 'value'}"; // unquoted key, single quotes
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(malformedJson));
                                                                                                                                                                            
                                                                                                                                                                            // When/Then - should fail in strict mode
                                                                                                                                                                            try {
                                                                                                                                                                                jsonReader.beginObject();
                                                                                                                                                                                fail("Should have thrown exception for malformed JSON in strict mode");
                                                                                                                                                                            } catch (Exception expected) {
                                                                                                                                                                                // Expected
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // When set to lenient
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(malformedJson));
                                                                                                                                                                            jsonReader.setLenient(true);
                                                                                                                                                                            
                                                                                                                                                                            // Then - should parse successfully
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            assertEquals("key", jsonReader.nextName());
                                                                                                                                                                            assertEquals("value", jsonReader.nextString());
                                                                                                                                                                            jsonReader.endObject();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekReturnsBeginObject() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            String json = "{}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_NONE since it's package-private
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekReturnsBeginArray() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            String json = "[]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_NONE
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedEndObject_ReturnsFalse() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(""));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_END_OBJECT
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_END_OBJECT);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertFalse(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedEndArray_ReturnsFalse() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(""));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_END_ARRAY
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_END_ARRAY);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertFalse(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedOtherValue_ReturnsTrue() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader("\"value\""));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_DOUBLE_QUOTED
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_DOUBLE_QUOTED);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedNone_AndDoPeekThrowsException() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            Reader mockReader = mock(Reader.class);
                                                                                                                                                                            when(mockReader.read(any(char[].class), anyInt(), anyInt()))
                                                                                                                                                                                .thenThrow(new IOException("Test exception"));
                                                                                                                                                                            
                                                                                                                                                                            jsonReader = new JsonReader(mockReader);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_NONE
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_NONE);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Expect exception
                                                                                                                                                                            expectedException.expect(IOException.class);
                                                                                                                                                                            expectedException.expectMessage("Test exception");
                                                                                                                                                                            
                                                                                                                                                                            // Test
                                                                                                                                                                            jsonReader.hasNext();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedIsUnquotedValue_ReturnsTrue() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader("value"));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_UNQUOTED
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_UNQUOTED);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testHasNext_WhenPeekedIsNumber_ReturnsTrue() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader("123"));
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set peeked to PEEKED_NUMBER
                                                                                                                                                                            try {
                                                                                                                                                                                java.lang.reflect.Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                                                                                                                                peekedField.setAccessible(true);
                                                                                                                                                                                peekedField.set(jsonReader, JsonReader.PEEKED_NUMBER);
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Failed to set peeked field via reflection");
                                                                                                                                                                            }
                                                                                                                                                                            
                                                                                                                                                                            // Test & Verify
                                                                                                                                                                            assertTrue(jsonReader.hasNext());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNone_CallsDoPeek() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            JsonReader spyReader = spy(jsonReader);
                                                                                                                                                                            when(spyReader.doPeek()).thenReturn(JsonReader.PEEKED_BEGIN_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            // Execute
                                                                                                                                                                            JsonToken result = spyReader.peek();
                                                                                                                                                                            
                                                                                                                                                                            // Verify
                                                                                                                                                                            verify(spyReader).doPeek();
                                                                                                                                                                            assertEquals(JsonToken.BEGIN_OBJECT, result);
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedBeginObject_ReturnsBeginObject() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, JsonReader.PEEKED_BEGIN_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            // Execute & Verify
                                                                                                                                                                            assertEquals(JsonToken.BEGIN_OBJECT, jsonReader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedEndObject_ReturnsEndObject() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, JsonReader.PEEKED_END_OBJECT);
                                                                                                                                                                            
                                                                                                                                                                            // Execute & Verify
                                                                                                                                                                            assertEquals(JsonToken.END_OBJECT, jsonReader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedBeginArray_ReturnsBeginArray() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, JsonReader.PEEKED_BEGIN_ARRAY);
                                                                                                                                                                            
                                                                                                                                                                            // Execute & Verify
                                                                                                                                                                            assertEquals(JsonToken.BEGIN_ARRAY, jsonReader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedEndArray_ReturnsEndArray() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, JsonReader.PEEKED_END_ARRAY);
                                                                                                                                                                            
                                                                                                                                                                            // Execute & Verify
                                                                                                                                                                            assertEquals(JsonToken.END_ARRAY, jsonReader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNameVariants_ReturnsName() throws Exception {
                                                                                                                                                                            // Test all name variants
                                                                                                                                                                            int[] nameVariants = {
                                                                                                                                                                                JsonReader.PEEKED_SINGLE_QUOTED_NAME,
                                                                                                                                                                                JsonReader.PEEKED_DOUBLE_QUOTED_NAME,
                                                                                                                                                                                JsonReader.PEEKED_UNQUOTED_NAME
                                                                                                                                                                            };
                                                                                                                                                                            
                                                                                                                                                                            for (int variant : nameVariants) {
                                                                                                                                                                                setPeekedValue(jsonReader, variant);
                                                                                                                                                                                assertEquals(JsonToken.NAME, jsonReader.peek());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedBooleanVariants_ReturnsBoolean() throws Exception {
                                                                                                                                                                            // Test both boolean variants
                                                                                                                                                                            int[] booleanVariants = {
                                                                                                                                                                                JsonReader.PEEKED_TRUE,
                                                                                                                                                                                JsonReader.PEEKED_FALSE
                                                                                                                                                                            };
                                                                                                                                                                            
                                                                                                                                                                            for (int variant : booleanVariants) {
                                                                                                                                                                                setPeekedValue(jsonReader, variant);
                                                                                                                                                                                assertEquals(JsonToken.BOOLEAN, jsonReader.peek());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNull_ReturnsNull() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, JsonReader.PEEKED_NULL);
                                                                                                                                                                            
                                                                                                                                                                            // Execute & Verify
                                                                                                                                                                            assertEquals(JsonToken.NULL, jsonReader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedStringVariants_ReturnsString() throws Exception {
                                                                                                                                                                            // Test all string variants
                                                                                                                                                                            int[] stringVariants = {
                                                                                                                                                                                JsonReader.PEEKED_SINGLE_QUOTED,
                                                                                                                                                                                JsonReader.PEEKED_DOUBLE_QUOTED,
                                                                                                                                                                                JsonReader.PEEKED_UNQUOTED,
                                                                                                                                                                                JsonReader.PEEKED_BUFFERED
                                                                                                                                                                            };
                                                                                                                                                                            
                                                                                                                                                                            for (int variant : stringVariants) {
                                                                                                                                                                                setPeekedValue(jsonReader, variant);
                                                                                                                                                                                assertEquals(JsonToken.STRING, jsonReader.peek());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedNumberVariants_ReturnsNumber() throws Exception {
                                                                                                                                                                            // Test both number variants
                                                                                                                                                                            int[] numberVariants = {
                                                                                                                                                                                JsonReader.PEEKED_LONG,
                                                                                                                                                                                JsonReader.PEEKED_NUMBER
                                                                                                                                                                            };
                                                                                                                                                                            
                                                                                                                                                                            for (int variant : numberVariants) {
                                                                                                                                                                                setPeekedValue(jsonReader, variant);
                                                                                                                                                                                assertEquals(JsonToken.NUMBER, jsonReader.peek());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenPeekedEof_ReturnsEndDocument() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, JsonReader.PEEKED_EOF);
                                                                                                                                                                            
                                                                                                                                                                            // Execute & Verify
                                                                                                                                                                            assertEquals(JsonToken.END_DOCUMENT, jsonReader.peek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testPeek_WhenInvalidPeekedValue_ThrowsAssertionError() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            setPeekedValue(jsonReader, -1); // Invalid peeked value
                                                                                                                                                                            
                                                                                                                                                                            // Expect exception
                                                                                                                                                                            thrown.expect(AssertionError.class);
                                                                                                                                                                            
                                                                                                                                                                            // Execute
                                                                                                                                                                            jsonReader.peek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_EmptyArray() throws Exception {
                                                                                                                                                                            String json = "[]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_END_ARRAY, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyArray() throws Exception {
                                                                                                                                                                            String json = "[1, 2]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            
                                                                                                                                                                            // First peek should find the number
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_NUMBER, jsonReader.doPeek());
                                                                                                                                                                            jsonReader.nextInt();
                                                                                                                                                                            
                                                                                                                                                                            // After comma, peek should find next number
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_NUMBER, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_EmptyObject() throws Exception {
                                                                                                                                                                            String json = "{}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_END_OBJECT, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyObject() throws Exception {
                                                                                                                                                                            String json = "{\"key\":\"value\"}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_DOUBLE_QUOTED_NAME, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_EmptyDocument() throws Exception {
                                                                                                                                                                            String json = "";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_EOF, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_NonEmptyDocument() throws Exception {
                                                                                                                                                                            String json = "123";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_NUMBER, jsonReader.doPeek());
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_ClosedReader() throws Exception {
                                                                                                                                                                            String json = "[]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.close();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expect(IllegalStateException.class);
                                                                                                                                                                            expectedException.expectMessage("JsonReader is closed");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_UnterminatedArray() throws Exception {
                                                                                                                                                                            String json = "[1, 2";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            jsonReader.nextInt();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expectMessage("Unterminated array");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }

    @Test
                                                                                                                                                                        public void testDoPeek_UnterminatedObject() throws Exception {
                                                                                                                                                                            String json = "{\"key\":\"value\"";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            jsonReader.nextName();
                                                                                                                                                                            jsonReader.nextString();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expectMessage("Unterminated object");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_InvalidValueInArray() throws Exception {
                                                                                                                                                                            String json = "[invalid]";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expectMessage("Expected value");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_SingleQuotedString() throws Exception {
                                                                                                                                                                            String json = "['value']";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginArray();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_SINGLE_QUOTED, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_BooleanTrue() throws Exception {
                                                                                                                                                                            String json = "true";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_TRUE, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_BooleanFalse() throws Exception {
                                                                                                                                                                            String json = "false";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_FALSE, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_NullValue() throws Exception {
                                                                                                                                                                            String json = "null";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_NULL, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_UnquotedName() throws Exception {
                                                                                                                                                                            String json = "{key:123}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            assertEquals(JsonReader.PEEKED_UNQUOTED_NAME, jsonReader.doPeek());
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_ExpectedNameError() throws Exception {
                                                                                                                                                                            String json = "{123}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expectMessage("Expected name");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }
                                                                                                                                                                    
                                                                                                                                                                        @Test
                                                                                                                                                                        public void testDoPeek_ExpectedColonError() throws Exception {
                                                                                                                                                                            String json = "{\"key\" 123}";
                                                                                                                                                                            jsonReader = new JsonReader(new StringReader(json));
                                                                                                                                                                            jsonReader.beginObject();
                                                                                                                                                                            jsonReader.nextName();
                                                                                                                                                                            
                                                                                                                                                                            expectedException.expectMessage("Expected ':'");
                                                                                                                                                                            jsonReader.doPeek();
                                                                                                                                                                        }
                                                                                                                                                                    }

                                                                                                                                                
                                                                                                                                                public void testPeekKeyword_MismatchAfterFirstChar() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    JsonReader jsonReader = new JsonReader(new StringReader(""));
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private fields
                                                                                                                                                }

                                                                                                                                            public void testPeekKeyword_FalseLowerCase() throws Exception {
                                                                                                                                                // Setup
                                                                                                                                                JsonReader jsonReader = new JsonReader(new StringReader(""));
                                                                                                                                                
                                                                                                                                                // Set up buffer with "false"
                                                                                                                                            }

                                                                                                                                public void testPeekKeyword_FailedBufferRefill() throws Exception {
                                                                                                                                    // Setup test buffer and reader
                                                                                                                                    char[] testBuffer = new char[1024];
                                                                                                                                    
                                                                                                                                    // Set buffer position and limit using reflection
                                                                                                                                }

    @Test
                                                                                public void testPeekKeyword_TrueUpperCase() throws Exception {
                                                                                    // Setup
                                                                                    JsonReader jsonReader = new JsonReader(new StringReader("TRUE"));
                                                                                    
                                                                                    // Use reflection to set private buffer field
                                                                                }

    @Test
                                                                                public void testPeekKeyword_TrueMixedCase() throws Exception {
                                                                                    // Setup
                                                                                    JsonReader jsonReader = new JsonReader(new StringReader("TrUe"));
                                                                                    
                                                                                    // Use reflection to access private fields
{}
                                                                                }

    @Test
                                                                                public void testPeekKeyword_NullLowerCase() throws Exception {
                                                                                    // Setup
                                                                                    char[] testBuffer = new char[4];
                                                                                    
                                                                                    // Create JsonReader with mock Reader
                                                                                    
                                                                                    // Use reflection to access private peekKeyword method
                                                                                    // Verify that the method recognized "null" keyword
                                                                                }

    @Test
                                                                                public void testPeekKeyword_InvalidFirstChar() throws Exception {
                                                                                    // Setup
                                                                                    String json = "x"; // Not t, f, or n
                                                                                    
                                                                                    // Use reflection to access private peekKeyword method
                                                                                    // Verify - assuming peekKeyword returns -1 for invalid first char
                                                                                }

    @Test
                                                                                public void testPeekKeyword_PartialMatch() throws Exception {
                                                                                    // Setup test buffer with partial keyword "tru"
                                                                                    String partialKeyword = "tru";
                                                                                    
                                                                                    // Use reflection to access private peekKeyword method
                                                                                    // Verify that the partial match was detected
                                                                                    // Assuming peekKeyword returns the length of matched keyword portion
                                                                                }

    @Test
                                                                                public void testPeekKeyword_FollowedByLiteral() throws Exception {
                                                                                    // Setup test buffer with "truex" where x is a literal character
                                                                                    String testData = "truex";
                                                                                
                                                                                    // Use reflection to access private peekKeyword method
                                                                                    // Verify the result (assuming peekKeyword returns the length of matched keyword)
                                                                                }

    @Test
                                                                                public void testPeekKeyword_NeedsBufferRefill() throws Exception {
                                                                                    // Setup test buffer and reader
                                                                                    char[] testBuffer = new char[4];
                                                                                    
                                                                                    
                                                                                    // Use reflection to access private fields
{
                                                                                        System.arraycopy(testBuffer, 0, (char[])invocation.getArgument(0), 0, testBuffer.length);
}
                                                                                    
                                                                                    // Use reflection to access and test peekKeyword
                                                                                }

    @Test
                                                                                public void testPeekKeyword_AtBufferEnd() throws Exception {
                                                                                    // Setup test buffer with "true" at the end
                                                                                    char[] testBuffer = new char[1024];
                                                                                    
                                                                                    // Create a reader with our test buffer
                                                                                    
                                                                                    // Use reflection to access private peekKeyword method
                                                                                }

    @Test
                                                                                public void testPeekKeyword_TrueLowerCase() throws Exception {
                                                                                    // Setup
                                                                                    char[] testBuffer = {'t', 'r', 'u', 'e'};
                                                                                    
                                                                                    // Use reflection to access private buffer field
                                                                                    
                                                                                }


}
