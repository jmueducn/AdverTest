package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
 
public class JsonTreeWriterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testValue_String_WhenClosed() throws Exception {
                    // Create JsonTreeWriter instance
                    JsonTreeWriter writer = new JsonTreeWriter();
                    
                    // Use reflection to access private SENTINEL_CLOSED field
                    Field sentinelClosedField = JsonTreeWriter.class.getDeclaredField("SENTINEL_CLOSED");
                    sentinelClosedField.setAccessible(true);
                    Object sentinelClosed = sentinelClosedField.get(null);
                    
                    // Create mock stack and add SENTINEL_CLOSED to simulate closed state
                    Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                    stackField.setAccessible(true);
                    List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                    stack.add((JsonElement) sentinelClosed);
                    
                    // Verify exception is thrown when trying to write value in closed state
                    thrown.expect(IllegalStateException.class);
                    writer.value("test");
                }

    @Test
                public void testValue_String_WhenInObjectWithoutName() throws Exception {
                    // Create writer and mock stack
                    JsonTreeWriter writer = new JsonTreeWriter();
                    List<JsonElement> mockStack = new ArrayList<>();
                    
                    // Simulate object context without pending name
                    mockStack.add(new JsonPrimitive("object_marker"));
                    
                    // Use reflection to set pendingName to null
                    Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                    pendingNameField.setAccessible(true);
                    pendingNameField.set(writer, null);
                    
                    // Set up expectation for exception
                    thrown.expect(IllegalStateException.class);
                    
                    // Call the method that should throw exception
                    writer.value("test");
                }

    @Test
                public void testValueBoolean_WorksWithFalseValue() throws Exception {
                    JsonTreeWriter writer = new JsonTreeWriter();
                    writer.value(false);
                    
                    // Use reflection to access private peek() method
                    Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                    peekMethod.setAccessible(true);
                    JsonElement element = (JsonElement) peekMethod.invoke(writer);
                    
                    assertFalse(element.getAsBoolean());
                }

    @Test
                public void testValueBoolean_AfterBeginArray() throws Exception {
                    JsonTreeWriter writer = new JsonTreeWriter();
                    writer.beginArray();
                    writer.value(true);
                    
                    // Use reflection to access private peek() method
                    Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                    peekMethod.setAccessible(true);
                    JsonElement array = (JsonElement) peekMethod.invoke(writer);
                    
                    assertTrue(array instanceof JsonArray);
                    JsonArray jsonArray = (JsonArray) array;
                    assertEquals(1, jsonArray.size());
                    assertTrue(jsonArray.get(0).getAsBoolean());
                }

    @Test
                public void testValue_Double_SpecialValues_WhenLenient() {
                    JsonTreeWriter writer = new JsonTreeWriter();
                    // Make writer lenient (assuming there's a way to set lenient mode)
                    // This might require reflection since we don't see a setLenient method
                    try {
                        java.lang.reflect.Field lenientField = JsonWriter.class.getDeclaredField("lenient");
                        lenientField.setAccessible(true);
                        lenientField.set(writer, true);
                        
                        // Test that special values are accepted when lenient
                        JsonWriter result = writer.value(Double.NaN);
                        assertSame(writer, result);
                        
                        result = writer.value(Double.POSITIVE_INFINITY);
                        assertSame(writer, result);
                        
                        result = writer.value(Double.NEGATIVE_INFINITY);
                        assertSame(writer, result);
                    } catch (Exception e) {
                        fail("Failed to set lenient mode via reflection");
                    }
                }

    @Test
            public void testValueBoolean_MultipleValues() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                writer.beginArray();
                writer.value(true);
                writer.value(false);
                writer.endArray();
                
                // Get private stack field via reflection
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                assertEquals(3, stack.size()); // Array and two values
                JsonElement first = stack.get(1);
                JsonElement second = stack.get(2);
                
                assertTrue(first instanceof JsonPrimitive);
                assertTrue(second instanceof JsonPrimitive);
                assertEquals(true, ((JsonPrimitive) first).getAsBoolean());
                assertEquals(false, ((JsonPrimitive) second).getAsBoolean());
            }

    @Test
            public void testValue_ValidInteger_AddsToStack() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access the private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                writer.value(42);
                assertEquals(1, mockStack.size());
                JsonPrimitive primitive = (JsonPrimitive) mockStack.get(0);
                assertEquals(42, primitive.getAsInt());
            }

    @Test
            public void testValue_NaNInStrictMode_ThrowsException() throws Exception {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("JSON forbids NaN and infinities: NaN");
                
                // Create regular writer
                JsonTreeWriter strictWriter = new JsonTreeWriter();
                
                // Use reflection to make writer strict (non-lenient)
                Field lenientField = JsonTreeWriter.class.getDeclaredField("lenient");
                lenientField.setAccessible(true);
                lenientField.setBoolean(strictWriter, false);
                
                strictWriter.value(Double.NaN);
            }

    @Test
            public void testValue_InfiniteInStrictMode_ThrowsException() throws Exception {
                thrown.expect(IllegalArgumentException.class);
                thrown.expectMessage("JSON forbids NaN and infinities: Infinity");
                
                // Create regular writer
                JsonTreeWriter strictWriter = new JsonTreeWriter();
                
                // Use reflection to make writer strict (non-lenient)
                Field lenientField = JsonWriter.class.getDeclaredField("lenient");
                lenientField.setAccessible(true);
                lenientField.set(strictWriter, false);
                
                strictWriter.value(Double.POSITIVE_INFINITY);
            }

    @Test
            public void testValue_NaNInLenientMode_AddsToStack() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                writer.setLenient(true);
                
                // Use reflection to access the private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                writer.value(Double.NaN);
                assertEquals(1, mockStack.size());
                JsonPrimitive primitive = (JsonPrimitive) mockStack.get(0);
                assertTrue(Double.isNaN(primitive.getAsDouble()));
            }

    @Test
            public void testValue_InfiniteInLenientMode_AddsToStack() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                writer.setLenient(true);
                
                // Use reflection to access the private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                writer.value(Double.NEGATIVE_INFINITY);
                assertEquals(1, mockStack.size());
                JsonPrimitive primitive = (JsonPrimitive) mockStack.get(0);
                assertTrue(Double.isInfinite(primitive.getAsDouble()));
            }

    @Test
            public void testValue_ZeroValues_AddsToStack() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                writer.value(0);
                writer.value(0.0);
                
                assertEquals(2, stack.size());
                assertEquals(0, ((JsonPrimitive)stack.get(0)).getAsInt());
                assertEquals(0.0, ((JsonPrimitive)stack.get(1)).getAsDouble(), 0.0);
            }

    @Test
            public void testValue_MaxMinValues_AddsToStack() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access the private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                writer.value(Integer.MAX_VALUE);
                writer.value(Integer.MIN_VALUE);
                writer.value(Double.MAX_VALUE);
                writer.value(Double.MIN_VALUE);
                
                assertEquals(4, mockStack.size());
                assertEquals(Integer.MAX_VALUE, ((JsonPrimitive)mockStack.get(0)).getAsInt());
                assertEquals(Integer.MIN_VALUE, ((JsonPrimitive)mockStack.get(1)).getAsInt());
                assertEquals(Double.MAX_VALUE, ((JsonPrimitive)mockStack.get(2)).getAsDouble(), 0.0);
                assertEquals(Double.MIN_VALUE, ((JsonPrimitive)mockStack.get(3)).getAsDouble(), 0.0);
            }

    @Test
            public void testValue_String_NullInput() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access private stack field for verification
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                JsonTreeWriter result = (JsonTreeWriter) writer.value((String) null);
                
                // Verify nullValue() was called
                assertSame(writer, result);
                assertTrue(stack.isEmpty()); // No value should be added to stack
            }

    @Test
            public void testValue_String_EmptyString() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access the private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                JsonWriter result = writer.value("");
                
                assertSame(writer, result);
                assertEquals(1, mockStack.size());
                JsonPrimitive primitive = (JsonPrimitive) mockStack.get(0);
                assertEquals("", primitive.getAsString());
            }

    @Test
            public void testValue_String_RegularString() throws Exception {
                String testValue = "test string";
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Get the private stack field using reflection
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                writer.value(testValue);
                
                assertSame(writer, writer);
                assertEquals(1, stack.size());
                JsonPrimitive primitive = (JsonPrimitive) stack.get(0);
                assertEquals(testValue, primitive.getAsString());
            }

    @Test
            public void testValue_String_SpecialCharacters() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                String testValue = "line1\\nline2\\t tab \\\\ backslash \\\" quote";
                
                // Get the private stack field using reflection
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                JsonTreeWriter result = (JsonTreeWriter) writer.value(testValue);
                
                assertSame(writer, result);
                assertEquals(1, stack.size());
                JsonPrimitive primitive = (JsonPrimitive) stack.get(0);
                assertEquals(testValue, primitive.getAsString());
            }

    @Test
            public void testValue_String_WhenInArray() throws Exception {
                // Create JsonTreeWriter instance
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                // Simulate array context
                mockStack.add(new JsonPrimitive("array_marker"));
                
                String testValue = "array_value";
                JsonTreeWriter result = (JsonTreeWriter) writer.value(testValue);
                
                assertSame(writer, result);
                assertEquals(2, mockStack.size());
                JsonPrimitive primitive = (JsonPrimitive) mockStack.get(1);
                assertEquals(testValue, primitive.getAsString());
            }

    @Test
            public void testValue_String_WhenInObjectWithName() throws Exception {
                // Create JsonTreeWriter instance
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Use reflection to access private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> mockStack = (List<JsonElement>) stackField.get(writer);
                
                // Use reflection to access pendingName field
                Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                pendingNameField.setAccessible(true);
                
                // Simulate object context with pending name
                mockStack.add(new JsonPrimitive("object_marker"));
                String propertyName = "testProperty";
                pendingNameField.set(writer, propertyName);
                
                String testValue = "property_value";
                JsonTreeWriter result = (JsonTreeWriter) writer.value(testValue);
                
                assertSame(writer, result);
                // Should add both name and value (implementation detail of put method)
                // Assuming put handles this, we just verify the last added element
                assertEquals(2, mockStack.size());
                JsonPrimitive primitive = (JsonPrimitive) mockStack.get(1);
                assertEquals(testValue, primitive.getAsString());
                assertNull(pendingNameField.get(writer)); // Should be cleared after writing value
            }

    @Test
            public void testValueBoolean_AddsPrimitiveToStack() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
                assertSame(writer, result); // Verify method chaining
                
                // Use reflection to access private peek() method
                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                peekMethod.setAccessible(true);
                JsonElement element = (JsonElement) peekMethod.invoke(writer);
                
                assertTrue(element instanceof JsonPrimitive);
                assertEquals(true, element.getAsBoolean());
            }

    @Test
            public void testValue_BooleanTrue() throws Exception {
                // Setup
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Execute
                JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
                
                // Verify
                assertSame(writer, result);
                
                // Use reflection to access private peek() method
                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                peekMethod.setAccessible(true);
                JsonElement actual = (JsonElement) peekMethod.invoke(writer);
                assertEquals(new JsonPrimitive(true), actual);
            }

    @Test
            public void testValue_BooleanFalse() throws Exception {
                // Setup
                JsonTreeWriter writer = new JsonTreeWriter();
                
                // Execute
                JsonWriter result = writer.value(false);
                
                // Verify
                assertSame(writer, result);
                
                // Use reflection to access private peek() method
                Method peekMethod = JsonTreeWriter.class.getDeclaredMethod("peek");
                peekMethod.setAccessible(true);
                JsonElement actualValue = (JsonElement) peekMethod.invoke(writer);
                assertEquals(new JsonPrimitive(false), actualValue);
            }

    @Test
            public void testValueBoolean_TrueValue() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
                
                assertSame(writer, result); // Should return this
                
                // Use reflection to access private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                assertEquals(1, stack.size());
                JsonElement element = stack.get(0);
                assertTrue(element instanceof JsonPrimitive);
                assertEquals(true, ((JsonPrimitive) element).getAsBoolean());
            }

    @Test
            public void testValueBoolean_FalseValue() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                JsonWriter result = writer.value(false);
                
                assertSame(writer, result); // Should return this
                
                // Use reflection to access private stack field
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                @SuppressWarnings("unchecked")
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                assertEquals(1, stack.size());
                JsonElement element = stack.get(0);
                assertTrue(element instanceof JsonPrimitive);
                assertEquals(false, ((JsonPrimitive) element).getAsBoolean());
            }

    @Test
            public void testValueBoolean_AfterBeginArray1() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                writer.beginArray();
                JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
                
                assertSame(writer, result);
                
                // Access private stack field using reflection
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                
                assertEquals(2, stack.size()); // Array and the value
                JsonElement element = stack.get(1);
                assertTrue(element instanceof JsonPrimitive);
                assertEquals(true, ((JsonPrimitive) element).getAsBoolean());
            }

    @Test
            public void testValueBoolean_AfterBeginObjectWithName1() throws Exception {
                JsonTreeWriter writer = new JsonTreeWriter();
                writer.beginObject();
                writer.name("test");
                writer.value(true);
                
                assertSame(writer, writer); // Verify we're working with the same writer
                
                // Access private stack field using reflection
                Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
                stackField.setAccessible(true);
                List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
                assertEquals(2, stack.size()); // Object and the value
                
                JsonElement element = stack.get(1);
                assertTrue(element instanceof JsonPrimitive);
                assertEquals(true, ((JsonPrimitive) element).getAsBoolean());
                
                // Access private pendingName field using reflection
                Field pendingNameField = JsonTreeWriter.class.getDeclaredField("pendingName");
                pendingNameField.setAccessible(true);
                assertNull(pendingNameField.get(writer)); // Name should be cleared
            }

    @Test
        public void testValueBoolean_WithNullProduct() throws Exception {
            // Create new JsonTreeWriter instance
            JsonTreeWriter writer = new JsonTreeWriter();
            
            // Use reflection to set the private product field to null
            Field productField = JsonTreeWriter.class.getDeclaredField("product");
            productField.setAccessible(true);
            productField.set(writer, null);
            
            // Test the value method
            JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
            
            // Verify results
            assertSame(writer, result);
            
            // Use reflection to access the private stack field
            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
            stackField.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
            
            assertEquals(1, stack.size());
            JsonElement element = stack.get(0);
            assertTrue(element instanceof JsonPrimitive);
            assertEquals(true, ((JsonPrimitive) element).getAsBoolean());
        }

    @Test
        public void testValueBoolean_WithExistingProduct() throws Exception {
            // Set up existing product
            JsonTreeWriter writer = new JsonTreeWriter();
            JsonPrimitive existing = new JsonPrimitive("existing");
            
            // Use reflection to set private product field
            Field productField = JsonTreeWriter.class.getDeclaredField("product");
            productField.setAccessible(true);
            productField.set(writer, existing);
            
            JsonTreeWriter result = (JsonTreeWriter) writer.value(true);
            
            assertSame(writer, result);
            
            // Use reflection to access private stack field
            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
            stackField.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<JsonElement> stack = (List<JsonElement>) stackField.get(writer);
            
            assertEquals(1, stack.size());
            JsonElement element = stack.get(0);
            assertTrue(element instanceof JsonPrimitive);
            assertEquals(true, ((JsonPrimitive) element).getAsBoolean());
            
            // Existing product should be replaced
            assertNotSame(existing, productField.get(writer));
        }

    @Test
    public void testValue_Double_NaN_WhenNotLenient() {
        JsonTreeWriter writer = new JsonTreeWriter();
        
        // Set up exception expectation
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("JSON forbids NaN and infinities: NaN");
        
        try {
            writer.value(Double.NaN);
        } catch (IOException e) {
            // Should not happen in this test case
            throw new AssertionError("Unexpected IOException", e);
        }
    }

    @Test
    public void testValue_Double_PositiveInfinity_WhenNotLenient() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("JSON forbids NaN and infinities: Infinity");
        
        writer.value(Double.POSITIVE_INFINITY);
    }

    @Test
    public void testValue_Double_NegativeInfinity_WhenNotLenient() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("JSON forbids NaN and infinities: -Infinity");
        
        try {
            writer.value(Double.NEGATIVE_INFINITY);
        } catch (IOException e) {
            fail("Unexpected IOException: " + e.getMessage());
        }
    }

    @Test
    public void testValueBoolean_AfterBeginObjectWithoutName() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        ExpectedException thrown = ExpectedException.none();
        writer.beginObject();
        thrown.expect(IllegalStateException.class);
        writer.value(true); // Should throw because we haven't set a name
    }

    @Test
    public void testValueBoolean_AfterClose() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.close();
        try {
            writer.value(true);
            fail("Expected IOException to be thrown");
        } catch (IOException expected) {
            // Expected exception
        }
    }

    @Test
    public void testValue_Double_ValidValues() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        
        // Test with regular double values
        JsonTreeWriter result = (JsonTreeWriter) writer.value(3.14);
        assertSame(writer, result); // Should return this
        
        // Test with zero
        result = (JsonTreeWriter) writer.value(0.0);
        assertSame(writer, result);
        
        // Test with negative value
        result = (JsonTreeWriter) writer.value(-2.5);
        assertSame(writer, result);
        
        // Test with max double value
        result = (JsonTreeWriter) writer.value(Double.MAX_VALUE);
        assertSame(writer, result);
        
        // Test with min double value
        result = (JsonTreeWriter) writer.value(Double.MIN_VALUE);
        assertSame(writer, result);
    }

    @Test
    public void testValue_Double_VerifyPutCalled() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        
        writer.value(1.23);
        
        // Verify the result by checking the final JSON output
        JsonElement result = writer.get();
        assertTrue(result instanceof JsonPrimitive);
        assertEquals(1.23, ((JsonPrimitive) result).getAsDouble(), 0.0001);
    }

    @Test(expected = IllegalStateException.class)
    public void testValueBoolean_AfterBeginObjectWithoutName1() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.beginObject();
        writer.value(true); // Should throw because we didn't set a name first
    }

    @Test
    public void testValueBoolean_AfterClose1() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.close();
        thrown.expect(IllegalStateException.class);
        writer.value(true); // Should throw because writer is closed
    }

    @Test
    public void testValue_NullInput_CallsNullValue() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        JsonTreeWriter spyWriter = spy(writer);
        spyWriter.value((Number)null);
        verify(spyWriter).nullValue();
    }

    @Test
    public void testValue_ValidDouble_AddsToStack() {
        JsonTreeWriter writer = new JsonTreeWriter();
        List<JsonElement> mockStack = new ArrayList<>();
        
        // Use reflection to set the private stack field
        try {
            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
            stackField.setAccessible(true);
            stackField.set(writer, mockStack);
        } catch (Exception e) {
            fail("Failed to set up test due to reflection error: " + e.getMessage());
        }
        
        try {
            writer.value(3.14);
            assertEquals(1, mockStack.size());
            JsonPrimitive primitive = (JsonPrimitive) mockStack.get(0);
            assertEquals(3.14, primitive.getAsDouble(), 0.0001);
        } catch (IOException e) {
            fail("Unexpected IOException: " + e.getMessage());
        }
    }

    @Test
    public void testValue_DifferentNumberTypes_AddsToStack() {
        JsonTreeWriter writer = new JsonTreeWriter();
        List<JsonElement> mockStack = new ArrayList<>();
        
        // Use reflection to access private stack field
        try {
            Field stackField = JsonTreeWriter.class.getDeclaredField("stack");
            stackField.setAccessible(true);
            stackField.set(writer, mockStack);
        } catch (Exception e) {
            fail("Failed to set up test due to reflection error: " + e.getMessage());
        }
        
        try {
            writer.value(Integer.valueOf(10));
            writer.value(Double.valueOf(10.5));
            writer.value(Long.valueOf(Long.MAX_VALUE));
            writer.value(Float.valueOf(3.14f));
        } catch (IOException e) {
            fail("Unexpected IOException: " + e.getMessage());
        }
        
        assertEquals(4, mockStack.size());
        assertEquals(10, ((JsonPrimitive)mockStack.get(0)).getAsInt());
        assertEquals(10.5, ((JsonPrimitive)mockStack.get(1)).getAsDouble(), 0.0);
        assertEquals(Long.MAX_VALUE, ((JsonPrimitive)mockStack.get(2)).getAsLong());
        assertEquals(3.14f, ((JsonPrimitive)mockStack.get(3)).getAsFloat(), 0.0f);
    }

    @Test
    public void testValueBoolean_AfterBeginObjectWithName() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.beginObject();
        writer.name("test");
        writer.value(false);
        JsonElement object = writer.get();
        assertTrue(object instanceof JsonObject);
        JsonObject jsonObject = (JsonObject) object;
        assertTrue(jsonObject.has("test"));
        assertFalse(jsonObject.get("test").getAsBoolean());
    }

    @Test
    public void testValueBoolean_MultipleValuesInArray() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.beginArray()
            .value(true)
            .value(false)
            .endArray();
        
        JsonElement array = writer.get();
        JsonArray jsonArray = (JsonArray) array;
        assertEquals(2, jsonArray.size());
        assertTrue(jsonArray.get(0).getAsBoolean());
        assertFalse(jsonArray.get(1).getAsBoolean());
    }

    @Test
    public void testValueBoolean_InNestedStructures() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.beginObject()
                .name("array")
                .beginArray()
                    .value(true)
                    .value(false)
                .endArray()
                .name("flag")
                .value(true)
                .endObject();
        
        JsonElement object = writer.get();
        JsonObject jsonObject = (JsonObject) object;
        
        // Verify array contents
        JsonArray array = jsonObject.getAsJsonArray("array");
        assertEquals(2, array.size());
        assertTrue(array.get(0).getAsBoolean());
        assertFalse(array.get(1).getAsBoolean());
        
        // Verify direct boolean value
        assertTrue(jsonObject.get("flag").getAsBoolean());
    }

    @Test
    public void testValue_BooleanAfterName() throws IOException {
        // Setup
        JsonTreeWriter writer = new JsonTreeWriter();
        writer.name("test");
        
        // Execute
        writer.value(true);
        
        // Verify
        JsonElement element = writer.get();
        assertTrue(element.isJsonObject());
        JsonObject obj = element.getAsJsonObject();
        assertTrue(obj.has("test"));
        assertTrue(obj.get("test").getAsBoolean());
    }

    @Test
    public void testValue_BooleanInArray() {
        // Setup
        JsonTreeWriter writer = new JsonTreeWriter();
        try {
            writer.beginArray();
            
            // Execute
            JsonWriter result = writer.value(true);
            
            // Verify
            assertSame(writer, result);
            JsonElement element = writer.get();
            assertTrue(element.isJsonArray());
            JsonArray array = element.getAsJsonArray();
            assertEquals(1, array.size());
            assertTrue(array.get(0).getAsBoolean());
        } catch (IOException e) {
            fail("Unexpected IOException: " + e.getMessage());
        }
    }

    @Test
    public void testValue_ReturnsThis() throws IOException {
        JsonTreeWriter writer = new JsonTreeWriter();
        JsonTreeWriter result = (JsonTreeWriter) writer.value(123);
        assertSame(writer, result);
    }

    @Test
    public void testValue_BooleanNull() throws IOException {
        // Setup
        JsonTreeWriter writer = new JsonTreeWriter();
        JsonTreeWriter spyWriter = spy(writer);
        doReturn((JsonTreeWriter)spyWriter).when(spyWriter).nullValue();
        
        // Execute
        JsonTreeWriter result = (JsonTreeWriter)spyWriter.value((Boolean)null);
        
        // Verify
        verify(spyWriter).nullValue();
        assertSame(spyWriter, result);
    }


}
