package gentest.com.google.gson.stream.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.stream.*;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
 
public class JsonWriterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testValueBoolean_TrueValue() throws Exception {
                                                                                            // Arrange
                                                                                            Writer writer = mock(Writer.class);
                                                                                            JsonWriter jsonWriter = new JsonWriter(writer);
                                                                                            
                                                                                            // Act
                                                                                            JsonWriter result = jsonWriter.value(true);
                                                                                            
                                                                                            // Assert
                                                                                            verify(writer).write("true");
                                                                                            assertSame(jsonWriter, result);
                                                                                        }

    @Test
                                                                                        public void testValueBoolean_FalseValue() throws Exception {
                                                                                            // Arrange
                                                                                            Writer writer = mock(Writer.class);
                                                                                            JsonWriter jsonWriter = new JsonWriter(writer);
                                                                                            
                                                                                            // Act
                                                                                            JsonWriter result = jsonWriter.value(false);
                                                                                            
                                                                                            // Assert
                                                                                            verify(writer).write("false");
                                                                                            assertSame(jsonWriter, result);
                                                                                        }

    @Test
                                                                                        public void testValueBoolean_WithDeferredName() throws Exception {
                                                                                            // Arrange
                                                                                            Writer writer = mock(Writer.class);
                                                                                            JsonWriter jsonWriter = new JsonWriter(writer);
                                                                                            jsonWriter.name("testName");
                                                                                            
                                                                                            // Act
                                                                                            jsonWriter.value(true);
                                                                                            
                                                                                            // Assert
                                                                                            verify(writer).write("\"testName\":");
                                                                                            verify(writer).write("true");
                                                                                        }

    @Test
                                                                                        public void testValueBoolean_IOException() throws Exception {
                                                                                            // Arrange
                                                                                            Writer writer = mock(Writer.class);
                                                                                            doThrow(new java.io.IOException("Test exception")).when(writer).write(anyString());
                                                                                            JsonWriter jsonWriter = new JsonWriter(writer);
                                                                                            
                                                                                            thrown.expect(java.io.IOException.class);
                                                                                            thrown.expectMessage("Test exception");
                                                                                            
                                                                                            // Act
                                                                                            jsonWriter.value(true);
                                                                                        }

    @Test
                                                                                        public void testValueLong_VerifyWriterInteraction() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter jsonWriter = new JsonWriter(mockWriter);
                                                                                            
                                                                                            jsonWriter.value(123L);
                                                                                            verify(mockWriter).write("123");
                                                                                        }

    @Test
                                                                                        public void testValueLong_ExceptionFromWriter() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            doThrow(new IOException("Test exception")).when(mockWriter).write(anyString());
                                                                                            JsonWriter jsonWriter = new JsonWriter(mockWriter);
                                                                                            
                                                                                            thrown.expect(IOException.class);
                                                                                            thrown.expectMessage("Test exception");
                                                                                            jsonWriter.value(123L);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_ValidInteger() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            Number value = 42;
                                                                                            
                                                                                            JsonWriter result = writer.value(value);
                                                                                            
                                                                                            verify(mockWriter).append("42");
                                                                                            assertSame(writer, result);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_ValidDouble() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            Number value = 3.14159;
                                                                                            
                                                                                            JsonWriter result = writer.value(value);
                                                                                            
                                                                                            verify(mockWriter).append("3.14159");
                                                                                            assertSame(writer, result);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_Infinity_StrictMode() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            writer.setLenient(false);
                                                                                            Number value = Double.POSITIVE_INFINITY;
                                                                                            
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Numeric values must be finite, but was Infinity");
                                                                                            
                                                                                            writer.value(value);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_Infinity_LenientMode() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            writer.setLenient(true);
                                                                                            Number value = Double.POSITIVE_INFINITY;
                                                                                            
                                                                                            JsonWriter result = writer.value(value);
                                                                                            
                                                                                            verify(mockWriter).append("Infinity");
                                                                                            assertSame(writer, result);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_NaN_StrictMode() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            writer.setLenient(false);
                                                                                            Number value = Double.NaN;
                                                                                            
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Numeric values must be finite, but was NaN");
                                                                                            
                                                                                            writer.value(value);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_NaN_LenientMode() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            writer.setLenient(true);
                                                                                            Number value = Double.NaN;
                                                                                            
                                                                                            JsonWriter result = writer.value(value);
                                                                                            
                                                                                            verify(mockWriter).append("NaN");
                                                                                            assertSame(writer, result);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_NegativeInfinity_StrictMode() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            writer.setLenient(false);
                                                                                            Number value = Double.NEGATIVE_INFINITY;
                                                                                            
                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                            thrown.expectMessage("Numeric values must be finite, but was -Infinity");
                                                                                            
                                                                                            writer.value(value);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_Zero() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            Number value = 0;
                                                                                            
                                                                                            JsonWriter result = writer.value(value);
                                                                                            
                                                                                            verify(mockWriter).append("0");
                                                                                            assertSame(writer, result);
                                                                                        }

    @Test
                                                                                        public void testValue_Number_LargeValue() throws Exception {
                                                                                            Writer mockWriter = mock(Writer.class);
                                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                                            Number value = Long.MAX_VALUE;
                                                                                            
                                                                                            JsonWriter result = writer.value(value);
                                                                                            
                                                                                            verify(mockWriter).append("9223372036854775807");
                                                                                            assertSame(writer, result);
                                                                                        }

    @Test
                                                                                public void testValue_DeferredNamePresent_WritesNameFirst() throws Exception {
                                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                                    com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                                    
                                                                                    // Using reflection to set deferredName since it's private
                                                                                    // This is a workaround for testing private fields
                                                                                    try {
                                                                                        java.lang.reflect.Field field = com.google.gson.stream.JsonWriter.class.getDeclaredField("deferredName");
                                                                                        field.setAccessible(true);
                                                                                        field.set(jsonWriter, "name");
                                                                                    } catch (Exception e) {
                                                                                        throw new RuntimeException(e);
                                                                                    }
                                                                                    
                                                                                    jsonWriter.value("value");
                                                                                    
                                                                                    assert(stringWriter.toString().equals("\"name\":\"value\""));
                                                                                }

    @Test
                                                                                public void testValue_WriteFails_ThrowsIOException() throws Exception {
                                                                                    Writer mockWriter = mock(Writer.class);
                                                                                    ExpectedException expectedException = ExpectedException.none();
                                                                                    
                                                                                    doThrow(new java.io.IOException("Mocked IO exception"))
                                                                                        .when(mockWriter).write(anyString());
                                                                                    JsonWriter jsonWriter = new JsonWriter(mockWriter);
                                                                                    
                                                                                    expectedException.expect(java.io.IOException.class);
                                                                                    jsonWriter.value("test");
                                                                                }

    @Test
                                                                                public void testValueBoolean_IOExceptionDuringWrite() throws IOException {
                                                                                    Writer mockWriter = mock(Writer.class);
                                                                                    JsonWriter jsonWriter = new JsonWriter(mockWriter);
                                                                                    doThrow(new IOException("Simulated IO error")).when(mockWriter).write(anyString());
                                                                                    
                                                                                    ExpectedException expectedException = ExpectedException.none();
                                                                                    expectedException.expect(IOException.class);
                                                                                    expectedException.expectMessage("Simulated IO error");
                                                                                    
                                                                                    jsonWriter.value(true);
                                                                                }

    @Test
                                                                        public void testValueLong_TypicalValues() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            com.google.gson.stream.JsonWriter result = jsonWriter.value(12345L);
                                                                            assertEquals(jsonWriter, result);
                                                                            assertEquals("12345", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_Zero() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.value(0L);
                                                                            assertEquals("0", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_MaxValue() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.value(Long.MAX_VALUE);
                                                                            org.junit.Assert.assertEquals("9223372036854775807", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_MinValue() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.value(Long.MIN_VALUE);
                                                                            assertEquals("-9223372036854775808", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_NegativeValue() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.value(-987654321L);
                                                                            assertEquals("-987654321", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_WithDeferredName() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            jsonWriter.name("test");
                                                                            jsonWriter.value(42L);
                                                                            assertEquals("\"test\":42", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_Chaining() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.value(1L).value(2L).value(3L);
                                                                            assertEquals("123", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_AfterBeginArray() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.beginArray().value(1L).value(2L).endArray();
                                                                            assertEquals("[1,2]", writer.toString());
                                                                        }

    @Test
                                                                        public void testValueLong_AfterBeginObject() throws Exception {
                                                                            java.io.Writer writer = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                                            
                                                                            jsonWriter.beginObject().name("num").value(123L).endObject();
                                                                            assertEquals("{\"num\":123}", writer.toString());
                                                                        }

    @Test
                                                                        public void testValue_Number_NullValue() throws Exception {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter writer = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            writer.nullValue(); // Setup expected null value behavior
                                                                            com.google.gson.stream.JsonWriter result = writer.value((Number)null);
                                                                            // Verify null case returns nullValue() result
                                                                            assertSame(writer, result);
                                                                        }

    @Test
                                                                        public void testValue_Number_CallsBeforeValue() throws Exception {
                                                                            Writer mockWriter = mock(Writer.class);
                                                                            JsonWriter writer = new JsonWriter(mockWriter);
                                                                            Number value = 123;
                                                                            
                                                                            writer.value(value);
                                                                            
                                                                            // Verify that the value was properly written to the output
                                                                            verify(mockWriter).write(eq("123"));
                                                                        }

    @Test
                                                                        public void testValue_NullInput_ReturnsNullValue() throws Exception {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.setSerializeNulls(true);
                                                                            
                                                                            com.google.gson.stream.JsonWriter result = jsonWriter.value((String)null);
                                                                            
                                                                            // Verify nullValue() was called by checking output contains "null"
                                                                            assertTrue(stringWriter.toString().contains("null"));
                                                                        }

    @Test
                                                                        public void testValue_EmptyString_WritesCorrectly() throws Exception {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            
                                                                            jsonWriter.value("");
                                                                            
                                                                            assertEquals("\"\"", stringWriter.toString());
                                                                        }

    @Test
                                                                        public void testValue_RegularString_WritesCorrectly() throws Exception {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            
                                                                            jsonWriter.value("test");
                                                                            
                                                                            assertEquals("\"test\"", stringWriter.toString());
                                                                        }

    @Test
                                                                        public void testValue_StringWithSpecialChars_WritesEscaped() throws Exception {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            
                                                                            jsonWriter.value("line\nbreak");
                                                                            
                                                                            assertEquals("\"line\\nbreak\"", stringWriter.toString());
                                                                        }

    @Test
                                                                        public void testValue_StringNeedsHtmlEscaping_WritesEscapedWhenHtmlSafe() throws Exception {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.setHtmlSafe(true);
                                                                            
                                                                            jsonWriter.value("<script>");
                                                                            
                                                                            assertEquals("\"\\u003cscript\\u003e\"", stringWriter.toString());
                                                                        }

    @Test
                                                                        public void testValueBoolean_TrueValue1() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.value(true);
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("true", result);
                                                                        }

    @Test
                                                                        public void testValueBoolean_FalseValue1() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.value(false);
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("false", result);
                                                                        }

    @Test
                                                                        public void testValueBoolean_WithDeferredName1() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            // Set up deferred name
                                                                            jsonWriter.name("testField");
                                                                            jsonWriter.value(true);
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("\"testField\":true", result);
                                                                        }

    @Test
                                                                        public void testValueBoolean_WithNullWriter() {
                                                                            try {
                                                                                fail("Expected NullPointerException");
                                                                            } catch (NullPointerException e) {
                                                                                assertEquals("out == null", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testValueBoolean_Chaining() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            com.google.gson.stream.JsonWriter returnedWriter = jsonWriter.value(true);
                                                                            
                                                                            assertSame(jsonWriter, returnedWriter);
                                                                        }

    @Test
                                                                        public void testValueBoolean_InArrayContext() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.beginArray()
                                                                                     .value(true)
                                                                                     .value(false)
                                                                                     .endArray();
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("[true,false]", result);
                                                                        }

    @Test
                                                                        public void testValueBoolean_InObjectContext() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.beginObject()
                                                                                     .name("flag1").value(true)
                                                                                     .name("flag2").value(false)
                                                                                     .endObject();
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("{\"flag1\":true,\"flag2\":false}", result);
                                                                        }

    @Test
                                                                        public void testValueBoolean_BoxedBoolean() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                            jsonWriter.value(Boolean.TRUE);
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("true", result);
                                                                        }

    @Test
                                                                        public void testValueBoolean_NullBoolean() throws IOException {
                                                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                            JsonWriter jsonWriter = new JsonWriter(stringWriter);
                                                                            jsonWriter.value((Boolean)null);
                                                                            
                                                                            String result = stringWriter.toString();
                                                                            assertEquals("null", result);
                                                                        }

    @Test
                                                                    public void testValueDouble_WritesValidDouble() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        com.google.gson.stream.JsonWriter result = jsonWriter.value(123.456);
                                                                        
                                                                        assertSame(jsonWriter, result);
                                                                        assertEquals("123.456", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_WritesZero() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.value(0.0);
                                                                        
                                                                        assertEquals("0.0", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_WritesNegativeValue() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.value(-123.456);
                                                                        
                                                                        assertEquals("-123.456", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_WritesMaxDouble() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.value(Double.MAX_VALUE);
                                                                        
                                                                        assertEquals("1.7976931348623157E308", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_WritesMinDouble() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.value(Double.MIN_VALUE);
                                                                        
                                                                        assertEquals("4.9E-324", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_ThrowsExceptionForNaNWhenNotLenient() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.setLenient(false);
                                                                        
                                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("Numeric values must be finite, but was NaN");
                                                                        jsonWriter.value(Double.NaN);
                                                                    }

    @Test
                                                                    public void testValueDouble_ThrowsExceptionForPositiveInfinityWhenNotLenient() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.setLenient(false);
                                                                        
                                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("Numeric values must be finite, but was Infinity");
                                                                        jsonWriter.value(Double.POSITIVE_INFINITY);
                                                                    }

    @Test
                                                                    public void testValueDouble_AllowsNaNWhenLenient() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.setLenient(true);
                                                                        jsonWriter.value(Double.NaN);
                                                                        
                                                                        assertEquals("NaN", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_AllowsInfinityWhenLenient() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.setLenient(true);
                                                                        jsonWriter.value(Double.POSITIVE_INFINITY);
                                                                        
                                                                        assertEquals("Infinity", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValueDouble_WritesDeferredNameFirst() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        jsonWriter.beginObject();  // Need to start object for name-value pairs
                                                                        jsonWriter.name("testName");
                                                                        jsonWriter.value(42.0);
                                                                        jsonWriter.endObject();  // Need to properly close the object
                                                                        
                                                                        assertEquals("{\"testName\":42.0}", stringWriter.toString());
                                                                    }

    @Test
                                                                    public void testValue_Number_CallsWriteDeferredName() throws Exception {
                                                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                        com.google.gson.stream.JsonWriter writer = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                        writer.name("test"); // Set deferred name
                                                                        Number value = 123;
                                                                        
                                                                        writer.value(value);
                                                                        
                                                                        String result = stringWriter.toString();
                                                                        assertTrue(result.contains("\"test\":123"));
                                                                    }

    @Test
                                                                    public void testValue_InvalidState_ThrowsException() throws Exception {
                                                                        java.io.StringWriter mockWriter = new java.io.StringWriter();
                                                                        JsonWriter jsonWriter = new JsonWriter(mockWriter);
                                                                        // Force invalid state by making stack empty
                                                                        try {
                                                                            java.lang.reflect.Field field = JsonWriter.class.getDeclaredField("stackSize");
                                                                            field.setAccessible(true);
                                                                            field.set(jsonWriter, 0);
                                                                        } catch (Exception e) {
                                                                            throw new RuntimeException(e);
                                                                        }
                                                                        
                                                                        try {
                                                                            jsonWriter.value("test");
                                                                            fail("Expected IllegalStateException to be thrown");
                                                                        } catch (IllegalStateException expected) {
                                                                            // Expected exception
                                                                        }
                                                                    }

    @Test
                                                                public void testValueDouble_ThrowsExceptionForNegativeInfinityWhenNotLenient() throws Exception {
                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                    com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                    jsonWriter.setLenient(false);
                                                                    
                                                                    org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                    thrown.expect(IllegalArgumentException.class);
                                                                    thrown.expectMessage("Numeric values must be finite, but was -Infinity");
                                                                    jsonWriter.value(Double.NEGATIVE_INFINITY);
                                                                }

    @Test
                                                                public void testValueDouble_CallsBeforeValue() throws Exception {
                                                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                    com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                    jsonWriter.beginArray(); // This adds a separator
                                                                    jsonWriter.value(1.0);
                                                                    jsonWriter.value(2.0);
                                                                    jsonWriter.endArray();
                                                                    
                                                                    assertEquals("[1.0,2.0]", stringWriter.toString());
                                                                }

    @Test
                                                            public void testValueBoolean_WithIndentation() throws IOException {
                                                                java.io.StringWriter stringWriter = new java.io.StringWriter();
                                                                com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                                                jsonWriter.setIndent("  ");
                                                                jsonWriter.beginObject()
                                                                          .name("flags")
                                                                          .beginArray()
                                                                          .value(true)
                                                                          .value(false)
                                                                          .endArray()
                                                                          .endObject();
                                                                
                                                                String result = stringWriter.toString();
                                                                String expected = "{\n  \"flags\": [\n    true,\n    false\n  ]\n}";
                                                                org.junit.Assert.assertEquals(expected, result);
                                                            }

    @Test(expected = IllegalStateException.class)
                                                        public void testValue_ClosedWriter_ThrowsException() throws Exception {
                                                            java.io.Writer writer = new java.io.StringWriter();
                                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(writer);
                                                            jsonWriter.close();
                                                            jsonWriter.value("test");
                                                        }

    @Test
                                    public void testValueBoolean_VerifyMethodSequence() throws Exception {
                                        // Arrange
                                        java.io.StringWriter stringWriter = new java.io.StringWriter();
                                        JsonWriter jsonWriter = new JsonWriter(stringWriter);
                                        
                                        // Use reflection to access private methods
                                        java.lang.reflect.Method writeDeferredName = com.google.gson.stream.JsonWriter.class
                                            .getDeclaredMethod("writeDeferredName");
                                        writeDeferredName.setAccessible(true);
                                        
                                        java.lang.reflect.Method beforeValue = com.google.gson.stream.JsonWriter.class
                                            .getDeclaredMethod("beforeValue");
                                        beforeValue.setAccessible(true);
                                        
                                        // Act
                                        jsonWriter.value(true);
                                        
                                        // Assert - Verify private method calls were made using reflection
                                        // These will throw exceptions if the methods weren't called
                                        writeDeferredName.invoke(jsonWriter);
                                        beforeValue.invoke(jsonWriter);
                                        
                                        // Also verify the output contains the boolean value
                                        String json = stringWriter.toString();
                                        assertEquals("true", json.trim());
                                    }

    @Test
                                public void testValueBoolean_NullInput() throws Exception {
                                    // Arrange
                                    java.io.StringWriter stringWriter = new java.io.StringWriter();
                                    JsonWriter jsonWriter = new JsonWriter(stringWriter);
                                    
                                    // Act
                                    JsonWriter result = jsonWriter.value((Boolean)null);
                                    
                                    // Assert
                                    org.junit.Assert.assertSame(jsonWriter, result);
                                    org.junit.Assert.assertEquals("", stringWriter.toString()); // Verify no output was written
                                }


}
