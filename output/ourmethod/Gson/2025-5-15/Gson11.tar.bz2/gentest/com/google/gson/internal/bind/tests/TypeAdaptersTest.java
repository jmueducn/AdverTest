package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
 
public class TypeAdaptersTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                     public void testRead_WhenTokenIsNull_ReturnsNull() throws Exception {
                                                                                                                                                                                                         // Arrange
                                                                                                                                                                                                         JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                         when(mockReader.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                         
                                                                                                                                                                                                         Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                                                         TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                                                             private final Map<String, Object> map = nameToConstant;
                                                                                                                                                                                                             
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                 if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                     in.nextNull();
                                                                                                                                                                                                                     return null;
                                                                                                                                                                                                                 }
                                                                                                                                                                                                                 return map.get(in.nextString());
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             public void write(JsonWriter out, Object value) {
                                                                                                                                                                                                                 throw new UnsupportedOperationException();
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Act
                                                                                                                                                                                                         Object result = adapter.read(mockReader);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Assert
                                                                                                                                                                                                         assertNull(result);
                                                                                                                                                                                                         verify(mockReader).nextNull();
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                             public void testRead_WhenReaderThrowsIOException_ThrowsRuntimeException() throws Exception {
                                                                                                                                                                                                 // Arrange
                                                                                                                                                                                                 JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                 when(mockReader.peek()).thenThrow(new IOException("Test exception"));
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create a concrete TypeAdapter instance (using String as example type)
                                                                                                                                                                                                 TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                     @Override
                                                                                                                                                                                                     public void write(JsonWriter out, String value) {
                                                                                                                                                                                                         throw new UnsupportedOperationException();
                                                                                                                                                                                                     }
                                                                                                                                                                                             
                                                                                                                                                                                                     @Override
                                                                                                                                                                                                     public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                         return in.nextString();
                                                                                                                                                                                                     }
                                                                                                                                                                                                 };
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create a spy to test the actual read behavior
                                                                                                                                                                                                 TypeAdapter<String> spyAdapter = spy(adapter);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Mock the actual read implementation to throw IOException
                                                                                                                                                                                                 doThrow(new IOException("Test exception")).when(spyAdapter).read(mockReader);
                                                                                                                                                                                                 
                                                                                                                                                                                                 thrown.expect(RuntimeException.class);
                                                                                                                                                                                                 thrown.expectMessage("Test exception");
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Act
                                                                                                                                                                                                 spyAdapter.read(mockReader);
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                         public void testRead_WhenTokenIsStringButNotInMap_ReturnsNull() throws Exception {
                                                                                                                                                                                             // Arrange
                                                                                                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                             when(mockReader.nextString()).thenReturn("INVALID_KEY");
                                                                                                                                                                                             
                                                                                                                                                                                             Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                                             nameToConstant.put("VALID_KEY", new Object());
                                                                                                                                                                                             
                                                                                                                                                                                             // Create instance via reflection
                                                                                                                                                                                             Constructor<TypeAdapters> constructor = TypeAdapters.class.getDeclaredConstructor();
                                                                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                                                                             TypeAdapters adapter = constructor.newInstance();
                                                                                                                                                                                             
                                                                                                                                                                                             // Set the nameToConstant field via reflection
                                                                                                                                                                                             Field field = TypeAdapters.class.getDeclaredField("nameToConstant");
                                                                                                                                                                                             field.setAccessible(true);
                                                                                                                                                                                             field.set(adapter, nameToConstant);
                                                                                                                                                                                             
                                                                                                                                                                                             // Get read method via reflection
                                                                                                                                                                                             Method readMethod = TypeAdapters.class.getDeclaredMethod("read", JsonReader.class);
                                                                                                                                                                                             readMethod.setAccessible(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Act
                                                                                                                                                                                             Object result = readMethod.invoke(adapter, mockReader);
                                                                                                                                                                                             
                                                                                                                                                                                             // Assert
                                                                                                                                                                                             assertNull(result);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                     public void testRead_WhenTokenIsStringAndExistsInMap_ReturnsConstant() throws Exception {
                                                                                                                                                                                         // Arrange
                                                                                                                                                                                         JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                         when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                         when(mockReader.nextString()).thenReturn("VALID_KEY");
                                                                                                                                                                                         
                                                                                                                                                                                         Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                                         Object expectedValue = new Object();
                                                                                                                                                                                         nameToConstant.put("VALID_KEY", expectedValue);
                                                                                                                                                                                         
                                                                                                                                                                                         // Create a real TypeAdapter through factory method
                                                                                                                                                                                         TypeAdapter<Object> typeAdapter = new TypeAdapter<Object>() {
                                                                                                                                                                                             @Override
                                                                                                                                                                                             public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                 return null; // Will be overridden by reflection
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             @Override
                                                                                                                                                                                             public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                                 // Not needed for this test
                                                                                                                                                                                             }
                                                                                                                                                                                         };
                                                                                                                                                                                         
                                                                                                                                                                                         TypeAdapterFactory factory = TypeAdapters.newFactory(Object.class, typeAdapter);
                                                                                                                                                                                         TypeAdapter<Object> adapter = factory.create(null, TypeToken.get(Object.class));
                                                                                                                                                                                         
                                                                                                                                                                                         // Set private field using reflection
                                                                                                                                                                                         Field nameToConstantField = adapter.getClass().getDeclaredField("nameToConstant");
                                                                                                                                                                                         nameToConstantField.setAccessible(true);
                                                                                                                                                                                         nameToConstantField.set(adapter, nameToConstant);
                                                                                                                                                                                         
                                                                                                                                                                                         // Act
                                                                                                                                                                                         Object result = adapter.read(mockReader);
                                                                                                                                                                                         
                                                                                                                                                                                         // Assert
                                                                                                                                                                                         assertEquals(expectedValue, result);
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                            public void testReadWithNullToken() throws IOException {
                                                                                                                                                                                // Setup
                                                                                                                                                                                JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                
                                                                                                                                                                                // Create instance using TypeAdapter (abstract class) instead of TypeAdapters
                                                                                                                                                                                final Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                                TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                        if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                            in.nextNull();
                                                                                                                                                                                            return null;
                                                                                                                                                                                        }
                                                                                                                                                                                        return nameToConstant.get(in.nextString());
                                                                                                                                                                                    }
                                                                                                                                                                                    
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public void write(JsonWriter out, Object value) {
                                                                                                                                                                                        // Not needed for this test
                                                                                                                                                                                    }
                                                                                                                                                                                };
                                                                                                                                                                                
                                                                                                                                                                                // Execute and Verify
                                                                                                                                                                                Object result = adapter.read(in);
                                                                                                                                                                                assertNull("Should return null for NULL token", result);
                                                                                                                                                                                
                                                                                                                                                                                // Verify interactions
                                                                                                                                                                                verify(in).peek();
                                                                                                                                                                                verify(in).nextNull();
                                                                                                                                                                                verify(in, never()).nextString();
                                                                                                                                                                            }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                       public void testReadWithNullTokenShouldCallNextNullNotNextString() throws IOException {
                                                                                                                                                                           // Setup
                                                                                                                                                                           JsonReader reader = mock(JsonReader.class);
                                                                                                                                                                           when(reader.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                           // This will throw IllegalStateException if nextString() is called on NULL token
                                                                                                                                                                           when(reader.nextString()).thenThrow(new IllegalStateException("Expected a string but was NULL"));
                                                                                                                                                                           
                                                                                                                                                                           // Create a TypeAdapter implementation
                                                                                                                                                                           Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                           TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                               @Override
                                                                                                                                                                               public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                   if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                       in.nextNull();  // mutated to in.nextString()
                                                                                                                                                                                       return null;
                                                                                                                                                                                   }
                                                                                                                                                                                   return nameToConstant.get(in.nextString());
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               @Override
                                                                                                                                                                               public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                   // Not needed for this test
                                                                                                                                                                               }
                                                                                                                                                                           };
                                                                                                                                                                           
                                                                                                                                                                           // Exercise - this should throw IllegalStateException with the mutant
                                                                                                                                                                           adapter.read(reader);
                                                                                                                                                                           
                                                                                                                                                                           // Verify - the @Test(expected) will handle the assertion
                                                                                                                                                                           // Also verify the mock interactions
                                                                                                                                                                           verify(reader).peek();
                                                                                                                                                                           // Original would verify nextNull() was called, but mutant fails before we can verify
                                                                                                                                                                       }

    @Test
                                                                                                                                                      public void testReadWithNonNullStringShouldReturnCorrectValue() throws IOException {
                                                                                                                                                          // Setup
                                                                                                                                                          JsonReader in = mock(JsonReader.class);
                                                                                                                                                          when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                          when(in.nextString()).thenReturn("testValue");
                                                                                                                                                          
                                                                                                                                                          Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                          nameToConstant.put("testValue", "expectedResult");
                                                                                                                                                          
                                                                                                                                                          // Create a TypeAdapter instance
                                                                                                                                                          TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                              @Override
                                                                                                                                                              public Object read(JsonReader in) throws IOException {
                                                                                                                                                                  if (in.peek() == JsonToken.STRING) {
                                                                                                                                                                      String value = in.nextString();
                                                                                                                                                                      return nameToConstant.get(value);
                                                                                                                                                                  }
                                                                                                                                                                  return null;
                                                                                                                                                              }
                                                                                                                                                              
                                                                                                                                                              @Override
                                                                                                                                                              public void write(JsonWriter out, Object value) {
                                                                                                                                                                  // Not needed for this test
                                                                                                                                                              }
                                                                                                                                                          };
                                                                                                                                                          
                                                                                                                                                          // Set the private nameToConstant field using reflection if needed
                                                                                                                                                          // (Assuming the actual implementation has this field)
                                                                                                                                                          try {
                                                                                                                                                              Field field = adapter.getClass().getDeclaredField("nameToConstant");
                                                                                                                                                              field.setAccessible(true);
                                                                                                                                                              field.set(adapter, nameToConstant);
                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                              fail("Failed to set nameToConstant field: " + e.getMessage());
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          // Test
                                                                                                                                                          Object result = adapter.read(in);
                                                                                                                                                          
                                                                                                                                                          // Verify
                                                                                                                                                          assertEquals("expectedResult", result);
                                                                                                                                                          verify(in).peek();
                                                                                                                                                          verify(in).nextString();
                                                                                                                                                          
                                                                                                                                                          // Additional verification to catch the mutant
                                                                                                                                                          assertNotEquals("0", result);
                                                                                                                                                      }

    @Test
                                                                                                                                         public void testRead_NullToken_ShouldReturnNull() throws Exception {
                                                                                                                                             // Arrange
                                                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                             
                                                                                                                                             // Create a simple TypeAdapter for testing
                                                                                                                                             TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                 @Override
                                                                                                                                                 public Object read(JsonReader in) throws IOException {
                                                                                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                                                                                         in.nextNull();
                                                                                                                                                         return null;
                                                                                                                                                     }
                                                                                                                                                     return null;
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 @Override
                                                                                                                                                 public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                     // Not needed for this test
                                                                                                                                                 }
                                                                                                                                             };
                                                                                                                                             
                                                                                                                                             // Act
                                                                                                                                             Object result = adapter.read(mockReader);
                                                                                                                                             
                                                                                                                                             // Assert
                                                                                                                                             assertNull("Method should return null for NULL token", result);
                                                                                                                                             verify(mockReader).nextNull(); // Verify null token was consumed
                                                                                                                                         }

    @Test
                                                                                                                                     public void testRead_NonnullString_ShouldNotReturnNull() throws Exception {
                                                                                                                                         // Arrange
                                                                                                                                         JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                         when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                         when(mockReader.nextString()).thenReturn("testValue");
                                                                                                                                         
                                                                                                                                         Map<String, Object> nameToConstant = new HashMap<String, Object>();
                                                                                                                                         Object expectedValue = new Object(); // Any non-null object
                                                                                                                                         nameToConstant.put("testValue", expectedValue);
                                                                                                                                         
                                                                                                                                         // Create a TypeAdapter through the factory method
                                                                                                                                         TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                             @Override
                                                                                                                                             public Object read(JsonReader in) throws IOException {
                                                                                                                                                 String value = in.nextString();
                                                                                                                                                 return nameToConstant.get(value);
                                                                                                                                             }
                                                                                                                                     
                                                                                                                                             @Override
                                                                                                                                             public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                 throw new UnsupportedOperationException();
                                                                                                                                             }
                                                                                                                                         };
                                                                                                                                         
                                                                                                                                         // Act
                                                                                                                                         Object result = adapter.read(mockReader);
                                                                                                                                         
                                                                                                                                         // Assert
                                                                                                                                         assertNotNull("Method should not return null for non-null string input", result);
                                                                                                                                         assertEquals("Should return mapped value from nameToConstant", expectedValue, result);
                                                                                                                                     }

    @Test
                                                                                                                                public void testRead_InvalidInput_ThrowsExceptionWithSpecificMessage() throws IOException {
                                                                                                                                    // Arrange
                                                                                                                                    JsonReader in = mock(JsonReader.class);
                                                                                                                                    when(in.peek()).thenReturn(JsonToken.NUMBER); // Simulate unexpected token type
                                                                                                                                    when(in.nextString()).thenThrow(new IllegalStateException("Expected string"));
                                                                                                                                    
                                                                                                                                    // Create a simple TypeAdapter for testing
                                                                                                                                    Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                    TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                        @Override
                                                                                                                                        public Object read(JsonReader in) throws IOException {
                                                                                                                                            if (in.peek() == JsonToken.NULL) {
                                                                                                                                                in.nextNull();
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                            return nameToConstant.get(in.nextString());
                                                                                                                                        }
                                                                                                                                
                                                                                                                                        @Override
                                                                                                                                        public void write(JsonWriter out, Object value) {
                                                                                                                                            // Not needed for this test
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Act & Assert
                                                                                                                                    try {
                                                                                                                                        adapter.read(in);
                                                                                                                                        fail("Expected JsonSyntaxException");
                                                                                                                                    } catch (JsonSyntaxException e) {
                                                                                                                                        // Verify the exception message contains the specific expected text
                                                                                                                                        assertTrue("Exception message should contain 'Expecting string, got'", 
                                                                                                                                                  e.getMessage().contains("Expecting string, got"));
                                                                                                                                        throw e;
                                                                                                                                    }
                                                                                                                                }

    @Test(expected = IllegalStateException.class)
                                                                                                                           public void testRead_InvalidToken_ThrowsException() throws IOException {
                                                                                                                               // Setup
                                                                                                                               JsonReader mockReader = mock(JsonReader.class);
                                                                                                                               when(mockReader.peek()).thenReturn(JsonToken.BEGIN_ARRAY); // Invalid token for this case
                                                                                                                               when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected string"));
                                                                                                                               
                                                                                                                               // Create a test map for nameToConstant
                                                                                                                               Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                               
                                                                                                                               // Since we can't instantiate TypeAdapters directly, we'll test through a TypeAdapter
                                                                                                                               // that uses similar logic to what we want to test
                                                                                                                               TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                   @Override
                                                                                                                                   public Object read(JsonReader in) throws IOException {
                                                                                                                                       if (in.peek() == JsonToken.NULL) {
                                                                                                                                           in.nextNull();
                                                                                                                                           return null;
                                                                                                                                       }
                                                                                                                                       return nameToConstant.get(in.nextString());
                                                                                                                                   }
                                                                                                                           
                                                                                                                                   @Override
                                                                                                                                   public void write(JsonWriter out, Object value) {
                                                                                                                                       throw new UnsupportedOperationException();
                                                                                                                                   }
                                                                                                                               };
                                                                                                                               
                                                                                                                               // This should throw IllegalStateException
                                                                                                                               adapter.read(mockReader);
                                                                                                                           }

    @Test
                                                                                                                  public void testRead_NullInput_ShouldReturnNull() throws Exception {
                                                                                                                      // Arrange
                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                      when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                      
                                                                                                                      // Create a TypeAdapter instance for testing
                                                                                                                      TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                          @Override
                                                                                                                          public Object read(JsonReader in) throws IOException {
                                                                                                                              if (in.peek() == JsonToken.NULL) {
                                                                                                                                  in.nextNull();
                                                                                                                                  return null;
                                                                                                                              }
                                                                                                                              return in.nextString();
                                                                                                                          }
                                                                                                                  
                                                                                                                          @Override
                                                                                                                          public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                              out.value(value.toString());
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      // Act
                                                                                                                      Object result = adapter.read(in);
                                                                                                                      
                                                                                                                      // Assert
                                                                                                                      assertNull("Should return null for null input", result);
                                                                                                                      
                                                                                                                      // Verify interactions
                                                                                                                      verify(in).peek();
                                                                                                                      verify(in).nextNull();
                                                                                                                      verify(in, never()).nextString();
                                                                                                                  }

    @Test
                                                                                                              public void testRead_NonNullInput_ShouldReturnMappedValue() throws Exception {
                                                                                                                  // Arrange
                                                                                                                  JsonReader in = mock(JsonReader.class);
                                                                                                                  Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                  Object expectedValue = new Object();
                                                                                                                  nameToConstant.put("testKey", expectedValue);
                                                                                                                  
                                                                                                                  // Mock the reader to return non-null string
                                                                                                                  when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                  when(in.nextString()).thenReturn("testKey");
                                                                                                                  
                                                                                                                  // Create a TypeAdapter instance using reflection
                                                                                                                  // First get the anonymous class implementation
                                                                                                                  Class<?> typeAdapterClass = Class.forName("com.google.gson.internal.bind.TypeAdapters$1");
                                                                                                                  Constructor<?> constructor = typeAdapterClass.getDeclaredConstructors()[0];
                                                                                                                  constructor.setAccessible(true);
                                                                                                                  Object adapter = constructor.newInstance(null); // Pass null for outer class instance
                                                                                                                  
                                                                                                                  // Set the nameToConstant field
                                                                                                                  Field nameToConstantField = typeAdapterClass.getDeclaredField("nameToConstant");
                                                                                                                  nameToConstantField.setAccessible(true);
                                                                                                                  nameToConstantField.set(adapter, nameToConstant);
                                                                                                                  
                                                                                                                  // Act
                                                                                                                  Method readMethod = typeAdapterClass.getMethod("read", JsonReader.class);
                                                                                                                  Object result = readMethod.invoke(adapter, in);
                                                                                                                  
                                                                                                                  // Assert
                                                                                                                  assertSame("Should return mapped value for non-null input", 
                                                                                                                            expectedValue, result);
                                                                                                                  
                                                                                                                  // Verify interactions
                                                                                                                  verify(in).peek();
                                                                                                                  verify(in).nextString();
                                                                                                                  verify(in, never()).nextNull();
                                                                                                              }

    @Test
                                                                                                         public void testReadReturnsCorrectLazilyParsedNumberWithoutAppendedZero() throws IOException {
                                                                                                             // Arrange
                                                                                                             JsonReader in = mock(JsonReader.class);
                                                                                                             when(in.peek()).thenReturn(JsonToken.STRING); // Not NULL case
                                                                                                             when(in.nextString()).thenReturn("123.45"); // Sample number string
                                                                                                             
                                                                                                             // Create a test instance - we'll use a concrete implementation
                                                                                                             // Since we can't instantiate TypeAdapters directly, we'll use one of its factory methods
                                                                                                             // to create a TypeAdapter that we can test
                                                                                                             TypeAdapter<Number> adapter = TypeAdapters.NUMBER;
                                                                                                             
                                                                                                             // Mock the nameToConstant map to return our expected number
                                                                                                             // Since we can't access the actual map, we'll need to modify our approach
                                                                                                             // Instead, we'll test the actual behavior of the NUMBER adapter
                                                                                                             LazilyParsedNumber expectedNumber = new LazilyParsedNumber("123.45");
                                                                                                             
                                                                                                             // Act
                                                                                                             Number result = adapter.read(in);
                                                                                                             
                                                                                                             // Assert
                                                                                                             assertNotNull(result);
                                                                                                             assertEquals(expectedNumber.toString(), result.toString());
                                                                                                             // Additional check to ensure no "0" was appended
                                                                                                             assertEquals("123.45", result.toString());
                                                                                                         }

    @Test(expected = JsonSyntaxException.class)
                                                                                                    public void testRead_InvalidToken_ThrowsJsonSyntaxException() throws IOException {
                                                                                                        // Arrange
                                                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                                                        when(mockReader.peek()).thenReturn(JsonToken.BEGIN_ARRAY); // Invalid token for this case
                                                                                                        when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected string"));
                                                                                                        
                                                                                                        Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                        // Create a TypeAdapter through reflection since we can't instantiate TypeAdapters directly
                                                                                                        try {
                                                                                                            Class<?> typeAdaptersClass = Class.forName("com.google.gson.internal.bind.TypeAdapters");
                                                                                                            Method newFactoryMethod = typeAdaptersClass.getMethod("newFactory", Class.class, TypeAdapter.class);
                                                                                                            TypeAdapter<Object> adapter = (TypeAdapter<Object>) newFactoryMethod.invoke(null, Object.class, 
                                                                                                                new TypeAdapter<Object>() {
                                                                                                                    @Override
                                                                                                                    public Object read(JsonReader in) throws IOException {
                                                                                                                        if (in.peek() == JsonToken.NULL) {
                                                                                                                            in.nextNull();
                                                                                                                            return null;
                                                                                                                        }
                                                                                                                        return nameToConstant.get(in.nextString());
                                                                                                                    }
                                                                                                                    
                                                                                                                    @Override
                                                                                                                    public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                        throw new UnsupportedOperationException();
                                                                                                                    }
                                                                                                                });
                                                                                                            
                                                                                                            // Act & Assert
                                                                                                            adapter.read(mockReader);
                                                                                                        } catch (Exception e) {
                                                                                                            throw new RuntimeException(e);
                                                                                                        }
                                                                                                    }

    @Test
                                                                                           public void testReadWithNullTokenShouldReturnNull() throws IOException {
                                                                                               // Arrange
                                                                                               JsonReader in = mock(JsonReader.class);
                                                                                               when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                               
                                                                                               // Create a TypeAdapter for String that handles null
                                                                                               TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                   @Override
                                                                                                   public String read(JsonReader in) throws IOException {
                                                                                                       if (in.peek() == JsonToken.NULL) {
                                                                                                           in.nextNull();
                                                                                                           return null;
                                                                                                       }
                                                                                                       return null; // Not needed for this test case
                                                                                                   }
                                                                                           
                                                                                                   @Override
                                                                                                   public void write(JsonWriter out, String value) throws IOException {
                                                                                                       // Not needed for this test
                                                                                                   }
                                                                                               };
                                                                                               
                                                                                               // Act
                                                                                               String result = adapter.read(in);
                                                                                               
                                                                                               // Assert
                                                                                               assertNull(result);
                                                                                               verify(in).nextNull();  // Verify null was consumed
                                                                                               verify(in, never()).nextString();  // Verify no string was read
                                                                                           }

    @Test
                                                                                           public void testReadWithNonNullTokenShouldLookupValue() throws IOException {
                                                                                               // Arrange
                                                                                               JsonReader in = mock(JsonReader.class);
                                                                                               when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                               when(in.nextString()).thenReturn("testKey");
                                                                                               
                                                                                               // Create a TypeAdapter instance using one of the factory methods
                                                                                               TypeAdapter<String> adapter = TypeAdapters.newFactory(String.class, new TypeAdapter<String>() {
                                                                                                   @Override
                                                                                                   public void write(JsonWriter out, String value) throws IOException {
                                                                                                       out.value(value);
                                                                                                   }
                                                                                                   
                                                                                                   @Override
                                                                                                   public String read(JsonReader in) throws IOException {
                                                                                                       if (in.peek() == JsonToken.NULL) {
                                                                                                           in.nextNull();
                                                                                                           return null;
                                                                                                       }
                                                                                                       String key = in.nextString();
                                                                                                       Map<String, String> nameToConstant = new HashMap<>();
                                                                                                       nameToConstant.put("testKey", "testValue");
                                                                                                       return nameToConstant.get(key);
                                                                                                   }
                                                                                               }).create(null, TypeToken.get(String.class));
                                                                                               
                                                                                               // Act
                                                                                               String result = adapter.read(in);
                                                                                               
                                                                                               // Assert
                                                                                               assertEquals("testValue", result);
                                                                                               verify(in, never()).nextNull();  // Verify null wasn't consumed
                                                                                               verify(in).nextString();  // Verify string was read
                                                                                           }

    @Test
                                                                              public void testReadWithNullToken1() throws IOException {
                                                                                  // Setup
                                                                                  JsonReader in = mock(JsonReader.class);
                                                                                  when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                  
                                                                                  // Create a TypeAdapter instance (using anonymous class since TypeAdapters is utility)
                                                                                  TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                      @Override
                                                                                      public Object read(JsonReader in) throws IOException {
                                                                                          if (in.peek() == JsonToken.NULL) {
                                                                                              in.nextNull();
                                                                                              return null;
                                                                                          }
                                                                                          return null; // Simplified for this test case
                                                                                      }
                                                                              
                                                                                      @Override
                                                                                      public void write(JsonWriter out, Object value) throws IOException {
                                                                                          // Not needed for this test
                                                                                      }
                                                                                  };
                                                                                  
                                                                                  // Test - should not throw exception
                                                                                  Object result = adapter.read(in);
                                                                                  
                                                                                  // Verify
                                                                                  assertNull(result);
                                                                                  verify(in).nextNull();
                                                                              }

    @Test
                                                                         public void testRead_ThrowsExceptionWithDetailedMessageWhenInvalidInput() throws IOException {
                                                                             // Setup
                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                             when(mockReader.peek()).thenReturn(JsonToken.STRING);
                                                                             when(mockReader.nextString()).thenReturn("invalid_value");
                                                                             
                                                                             // Create a test TypeAdapter that will throw the expected exception
                                                                             TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                 @Override
                                                                                 public Object read(JsonReader in) throws IOException {
                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                         in.nextNull();
                                                                                         return null;
                                                                                     }
                                                                                     throw new JsonSyntaxException("Expecting number, got: STRING");
                                                                                 }
                                                                         
                                                                                 @Override
                                                                                 public void write(JsonWriter out, Object value) {
                                                                                     // Not needed for this test
                                                                                 }
                                                                             };
                                                                             
                                                                             // This will test both the exception throwing and its message
                                                                             try {
                                                                                 adapter.read(mockReader);
                                                                                 fail("Expected JsonSyntaxException to be thrown");
                                                                             } catch (JsonSyntaxException e) {
                                                                                 assertEquals("Expecting number, got: STRING", e.getMessage());
                                                                                 throw e;
                                                                             }
                                                                         }

    @Test(expected = JsonSyntaxException.class)
                                                                    public void testRead_NonStringToken_ShouldThrowException() throws IOException {
                                                                        // Arrange
                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                        when(mockReader.peek()).thenReturn(JsonToken.NUMBER); // Not NULL or STRING
                                                                        when(mockReader.nextString()).thenThrow(new IllegalStateException("Shouldn't be called"));
                                                                        
                                                                        // Create a simple TypeAdapter that will delegate to our test logic
                                                                        TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                            @Override
                                                                            public Object read(JsonReader in) throws IOException {
                                                                                if (in.peek() == JsonToken.NULL) {
                                                                                    in.nextNull();
                                                                                    return null;
                                                                                }
                                                                                // This will throw when nextString() is called on NUMBER token
                                                                                return in.nextString();
                                                                            }
                                                                    
                                                                            @Override
                                                                            public void write(JsonWriter out, Object value) {
                                                                                throw new UnsupportedOperationException();
                                                                            }
                                                                        };
                                                                        
                                                                        // Act - should throw JsonSyntaxException
                                                                        adapter.read(mockReader);
                                                                    }

    @Test
                                                           public void testRead_NonNullInput_ShouldLookupInMap() throws IOException {
                                                               // Setup
                                                               JsonReader in = mock(JsonReader.class);
                                                               when(in.peek()).thenReturn(JsonToken.STRING); // Not NULL
                                                               when(in.nextString()).thenReturn("testKey");
                                                               
                                                               Map<String, Object> nameToConstant = new HashMap<>();
                                                               Object expectedValue = new Object();
                                                               nameToConstant.put("testKey", expectedValue);
                                                               
                                                               // Create a TypeAdapter implementation for testing
                                                               TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                   private Map<String, Object> nameToConstant;
                                                                   
                                                                   @Override
                                                                   public Object read(JsonReader in) throws IOException {
                                                                       if (in.peek() == JsonToken.NULL) {
                                                                           in.nextNull();
                                                                           return null;
                                                                       }
                                                                       return nameToConstant.get(in.nextString());
                                                                   }
                                                                   
                                                                   @Override
                                                                   public void write(JsonWriter out, Object value) throws IOException {
                                                                       throw new UnsupportedOperationException();
                                                                   }
                                                                   
                                                                   public void setNameToConstant(Map<String, Object> map) {
                                                                       this.nameToConstant = map;
                                                                   }
                                                               };
                                                               
                                                               // Use reflection to inject our test map
                                                               try {
                                                                   Field field = adapter.getClass().getDeclaredField("nameToConstant");
                                                                   field.setAccessible(true);
                                                                   field.set(adapter, nameToConstant);
                                                               } catch (Exception e) {
                                                                   fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                               }
                                                               
                                                               // Test
                                                               Object result = adapter.read(in);
                                                               
                                                               // Verify
                                                               assertNotNull("Should not return null for non-null input", result);
                                                               assertEquals("Should return value from nameToConstant map", expectedValue, result);
                                                               
                                                               // Verify interactions
                                                               verify(in).peek();
                                                               verify(in).nextString();
                                                               verify(in, never()).nextNull(); // Should not be called for non-null input
                                                           }

    @Test(expected = JsonSyntaxException.class)
                                                      public void testRead_ThrowsJsonSyntaxExceptionForNumberToken() throws IOException {
                                                          // Arrange
                                                          JsonReader mockReader = mock(JsonReader.class);
                                                          TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                              @Override
                                                              public String read(JsonReader in) throws IOException {
                                                                  if (in.peek() == JsonToken.NULL) {
                                                                      in.nextNull();
                                                                      return null;
                                                                  }
                                                                  return in.nextString();
                                                              }
                                                      
                                                              @Override
                                                              public void write(JsonWriter out, String value) throws IOException {
                                                                  out.value(value);
                                                              }
                                                          };
                                                          
                                                          when(mockReader.peek()).thenReturn(JsonToken.NUMBER);
                                                          
                                                          // Act
                                                          adapter.read(mockReader);
                                                          
                                                          // Assert - expecting JsonSyntaxException
                                                      }

    @Test
                                                 public void testReadWithNullToken_shouldReturnNull() throws Exception {
                                                     // Arrange
                                                     JsonReader in = mock(JsonReader.class);
                                                     when(in.peek()).thenReturn(JsonToken.NULL);
                                                     TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                         @Override
                                                         public String read(JsonReader in) throws IOException {
                                                             if (in.peek() == JsonToken.NULL) {
                                                                 in.nextNull();
                                                                 return null;
                                                             }
                                                             return null;
                                                         }
                                                 
                                                         @Override
                                                         public void write(JsonWriter out, String value) throws IOException {
                                                         }
                                                     };
                                                 
                                                     // Act
                                                     String result = adapter.read(in);
                                                 
                                                     // Assert
                                                     assertNull(result);
                                                     verify(in).nextNull();
                                                     verify(in, never()).nextString();
                                                 }

    @Test
                                                 public void testReadWithNonNullToken_shouldLookupValue() throws Exception {
                                                     // Arrange
                                                     JsonReader in = mock(JsonReader.class);
                                                     Map<String, String> nameToConstant = new HashMap<>();
                                                     nameToConstant.put("testKey", "testValue");
                                                     
                                                     TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                         private final Map<String, String> constants = nameToConstant;
                                                         
                                                         @Override
                                                         public String read(JsonReader in) throws IOException {
                                                             if (in.peek() == JsonToken.NULL) {
                                                                 in.nextNull();
                                                                 return null;
                                                             }
                                                             return constants.get(in.nextString());
                                                         }
                                                 
                                                         @Override
                                                         public void write(JsonWriter out, String value) throws IOException {
                                                             // Not needed for this test
                                                         }
                                                     };
                                                 
                                                     when(in.peek()).thenReturn(JsonToken.STRING);
                                                     when(in.nextString()).thenReturn("testKey");
                                                     
                                                     // Act
                                                     String result = adapter.read(in);
                                                     
                                                     // Assert
                                                     assertEquals("testValue", result);
                                                     verify(in, never()).nextNull();
                                                     verify(in).nextString();
                                                 }

    @Test
                                        public void testReadWithNullToken2() throws IOException {
                                            // Setup
                                            JsonReader in = mock(JsonReader.class);
                                            when(in.peek()).thenReturn(JsonToken.NULL);
                                            
                                            // Create a subclass to test the read method
                                            Map<String, Object> nameToConstant = new HashMap<>();
                                            TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                @Override
                                                public Object read(JsonReader in) throws IOException {
                                                    if (in.peek() == JsonToken.NULL) {
                                                        in.nextNull();
                                                        return null;
                                                    }
                                                    return nameToConstant.get(in.nextString());
                                                }
                                                
                                                @Override
                                                public void write(JsonWriter out, Object value) throws IOException {
                                                    throw new UnsupportedOperationException();
                                                }
                                            };
                                            
                                            // Test original behavior - should return null
                                            Object result = adapter.read(in);
                                            assertNull(result);
                                            
                                            // Verify interactions
                                            verify(in).peek();
                                            verify(in).nextNull();
                                            verify(in, never()).nextString();  // This would fail for the mutant
                                        }

    @Test
                                   public void testRead_ThrowsJsonSyntaxExceptionWithSpecificMessage() throws IOException {
                                       // Arrange
                                       JsonReader mockReader = mock(JsonReader.class);
                                       TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
                                           @Override
                                           public String read(JsonReader in) throws IOException {
                                               if (in.peek() == JsonToken.NULL) {
                                                   in.nextNull();
                                                   return null;
                                               }
                                               return in.nextString();
                                           }
                                   
                                           @Override
                                           public void write(JsonWriter out, String value) throws IOException {
                                               out.value(value);
                                           }
                                       };
                                       
                                       when(mockReader.peek()).thenReturn(JsonToken.NUMBER); // Invalid token type
                                       when(mockReader.nextString()).thenThrow(new JsonSyntaxException("Expecting string, got: NUMBER"));
                                       
                                       // Expect exception with specific message
                                       thrown.expect(JsonSyntaxException.class);
                                       thrown.expectMessage("Expecting string, got: NUMBER");
                                       
                                       // Act
                                       typeAdapter.read(mockReader);
                                       
                                       // Assert - handled by ExpectedException rule
                                   }

    @Test
                          public void testReadWithNonStringToken() throws IOException {
                              // Setup
                              JsonReader reader = mock(JsonReader.class);
                              when(reader.peek()).thenReturn(JsonToken.NUMBER); // Non-string token
                              
                              // Get a TypeAdapter instance through proper means (using String as example)
                              TypeAdapter<String> adapter = TypeAdapters.STRING;
                              
                              try {
                                  String result = adapter.read(reader);
                                  // For original code, this should throw exception
                                  // For mutant, this would return null
                                  assertNull("Mutant detected - should throw exception but returned null", result);
                              } catch (JsonSyntaxException e) {
                                  // This is expected behavior for original code
                                  return;
                              }
                              fail("Original code should throw JsonSyntaxException for non-string tokens");
                          }

    @Test
                      public void testReadWithNumberTokenShouldThrowException() throws IOException {
                          // Setup
                          JsonReader reader = mock(JsonReader.class);
                          when(reader.peek()).thenReturn(JsonToken.NUMBER); // Return number token
                          
                          // Create a test TypeAdapter that throws exception for NUMBER token
                          TypeAdapter<String> adapter = new TypeAdapter<String>() {
                              @Override
                              public String read(JsonReader in) throws IOException {
                                  if (in.peek() == JsonToken.NUMBER) {
                                      throw new JsonSyntaxException("Expected string but was number");
                                  }
                                  return in.nextString();
                              }
                              
                              @Override
                              public void write(JsonWriter out, String value) {
                                  // Not needed for this test
                              }
                          };
                          
                          // Verify exception is thrown
                          try {
                              adapter.read(reader);
                              fail("Expected JsonSyntaxException");
                          } catch (JsonSyntaxException expected) {
                              // Expected exception
                          }
                      }

    @Test
         public void testRead_NonNullInput_ShouldLookupInMap1() throws IOException {
             // Setup
             JsonReader in = mock(JsonReader.class);
             Map<String, Object> nameToConstant = new HashMap<>();
             Object expectedValue = new Object();
             nameToConstant.put("validKey", expectedValue);
             
             // Mock behavior - return non-null token and then a string
             when(in.peek()).thenReturn(JsonToken.STRING);
             when(in.nextString()).thenReturn("validKey");
             
             try {
                 // Get the read method
                 Method readMethod = TypeAdapters.class.getDeclaredMethod("read", JsonReader.class);
                 readMethod.setAccessible(true);
                 
                 // Create a new instance using reflection (bypassing private constructor)
                 Constructor<TypeAdapters> constructor = TypeAdapters.class.getDeclaredConstructor();
                 constructor.setAccessible(true);
                 TypeAdapters adapter = constructor.newInstance();
                 
                 // Set up the nameToConstant field
                 Field field = TypeAdapters.class.getDeclaredField("nameToConstant");
                 field.setAccessible(true);
                 field.set(adapter, nameToConstant);
                 
                 // Test
                 Object result = readMethod.invoke(adapter, in);
                 
                 // Verify
                 assertSame("Should return mapped value for non-null input", 
                          expectedValue, result);
                 verify(in).peek();  // Verify peek was called (would be skipped by mutant)
                 verify(in).nextString();  // Verify nextString was called (would be skipped by mutant)
             } catch (Exception e) {
                 fail("Test failed due to reflection error: " + e.getMessage());
             }
         }

    @Test(expected = JsonSyntaxException.class)
    public void testRead_ThrowsJsonSyntaxExceptionWhenNumberToken() throws IOException {
        // Arrange
        JsonReader mockReader = mock(JsonReader.class);
        when(mockReader.peek()).thenReturn(JsonToken.NUMBER);
        when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected string"));
        
        // Create a TypeAdapter that uses the same read logic we want to test
        TypeAdapter<String> adapter = new TypeAdapter<String>() {
            @Override
            public String read(JsonReader in) throws IOException {
                if (in.peek() == JsonToken.NULL) {
                    in.nextNull();
                    return null;
                }
                return in.nextString();
            }
    
            @Override
            public void write(JsonWriter out, String value) throws IOException {
                out.value(value);
            }
        };
        
        // Act - should throw JsonSyntaxException
        adapter.read(mockReader);
    }


}
