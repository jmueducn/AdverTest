package gentest.com.google.gson.internal.bind.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.util.*;
import java.text.ParseException;
import java.text.ParsePosition;
 
public class ISO8601UtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                public void testParse_DateOnly() throws Exception {
                                                                                    String dateStr = "2023-05-15";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar();
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.HOUR_OF_DAY));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals(dateStr.length(), pos.getIndex());
                                                                                }

    @Test
                                                                                public void testParse_DateTime() throws Exception {
                                                                                    // Import required classes
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse("2023-05-15T14:30:45", pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar();
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(14, cal.get(java.util.Calendar.HOUR_OF_DAY));
                                                                                    assertEquals(30, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(45, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals("2023-05-15T14:30:45".length(), pos.getIndex());
                                                                                }

    @Test
                                                                                public void testParse_DateTimeWithMillis() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45.123";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar();
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(14, cal.get(java.util.Calendar.HOUR_OF_DAY));
                                                                                    assertEquals(30, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(45, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(123, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals(dateStr.length(), pos.getIndex());
                                                                                }

    @Test
                                                                                public void testParse_DateTimeWithZuluTimeZone() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45Z";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"));
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(14, cal.get(java.util.Calendar.HOUR_OF_DAY));
                                                                                    assertEquals(30, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(45, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals(dateStr.length(), pos.getIndex());
                                                                                }

    @Test
                                                                                public void testParse_DateTimeWithPositiveOffset() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45+02:00";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    // The time should be converted to UTC
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"));
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(12, cal.get(java.util.Calendar.HOUR_OF_DAY)); // 14:30 - 2 hours
                                                                                    assertEquals(30, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(45, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals(dateStr.length(), pos.getIndex());
                                                                                }

    @Test
                                                                                public void testParse_DateTimeWithNegativeOffset() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45-05:00";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    // The time should be converted to UTC
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"));
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(19, cal.get(java.util.Calendar.HOUR_OF_DAY)); // 14:30 + 5 hours
                                                                                    assertEquals(30, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(45, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals(dateStr.length(), pos.getIndex());
                                                                                }

    @Test
                                                                                public void testParse_DateTimeWithShortOffset() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45+02";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    // The time should be converted to UTC
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"));
                                                                                    cal.setTime(result);
                                                                                    assertEquals(2023, cal.get(java.util.Calendar.YEAR));
                                                                                    assertEquals(java.util.Calendar.MAY, cal.get(java.util.Calendar.MONTH));
                                                                                    assertEquals(15, cal.get(java.util.Calendar.DAY_OF_MONTH));
                                                                                    assertEquals(12, cal.get(java.util.Calendar.HOUR_OF_DAY)); // 14:30 - 2 hours
                                                                                    assertEquals(30, cal.get(java.util.Calendar.MINUTE));
                                                                                    assertEquals(45, cal.get(java.util.Calendar.SECOND));
                                                                                    assertEquals(0, cal.get(java.util.Calendar.MILLISECOND));
                                                                                    assertEquals(dateStr.length() + 3, pos.getIndex()); // +3 because method appends "00" to short offset
                                                                                }

    @Test
                                                                                public void testParse_InvalidTimeThrowsException() {
                                                                                    org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                                                    String dateStr = "2023-05-15T25:30:45"; // Invalid hour
                                                                                    ParsePosition pos = new ParsePosition(0);
                                                                                    
                                                                                    exceptionRule.expect(ParseException.class);
                                                                                    exceptionRule.expectMessage("Failed to parse date [\'2023-05-15T25:30:45\']");
                                                                                    
                                                                                }

    @Test
                                                                                public void testParse_MissingTimezoneThrowsException() {
                                                                                    String dateStr = "2023-05-15T14:30:45"; // Missing timezone
                                                                                    ParsePosition pos = new ParsePosition(0);
                                                                                    
                                                                                    ExpectedException exceptionRule = ExpectedException.none();
                                                                                    exceptionRule.expect(ParseException.class);
                                                                                    exceptionRule.expectMessage("Failed to parse date [\'2023-05-15T14:30:45\']: No time zone indicator");
                                                                                    
                                                                                }

                                                                                
                                                                                public void testParse_InvalidTimezoneThrowsException() {
                                                                                    String dateStr = "2023-05-15T14:30:45X"; // Invalid timezone indicator
                                                                                    ParsePosition pos = new ParsePosition(0);
                                                                                    
                                                                                    try {
                                                                                        ISO8601Utils.parse(dateStr, pos);
                                                                                    } catch (ParseException e) {
                                                                                        assertEquals("Failed to parse date ['2023-05-15T14:30:45X']: Invalid time zone indicator 'X'", e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testParse_LeapSecondsHandling() throws Exception {
                                                                                    // Import required classes (these would normally be at file level, but we're including them here for completeness)
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse("2023-05-15T14:30:62", pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar();
                                                                                    cal.setTime(result);
                                                                                    assertEquals(59, cal.get(java.util.Calendar.SECOND)); // Should be truncated to 59
                                                                                }

    @Test
                                                                                public void testParse_PartialMilliseconds() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45.1";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar();
                                                                                    cal.setTime(result);
                                                                                    assertEquals(100, cal.get(java.util.Calendar.MILLISECOND)); // .1 should become 100ms
                                                                                }

    @Test
                                                                                public void testParse_TwoDigitMilliseconds() throws Exception {
                                                                                    String dateStr = "2023-05-15T14:30:45.12";
                                                                                    java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                    java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                    
                                                                                    java.util.Calendar cal = new java.util.GregorianCalendar();
                                                                                    cal.setTime(result);
                                                                                    assertEquals(120, cal.get(java.util.Calendar.MILLISECOND)); // .12 should become 120ms
                                                                                }

    @Test(expected = ParseException.class)
                                    public void testParse_InvalidDateThrowsException() throws ParseException {
                                        String dateStr = "2023-13-15"; // Invalid month
                                        ParsePosition pos = new ParsePosition(0);
                                        
                                        try {
                                            ISO8601Utils.parse(dateStr, pos);
                                            fail("Expected ParseException to be thrown");
                                        } catch (ParseException e) {
                                            assertTrue(e.getMessage().contains("Failed to parse date [\'2023-13-15\']"));
                                            throw e;
                                        }
                                    }


}
