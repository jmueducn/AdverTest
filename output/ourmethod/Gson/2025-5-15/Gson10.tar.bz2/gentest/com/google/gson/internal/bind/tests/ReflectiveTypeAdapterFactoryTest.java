package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Primitives;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
 
public class ReflectiveTypeAdapterFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                public void testCreate_WithValidType_ReturnsTypeAdapter() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ConstructorConstructor mockConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                                    FieldNamingStrategy mockNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                                    Excluder mockExcluder = mock(Excluder.class);
                                                                                                                                                                    
                                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                        mockConstructor, mockNamingStrategy, mockExcluder);
                                                                                                                                                                    Gson gson = new Gson();
                                                                                                                                                                    TypeToken<String> type = TypeToken.get(String.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockExcluder.excludeClass(String.class, true)).thenReturn(false);
                                                                                                                                                                    when(mockExcluder.excludeClass(String.class, false)).thenReturn(false);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    TypeAdapter<String> adapter = factory.create(gson, type);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNotNull(adapter);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testCreate_WithExcludedClass_ReturnsNull() {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ConstructorConstructor mockConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                                    FieldNamingStrategy mockNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                                    Excluder mockExcluder = mock(Excluder.class);
                                                                                                                                                                    
                                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                        mockConstructor, mockNamingStrategy, mockExcluder);
                                                                                                                                                                    Gson gson = new Gson();
                                                                                                                                                                    TypeToken<String> type = TypeToken.get(String.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockExcluder.excludeClass(String.class, true)).thenReturn(true);
                                                                                                                                                                    when(mockExcluder.excludeClass(String.class, false)).thenReturn(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    TypeAdapter<String> adapter = factory.create(gson, type);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertNull(adapter);
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testExcludeField_WithExcludedField_ReturnsTrue() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ConstructorConstructor mockConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                                    FieldNamingStrategy mockNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                                    Excluder mockExcluder = mock(Excluder.class);
                                                                                                                                                                    
                                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                        mockConstructor, mockNamingStrategy, mockExcluder);
                                                                                                                                                                    Field field = String.class.getDeclaredField("value");
                                                                                                                                                                    
                                                                                                                                                                    when(mockExcluder.excludeField(field, true)).thenReturn(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test & Verify
                                                                                                                                                                    assertTrue(mockExcluder.excludeField(field, true));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testExcludeField_WithIncludedField_ReturnsFalse() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ConstructorConstructor mockConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                                    FieldNamingStrategy mockNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                                    Excluder mockExcluder = mock(Excluder.class);
                                                                                                                                                                    
                                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                        mockConstructor, mockNamingStrategy, mockExcluder);
                                                                                                                                                                    Field field = String.class.getDeclaredField("value");
                                                                                                                                                                    
                                                                                                                                                                    when(mockExcluder.excludeField(field, false)).thenReturn(false);
                                                                                                                                                                    
                                                                                                                                                                    // Test & Verify
                                                                                                                                                                    assertFalse(factory.excludeField(field, false));
                                                                                                                                                                }

    @Test
                                                                                                                                                                public void testGetFieldNames_WithNamingStrategy_ReturnsCorrectNames() throws Exception {
                                                                                                                                                                    // Setup
                                                                                                                                                                    ConstructorConstructor mockConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                                    FieldNamingStrategy mockNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                                    Excluder mockExcluder = mock(Excluder.class);
                                                                                                                                                                    
                                                                                                                                                                    when(mockNamingStrategy.translateName(any(Field.class))).thenReturn("customName");
                                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                        mockConstructor, mockNamingStrategy, mockExcluder);
                                                                                                                                                                    Field field = String.class.getDeclaredField("value");
                                                                                                                                                                    
                                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                                    Method getFieldNamesMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod("getFieldNames", Field.class);
                                                                                                                                                                    getFieldNamesMethod.setAccessible(true);
                                                                                                                                                                    
                                                                                                                                                                    // Test
                                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                                    List<String> names = (List<String>) getFieldNamesMethod.invoke(factory, field);
                                                                                                                                                                    
                                                                                                                                                                    // Verify
                                                                                                                                                                    assertEquals(1, names.size());
                                                                                                                                                                    assertEquals("customName", names.get(0));
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testRead_EmptyObject() throws IOException {
                                                                                                                                                                // Create mock objects
                                                                                                                                                                JsonReader in = mock(JsonReader.class);
                                                                                                                                                                ConstructorConstructor constructor = mock(ConstructorConstructor.class);
                                                                                                                                                                ObjectConstructor<Object> objectConstructor = mock(ObjectConstructor.class);
                                                                                                                                                                
                                                                                                                                                                // Create adapter factory with required dependencies
                                                                                                                                                                ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                    constructor, 
                                                                                                                                                                    mock(FieldNamingStrategy.class), 
                                                                                                                                                                    mock(Excluder.class)
                                                                                                                                                                );
                                                                                                                                                                
                                                                                                                                                                // Setup test data
                                                                                                                                                                Object mockInstance = new Object();
                                                                                                                                                                
                                                                                                                                                                // Configure mocks
                                                                                                                                                                when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
                                                                                                                                                                when(constructor.get(TypeToken.get(Object.class))).thenReturn(objectConstructor);
                                                                                                                                                                when(objectConstructor.construct()).thenReturn(mockInstance);
                                                                                                                                                                when(in.hasNext()).thenReturn(false);
                                                                                                                                                                
                                                                                                                                                                // Execute test
                                                                                                                                                                Object result = adapterFactory.create(mock(Gson.class), TypeToken.get(Object.class)).read(in);
                                                                                                                                                                
                                                                                                                                                                // Verify behavior
                                                                                                                                                                verify(in).beginObject();
                                                                                                                                                                verify(in).endObject();
                                                                                                                                                                assertEquals(mockInstance, result);
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testCreateBoundField_WithJsonAdapterAnnotation() throws Exception {
                                                                                                                                                            // Define a sample class with JsonAdapter annotation
                                                                                                                                                            class SampleClass {
                                                                                                                                                                @com.google.gson.annotations.JsonAdapter(Object.class)
                                                                                                                                                                private Object annotatedField;
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            // Setup
                                                                                                                                                            Field field = SampleClass.class.getDeclaredField("annotatedField");
                                                                                                                                                            TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                                                                                                            String name = "annotatedField";
                                                                                                                                                            boolean serialize = true;
                                                                                                                                                            boolean deserialize = true;
                                                                                                                                                            
                                                                                                                                                            // Create mock objects
                                                                                                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                constructorConstructor, 
                                                                                                                                                                mock(FieldNamingStrategy.class), 
                                                                                                                                                                mock(Excluder.class)
                                                                                                                                                            );
                                                                                                                                                            Gson gson = mock(Gson.class);
                                                                                                                                                            
                                                                                                                                                            // Get the actual JsonAdapter annotation
                                                                                                                                                            JsonAdapter jsonAdapter = field.getAnnotation(JsonAdapter.class);
                                                                                                                                                            
                                                                                                                                                            TypeAdapter<?> mockAdapter = mock(TypeAdapter.class);
                                                                                                                                                            when(gson.getDelegateAdapter(any(ReflectiveTypeAdapterFactory.class), any(TypeToken.class)))
                                                                                                                                                                .thenReturn(mockAdapter);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access the private createBoundField method
                                                                                                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                                "createBoundField", 
                                                                                                                                                                Gson.class, 
                                                                                                                                                                Field.class, 
                                                                                                                                                                String.class, 
                                                                                                                                                                TypeToken.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                boolean.class
                                                                                                                                                            );
                                                                                                                                                            createBoundFieldMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                                factory, 
                                                                                                                                                                gson, 
                                                                                                                                                                field, 
                                                                                                                                                                name, 
                                                                                                                                                                fieldType, 
                                                                                                                                                                serialize, 
                                                                                                                                                                deserialize
                                                                                                                                                            );
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNotNull(boundField);
                                                                                                                                                            verify(gson).getDelegateAdapter(any(ReflectiveTypeAdapterFactory.class), eq(fieldType));
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testCreateBoundField_WithPrimitiveType() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            class SampleClass {
                                                                                                                                                                int primitiveField;
                                                                                                                                                            }
                                                                                                                                                            Field field = SampleClass.class.getDeclaredField("primitiveField");
                                                                                                                                                            TypeToken<?> fieldType = TypeToken.get(field.getType());
                                                                                                                                                            String name = "primitiveField";
                                                                                                                                                            boolean serialize = true;
                                                                                                                                                            boolean deserialize = true;
                                                                                                                                                            
                                                                                                                                                            // Create mock objects
                                                                                                                                                            Gson gson = mock(Gson.class);
                                                                                                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                            FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                            Excluder excluder = mock(Excluder.class);
                                                                                                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                constructorConstructor, fieldNamingStrategy, excluder);
                                                                                                                                                            
                                                                                                                                                            @SuppressWarnings("unchecked")
                                                                                                                                                            TypeAdapter<Object> mockAdapter = mock(TypeAdapter.class);
                                                                                                                                                            when(gson.getAdapter(any(TypeToken.class))).thenReturn(mockAdapter);
                                                                                                                                                            
                                                                                                                                                            // Get private method via reflection
                                                                                                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                                "createBoundField", 
                                                                                                                                                                Gson.class, 
                                                                                                                                                                Field.class, 
                                                                                                                                                                String.class, 
                                                                                                                                                                TypeToken.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                boolean.class
                                                                                                                                                            );
                                                                                                                                                            createBoundFieldMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                                factory, 
                                                                                                                                                                gson, 
                                                                                                                                                                field, 
                                                                                                                                                                name, 
                                                                                                                                                                fieldType, 
                                                                                                                                                                serialize, 
                                                                                                                                                                deserialize
                                                                                                                                                            );
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertNotNull(boundField);
                                                                                                                                                            assertTrue(Primitives.isPrimitive(fieldType.getRawType()));
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testCreateBoundField_WriteField_ReturnsFalseWhenNotSerialized() throws Exception {
                                                                                                                                                            // Setup
                                                                                                                                                            class SampleClass {
                                                                                                                                                                @SuppressWarnings("unused")
                                                                                                                                                                private String normalField;
                                                                                                                                                            }
                                                                                                                                                            
                                                                                                                                                            Gson gson = mock(Gson.class);
                                                                                                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                            FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                                                                                            Excluder excluder = mock(Excluder.class);
                                                                                                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                constructorConstructor, fieldNamingPolicy, excluder);
                                                                                                                                                            
                                                                                                                                                            Field field = SampleClass.class.getDeclaredField("normalField");
                                                                                                                                                            TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                                                                                                            String name = "normalField";
                                                                                                                                                            boolean serialize = false; // Not serialized
                                                                                                                                                            boolean deserialize = true;
                                                                                                                                                            
                                                                                                                                                            @SuppressWarnings("rawtypes")
                                                                                                                                                            TypeAdapter mockAdapter = mock(TypeAdapter.class);
                                                                                                                                                            when(gson.getAdapter(fieldType)).thenReturn(mockAdapter);
                                                                                                                                                            
                                                                                                                                                            // Access private createBoundField method via reflection
                                                                                                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                                "createBoundField", 
                                                                                                                                                                Gson.class, 
                                                                                                                                                                Field.class, 
                                                                                                                                                                String.class, 
                                                                                                                                                                TypeToken.class, 
                                                                                                                                                                boolean.class, 
                                                                                                                                                                boolean.class
                                                                                                                                                            );
                                                                                                                                                            createBoundFieldMethod.setAccessible(true);
                                                                                                                                                            
                                                                                                                                                            // Test
                                                                                                                                                            Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                                factory, 
                                                                                                                                                                gson, field, name, fieldType, serialize, deserialize
                                                                                                                                                            );
                                                                                                                                                            
                                                                                                                                                            // Use reflection to access writeField method
                                                                                                                                                            Method writeFieldMethod = boundField.getClass().getDeclaredMethod("writeField", Object.class);
                                                                                                                                                            writeFieldMethod.setAccessible(true);
                                                                                                                                                            boolean result = (boolean) writeFieldMethod.invoke(boundField, new Object());
                                                                                                                                                            
                                                                                                                                                            // Verify
                                                                                                                                                            assertFalse(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                        public void testRead_NullValue() throws IOException {
                                                                                                                                                            JsonReader in = mock(JsonReader.class);
                                                                                                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                            FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                            Excluder excluder = mock(Excluder.class);
                                                                                                                                                            
                                                                                                                                                            ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                                constructorConstructor, fieldNamingStrategy, excluder);
                                                                                                                                                            
                                                                                                                                                            // Create a TypeAdapter for Object.class
                                                                                                                                                            TypeToken<Object> typeToken = TypeToken.get(Object.class);
                                                                                                                                                            TypeAdapter<Object> adapter = adapterFactory.create(mock(Gson.class), typeToken);
                                                                                                                                                            
                                                                                                                                                            when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                            
                                                                                                                                                            Object result = adapter.read(in);
                                                                                                                                                            
                                                                                                                                                            verify(in).nextNull();
                                                                                                                                                            assertNull(result);
                                                                                                                                                        }

    @Test
                                                                                                                                                public void testCreateBoundField_WithoutJsonAdapterAnnotation() throws Exception {
                                                                                                                                                    // Define a simple test class
                                                                                                                                                    class SampleClass {
                                                                                                                                                        public String normalField;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Setup
                                                                                                                                                    Field field = SampleClass.class.getDeclaredField("normalField");
                                                                                                                                                    TypeToken<String> fieldType = new TypeToken<String>() {};
                                                                                                                                                    String name = "normalField";
                                                                                                                                                    boolean serialize = true;
                                                                                                                                                    boolean deserialize = true;
                                                                                                                                                    
                                                                                                                                                    // Mock objects
                                                                                                                                                    Gson gson = mock(Gson.class);
                                                                                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                                                                                    
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    TypeAdapter<String> mockAdapter = mock(TypeAdapter.class);
                                                                                                                                                    when(gson.getAdapter(fieldType)).thenReturn(mockAdapter);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access createBoundField since it's private
                                                                                                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                        "createBoundField", 
                                                                                                                                                        Gson.class, Field.class, String.class, TypeToken.class, 
                                                                                                                                                        boolean.class, boolean.class);
                                                                                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test
                                                                                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                        factory, gson, field, name, fieldType, serialize, deserialize);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(boundField);
                                                                                                                                                    verify(gson).getAdapter(fieldType);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testCreateBoundField_Read_NullValueForPrimitive() throws Exception {
                                                                                                                                                    // Define sample class for testing
                                                                                                                                                    class SampleClass {
                                                                                                                                                        int primitiveField;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Setup
                                                                                                                                                    Gson gson = mock(Gson.class);
                                                                                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                                                                                    
                                                                                                                                                    Field field = SampleClass.class.getDeclaredField("primitiveField");
                                                                                                                                                    TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                                                                                                    String name = "primitiveField";
                                                                                                                                                    boolean serialize = true;
                                                                                                                                                    boolean deserialize = true;
                                                                                                                                                    
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    TypeAdapter<Integer> mockAdapter = mock(TypeAdapter.class);
                                                                                                                                                    when(mockAdapter.read(any(JsonReader.class))).thenReturn(null);
                                                                                                                                                    when(gson.getAdapter(any(TypeToken.class))).thenReturn(mockAdapter);
                                                                                                                                                    
                                                                                                                                                    SampleClass instance = new SampleClass();
                                                                                                                                                    instance.primitiveField = 42; // Initial value
                                                                                                                                                    
                                                                                                                                                    JsonReader reader = mock(JsonReader.class);
                                                                                                                                                    
                                                                                                                                                    // Test - use reflection to access private method
                                                                                                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                        "createBoundField", Gson.class, Field.class, String.class, 
                                                                                                                                                        TypeToken.class, boolean.class, boolean.class);
                                                                                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                        factory, gson, field, name, fieldType, serialize, deserialize);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to invoke read method since BoundField is not public
                                                                                                                                                    Method readMethod = boundField.getClass().getDeclaredMethod(
                                                                                                                                                        "read", JsonReader.class, Object.class);
                                                                                                                                                    readMethod.setAccessible(true);
                                                                                                                                                    readMethod.invoke(boundField, reader, instance);
                                                                                                                                                    
                                                                                                                                                    // Verify - primitive field should not be set to null
                                                                                                                                                    assertEquals(42, instance.primitiveField);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testCreateBoundField_Read_NonNullValueForObject() throws Exception {
                                                                                                                                                    // Define sample class
                                                                                                                                                    class SampleClass {
                                                                                                                                                        private Object normalField;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Setup
                                                                                                                                                    Field field = SampleClass.class.getDeclaredField("normalField");
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    com.google.gson.reflect.TypeToken<Object> fieldType = (com.google.gson.reflect.TypeToken<Object>) com.google.gson.reflect.TypeToken.get(field.getGenericType());
                                                                                                                                                    String name = "normalField";
                                                                                                                                                    boolean serialize = true;
                                                                                                                                                    boolean deserialize = true;
                                                                                                                                                    
                                                                                                                                                    Object expectedValue = "testValue";
                                                                                                                                                    com.google.gson.TypeAdapter<Object> mockAdapter = mock(com.google.gson.TypeAdapter.class);
                                                                                                                                                    when(mockAdapter.read(any(com.google.gson.stream.JsonReader.class))).thenReturn(expectedValue);
                                                                                                                                                    
                                                                                                                                                    com.google.gson.Gson gson = mock(com.google.gson.Gson.class);
                                                                                                                                                    when(gson.getAdapter(fieldType)).thenReturn(mockAdapter);
                                                                                                                                                    
                                                                                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                                                                                    
                                                                                                                                                    SampleClass instance = new SampleClass();
                                                                                                                                                    com.google.gson.stream.JsonReader reader = mock(com.google.gson.stream.JsonReader.class);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private createBoundField method
                                                                                                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                        "createBoundField", 
                                                                                                                                                        com.google.gson.Gson.class, 
                                                                                                                                                        Field.class, 
                                                                                                                                                        String.class, 
                                                                                                                                                        com.google.gson.reflect.TypeToken.class, 
                                                                                                                                                        boolean.class, 
                                                                                                                                                        boolean.class);
                                                                                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test
                                                                                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                        factory, 
                                                                                                                                                        gson, field, name, fieldType, serialize, deserialize);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access read method
                                                                                                                                                    Method readMethod = boundField.getClass().getDeclaredMethod("read", 
                                                                                                                                                        com.google.gson.stream.JsonReader.class, Object.class);
                                                                                                                                                    readMethod.setAccessible(true);
                                                                                                                                                    readMethod.invoke(boundField, reader, instance);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    assertEquals(expectedValue, field.get(instance));
                                                                                                                                                }

    @Test
                                                                                                                                                public void testCreateBoundField_Write_WithJsonAdapterPresent() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    class SampleClass {
                                                                                                                                                        @com.google.gson.annotations.JsonAdapter(Object.class)
                                                                                                                                                        private String annotatedField;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    Field field = SampleClass.class.getDeclaredField("annotatedField");
                                                                                                                                                    com.google.gson.reflect.TypeToken<?> fieldType = com.google.gson.reflect.TypeToken.get(field.getGenericType());
                                                                                                                                                    String name = "annotatedField";
                                                                                                                                                    boolean serialize = true;
                                                                                                                                                    boolean deserialize = true;
                                                                                                                                                    
                                                                                                                                                    // Mock JsonAdapter annotation
                                                                                                                                                    com.google.gson.annotations.JsonAdapter jsonAdapterAnnotation = mock(com.google.gson.annotations.JsonAdapter.class);
                                                                                                                                                    Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                                                                    modifiersField.setAccessible(true);
                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Mock factory and gson
                                                                                                                                                    com.google.gson.internal.ConstructorConstructor constructorConstructor = mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                                                                                                    com.google.gson.internal.bind.ReflectiveTypeAdapterFactory factory = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                                                                                                        constructorConstructor, mock(com.google.gson.FieldNamingStrategy.class), mock(com.google.gson.internal.Excluder.class));
                                                                                                                                                    com.google.gson.Gson gson = mock(com.google.gson.Gson.class);
                                                                                                                                                    
                                                                                                                                                    // Mock behavior
                                                                                                                                                    when(field.getAnnotation(com.google.gson.annotations.JsonAdapter.class)).thenReturn(jsonAdapterAnnotation);
                                                                                                                                                    Object fieldValue = "testValue";
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    com.google.gson.TypeAdapter<Object> mockAdapter = mock(com.google.gson.TypeAdapter.class);
                                                                                                                                                    when(gson.getAdapter(any(com.google.gson.reflect.TypeToken.class))).thenReturn(mockAdapter);
                                                                                                                                                    
                                                                                                                                                    SampleClass instance = new SampleClass();
                                                                                                                                                    field.set(instance, fieldValue);
                                                                                                                                                    
                                                                                                                                                    com.google.gson.stream.JsonWriter writer = mock(com.google.gson.stream.JsonWriter.class);
                                                                                                                                                    
                                                                                                                                                    // Get private createBoundField method via reflection
                                                                                                                                                    Method createBoundFieldMethod = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                                                                                                                        .getDeclaredMethod("createBoundField", com.google.gson.Gson.class, Field.class, String.class,
                                                                                                                                                            com.google.gson.reflect.TypeToken.class, boolean.class, boolean.class);
                                                                                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test
                                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                        factory, gson, field, name, fieldType, serialize, deserialize);
                                                                                                                                                    
                                                                                                                                                    // Get private write method of BoundField via reflection
                                                                                                                                                    Method writeMethod = boundField.getClass().getDeclaredMethod("write", 
                                                                                                                                                        com.google.gson.stream.JsonWriter.class, Object.class);
                                                                                                                                                    writeMethod.setAccessible(true);
                                                                                                                                                    writeMethod.invoke(boundField, writer, instance);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    verify(mockAdapter).write(writer, fieldValue);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testWrite_WithValidObject() throws Exception {
                                                                                                                                                    // Create mocks
                                                                                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                    FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                                                                                    Gson gson = mock(Gson.class);
                                                                                                                                                    
                                                                                                                                                    // Create real factory
                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                        constructorConstructor,
                                                                                                                                                        fieldNamingStrategy,
                                                                                                                                                        excluder
                                                                                                                                                    );
                                                                                                                                                    
                                                                                                                                                    // Create a test adapter that implements the write method
                                                                                                                                                    TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                        @Override
                                                                                                                                                        public void write(JsonWriter writer, String value) throws IOException {
                                                                                                                                                            writer.value(value.toString());
                                                                                                                                                        }
                                                                                                                                                        
                                                                                                                                                        @Override
                                                                                                                                                        public String read(JsonReader in) throws IOException {
                                                                                                                                                            return null;
                                                                                                                                                        }
                                                                                                                                                    };
                                                                                                                                                    
                                                                                                                                                    // Mock the factory to return our test adapter
                                                                                                                                                    when(gson.getAdapter(any(TypeToken.class))).thenReturn(adapter);
                                                                                                                                                    
                                                                                                                                                    JsonWriter writer = mock(JsonWriter.class);
                                                                                                                                                    String testValue = "testValue";
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private createBoundField method
                                                                                                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                        "createBoundField",
                                                                                                                                                        Gson.class,
                                                                                                                                                        Field.class,
                                                                                                                                                        String.class,
                                                                                                                                                        TypeToken.class,
                                                                                                                                                        boolean.class,
                                                                                                                                                        boolean.class
                                                                                                                                                    );
                                                                                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Create a bound field that will use our adapter
                                                                                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                        factory,
                                                                                                                                                        gson,
                                                                                                                                                        mock(Field.class),
                                                                                                                                                        "testField",
                                                                                                                                                        TypeToken.get(String.class),
                                                                                                                                                        true,
                                                                                                                                                        false
                                                                                                                                                    );
                                                                                                                                                    
                                                                                                                                                    // Get write method from BoundField class
                                                                                                                                                    Method writeMethod = boundField.getClass().getDeclaredMethod("write", JsonWriter.class, Object.class);
                                                                                                                                                    writeMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test the write operation
                                                                                                                                                    writeMethod.invoke(boundField, writer, testValue);
                                                                                                                                                    
                                                                                                                                                    // Verify the writer was called correctly
                                                                                                                                                    verify(writer).value(testValue);
                                                                                                                                                }

    @Test
                                                                                                                                                public void testCreateBoundField_WithSerializableField_CreatesBoundField() throws Exception {
                                                                                                                                                    // Setup
                                                                                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                                    FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                                                                                    when(excluder.excludeField(any(Field.class), anyBoolean())).thenReturn(false);
                                                                                                                                                    
                                                                                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                                        constructorConstructor, fieldNamingStrategy, excluder);
                                                                                                                                                    Gson gson = new Gson();
                                                                                                                                                    
                                                                                                                                                    // Define a simple test class
                                                                                                                                                    class TestClass {
                                                                                                                                                        private String testField;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    Field field = TestClass.class.getDeclaredField("testField");
                                                                                                                                                    TypeToken<String> fieldType = TypeToken.get(String.class);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to access private method
                                                                                                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                                                                                        "createBoundField", 
                                                                                                                                                        Gson.class, 
                                                                                                                                                        Field.class, 
                                                                                                                                                        String.class, 
                                                                                                                                                        TypeToken.class, 
                                                                                                                                                        boolean.class, 
                                                                                                                                                        boolean.class);
                                                                                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                                                                                    
                                                                                                                                                    // Test
                                                                                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                                                                                        factory, 
                                                                                                                                                        gson, 
                                                                                                                                                        field, 
                                                                                                                                                        "testField", 
                                                                                                                                                        fieldType, 
                                                                                                                                                        true, 
                                                                                                                                                        false);
                                                                                                                                                    
                                                                                                                                                    // Verify
                                                                                                                                                    assertNotNull(boundField);
                                                                                                                                                }

    @Test
                                                                                                                                        public void testRead_WithValidFields() throws IOException {
                                                                                                                                            // Setup mocks and test data
                                                                                                                                            com.google.gson.stream.JsonReader in = mock(com.google.gson.stream.JsonReader.class);
                                                                                                                                            com.google.gson.internal.ConstructorConstructor constructor = mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                                                                                            java.util.Map<String, Object> boundFields = new java.util.HashMap<String, Object>();
                                                                                                                                            ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(constructor, null, null);
                                                                                                                                            
                                                                                                                                            Object mockInstance = new Object();
                                                                                                                                            
                                                                                                                                            // Create a mock BoundField using reflection
                                                                                                                                            try {
                                                                                                                                                // Get the BoundField class
                                                                                                                                                Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                                                                                                                                                
                                                                                                                                                // Create a mock instance
                                                                                                                                                Object validField = mock(boundFieldClass);
                                                                                                                                                
                                                                                                                                                // Mock the deserialized field
                                                                                                                                                when(boundFieldClass.getMethod("isDeserialized").invoke(validField)).thenReturn(true);
                                                                                                                                                
                                                                                                                                                // Get the read method
                                                                                                                                                Method readMethod = boundFieldClass.getMethod("read", com.google.gson.stream.JsonReader.class, Object.class);
                                                                                                                                                
                                                                                                                                                // Mock the read method
                                                                                                                                                doNothing().when(readMethod).invoke(validField, any(com.google.gson.stream.JsonReader.class), any(Object.class));
                                                                                                                                                
                                                                                                                                                boundFields.put("validField", validField);
                                                                                                                                                
                                                                                                                                                // Mock JSON reading behavior
                                                                                                                                                when(in.peek()).thenReturn(com.google.gson.stream.JsonToken.BEGIN_OBJECT);
                                                                                                                                                when(constructor.get(any(com.google.gson.reflect.TypeToken.class))).thenReturn(new com.google.gson.InstanceCreator<Object>() {
                                                                                                                                                    @Override
                                                                                                                                                    public Object createInstance(Type type) {
                                                                                                                                                        return mockInstance;
                                                                                                                                                    }
                                                                                                                                                });
                                                                                                                                                when(in.hasNext()).thenReturn(true, false);
                                                                                                                                                when(in.nextName()).thenReturn("validField");
                                                                                                                                                
                                                                                                                                                // Use reflection to set boundFields
                                                                                                                                                Field boundFieldsField = ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                                                                                                                boundFieldsField.setAccessible(true);
                                                                                                                                                boundFieldsField.set(adapterFactory, boundFields);
                                                                                                                                                
                                                                                                                                                // Execute test
                                                                                                                                                Object result = adapterFactory.create(null, null).read(in);
                                                                                                                                                
                                                                                                                                                // Verify behavior
                                                                                                                                                verify(in).beginObject();
                                                                                                                                                verify(in).endObject();
                                                                                                                                                assertEquals(mockInstance, result);
                                                                                                                                                
                                                                                                                                                // Verify field was read
                                                                                                                                                verify(readMethod).invoke(validField, eq(in), eq(mockInstance));
                                                                                                                                                
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                throw new RuntimeException(e);
                                                                                                                                            }
                                                                                                                                        }

    @Test(expected = JsonSyntaxException.class)
                                                                                                                            public void testRead_ThrowsJsonSyntaxException() throws IOException {
                                                                                                                                JsonReader in = mock(JsonReader.class);
                                                                                                                                ConstructorConstructor constructor = mock(ConstructorConstructor.class);
                                                                                                                                FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                Excluder excluder = mock(Excluder.class);
                                                                                                                                ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                                                                    constructor, fieldNamingStrategy, excluder);
                                                                                                                                
                                                                                                                                Object mockInstance = new Object();
                                                                                                                                when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
                                                                                                                                when(in.hasNext()).thenReturn(true);
                                                                                                                                when(in.nextName()).thenThrow(new IllegalStateException("Test exception"));
                                                                                                                                
                                                                                                                                Gson gson = mock(Gson.class);
                                                                                                                                TypeAdapter<Object> adapter = adapterFactory.create(gson, TypeToken.get(Object.class));
                                                                                                                                adapter.read(in);
                                                                                                                            }

    @Test(expected = AssertionError.class)
                                                                                                                            public void testRead_ThrowsAssertionError() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                                                                                // Setup mocks
                                                                                                                                JsonReader in = mock(JsonReader.class);
                                                                                                                                ConstructorConstructor constructor = mock(ConstructorConstructor.class);
                                                                                                                                FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                Excluder excluder = mock(Excluder.class);
                                                                                                                                ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                                                                    constructor, fieldNamingStrategy, excluder);
                                                                                                                                
                                                                                                                                // Use reflection to access private boundFields map
                                                                                                                                Field boundFieldsField = ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                                                                                                boundFieldsField.setAccessible(true);
                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                Map<String, Object> boundFields = 
                                                                                                                                    (Map<String, Object>) boundFieldsField.get(adapterFactory);
                                                                                                                                if (boundFields == null) {
                                                                                                                                    boundFieldsField.set(adapterFactory, boundFields);
                                                                                                                                }
                                                                                                                                
                                                                                                                                Object mockInstance = new Object();
                                                                                                                                // Get the BoundField class via reflection
                                                                                                                                Class<?> boundFieldClass = null;
                                                                                                                                for (Class<?> clazz : ReflectiveTypeAdapterFactory.class.getDeclaredClasses()) {
                                                                                                                                    if (clazz.getSimpleName().equals("BoundField")) {
                                                                                                                                        boundFieldClass = clazz;
                                                                                                                                        break;
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                assertNotNull(boundFieldClass);
                                                                                                                                
                                                                                                                                // Create a real instance of BoundField instead of mocking
                                                                                                                                Constructor<?> boundFieldConstructor = boundFieldClass.getDeclaredConstructors()[0];
                                                                                                                                boundFieldConstructor.setAccessible(true);
                                                                                                                                
                                                                                                                                // Setup field to simulate deserialized field
                                                                                                                                Field deserializedField = boundFieldClass.getDeclaredField("deserialized");
                                                                                                                                deserializedField.setAccessible(true);
                                                                                                                                
                                                                                                                                
                                                                                                                                when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
                                                                                                                                when(in.hasNext()).thenReturn(true, false);
                                                                                                                                when(in.nextName()).thenReturn("field");
                                                                                                                                
                                                                                                                                // Force the read to throw IllegalAccessException
                                                                                                                                doThrow(new IllegalAccessException()).when(in).nextString();
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    adapterFactory.create(mock(Gson.class), TypeToken.get(Object.class)).read(in);
                                                                                                                                } catch (RuntimeException e) {
                                                                                                                                    if (e.getCause() instanceof IllegalAccessException) {
                                                                                                                                        throw new AssertionError();
                                                                                                                                    }
                                                                                                                                    throw e;
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testWrite_NullValue() throws Exception {
                                                                                                                                // Create mocks
                                                                                                                                com.google.gson.stream.JsonWriter mockWriter = mock(com.google.gson.stream.JsonWriter.class);
                                                                                                                                com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                                                                                                    mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                                                                                com.google.gson.FieldNamingStrategy fieldNamingStrategy = 
                                                                                                                                    mock(com.google.gson.FieldNamingStrategy.class);
                                                                                                                                com.google.gson.internal.Excluder excluder = mock(com.google.gson.internal.Excluder.class);
                                                                                                                                com.google.gson.Gson gson = mock(com.google.gson.Gson.class);
                                                                                                                                
                                                                                                                                // Create the factory
                                                                                                                                com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                                                                                                                                    new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                                                                                        constructorConstructor, fieldNamingStrategy, excluder);
                                                                                                                                
                                                                                                                                // Get BoundField class via reflection
                                                                                                                                Class<?> boundFieldClass = Class.forName(
                                                                                                                                    "com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                                                                                                                                
                                                                                                                                // Create a mock BoundField using reflection
                                                                                                                                Object boundField = Proxy.newProxyInstance(
                                                                                                                                    boundFieldClass.getClassLoader(),
                                                                                                                                    new Class<?>[] { boundFieldClass },
                                                                                                                                    (proxy, method, args) -> {
                                                                                                                                        if (method.getName().equals("write")) {
                                                                                                                                            if (args[1] == null) {
                                                                                                                                                ((com.google.gson.stream.JsonWriter)args[0]).nullValue();
                                                                                                                                            }
                                                                                                                                            return null;
                                                                                                                                        } else if (method.getName().equals("writeField")) {
                                                                                                                                            return true;
                                                                                                                                        } else if (method.getName().equals("read")) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        return null;
                                                                                                                                    });
                                                                                                                                
                                                                                                                                // Use reflection to set the boundFields map
                                                                                                                                java.lang.reflect.Field boundFieldsField = 
                                                                                                                                    com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                                                                                                boundFieldsField.setAccessible(true);
                                                                                                                                java.util.Map<String, Object> boundFields = new java.util.HashMap<>();
                                                                                                                                boundFields.put("testField", boundField);
                                                                                                                                boundFieldsField.set(adapterFactory, boundFields);
                                                                                                                                
                                                                                                                                // Test the write method with null value
                                                                                                                                adapterFactory.create(gson, com.google.gson.reflect.TypeToken.get(Object.class))
                                                                                                                                    .write(mockWriter, null);
                                                                                                                                
                                                                                                                                // Verify interactions
                                                                                                                                verify(mockWriter).nullValue();
                                                                                                                                verifyNoMoreInteractions(mockWriter);
                                                                                                                            }

    @Test
                                                                                                                            public void testWrite_SomeFieldsIncluded() throws Exception {
                                                                                                                                // Create mock objects
                                                                                                                                com.google.gson.stream.JsonWriter mockWriter = mock(com.google.gson.stream.JsonWriter.class);
                                                                                                                                
                                                                                                                                // Get BoundField class through reflection
                                                                                                                                Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                                                                                                                                
                                                                                                                                // Create test BoundField implementations using reflection
                                                                                                                                Object mockBoundField1 = Proxy.newProxyInstance(
                                                                                                                                    getClass().getClassLoader(),
                                                                                                                                    new Class<?>[] {boundFieldClass},
                                                                                                                                    (proxy, method, args) -> {
                                                                                                                                        if (method.getName().equals("writeField")) {
                                                                                                                                            return true;
                                                                                                                                        }
                                                                                                                                        if (method.getName().equals("write")) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        if (method.getName().equals("read")) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        return method.invoke(proxy, args);
                                                                                                                                    });
                                                                                                                                
                                                                                                                                Object mockBoundField2 = Proxy.newProxyInstance(
                                                                                                                                    getClass().getClassLoader(),
                                                                                                                                    new Class<?>[] {boundFieldClass},
                                                                                                                                    (proxy, method, args) -> {
                                                                                                                                        if (method.getName().equals("writeField")) {
                                                                                                                                            return false;
                                                                                                                                        }
                                                                                                                                        if (method.getName().equals("write")) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        if (method.getName().equals("read")) {
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        return method.invoke(proxy, args);
                                                                                                                                    });
                                                                                                                                
                                                                                                                                // Initialize adapter factory with required dependencies
                                                                                                                                com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                                                                                                    mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                                                                                com.google.gson.FieldNamingStrategy fieldNamingStrategy = 
                                                                                                                                    mock(com.google.gson.FieldNamingStrategy.class);
                                                                                                                                com.google.gson.internal.Excluder excluder = 
                                                                                                                                    mock(com.google.gson.internal.Excluder.class);
                                                                                                                                com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                                                                                                                                    new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                                                                                        constructorConstructor, fieldNamingStrategy, excluder);
                                                                                                                                
                                                                                                                                // Create and populate bound fields map
                                                                                                                                java.util.Map<String, Object> mockBoundFields = new java.util.HashMap<>();
                                                                                                                                mockBoundFields.put("field1", mockBoundField1);
                                                                                                                                mockBoundFields.put("field2", mockBoundField2);
                                                                                                                                
                                                                                                                                // Set boundFields in adapterFactory using reflection
                                                                                                                                java.lang.reflect.Field boundFieldsField = 
                                                                                                                                    com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                                                                                                boundFieldsField.setAccessible(true);
                                                                                                                                boundFieldsField.set(adapterFactory, mockBoundFields);
                                                                                                                                
                                                                                                                                // Execute test
                                                                                                                                Object testObject = new Object();
                                                                                                                                
                                                                                                                                // Verify behavior
                                                                                                                                verify(mockWriter).name("field1");
                                                                                                                                verify(mockWriter, never()).name("field2");
                                                                                                                            }

    @Test
                                                                                                                            public void testWrite_ThrowsIOException() throws IOException {
                                                                                                                                // Define expected exception rule
                                                                                                                                ExpectedException expectedException = ExpectedException.none();
                                                                                                                                
                                                                                                                                // Create a mock TypeAdapter that throws IOException
                                                                                                                                TypeAdapter<String> mockAdapter = new TypeAdapter<String>() {
                                                                                                                                    @Override
                                                                                                                                    public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                        throw new IOException("Test IO Exception");
                                                                                                                                    }
                                                                                                                                
                                                                                                                                    @Override
                                                                                                                                    public String read(JsonReader in) throws IOException {
                                                                                                                                        return null;
                                                                                                                                    }
                                                                                                                                };
                                                                                                                                
                                                                                                                                // Create required mocks
                                                                                                                                ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                                                                FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                                                                Excluder excluder = mock(Excluder.class);
                                                                                                                                
                                                                                                                                // Create factory instance
                                                                                                                                ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                                                                    constructorConstructor, fieldNamingStrategy, excluder);
                                                                                                                                
                                                                                                                                // Mock Gson and TypeToken
                                                                                                                                Gson gson = mock(Gson.class);
                                                                                                                                TypeToken<String> typeToken = TypeToken.get(String.class);
                                                                                                                                
                                                                                                                                // Use reflection to inject our mock adapter
                                                                                                                                try {
                                                                                                                                    Field boundTypesField = ReflectiveTypeAdapterFactory.class.getDeclaredField("boundTypes");
                                                                                                                                    boundTypesField.setAccessible(true);
                                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                                    Map<TypeToken<?>, TypeAdapter<?>> boundTypes = (Map<TypeToken<?>, TypeAdapter<?>>) boundTypesField.get(factory);
                                                                                                                                    boundTypes.put(typeToken, mockAdapter);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    throw new RuntimeException(e);
                                                                                                                                }
                                                                                                                                
                                                                                                                                JsonWriter writer = mock(JsonWriter.class);
                                                                                                                                TypeAdapter<String> adapter = factory.create(gson, typeToken);
                                                                                                                                
                                                                                                                                // Set expectations
                                                                                                                                expectedException.expectMessage("Test IO Exception");
                                                                                                                                
                                                                                                                                // Test
                                                                                                                                adapter.write(writer, "test");
                                                                                                                            }

    @Test(expected = IllegalAccessException.class)
                                                                                                        public void testWrite_IllegalAccessException() throws Exception {
                                                                                                            // Create mock objects
                                                                                                            com.google.gson.stream.JsonWriter mockWriter = mock(com.google.gson.stream.JsonWriter.class);
                                                                                                            com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                                                                                mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                                                            com.google.gson.FieldNamingStrategy fieldNamingPolicy = 
                                                                                                                mock(com.google.gson.FieldNamingStrategy.class);
                                                                                                            com.google.gson.internal.Excluder excluder = mock(com.google.gson.internal.Excluder.class);
                                                                                                            
                                                                                                            // Create real adapter factory with mock dependencies
                                                                                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                                                                                                                new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                                                                    constructorConstructor, fieldNamingPolicy, excluder);
                                                                                                            
                                                                                                            // Create test object and type token
                                                                                                            Object testObject = new Object();
                                                                                                            com.google.gson.reflect.TypeToken<Object> typeToken = com.google.gson.reflect.TypeToken.get(Object.class);
                                                                                                            
                                                                                                            // Use reflection to access private boundFields map
                                                                                                            java.lang.reflect.Field boundFieldsField = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                                                                                .getDeclaredField("boundFields");
                                                                                                            boundFieldsField.setAccessible(true);
                                                                                                            
                                                                                                            @SuppressWarnings("unchecked")
                                                                                                            java.util.Map<com.google.gson.reflect.TypeToken<?>, java.util.Map<String, Object>> boundFields = 
                                                                                                                (java.util.Map<com.google.gson.reflect.TypeToken<?>, java.util.Map<String, Object>>) boundFieldsField.get(adapterFactory);
                                                                                                            
                                                                                                            // Create mock bound field behavior using dynamic proxy
                                                                                                            java.util.Map<String, Object> mockBoundFields = new java.util.HashMap<>();
                                                                                                            Object mockBoundField = Proxy.newProxyInstance(
                                                                                                                this.getClass().getClassLoader(),
                                                                                                                new Class<?>[] {
                                                                                                                    Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField")
                                                                                                                },
                                                                                                                (proxy, method, args) -> {
                                                                                                                    if (method.getName().equals("write")) {
                                                                                                                        throw new IllegalAccessException("Test exception");
                                                                                                                    }
                                                                                                                    if (method.getName().equals("writeField")) {
                                                                                                                        return true;
                                                                                                                    }
                                                                                                                    if (method.getName().equals("read")) {
                                                                                                                        throw new UnsupportedOperationException();
                                                                                                                    }
                                                                                                                    return null;
                                                                                                                });
                                                                                                            
                                                                                                            mockBoundFields.put("field1", mockBoundField);
                                                                                                            boundFields.put(typeToken, mockBoundFields);
                                                                                                            
                                                                                                            // This should throw IllegalAccessException
                                                                                                            adapterFactory.create(null, typeToken).write(mockWriter, testObject);
                                                                                                        }

    @Test
                                                                                        public void testWrite_WithFields() throws Exception {
                                                                                            // Create mock objects using reflection since BoundField is package-private
                                                                                            Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                                                                                            Object mockBoundField1 = mock(boundFieldClass);
                                                                                            Object mockBoundField2 = mock(boundFieldClass);
                                                                                            com.google.gson.stream.JsonWriter mockWriter = mock(com.google.gson.stream.JsonWriter.class);
                                                                                            
                                                                                            // Create test object
                                                                                            Object testObject = new Object();
                                                                                            
                                                                                            // Create mockBoundFields map
                                                                                            java.util.Map<String, Object> mockBoundFields = new java.util.LinkedHashMap<>();
                                                                                            
                                                                                            // Create adapter factory with required dependencies
                                                                                            com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                                                                mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                                            com.google.gson.FieldNamingStrategy fieldNamingPolicy = 
                                                                                                mock(com.google.gson.FieldNamingStrategy.class);
                                                                                            com.google.gson.internal.Excluder excluder = mock(com.google.gson.internal.Excluder.class);
                                                                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                                                                                                new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                                                    constructorConstructor, fieldNamingPolicy, excluder);
                                                                                            
                                                                                            // Set up mock behavior using reflection
                                                                                            java.lang.reflect.Method writeFieldMethod = boundFieldClass.getDeclaredMethod(
                                                                                                "write", com.google.gson.stream.JsonWriter.class, Object.class);
                                                                                            writeFieldMethod.setAccessible(true);
                                                                                            when(writeFieldMethod.invoke(mockBoundField1, mockWriter, testObject)).thenReturn(null);
                                                                                            
                                                                                            java.lang.reflect.Method getNameMethod = boundFieldClass.getDeclaredMethod("getName");
                                                                                            getNameMethod.setAccessible(true);
                                                                                            when(getNameMethod.invoke(mockBoundField1)).thenReturn("field1");
                                                                                            
                                                                                            when(writeFieldMethod.invoke(mockBoundField2, mockWriter, testObject)).thenReturn(null);
                                                                                            when(getNameMethod.invoke(mockBoundField2)).thenReturn("field2");
                                                                                            
                                                                                            mockBoundFields.put("field1", mockBoundField1);
                                                                                            mockBoundFields.put("field2", mockBoundField2);
                                                                                            
                                                                                            // Use reflection to set boundFields in adapterFactory
                                                                                            java.lang.reflect.Field boundFieldsField = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                                                                .getDeclaredField("boundFields");
                                                                                            boundFieldsField.setAccessible(true);
                                                                                            boundFieldsField.set(adapterFactory, mockBoundFields);
                                                                                            
                                                                                            // Create in-order verifier
                                                                                            org.mockito.InOrder inOrder = inOrder(mockWriter);
                                                                                            
                                                                                            // Get and invoke the write method using reflection
                                                                                            java.lang.reflect.Method writeMethod = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                                                                .getDeclaredMethod("write", com.google.gson.stream.JsonWriter.class, Object.class);
                                                                                            writeMethod.setAccessible(true);
                                                                                            writeMethod.invoke(adapterFactory, mockWriter, testObject);
                                                                                            
                                                                                            // Verify write sequence
                                                                                            inOrder.verify(mockWriter).beginObject();
                                                                                            inOrder.verify(mockWriter).name("field1");
                                                                                            inOrder.verify(mockWriter).name("field2");
                                                                                            inOrder.verify(mockWriter).endObject();
                                                                                        }

    @Test
                                                                        public void testRead_WithUnknownField() throws IOException, NoSuchFieldException, IllegalAccessException {
                                                                            // Create mock objects
                                                                            JsonReader in = mock(JsonReader.class);
                                                                            ConstructorConstructor constructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            
                                                                            // Initialize required objects
                                                                            Object mockInstance = new Object();
                                                                            
                                                                            // Create adapter factory with mocks
                                                                            ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                constructor, 
                                                                                fieldNamingStrategy, 
                                                                                excluder
                                                                            );
                                                                            
                                                                            // Set up mock behaviors
                                                                            when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
                                                                            when(constructor.get(TypeToken.get(Object.class))).thenReturn(new ObjectConstructor<Object>() {
                                                                                @Override
                                                                                public Object construct() {
                                                                                    return mockInstance;
                                                                                }
                                                                            });
                                                                            when(in.hasNext()).thenReturn(true, false);
                                                                            when(in.nextName()).thenReturn("unknownField");
                                                                            
                                                                            try {
                                                                                // Get BoundField class through reflection
                                                                                Class<?> boundFieldClass = null;
                                                                                for (Class<?> clazz : ReflectiveTypeAdapterFactory.class.getDeclaredClasses()) {
                                                                                    if (clazz.getSimpleName().equals("BoundField")) {
                                                                                        boundFieldClass = clazz;
                                                                                        break;
                                                                                    }
                                                                                }
                                                                                
                                                                                if (boundFieldClass == null) {
                                                                                    fail("Could not find BoundField class");
                                                                                }
                                                                                
                                                                                // Create a BoundField instance using reflection
                                                                                Constructor<?> boundFieldConstructor = boundFieldClass.getDeclaredConstructor(
                                                                                    ReflectiveTypeAdapterFactory.class, String.class, boolean.class, boolean.class);
                                                                                boundFieldConstructor.setAccessible(true);
                                                                                
                                                                                Object boundField = boundFieldConstructor.newInstance(
                                                                                    adapterFactory, "knownField", true, true);
                                                                                
                                                                                // Use reflection to access private boundFields map
                                                                                Field boundFieldsField = ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                                                boundFieldsField.setAccessible(true);
                                                                                
                                                                                // Create and populate the boundFields map
                                                                                @SuppressWarnings("unchecked")
                                                                                Map<String, Object> boundFieldsMap = new java.util.HashMap<String, Object>();
                                                                                boundFieldsMap.put("knownField", boundField);
                                                                                boundFieldsField.set(adapterFactory, boundFieldsMap);
                                                                                
                                                                            } catch (Exception e) {
                                                                                fail("Failed to set up test: " + e.getMessage());
                                                                            }
                                                                            
                                                                            // Call method under test
                                                                            Object result = adapterFactory.create(null, TypeToken.get(Object.class)).read(in);
                                                                            
                                                                            // Verify interactions
                                                                            verify(in).beginObject();
                                                                            verify(in).nextName();
                                                                            verify(in).skipValue();
                                                                            verify(in).endObject();
                                                                            assertEquals(mockInstance, result);
                                                                        }

    @Test
                                                                    public void testGetBoundFields_WithValidType_ReturnsFieldMap() throws Exception {
                                                                        // Setup
                                                                        com.google.gson.internal.ConstructorConstructor mockConstructor = 
                                                                            new com.google.gson.internal.ConstructorConstructor(java.util.Collections.<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>>emptyMap());
                                                                        com.google.gson.FieldNamingStrategy mockNamingStrategy = com.google.gson.FieldNamingPolicy.IDENTITY;
                                                                        com.google.gson.internal.Excluder mockExcluder = com.google.gson.internal.Excluder.DEFAULT;
                                                                        
                                                                        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory factory = 
                                                                            new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                                mockConstructor, mockNamingStrategy, mockExcluder);
                                                                        com.google.gson.Gson gson = new com.google.gson.Gson();
                                                                        
                                                                        // Simple test class with one field
                                                                        class TestClass {
                                                                            public String field;
                                                                        }
                                                                        
                                                                        com.google.gson.reflect.TypeToken<TestClass> type = 
                                                                            com.google.gson.reflect.TypeToken.get(TestClass.class);
                                                                        
                                                                        // Access private method via reflection
                                                                        java.lang.reflect.Method getBoundFieldsMethod = 
                                                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                                                .getDeclaredMethod("getBoundFields", com.google.gson.Gson.class, 
                                                                                    com.google.gson.reflect.TypeToken.class, java.lang.Class.class);
                                                                        getBoundFieldsMethod.setAccessible(true);
                                                                        
                                                                        // Test
                                                                        @SuppressWarnings("unchecked")
                                                                        java.util.Map<String, Object> fields = 
                                                                            (java.util.Map<String, Object>) 
                                                                                getBoundFieldsMethod.invoke(factory, gson, type, TestClass.class);
                                                                        
                                                                        // Verify
                                                                        org.junit.Assert.assertFalse(fields.isEmpty());
                                                                        org.junit.Assert.assertTrue(fields.containsKey("field"));
                                                                    }

    @Test
                                                        public void testWrite_EmptyObject() throws Exception {
                                                            // Create mock objects
                                                            com.google.gson.stream.JsonWriter mockWriter = mock(com.google.gson.stream.JsonWriter.class);
                                                            
                                                            com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                                mock(com.google.gson.internal.ConstructorConstructor.class);
                                                            com.google.gson.FieldNamingStrategy fieldNamingPolicy = 
                                                                mock(com.google.gson.FieldNamingStrategy.class);
                                                            com.google.gson.internal.Excluder excluder = 
                                                                mock(com.google.gson.internal.Excluder.class);
                                                            
                                                            // Define a simple nested class with no fields to serialize
                                                            class EmptyClass {}
                                                            EmptyClass testObject = new EmptyClass();
                                                            
                                                            // Create adapter factory
                                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                                                                new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                    constructorConstructor, fieldNamingPolicy, excluder);
                                                            
                                                            // Mock excluder to exclude all fields (making the object effectively empty)
                                                            when(excluder.excludeField(
                                                                any(java.lang.reflect.Field.class), 
                                                                anyBoolean())).thenReturn(true);
                                                            
                                                            // Get the adapter and write the object
                                                            com.google.gson.TypeAdapter<EmptyClass> adapter = 
                                                                adapterFactory.create(
                                                                    mock(com.google.gson.Gson.class), 
                                                                    com.google.gson.reflect.TypeToken.get(EmptyClass.class));
                                                            adapter.write(mockWriter, testObject);
                                                            
                                                            // Verify behavior - only begin/end object should be called
                                                            verify(mockWriter).beginObject();
                                                            verify(mockWriter).endObject();
                                                            verifyNoMoreInteractions(mockWriter);
                                                        }

    @Test
                                                public void testWrite_WithNullValue() throws IOException, NoSuchFieldException, IllegalAccessException, ClassNotFoundException {
                                                    // Create mocks
                                                    com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                        mock(com.google.gson.internal.ConstructorConstructor.class);
                                                    com.google.gson.FieldNamingStrategy fieldNamingStrategy = 
                                                        mock(com.google.gson.FieldNamingStrategy.class);
                                                    com.google.gson.internal.Excluder excluder = 
                                                        mock(com.google.gson.internal.Excluder.class);
                                                    com.google.gson.stream.JsonWriter writer = 
                                                        mock(com.google.gson.stream.JsonWriter.class);
                                                    
                                                    // Create factory instance
                                                    com.google.gson.internal.bind.ReflectiveTypeAdapterFactory factory = 
                                                        new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                            constructorConstructor,
                                                            fieldNamingStrategy,
                                                            excluder
                                                        );
                                                    
                                                    // Create a mock TypeAdapter
                                                    com.google.gson.TypeAdapter<Object> adapter = mock(com.google.gson.TypeAdapter.class);
                                                    doAnswer(invocation -> {
                                                        com.google.gson.stream.JsonWriter out = invocation.getArgument(0);
                                                        Object value = invocation.getArgument(1);
                                                        if (value == null) {
                                                            out.nullValue();
                                                        } else {
                                                            out.value(value.toString());
                                                        }
                                                        return null;
                                                    }).when(adapter).write(any(com.google.gson.stream.JsonWriter.class), any());
                                                    
                                                    // Get BoundField class via reflection
                                                    Class<?> factoryClass = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class;
                                                    Class<?> boundFieldClass = null;
                                                    for (Class<?> innerClass : factoryClass.getDeclaredClasses()) {
                                                        if (innerClass.getSimpleName().equals("BoundField")) {
                                                            boundFieldClass = innerClass;
                                                            break;
                                                        }
                                                    }
                                                    assertNotNull("BoundField class should be found", boundFieldClass);
                                                    
                                                    // Create BoundField instance using reflection
                                                    Object boundField = Proxy.newProxyInstance(
                                                        boundFieldClass.getClassLoader(),
                                                        new Class<?>[] {boundFieldClass},
                                                        new java.lang.reflect.InvocationHandler() {
                                                            @Override
                                                            public Object invoke(Object proxy, java.lang.reflect.Method method, Object[] args) throws Throwable {
                                                                if ("write".equals(method.getName())) {
                                                                    adapter.write((com.google.gson.stream.JsonWriter)args[0], args[1]);
                                                                    return null;
                                                                } else if ("read".equals(method.getName())) {
                                                                    return null; // Not used in this test
                                                                } else if ("writeField".equals(method.getName())) {
                                                                    return true;
                                                                }
                                                                throw new UnsupportedOperationException("Unexpected method call: " + method.getName());
                                                            }
                                                        });
                                                    
                                                    // Create and populate boundFields map
                                                    java.util.Map<String, Object> boundFields = new java.util.HashMap<String, Object>();
                                                    boundFields.put("testField", boundField);
                                                    
                                                    // Use reflection to set the adapter
                                                    java.lang.reflect.Field boundFieldsField = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                        .getDeclaredField("boundFields");
                                                    boundFieldsField.setAccessible(true);
                                                    boundFieldsField.set(factory, boundFields);
                                                    
                                                    // Test the write method
                                                    factory.create(null, null).write(writer, null);
                                                    
                                                    // Verify behavior
                                                    verify(writer).nullValue();
                                                    verify(writer, never()).value(anyString());
                                                }

    @Test
                    public void testWrite_FieldOrderPreserved() throws Exception {
                        // Create mock objects
                        Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                        
                        // Create test object and mock fields
                        Object testObject = new Object();
                        java.util.Map<String, Object> mockBoundFields = new java.util.LinkedHashMap<>();
                        
                        // Create mock BoundField instances
                        Object mockBoundField1 = mock(boundFieldClass);
                        Object mockBoundField2 = mock(boundFieldClass);
                        
                        // Create mock JsonWriter and InOrder verification
                        com.google.gson.stream.JsonWriter mockWriter = mock(com.google.gson.stream.JsonWriter.class);
                        org.mockito.InOrder inOrder = inOrder(mockWriter);
                        
                        // Set up mock behavior using reflection
                        java.lang.reflect.Method writeFieldMethod = boundFieldClass.getDeclaredMethod("write", 
                            com.google.gson.stream.JsonWriter.class, Object.class);
                        java.lang.reflect.Method getNameMethod = boundFieldClass.getDeclaredMethod("getName");
                        
                        // Mock getName() to return field names
                        when(getNameMethod.invoke(mockBoundField1)).thenReturn("fieldA");
                        when(getNameMethod.invoke(mockBoundField2)).thenReturn("fieldB");
                        
                        // Mock writeField to do nothing
                        doNothing().when(writeFieldMethod).invoke(mockBoundField1, mockWriter, testObject);
                        doNothing().when(writeFieldMethod).invoke(mockBoundField2, mockWriter, testObject);
                        
                        // Insert in reverse order to test ordering
                        mockBoundFields.put("fieldB", mockBoundField2);
                        mockBoundFields.put("fieldA", mockBoundField1);
                        
                        // Create mock dependencies
                        com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                            mock(com.google.gson.internal.ConstructorConstructor.class);
                        com.google.gson.FieldNamingStrategy fieldNamingPolicy = 
                            mock(com.google.gson.FieldNamingStrategy.class);
                        com.google.gson.internal.Excluder excluder = 
                            mock(com.google.gson.internal.Excluder.class);
                        
                        // Create adapter factory with proper constructor
                        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                            new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                constructorConstructor, fieldNamingPolicy, excluder);
                        
                        // Use reflection to set boundFields since it's private
                        java.lang.reflect.Field boundFieldsField = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                            .getDeclaredField("boundFields");
                        boundFieldsField.setAccessible(true);
                        boundFieldsField.set(adapterFactory, mockBoundFields);
                        
                        // Execute test
                        java.lang.reflect.Method writeMethod = adapterFactory.getClass().getDeclaredMethod("write", 
                            com.google.gson.stream.JsonWriter.class, Object.class);
                        writeMethod.setAccessible(true);
                        writeMethod.invoke(adapterFactory, mockWriter, testObject);
                        
                        // Verify order
                        inOrder.verify(mockWriter).beginObject();
                        inOrder.verify(mockWriter).name("fieldA");
                        inOrder.verify(mockWriter).name("fieldB");
                        inOrder.verify(mockWriter).endObject();
                    }

    @Test
    public void testRead_WithNonDeserializedField() throws IOException, NoSuchMethodException, IllegalAccessException, NoSuchFieldException, InvocationTargetException {
        // Setup mocks
        com.google.gson.stream.JsonReader in = mock(com.google.gson.stream.JsonReader.class);
        com.google.gson.internal.ConstructorConstructor constructorConstructor = 
            mock(com.google.gson.internal.ConstructorConstructor.class);
        com.google.gson.internal.ObjectConstructor<Object> constructor = 
            mock(com.google.gson.internal.ObjectConstructor.class);
        Object mockInstance = new Object();
        
        // Create boundFields map using Object type since BoundField is not accessible
        
        // Create adapter factory
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
            new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                constructorConstructor,
                mock(com.google.gson.FieldNamingStrategy.class), 
                mock(com.google.gson.internal.Excluder.class)
            );
        
        // Create a real BoundField instance through reflection
        Method createBoundFieldMethod = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
            "createBoundField", 
            com.google.gson.Gson.class, 
            java.lang.reflect.Field.class, 
            String.class, 
            com.google.gson.reflect.TypeToken.class, 
            boolean.class, 
            boolean.class
        );
        createBoundFieldMethod.setAccessible(true);
        
        // Create a dummy field
        Field dummyField = Object.class.getDeclaredField("class");
        
        // Create a non-deserialized field
        Object nonDeserializedField = createBoundFieldMethod.invoke(
            adapterFactory,
            mock(com.google.gson.Gson.class),
            dummyField,
            "nonDeserializedField",
            com.google.gson.reflect.TypeToken.get(Object.class),
            true,  // serialize
            false  // deserialize
        );
        
        // Add our field to boundFields map
        
        // Inject boundFields into adapter factory
        Field boundFieldsField = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
            .getDeclaredField("boundFields");
        boundFieldsField.setAccessible(true);
        
        // Setup reader behavior
        when(in.peek()).thenReturn(com.google.gson.stream.JsonToken.BEGIN_OBJECT);
        when(constructor.construct()).thenReturn(mockInstance);
        when(in.hasNext()).thenReturn(true).thenReturn(false);
        when(in.nextName()).thenReturn("nonDeserializedField");
        
        // Create type adapter
        com.google.gson.TypeAdapter<Object> adapter = adapterFactory.create(mock(com.google.gson.Gson.class), 
            com.google.gson.reflect.TypeToken.get(Object.class));
        
        // Test
        Object result = adapter.read(in);
        
        // Verify
        verify(in).skipValue();
        verify(in, never()).nextString();
        verify(in).beginObject();
        verify(in).endObject();
        assertEquals(mockInstance, result);
    }

    @Test
    public void testWrite_WithBoundFields() throws Exception {
        // Define test class as local class (non-static)
        class TestClass {
            String testField;
        }
        
        // Create mocks
        com.google.gson.internal.ConstructorConstructor constructor = 
            mock(com.google.gson.internal.ConstructorConstructor.class);
        com.google.gson.FieldNamingStrategy namingStrategy = 
            mock(com.google.gson.FieldNamingStrategy.class);
        com.google.gson.internal.Excluder excluder = 
            mock(com.google.gson.internal.Excluder.class);
        com.google.gson.Gson gson = 
            mock(com.google.gson.Gson.class);
        
        // Mock behavior
        when(namingStrategy.translateName(any(java.lang.reflect.Field.class))).thenReturn("testField");
        when(excluder.excludeField(any(java.lang.reflect.Field.class), anyBoolean())).thenReturn(false);
        
        // Create factory
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory factory = 
            new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                constructor, namingStrategy, excluder
            );
        
        // Get createBoundField method via reflection
        java.lang.reflect.Method createBoundFieldMethod = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
            .getDeclaredMethod("createBoundField", com.google.gson.Gson.class, java.lang.reflect.Field.class, String.class, 
                com.google.gson.reflect.TypeToken.class, boolean.class, boolean.class);
        createBoundFieldMethod.setAccessible(true);
        
        // Create bound field
        java.lang.reflect.Field field = TestClass.class.getDeclaredField("testField");
        com.google.gson.reflect.TypeToken<?> fieldType = com.google.gson.reflect.TypeToken.get(String.class);
        Object boundField = createBoundFieldMethod.invoke(factory, 
            gson, field, "testField", fieldType, true, false);
        
        // Create test object
        TestClass testObject = new TestClass();
        testObject.testField = "testValue";
        
        // Mock JsonWriter and setup inOrder verification
        com.google.gson.stream.JsonWriter writer = mock(com.google.gson.stream.JsonWriter.class);
        
        // Create adapter and write
        com.google.gson.TypeAdapter<TestClass> adapter = new com.google.gson.TypeAdapter<TestClass>() {
            @Override
            public void write(com.google.gson.stream.JsonWriter out, TestClass value) throws IOException {
                out.beginObject();
                try {
                    // Get the BoundField.WriteMethod via reflection
                    java.lang.reflect.Method writeMethod = boundField.getClass().getDeclaredMethod("write", 
                        com.google.gson.stream.JsonWriter.class, Object.class);
                    writeMethod.setAccessible(true);
                    writeMethod.invoke(boundField, out, value);
                } catch (Exception e) {
                    throw new IOException(e);
                }
                out.endObject();
            }
            
            @Override
            public TestClass read(com.google.gson.stream.JsonReader in) throws IOException {
                return null;
            }
        };
        
        adapter.write(writer, testObject);
        
        // Verify
    }


}
