package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
 
public class $Gson$TypesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                   public void testSubtypeOf_WithClassType() {
                                                       // Setup
                                                       Class<?> stringClass = String.class;
                                                       
                                                       // Execute
                                                       WildcardType result = $Gson$Types.subtypeOf(stringClass);
                                                       
                                                       // Verify
                                                       Type[] upperBounds = result.getUpperBounds();
                                                       Type[] lowerBounds = result.getLowerBounds();
                                                       
                                                       assertEquals(1, upperBounds.length);
                                                       assertEquals(stringClass, upperBounds[0]);
                                                       assertEquals(0, lowerBounds.length);
                                                   }

 @Test
                                                   public void testSubtypeOf_WithWildcardType() {
                                                       // Setup
                                                       WildcardType mockWildcard = mock(WildcardType.class);
                                                       Type[] mockUpperBounds = new Type[]{Number.class};
                                                       when(mockWildcard.getUpperBounds()).thenReturn(mockUpperBounds);
                                                       
                                                       // Execute
                                                       WildcardType result = $Gson$Types.subtypeOf(mockWildcard);
                                                       
                                                       // Verify
                                                       Type[] upperBounds = result.getUpperBounds();
                                                       Type[] lowerBounds = result.getLowerBounds();
                                                       
                                                       assertEquals(1, upperBounds.length);
                                                       assertEquals(Number.class, upperBounds[0]);
                                                       assertEquals(0, lowerBounds.length);
                                                       verify(mockWildcard).getUpperBounds();
                                                   }

 @Test
                                                   public void testSubtypeOf_WithParameterizedType() {
                                                       // Setup
                                                       ParameterizedType mockParamType = mock(ParameterizedType.class);
                                                       
                                                       // Execute
                                                       WildcardType result = $Gson$Types.subtypeOf(mockParamType);
                                                       
                                                       // Verify
                                                       Type[] upperBounds = result.getUpperBounds();
                                                       Type[] lowerBounds = result.getLowerBounds();
                                                       
                                                       assertEquals(1, upperBounds.length);
                                                       assertEquals(mockParamType, upperBounds[0]);
                                                       assertEquals(0, lowerBounds.length);
                                                   }

 @Test
                                                   public void testSubtypeOf_WithGenericArrayType() {
                                                       // Setup
                                                       GenericArrayType mockArrayType = mock(GenericArrayType.class);
                                                       
                                                       // Execute
                                                       WildcardType result = $Gson$Types.subtypeOf(mockArrayType);
                                                       
                                                       // Verify
                                                       Type[] upperBounds = result.getUpperBounds();
                                                       Type[] lowerBounds = result.getLowerBounds();
                                                       
                                                       assertEquals(1, upperBounds.length);
                                                       assertEquals(mockArrayType, upperBounds[0]);
                                                       assertEquals(0, lowerBounds.length);
                                                   }

 @Test
                                                   public void testSubtypeOf_WithNullBound() {
                                                       // Expect exception
                                                       thrown.expect(NullPointerException.class);
                                                       thrown.expectMessage("bound == null");
                                                       
                                                       // Execute
                                                       $Gson$Types.subtypeOf(null);
                                                   }

 @Test
                                                   public void testSubtypeOf_WithWildcardHavingMultipleUpperBounds() {
                                                       // Setup
                                                       WildcardType mockWildcard = mock(WildcardType.class);
                                                       Type[] mockUpperBounds = new Type[]{Number.class, Comparable.class};
                                                       when(mockWildcard.getUpperBounds()).thenReturn(mockUpperBounds);
                                                       
                                                       // Execute
                                                       WildcardType result = $Gson$Types.subtypeOf(mockWildcard);
                                                       
                                                       // Verify
                                                       Type[] upperBounds = result.getUpperBounds();
                                                       Type[] lowerBounds = result.getLowerBounds();
                                                       
                                                       assertEquals(2, upperBounds.length);
                                                       assertEquals(Number.class, upperBounds[0]);
                                                       assertEquals(Comparable.class, upperBounds[1]);
                                                       assertEquals(0, lowerBounds.length);
                                                   }

 @Test
                                                   public void testSubtypeOf_VerifyWildcardTypeImplProperties() {
                                                       // Setup
                                                       Class<?> boundType = Integer.class;
                                                       
                                                       // Execute
                                                       WildcardType result = $Gson$Types.subtypeOf(boundType);
                                                       
                                                       // Verify toString() behavior
                                                       assertEquals("? extends java.lang.Integer", result.toString());
                                                       
                                                       // Verify equals() behavior
                                                       WildcardType sameResult = $Gson$Types.subtypeOf(boundType);
                                                       assertTrue(result.equals(sameResult));
                                                       
                                                       // Verify hashCode() consistency
                                                       assertEquals(result.hashCode(), sameResult.hashCode());
                                                   }

 @Test
                                                   public void testSupertypeOf_WithRegularType() {
                                                       // Arrange
                                                       Type regularType = String.class;
                                                       
                                                       // Act
                                                       WildcardType result = $Gson$Types.supertypeOf(regularType);
                                                       
                                                       // Assert
                                                       assertNotNull(result);
                                                       assertEquals(1, result.getUpperBounds().length);
                                                       assertEquals(Object.class, result.getUpperBounds()[0]);
                                                       
                                                       assertEquals(1, result.getLowerBounds().length);
                                                       assertEquals(regularType, result.getLowerBounds()[0]);
                                                   }

 @Test
                                                   public void testSupertypeOf_WithWildcardType() {
                                                       // Arrange
                                                       WildcardType wildcardType = mock(WildcardType.class);
                                                       Type[] lowerBounds = {Number.class};
                                                       when(wildcardType.getLowerBounds()).thenReturn(lowerBounds);
                                                       
                                                       // Act
                                                       WildcardType result = $Gson$Types.supertypeOf(wildcardType);
                                                       
                                                       // Assert
                                                       assertNotNull(result);
                                                       assertEquals(1, result.getUpperBounds().length);
                                                       assertEquals(Object.class, result.getUpperBounds()[0]);
                                                       
                                                       assertEquals(lowerBounds, result.getLowerBounds());
                                                       verify(wildcardType).getLowerBounds();
                                                   }

 @Test
                                                   public void testSupertypeOf_WithNullType() {
                                                       // Arrange
                                                       thrown.expect(NullPointerException.class);
                                                       
                                                       // Act & Assert
                                                       $Gson$Types.supertypeOf(null);
                                                   }

 @Test
                                                   public void testSupertypeOf_WithPrimitiveType() {
                                                       // Arrange
                                                       Type primitiveType = int.class;
                                                       
                                                       // Act
                                                       WildcardType result = $Gson$Types.supertypeOf(primitiveType);
                                                       
                                                       // Assert
                                                       assertNotNull(result);
                                                       assertEquals(1, result.getUpperBounds().length);
                                                       assertEquals(Object.class, result.getUpperBounds()[0]);
                                                       
                                                       assertEquals(1, result.getLowerBounds().length);
                                                       assertEquals(primitiveType, result.getLowerBounds()[0]);
                                                   }

 @Test
                                                   public void testSupertypeOf_WithArrayType() {
                                                       // Arrange
                                                       Type arrayType = String[].class;
                                                       
                                                       // Act
                                                       WildcardType result = $Gson$Types.supertypeOf(arrayType);
                                                       
                                                       // Assert
                                                       assertNotNull(result);
                                                       assertEquals(1, result.getUpperBounds().length);
                                                       assertEquals(Object.class, result.getUpperBounds()[0]);
                                                       
                                                       assertEquals(1, result.getLowerBounds().length);
                                                       assertEquals(arrayType, result.getLowerBounds()[0]);
                                                   }

 @Test
                                                   public void testSupertypeOf_WithParameterizedType() {
                                                       // Arrange
                                                       ParameterizedType parameterizedType = mock(ParameterizedType.class);
                                                       
                                                       // Act
                                                       WildcardType result = $Gson$Types.supertypeOf(parameterizedType);
                                                       
                                                       // Assert
                                                       assertNotNull(result);
                                                       assertEquals(1, result.getUpperBounds().length);
                                                       assertEquals(Object.class, result.getUpperBounds()[0]);
                                                       
                                                       assertEquals(1, result.getLowerBounds().length);
                                                       assertEquals(parameterizedType, result.getLowerBounds()[0]);
                                                   }

 @Test
                                           public void testSupertypeOf_WithWildcardTypeHavingEmptyLowerBounds() {
                                               // Arrange
                                               WildcardType wildcardType = mock(WildcardType.class);
                                               Type[] emptyTypeArray = new Type[0];
                                               when(wildcardType.getLowerBounds()).thenReturn(emptyTypeArray);
                                               
                                               // Act
                                               WildcardType result = $Gson$Types.supertypeOf(wildcardType);
                                               
                                               // Assert
                                               assertNotNull(result);
                                               assertEquals(1, result.getUpperBounds().length);
                                               assertEquals(Object.class, result.getUpperBounds()[0]);
                                               
                                               assertEquals(0, result.getLowerBounds().length);
                                               verify(wildcardType).getLowerBounds();
                                           }

 @Test
       public void testSupertypeOfWithNonWildcardType() {
           // Arrange
           Type bound = String.class; // Non-WildcardType
           
           // Act
           WildcardType result = $Gson$Types.supertypeOf(bound);
           
           // Assert
           assertNotNull(result);
           assertEquals(1, result.getLowerBounds().length);
           assertEquals(String.class, result.getLowerBounds()[0]);
           assertEquals(1, result.getUpperBounds().length);
           assertEquals(Object.class, result.getUpperBounds()[0]);
       }

 @Test
       public void testSupertypeOfWithWildcardType() {
           // Arrange
           WildcardType wildcardBound = mock(WildcardType.class);
           Type[] lowerBounds = {Number.class};
           when(wildcardBound.getLowerBounds()).thenReturn(lowerBounds);
           
           // Act
           WildcardType result = $Gson$Types.supertypeOf(wildcardBound);
           
           // Assert
           assertNotNull(result);
           assertSame(lowerBounds, result.getLowerBounds());
           assertEquals(1, result.getUpperBounds().length);
           assertEquals(Object.class, result.getUpperBounds()[0]);
       }

 @Test
  public void testSupertypeOfWithNonWildcardTypeBound() {
      // Arrange
      Type bound = String.class; // Non-WildcardType
      
      // Act
      WildcardType result = $Gson$Types.supertypeOf(bound);
      
      // Assert
      // Verify lower bounds contain the original bound
      Type[] lowerBounds = result.getLowerBounds();
      assertEquals(1, lowerBounds.length);
      assertEquals(bound, lowerBounds[0]);
      
      // Verify upper bounds is Object.class
      Type[] upperBounds = result.getUpperBounds();
      assertEquals(1, upperBounds.length);
      assertEquals(Object.class, upperBounds[0]);
  }

 @Test
 public void testSupertypeOfWithWildcardType1() {
     // Create a mock WildcardType with lower bounds
     WildcardType wildcardBound = mock(WildcardType.class);
     Type[] expectedLowerBounds = new Type[]{String.class};
     when(wildcardBound.getLowerBounds()).thenReturn(expectedLowerBounds);
     
     // Call the method under test
     WildcardType result = $Gson$Types.supertypeOf(wildcardBound);
     
     // Verify the lower bounds are correctly set
     assertArrayEquals(expectedLowerBounds, result.getLowerBounds());
     
     // Also verify upper bounds are correctly set to Object.class
     assertArrayEquals(new Type[]{Object.class}, result.getUpperBounds());
 }

}
