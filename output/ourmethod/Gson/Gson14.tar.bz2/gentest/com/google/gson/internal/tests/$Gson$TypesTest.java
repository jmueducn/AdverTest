package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
 
public class $Gson$TypesTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                     public void testSubtypeOf_WithRegularType() {
                                                         // Setup
                                                         Type mockType = mock(Type.class);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.subtypeOf(mockType);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(mockType, result.getUpperBounds()[0]);
                                                         assertEquals(0, result.getLowerBounds().length);
                                                     }

 @Test
                                                     public void testSubtypeOf_WithWildcardType() {
                                                         // Setup
                                                         WildcardType mockWildcard = mock(WildcardType.class);
                                                         Type[] upperBounds = new Type[] { mock(Type.class), mock(Type.class) };
                                                         when(mockWildcard.getUpperBounds()).thenReturn(upperBounds);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.subtypeOf(mockWildcard);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertSame(upperBounds, result.getUpperBounds());
                                                         assertEquals(0, result.getLowerBounds().length);
                                                     }

 @Test
                                                     public void testSubtypeOf_WithNullBound() {
                                                         // Setup
                                                         thrown.expect(NullPointerException.class);
                                                         
                                                         // Execute
                                                         $Gson$Types.subtypeOf(null);
                                                     }

 @Test
                                                     public void testSubtypeOf_WithEmptyUpperBounds() {
                                                         // Setup
                                                         WildcardType mockWildcard = mock(WildcardType.class);
                                                         when(mockWildcard.getUpperBounds()).thenReturn(new Type[0]);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.subtypeOf(mockWildcard);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(0, result.getUpperBounds().length);
                                                         assertEquals(0, result.getLowerBounds().length);
                                                     }

 @Test
                                                     public void testSubtypeOf_WithMultipleUpperBounds() {
                                                         // Setup
                                                         WildcardType mockWildcard = mock(WildcardType.class);
                                                         Type bound1 = mock(Type.class);
                                                         Type bound2 = mock(Type.class);
                                                         when(mockWildcard.getUpperBounds()).thenReturn(new Type[] { bound1, bound2 });
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.subtypeOf(mockWildcard);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(2, result.getUpperBounds().length);
                                                         assertSame(bound1, result.getUpperBounds()[0]);
                                                         assertSame(bound2, result.getUpperBounds()[1]);
                                                         assertEquals(0, result.getLowerBounds().length);
                                                     }

 @Test
                                                     public void testSubtypeOf_VerifyWildcardTypeImplCreation() {
                                                         // Setup
                                                         Type mockType = mock(Type.class);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.subtypeOf(mockType);
                                                         
                                                         // Verify the created WildcardTypeImpl has correct bounds
                                                         Type[] upperBounds = result.getUpperBounds();
                                                         Type[] lowerBounds = result.getLowerBounds();
                                                         
                                                         assertEquals(1, upperBounds.length);
                                                         assertSame(mockType, upperBounds[0]);
                                                         assertEquals(0, lowerBounds.length);
                                                     }

 @Test
                                                     public void testSupertypeOf_WithConcreteType() {
                                                         // Setup
                                                         Type concreteType = String.class;
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.supertypeOf(concreteType);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(Object.class, result.getUpperBounds()[0]);
                                                         
                                                         assertEquals(1, result.getLowerBounds().length);
                                                         assertEquals(concreteType, result.getLowerBounds()[0]);
                                                     }

 @Test
                                                     public void testSupertypeOf_WithWildcardType() {
                                                         // Setup
                                                         WildcardType mockWildcard = mock(WildcardType.class);
                                                         Type[] lowerBounds = {Number.class};
                                                         when(mockWildcard.getLowerBounds()).thenReturn(lowerBounds);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.supertypeOf(mockWildcard);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(Object.class, result.getUpperBounds()[0]);
                                                         
                                                         assertEquals(lowerBounds, result.getLowerBounds());
                                                         verify(mockWildcard).getLowerBounds();
                                                     }

 @Test
                                                     public void testSupertypeOf_WithNullType() {
                                                         // Setup
                                                         thrown.expect(NullPointerException.class);
                                                         
                                                         // Execute
                                                         $Gson$Types.supertypeOf(null);
                                                     }

 @Test
                                                     public void testSupertypeOf_WithMultipleLowerBoundsWildcard() {
                                                         // Setup
                                                         WildcardType mockWildcard = mock(WildcardType.class);
                                                         Type[] lowerBounds = {Number.class, Serializable.class};
                                                         when(mockWildcard.getLowerBounds()).thenReturn(lowerBounds);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.supertypeOf(mockWildcard);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(Object.class, result.getUpperBounds()[0]);
                                                         
                                                         assertEquals(lowerBounds, result.getLowerBounds());
                                                         verify(mockWildcard).getLowerBounds();
                                                     }

 @Test
                                                     public void testSupertypeOf_WithPrimitiveType() {
                                                         // Setup
                                                         Type primitiveType = int.class;
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.supertypeOf(primitiveType);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(Object.class, result.getUpperBounds()[0]);
                                                         
                                                         assertEquals(1, result.getLowerBounds().length);
                                                         assertEquals(primitiveType, result.getLowerBounds()[0]);
                                                     }

 @Test
                                                     public void testSupertypeOf_WithArrayType() {
                                                         // Setup
                                                         Type arrayType = String[].class;
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.supertypeOf(arrayType);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(Object.class, result.getUpperBounds()[0]);
                                                         
                                                         assertEquals(1, result.getLowerBounds().length);
                                                         assertEquals(arrayType, result.getLowerBounds()[0]);
                                                     }

 @Test
                                                     public void testSupertypeOf_WithParameterizedType() {
                                                         // Setup
                                                         ParameterizedType mockParameterizedType = mock(ParameterizedType.class);
                                                         
                                                         // Execute
                                                         WildcardType result = $Gson$Types.supertypeOf(mockParameterizedType);
                                                         
                                                         // Verify
                                                         assertNotNull(result);
                                                         assertEquals(1, result.getUpperBounds().length);
                                                         assertEquals(Object.class, result.getUpperBounds()[0]);
                                                         
                                                         assertEquals(1, result.getLowerBounds().length);
                                                         assertEquals(mockParameterizedType, result.getLowerBounds()[0]);
                                                     }

 @Test
                                             public void testSupertypeOf_WithEmptyLowerBoundsWildcard() {
                                                 // Setup
                                                 WildcardType mockWildcard = mock(WildcardType.class);
                                                 Type[] emptyTypeArray = new Type[0];
                                                 when(mockWildcard.getLowerBounds()).thenReturn(emptyTypeArray);
                                                 
                                                 // Execute
                                                 WildcardType result = $Gson$Types.supertypeOf(mockWildcard);
                                                 
                                                 // Verify
                                                 assertNotNull(result);
                                                 assertEquals(1, result.getUpperBounds().length);
                                                 assertEquals(Object.class, result.getUpperBounds()[0]);
                                                 
                                                 assertEquals(0, result.getLowerBounds().length);
                                                 verify(mockWildcard).getLowerBounds();
                                             }

 @Test
         public void testSupertypeOf_NonNullLowerBounds() {
             // Test with regular class type
             Type stringType = String.class;
             WildcardType wildcardType = $Gson$Types.supertypeOf(stringType);
             
             assertNotNull("WildcardType should not be null", wildcardType);
             Type[] lowerBounds = wildcardType.getLowerBounds();
             assertNotNull("Lower bounds should not be null", lowerBounds);
             assertEquals("Should have exactly one lower bound", 1, lowerBounds.length);
             assertEquals("Lower bound should be the input type", stringType, lowerBounds[0]);
             
             // Test with WildcardType input
             WildcardType inputWildcard = $Gson$Types.subtypeOf(Object.class);
             wildcardType = $Gson$Types.supertypeOf(inputWildcard);
             
             assertNotNull("WildcardType should not be null", wildcardType);
             lowerBounds = wildcardType.getLowerBounds();
             assertNotNull("Lower bounds should not be null", lowerBounds);
             assertArrayEquals("Lower bounds should match input wildcard's lower bounds", 
                              inputWildcard.getLowerBounds(), lowerBounds);
         }

 @Test
        public void testSupertypeOfWithNullBound() {
            // Test with null bound
            Type bound = null;
            WildcardType result = $Gson$Types.supertypeOf(bound);
            
            // Verify the lower bounds contain null (original behavior)
            assertNotNull(result.getLowerBounds());
            assertEquals(1, result.getLowerBounds().length);
            assertNull(result.getLowerBounds()[0]);
            
            // Verify upper bounds contain Object.class
            assertEquals(1, result.getUpperBounds().length);
            assertEquals(Object.class, result.getUpperBounds()[0]);
        }

 @Test
        public void testSupertypeOfWithRegularType() {
            // Test with regular Type (not WildcardType)
            Type bound = String.class;
            WildcardType result = $Gson$Types.supertypeOf(bound);
            
            // Verify lower bounds contain the original type
            assertEquals(1, result.getLowerBounds().length);
            assertEquals(bound, result.getLowerBounds()[0]);
        }

 @Test
        public void testSupertypeOfWithWildcardType() {
            // Create a mock WildcardType
            WildcardType wildcardBound = mock(WildcardType.class);
            Type[] lowerBounds = new Type[] {Number.class};
            when(wildcardBound.getLowerBounds()).thenReturn(lowerBounds);
            
            WildcardType result = $Gson$Types.supertypeOf(wildcardBound);
            
            // Verify it uses the wildcard's lower bounds directly
            assertSame(lowerBounds, result.getLowerBounds());
        }

 @Test
       public void testSupertypeOfWithNonWildcardType() {
           // Arrange
           Type bound = String.class;
           
           // Act
           WildcardType result = $Gson$Types.supertypeOf(bound);
           
           // Assert
           Type[] lowerBounds = result.getLowerBounds();
           assertEquals(1, lowerBounds.length);
           assertEquals(bound, lowerBounds[0]);
       }

 @Test
       public void testSupertypeOfWithWildcardType1() {
           // Arrange
           WildcardType wildcardBound = mock(WildcardType.class);
           Type[] expectedLowerBounds = new Type[]{Number.class};
           when(wildcardBound.getLowerBounds()).thenReturn(expectedLowerBounds);
           
           // Act
           WildcardType result = $Gson$Types.supertypeOf(wildcardBound);
           
           // Assert
           Type[] actualLowerBounds = result.getLowerBounds();
           assertArrayEquals(expectedLowerBounds, actualLowerBounds);
       }

 @Test
      public void testSupertypeOfWithNonWildcardType1() {
          // Arrange
          Type bound = String.class;
          
          // Act
          WildcardType result = $Gson$Types.supertypeOf(bound);
          
          // Assert
          Type[] lowerBounds = result.getLowerBounds();
          assertEquals(1, lowerBounds.length);
          assertEquals(bound, lowerBounds[0]);
          
          Type[] upperBounds = result.getUpperBounds();
          assertEquals(1, upperBounds.length);
          assertEquals(Object.class, upperBounds[0]);
      }

 @Test(expected = NullPointerException.class)
     public void testSupertypeOfWithNullBoundShouldThrowNPE() {
         // This test will pass with original code (throws NPE)
         // and fail with mutated code (returns WildcardType with null)
         $Gson$Types.supertypeOf(null);
     }

 @Test
     public void testSupertypeOfWithNullBoundMutantBehavior() {
         try {
             // Call with null to test mutant behavior
             WildcardType result = $Gson$Types.supertypeOf(null);
             
             // Verify mutant behavior - should have null in lower bounds
             Type[] lowerBounds = result.getLowerBounds();
             assertEquals(1, lowerBounds.length);
             assertNull(lowerBounds[0]);
             
             // Verify upper bounds
             Type[] upperBounds = result.getUpperBounds();
             assertEquals(1, upperBounds.length);
             assertEquals(Object.class, upperBounds[0]);
             
             fail("Expected NullPointerException but got WildcardType with null bound");
         } catch (NullPointerException e) {
             // This is expected for original code
         }
     }

}
