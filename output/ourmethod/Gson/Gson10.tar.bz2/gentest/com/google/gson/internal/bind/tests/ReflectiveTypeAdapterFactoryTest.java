package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Primitives;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
 
public class ReflectiveTypeAdapterFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                public void testCreate_WithValidType_ReturnsTypeAdapter() {
                                                                                    // Setup
                                                                                    Gson gson = mock(Gson.class);
                                                                                    TypeToken<String> type = TypeToken.get(String.class);
                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                    
                                                                                    // Create factory instance
                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(excluder.excludeClass(String.class, false)).thenReturn(false);
                                                                                    when(fieldNamingPolicy.translateName(any(Field.class))).thenReturn("fieldName");
                                                                                    
                                                                                    // Test
                                                                                    TypeAdapter<String> adapter = factory.create(gson, type);
                                                                                    
                                                                                    // Verify
                                                                                    assertNotNull(adapter);
                                                                                    // Additional assertions could verify the adapter's behavior
                                                                                }

    @Test
                                                                                public void testCreate_WithExcludedClass_ReturnsNull() {
                                                                                    // Setup
                                                                                    Gson gson = mock(Gson.class);
                                                                                    TypeToken<String> type = TypeToken.get(String.class);
                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                    
                                                                                    // Create factory instance with mocked dependencies
                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(excluder.excludeClass(String.class, false)).thenReturn(true);
                                                                                    
                                                                                    // Test
                                                                                    TypeAdapter<String> adapter = factory.create(gson, type);
                                                                                    
                                                                                    // Verify
                                                                                    assertNull(adapter);
                                                                                }

    @Test
                                                                                public void testExcludeField_WithSerialization_DelegatesToExcluder() {
                                                                                    // Setup
                                                                                    Field field = mock(Field.class);
                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                    
                                                                                    // Create factory instance with mocked dependencies
                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(excluder.excludeField(field, true)).thenReturn(true);
                                                                                    
                                                                                    // Test
                                                                                    boolean result = factory.excludeField(field, true);
                                                                                    
                                                                                    // Verify
                                                                                    assertTrue(result);
                                                                                    verify(excluder).excludeField(field, true);
                                                                                }

    @Test
                                                                                public void testCreateBoundField_WithSerializationOnly_CreatesCorrectBoundField() throws Exception {
                                                                                    // Setup
                                                                                    Gson context = mock(Gson.class);
                                                                                    Field field = String.class.getDeclaredField("value"); // Using reflection to get a real field
                                                                                    TypeToken<?> fieldType = TypeToken.get(String.class);
                                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                    Excluder excluder = mock(Excluder.class);
                                                                                    
                                                                                    // Create factory instance
                                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                                    
                                                                                    // Mock behavior
                                                                                    when(fieldNamingPolicy.translateName(field)).thenReturn("fieldName");
                                                                                    when(context.getAdapter(fieldType)).thenReturn(mock(TypeAdapter.class));
                                                                                    when(excluder.excludeField(field, true)).thenReturn(false);
                                                                                    
                                                                                    // Test
                                                                                    // Using reflection to access private createBoundField method
                                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                        "createBoundField", 
                                                                                        Gson.class, 
                                                                                        Field.class, 
                                                                                        String.class, 
                                                                                        TypeToken.class, 
                                                                                        boolean.class, 
                                                                                        boolean.class);
                                                                                    createBoundFieldMethod.setAccessible(true);
                                                                                    
                                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                                        factory, 
                                                                                        context, 
                                                                                        field, 
                                                                                        "name", 
                                                                                        fieldType, 
                                                                                        true, 
                                                                                        false);
                                                                                    
                                                                                    // Verify
                                                                                    assertNotNull(boundField);
                                                                                }

    @Test
                                                                            public void testRead_EmptyObject_ReturnsInstance() throws Exception {
                                                                                // Create mocks
                                                                                JsonReader in = mock(JsonReader.class);
                                                                                ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                ObjectConstructor<Object> constructor = mock(ObjectConstructor.class);
                                                                                FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                Excluder excluder = mock(Excluder.class);
                                                                                
                                                                                // Create test instance
                                                                                ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                    constructorConstructor, fieldNamingStrategy, excluder);
                                                                                
                                                                                // Setup test data
                                                                                Object instance = new Object();
                                                                                
                                                                                // Mock behaviors
                                                                                when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
                                                                                when(constructorConstructor.get(TypeToken.get(Object.class))).thenReturn(constructor);
                                                                                when(constructor.construct()).thenReturn(instance);
                                                                                when(in.hasNext()).thenReturn(false);
                                                                                
                                                                                // Execute test
                                                                                Object result = adapterFactory.create(null, TypeToken.get(Object.class)).read(in);
                                                                                
                                                                                // Verify results
                                                                                assertSame(instance, result);
                                                                                verify(in).beginObject();
                                                                                verify(in).endObject();
                                                                                verify(in, never()).nextName();
                                                                            }

    @Test
                                                                            public void testWrite_NullValue() {
                                                                                // Setup
                                                                                JsonWriter out = mock(JsonWriter.class);
                                                                                ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                Excluder excluder = mock(Excluder.class);
                                                                                ReflectiveTypeAdapterFactory adapter = new ReflectiveTypeAdapterFactory(
                                                                                    constructorConstructor, 
                                                                                    fieldNamingStrategy, 
                                                                                    excluder
                                                                                );
                                                                                
                                                                                // Create a TypeAdapter instance to test
                                                                                TypeAdapter<Object> typeAdapter = adapter.create(mock(Gson.class), TypeToken.get(Object.class));
                                                                                
                                                                                // Execute
                                                                                
                                                                                // Verify
                                                                            }

    @Test
                                                                            public void testGetFieldNames_ReturnsCorrectNames() throws Exception {
                                                                                // Setup
                                                                                class TestClass {
                                                                                    @SuppressWarnings("unused")
                                                                                    private String testField;
                                                                                }
                                                                                
                                                                                Field field = TestClass.class.getDeclaredField("testField");
                                                                                FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                Excluder excluder = mock(Excluder.class);
                                                                                
                                                                                // Create factory instance
                                                                                ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                    constructorConstructor, fieldNamingPolicy, excluder);
                                                                                
                                                                                // Mock behavior
                                                                                when(fieldNamingPolicy.translateName(field)).thenReturn("customName");
                                                                                
                                                                                // Use reflection to access private method
                                                                                Method getFieldNamesMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod("getFieldNames", Field.class);
                                                                                getFieldNamesMethod.setAccessible(true);
                                                                                
                                                                                // Test
                                                                                @SuppressWarnings("unchecked")
                                                                                List<String> names = (List<String>) getFieldNamesMethod.invoke(factory, field);
                                                                                
                                                                                // Verify
                                                                                assertEquals(1, names.size());
                                                                                assertEquals("customName", names.get(0));
                                                                            }

    @Test
                                                                            public void testRead_WhenJsonTokenIsNull_ReturnsNull() throws Exception {
                                                                                // Create mock objects
                                                                                JsonReader in = mock(JsonReader.class);
                                                                                ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                                FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                                Excluder excluder = mock(Excluder.class);
                                                                                
                                                                                // Create adapter factory
                                                                                ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                    constructorConstructor, fieldNamingPolicy, excluder);
                                                                                
                                                                                // Create a TypeAdapter for testing
                                                                                TypeToken<Object> typeToken = TypeToken.get(Object.class);
                                                                                Gson gson = new Gson();
                                                                                TypeAdapter<Object> adapter = adapterFactory.create(gson, typeToken);
                                                                                
                                                                                // Mock behavior
                                                                                when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                
                                                                                // Test
                                                                                Object result = adapter.read(in);
                                                                                
                                                                                // Verify
                                                                                assertNull(result);
                                                                                verify(in).nextNull();
                                                                                verify(in, never()).beginObject();
                                                                            }

    @Test
                                                                            public void testRead_WhenIllegalStateExceptionOccurs_ThrowsJsonSyntaxException() throws Exception {
                                                                                // Create mock objects
                                                                                JsonReader in = mock(JsonReader.class);
                                                                                ConstructorConstructor constructor = mock(ConstructorConstructor.class);
                                                                                FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                                Excluder excluder = mock(Excluder.class);
                                                                                Gson gson = mock(Gson.class);
                                                                                TypeToken<Object> typeToken = TypeToken.get(Object.class);
                                                                                
                                                                                // Create the adapter factory with mocked dependencies
                                                                                ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
                                                                                    constructor, fieldNamingStrategy, excluder);
                                                                                
                                                                                // Create a mock TypeAdapter
                                                                                TypeAdapter<Object> typeAdapter = mock(TypeAdapter.class);
                                                                                
                                                                                // Set up mock behavior
                                                                                when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
                                                                                when(constructor.get(typeToken)).thenReturn(new ObjectConstructor<Object>() {
                                                                                    @Override
                                                                                    public Object construct() {
                                                                                        return new Object();
                                                                                    }
                                                                                });
                                                                                when(in.hasNext()).thenReturn(true);
                                                                                when(in.nextName()).thenThrow(new IllegalStateException("Test exception"));
                                                                                
                                                                                // Set up exception expectations
                                                                                thrown.expect(JsonSyntaxException.class);
                                                                                thrown.expectMessage("Test exception");
                                                                                
                                                                                // Create adapter and execute test
                                                                                TypeAdapter<Object> adapter = adapterFactory.create(gson, typeToken);
                                                                                adapter.read(in);
                                                                            }

    @Test
                                                                        public void testCreateBoundField_WithoutJsonAnnotation() throws Exception {
                                                                            // Define a simple sample class for testing
                                                                            class SampleClass {
                                                                                @SuppressWarnings("unused")
                                                                                private String normalField;
                                                                            }
                                                                            
                                                                            // Setup
                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                constructorConstructor, fieldNamingPolicy, excluder);
                                                                            
                                                                            Gson gson = mock(Gson.class);
                                                                            Field field = SampleClass.class.getDeclaredField("normalField");
                                                                            TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                            @SuppressWarnings("rawtypes")
                                                                            TypeAdapter mockAdapter = mock(TypeAdapter.class);
                                                                            
                                                                            when(gson.getAdapter(any(TypeToken.class))).thenReturn(mockAdapter);
                                                                            
                                                                            // Test
                                                                            // Use reflection to access private createBoundField method
                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class
                                                                                .getDeclaredMethod("createBoundField", Gson.class, Field.class, String.class, 
                                                                                    TypeToken.class, boolean.class, boolean.class);
                                                                            createBoundFieldMethod.setAccessible(true);
                                                                            Object boundField = createBoundFieldMethod.invoke(factory, 
                                                                                gson, field, "normalField", fieldType, true, true);
                                                                            
                                                                            // Verify
                                                                            assertNotNull(boundField);
                                                                        }

    @Test
                                                                        public void testCreateBoundField_PrimitiveType() throws Exception {
                                                                            // Setup
                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                constructorConstructor, fieldNamingPolicy, excluder);
                                                                            
                                                                            Gson gson = mock(Gson.class);
                                                                            
                                                                            // Create a sample class with a primitive field for testing
                                                                            class SampleClass {
                                                                                public int primitiveField;
                                                                            }
                                                                            
                                                                            Field field = SampleClass.class.getField("primitiveField");
                                                                            TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                            @SuppressWarnings("rawtypes")
                                                                            TypeAdapter mockAdapter = mock(TypeAdapter.class);
                                                                            
                                                                            when(gson.getAdapter(any(TypeToken.class))).thenReturn(mockAdapter);
                                                                            
                                                                            // Test
                                                                            // Using reflection to access private createBoundField method
                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                "createBoundField", 
                                                                                Gson.class, Field.class, String.class, TypeToken.class, boolean.class, boolean.class);
                                                                            createBoundFieldMethod.setAccessible(true);
                                                                            Object boundField = createBoundFieldMethod.invoke(
                                                                                factory, gson, field, "primitiveField", fieldType, true, true);
                                                                            
                                                                            // Verify
                                                                            assertNotNull(boundField);
                                                                        }

    @Test
                                                                        public void testCreateBoundField_WriteField_ReturnsFalseWhenNotSerialized() throws Exception {
                                                                            // Setup
                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                constructorConstructor, fieldNamingPolicy, excluder);
                                                                            
                                                                            Gson gson = mock(Gson.class);
                                                                            // Define a sample class with a field for testing
                                                                            class SampleClass {
                                                                                public String normalField;
                                                                            }
                                                                            Field field = SampleClass.class.getField("normalField");
                                                                            TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                            @SuppressWarnings("unchecked")
                                                                            TypeAdapter<String> mockAdapter = mock(TypeAdapter.class);
                                                                            
                                                                            when(gson.getAdapter(any(TypeToken.class))).thenReturn(mockAdapter);
                                                                            
                                                                            // Test with serialize=false
                                                                            // Need to use reflection to access private method
                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                                "createBoundField", 
                                                                                Gson.class, Field.class, String.class, TypeToken.class, boolean.class, boolean.class);
                                                                            createBoundFieldMethod.setAccessible(true);
                                                                            Object boundField = createBoundFieldMethod.invoke(
                                                                                factory, gson, field, "normalField", fieldType, false, true);
                                                                            
                                                                            // Need to use reflection to access writeField method
                                                                            Method writeFieldMethod = boundField.getClass().getDeclaredMethod("writeField", Object.class);
                                                                            writeFieldMethod.setAccessible(true);
                                                                            boolean result = (boolean) writeFieldMethod.invoke(boundField, new SampleClass());
                                                                            
                                                                            // Verify
                                                                            assertFalse(result);
                                                                        }

    @Test
                                                                        public void testCreateBoundField_WriteField_ReturnsTrueWhenFieldValueDifferent() throws Exception {
                                                                            // Define a sample class for testing
                                                                            class SampleClass {
                                                                                public String normalField = "initialValue";
                                                                            }
                                                                        
                                                                            // Setup
                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                constructorConstructor, fieldNamingPolicy, excluder);
                                                                            
                                                                            Gson gson = mock(Gson.class);
                                                                            Field field = SampleClass.class.getDeclaredField("normalField");
                                                                            TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                            @SuppressWarnings("rawtypes")
                                                                            TypeAdapter mockAdapter = mock(TypeAdapter.class);
                                                                            SampleClass instance = new SampleClass();
                                                                            
                                                                            when(gson.getAdapter(fieldType)).thenReturn(mockAdapter);
                                                                            
                                                                            // Test with serialize=true
                                                                            // Using reflection to access createBoundField since it's private
                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class
                                                                                .getDeclaredMethod("createBoundField", Gson.class, Field.class, 
                                                                                    String.class, TypeToken.class, boolean.class, boolean.class);
                                                                            createBoundFieldMethod.setAccessible(true);
                                                                            Object boundField = createBoundFieldMethod.invoke(factory, 
                                                                                gson, field, "normalField", fieldType, true, true);
                                                                            
                                                                            // Using reflection to access writeField method
                                                                            Method writeFieldMethod = boundField.getClass()
                                                                                .getDeclaredMethod("writeField", Object.class);
                                                                            writeFieldMethod.setAccessible(true);
                                                                            boolean result = (boolean) writeFieldMethod.invoke(boundField, instance);
                                                                            
                                                                            // Verify
                                                                            assertTrue(result);
                                                                        }

    @Test
                                                                        public void testCreateBoundField_Read_NonNullValueForObject() throws Exception {
                                                                            // Define sample class for testing
                                                                            class SampleClass {
                                                                                public String normalField;
                                                                            }
                                                                            
                                                                            // Setup
                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                constructorConstructor, fieldNamingPolicy, excluder);
                                                                            
                                                                            Gson gson = mock(Gson.class);
                                                                            Field field = SampleClass.class.getField("normalField");
                                                                            TypeToken<String> fieldType = TypeToken.get(String.class);
                                                                            TypeAdapter<String> mockAdapter = mock(TypeAdapter.class);
                                                                            SampleClass instance = new SampleClass();
                                                                            String expectedValue = "testValue";
                                                                            
                                                                            when(gson.getAdapter(fieldType)).thenReturn(mockAdapter);
                                                                            when(mockAdapter.read(any(JsonReader.class))).thenReturn(expectedValue);
                                                                            
                                                                            // Use reflection to access private createBoundField method
                                                                            Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class
                                                                                .getDeclaredMethod("createBoundField", Gson.class, Field.class, 
                                                                                    String.class, TypeToken.class, boolean.class, boolean.class);
                                                                            createBoundFieldMethod.setAccessible(true);
                                                                            
                                                                            Object boundField = createBoundFieldMethod.invoke(factory, gson, field, 
                                                                                "normalField", fieldType, true, true);
                                                                            
                                                                            JsonReader reader = mock(JsonReader.class);
                                                                            
                                                                            // Use reflection to call read method on the boundField
                                                                            Method readMethod = boundField.getClass().getDeclaredMethod("read", 
                                                                                JsonReader.class, Object.class);
                                                                            readMethod.setAccessible(true);
                                                                            readMethod.invoke(boundField, reader, instance);
                                                                            
                                                                            // Verify that field was set
                                                                            assertEquals(expectedValue, instance.normalField);
                                                                        }

    @Test
                                                                        public void testWrite_WithIOException_ShouldPropagateException() throws IOException {
                                                                            ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                            FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                            Excluder excluder = mock(Excluder.class);
                                                                            
                                                                            // Create a mock TypeAdapter that throws IOException
                                                                            TypeAdapter<String> mockAdapter = new TypeAdapter<String>() {
                                                                                @Override
                                                                                public void write(JsonWriter out, String value) throws IOException {
                                                                                    throw new IOException("Test exception");
                                                                                }
                                                                                
                                                                                @Override
                                                                                public String read(JsonReader in) throws IOException {
                                                                                    return null; // Not needed for this test
                                                                                }
                                                                            };
                                                                            
                                                                            // Mock the factory to return our mock adapter
                                                                            ReflectiveTypeAdapterFactory factory = spy(new ReflectiveTypeAdapterFactory(
                                                                                    constructorConstructor, 
                                                                                    fieldNamingStrategy, 
                                                                                    excluder));
                                                                            
                                                                            when(factory.create(any(Gson.class), any(TypeToken.class))).thenReturn(mockAdapter);
                                                                            
                                                                            JsonWriter jsonWriter = mock(JsonWriter.class);
                                                                            try {
                                                                                // Need to create a proper TypeAdapter through the factory
                                                                                TypeAdapter<String> adapter = factory.create(mock(Gson.class), TypeToken.get(String.class));
                                                                                adapter.write(jsonWriter, "testValue");
                                                                                fail("Expected IOException to be thrown");
                                                                            } catch (IOException e) {
                                                                                assertEquals("Test exception", e.getMessage());
                                                                            }
                                                                        }

    @Test(expected = NullPointerException.class)
                                                                    public void testWrite_WithNullWriter_ShouldThrowException() {
                                                                        ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                        FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                                        Excluder excluder = mock(Excluder.class);
                                                                        
                                                                        ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                                constructorConstructor, 
                                                                                fieldNamingStrategy, 
                                                                                excluder);
                                                                        
                                                                        // Create a TypeAdapter for String type
                                                                        TypeAdapter<String> adapter = factory.create(mock(Gson.class), TypeToken.get(String.class));
                                                                        
                                                                        // This should throw NullPointerException
                                                                    }

    @Test
                                                                public void testCreateBoundField_WithJsonAnnotation() throws Exception {
                                                                    // Setup
                                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                                    FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
                                                                    Excluder excluder = mock(Excluder.class);
                                                                    
                                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                                        constructorConstructor, fieldNamingPolicy, excluder);
                                                                    
                                                                    Gson gson = mock(Gson.class);
                                                                    
                                                                    // Sample class with annotated field for testing
                                                                    class SampleClass {
                                                                        @com.google.gson.annotations.SerializedName("annotatedField")
                                                                        private String annotatedField;
                                                                    }
                                                                    
                                                                    Field field = SampleClass.class.getDeclaredField("annotatedField");
                                                                    TypeToken<?> fieldType = TypeToken.get(field.getGenericType());
                                                                    @SuppressWarnings("rawtypes")
                                                                    TypeAdapter mockAdapter = mock(TypeAdapter.class);
                                                                    
                                                                    when(gson.getAdapter(any(TypeToken.class))).thenReturn(mockAdapter);
                                                                    
                                                                    // Test - Need to use reflection to access private createBoundField method
                                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                        "createBoundField", 
                                                                        Gson.class, 
                                                                        Field.class, 
                                                                        String.class, 
                                                                        TypeToken.class, 
                                                                        boolean.class, 
                                                                        boolean.class);
                                                                    createBoundFieldMethod.setAccessible(true);
                                                                    
                                                                    Object boundField = createBoundFieldMethod.invoke(
                                                                        factory, 
                                                                        gson, 
                                                                        field, 
                                                                        "annotatedField", 
                                                                        fieldType, 
                                                                        true, 
                                                                        true);
                                                                    
                                                                    // Verify
                                                                    assertNotNull(boundField);
                                                                    // Additional verification would require reflection to check internal state
                                                                }

    @Test
                                                                public void testCreateBoundField_Read_NullValueForPrimitive() throws Exception {
                                                                    // Setup
                                                                    com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                                        mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                    com.google.gson.FieldNamingStrategy fieldNamingPolicy = 
                                                                        mock(com.google.gson.FieldNamingStrategy.class);
                                                                    com.google.gson.internal.Excluder excluder = 
                                                                        mock(com.google.gson.internal.Excluder.class);
                                                                    com.google.gson.internal.bind.ReflectiveTypeAdapterFactory factory = 
                                                                        new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                            constructorConstructor, fieldNamingPolicy, excluder);
                                                                    
                                                                    com.google.gson.Gson gson = mock(com.google.gson.Gson.class);
                                                                    
                                                                    // Define a sample class with primitive field for testing
                                                                    class SampleClass {
                                                                        public int primitiveField;
                                                                    }
                                                                    
                                                                    Field field = SampleClass.class.getField("primitiveField");
                                                                    @SuppressWarnings("unchecked")
                                                                    com.google.gson.reflect.TypeToken<Integer> fieldType = 
                                                                        (com.google.gson.reflect.TypeToken<Integer>) com.google.gson.reflect.TypeToken.get(field.getGenericType());
                                                                    @SuppressWarnings("unchecked")
                                                                    com.google.gson.TypeAdapter<Integer> mockAdapter = 
                                                                        (com.google.gson.TypeAdapter<Integer>) mock(com.google.gson.TypeAdapter.class);
                                                                    SampleClass instance = new SampleClass();
                                                                    
                                                                    when(gson.getAdapter(fieldType)).thenReturn(mockAdapter);
                                                                    when(mockAdapter.read(any(com.google.gson.stream.JsonReader.class))).thenReturn(null);
                                                                    
                                                                    // Use reflection to access createBoundField since it's private
                                                                    Method createBoundFieldMethod = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                                                                        .getDeclaredMethod("createBoundField", com.google.gson.Gson.class, Field.class, 
                                                                            String.class, com.google.gson.reflect.TypeToken.class, boolean.class, boolean.class);
                                                                    createBoundFieldMethod.setAccessible(true);
                                                                    Object boundField = createBoundFieldMethod.invoke(factory, 
                                                                        gson, field, "primitiveField", fieldType, true, true);
                                                                    
                                                                    com.google.gson.stream.JsonReader reader = 
                                                                        mock(com.google.gson.stream.JsonReader.class);
                                                                    
                                                                    // Use reflection to invoke read method on BoundField
                                                                    Method readMethod = boundField.getClass().getDeclaredMethod("read", 
                                                                        com.google.gson.stream.JsonReader.class, Object.class);
                                                                    readMethod.setAccessible(true);
                                                                    readMethod.invoke(boundField, reader, instance);
                                                                    
                                                                    // Verify that field wasn't set (primitive can't be null)
                                                                    assertEquals(0, instance.primitiveField);
                                                                }

    @Test
                                                            public void testRead_WithBoundFields_ReadsValues() throws Exception {
                                                                // Create mocks
                                                                com.google.gson.internal.ConstructorConstructor constructor = mock(com.google.gson.internal.ConstructorConstructor.class);
                                                                com.google.gson.FieldNamingStrategy fieldNamingPolicy = mock(com.google.gson.FieldNamingStrategy.class);
                                                                com.google.gson.internal.Excluder excluder = mock(com.google.gson.internal.Excluder.class);
                                                                com.google.gson.stream.JsonReader in = mock(com.google.gson.stream.JsonReader.class);
                                                                
                                                                // Create instance and setup mocks
                                                                Object instance = new Object();
                                                                
                                                                // Get BoundField class via reflection
                                                                Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                                                                Object field1 = mock(boundFieldClass);
                                                                
                                                                // Set deserialized field via reflection
                                                                Field deserializedField = boundFieldClass.getDeclaredField("deserialized");
                                                                deserializedField.setAccessible(true);
                                                                deserializedField.setBoolean(field1, true);
                                                                
                                                                // Create adapter factory
                                                                com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                                                                    new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                        constructor, fieldNamingPolicy, excluder);
                                                                
                                                                // Use reflection to set boundFields since it's private
                                                                Field boundFieldsField = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                                boundFieldsField.setAccessible(true);
                                                                @SuppressWarnings("unchecked")
                                                                java.util.Map<String, Object> boundFields = new java.util.HashMap<String, Object>();
                                                                boundFields.put("validField", field1);
                                                                boundFieldsField.set(adapterFactory, boundFields);
                                                                
                                                                // Setup reader behavior
                                                                when(in.peek()).thenReturn(com.google.gson.stream.JsonToken.BEGIN_OBJECT);
                                                                when(constructor.get(com.google.gson.reflect.TypeToken.get(Object.class))).thenReturn(
                                                                    new com.google.gson.internal.ObjectConstructor<Object>() {
                                                                        @Override
                                                                        public Object construct() {
                                                                            return instance;
                                                                        }
                                                                    });
                                                                when(in.hasNext()).thenReturn(true, true, false);
                                                                when(in.nextName()).thenReturn("validField", "invalidField");
                                                                
                                                                // Create type adapter
                                                                com.google.gson.TypeAdapter<Object> adapter = adapterFactory.create(null, com.google.gson.reflect.TypeToken.get(Object.class));
                                                                
                                                                // Execute test
                                                                Object result = adapter.read(in);
                                                                
                                                                // Verify
                                                                assertSame(instance, result);
                                                                
                                                                // Verify field1.read() was called using reflection
                                                                Method readMethod = boundFieldClass.getDeclaredMethod("read", com.google.gson.stream.JsonReader.class, Object.class);
                                                                readMethod.setAccessible(true);
                                                                readMethod.invoke(field1, in, instance);  // This will throw if the method wasn't called
                                                                
                                                                verify(in).skipValue(); // for invalidField
                                                                verify(in).endObject();
                                                            }

    @Test
                                                        public void testRead_WhenNoBoundFields_SkipsAllValues() throws Exception {
                                                            // Create mocks
                                                            com.google.gson.stream.JsonReader in = mock(com.google.gson.stream.JsonReader.class);
                                                            com.google.gson.internal.ConstructorConstructor constructor = mock(com.google.gson.internal.ConstructorConstructor.class);
                                                            com.google.gson.FieldNamingStrategy fieldNamingStrategy = mock(com.google.gson.FieldNamingStrategy.class);
                                                            com.google.gson.internal.Excluder excluder = com.google.gson.internal.Excluder.DEFAULT;
                                                            
                                                            // Create test objects
                                                            Object instance = new Object();
                                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                                constructor, fieldNamingStrategy, excluder);
                                                            
                                                            // Setup mock behavior
                                                            when(in.peek()).thenReturn(com.google.gson.stream.JsonToken.BEGIN_OBJECT);
                                                            when(constructor.get(com.google.gson.reflect.TypeToken.get(Object.class))).thenReturn(new com.google.gson.internal.ObjectConstructor<Object>() {
                                                                @Override
                                                                public Object construct() {
                                                                    return instance;
                                                                }
                                                            });
                                                            when(in.hasNext()).thenReturn(true, true, false);
                                                            when(in.nextName()).thenReturn("field1", "field2");
                                                            when(in.peek()).thenReturn(com.google.gson.stream.JsonToken.STRING, com.google.gson.stream.JsonToken.STRING);
                                                            
                                                            // Create a mock Gson instance
                                                            com.google.gson.Gson gson = mock(com.google.gson.Gson.class);
                                                            
                                                            // Execute test
                                                            com.google.gson.TypeAdapter<Object> adapter = adapterFactory.create(gson, com.google.gson.reflect.TypeToken.get(Object.class));
                                                            Object result = adapter.read(in);
                                                            
                                                            // Verify results
                                                            assertSame(instance, result);
                                                            verify(in).beginObject();
                                                            verify(in, times(2)).skipValue();
                                                            verify(in).endObject();
                                                        }

    @Test
                                                    public void testGetBoundFields_WithNoFields_ReturnsEmptyMap() {
                                                        // Setup
                                                        com.google.gson.Gson context = mock(com.google.gson.Gson.class);
                                                        com.google.gson.reflect.TypeToken<Object> type = com.google.gson.reflect.TypeToken.get(Object.class);
                                                        com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                            mock(com.google.gson.internal.ConstructorConstructor.class);
                                                        com.google.gson.FieldNamingStrategy fieldNamingPolicy = 
                                                            mock(com.google.gson.FieldNamingStrategy.class);
                                                        com.google.gson.internal.Excluder excluder = mock(com.google.gson.internal.Excluder.class);
                                                        
                                                        // Mock the behavior of excluder to exclude all fields
                                                        when(excluder.excludeField(any(java.lang.reflect.Field.class), anyBoolean())).thenReturn(true);
                                                        
                                                        ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                            constructorConstructor, fieldNamingPolicy, excluder);
                                                        
                                                        // Test - need to use reflection to access private method
                                                        try {
                                                            Method getBoundFieldsMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                                "getBoundFields", com.google.gson.Gson.class, 
                                                                com.google.gson.reflect.TypeToken.class, Class.class);
                                                            getBoundFieldsMethod.setAccessible(true);
                                                            
                                                            @SuppressWarnings("unchecked")
                                                            Map<String, Object> fields = 
                                                                (Map<String, Object>) getBoundFieldsMethod.invoke(
                                                                    factory, context, type, Object.class);
                                                            
                                                            // Verify
                                                            assertNotNull(fields);
                                                            assertTrue(fields.isEmpty());
                                                        } catch (Exception e) {
                                                            fail("Reflection failed: " + e.getMessage());
                                                        }
                                                    }

    @Test
                                                public void testWrite_WhenWriteFieldReturnsFalse_ShouldNotWrite() throws Exception {
                                                    ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
                                                    FieldNamingStrategy fieldNamingStrategy = mock(FieldNamingStrategy.class);
                                                    Excluder excluder = mock(Excluder.class);
                                                    
                                                    // Create the factory
                                                    ReflectiveTypeAdapterFactory factory = new ReflectiveTypeAdapterFactory(
                                                            constructorConstructor, 
                                                            fieldNamingStrategy, 
                                                            excluder);
                                                    
                                                    // Create test parameters
                                                    Gson gson = new Gson();
                                                    Field[] fields = String.class.getDeclaredFields();
                                                    if (fields.length == 0) {
                                                        fail("No fields found in String class for testing");
                                                    }
                                                    Field field = fields[0]; // Just get any field for testing
                                                    String name = "testField";
                                                    TypeToken<?> fieldType = TypeToken.get(field.getType());
                                                    
                                                    // Create the bound field
                                                    Method createBoundFieldMethod = ReflectiveTypeAdapterFactory.class.getDeclaredMethod(
                                                            "createBoundField", 
                                                            Gson.class, Field.class, String.class, TypeToken.class, boolean.class, boolean.class);
                                                    createBoundFieldMethod.setAccessible(true);
                                                    Object boundField = createBoundFieldMethod.invoke(
                                                            factory, 
                                                            gson, field, name, fieldType, true, false);
                                                    
                                                    // Mock the writeField method to return false
                                                    Method writeFieldMethod = boundField.getClass().getDeclaredMethod("writeField", Object.class);
                                                    writeFieldMethod.setAccessible(true);
                                                    when(writeFieldMethod.invoke(boundField, any())).thenReturn(false);
                                                    
                                                    // Create a map to hold the bound fields
                                                    Map<String, Object> boundFields = new LinkedHashMap<>();
                                                    boundFields.put("fieldName", boundField);
                                                    
                                                    // Use reflection to set the boundFields since it's private
                                                    Field boundFieldsField = ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
                                                    boundFieldsField.setAccessible(true);
                                                    boundFieldsField.set(factory, boundFields);
                                                    
                                                    // Create the TypeAdapter and test its write method
                                                    TypeToken<String> typeToken = TypeToken.get(String.class);
                                                    TypeAdapter<String> adapter = factory.create(gson, typeToken);
                                                    
                                                    JsonWriter jsonWriter = mock(JsonWriter.class);
                                                    adapter.write(jsonWriter, "testValue");
                                                    
                                                    // Verify write method was never called on the bound field
                                                    Method writeMethod = boundField.getClass().getDeclaredMethod("write", JsonWriter.class, Object.class);
                                                    writeMethod.setAccessible(true);
                                                    verify(writeMethod, never()).invoke(boundField, any(JsonWriter.class), any());
                                                    verify(jsonWriter, never()).value(anyString());
                                                }

    @Test
                                        public void testWrite_WithValidValue_ShouldWriteToJsonWriter() throws IOException {
                                            // Create a mock TypeAdapter
                                            TypeAdapter<String> mockAdapter = new TypeAdapter<String>() {
                                                @Override
                                                public void write(JsonWriter out, String value) throws IOException {
                                                    out.value(value);
                                                }
                                                
                                                @Override
                                                public String read(JsonReader in) throws IOException {
                                                    return null; // Not needed for this test
                                                }
                                            };
                                            
                                            // Create required objects for ReflectiveTypeAdapterFactory
                                            java.util.Map<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>> emptyMap = 
                                                java.util.Collections.<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>>emptyMap();
                                            com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                                new com.google.gson.internal.ConstructorConstructor(emptyMap);
                                            com.google.gson.FieldNamingStrategy fieldNamingPolicy = com.google.gson.FieldNamingPolicy.IDENTITY;
                                            com.google.gson.internal.Excluder excluder = new com.google.gson.internal.Excluder();
                                            
                                            // Create the real factory
                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory realFactory = 
                                                new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                                    constructorConstructor, 
                                                    fieldNamingPolicy, 
                                                    excluder);
                                            
                                            // Create a spy of the factory using Mockito
                                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory factorySpy = 
                                                spy(realFactory);
                                            
                                            // Configure the spy to return our mock adapter for String.class
                                            doAnswer(invocation -> {
                                                com.google.gson.reflect.TypeToken<?> type = invocation.getArgument(1);
                                                if (type.getRawType() == String.class) {
                                                    @SuppressWarnings("unchecked")
                                                    TypeAdapter<String> adapter = mockAdapter;
                                                    return adapter;
                                                }
                                                return invocation.callRealMethod();
                                            }).when(factorySpy).create(any(com.google.gson.Gson.class), 
                                                any(com.google.gson.reflect.TypeToken.class));
                                         
                                            java.io.StringWriter stringWriter = new java.io.StringWriter();
                                            com.google.gson.stream.JsonWriter jsonWriter = new com.google.gson.stream.JsonWriter(stringWriter);
                                            String testValue = "testValue";
                                            
                                            // Get the TypeAdapter and execute write
                                            TypeAdapter<String> adapter = factorySpy.create(new com.google.gson.Gson(), 
                                                com.google.gson.reflect.TypeToken.get(String.class));
                                            adapter.write(jsonWriter, testValue);
                                            
                                            // Verify
                                            jsonWriter.flush();
                                            org.junit.Assert.assertEquals("\"" + testValue + "\"", stringWriter.toString());
                                        }

    @Test
                        public void testWrite_IllegalAccessException() throws Exception {
                            // Setup
                            com.google.gson.stream.JsonWriter out = mock(com.google.gson.stream.JsonWriter.class);
                            
                            // Create boundFields map using reflection since BoundField is private
                            Class<?> adapterFactoryClass = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class;
                            Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                            
                            // Create mock BoundField
                            Object failingField = mock(boundFieldClass);
                            when(boundFieldClass.getMethod("writeField", Object.class).invoke(failingField, any()))
                                .thenReturn(true);
                            doThrow(new IllegalAccessException("Test exception"))
                                .when(boundFieldClass.getMethod("write", com.google.gson.stream.JsonWriter.class, Object.class))
                                .invoke(failingField, out, any(Object.class));
                            
                            // Create boundFields map with correct type
                            java.util.Map<String, Object> boundFields = new java.util.HashMap<String, Object>();
                            boundFields.put("failingField", failingField);
                            
                            com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                                mock(com.google.gson.internal.ConstructorConstructor.class);
                            com.google.gson.FieldNamingStrategy fieldNamingStrategy = 
                                mock(com.google.gson.FieldNamingStrategy.class);
                            com.google.gson.internal.Excluder excluder = 
                                mock(com.google.gson.internal.Excluder.class);
                            
                            com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapter = 
                                new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                    constructorConstructor, 
                                    fieldNamingStrategy, 
                                    excluder
                                );
                            
                            // Use reflection to set boundFields
                            try {
                                java.lang.reflect.Field field = adapterFactoryClass
                                    .getDeclaredField("boundFields");
                                field.setAccessible(true);
                                field.set(adapter, boundFields);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            
                            // Test
                            try {
                                // Create a test object to write
                                Object testObject = new Object();
                                // Use reflection to call the write method
                                Method writeMethod = adapterFactoryClass.getDeclaredMethod("write", 
                                    com.google.gson.stream.JsonWriter.class, Object.class);
                                writeMethod.setAccessible(true);
                                writeMethod.invoke(adapter, out, testObject);
                                fail("Expected IllegalAccessException");
                            } catch (InvocationTargetException e) {
                                Throwable cause = e.getCause();
                                assertTrue(cause instanceof IllegalAccessException);
                                assertEquals("Test exception", cause.getMessage());
                            }
                        }

    @Test
                    public void testWrite_WithFields() throws Exception {
                        // Setup
                        com.google.gson.stream.JsonWriter out = mock(com.google.gson.stream.JsonWriter.class);
                        
                        // Create boundFields map
                        Map<String, Object> boundFields = new LinkedHashMap<>();
                        
                        // Get BoundField class via reflection
                        Class<?> boundFieldClass = Class.forName("com.google.gson.internal.bind.ReflectiveTypeAdapterFactory$BoundField");
                        
                        // Create mock BoundField instances
                        Object field1 = mock(boundFieldClass);
                        when(boundFieldClass.getMethod("writeField", Object.class).invoke(field1, any())).thenReturn(true);
                        when(boundFieldClass.getMethod("getName").invoke(field1)).thenReturn("field1");
                        
                        Object field2 = mock(boundFieldClass);
                        when(boundFieldClass.getMethod("writeField", Object.class).invoke(field2, any())).thenReturn(false);
                        when(boundFieldClass.getMethod("getName").invoke(field2)).thenReturn("field2");
                        
                        Object field3 = mock(boundFieldClass);
                        when(boundFieldClass.getMethod("writeField", Object.class).invoke(field3, any())).thenReturn(true);
                        when(boundFieldClass.getMethod("getName").invoke(field3)).thenReturn("field3");
                        
                        // Add fields to boundFields map
                        boundFields.put("field1", field1);
                        boundFields.put("field2", field2);
                        boundFields.put("field3", field3);
                        
                        com.google.gson.internal.ConstructorConstructor constructorConstructor = 
                            mock(com.google.gson.internal.ConstructorConstructor.class);
                        com.google.gson.FieldNamingStrategy fieldNamingStrategy = 
                            mock(com.google.gson.FieldNamingStrategy.class);
                        com.google.gson.internal.Excluder excluder = 
                            mock(com.google.gson.internal.Excluder.class);
                        
                        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapterFactory = 
                            new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                                constructorConstructor, 
                                fieldNamingStrategy, 
                                excluder
                            );
                        
                        // Use reflection to set boundFields
                        java.lang.reflect.Field field = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                            .getDeclaredField("boundFields");
                        field.setAccessible(true);
                        field.set(adapterFactory, boundFields);
                        
                        // Create a TypeAdapter for Object.class
                        com.google.gson.Gson gson = new com.google.gson.Gson();
                        com.google.gson.reflect.TypeToken<Object> typeToken = com.google.gson.reflect.TypeToken.get(Object.class);
                        com.google.gson.TypeAdapter<Object> adapter = adapterFactory.create(gson, typeToken);
                        
                        // Execute
                        Object testObject = new Object();
                        adapter.write(out, testObject);
                        
                        // Verify
                        verify(out).beginObject();
                        verify(out).endObject();
                        
                        // Verify field1 was written
                        verify(out).name("field1");
                        verify(boundFieldClass.getMethod("write", com.google.gson.stream.JsonWriter.class, Object.class)
                            .invoke(field1, out, testObject));
                        
                        // Verify field2 was not written
                        verify(out, never()).name("field2");
                        verify(boundFieldClass.getMethod("write", com.google.gson.stream.JsonWriter.class, Object.class)
                            .invoke(field2, out, testObject), never());
                        
                        // Verify field3 was written
                        verify(out).name("field3");
                        verify(boundFieldClass.getMethod("write", com.google.gson.stream.JsonWriter.class, Object.class)
                            .invoke(field3, out, testObject));
                    }

    @Test
    public void testRead_WhenIllegalAccessExceptionOccurs_ThrowsAssertionError() throws Exception {
        // Mock dependencies
        ConstructorConstructor constructorConstructor = mock(ConstructorConstructor.class);
        FieldNamingStrategy fieldNamingPolicy = mock(FieldNamingStrategy.class);
        Excluder excluder = mock(Excluder.class);
        Gson gson = mock(Gson.class);
        
        // Create test instance
        ReflectiveTypeAdapterFactory adapterFactory = new ReflectiveTypeAdapterFactory(
            constructorConstructor, fieldNamingPolicy, excluder);
        
        // Get BoundField class through reflection
        Class<?> boundFieldClass = null;
        for (Class<?> clazz : ReflectiveTypeAdapterFactory.class.getDeclaredClasses()) {
            if (clazz.getSimpleName().equals("BoundField")) {
                boundFieldClass = clazz;
                break;
            }
        }
        assertNotNull(boundFieldClass);
        
        // Create boundFields map
        
        // Mock bound fields
        Object field = mock(boundFieldClass);
        Method isDeserializedMethod = boundFieldClass.getDeclaredMethod("isDeserialized");
        isDeserializedMethod.setAccessible(true);
        when(isDeserializedMethod.invoke(field)).thenReturn(true);
        
        // Inject boundFields into adapterFactory using reflection
        Field boundFieldsField = ReflectiveTypeAdapterFactory.class.getDeclaredField("boundFields");
        boundFieldsField.setAccessible(true);
        
        // Mock JsonReader
        JsonReader in = mock(JsonReader.class);
        when(in.peek()).thenReturn(JsonToken.BEGIN_OBJECT);
        when(in.hasNext()).thenReturn(true);
        when(in.nextName()).thenReturn("field");
        
        // Mock constructor
        ObjectConstructor<Object> constructor = mock(ObjectConstructor.class);
        when(constructor.construct()).thenReturn(new Object());
        when(constructorConstructor.get(any(TypeToken.class))).thenReturn(constructor);
        
        // Setup exception
        Method readMethod = boundFieldClass.getDeclaredMethod("read", JsonReader.class, Object.class);
        readMethod.setAccessible(true);
        when(readMethod.invoke(field, any(JsonReader.class), any(Object.class)))
            .thenThrow(new IllegalAccessException("Access denied"));
        
        // Create type adapter
        TypeAdapter<Object> adapter = adapterFactory.create(gson, TypeToken.get(Object.class));
        
        // Verify assertion
        try {
            adapter.read(in);
            fail("Expected AssertionError");
        } catch (AssertionError expected) {
            // Expected exception
        }
    }

    @Test
    public void testWrite_EmptyObject() throws Exception {
        // Setup
        com.google.gson.stream.JsonWriter out = mock(com.google.gson.stream.JsonWriter.class);
        // Create an empty boundFields map
        com.google.gson.internal.ConstructorConstructor constructorConstructor = 
            mock(com.google.gson.internal.ConstructorConstructor.class);
        com.google.gson.FieldNamingStrategy fieldNamingStrategy = 
            mock(com.google.gson.FieldNamingStrategy.class);
        com.google.gson.internal.Excluder excluder = 
            mock(com.google.gson.internal.Excluder.class);
        
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory adapter = 
            new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(
                constructorConstructor, 
                fieldNamingStrategy, 
                excluder
            );
        
        // Use reflection to set boundFields since it's private final
        try {
            java.lang.reflect.Field field = com.google.gson.internal.bind.ReflectiveTypeAdapterFactory.class
                .getDeclaredField("boundFields");
            field.setAccessible(true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        // Execute
        java.lang.reflect.Method writeMethod = adapter.getClass().getDeclaredMethod("write", 
            com.google.gson.stream.JsonWriter.class, Object.class);
        writeMethod.setAccessible(true);
        writeMethod.invoke(adapter, out, new Object());
        
        // Verify
        verify(out).beginObject();
        verify(out).endObject();
        verify(out, never()).name(anyString());
    }


}
