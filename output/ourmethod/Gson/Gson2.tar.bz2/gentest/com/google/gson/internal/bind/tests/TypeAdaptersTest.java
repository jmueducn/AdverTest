package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
 
public class TypeAdaptersTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                  public void testNewTypeHierarchyFactory_ReturnsNullForIncompatibleTypes() {
                      // Setup
                      Class<Number> clazz = Number.class;
                      TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                      
                      // Test with incompatible type (String)
                      TypeToken<String> stringToken = TypeToken.get(String.class);
                      Gson gson = new Gson();
                      
                      // Verify
                      assertNull(factory.create(gson, stringToken));
                  }

 @Test
                  public void testNewTypeHierarchyFactory_CreatesAdapterForCompatibleTypes() throws IOException {
                      // Setup
                      Class<Number> clazz = Number.class;
                      TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                      
                      // Test with compatible type (Integer)
                      TypeToken<Integer> integerToken = TypeToken.get(Integer.class);
                      Gson gson = new Gson();
                      
                      // Verify adapter is created
                      TypeAdapter<Integer> resultAdapter = factory.create(gson, integerToken);
                      assertNotNull(resultAdapter);
                      
                      // Test adapter behavior
                      JsonReader reader = mock(JsonReader.class);
                      when(typeAdapter.read(reader)).thenReturn(42);
                      assertEquals(42, (int) resultAdapter.read(reader));
                      
                      JsonWriter writer = mock(JsonWriter.class);
                      resultAdapter.write(writer, 42);
                      verify(typeAdapter).write(writer, 42);
                  }

 @Test
                  public void testNewTypeHierarchyFactory_ThrowsJsonSyntaxExceptionForWrongInstance() throws IOException {
                      // Setup
                      Class<Number> clazz = Number.class;
                      TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                      
                      // Test with compatible type (Integer)
                      TypeToken<Integer> integerToken = TypeToken.get(Integer.class);
                      Gson gson = new Gson();
                      TypeAdapter<Integer> resultAdapter = factory.create(gson, integerToken);
                      
                      // Setup exception expectation
                      thrown.expect(JsonSyntaxException.class);
                      thrown.expectMessage("Expected a java.lang.Integer but was java.lang.Double");
                      
                      // Test with wrong instance type
                      JsonReader reader = mock(JsonReader.class);
                      when(typeAdapter.read(reader)).thenReturn(42.0); // Returns Double instead of Integer
                      resultAdapter.read(reader);
                  }

 @Test
                  public void testNewTypeHierarchyFactory_ToStringReturnsExpectedFormat() {
                      // Setup
                      Class<Number> clazz = Number.class;
                      TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                      
                      // Verify toString
                      String expected = "Factory[typeHierarchy=java.lang.Number,adapter=" + typeAdapter.toString() + "]";
                      assertEquals(expected, factory.toString());
                  }

 @Test
                  public void testNewTypeHierarchyFactory_HandlesNullValues() throws IOException {
                      // Setup
                      Class<Number> clazz = Number.class;
                      TypeAdapter<Number> typeAdapter = mock(TypeAdapter.class);
                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, typeAdapter);
                      
                      // Test with compatible type (Integer)
                      TypeToken<Integer> integerToken = TypeToken.get(Integer.class);
                      Gson gson = new Gson();
                      TypeAdapter<Integer> resultAdapter = factory.create(gson, integerToken);
                      
                      // Test with null value
                      JsonReader reader = mock(JsonReader.class);
                      when(typeAdapter.read(reader)).thenReturn(null);
                      assertNull(resultAdapter.read(reader));
                  }

 @Test
                  public void testNewTypeHierarchyFactory_WorksWithCustomTypes() {
                      // Setup custom type hierarchy
                      class Parent {}
                      class Child extends Parent {}
                      
                      TypeAdapter<Parent> parentAdapter = mock(TypeAdapter.class);
                      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(Parent.class, parentAdapter);
                      
                      // Test with child type
                      TypeToken<Child> childToken = TypeToken.get(Child.class);
                      Gson gson = new Gson();
                      
                      TypeAdapter<Child> resultAdapter = factory.create(gson, childToken);
                      assertNotNull(resultAdapter);
                  }

 @Test
          public void testRead_WhenNullToken_ReturnsNull() throws Exception {
              // Arrange
              JsonReader mockReader = mock(JsonReader.class);
              TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                  @Override
                  public String read(JsonReader in) throws IOException {
                      if (in.peek() == JsonToken.NULL) {
                          in.nextNull();
                          return null;
                      }
                      return in.nextString();
                  }
          
                  @Override
                  public void write(JsonWriter out, String value) throws IOException {
                      out.value(value);
                  }
              };
              
              when(mockReader.peek()).thenReturn(JsonToken.NULL);
              
              // Act
              String result = typeAdapters.read(mockReader);
              
              // Assert
              verify(mockReader).nextNull();
              assertNull(result);
          }

 @Test
          public void testRead_WhenValidString_ReturnsMappedConstant() throws Exception {
              // Arrange
              JsonReader mockReader = mock(JsonReader.class);
              TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
                  @Override
                  public void write(JsonWriter out, String value) {
                      // Not used in this test
                  }
          
                  @Override
                  public String read(JsonReader in) {
                      try {
                          String value = in.nextString();
                          if ("VALUE1".equals(value)) {
                              return "Constant1";
                          }
                          return null;
                      } catch (IOException e) {
                          throw new RuntimeException(e);
                      }
                  }
              };
              
              when(mockReader.peek()).thenReturn(JsonToken.STRING);
              when(mockReader.nextString()).thenReturn("VALUE1");
              
              // Act
              String result = typeAdapter.read(mockReader);
              
              // Assert
              verify(mockReader, never()).nextNull();
              assertEquals("Constant1", result);
          }

 @Test
          public void testRead_WhenUnknownString_ReturnsNull() throws Exception {
              // Arrange
              JsonReader mockReader = mock(JsonReader.class);
              TypeAdapter<String> typeAdapters = TypeAdapters.STRING;
              
              when(mockReader.peek()).thenReturn(JsonToken.STRING);
              when(mockReader.nextString()).thenReturn("UNKNOWN_VALUE");
              
              // Act
              String result = typeAdapters.read(mockReader);
              
              // Assert
              assertNull(result);
          }

 @Test
          public void testRead_WhenInvalidToken_ThrowsException() throws Exception {
              // Arrange
              JsonReader mockReader = mock(JsonReader.class);
              when(mockReader.peek()).thenReturn(JsonToken.BEGIN_ARRAY);
              
              TypeAdapter<Object> typeAdapters = new TypeAdapter<Object>() {
                  @Override
                  public Object read(JsonReader in) throws IOException {
                      JsonToken token = in.peek();
                      if (token != JsonToken.STRING && token != JsonToken.NULL) {
                          throw new IllegalStateException("Expected STRING or NULL but was " + token);
                      }
                      return null;
                  }
          
                  @Override
                  public void write(JsonWriter out, Object value) throws IOException {
                      // Not needed for this test
                  }
              };
              
              ExpectedException thrown = ExpectedException.none();
              
              // Expect exception
              thrown.expect(IllegalStateException.class);
              thrown.expectMessage("Expected STRING or NULL but was BEGIN_ARRAY");
              
              // Act
              typeAdapters.read(mockReader);
          }

 @Test
          public void testRead_WhenEmptyString_ReturnsNull() throws Exception {
              // Arrange
              JsonReader mockReader = mock(JsonReader.class);
              TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                  @Override
                  public String read(JsonReader in) throws IOException {
                      String value = in.nextString();
                      return value.isEmpty() ? null : value;
                  }
          
                  @Override
                  public void write(JsonWriter out, String value) throws IOException {
                      out.value(value);
                  }
              };
              
              when(mockReader.peek()).thenReturn(JsonToken.STRING);
              when(mockReader.nextString()).thenReturn("");
              
              // Act
              String result = typeAdapters.read(mockReader);
              
              // Assert
              assertNull(result);
          }

 @Test
          public void testWrite_WithValidMappedValue() throws Exception {
              // Arrange
              String testValue = "test_value";
              JsonWriter jsonWriter = mock(JsonWriter.class);
              TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
                  @Override
                  public void write(JsonWriter out, String value) throws IOException {
                      out.value("TEST");
                  }
                  
                  @Override
                  public String read(JsonReader in) throws IOException {
                      return null;
                  }
              };
              
              // Act
              typeAdapter.write(jsonWriter, testValue);
              
              // Assert
              verify(jsonWriter).value("TEST");
          }

 @Test
          public void testWrite_WithAnotherValidMappedValue() throws Exception {
              // Arrange
              String testValue = "example_value";
              JsonWriter jsonWriter = mock(JsonWriter.class);
              TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                  @Override
                  public String read(JsonReader in) throws IOException {
                      return null;
                  }
          
                  @Override
                  public void write(JsonWriter out, String value) throws IOException {
                      out.value("EXAMPLE");
                  }
              };
              
              // Act
              typeAdapters.write(jsonWriter, testValue);
              
              // Assert
              verify(jsonWriter).value("EXAMPLE");
          }

 @Test
          public void testWrite_WithEmptyStringValue() throws Exception {
              // Arrange
              String testValue = "";
              JsonWriter jsonWriter = mock(JsonWriter.class);
              TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                  @Override
                  public String read(JsonReader in) throws IOException {
                      return null;
                  }
          
                  @Override
                  public void write(JsonWriter out, String value) throws IOException {
                      out.value(value);
                  }
              };
              
              // Act
              typeAdapters.write(jsonWriter, testValue);
              
              // Assert
              verify(jsonWriter).value(testValue);
          }

 @Test
          public void testWrite_VerifiesNoOtherInteractions() throws Exception {
              // Arrange
              String testValue = "test_value";
              JsonWriter jsonWriter = mock(JsonWriter.class);
              TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                  @Override
                  public String read(JsonReader in) throws IOException {
                      return null;
                  }
          
                  @Override
                  public void write(JsonWriter out, String value) throws IOException {
                      out.value("TEST");
                  }
              };
              
              // Act
              typeAdapters.write(jsonWriter, testValue);
              
              // Assert
              verify(jsonWriter).value("TEST");
              verifyNoMoreInteractions(jsonWriter);
          }

 @Test
      public void testWrite_WithNullValue() throws Exception {
          // Arrange
          String testValue = null;
          JsonWriter jsonWriter = mock(JsonWriter.class);
          TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
              @Override
              public void write(JsonWriter out, String value) {
                  try {
                      out.value((String)value);  // Explicitly cast to String to resolve ambiguity
                  } catch (IOException e) {
                      throw new RuntimeException(e);
                  }
              }
          
              @Override
              public String read(JsonReader in) throws IOException {
                  return null;
              }
          };
          
          // Act
          typeAdapter.write(jsonWriter, testValue);
          
          // Assert
          verify(jsonWriter).value((String)null);  // Explicitly cast to String to resolve ambiguity
      }

 @Test
      public void testWrite_WithUnmappedValue() throws Exception {
          // Arrange
          String testValue = "unmapped_value";
          JsonWriter jsonWriter = mock(JsonWriter.class);
          TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
              @Override
              public void write(JsonWriter out, String value) throws IOException {
                  out.value((String) null);
              }
              
              @Override
              public String read(JsonReader in) throws IOException {
                  return null;
              }
          };
          
          // Act
          typeAdapter.write(jsonWriter, testValue);
          
          // Assert
          verify(jsonWriter).value((String) null);
      }

 @Test
  public void testRead_TypeMismatch_ShouldThrowException() throws IOException {
      // Setup
      Class<Number> clazz = Number.class;
      TypeAdapter<Number> mockTypeAdapter = mock(TypeAdapter.class);
      
      // Create test objects
      JsonReader mockReader = mock(JsonReader.class);
      String expectedExceptionMessage = "Expected a " + String.class.getName() + " but was " + Number.class.getName();
      
      // Configure mocks
      Number numberResult = 42; // Doesn't match String.class
      when(mockTypeAdapter.read(mockReader)).thenReturn(numberResult);
      
      // Create factory and adapter
      TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
      TypeAdapter<String> adapter = factory.create(new Gson(), TypeToken.get(String.class));
      
      // Test and verify
      try {
          String result = adapter.read(mockReader);
          fail("Expected JsonSyntaxException but got: " + result);
      } catch (JsonSyntaxException e) {
          assertEquals(expectedExceptionMessage, e.getMessage());
      }
      
      // Verify interactions
      verify(mockTypeAdapter).read(mockReader);
  }

 @Test
 public void testTypeHierarchyFactoryWriteDoesNotWrapInObject() throws IOException {
     // Setup
     Class<String> clazz = String.class;
     TypeAdapter<String> mockTypeAdapter = mock(TypeAdapter.class);
     JsonWriter mockWriter = mock(JsonWriter.class);
     String testValue = "test value";
     
     // Create the factory and adapter
     TypeAdapterFactory factory = TypeAdapters.newTypeHierarchyFactory(clazz, mockTypeAdapter);
     TypeAdapter<String> adapter = factory.create(new Gson(), TypeToken.get(String.class));
     
     // Execute
     adapter.write(mockWriter, testValue);
     
     // Verify
     // Original behavior should only call typeAdapter.write()
     verify(mockTypeAdapter).write(mockWriter, testValue);
     
     // Mutation adds beginObject/endObject calls - verify they don't happen
     verify(mockWriter, never()).beginObject();
     verify(mockWriter, never()).endObject();
     
     // Ensure no other interactions with the writer
     verifyNoMoreInteractions(mockWriter);
 }

}
