package gentest.com.google.gson.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.*;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
 
public class TypeInfoFactoryTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                public void testGetActualType_WithGenericArrayTypeAndDifferentComponentType() {
                                                                    // Arrange
                                                                    GenericArrayType genericArrayType = mock(GenericArrayType.class);
                                                                    Type componentType = mock(Type.class);
                                                                    Type actualType = String.class;
                                                                    
                                                                    when(genericArrayType.getGenericComponentType()).thenReturn(componentType);
                                                                    // Mock the getActualType call for component type to return different actual type
                                                                    // This would require PowerMock or refactoring to make testable
                                                                    
                                                                    // Act
                                                                    // This test would need to be completed with proper mocking setup
                                                                    // Type result = TypeInfoFactory.getActualType(genericArrayType, mock(Type.class), Object.class);
                                                                    
                                                                    // Assert would verify the array wrapping behavior
                                                                }

    @Test
                                                    public void testGetActualType_WithClassType() throws Exception {
                                                        // Arrange
                                                        Class<?> testClass = String.class;
                                                        Type parentType = mock(Type.class);
                                                        Class<?> rawParentClass = Object.class;
                                                        
                                                        // Get the TypeInfoFactory class
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        
                                                        // Get the private method via reflection
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", Type.class, Type.class, Class.class);
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        // Act
                                                        Type result = (Type) getActualTypeMethod.invoke(
                                                            null, testClass, parentType, rawParentClass);
                                                        
                                                        // Assert
                                                        assertEquals(testClass, result);
                                                    }

    @Test
                                                    public void testGetActualType_WithParameterizedType() throws Exception {
                                                        // Arrange
                                                        ParameterizedType parameterizedType = mock(ParameterizedType.class);
                                                        Type rawType = String.class;
                                                        Type ownerType = mock(Type.class);
                                                        Type[] typeArgs = new Type[]{Integer.class};
                                                        
                                                        when(parameterizedType.getOwnerType()).thenReturn(ownerType);
                                                        when(parameterizedType.getRawType()).thenReturn(rawType);
                                                        when(parameterizedType.getActualTypeArguments()).thenReturn(typeArgs);
                                                        
                                                        // Get private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", 
                                                            Type.class, 
                                                            Type.class, 
                                                            Class.class
                                                        );
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        // Act
                                                        Type result = (Type) getActualTypeMethod.invoke(
                                                            null, 
                                                            parameterizedType, 
                                                            parameterizedType, 
                                                            rawType.getClass()
                                                        );
                                                        
                                                        // Assert
                                                        assertTrue(result instanceof ParameterizedType);
                                                        // Additional assertions would verify the ParameterizedTypeImpl creation
                                                    }

    @Test
                                                    public void testGetActualType_WithGenericArrayType() throws Exception {
                                                        // Arrange
                                                        GenericArrayType genericArrayType = mock(GenericArrayType.class);
                                                        Type componentType = String.class;
                                                        when(genericArrayType.getGenericComponentType()).thenReturn(componentType);
                                                        
                                                        // Get the TypeInfoFactory class
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        
                                                        // Get private method via reflection
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", Type.class, Type.class, Class.class);
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        // Act
                                                        Type result = (Type) getActualTypeMethod.invoke(
                                                            null, genericArrayType, mock(Type.class), Object.class);
                                                        
                                                        // Assert
                                                        assertEquals(genericArrayType, result);
                                                    }

    @Test
                                                    public void testGetActualType_WithTypeVariableAndParameterizedParent() throws Exception {
                                                        // Arrange
                                                        TypeVariable<?> typeVariable = mock(TypeVariable.class);
                                                        ParameterizedType parentType = mock(ParameterizedType.class);
                                                        Class<?> rawParentClass = ArrayList.class;
                                                        TypeVariable<?>[] classTypeVariables = new TypeVariable<?>[1];
                                                        classTypeVariables[0] = typeVariable;
                                                        Type[] actualTypeArguments = new Type[]{String.class};
                                                        
                                                        // Mock the Class.getTypeParameters() call
                                                        when(((Class)rawParentClass).getTypeParameters()).thenReturn(classTypeVariables);
                                                        when(parentType.getActualTypeArguments()).thenReturn(actualTypeArguments);
                                                        when(parentType.getRawType()).thenReturn(rawParentClass);
                                                        
                                                        // Use reflection to access private method
                                                        Method getActualTypeMethod = null;
                                                        try {
                                                            // Get the class using reflection since it's package-private
                                                            Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                            getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                                "getActualType", Type.class, Type.class, Class.class);
                                                            getActualTypeMethod.setAccessible(true);
                                                        } catch (ClassNotFoundException | NoSuchMethodException e) {
                                                            fail("Failed to access TypeInfoFactory class or method: " + e.getMessage());
                                                        }
                                                        
                                                        // Act
                                                        Type result = (Type) getActualTypeMethod.invoke(
                                                            null, typeVariable, parentType, rawParentClass);
                                                        
                                                        // Assert
                                                        assertEquals(String.class, result);
                                                    }

    @Test
                                                    public void testGetActualType_WithWildcardType() throws Exception {
                                                        // Arrange
                                                        WildcardType wildcardType = mock(WildcardType.class);
                                                        Type upperBound = String.class;
                                                        when(wildcardType.getUpperBounds()).thenReturn(new Type[]{upperBound});
                                                        
                                                        // Get the TypeInfoFactory class
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        
                                                        // Get private method via reflection
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", 
                                                            Type.class, 
                                                            Type.class, 
                                                            Class.class
                                                        );
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        // Act
                                                        Type result = (Type) getActualTypeMethod.invoke(
                                                            null, 
                                                            wildcardType, 
                                                            mock(Type.class), 
                                                            Object.class
                                                        );
                                                        
                                                        // Assert
                                                        assertEquals(upperBound, result);
                                                    }

    @Test
                                                    public void testGetActualType_WithUnsupportedTypeVariable() throws Exception {
                                                        // Arrange
                                                        TypeVariable<?> typeVariable = mock(TypeVariable.class);
                                                        Type parentType = Object.class;
                                                        Class<?> rawParentClass = Object.class;
                                                        
                                                        // Get the private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", 
                                                            Type.class, 
                                                            Type.class, 
                                                            Class.class
                                                        );
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        thrown.expect(UnsupportedOperationException.class);
                                                        thrown.expectMessage("Expecting parameterized type");
                                                        
                                                        // Act
                                                        getActualTypeMethod.invoke(null, typeVariable, parentType, rawParentClass);
                                                    }

    @Test
                                                    public void testGetActualType_WithInvalidType() throws Exception {
                                                        // Arrange
                                                        Type invalidType = mock(Type.class); // Not any of the supported types
                                                        when(invalidType.toString()).thenReturn("InvalidType");
                                                        
                                                        // Get the private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", 
                                                            Type.class, 
                                                            Type.class, 
                                                            Class.class
                                                        );
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        // Expected exception
                                                        thrown.expect(IllegalArgumentException.class);
                                                        thrown.expectMessage("Type 'InvalidType' is not a Class");
                                                        
                                                        // Act
                                                        getActualTypeMethod.invoke(
                                                            null, // static method
                                                            invalidType, 
                                                            mock(Type.class), 
                                                            Object.class
                                                        );
                                                    }

    @Test
                                                    public void testExtractTypeForHierarchy_WithUnsupportedParentType() throws Exception {
                                                        // Setup
                                                        TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                                        Type parentType = mock(Type.class); // Neither Class nor ParameterizedType
                                                        
                                                        // Get the class and method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method extractTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                                        extractTypeMethod.setAccessible(true);
                                                        
                                                        // Execute
                                                        Type result = (Type) extractTypeMethod.invoke(null, parentType, typeToEvaluate);
                                                        
                                                        // Verify
                                                        assertNull(result);
                                                    }

    @Test
                                                    public void testExtractTypeForHierarchy_WithNonMatchingSuperclass() throws Exception {
                                                        // Setup
                                                        TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                                        Class<?> parentType = String.class; // String's superclass is Object
                                                        
                                                        // Get the private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                                        extractTypeForHierarchy.setAccessible(true);
                                                        
                                                        // Execute
                                                        Type result = (Type) extractTypeForHierarchy.invoke(null, parentType, typeToEvaluate);
                                                        
                                                        // Verify
                                                        assertNull(result);
                                                    }

    @Test
                                                    public void testExtractTypeForHierarchy_WithNullParentType() throws Exception {
                                                        // Setup
                                                        TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                                                        
                                                        // Get private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                                        extractTypeForHierarchy.setAccessible(true);
                                                        
                                                        // Execute
                                                        Type result = (Type) extractTypeForHierarchy.invoke(null, null, typeToEvaluate);
                                                        
                                                        // Verify
                                                        assertNull(result);
                                                    }

    @Test
                                                    public void testExtractTypeForHierarchy_WithNullTypeToEvaluate() throws Exception {
                                                        // Setup
                                                        Class<?> parentType = ArrayList.class;
                                                        
                                                        // Get the private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                                                        extractTypeForHierarchy.setAccessible(true);
                                                        
                                                        // Execute
                                                        Type result = (Type) extractTypeForHierarchy.invoke(null, parentType, null);
                                                        
                                                        // Verify
                                                        assertNull(result);
                                                    }

    @Test
                                                    public void testExtractRealTypes_NullInput() throws Exception {
                                                        // Setup exception expectation
                                                        thrown.expect(NullPointerException.class);
                                                        thrown.expectMessage("actualTypeArguments");
                                                        
                                                        // Get the private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractRealTypes", 
                                                            Type[].class, 
                                                            Type.class, 
                                                            Class.class
                                                        );
                                                        extractRealTypesMethod.setAccessible(true);
                                                        
                                                        // Prepare mock arguments
                                                        Type mockType = mock(Type.class);
                                                        Class<?> mockClass = mock(Class.class);
                                                        
                                                        // Invoke the method with null input
                                                        extractRealTypesMethod.invoke(null, new Object[]{null, mockType, mockClass});
                                                    }

    @Test
                                                    public void testExtractRealTypes_EmptyArray() throws Exception {
                                                        Type[] input = new Type[0];
                                                        Type parentType = mock(Type.class);
                                                        Class<?> rawParentClass = mock(Class.class);
                                                        
                                                        // Get the private method via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractRealTypes", 
                                                            Type[].class, 
                                                            Type.class, 
                                                            Class.class
                                                        );
                                                        extractRealTypesMethod.setAccessible(true);
                                                        
                                                        // Invoke the method
                                                        Type[] result = (Type[]) extractRealTypesMethod.invoke(
                                                            null, // static method
                                                            input, 
                                                            parentType, 
                                                            rawParentClass
                                                        );
                                                        
                                                        assertEquals(0, result.length);
                                                    }

    @Test
                                                    public void testExtractRealTypes_VerifyDelegation() throws Exception {
                                                        Type[] input = new Type[1];
                                                        input[0] = mock(Type.class);
                                                        Type parentType = mock(Type.class);
                                                        Class<?> rawParentClass = mock(Class.class);
                                                        
                                                        // Get the TypeInfoFactory class via reflection
                                                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                        
                                                        // Get the extractRealTypes method via reflection
                                                        Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "extractRealTypes", Type[].class, Type.class, Class.class);
                                                        extractRealTypesMethod.setAccessible(true);
                                                        
                                                        // Get the getActualType method via reflection
                                                        Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                            "getActualType", Type.class, Type.class, Class.class);
                                                        getActualTypeMethod.setAccessible(true);
                                                        
                                                        // Create a mock of TypeInfoFactory
                                                        Object spyFactory = mock(typeInfoFactoryClass);
                                                        when(spyFactory.getClass().getMethod("getActualType", Type.class, Type.class, Class.class)
                                                            .invoke(spyFactory, any(Type.class), any(Type.class), any(Class.class)))
                                                            .thenAnswer(invocation -> getActualTypeMethod.invoke(null, invocation.getArguments()));
                                                        
                                                        // Invoke the method
                                                        extractRealTypesMethod.invoke(null, input, parentType, rawParentClass);
                                                        
                                                        // Verify the delegation
                                                        verify(spyFactory).getClass().getMethod("getActualType", Type.class, Type.class, Class.class)
                                                            .invoke(spyFactory, input[0], parentType, rawParentClass);
                                                    }

    @Test
                                                public void testExtractRealTypes_SingleElement() throws Exception {
                                                    Type[] input = new Type[1];
                                                    input[0] = mock(Type.class);
                                                    Type parentType = mock(Type.class);
                                                    Class<?> rawParentClass = mock(Class.class);
                                                    Type expectedType = mock(Type.class);
                                                    
                                                    // Get the TypeInfoFactory class
                                                    Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                                                    
                                                    // Get the extractRealTypes method via reflection
                                                    Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                        "extractRealTypes", Type[].class, Type.class, Class.class);
                                                    extractRealTypesMethod.setAccessible(true);
                                                    
                                                    // Get the getActualType method via reflection for mocking
                                                    Method getActualTypeMethod = typeInfoFactoryClass.getDeclaredMethod(
                                                        "getActualType", Type.class, Type.class, Class.class);
                                                    getActualTypeMethod.setAccessible(true);
                                                    
                                                    // Create a spy using reflection
                                                    Constructor<?> constructor = typeInfoFactoryClass.getDeclaredConstructor();
                                                    constructor.setAccessible(true);
                                                    Object factory = constructor.newInstance();
                                                    Object spyFactory = spy(factory);
                                                    
                                                    // Mock the behavior of getActualType
                                                    when(getActualTypeMethod.invoke(
                                                        spyFactory, 
                                                        eq(input[0]), 
                                                        eq(parentType), 
                                                        eq(rawParentClass))
                                                    ).thenReturn(expectedType);
                                                    
                                                    // Invoke the method
                                                    Type[] result = (Type[]) extractRealTypesMethod.invoke(
                                                        spyFactory, input, parentType, rawParentClass);
                                                    
                                                    assertEquals(1, result.length);
                                                    assertSame(expectedType, result[0]);
                                                }

    @Test
                    public void testExtractTypeForHierarchy_WithRecursiveTypeResolution() throws Exception {
                        // Setup complex hierarchy
                        TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                        
                        // First level
                        Class<?> level1Class = mock(Class.class);
                        ParameterizedType level1Super = mock(ParameterizedType.class);
                        Class<?> level1RawSuper = mock(Class.class);
                        
                        when(level1Class.getGenericSuperclass()).thenReturn(level1Super);
                        when(level1Super.getRawType()).thenReturn(level1RawSuper);
                        when(level1RawSuper.getTypeParameters()).thenReturn(new TypeVariable[0]);
                        
                        // Second level (where we find our type)
                        ParameterizedType level2Super = mock(ParameterizedType.class);
                        Class<?> level2RawSuper = mock(Class.class);
                        
                        when(level1RawSuper.getGenericSuperclass()).thenReturn(level2Super);
                        when(level2Super.getRawType()).thenReturn(level2RawSuper);
                        when(level2RawSuper.getTypeParameters()).thenReturn(new TypeVariable[]{typeToEvaluate});
                        when(typeToEvaluate.getGenericDeclaration()).thenReturn(level2RawSuper);
                        
                        Type[] actualTypeArguments = new Type[]{Double.class};
                        when(level1Super.getActualTypeArguments()).thenReturn(actualTypeArguments);
                        
                        // Get private method via reflection
                        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                        Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                            "extractTypeForHierarchy", Type.class, TypeVariable.class);
                        extractTypeForHierarchy.setAccessible(true);
                        
                        // Execute
                        Type result = (Type) extractTypeForHierarchy.invoke(null, level1Class, typeToEvaluate);
                        
                        // Verify
                        assertEquals(Double.class, result);
                    }

    @Test
            public void testExtractTypeForHierarchy_WithClassParentTypeAndMatchingSuperclass() throws Exception {
                // Setup
                TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
                Class<?> parentType = ArrayList.class;
                ParameterizedType superClass = mock(ParameterizedType.class);
                Class<?> rawSuperClassType = mock(Class.class);
                
                when(parentType.getGenericSuperclass()).thenReturn(superClass);
                when(superClass.getRawType()).thenReturn(rawSuperClassType);
                when(rawSuperClassType.getTypeParameters()).thenReturn(new TypeVariable[]{typeToEvaluate});
                when(typeToEvaluate.getGenericDeclaration()).thenReturn(rawSuperClassType);
                
                Type[] actualTypeArguments = new Type[]{String.class};
                when(superClass.getActualTypeArguments()).thenReturn(actualTypeArguments);
                
                // Get the TypeInfoFactory class and method via reflection
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
                    "extractTypeForHierarchy", Type.class, TypeVariable.class);
                extractTypeForHierarchy.setAccessible(true);
                
                // Execute
                Type result = (Type) extractTypeForHierarchy.invoke(null, parentType, typeToEvaluate);
                
                // Verify
                assertEquals(String.class, result);
            }

    @Test
            public void testExtractRealTypes_MultipleElements() throws Exception {
                // Create input types
                Type[] input = new Type[3];
                input[0] = mock(Type.class);
                input[1] = mock(Type.class);
                input[2] = mock(Type.class);
                
                // Create parent type and class
                Type parentType = mock(Type.class);
                @SuppressWarnings("rawtypes")
                Class rawParentClass = mock(Class.class);
                
                // Get TypeInfoFactory class using reflection
                Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
                
                // Create instance using reflection
                Constructor<?> constructor = typeInfoFactoryClass.getDeclaredConstructor();
                constructor.setAccessible(true);
                Object factory = constructor.newInstance();
                
                // Call extractRealTypes using reflection
                Method extractRealTypesMethod = typeInfoFactoryClass.getDeclaredMethod(
                    "extractRealTypes", Type[].class, Type.class, Class.class);
                extractRealTypesMethod.setAccessible(true);
                
                Type[] result = (Type[]) extractRealTypesMethod.invoke(factory, input, parentType, rawParentClass);
                
                // Verify the result has the same length as input
                assertEquals(3, result.length);
                // Since we can't mock private getActualType behavior, we just verify the method executes
                // without throwing exceptions and returns an array of the correct length
            }

    @Test
    public void testExtractTypeForHierarchy_WithParameterizedParentTypeAndMatchingSuperclass() throws Exception {
        // Setup
        TypeVariable<?> typeToEvaluate = mock(TypeVariable.class);
        ParameterizedType parentType = mock(ParameterizedType.class);
        Class<?> rawParentType = ArrayList.class;
        ParameterizedType superClass = mock(ParameterizedType.class);
        Class<?> rawSuperClassType = java.util.AbstractList.class;
        
        when(parentType.getRawType()).thenReturn(rawParentType);
        when(rawParentType.getGenericSuperclass()).thenReturn(superClass);
        when(superClass.getRawType()).thenReturn(rawSuperClassType);
        when(rawSuperClassType.getTypeParameters()).thenReturn(new TypeVariable[]{typeToEvaluate});
        when(typeToEvaluate.getGenericDeclaration()).thenReturn(rawSuperClassType);
        
        Type[] actualTypeArguments = new Type[]{Integer.class};
        when(parentType.getActualTypeArguments()).thenReturn(actualTypeArguments);
        
        // Get private method via reflection
        Class<?> typeInfoFactoryClass = Class.forName("com.google.gson.TypeInfoFactory");
        Method extractTypeForHierarchy = typeInfoFactoryClass.getDeclaredMethod(
            "extractTypeForHierarchy", Type.class, TypeVariable.class);
        extractTypeForHierarchy.setAccessible(true);
        
        // Execute
        Type result = (Type) extractTypeForHierarchy.invoke(null, parentType, typeToEvaluate);
        
        // Verify
        assertEquals(Integer.class, result);
    }


}
