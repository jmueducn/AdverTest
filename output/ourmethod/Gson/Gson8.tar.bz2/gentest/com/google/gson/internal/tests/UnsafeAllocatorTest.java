package gentest.com.google.gson.internal.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.*;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
 
public class UnsafeAllocatorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                              public void testNewInstance_WithConcreteClass() throws Exception {
                                                                                                                                                                                                                  // Create a concrete implementation for this test
                                                                                                                                                                                                                  UnsafeAllocator concreteAllocator = new UnsafeAllocator() {
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public <T> T newInstance(Class<T> c) {
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              return c.newInstance();
                                                                                                                                                                                                                          } catch (InstantiationException | IllegalAccessException e) {
                                                                                                                                                                                                                              throw new RuntimeException(e);
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  };
                                                                                                                                                                                                          
                                                                                                                                                                                                                  Object result = concreteAllocator.newInstance(Object.class);
                                                                                                                                                                                                                  assertNotNull(result);
                                                                                                                                                                                                                  assertEquals(Object.class, result.getClass());
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testNewInstance_WithAbstractClass() throws Exception {
                                                                                                                                                                                                                  thrown.expect(InstantiationException.class);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create a concrete implementation that tries to instantiate abstract class
                                                                                                                                                                                                                  UnsafeAllocator concreteAllocator = new UnsafeAllocator() {
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public <T> T newInstance(Class<T> c) throws InstantiationException {
                                                                                                                                                                                                                          if (c.isInterface() || java.lang.reflect.Modifier.isAbstract(c.getModifiers())) {
                                                                                                                                                                                                                              throw new InstantiationException();
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              return c.newInstance();
                                                                                                                                                                                                                          } catch (IllegalAccessException e) {
                                                                                                                                                                                                                              throw new RuntimeException(e);
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  };
                                                                                                                                                                                                          
                                                                                                                                                                                                                  concreteAllocator.newInstance(UnsafeAllocator.class);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testNewInstance_WithInterface() throws Exception {
                                                                                                                                                                                                                  thrown.expect(InstantiationException.class);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create a concrete implementation that tries to instantiate interface
                                                                                                                                                                                                                  UnsafeAllocator concreteAllocator = new UnsafeAllocator() {
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      public <T> T newInstance(Class<T> c) throws InstantiationException {
                                                                                                                                                                                                                          if (c.isInterface()) {
                                                                                                                                                                                                                              throw new InstantiationException();
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              return c.newInstance();
                                                                                                                                                                                                                          } catch (IllegalAccessException e) {
                                                                                                                                                                                                                              throw new RuntimeException(e);
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  };
                                                                                                                                                                                                          
                                                                                                                                                                                                                  concreteAllocator.newInstance(Runnable.class);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testCreate_ReturnsNonNullInstance() {
                                                                                                                                                                                                                  UnsafeAllocator instance = UnsafeAllocator.create();
                                                                                                                                                                                                                  assertNotNull(instance);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testCreate_ReturnsNewInstanceEachTime() {
                                                                                                                                                                                                                  UnsafeAllocator instance1 = UnsafeAllocator.create();
                                                                                                                                                                                                                  UnsafeAllocator instance2 = UnsafeAllocator.create();
                                                                                                                                                                                                                  assertNotSame(instance1, instance2);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testCreate_WithObjectStreamClassAvailable() throws Exception {
                                                                                                                                                                                                                  // Make Unsafe unavailable
                                                                                                                                                                                                                  when(Class.forName("sun.misc.Unsafe")).thenThrow(new ClassNotFoundException());
                                                                                                                                                                                                          
                                                                                                                                                                                                                  // Setup ObjectStreamClass mocks
                                                                                                                                                                                                                  Method mockGetConstructorId = mock(Method.class);
                                                                                                                                                                                                                  Method mockNewInstance = mock(Method.class);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                                                                      .thenReturn(mockGetConstructorId);
                                                                                                                                                                                                                  when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(123);
                                                                                                                                                                                                                  when(ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class))
                                                                                                                                                                                                                      .thenReturn(mockNewInstance);
                                                                                                                                                                                                          
                                                                                                                                                                                                                  // Test the create method
                                                                                                                                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                                                  assertNotNull(allocator);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test the allocator's behavior
                                                                                                                                                                                                                  Class<String> testClass = String.class;
                                                                                                                                                                                                                  when(mockNewInstance.invoke(null, testClass, 123)).thenReturn("test");
                                                                                                                                                                                                                  assertEquals("test", allocator.newInstance(testClass));
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testCreate_WithObjectInputStreamAvailable() throws Exception {
                                                                                                                                                                                                                  // Make previous methods unavailable
                                                                                                                                                                                                                  when(Class.forName("sun.misc.Unsafe")).thenThrow(new ClassNotFoundException());
                                                                                                                                                                                                                  when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                                                                      .thenThrow(new NoSuchMethodException());
                                                                                                                                                                                                          
                                                                                                                                                                                                                  // Setup ObjectInputStream mock
                                                                                                                                                                                                                  Method mockNewInstance = mock(Method.class);
                                                                                                                                                                                                                  when(ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class))
                                                                                                                                                                                                                      .thenReturn(mockNewInstance);
                                                                                                                                                                                                          
                                                                                                                                                                                                                  // Test the create method
                                                                                                                                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                                                  assertNotNull(allocator);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test the allocator's behavior
                                                                                                                                                                                                                  Class<String> testClass = String.class;
                                                                                                                                                                                                                  when(mockNewInstance.invoke(null, testClass, Object.class)).thenReturn("test");
                                                                                                                                                                                                                  assertEquals("test", allocator.newInstance(testClass));
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                      public void testNewInstance_WithNullClass() throws Exception {
                                                                                                                                                                                                          UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                                          ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                          thrown.expect(NullPointerException.class);
                                                                                                                                                                                                          allocator.newInstance(null);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testCreate_WithNoAllocationMethodsAvailable() throws Exception {
                                                                                                                                                                                                          // Setup expected exception rule
                                                                                                                                                                                                          ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Make all allocation methods unavailable
                                                                                                                                                                                                          when(Class.forName("sun.misc.Unsafe")).thenThrow(new ClassNotFoundException());
                                                                                                                                                                                                          when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                                                              .thenThrow(new NoSuchMethodException());
                                                                                                                                                                                                          when(ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class))
                                                                                                                                                                                                              .thenThrow(new NoSuchMethodException());
                                                                                                                                                                                                      
                                                                                                                                                                                                          // Test the create method
                                                                                                                                                                                                          UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                                          assertNotNull(allocator);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify it falls back to the basic implementation
                                                                                                                                                                                                          expectedException.expect(UnsupportedOperationException.class);
                                                                                                                                                                                                          expectedException.expectMessage("Cannot allocate java.lang.String");
                                                                                                                                                                                                          allocator.newInstance(String.class);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testNewInstance_WithNonInstantiableClass() throws Exception {
                                                                                                                                                                                                          // Create an allocator (any implementation will do)
                                                                                                                                                                                                          UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Setup expected exception rule
                                                                                                                                                                                                          ExpectedException expectedException = ExpectedException.none();
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Test with an interface (non-instantiable)
                                                                                                                                                                                                          expectedException.expect(AssertionError.class);
                                                                                                                                                                                                          allocator.newInstance(Runnable.class);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testAssertInstantiable_WithConcreteClass() throws Exception {
                                                                                                                                                                                                          Class<?> concreteClass = String.class; // String is a concrete class
                                                                                                                                                                                                          Class<?> allocatorClass = Class.forName("com.google.gson.internal.UnsafeAllocator");
                                                                                                                                                                                                          Method assertInstantiableMethod = allocatorClass.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                                          assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                                          assertInstantiableMethod.invoke(null, concreteClass);
                                                                                                                                                                                                          // No exception expected
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testAssertInstantiable_WithInterface() throws Exception {
                                                                                                                                                                                                          Class<?> interfaceClass = Runnable.class; // Runnable is an interface
                                                                                                                                                                                                          
                                                                                                                                                                                                          thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                                                                          thrown.expectMessage("Interface can't be instantiated! Interface name: java.lang.Runnable");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get the private assertInstantiable method via reflection
                                                                                                                                                                                                          Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                                          assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Invoke the method on null since it's static
                                                                                                                                                                                                          assertInstantiableMethod.invoke(null, interfaceClass);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testAssertInstantiable_WithAbstractClass() throws Exception {
                                                                                                                                                                                                          Class<?> abstractClass = Number.class; // Number is an abstract class
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get the private assertInstantiable method via reflection
                                                                                                                                                                                                          Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                                          assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                                                                          thrown.expectMessage("Abstract class can't be instantiated! Class name: java.lang.Number");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Invoke the method on null since it's static
                                                                                                                                                                                                          assertInstantiableMethod.invoke(null, abstractClass);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testAssertInstantiable_WithMockedInterface() throws Exception {
                                                                                                                                                                                                          Class<?> mockedInterface = mock(Class.class);
                                                                                                                                                                                                          when(mockedInterface.getModifiers()).thenReturn(Modifier.INTERFACE);
                                                                                                                                                                                                          when(mockedInterface.getName()).thenReturn("com.example.TestInterface");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get the private assertInstantiable method using reflection
                                                                                                                                                                                                          Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                                          assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                                                                          thrown.expectMessage("Interface can't be instantiated! Interface name: com.example.TestInterface");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Invoke the method on null instance since it's static
                                                                                                                                                                                                          assertInstantiableMethod.invoke(null, mockedInterface);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testAssertInstantiable_WithMockedAbstractClass() throws Exception {
                                                                                                                                                                                                          Class<?> mockedAbstractClass = mock(Class.class);
                                                                                                                                                                                                          when(mockedAbstractClass.getModifiers()).thenReturn(Modifier.ABSTRACT);
                                                                                                                                                                                                          when(mockedAbstractClass.getName()).thenReturn("com.example.TestAbstractClass");
                                                                                                                                                                                                          
                                                                                                                                                                                                          thrown.expect(UnsupportedOperationException.class);
                                                                                                                                                                                                          thrown.expectMessage("Abstract class can't be instantiated! Class name: com.example.TestAbstractClass");
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Use reflection to access the private method
                                                                                                                                                                                                          Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                                          assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                                          assertInstantiableMethod.invoke(null, mockedAbstractClass);
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                      public void testAssertInstantiable_WithMockedConcreteClass() throws Exception {
                                                                                                                                                                                                          Class<?> mockedConcreteClass = mock(Class.class);
                                                                                                                                                                                                          when(mockedConcreteClass.getModifiers()).thenReturn(0); // 0 means no modifiers (concrete class)
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Get the private assertInstantiable method via reflection
                                                                                                                                                                                                          Method assertInstantiableMethod = UnsafeAllocator.class.getDeclaredMethod("assertInstantiable", Class.class);
                                                                                                                                                                                                          assertInstantiableMethod.setAccessible(true);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Invoke the method (static method, so first parameter is null)
                                                                                                                                                                                                          assertInstantiableMethod.invoke(null, mockedConcreteClass);
                                                                                                                                                                                                          // No exception expected
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                          public void testCreate_WithUnsafeAvailable() throws Exception {
                                                                                                                                                                                              // Setup reflection mocks
                                                                                                                                                                                              Class<?> mockUnsafeClass = mock(Class.class);
                                                                                                                                                                                              Field mockField = mock(Field.class);
                                                                                                                                                                                              Method mockMethod = mock(Method.class);
                                                                                                                                                                                              Object mockUnsafe = mock(Object.class);
                                                                                                                                                                                              
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // Test the create method
                                                                                                                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify it created an allocator that uses Unsafe
                                                                                                                                                                                                  assertNotNull(allocator);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test the allocator's behavior
                                                                                                                                                                                                  Class<String> testClass = String.class;
                                                                                                                                                                                                  try {
                                                                                                                                                                                                      String instance = allocator.newInstance(testClass);
                                                                                                                                                                                                      // If we get here, Unsafe is available and working
                                                                                                                                                                                                      assertNotNull(instance);
                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                      // Expected if Unsafe isn't actually available in this environment
                                                                                                                                                                                                      // We can't properly mock the Unsafe behavior without PowerMockito
                                                                                                                                                                                                      org.junit.Assume.assumeNoException(e);
                                                                                                                                                                                                  }
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  // If Unsafe isn't available at all, mark test as ignored
                                                                                                                                                                                                  org.junit.Assume.assumeNoException(e);
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                          public void testCreateUsesUnsafeAllocation() throws Exception {
                                                                                                                                                                                              // This test will fail if the first allocation strategy (sun.misc.Unsafe) is not used
                                                                                                                                                                                              // which would happen with the mutant that changes Class.forName to Object.class
                                                                                                                                                                                              
                                                                                                                                                                                              UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                              
                                                                                                                                                                                              // Try to create an instance of a simple class
                                                                                                                                                                                              class TestClass {}
                                                                                                                                                                                              TestClass instance = allocator.newInstance(TestClass.class);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify we got an instance (would throw if fell through to throwing allocator)
                                                                                                                                                                                              assertNotNull(instance);
                                                                                                                                                                                              assertEquals(TestClass.class, instance.getClass());
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify it's not using ObjectStreamClass or ObjectInputStream strategies
                                                                                                                                                                                              // by checking if the instance is truly new (not initialized)
                                                                                                                                                                                              // This is a weak check but works for this case
                                                                                                                                                                                              try {
                                                                                                                                                                                                  // If constructor was called, this would fail for TestClass
                                                                                                                                                                                                  // But with unsafe allocation, constructor isn't called
                                                                                                                                                                                                  instance.hashCode();
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Instance appears to have gone through normal construction");
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                         public void testCreateHandlesPrivateFieldAccessFailure() throws Exception {
                                                                                                                                                                                             // The test doesn't need to mock anything since we're testing the real behavior
                                                                                                                                                                                             // with reflection. The mutation will cause the first attempt to fail, but the
                                                                                                                                                                                             // method should continue to the next strategy.
                                                                                                                                                                                             
                                                                                                                                                                                             // Create the allocator - this will exercise all code paths
                                                                                                                                                                                             UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify it created a working allocator by testing with a simple class
                                                                                                                                                                                             class TestClass {}
                                                                                                                                                                                             TestClass instance = allocator.newInstance(TestClass.class);
                                                                                                                                                                                             
                                                                                                                                                                                             // If we get here without exceptions, the test passes
                                                                                                                                                                                             assertNotNull(instance);
                                                                                                                                                                                             assertEquals(TestClass.class, instance.getClass());
                                                                                                                                                                                             
                                                                                                                                                                                             // The key point is that the test passes despite the mutation,
                                                                                                                                                                                             // but a proper mutation testing tool would detect that the
                                                                                                                                                                                             // behavior path changed (from using sun.misc.Unsafe to using
                                                                                                                                                                                             // one of the fallback methods)
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                    public void testCreateDetectsFieldAccessMutation() throws Exception {
                                                                                                                                                                                        // Redirect System.err to capture any reflection failures
                                                                                                                                                                                        java.io.ByteArrayOutputStream errContent = new java.io.ByteArrayOutputStream();
                                                                                                                                                                                        java.io.PrintStream originalErr = System.err;
                                                                                                                                                                                        System.setErr(new java.io.PrintStream(errContent));
                                                                                                                                                                                        
                                                                                                                                                                                        try {
                                                                                                                                                                                            com.google.gson.internal.UnsafeAllocator allocator = com.google.gson.internal.UnsafeAllocator.create();
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify implementation by checking behavior
                                                                                                                                                                                            try {
                                                                                                                                                                                                allocator.newInstance(Object.class);
                                                                                                                                                                                                // If we get here, the test passes because the mutation
                                                                                                                                                                                                // would cause different code paths to be taken
                                                                                                                                                                                            } catch (UnsupportedOperationException e) {
                                                                                                                                                                                                // This would happen if all strategies failed
                                                                                                                                                                                                fail("All allocation strategies failed");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Check if the first strategy failed (which it should with the mutation)
                                                                                                                                                                                            String errOutput = errContent.toString();
                                                                                                                                                                                            assertTrue("Expected reflection failure for sun.misc.Unsafe", 
                                                                                                                                                                                                      errOutput.contains("sun.misc.Unsafe") || 
                                                                                                                                                                                                      errOutput.contains("theUnsafe"));
                                                                                                                                                                                        } finally {
                                                                                                                                                                                            System.setErr(originalErr);
                                                                                                                                                                                        }
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testCreateDetectsSetAccessibleMutation() throws Exception {
                                                                                                                                                                                        // Create a simple test class
                                                                                                                                                                                        class TestClass {}
                                                                                                                                                                                        
                                                                                                                                                                                        // Create the allocator
                                                                                                                                                                                        UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                        
                                                                                                                                                                                        try {
                                                                                                                                                                                            // Try to create an instance
                                                                                                                                                                                            TestClass instance = allocator.newInstance(TestClass.class);
                                                                                                                                                                                            
                                                                                                                                                                                            // If we get here, the test should fail because the mutation wasn't caught
                                                                                                                                                                                            // (the original would work, mutated version would throw)
                                                                                                                                                                                            fail("Expected the mutation to cause fallback to later strategies");
                                                                                                                                                                                        } catch (UnsupportedOperationException e) {
                                                                                                                                                                                            // This is expected for the mutated version that falls through all strategies
                                                                                                                                                                                            assertTrue(e.getMessage().contains("Cannot allocate"));
                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                            // Any other exception means the test didn't properly detect the mutation
                                                                                                                                                                                            fail("Unexpected exception: " + e);
                                                                                                                                                                                        }
                                                                                                                                                                                    }

    @Test(expected = Exception.class)
                                                                                                                                                                                   public void testNewInstance_WithAbstractClass_ShouldThrowException() throws Exception {
                                                                                                                                                                                       // Arrange
                                                                                                                                                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                       
                                                                                                                                                                                       // Create an abstract class for testing
                                                                                                                                                                                       abstract class AbstractTestClass {}
                                                                                                                                                                                       
                                                                                                                                                                                       // Act & Assert
                                                                                                                                                                                       // This should throw from assertInstantiable() in original code
                                                                                                                                                                                       // Mutated version would try to instantiate the abstract class
                                                                                                                                                                                       allocator.newInstance(AbstractTestClass.class);
                                                                                                                                                                                   }

    @Test(expected = Exception.class)
                                                                                                                                                                                   public void testNewInstance_WithInterface_ShouldThrowException() throws Exception {
                                                                                                                                                                                       // Arrange
                                                                                                                                                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                       
                                                                                                                                                                                       // Act & Assert
                                                                                                                                                                                       // This should throw from assertInstantiable() in original code
                                                                                                                                                                                       // Mutated version would try to instantiate the interface
                                                                                                                                                                                       allocator.newInstance(Runnable.class);
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                  public void testCreateWithUnsafeAllocationReturnsNonNullInstance() throws Exception {
                                                                                                                                                                                      // Arrange
                                                                                                                                                                                      // This test assumes the environment supports sun.misc.Unsafe allocation
                                                                                                                                                                                      // (which is true for most standard JVMs)
                                                                                                                                                                                      UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                      
                                                                                                                                                                                      // Act
                                                                                                                                                                                      Object instance = allocator.newInstance(Object.class);
                                                                                                                                                                                      
                                                                                                                                                                                      // Assert
                                                                                                                                                                                      assertNotNull("Allocator should return non-null instance when using sun.misc.Unsafe strategy", 
                                                                                                                                                                                          instance);
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                 public void testCreateHandlesErrors() throws Exception {
                                                                                                                                                                                     // Setup - mock Class.forName to throw an Error
                                                                                                                                                                                     Class<?> mockedClass = mock(Class.class);
                                                                                                                                                                                     when(Class.forName("sun.misc.Unsafe")).thenThrow(new OutOfMemoryError());
                                                                                                                                                                                     
                                                                                                                                                                                     try {
                                                                                                                                                                                         // Execute
                                                                                                                                                                                         UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify - if we get here, the Error was caught (mutant behavior)
                                                                                                                                                                                         assertNotNull(allocator);
                                                                                                                                                                                         
                                                                                                                                                                                         // Test that the fallback allocator works
                                                                                                                                                                                         try {
                                                                                                                                                                                             allocator.newInstance(Object.class);
                                                                                                                                                                                             fail("Expected UnsupportedOperationException");
                                                                                                                                                                                         } catch (UnsupportedOperationException expected) {
                                                                                                                                                                                             // This is expected for the fallback allocator
                                                                                                                                                                                         }
                                                                                                                                                                                     } catch (OutOfMemoryError e) {
                                                                                                                                                                                         // This would happen with original version (catches Exception but not Error)
                                                                                                                                                                                         fail("Original version would propagate Error, mutant should catch it");
                                                                                                                                                                                     }
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                public void testCreateAllocatorUsesObjectStreamClass() throws Exception {
                                                                                                                                                                                    // This test verifies the allocator properly uses ObjectStreamClass approach
                                                                                                                                                                                    // The mutation would cause this approach to fail and fall through
                                                                                                                                                                                    
                                                                                                                                                                                    // Create test class that should be instantiable
                                                                                                                                                                                    class TestClass {}
                                                                                                                                                                                    
                                                                                                                                                                                    // Create allocator instance
                                                                                                                                                                                    UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                    
                                                                                                                                                                                    try {
                                                                                                                                                                                        // Try to create instance - should succeed if ObjectStreamClass approach works
                                                                                                                                                                                        Object instance = allocator.newInstance(TestClass.class);
                                                                                                                                                                                        assertNotNull("Allocator should create instance", instance);
                                                                                                                                                                                        assertEquals("Created instance should be of correct type", 
                                                                                                                                                                                            TestClass.class, instance.getClass());
                                                                                                                                                                                    } catch (UnsupportedOperationException e) {
                                                                                                                                                                                        // If we get here, the allocator fell through to the unsupported case
                                                                                                                                                                                        // which means the mutation was not caught
                                                                                                                                                                                        fail("Allocator fell back to unsupported case - mutation detected");
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                               public void testCreateUsesObjectStreamClassApproach() throws Exception {
                                                                                                                                                                                   // Setup - mock ObjectStreamClass methods
                                                                                                                                                                                   Method mockGetConstructorId = mock(Method.class);
                                                                                                                                                                                   Method mockNewInstance = mock(Method.class);
                                                                                                                                                                                   
                                                                                                                                                                                   // Mock the static methods we'll call via reflection
                                                                                                                                                                                   when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                                       .thenReturn(mockGetConstructorId);
                                                                                                                                                                                   when(ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class))
                                                                                                                                                                                       .thenReturn(mockNewInstance);
                                                                                                                                                                                   
                                                                                                                                                                                   // Mock the method invocations
                                                                                                                                                                                   when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(123);
                                                                                                                                                                                   when(mockNewInstance.invoke(null, String.class, 123)).thenReturn("test");
                                                                                                                                                                                   
                                                                                                                                                                                   // Test the create method
                                                                                                                                                                                   UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the allocator uses the ObjectStreamClass approach
                                                                                                                                                                                   Object instance = allocator.newInstance(String.class);
                                                                                                                                                                                   assertEquals("test", instance);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify accessibility was set (this would fail for the mutant)
                                                                                                                                                                                   verify(mockGetConstructorId).setAccessible(true);
                                                                                                                                                                                   verify(mockNewInstance).setAccessible(true);
                                                                                                                                                                               }

    @Test(expected = Exception.class)
                                                                                                                                                                               public void testCreateFailsWhenAccessibilityNotSet() throws Exception {
                                                                                                                                                                                   // Setup - mock ObjectStreamClass methods but don't allow accessibility
                                                                                                                                                                                   Method mockGetConstructorId = mock(Method.class);
                                                                                                                                                                                   when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                                       .thenReturn(mockGetConstructorId);
                                                                                                                                                                                   
                                                                                                                                                                                   // Don't mock setAccessible(true) - this simulates the mutant behavior
                                                                                                                                                                                   when(mockGetConstructorId.invoke(null, Object.class))
                                                                                                                                                                                       .thenThrow(new IllegalAccessException("Access denied"));
                                                                                                                                                                                   
                                                                                                                                                                                   // This should throw an exception because we can't access the private method
                                                                                                                                                                                   UnsafeAllocator.create();
                                                                                                                                                                               }

    @Test
                                                                                                                                                                              public void testCreateUsesCorrectConstructorId() throws Exception {
                                                                                                                                                                                  // Setup - we need to make the first approach (sun.misc.Unsafe) fail
                                                                                                                                                                                  // so it falls through to the ObjectStreamClass approach
                                                                                                                                                                                  SecurityManager originalManager = System.getSecurityManager();
                                                                                                                                                                                  try {
                                                                                                                                                                                      // Block access to sun.misc.Unsafe
                                                                                                                                                                                      System.setSecurityManager(new SecurityManager() {
                                                                                                                                                                                          @Override
                                                                                                                                                                                          public void checkPermission(java.security.Permission perm) {
                                                                                                                                                                                              if (perm.getName().contains("suppressAccessChecks")) {
                                                                                                                                                                                                  throw new SecurityException("Access denied");
                                                                                                                                                                                              }
                                                                                                                                                                                          }
                                                                                                                                                                                      });
                                                                                                                                                                          
                                                                                                                                                                                      // Test object creation
                                                                                                                                                                                      UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                      Object obj = allocator.newInstance(Object.class);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify the object was created successfully
                                                                                                                                                                                      assertNotNull(obj);
                                                                                                                                                                                      assertEquals(Object.class, obj.getClass());
                                                                                                                                                                                  } finally {
                                                                                                                                                                                      // Restore original security manager
                                                                                                                                                                                      System.setSecurityManager(originalManager);
                                                                                                                                                                                  }
                                                                                                                                                                              }

    @Test(expected = Exception.class)
                                                                                                                                                                             public void testNewInstance_NonInstantiableClass_ShouldFail() throws Exception {
                                                                                                                                                                                 // Arrange
                                                                                                                                                                                 UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                 Class<?> nonInstantiableClass = Runnable.class; // Using an interface which can't be instantiated
                                                                                                                                                                         
                                                                                                                                                                                 // Act
                                                                                                                                                                                 allocator.newInstance(nonInstantiableClass);
                                                                                                                                                                                 
                                                                                                                                                                                 // Assert - should throw exception due to assertInstantiable check
                                                                                                                                                                                 // If mutant is present (if false) check is skipped, this will try to instantiate
                                                                                                                                                                                 // and likely throw a different exception which will still fail the test
                                                                                                                                                                             }

    @Test
                                                                                                                                                                             public void testNewInstance_RegularClass_ShouldSucceed() throws Exception {
                                                                                                                                                                                 // Arrange
                                                                                                                                                                                 UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                                 Class<?> regularClass = Object.class; // Regular instantiable class
                                                                                                                                                                         
                                                                                                                                                                                 // Act
                                                                                                                                                                                 Object instance = allocator.newInstance(regularClass);
                                                                                                                                                                         
                                                                                                                                                                                 // Assert
                                                                                                                                                                                 assertNotNull(instance);
                                                                                                                                                                                 assertEquals(regularClass, instance.getClass());
                                                                                                                                                                             }

    @Test
                                                                                                                                                                       public void testCreateWithObjectStreamClassApproach() throws Exception {
                                                                                                                                                                           // Mock Class.forName to fail for sun.misc.Unsafe
                                                                                                                                                                           when(Class.forName("sun.misc.Unsafe")).thenThrow(new ClassNotFoundException());
                                                                                                                                                                           
                                                                                                                                                                           // Mock ObjectStreamClass methods
                                                                                                                                                                           Method getConstructorId = mock(Method.class);
                                                                                                                                                                           Method newInstance = mock(Method.class);
                                                                                                                                                                           
                                                                                                                                                                           when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                               .thenReturn(getConstructorId);
                                                                                                                                                                           when(ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class))
                                                                                                                                                                               .thenReturn(newInstance);
                                                                                                                                                                           
                                                                                                                                                                           // Return dummy constructorId
                                                                                                                                                                           when(getConstructorId.invoke(null, Object.class)).thenReturn(123);
                                                                                                                                                                           
                                                                                                                                                                           // Create test class
                                                                                                                                                                           class TestClass {}
                                                                                                                                                                           
                                                                                                                                                                           // Setup mock to return test instance when called with TestClass
                                                                                                                                                                           TestClass expectedInstance = new TestClass();
                                                                                                                                                                           when(newInstance.invoke(null, TestClass.class, 123)).thenReturn(expectedInstance);
                                                                                                                                                                           
                                                                                                                                                                           // Create allocator
                                                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                           
                                                                                                                                                                           // Test that it creates TestClass instance (would fail with mutant)
                                                                                                                                                                           Object result = allocator.newInstance(TestClass.class);
                                                                                                                                                                           assertSame(expectedInstance, result);
                                                                                                                                                                           
                                                                                                                                                                           // Verify mock interactions
                                                                                                                                                                           verify(newInstance).invoke(null, TestClass.class, 123);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                       public void testCreateWithObjectStreamClassFallback() throws Exception {
                                                                                                                                                                           // Setup reflection mocks
                                                                                                                                                                           Method mockGetConstructorId = mock(Method.class);
                                                                                                                                                                           Method mockNewInstance = mock(Method.class);
                                                                                                                                                                           
                                                                                                                                                                           // Mock the static methods
                                                                                                                                                                           when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                                                                               .thenReturn(mockGetConstructorId);
                                                                                                                                                                           when(ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class))
                                                                                                                                                                               .thenReturn(mockNewInstance);
                                                                                                                                                                           
                                                                                                                                                                           // Mock the method invocations
                                                                                                                                                                           when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(123);
                                                                                                                                                                           
                                                                                                                                                                           // For the original code, this would work:
                                                                                                                                                                           // when(mockNewInstance.invoke(null, any(Class.class), anyInt())).thenReturn(new Object());
                                                                                                                                                                           
                                                                                                                                                                           // For testing the mutant where setAccessible is commented out,
                                                                                                                                                                           // the newInstance.invoke should throw IllegalAccessException
                                                                                                                                                                           when(mockNewInstance.invoke(null, any(Class.class), anyInt()))
                                                                                                                                                                               .thenThrow(new IllegalAccessException("Method not accessible"));
                                                                                                                                                                           
                                                                                                                                                                           try {
                                                                                                                                                                               UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                               allocator.newInstance(Object.class);
                                                                                                                                                                               fail("Expected exception to be thrown");
                                                                                                                                                                           } catch (UnsupportedOperationException e) {
                                                                                                                                                                               // This is the expected path for the mutant
                                                                                                                                                                               assertEquals("Cannot allocate class java.lang.Object", e.getMessage());
                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                               fail("Unexpected exception: " + e);
                                                                                                                                                                           }
                                                                                                                                                                           
                                                                                                                                                                           // Verify the methods were called as expected
                                                                                                                                                                           verify(mockGetConstructorId).setAccessible(true);
                                                                                                                                                                           // For the mutant, we would want to verify newInstance was NOT made accessible
                                                                                                                                                                           // but we can't verify a negative with Mockito
                                                                                                                                                                       }

    @Test(expected = Exception.class)
                                                                                                                                                                      public void testNewInstanceValidatesCorrectClass() throws Exception {
                                                                                                                                                                          // Create the allocator instance
                                                                                                                                                                          UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                                          
                                                                                                                                                                          // Create a test class that should fail validation
                                                                                                                                                                          Class<?> invalidClass = mock(Class.class);
                                                                                                                                                                          when(invalidClass.getName()).thenReturn("InvalidClass");
                                                                                                                                                                          
                                                                                                                                                                          try {
                                                                                                                                                                              // This should throw because assertInstantiable should check invalidClass
                                                                                                                                                                              allocator.newInstance(invalidClass);
                                                                                                                                                                              fail("Expected exception not thrown");
                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                              // Verify the exception message indicates it failed on the correct class
                                                                                                                                                                              assertTrue(e.getMessage().contains("InvalidClass"));
                                                                                                                                                                              throw e;
                                                                                                                                                                          }
                                                                                                                                                                      }

    @Test
                                                                                                                                                    public void testCreateUsesObjectClassForObjectInputStreamAllocator() throws Exception {
                                                                                                                                                        // Define TestClass inside the method
                                                                                                                                                        class TestClass {}
                                                                                                                                                        
                                                                                                                                                        // Setup reflection mocks to force the ObjectInputStream path
                                                                                                                                                        Method mockNewInstance = mock(Method.class);
                                                                                                                                                        when(mockNewInstance.invoke(null, any(Class.class), any(Class.class)))
                                                                                                                                                            .thenReturn(new Object());
                                                                                                                                                        
                                                                                                                                                        // Mock ObjectInputStream.class to return our mock method
                                                                                                                                                        Class<ObjectInputStream> mockObjectInputStreamClass = mock(Class.class);
                                                                                                                                                        when(mockObjectInputStreamClass.getDeclaredMethod(
                                                                                                                                                            "newInstance", Class.class, Class.class))
                                                                                                                                                            .thenReturn(mockNewInstance);
                                                                                                                                                        
                                                                                                                                                        // Create the allocator - this should use ObjectInputStream path
                                                                                                                                                        UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                        
                                                                                                                                                        // Verify behavior
                                                                                                                                                        TestClass instance = allocator.newInstance(TestClass.class);
                                                                                                                                                        assertNotNull(instance);
                                                                                                                                                        
                                                                                                                                                        // Verify mock interaction - should have used Object.class as second param
                                                                                                                                                        verify(mockNewInstance).invoke(null, TestClass.class, Object.class);
                                                                                                                                                    }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                                    public void testCreateFallbackThrowsUnsupportedOperationException() throws Exception {
                                                                                                                                                        // This test forces the fallback case by ensuring all reflection attempts fail
                                                                                                                                                        // We can't easily mock the static methods called in create(), 
                                                                                                                                                        // but we can rely on the fact that in a normal JVM environment,
                                                                                                                                                        // the fallback case will be reached
                                                                                                                                                        
                                                                                                                                                        // Get the fallback allocator
                                                                                                                                                        UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                        
                                                                                                                                                        // Try to create an instance - should throw UnsupportedOperationException
                                                                                                                                                        // The test will pass if this exception is thrown, and fail otherwise
                                                                                                                                                        allocator.newInstance(Object.class);
                                                                                                                                                    }

    @Test
                                                                                                                                                    public void testCreateFallbackExceptionMessage() {
                                                                                                                                                        try {
                                                                                                                                                            // Get the fallback allocator
                                                                                                                                                            UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                            
                                                                                                                                                            // Try to create an instance
                                                                                                                                                            allocator.newInstance(String.class);
                                                                                                                                                            fail("Expected UnsupportedOperationException");
                                                                                                                                                        } catch (UnsupportedOperationException e) {
                                                                                                                                                            // Verify the exception message
                                                                                                                                                            assertEquals("Cannot allocate class java.lang.String", e.getMessage());
                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                            fail("Expected UnsupportedOperationException but got " + e.getClass());
                                                                                                                                                        }
                                                                                                                                                    }

    @Test(expected = IllegalArgumentException.class)
                                                                                                                                              public void testNewInstanceShouldNotAllowInterfaceInstantiation() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  // This should throw an exception since we're trying to instantiate an interface
                                                                                                                                                  // If the mutant is present (if(false)), this test will fail as it won't throw
                                                                                                                                                  allocator.newInstance(Runnable.class);
                                                                                                                                              }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                              public void testCreate_shouldThrowUnsupportedOperationExceptionWhenAllMethodsFail() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                  
                                                                                                                                                  // Act & Assert
                                                                                                                                                  // This will throw the exception we're testing for
                                                                                                                                                  allocator.newInstance(Object.class);
                                                                                                                                              }

    @Test
                                                                                                                                              public void testCreate_verifyExceptionMessage() throws Exception {
                                                                                                                                                  // Arrange
                                                                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                  Class<?> testClass = Object.class;
                                                                                                                                                  
                                                                                                                                                  try {
                                                                                                                                                      // Act
                                                                                                                                                      allocator.newInstance(testClass);
                                                                                                                                                      fail("Expected exception was not thrown");
                                                                                                                                                  } catch (UnsupportedOperationException e) {
                                                                                                                                                      // Assert
                                                                                                                                                      assertEquals("Cannot allocate " + testClass, e.getMessage());
                                                                                                                                                  }
                                                                                                                                              }

    @Test(expected = UnsupportedOperationException.class)
                                                                                                                                             public void testNewInstanceWithAbstractClassThrowsException() throws Exception {
                                                                                                                                                 // Arrange
                                                                                                                                                 UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                 
                                                                                                                                                 // Create an abstract class for testing
                                                                                                                                                 abstract class AbstractTestClass {}
                                                                                                                                                 
                                                                                                                                                 // Act & Assert
                                                                                                                                                 // This should throw UnsupportedOperationException
                                                                                                                                                 allocator.newInstance(AbstractTestClass.class);
                                                                                                                                             }

    @Test
                                                                                                                                             public void testNewInstanceWithAbstractClassExceptionMessage() throws Exception {
                                                                                                                                                 // Arrange
                                                                                                                                                 UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                                 
                                                                                                                                                 // Create an abstract class for testing
                                                                                                                                                 abstract class AbstractTestClass {}
                                                                                                                                                 Class<?> abstractClass = AbstractTestClass.class;
                                                                                                                                                 
                                                                                                                                                 try {
                                                                                                                                                     // Act
                                                                                                                                                     allocator.newInstance(abstractClass);
                                                                                                                                                     fail("Expected UnsupportedOperationException");
                                                                                                                                                 } catch (UnsupportedOperationException e) {
                                                                                                                                                     // Assert
                                                                                                                                                     String expectedMessage = "Cannot allocate " + abstractClass.getName();
                                                                                                                                                     assertEquals(expectedMessage, e.getMessage());
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                       public void testCreateWithAbstractClassShouldPass() throws Exception {
                                                                                                                                           // Define abstract test class inside the method
                                                                                                                                           abstract class TestAbstractClass {}
                                                                                                                                           
                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                           try {
                                                                                                                                               // Original should pass (only checks interface)
                                                                                                                                               // Mutant would fail here (checks abstract)
                                                                                                                                               Object instance = allocator.newInstance(TestAbstractClass.class);
                                                                                                                                               assertNotNull(instance);
                                                                                                                                           } catch (Exception e) {
                                                                                                                                               fail("Should not throw exception for abstract class in original implementation");
                                                                                                                                           }
                                                                                                                                       }

    @Test
                                                                                                                                       public void testCreateWithConcreteClassShouldPass() throws Exception {
                                                                                                                                           // Define a simple concrete class for testing
                                                                                                                                           class TestConcreteClass {
                                                                                                                                               public TestConcreteClass() {}
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                           Object instance = allocator.newInstance(TestConcreteClass.class);
                                                                                                                                           assertNotNull(instance);
                                                                                                                                       }

    @Test
                                                                                                                                   public void testCreateWithInterfaceShouldFail() throws Exception {
                                                                                                                                       // Use standard Runnable interface for testing instead of local interface
                                                                                                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                       try {
                                                                                                                                           allocator.newInstance(Runnable.class);
                                                                                                                                           fail("Should have thrown exception for interface");
                                                                                                                                       } catch (Exception expected) {
                                                                                                                                           // Expected behavior - original would fail here
                                                                                                                                           // Mutant might pass if it only checks for abstract
                                                                                                                                       }
                                                                                                                                   }

    @Test(expected = Exception.class)
                                                                                                                                   public void testNewInstanceWithNonInstantiableClass() throws Exception {
                                                                                                                                       // Arrange
                                                                                                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                       
                                                                                                                                       // Act & Assert - should throw from assertInstantiable
                                                                                                                                       // Using Runnable.class as a non-instantiable class (interface)
                                                                                                                                       allocator.newInstance(Runnable.class);
                                                                                                                                       
                                                                                                                                       // If we get here, the test fails because the mutation skipped the check
                                                                                                                                   }

    @Test
                                                                                                                                   public void testNewInstanceWithRegularClass() throws Exception {
                                                                                                                                       // Arrange
                                                                                                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                       
                                                                                                                                       // Act - should work for regular classes
                                                                                                                                       Object instance = allocator.newInstance(Object.class);
                                                                                                                                       
                                                                                                                                       // Assert
                                                                                                                                       assertNotNull(instance);
                                                                                                                                       assertEquals(Object.class, instance.getClass());
                                                                                                                                   }

    @Test
                                                                                                                             public void testCreate_PropagatesError() throws Exception {
                                                                                                                                 // Setup - mock Class.forName to throw an Error
                                                                                                                                 Class<?> mockClass = mock(Class.class);
                                                                                                                                 when(mockClass.getDeclaredField(anyString())).thenThrow(new LinkageError());
                                                                                                                                 
                                                                                                                                 // Replace the actual Class.forName with our mock
                                                                                                                                 try {
                                                                                                                                     // Use reflection to replace Class.forName behavior
                                                                                                                                     Field classField = ClassLoader.class.getDeclaredField("scl");
                                                                                                                                     classField.setAccessible(true);
                                                                                                                                     ClassLoader originalLoader = (ClassLoader) classField.get(null);
                                                                                                                                     
                                                                                                                                     ClassLoader mockLoader = mock(ClassLoader.class);
                                                                                                                                     when(mockLoader.loadClass(anyString())).thenAnswer(invocation -> mockClass);
                                                                                                                                     classField.set(null, mockLoader);
                                                                                                                             
                                                                                                                                     // Setup expected exception
                                                                                                                                     try {
                                                                                                                                         // Test
                                                                                                                                         UnsafeAllocator.create();
                                                                                                                                         fail("Expected LinkageError to be thrown");
                                                                                                                                     } catch (LinkageError expected) {
                                                                                                                                         // Expected exception
                                                                                                                                     }
                                                                                                                                 } finally {
                                                                                                                                     // Restore original Class.forName behavior
                                                                                                                                     Field classField = ClassLoader.class.getDeclaredField("scl");
                                                                                                                                     classField.setAccessible(true);
                                                                                                                                     ClassLoader originalLoader = (ClassLoader) classField.get(null);
                                                                                                                                     classField.set(null, originalLoader);
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                                             public void testCreate_shouldUseObjectStreamClassWhenUnsafeFails() throws Exception {
                                                                                                                                 // Setup - mock Class.forName to fail for sun.misc.Unsafe
                                                                                                                                 Class<?> originalClass = Class.class;
                                                                                                                                 try {
                                                                                                                                     Class<?> mockedClass = mock(Class.class);
                                                                                                                                     when(mockedClass.forName("sun.misc.Unsafe")).thenThrow(new ClassNotFoundException());
                                                                                                                                     
                                                                                                                                     // Replace Class.class temporarily for the test
                                                                                                                                     Field classClassField = Class.class.getDeclaredField("class");
                                                                                                                                     classClassField.setAccessible(true);
                                                                                                                                     classClassField.set(null, mockedClass);
                                                                                                                                     
                                                                                                                                     // Test
                                                                                                                                     UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                                                     
                                                                                                                                     // Verify we didn't get the fallback allocator by checking if it throws
                                                                                                                                     try {
                                                                                                                                         allocator.newInstance(Object.class);
                                                                                                                                         // If we get here, the allocator works (not fallback)
                                                                                                                                     } catch (UnsupportedOperationException e) {
                                                                                                                                         fail("Got fallback allocator when ObjectStreamClass path should have worked");
                                                                                                                                     }
                                                                                                                                 } finally {
                                                                                                                                     // Restore original Class.class
                                                                                                                                     Field classClassField = Class.class.getDeclaredField("class");
                                                                                                                                     classClassField.setAccessible(true);
                                                                                                                                     classClassField.set(null, originalClass);
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                       public void testCreate_ObjectStreamClassPath_ShouldWorkWhenAccessible() throws Exception {
                                                                                                           // Define the interface as a local class instead
                                                                                                           class ExceptionMessageGetterImpl {
                                                                                                               String get(UnsafeAllocator allocator) {
                                                                                                                   try {
                                                                                                                       allocator.newInstance(String.class);
                                                                                                                       return null;
                                                                                                                   } catch (Exception e) {
                                                                                                                       return e.getMessage();
                                                                                                                   }
                                                                                                               }
                                                                                                           }
                                                                                                           
                                                                                                           // Create instance of the local class
                                                                                                           ExceptionMessageGetterImpl getExceptionMessage = new ExceptionMessageGetterImpl();
                                                                                                       
                                                                                                           // Setup reflection mocks to test the ObjectStreamClass path
                                                                                                           Class<?> mockUnsafeClass = mock(Class.class);
                                                                                                           when(mockUnsafeClass.getDeclaredField(anyString())).thenThrow(new NoSuchFieldException());
                                                                                                           
                                                                                                           // Mock ObjectStreamClass path components
                                                                                                           Method mockGetConstructorId = mock(Method.class);
                                                                                                           Method mockNewInstance = mock(Method.class);
                                                                                                           
                                                                                                           // First test original behavior (should succeed)
                                                                                                           try {
                                                                                                               // Mock the ObjectStreamClass reflection calls
                                                                                                               when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                                                                   .thenReturn(mockGetConstructorId);
                                                                                                               when(ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class))
                                                                                                                   .thenReturn(mockNewInstance);
                                                                                                               when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(123);
                                                                                                               
                                                                                                               UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                               
                                                                                                               // Verify the allocator is created (not the fallback one)
                                                                                                               assertNotEquals("Should not be fallback allocator",
                                                                                                                   "Cannot allocate", 
                                                                                                                   getExceptionMessage.get(allocator));
                                                                                                           } catch (UnsupportedOperationException e) {
                                                                                                               fail("Original code should not reach fallback allocator");
                                                                                                           }
                                                                                                           
                                                                                                           // Now test mutant behavior (should fail)
                                                                                                           try {
                                                                                                               // Reset mocks
                                                                                                               reset(mockGetConstructorId, mockNewInstance);
                                                                                                               
                                                                                                               // Simulate mutant behavior where setAccessible wasn't called
                                                                                                               when(mockGetConstructorId.invoke(null, Object.class))
                                                                                                                   .thenThrow(new IllegalAccessException("Mutant behavior"));
                                                                                                               
                                                                                                               UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                               
                                                                                                               // With mutant, should fall through to next attempt or fallback
                                                                                                               try {
                                                                                                                   allocator.newInstance(String.class);
                                                                                                                   fail("Mutant should have caused fallback to be used");
                                                                                                               } catch (UnsupportedOperationException e) {
                                                                                                                   assertTrue("Should use fallback allocator",
                                                                                                                       e.getMessage().contains("Cannot allocate"));
                                                                                                               }
                                                                                                           } catch (Exception e) {
                                                                                                               fail("Test setup failed: " + e.getMessage());
                                                                                                           }
                                                                                                       }

    @Test
                                                                                          public void testCreateUsesCorrectConstructorId1() throws Exception {
                                                                                              // Helper method to set final static fields
                                                                                              java.lang.reflect.Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                              modifiersField.setAccessible(true);
                                                                                              
                                                                                              // Setup reflection mocks
                                                                                              Method mockGetConstructorId = mock(Method.class);
                                                                                              Method mockNewInstance = mock(Method.class);
                                                                                              
                                                                                              // Mock ObjectStreamClass methods
                                                                                              when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(42); // Any non-zero ID
                                                                                              when(mockNewInstance.invoke(null, any(Class.class), eq(42))).thenReturn(new Object());
                                                                                              
                                                                                              // Get original methods
                                                                                              Method originalGetConstructorId = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                                                                                              Method originalNewInstance = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class);
                                                                                              
                                                                                              // Replace real methods with mocks
                                                                                              try {
                                                                                                  // Force the test to use our mocked methods
                                                                                                  Field getConstructorIdField = ObjectStreamClass.class.getDeclaredField("getConstructorId");
                                                                                                  getConstructorIdField.setAccessible(true);
                                                                                                  modifiersField.setInt(getConstructorIdField, getConstructorIdField.getModifiers() & ~Modifier.FINAL);
                                                                                                  getConstructorIdField.set(null, mockGetConstructorId);
                                                                                                  
                                                                                                  Field newInstanceField = ObjectStreamClass.class.getDeclaredField("newInstance");
                                                                                                  newInstanceField.setAccessible(true);
                                                                                                  modifiersField.setInt(newInstanceField, newInstanceField.getModifiers() & ~Modifier.FINAL);
                                                                                                  newInstanceField.set(null, mockNewInstance);
                                                                                                  
                                                                                                  // Create allocator - this should use the second approach
                                                                                                  UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                                  
                                                                                                  // Test that allocation works with our class
                                                                                                  Object instance = allocator.newInstance(Object.class);
                                                                                                  assertNotNull(instance);
                                                                                                  
                                                                                                  // Verify the correct constructor ID (42) was used
                                                                                                  verify(mockNewInstance).invoke(null, Object.class, 42);
                                                                                              } finally {
                                                                                                  // Restore original methods
                                                                                                  Field getConstructorIdField = ObjectStreamClass.class.getDeclaredField("getConstructorId");
                                                                                                  getConstructorIdField.setAccessible(true);
                                                                                                  getConstructorIdField.set(null, originalGetConstructorId);
                                                                                                  
                                                                                                  Field newInstanceField = ObjectStreamClass.class.getDeclaredField("newInstance");
                                                                                                  newInstanceField.setAccessible(true);
                                                                                                  newInstanceField.set(null, originalNewInstance);
                                                                                              }
                                                                                          }

    @Test
                                                                                          public void testNewInstance_allowsInstantiableClass() throws Exception {
                                                                                              // Arrange
                                                                                              UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                              Class<Object> instantiableClass = Object.class;
                                                                                              
                                                                                              // Act
                                                                                              Object instance = allocator.newInstance(instantiableClass);
                                                                                              
                                                                                              // Assert - should successfully create instance
                                                                                              assertNotNull(instance);
                                                                                              assertEquals(instantiableClass, instance.getClass());
                                                                                          }

    @Test(expected = InstantiationException.class)
                                                                                 public void testNewInstance_checksInstantiable() throws Exception {
                                                                                     // Arrange
                                                                                     UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                     
                                                                                     // Use an existing non-instantiable interface (like Runnable)
                                                                                     Class<Runnable> nonInstantiableInterface = Runnable.class;
                                                                                     
                                                                                     // Act - should throw when trying to instantiate interface
                                                                                     // If the mutant is present, this would try to instantiate the interface
                                                                                     // instead of throwing from assertInstantiable
                                                                                     allocator.newInstance(nonInstantiableInterface);
                                                                                     
                                                                                     // Assert - handled by expected exception
                                                                                 }

    @Test
                                                                                 public void testCreateAllocatorUsesCorrectClassInObjectStreamPath() throws Exception {
                                                                                     // Arrange
                                                                                     UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                     Class<String> targetClass = String.class; // Using String as test class
                                                                                     
                                                                                     try {
                                                                                         // Act
                                                                                         Object instance = allocator.newInstance(targetClass);
                                                                                         
                                                                                         // Assert
                                                                                         assertNotNull("Instance should not be null", instance);
                                                                                         assertEquals("Created instance should be of requested type", 
                                                                                                      targetClass, instance.getClass());
                                                                                     } catch (UnsupportedOperationException e) {
                                                                                         // This is acceptable if the test environment doesn't support unsafe allocation
                                                                                         assertTrue("Expected either correct instance or UnsupportedOperationException", 
                                                                                                   e.getMessage().contains("Cannot allocate"));
                                                                                     }
                                                                                 }

    @Test
                                                                                public void testCreateUsesObjectStreamClassImplementationWhenAccessible() throws Exception {
                                                                                    // This test will fail if newInstance.setAccessible(true) is commented out
                                                                                    // because it won't be able to use the ObjectStreamClass implementation
                                                                                    
                                                                                    // Create a test class we'll try to instantiate
                                                                                    class TestClass {}
                                                                                    
                                                                                    // Get the allocator
                                                                                    UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                    
                                                                                    try {
                                                                                        // Try to create an instance
                                                                                        TestClass instance = allocator.newInstance(TestClass.class);
                                                                                        
                                                                                        // If we get here, it means one of the first three approaches worked
                                                                                        // We can't directly check which implementation was used,
                                                                                        // but we can verify it's not the fallback implementation by checking
                                                                                        // that no exception was thrown
                                                                                        
                                                                                        assertNotNull(instance);
                                                                                    } catch (UnsupportedOperationException e) {
                                                                                        // If we get the fallback implementation's exception, the test should fail
                                                                                        fail("Expected to get a working allocator, but got fallback implementation");
                                                                                    }
                                                                                }

    @Test(expected = UnsupportedOperationException.class)
                                                                                public void testCreateFallsBackWhenAllReflectionFails() throws Exception {
                                                                                    // This test verifies the fallback behavior when all reflection attempts fail
                                                                                    // In a controlled environment where we can't use reflection (like security manager),
                                                                                    // or when the mutation is present, this would be the expected behavior
                                                                                    
                                                                                    // Mock the system to make all reflection attempts fail
                                                                                    // (This is just for demonstration - in reality you'd need to set up security manager)
                                                                                    
                                                                                    // Get the allocator (in a real test, you'd need to ensure reflection fails)
                                                                                    UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                                    
                                                                                    // Try to create an instance - should throw UnsupportedOperationException
                                                                                    allocator.newInstance(Object.class);
                                                                                }

    @Test(expected = InstantiationException.class)
                                                                          public void testNewInstanceWithAbstractClassShouldFail() throws Exception {
                                                                              // Arrange
                                                                              UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                              
                                                                              // Define abstract class for testing
                                                                              abstract class AbstractClassForTesting {
                                                                                  // Abstract class with no implementation
                                                                              }
                                                                              
                                                                              // Act
                                                                              // Using an abstract class that should fail assertInstantiable
                                                                              allocator.newInstance(AbstractClassForTesting.class);
                                                                              
                                                                              // Assert - exception expected (handled by @Test annotation)
                                                                          }

    @Test
                                                                          public void testObjectInputStreamAllocation() throws Exception {
                                                                              // Setup - we need to make sure the test reaches the ObjectInputStream path
                                                                              // by making the previous approaches fail
                                                                              try {
                                                                                  // First approach will fail
                                                                                  Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
                                                                                  fail("Should not be able to access Unsafe");
                                                                              } catch (Exception expected) {
                                                                              }
                                                                      
                                                                              try {
                                                                                  // Second approach will fail
                                                                                  ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                                                                                  fail("Should not be able to access ObjectStreamClass methods");
                                                                              } catch (Exception expected) {
                                                                              }
                                                                      
                                                                              // Now we should be using ObjectInputStream approach
                                                                              UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                              
                                                                              // Test with a simple class
                                                                              class TestClass {}
                                                                              
                                                                              // The original code would work with Object.class as parameter
                                                                              // The mutant would pass null instead, which should fail
                                                                              TestClass instance = allocator.newInstance(TestClass.class);
                                                                              assertNotNull(instance);
                                                                              assertEquals(TestClass.class, instance.getClass());
                                                                          }

    @Test
                                                                         public void testCreateFallbackAllocatorThrowsCorrectException() {
                                                                             // Arrange
                                                                             // The create() method will fall back to the last case when all reflection attempts fail
                                                                             UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                             
                                                                             // Act & Assert
                                                                             try {
                                                                                 allocator.newInstance(Object.class);
                                                                                 fail("Expected exception to be thrown");
                                                                             } catch (Exception e) {
                                                                                 // Verify the exact exception type is UnsupportedOperationException
                                                                                 assertEquals("Should throw UnsupportedOperationException", 
                                                                                     UnsupportedOperationException.class, e.getClass());
                                                                                 // Verify the message contains the class name
                                                                                 assertTrue("Exception message should contain class name",
                                                                                     e.getMessage().contains("Cannot allocate"));
                                                                             }
                                                                         }

    @Test(expected = UnsupportedOperationException.class)
                                                                        public void testCreate_shouldNotAllowInterfaceInstantiation() throws Exception {
                                                                            // Arrange
                                                                            UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                            
                                                                            // Act
                                                                            // Using Runnable as a test interface
                                                                            allocator.newInstance(Runnable.class);
                                                                            
                                                                            // Assert - exception should be thrown (handled by test annotation)
                                                                        }

    @Test
                                                                        public void testCreate_shouldAllowConcreteClassInstantiation() throws Exception {
                                                                            // Arrange
                                                                            UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                            
                                                                            // Act & Assert
                                                                            // Using Object as a test concrete class
                                                                            // We can't actually verify the instance creation due to security restrictions,
                                                                            // but we can verify no exception is thrown for concrete classes
                                                                            try {
                                                                                Object instance = allocator.newInstance(Object.class);
                                                                                // If we get here, the test passes (no exception for concrete class)
                                                                            } catch (UnsupportedOperationException e) {
                                                                                fail("Should not throw exception for concrete classes");
                                                                            }
                                                                        }

    @Test
                                                                       public void testCreateWithAbstractClass() throws Exception {
                                                                           UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                           
                                                                           // Create an abstract class
                                                                           abstract class TestAbstractClass {}
                                                                           Class<?> abstractClass = TestAbstractClass.class;
                                                                           
                                                                           try {
                                                                               // This should pass in original but throw in mutant
                                                                               allocator.newInstance(abstractClass);
                                                                               
                                                                               // If we get here in mutant test, mutant is detected
                                                                           } catch (Exception e) {
                                                                               // Mutant behavior - unexpected for original
                                                                               assertTrue(e instanceof UnsupportedOperationException);
                                                                           }
                                                                       }

    @Test
                                                                  public void testCreateWithInterface() throws Exception {
                                                                      UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                      
                                                                      // Use an existing interface instead of declaring one inside the method
                                                                      Class<?> interfaceClass = Runnable.class;
                                                                      
                                                                      try {
                                                                          // This should throw in original but pass in mutant
                                                                          allocator.newInstance(interfaceClass);
                                                                          
                                                                          // If we get here in original test, mutant is detected
                                                                          fail("Expected exception not thrown for interface");
                                                                      } catch (Exception e) {
                                                                          // Original behavior - expected
                                                                          assertTrue(e instanceof UnsupportedOperationException);
                                                                      }
                                                                  }

    @Test(expected = Exception.class)
                                                                  public void testNewInstanceWithInterfaceShouldFailValidation() throws Exception {
                                                                      // Arrange
                                                                      UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                      
                                                                      // Act - try to create instance of an interface
                                                                      // This should throw from assertInstantiable in original code
                                                                      // Mutant would skip validation and try unsafe allocation
                                                                      allocator.newInstance(Cloneable.class);
                                                                      
                                                                      // Assert - handled by expected exception
                                                                  }

    @Test(expected = Exception.class)
                                                                  public void testNewInstanceWithAbstractClassShouldFailValidation() throws Exception {
                                                                      // Arrange
                                                                      UnsafeAllocator allocator = UnsafeAllocator.create();
                                                                      
                                                                      // Act - try to create instance of abstract class
                                                                      allocator.newInstance(Number.class);
                                                                      
                                                                      // Assert - handled by expected exception
                                                                  }

    @Test
                                                            public void testCreateDetectsAccessibleMutation() throws Exception {
                                                                // Mock the first attempt (sun.misc.Unsafe) to fail
                                                                mockStatic(Class.class);
                                                                when(Class.forName("sun.misc.Unsafe")).thenThrow(new ClassNotFoundException());
                                                            
                                                                // Mock ObjectStreamClass and its methods
                                                                mockStatic(ObjectStreamClass.class);
                                                                Method mockGetConstructorId = mock(Method.class);
                                                                when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                    .thenReturn(mockGetConstructorId);
                                                                
                                                                // This is where the mutation occurs - the setAccessible(true) is commented out
                                                                // So the invoke() should fail with IllegalAccessException
                                                                when(mockGetConstructorId.invoke(null, Object.class))
                                                                    .thenThrow(new IllegalAccessException());
                                                            
                                                                // Mock the third attempt (ObjectInputStream) to succeed
                                                                Method mockNewInstance = mock(Method.class);
                                                                when(ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class))
                                                                    .thenReturn(mockNewInstance);
                                                                when(mockNewInstance.invoke(null, any(Class.class), eq(Object.class)))
                                                                    .thenReturn(new Object());
                                                            
                                                                // Call the method under test
                                                                UnsafeAllocator allocator = UnsafeAllocator.create();
                                                            
                                                                // Verify behavior - should fall through to third approach
                                                                Object result = allocator.newInstance(Object.class);
                                                                assertNotNull(result);
                                                            
                                                                // Verify the reflection interactions
                                                                verify(ObjectStreamClass.class).getDeclaredMethod("getConstructorId", Class.class);
                                                            
                                                                // This verifies that the test would fail if setAccessible wasn't called
                                                                // (which is what the mutation does)
                                                                verify(mockGetConstructorId).setAccessible(true);
                                                            }

    @Test
                                                            public void testCreateUsesCorrectConstructorId2() throws Exception {
                                                                // Mock ObjectStreamClass methods
                                                                Method mockGetConstructorId = mock(Method.class);
                                                                Method mockNewInstance = mock(Method.class);
                                                                
                                                                // Setup mock behavior
                                                                when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(123); // Return non-zero ID
                                                                when(mockNewInstance.invoke(null, any(Class.class), eq(123))).thenReturn(new Object());
                                                                
                                                                // Replace the real methods with our mocks
                                                                try {
                                                                    // Create test class that will use our mocks
                                                                    Class<?> testClass = Class.forName("UnsafeAllocator");
                                                                    Method createMethod = testClass.getMethod("create");
                                                                    
                                                                    // Create the allocator instance
                                                                    Object allocator = createMethod.invoke(null);
                                                                    
                                                                    // Get the newInstance method
                                                                    Method newInstanceMethod = allocator.getClass().getMethod("newInstance", Class.class);
                                                                    
                                                                    // Test with a simple class
                                                                    Class<?> testObjectClass = Object.class;
                                                                    Object result = newInstanceMethod.invoke(allocator, testObjectClass);
                                                                    
                                                                    // Verify the result is not null (creation succeeded)
                                                                    assertNotNull(result);
                                                                    
                                                                    // Verify the mock was called with correct constructor ID (123)
                                                                    verify(mockNewInstance).invoke(null, testObjectClass, 123);
                                                                } catch (Exception e) {
                                                                    fail("Test failed with exception: " + e.getMessage());
                                                                }
                                                            }

    @Test(expected = Exception.class)
                                                           public void testNewInstance_shouldCheckInstantiable() throws Exception {
                                                               // Arrange
                                                               UnsafeAllocator allocator = UnsafeAllocator.create();
                                                               
                                                               // Act - try to create instance of an interface (non-instantiable)
                                                               // This should fail due to assertInstantiable check
                                                               allocator.newInstance(Cloneable.class);
                                                               
                                                               // If we get here, the test fails because the mutant didn't perform the check
                                                               // Original code would throw from assertInstantiable before reaching here
                                                               fail("Should have thrown exception from assertInstantiable");
                                                           }

    @Test
                                                          public void testCreateWithObjectStreamClassPath() throws Exception {
                                                              // Setup - we need to mock the reflection calls to force execution down the ObjectStreamClass path
                                                              // since we can't actually test sun.misc.Unsafe in most environments
                                                              
                                                              // Create a test class that we'll request to be instantiated
                                                              class TestClass {}
                                                              
                                                              // Get the allocator instance
                                                              UnsafeAllocator allocator = UnsafeAllocator.create();
                                                              
                                                              try {
                                                                  // Attempt to create an instance of our test class
                                                                  Object instance = allocator.newInstance(TestClass.class);
                                                                  
                                                                  // Verify the created instance is of the correct type
                                                                  // This will fail with the mutant since it would return an Object instead
                                                                  assertTrue("Created instance should be of requested type", 
                                                                            TestClass.class.isInstance(instance));
                                                                  
                                                                  // Additional verification that it's not just an Object
                                                                  assertNotEquals("Created instance should not be Object class", 
                                                                                Object.class, instance.getClass());
                                                              } catch (UnsupportedOperationException e) {
                                                                  // This might happen if none of the allocation strategies worked
                                                                  // In a real test, we'd need to mock the reflection calls to ensure we test the specific path
                                                                  // But for detecting this mutant, we can assume the test environment supports ObjectStreamClass path
                                                                  fail("Test environment doesn't support any of the allocation strategies");
                                                              }
                                                          }

    @Test
                                                         public void testCreateUsesObjectStreamClassWhenAvailable() throws Exception {
                                                             // Mock ObjectStreamClass and its methods
                                                             mockStatic(ObjectStreamClass.class);
                                                             
                                                             Method mockGetConstructorId = mock(Method.class);
                                                             Method mockNewInstance = mock(Method.class);
                                                             
                                                             // Setup mock behavior
                                                             when(ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class))
                                                                 .thenReturn(mockGetConstructorId);
                                                             when(ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, int.class))
                                                                 .thenReturn(mockNewInstance);
                                                             when(mockGetConstructorId.invoke(null, Object.class)).thenReturn(123);
                                                             
                                                             // Create test object
                                                             Object testObj = new Object();
                                                             when(mockNewInstance.invoke(null, String.class, 123)).thenReturn(testObj);
                                                             
                                                             // Call the method under test
                                                             UnsafeAllocator allocator = UnsafeAllocator.create();
                                                             Object result = allocator.newInstance(String.class);
                                                             
                                                             // Verify accessibility was set and method was called
                                                             verify(mockNewInstance).setAccessible(true);
                                                             assertEquals(testObj, result);
                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                   public void testNewInstanceWithNonInstantiableClass1() throws Exception {
                                                       // Create the allocator instance
                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                       
                                                       // Try to create instance of an interface (non-instantiable)
                                                       // This should throw an IllegalArgumentException
                                                       allocator.newInstance(java.io.Serializable.class);
                                                   }

    @Test(expected = UnsupportedOperationException.class)
                                                   public void testCreateFallbackAllocatorThrowsCorrectException1() throws Exception {
                                                       // This test forces the fallback allocator to be used by making all unsafe allocation attempts fail
                                                       // We can't directly mock the static methods called in create(), but we can verify the behavior
                                                       // of the fallback allocator which is what we're testing
                                                       
                                                       // Get the fallback allocator (will happen when all unsafe attempts fail)
                                                       UnsafeAllocator allocator = UnsafeAllocator.create();
                                                       
                                                       // Try to create an instance - should throw UnsupportedOperationException
                                                       // If it throws RuntimeException instead, the test will fail
                                                       allocator.newInstance(Object.class);
                                                   }

    @Test
                                              public void testCreateFallbackAllocatorExceptionMessage() {
                                                  try {
                                                      UnsafeAllocator allocator = UnsafeAllocator.create();
                                                      try {
                                                          allocator.newInstance(String.class);
                                                          fail("Expected exception to be thrown");
                                                      } catch (Exception e) {
                                                          if (e instanceof UnsupportedOperationException) {
                                                              // Verify the exception message is correct
                                                              assertEquals("Cannot allocate class java.lang.String", e.getMessage());
                                                          } else if (e instanceof RuntimeException) {
                                                              // This would catch the mutant case
                                                              fail("Expected UnsupportedOperationException but got RuntimeException");
                                                          } else {
                                                              fail("Unexpected exception type: " + e.getClass().getName());
                                                          }
                                                      }
                                                  } catch (RuntimeException e) {
                                                      fail("Unexpected exception during allocator creation: " + e.getMessage());
                                                  }
                                              }

    @Test(expected = IllegalArgumentException.class)
                             public void testNewInstanceWithInterfaceShouldThrowException() throws Exception {
                                 // Arrange
                                 UnsafeAllocator allocator = UnsafeAllocator.create();
                                 
                                 // Act & Assert
                                 allocator.newInstance(Runnable.class);
                             }

    @Test
    public void testCreate_assertInstantiableChecksForInterfaces() throws Exception {
        // Arrange
        java.io.Serializable serializable = null; // Just for type reference
        java.util.AbstractList<?> abstractList = null; // Just for type reference
        java.util.ArrayList<?> arrayList = null; // Just for type reference
        
        UnsafeAllocator allocator = UnsafeAllocator.create();
        
        // Use existing classes for test cases
        try {
            // Act & Assert for interface (should throw)
            allocator.newInstance(java.io.Serializable.class); // Using standard interface
            fail("Should have thrown for interface");
        } catch (Exception e) {
            // Expected
        }
        
        try {
            // Act & Assert for abstract class (should not throw in original)
            allocator.newInstance(java.util.AbstractList.class); // Using standard abstract class
            // If we get here, original behavior is correct
        } catch (Exception e) {
            fail("Should not throw for abstract class in original");
        }
        
        // Act & Assert for concrete class (should always work)
        java.util.ArrayList<?> instance = allocator.newInstance(java.util.ArrayList.class); // Using standard concrete class
        assertNotNull(instance);
    }


}
