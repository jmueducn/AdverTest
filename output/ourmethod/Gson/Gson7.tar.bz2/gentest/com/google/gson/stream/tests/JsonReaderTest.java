package gentest.com.google.gson.stream.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.stream.*;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.internal.bind.JsonTreeReader;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
 
public class JsonReaderTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                    public void testNextInt_PeekedNumber() throws Exception {
                                                                        // Create reader with test input
                                                                        java.io.Reader input = new java.io.StringReader("123");
                                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(input);
                                                                        
                                                                        // Use reflection to access private fields
                                                                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                                        peekedField.setAccessible(true);
                                                                        int PEEKED_NUMBER = peekedField.getInt(null); // Get static field value
                                                                        
                                                                        java.lang.reflect.Field bufferField = com.google.gson.stream.JsonReader.class.getDeclaredField("buffer");
                                                                        bufferField.setAccessible(true);
                                                                        bufferField.set(reader, "123".toCharArray());
                                                                        
                                                                        java.lang.reflect.Field posField = com.google.gson.stream.JsonReader.class.getDeclaredField("pos");
                                                                        posField.setAccessible(true);
                                                                        posField.set(reader, 0);
                                                                        
                                                                        java.lang.reflect.Field peekedNumberLengthField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedNumberLength");
                                                                        peekedNumberLengthField.setAccessible(true);
                                                                        peekedNumberLengthField.set(reader, 3);
                                                                        
                                                                        // Set peeked field to PEEKED_NUMBER
                                                                        peekedField.set(reader, PEEKED_NUMBER);
                                                                        
                                                                        int result = reader.nextInt();
                                                                        assertEquals(123, result);
                                                                        
                                                                        // Get PEEKED_NONE value for assertion
                                                                        int PEEKED_NONE = peekedField.getInt(null);
                                                                        assertEquals(PEEKED_NONE, peekedField.get(reader));
                                                                    }

    @Test
                                                                public void testNextInt_PeekedLong_InvalidPrecision() throws Exception {
                                                                    java.io.StringReader stringReader = new java.io.StringReader("");
                                                                    JsonReader reader = new JsonReader(stringReader);
                                                                    
                                                                    // Use reflection to access private fields
                                                                    Field peekedField = JsonReader.class.getDeclaredField("peeked");
                                                                    peekedField.setAccessible(true);
                                                                    
                                                                    Field peekedLongField = JsonReader.class.getDeclaredField("peekedLong");
                                                                    peekedLongField.setAccessible(true);
                                                                    
                                                                    // Get PEEKED_LONG constant value via reflection
                                                                    Field peekedLongConstant = JsonReader.class.getDeclaredField("PEEKED_LONG");
                                                                    peekedLongConstant.setAccessible(true);
                                                                    int PEEKED_LONG = peekedLongConstant.getInt(null);
                                                                    
                                                                    // Set the private fields
                                                                    peekedField.setInt(reader, PEEKED_LONG);
                                                                    peekedLongField.setLong(reader, Long.MAX_VALUE);
                                                                    
                                                                    try {
                                                                        reader.nextInt();
                                                                        fail("Expected NumberFormatException");
                                                                    } catch (NumberFormatException e) {
                                                                        assertEquals("Expected an int but was " + Long.MAX_VALUE, e.getMessage());
                                                                    }
                                                                }

    @Test
                                                            public void testNextLong_InvalidPeekedState() throws Exception {
                                                                // Setup expected exception rule
                                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                
                                                                java.io.StringReader stringReader = new java.io.StringReader("");
                                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                                
                                                                // Use reflection to access private fields
                                                                java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                                peekedField.setAccessible(true);
                                                                java.lang.reflect.Field peekedBeginObjectField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_BEGIN_OBJECT");
                                                                peekedBeginObjectField.setAccessible(true);
                                                                java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                                stackSizeField.setAccessible(true);
                                                                java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                                pathIndicesField.setAccessible(true);
                                                                
                                                                // Get the PEEKED_BEGIN_OBJECT value
                                                                int PEEKED_BEGIN_OBJECT = peekedBeginObjectField.getInt(null);  // Changed from reader to null for static field
                                                                
                                                                // Set values using reflection
                                                                peekedField.setInt(reader, PEEKED_BEGIN_OBJECT);
                                                                stackSizeField.setInt(reader, 1);
                                                                pathIndicesField.set(reader, new int[1]);
                                                                
                                                                thrown.expect(IllegalStateException.class);
                                                                thrown.expectMessage("Expected a long but was");
                                                                reader.nextLong();
                                                            }

    @Test
                                                            public void testNextInt_PeekedLong_ValidInt() throws Exception {
                                                                // Create a StringReader with empty content
                                                                java.io.StringReader stringReader = new java.io.StringReader("");
                                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                                
                                                                // Use reflection to access private fields and constants
                                                                Class<?> readerClass = com.google.gson.stream.JsonReader.class;
                                                                
                                                                // Get PEEKED_LONG constant value
                                                                Field peekedLongConstField = readerClass.getDeclaredField("PEEKED_LONG");
                                                                peekedLongConstField.setAccessible(true);
                                                                int PEEKED_LONG = peekedLongConstField.getInt(null);
                                                                
                                                                // Set peeked field
                                                                Field peekedField = readerClass.getDeclaredField("peeked");
                                                                peekedField.setAccessible(true);
                                                                peekedField.setInt(reader, PEEKED_LONG);
                                                                
                                                                // Set peekedLong field
                                                                Field peekedLongValueField = readerClass.getDeclaredField("peekedLong");
                                                                peekedLongValueField.setAccessible(true);
                                                                peekedLongValueField.setLong(reader, 42L);
                                                                
                                                                int result = reader.nextInt();
                                                                assertEquals(42, result);
                                                                
                                                                // Get PEEKED_NONE constant value
                                                                Field peekedNoneField = readerClass.getDeclaredField("PEEKED_NONE");
                                                                peekedNoneField.setAccessible(true);
                                                                int PEEKED_NONE = peekedNoneField.getInt(null);
                                                                
                                                                // Verify peeked was reset to PEEKED_NONE
                                                                assertEquals(PEEKED_NONE, peekedField.getInt(reader));
                                                            }

    @Test
                                                        public void testNextLong_MinLongValue() throws Exception {
                                                            // Create the reader with the min long value string
                                                            java.io.StringReader stringReader = new java.io.StringReader("-9223372036854775808");
                                                            com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                            
                                                            // Use reflection to access private fields
                                                            java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                            peekedField.setAccessible(true);
                                                            
                                                            // Access the PEEKED_UNQUOTED constant (it's likely a static field)
                                                            java.lang.reflect.Field peekedUnquotedField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_UNQUOTED");
                                                            peekedUnquotedField.setAccessible(true);
                                                            int PEEKED_UNQUOTED = peekedUnquotedField.getInt(null);
                                                            peekedField.set(reader, PEEKED_UNQUOTED);
                                                            
                                                            java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                            stackSizeField.setAccessible(true);
                                                            stackSizeField.set(reader, 1);
                                                            
                                                            java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                            pathIndicesField.setAccessible(true);
                                                            pathIndicesField.set(reader, new int[1]);
                                                            
                                                            long result = reader.nextLong();
                                                            assertEquals(Long.MIN_VALUE, result);
                                                        }

    @Test
                                                    public void testNextInt_EmptyString() throws Exception {
                                                        java.io.StringReader stringReader = new java.io.StringReader("");
                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                        
                                                        // Use reflection to set private peeked field
                                                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                        peekedField.setAccessible(true);
                                                        java.lang.reflect.Field peekedNoneField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NONE");
                                                        peekedNoneField.setAccessible(true);
                                                        int peekedNoneValue = peekedNoneField.getInt(null);
                                                        peekedField.setInt(reader, peekedNoneValue);
                                                        
                                                        // Set up expected exception
                                                        try {
                                                            reader.nextInt();
                                                            fail("Expected IllegalStateException");
                                                        } catch (IllegalStateException expected) {
                                                            // Expected exception
                                                        }
                                                    }

    @Test
                                                    public void testNextLong_MaxLongValue() throws Exception {
                                                        // Create the reader with max long value
                                                        java.io.StringReader stringReader = new java.io.StringReader("9223372036854775807");
                                                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                        
                                                        // Use reflection to access private fields
                                                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                        peekedField.setAccessible(true);
                                                        
                                                        // Get the PEEKED_UNQUOTED constant value
                                                        java.lang.reflect.Field peekedUnquotedField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_UNQUOTED");
                                                        peekedUnquotedField.setAccessible(true);
                                                        int PEEKED_UNQUOTED = peekedUnquotedField.getInt(null);
                                                        
                                                        peekedField.set(reader, PEEKED_UNQUOTED);
                                                        
                                                        java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                        stackSizeField.setAccessible(true);
                                                        stackSizeField.set(reader, 1);
                                                        
                                                        java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                        pathIndicesField.setAccessible(true);
                                                        pathIndicesField.set(reader, new int[1]);
                                                        
                                                        long result = reader.nextLong();
                                                        assertEquals(Long.MAX_VALUE, result);
                                                    }

    @Test
                                                public void testNextLong_EmptyString() throws Exception {
                                                    // Create a StringReader with empty content
                                                    java.io.StringReader stringReader = new java.io.StringReader("");
                                                    // Create JsonReader instance
                                                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                    
                                                    // Use reflection to access private fields
                                                    java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                                    peekedField.setAccessible(true);
                                                    java.lang.reflect.Field peekedNoneField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NONE");
                                                    peekedNoneField.setAccessible(true);
                                                    java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                                    stackSizeField.setAccessible(true);
                                                    java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                                    pathIndicesField.setAccessible(true);
                                                    
                                                    // Set values using reflection
                                                    int peekedNoneValue = peekedNoneField.getInt(null);
                                                    peekedField.setInt(reader, peekedNoneValue);
                                                    stackSizeField.setInt(reader, 1);
                                                    pathIndicesField.set(reader, new int[1]);
                                                    
                                                    // Set up expected exception
                                                    try {
                                                        reader.nextLong();
                                                        fail("Expected NumberFormatException");
                                                    } catch (NumberFormatException e) {
                                                        // Expected exception
                                                    }
                                                }

    @Test
                                            public void testNextLong_PrecisionLoss() throws Exception {
                                                // Create a StringReader with test data
                                                java.io.StringReader stringReader = new java.io.StringReader("12345.5");
                                                // Create JsonReader instance
                                                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                                                
                                                // Use reflection to set private fields
                                                Class<?> readerClass = com.google.gson.stream.JsonReader.class;
                                                
                                                Field peekedField = readerClass.getDeclaredField("peeked");
                                                peekedField.setAccessible(true);
                                                peekedField.setInt(reader, 5); // PEEKED_NUMBER is typically 5
                                                
                                                Field posField = readerClass.getDeclaredField("pos");
                                                posField.setAccessible(true);
                                                posField.setInt(reader, 0);
                                                
                                                Field peekedNumberLengthField = readerClass.getDeclaredField("peekedNumberLength");
                                                peekedNumberLengthField.setAccessible(true);
                                                peekedNumberLengthField.setInt(reader, 7);
                                                
                                                Field bufferField = readerClass.getDeclaredField("buffer");
                                                bufferField.setAccessible(true);
                                                bufferField.set(reader, "12345.5".toCharArray());
                                                
                                                Field stackSizeField = readerClass.getDeclaredField("stackSize");
                                                stackSizeField.setAccessible(true);
                                                stackSizeField.setInt(reader, 1);
                                                
                                                Field pathIndicesField = readerClass.getDeclaredField("pathIndices");
                                                pathIndicesField.setAccessible(true);
                                                pathIndicesField.set(reader, new int[1]);
                                                
                                                try {
                                                    reader.nextLong();
                                                    fail("Expected NumberFormatException");
                                                } catch (NumberFormatException expected) {
                                                    // Test passes
                                                }
                                            }

    @Test
                                public void testNextLong_PeekedLong() throws Exception {
                                    // Create JsonReader instance
                                    java.io.Reader in = new java.io.StringReader("12345");
                                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(in);
                                    
                                    // Set private fields using reflection
                                    java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                                    peekedField.setAccessible(true);
                                    java.lang.reflect.Field peekedLongField = com.google.gson.stream.JsonReader.class.getDeclaredField("peekedLong");
                                    peekedLongField.setAccessible(true);
                                    java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                                    stackSizeField.setAccessible(true);
                                    java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                                    pathIndicesField.setAccessible(true);
                                    
                                    // Get PEEKED_LONG and PEEKED_NONE constants via reflection
                                    java.lang.reflect.Field peekedLongConst = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_LONG");
                                    peekedLongConst.setAccessible(true);
                                    int PEEKED_LONG = peekedLongConst.getInt(null);
                                    java.lang.reflect.Field peekedNoneConst = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NONE");
                                    peekedNoneConst.setAccessible(true);
                                    int PEEKED_NONE = peekedNoneConst.getInt(null);
                                    
                                    // Set values
                                    peekedField.setInt(reader, PEEKED_LONG);
                                    peekedLongField.setLong(reader, 12345L);
                                    stackSizeField.setInt(reader, 1);
                                    pathIndicesField.set(reader, new int[1]);
                                    
                                    long result = reader.nextLong();
                                    org.junit.Assert.assertEquals(12345L, result);
                                    org.junit.Assert.assertEquals(PEEKED_NONE, peekedField.getInt(reader));
                                    org.junit.Assert.assertEquals(1, ((int[]) pathIndicesField.get(reader))[0]);
                                }

    @Test
                    public void testNextLong_InvalidNumberFormat() throws Exception {
                        // Create a JsonReader instance with a StringReader containing invalid number
                        java.io.Reader stringReader = new java.io.StringReader("invalid");
                        com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                        
                        // Define expected exception rule
                        org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                        expectedException.expect(java.lang.NumberFormatException.class);
                        
                        // Use reflection to access private fields
                        java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                        peekedField.setAccessible(true);
                        
                        // Access PEEKED_NONE which is a static field
                        java.lang.reflect.Field peekedNoneField = com.google.gson.stream.JsonReader.class.getDeclaredField("PEEKED_NONE");
                        peekedNoneField.setAccessible(true);
                        int peekedNoneValue = peekedNoneField.getInt(null);
                        
                        java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                        stackSizeField.setAccessible(true);
                        java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                        pathIndicesField.setAccessible(true);
                        
                        // Set values using reflection
                        peekedField.set(reader, peekedNoneValue);
                        stackSizeField.set(reader, 1);
                        pathIndicesField.set(reader, new int[1]);
                        
                        reader.nextLong();
                    }

    @Test
                public void testNextLong_PeekedDoubleValue() throws Exception {
                    // Define constants that would normally be in JsonReader
                    final int PEEKED_NUMBER = 5;
                    final int PEEKED_NONE = 0;
                    
                    // Create a JsonReader instance with a StringReader
                    java.io.Reader in = new java.io.StringReader("12345.0");
                    com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(in);
                    
                    // Use reflection to set private fields
                    Class<?> readerClass = com.google.gson.stream.JsonReader.class;
                    
                    java.lang.reflect.Field peekedField = readerClass.getDeclaredField("peeked");
                    peekedField.setAccessible(true);
                    peekedField.set(reader, PEEKED_NUMBER);
                    
                    java.lang.reflect.Field posField = readerClass.getDeclaredField("pos");
                    posField.setAccessible(true);
                    posField.set(reader, 0);
                    
                    java.lang.reflect.Field peekedNumberLengthField = readerClass.getDeclaredField("peekedNumberLength");
                    peekedNumberLengthField.setAccessible(true);
                    peekedNumberLengthField.set(reader, 7);
                    
                    java.lang.reflect.Field bufferField = readerClass.getDeclaredField("buffer");
                    bufferField.setAccessible(true);
                    bufferField.set(reader, "12345.0".toCharArray());
                    
                    java.lang.reflect.Field stackSizeField = readerClass.getDeclaredField("stackSize");
                    stackSizeField.setAccessible(true);
                    stackSizeField.set(reader, 1);
                    
                    java.lang.reflect.Field pathIndicesField = readerClass.getDeclaredField("pathIndices");
                    pathIndicesField.setAccessible(true);
                    pathIndicesField.set(reader, new int[1]);
                    
                    long result = reader.nextLong();
                    assertEquals(12345L, result);
                    
                    int peekedNoneValue = (int) peekedField.get(reader);
                    assertEquals(PEEKED_NONE, peekedNoneValue);
                    
                    int[] pathIndices = (int[]) pathIndicesField.get(reader);
                    assertEquals(1, pathIndices[0]);
                }

    @Test
            public void testNextLong_PeekedUnquoted() throws Exception {
                // Create a JsonReader with a mock input
                java.io.StringReader stringReader = new java.io.StringReader("12345");
                com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(stringReader);
                
                // Use reflection to set private fields
                java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
                peekedField.setAccessible(true);
                final int PEEKED_UNQUOTED = 8; // Define constant locally
                peekedField.set(reader, PEEKED_UNQUOTED);
                
                java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
                stackSizeField.setAccessible(true);
                stackSizeField.set(reader, 1);
                
                java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
                pathIndicesField.setAccessible(true);
                pathIndicesField.set(reader, new int[1]);
                
                java.lang.reflect.Field pathNamesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathNames");
                pathNamesField.setAccessible(true);
                pathNamesField.set(reader, new String[1]);
                
                // Also need to set the buffer with our test value
                java.lang.reflect.Field bufferField = com.google.gson.stream.JsonReader.class.getDeclaredField("buffer");
                bufferField.setAccessible(true);
                char[] buffer = new char[1024];
                System.arraycopy("12345".toCharArray(), 0, buffer, 0, 5);
                bufferField.set(reader, buffer);
                
                java.lang.reflect.Field posField = com.google.gson.stream.JsonReader.class.getDeclaredField("pos");
                posField.setAccessible(true);
                posField.set(reader, 0);
                
                java.lang.reflect.Field limitField = com.google.gson.stream.JsonReader.class.getDeclaredField("limit");
                limitField.setAccessible(true);
                limitField.set(reader, 5);
                
                long result = reader.nextLong();
                assertEquals(12345L, result);
                
                // Verify peeked was reset to PEEKED_NONE (typically 0)
                final int PEEKED_NONE = 0; // Define constant locally
                assertEquals(PEEKED_NONE, peekedField.get(reader));
                
                // Verify pathIndices was updated
                int[] pathIndices = (int[]) pathIndicesField.get(reader);
                assertEquals(1, pathIndices[0]);
            }

    @Test
        public void testNextLong_PeekedDoubleQuoted() throws Exception {
            // Create a JsonReader with a mock Reader
            java.io.Reader mockReader = new java.io.StringReader("\"12345\"");
            com.google.gson.stream.JsonReader reader = new com.google.gson.stream.JsonReader(mockReader);
            
            // Use reflection to access private fields
            java.lang.reflect.Field peekedField = com.google.gson.stream.JsonReader.class.getDeclaredField("peeked");
            peekedField.setAccessible(true);
            // PEEKED_DOUBLE_QUOTED is 9
            peekedField.set(reader, 9);
            
            java.lang.reflect.Field stackSizeField = com.google.gson.stream.JsonReader.class.getDeclaredField("stackSize");
            stackSizeField.setAccessible(true);
            stackSizeField.set(reader, 1);
            
            java.lang.reflect.Field pathIndicesField = com.google.gson.stream.JsonReader.class.getDeclaredField("pathIndices");
            pathIndicesField.setAccessible(true);
            int[] pathIndices = new int[1];
            pathIndicesField.set(reader, pathIndices);
            
            long result = reader.nextLong();
            assertEquals(12345L, result);
            
            // PEEKED_NONE is 0
            assertEquals(0, peekedField.get(reader));
            assertEquals(1, pathIndices[0]);
        }

    @Test
    public void testNextInt_PeekedSingleQuoted() throws Exception {
        // Create a JsonReader with a StringReader containing the test data
        
        // Use reflection to access private fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        // Get PEEKED_SINGLE_QUOTED constant value
        Field peekedSingleQuotedField = JsonReader.class.getDeclaredField("PEEKED_SINGLE_QUOTED");
        peekedSingleQuotedField.setAccessible(true);
        int PEEKED_SINGLE_QUOTED = peekedSingleQuotedField.getInt(null);
        
        // Get PEEKED_NONE constant value
        Field peekedNoneField = JsonReader.class.getDeclaredField("PEEKED_NONE");
        peekedNoneField.setAccessible(true);
        int PEEKED_NONE = peekedNoneField.getInt(null);
        
        // Set peeked value
        
        // Test nextInt()
    }

    @Test
    public void testNextInt_PeekedDoubleQuoted() throws Exception {
        // Create a JsonReader with a StringReader containing the test data
        
        // Use reflection to access private fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        // Get PEEKED_DOUBLE_QUOTED constant value
        Field peekedDoubleQuotedField = JsonReader.class.getDeclaredField("PEEKED_DOUBLE_QUOTED");
        peekedDoubleQuotedField.setAccessible(true);
        int PEEKED_DOUBLE_QUOTED = peekedDoubleQuotedField.getInt(null);
        
        // Get PEEKED_NONE constant value
        Field peekedNoneField = JsonReader.class.getDeclaredField("PEEKED_NONE");
        peekedNoneField.setAccessible(true);
        int PEEKED_NONE = peekedNoneField.getInt(null);
        
        // Set the peeked value
        
        // Test nextInt()
    }

    @Test
    public void testNextInt_PeekedUnquoted() throws Exception {
        // Create a JsonReader with test input
        
        // Get private fields using reflection
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        // Get static fields
        Field peekedUnquotedField = JsonReader.class.getDeclaredField("PEEKED_UNQUOTED");
        peekedUnquotedField.setAccessible(true);
        int PEEKED_UNQUOTED = peekedUnquotedField.getInt(null);
        
        Field peekedNoneField = JsonReader.class.getDeclaredField("PEEKED_NONE");
        peekedNoneField.setAccessible(true);
        int PEEKED_NONE = peekedNoneField.getInt(null);
        
        // Set peeked value
        
    }

    @Test
    public void testNextInt_PeekedUnquoted_InvalidNumber() throws Exception {
        // Create a JsonReader with a StringReader containing invalid number content
        
        // Use reflection to access private fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        Field peekedUnquotedField = JsonReader.class.getDeclaredField("PEEKED_UNQUOTED");
        peekedUnquotedField.setAccessible(true);
        
        // Get the PEEKED_UNQUOTED constant value
        int peekedUnquotedValue = peekedUnquotedField.getInt(null);
        // Set the peeked field to PEEKED_UNQUOTED
        
        // Set up exception expectation
        try {
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected exception
        }
    }

    @Test
    public void testNextInt_PeekedDouble_ValidInt() throws Exception {
        // Create a JsonReader with a StringReader containing empty content
        
        // Get private fields using reflection
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        Field peekedStringField = JsonReader.class.getDeclaredField("peekedString");
        peekedStringField.setAccessible(true);
        
        // Get private constants using reflection
        Field peekedNumberField = JsonReader.class.getDeclaredField("PEEKED_NUMBER");
        peekedNumberField.setAccessible(true);
        int PEEKED_NUMBER = peekedNumberField.getInt(null);
        
        Field peekedBufferedField = JsonReader.class.getDeclaredField("PEEKED_BUFFERED");
        peekedBufferedField.setAccessible(true);
        int PEEKED_BUFFERED = peekedBufferedField.getInt(null);
        
        Field peekedNoneField = JsonReader.class.getDeclaredField("PEEKED_NONE");
        peekedNoneField.setAccessible(true);
        int PEEKED_NONE = peekedNoneField.getInt(null);
        
        // Set values using reflection
        
    }

    @Test
    public void testNextInt_PeekedDouble_InvalidPrecision() throws Exception {
        // Create a JsonReader instance
        
        // Use reflection to access private fields and constants
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        Field peekedStringField = JsonReader.class.getDeclaredField("peekedString");
        peekedStringField.setAccessible(true);
        
        // Get the PEEKED_NUMBER and PEEKED_BUFFERED constants
        Field peekedNumberField = JsonReader.class.getDeclaredField("PEEKED_NUMBER");
        peekedNumberField.setAccessible(true);
        int PEEKED_NUMBER = peekedNumberField.getInt(null);
        
        Field peekedBufferedField = JsonReader.class.getDeclaredField("PEEKED_BUFFERED");
        peekedBufferedField.setAccessible(true);
        int PEEKED_BUFFERED = peekedBufferedField.getInt(null);
        
        // Set the peeked values
        
        // Set up expected exception
        try {
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            assertEquals("Expected an int but was 123.5", e.getMessage());
        }
    }

    @Test
    public void testNextInt_InvalidPeekedState() throws Exception {
        // Create a JsonReader instance with a StringReader
        
        // Use reflection to access private fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        Field peekedTrueField = JsonReader.class.getDeclaredField("PEEKED_TRUE");
        peekedTrueField.setAccessible(true);
        int PEEKED_TRUE = peekedTrueField.getInt(null);  // Changed to null as PEEKED_TRUE is static
        
        // Set the peeked state to PEEKED_TRUE
        
        // Define expected exception rule
        ExpectedException thrown = ExpectedException.none();
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage("Expected an int but was");
        
        // Trigger the exception
    }

    @Test
    public void testNextInt_NegativeNumber() throws Exception {
        // Create a JsonReader with test data containing a negative number
        String json = "-42";
        
        // Use reflection to set the peeked state
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        // Get the PEEKED_NUMBER constant value
        // In Gson's JsonReader, PEEKED_NUMBER is directly in JsonReader class
        Field peekedNumberField = JsonReader.class.getDeclaredField("PEEKED_NUMBER");
        peekedNumberField.setAccessible(true);
        int PEEKED_NUMBER = peekedNumberField.getInt(null);
        
        // Set the peeked value
        
    }

    @Test
    public void testNextInt_MaxValue() throws Exception {
        // Create a JsonReader with a mock Reader containing the max integer value
        
        // Use reflection to access private fields
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        // Get the PEEKED_UNQUOTED constant value
        Field peekedUnquotedField = JsonReader.class.getDeclaredField("PEEKED_NUMBER");
        peekedUnquotedField.setAccessible(true);
        int PEEKED_NUMBER = peekedUnquotedField.getInt(null); // static field, use null
        
        // Set the peeked field to PEEKED_NUMBER since we're testing a number
        
    }

    @Test
    public void testNextInt_MinValue() throws Exception {
        // Create a JsonReader with a StringReader containing the minimum integer value
        
        // Use reflection to set peeked field and access PEEKED_UNQUOTED constant
        try {
            Field peekedField = JsonReader.class.getDeclaredField("peeked");
            peekedField.setAccessible(true);
            
            Field peekedUnquotedField = JsonReader.class.getDeclaredField("PEEKED_UNQUOTED");
            peekedUnquotedField.setAccessible(true);
            int peekedUnquotedValue = peekedUnquotedField.getInt(null);
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to set up test using reflection", e);
        }
        
    }

    @Test
    public void testNextLong_PeekedNumber() throws Exception {
        // Create a JsonReader instance
        
        // Use reflection to set private fields
        Class<?> readerClass = JsonReader.class;
        
        Field peekedField = readerClass.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        Field peekedNumberField = readerClass.getDeclaredField("PEEKED_NUMBER");
        peekedNumberField.setAccessible(true);
        int peekedNumberValue = peekedNumberField.getInt(null);
        
        Field posField = readerClass.getDeclaredField("pos");
        posField.setAccessible(true);
        
        Field peekedNumberLengthField = readerClass.getDeclaredField("peekedNumberLength");
        peekedNumberLengthField.setAccessible(true);
        
        Field bufferField = readerClass.getDeclaredField("buffer");
        bufferField.setAccessible(true);
        char[] buffer = "12345".toCharArray();
        
        Field stackSizeField = readerClass.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        
        Field pathIndicesField = readerClass.getDeclaredField("pathIndices");
        pathIndicesField.setAccessible(true);
        int[] pathIndicesArray = new int[1];
        
        
        Field peekedNoneField = readerClass.getDeclaredField("PEEKED_NONE");
        peekedNoneField.setAccessible(true);
        int peekedNoneValue = peekedNoneField.getInt(null);
        
    }

    @Test
    public void testNextLong_PeekedSingleQuoted() throws Exception {
        // Create a JsonReader with a StringReader containing the test data
        
        // Use reflection to access private fields and constants
        Field peekedField = JsonReader.class.getDeclaredField("peeked");
        peekedField.setAccessible(true);
        
        Field peekedSingleQuotedField = JsonReader.class.getDeclaredField("PEEKED_SINGLE_QUOTED");
        peekedSingleQuotedField.setAccessible(true);
        int PEEKED_SINGLE_QUOTED = peekedSingleQuotedField.getInt(null);
        
        Field peekedNoneField = JsonReader.class.getDeclaredField("PEEKED_NONE");
        peekedNoneField.setAccessible(true);
        int PEEKED_NONE = peekedNoneField.getInt(null);
        
        Field stackSizeField = JsonReader.class.getDeclaredField("stackSize");
        stackSizeField.setAccessible(true);
        
        Field pathIndicesField = JsonReader.class.getDeclaredField("pathIndices");
        pathIndicesField.setAccessible(true);
        
        // Set the private fields
        
    }


}
