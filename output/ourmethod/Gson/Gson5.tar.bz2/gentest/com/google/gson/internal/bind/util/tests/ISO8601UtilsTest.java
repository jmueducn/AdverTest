package gentest.com.google.gson.internal.bind.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.util.*;
import java.text.ParseException;
import java.text.ParsePosition;
 
public class ISO8601UtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                                 public void testParse_DateOnly() throws Exception {
                                                                                     String dateStr = "2023-05-15";
                                                                                     java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                                                                     java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                                                                     
                                                                                     // Verify date components
                                                                                     assertEquals(2023 - 1900, result.getYear()); // Date year is 1900-based
                                                                                     assertEquals(4, result.getMonth()); // Month is 0-based (May = 4)
                                                                                     assertEquals(15, result.getDate());
                                                                                     
                                                                                     // Verify time components are set to 0
                                                                                     assertEquals(0, result.getHours());
                                                                                     assertEquals(0, result.getMinutes());
                                                                                     assertEquals(0, result.getSeconds());
                                                                                     
                                                                                     // Verify position is updated
                                                                                     assertEquals(dateStr.length(), pos.getIndex());
                                                                                 }

 @Test
                                                                                 public void testParse_MissingTimezone_ThrowsParseException() throws Exception {
                                                                                     String dateStr = "2023-05-15T14:30:45"; // No timezone
                                                                                     ParsePosition pos = new ParsePosition(0);
                                                                                     
                                                                                     try {
                                                                                         ISO8601Utils.parse(dateStr, pos);
                                                                                         fail("Expected ParseException to be thrown");
                                                                                     } catch (java.text.ParseException e) {
                                                                                         assertTrue(e.getMessage().contains("No time zone indicator"));
                                                                                     }
                                                                                 }

 @Test
                                                                                 public void testParse_EmptyString_ThrowsParseException() throws Exception {
                                                                                     String dateStr = "";
                                                                                     ParsePosition pos = new ParsePosition(0);
                                                                                     
                                                                                     ExpectedException exceptionRule = ExpectedException.none();
                                                                                     exceptionRule.expect(java.text.ParseException.class);
                                                                                     exceptionRule.expectMessage("Failed to parse date");
                                                                                     
                                                                                     ISO8601Utils.parse(dateStr, pos);
                                                                                 }

 @Test(expected = ParseException.class)
                                                                             public void testParse_InvalidDate_ThrowsParseException() throws Exception {
                                                                                 String dateStr = "2023-13-15"; // Invalid month
                                                                                 ParsePosition pos = new ParsePosition(0);
                                                                                 
                                                                                 ISO8601Utils.parse(dateStr, pos);
                                                                             }

 @Test(expected = ParseException.class)
                                                                             public void testParse_InvalidTimezone_ThrowsParseException() throws Exception {
                                                                                 String dateStr = "2023-05-15T14:30:45X"; // Invalid timezone indicator
                                                                                 ParsePosition pos = new ParsePosition(0);
                                                                                 
                                                                                 ISO8601Utils.parse(dateStr, pos);
                                                                             }

 @Test
                                         public void testParse_DateTime() throws Exception {
                                             String dateStr = "2023-05-15T14:30:45";
                                             java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                             java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                             
                                             // Convert to Calendar for more reliable date component checks
                                             java.util.Calendar calendar = java.util.Calendar.getInstance();
                                             calendar.setTime(result);
                                             
                                             // Verify date and time components
                                             org.junit.Assert.assertEquals(2023, calendar.get(java.util.Calendar.YEAR));
                                             org.junit.Assert.assertEquals(java.util.Calendar.MAY, calendar.get(java.util.Calendar.MONTH));
                                             org.junit.Assert.assertEquals(15, calendar.get(java.util.Calendar.DAY_OF_MONTH));
                                             org.junit.Assert.assertEquals(14, calendar.get(java.util.Calendar.HOUR_OF_DAY));
                                             org.junit.Assert.assertEquals(30, calendar.get(java.util.Calendar.MINUTE));
                                             org.junit.Assert.assertEquals(45, calendar.get(java.util.Calendar.SECOND));
                                             
                                             // Verify position is updated
                                             org.junit.Assert.assertEquals(dateStr.length(), pos.getIndex());
                                         }

 @Test
                                         public void testParse_DateTimeWithMillis() throws Exception {
                                             String dateStr = "2023-05-15T14:30:45.123";
                                             ParsePosition pos = new ParsePosition(0);
                                             
                                             // Verify milliseconds (note: Date.getTime() returns milliseconds since epoch)
                                             
                                             // Verify position is updated
                                             assertEquals(dateStr.length(), pos.getIndex());
                                         }

 @Test
                                         public void testParse_WithUTCTimezone() throws Exception {
                                             String dateStr = "2023-05-15T14:30:45Z";
                                             java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                             java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                             
                                             // Verify timezone is handled (UTC)
                                             java.util.TimeZone utcTimeZone = java.util.TimeZone.getTimeZone("UTC");
                                             java.time.ZoneId utcZoneId = java.time.ZoneId.of("UTC");
                                             assertEquals(utcTimeZone, result.toInstant().atZone(utcZoneId).getZone());
                                             assertEquals(dateStr.length(), pos.getIndex());
                                         }

 @Test
                                         public void testParse_WithPositiveTimezoneOffset() throws Exception {
                                             String dateStr = "2023-05-15T14:30:45+05:00";
                                             ParsePosition pos = new ParsePosition(0);
                                             
                                             // Verify timezone offset is handled
                                             // Note: The actual time value should be adjusted for the timezone
                                             assertEquals(dateStr.length(), pos.getIndex());
                                         }

 @Test
                                         public void testParse_WithNegativeTimezoneOffset() throws Exception {
                                             String dateStr = "2023-05-15T14:30:45-03:00";
                                             ParsePosition pos = new ParsePosition(0);
                                             
                                             // Verify timezone offset is handled
                                             assertEquals(dateStr.length(), pos.getIndex());
                                         }

 @Test
                                         public void testParse_LeapSecondsHandling() throws Exception {
                                             String dateStr = "2023-05-15T23:59:60"; // Leap second
                                             java.text.ParsePosition pos = new java.text.ParsePosition(0);
                                             java.util.Date result = com.google.gson.internal.bind.util.ISO8601Utils.parse(dateStr, pos);
                                             
                                             // Convert Date to Calendar to get seconds
                                             java.util.Calendar calendar = java.util.Calendar.getInstance();
                                             calendar.setTime(result);
                                             
                                             // Verify leap second is converted to 59
                                             assertEquals(59, calendar.get(java.util.Calendar.SECOND));
                                         }

 @Test
                                         public void testParse_ShortTimezoneOffset() throws Exception {
                                             String dateStr = "2023-05-15T14:30:45+05"; // Short timezone offset
                                             ParsePosition pos = new ParsePosition(0);
                                             
                                             // Verify short offset is expanded to +0500
                                             assertEquals(dateStr.length() + 2, pos.getIndex());
                                         }

 @Test(expected = ParseException.class)
 public void testParseWithTimezoneOffsetShouldDetectMutant() throws ParseException {
     // Setup
     String dateStr = "2023-05-15T12:30:45+05:00"; // Date with timezone offset
     ParsePosition pos = new ParsePosition(0);
     
     // Exercise
     try {
         ISO8601Utils.parse(dateStr, pos);
     } catch (ParseException e) {
         // Verify the exception is caused by the mutant
         assertTrue(e.getCause() instanceof IndexOutOfBoundsException);
         throw e;
     }
     
     // If we get here, the test fails as the mutant wasn't caught
     fail("Expected ParseException due to timezone parsing failure");
 }

}
