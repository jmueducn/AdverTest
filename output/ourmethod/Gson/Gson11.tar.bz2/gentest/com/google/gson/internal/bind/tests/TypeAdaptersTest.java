package gentest.com.google.gson.internal.bind.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import com.google.gson.internal.bind.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
 
public class TypeAdaptersTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WhenTokenIsNull_ReturnsNull() throws Exception {
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapter = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                              // Implementation not needed for this test
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                              if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                                                                                                  in.nextNull();
                                                                                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                              return in.nextString();
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      String result = typeAdapter.read(in);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertNull(result);
                                                                                                                                                                                                                                                                                      verify(in).nextNull();
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WhenValidString_ReturnsMappedConstant() throws Exception {
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                              throw new UnsupportedOperationException();
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                              String value = in.nextString();
                                                                                                                                                                                                                                                                                              if ("VALUE1".equals(value)) {
                                                                                                                                                                                                                                                                                                  return "CONSTANT1";
                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                              return null;
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                                                      when(in.nextString()).thenReturn("VALUE1");
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      String result = typeAdapters.read(in);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertEquals("CONSTANT1", result);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WhenStringNotInMap_ReturnsNull() throws Exception {
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public String read(JsonReader reader) throws IOException {
                                                                                                                                                                                                                                                                                              return null; // Simulate returning null for unknown values
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public void write(JsonWriter writer, String value) throws IOException {
                                                                                                                                                                                                                                                                                              // Not needed for this test
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                                                      when(in.nextString()).thenReturn("UNKNOWN_VALUE");
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      String result = typeAdapters.read(in);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertNull(result);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WhenEmptyString_ReturnsNull() throws Exception {
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                              if (in.peek() == JsonToken.STRING && in.nextString().isEmpty()) {
                                                                                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                                                              return "";
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                              // Not needed for this test
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                                                      when(in.nextString()).thenReturn("");
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      String result = typeAdapters.read(in);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertNull(result);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WhenIOExceptionOccurs_ThrowsRuntimeException() throws Exception {
                                                                                                                                                                                                                                                                                      // Create mock JsonReader
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                                                      when(in.nextString()).thenThrow(new java.io.IOException("Test exception"));
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Create TypeAdapter instance (assuming it's a String TypeAdapter for this test)
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                              return in.nextString();
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                              out.value(value);
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Setup expected exception
                                                                                                                                                                                                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                                                      thrown.expect(RuntimeException.class);
                                                                                                                                                                                                                                                                                      thrown.expectMessage("Test exception");
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Execute test
                                                                                                                                                                                                                                                                                      typeAdapters.read(in);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WhenUnexpectedToken_ThrowsRuntimeException() throws Exception {
                                                                                                                                                                                                                                                                                      // Setup mock JsonReader
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.BEGIN_ARRAY);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Create instance of TypeAdapter (assuming it's a String TypeAdapter)
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapters = TypeAdapters.STRING;
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Setup expected exception
                                                                                                                                                                                                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                                                                      thrown.expect(RuntimeException.class);
                                                                                                                                                                                                                                                                                      thrown.expectMessage("Expected STRING or NULL");
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      typeAdapters.read(in);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                                  public void testRead_WithDifferentCaseString_ReturnsNullWhenCaseSensitive() throws Exception {
                                                                                                                                                                                                                                                                                      // Create mock JsonReader
                                                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Create TypeAdapter instance (assuming it's a String TypeAdapter)
                                                                                                                                                                                                                                                                                      TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                              // Implementation that returns null for case-sensitive mismatch
                                                                                                                                                                                                                                                                                              return null;
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                                                          public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                              // Not needed for this test
                                                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      // Set up mock behavior
                                                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                                                      when(in.nextString()).thenReturn("value1"); // lowercase version
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      String result = typeAdapters.read(in);
                                                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                                                      assertNull(result);
                                                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                                                         public void testReadWithNullValue() throws Exception {
                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Create a TypeAdapter instance using the factory method
                                                                                                                                                                                                                                                                             TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                                                                                         in.nextNull();
                                                                                                                                                                                                                                                                                         return null;
                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                     return "dummy";
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                 public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                     // Not needed for this test
                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Execute
                                                                                                                                                                                                                                                                             String result = adapter.read(mockReader);
                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                             assertNull(result);
                                                                                                                                                                                                                                                                             verify(mockReader).peek();
                                                                                                                                                                                                                                                                             verify(mockReader).nextNull();
                                                                                                                                                                                                                                                                             verifyNoMoreInteractions(mockReader);
                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                    public void testReadWithNullValue1() throws Exception {
                                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                                                                                        TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                                            public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                                                throw new UnsupportedOperationException();
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                                                            public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                                if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                                                                                    in.nextNull();
                                                                                                                                                                                                                                                                                    return null;
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                throw new UnsupportedOperationException();
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                        };
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        when(mockReader.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                                        String result = adapter.read(mockReader);
                                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                                        assertNull(result);
                                                                                                                                                                                                                                                                        verify(mockReader).peek();
                                                                                                                                                                                                                                                                        verify(mockReader).nextNull();  // This will fail if mutant uses skipValue()
                                                                                                                                                                                                                                                                        verifyNoMoreInteractions(mockReader);
                                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                               public void testReadReturnsCorrectLazilyParsedNumber() throws IOException {
                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                   JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                                   when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                                   when(in.nextString()).thenReturn("123.45");
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Create an anonymous TypeAdapter implementation
                                                                                                                                                                                                                                                                   TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                                       public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                                           if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                                                                               in.nextNull();
                                                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                           return new LazilyParsedNumber(in.nextString());
                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                                       public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                                                                                                           // Not needed for this test
                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                   };
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Execute
                                                                                                                                                                                                                                                                   Object result = adapter.read(in);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                                                                                   assertTrue(result instanceof LazilyParsedNumber);
                                                                                                                                                                                                                                                                   assertEquals("123.45", result.toString()); // This will fail with the mutant which returns "0"
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Verify interactions
                                                                                                                                                                                                                                                                   verify(in).peek();
                                                                                                                                                                                                                                                                   verify(in).nextString();
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                  public void testRead_ReturnsLazilyParsedNumberWhenStringNotInMap() throws IOException {
                                                                                                                                                                                                                                                      // Arrange
                                                                                                                                                                                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                      when(in.nextString()).thenReturn("unknown_value");
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                                                                                                                                      nameToConstant.put("known_value", new Object());
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create a TypeAdapter that implements the desired behavior
                                                                                                                                                                                                                                                      TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                          public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                              String value = in.nextString();
                                                                                                                                                                                                                                                              if (!nameToConstant.containsKey(value)) {
                                                                                                                                                                                                                                                                  return new LazilyParsedNumber(value);
                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                              return nameToConstant.get(value);
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                          public void write(JsonWriter out, Object value) {
                                                                                                                                                                                                                                                              throw new UnsupportedOperationException();
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Act
                                                                                                                                                                                                                                                      Object result = adapter.read(in);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Assert
                                                                                                                                                                                                                                                      assertNotNull("Should return LazilyParsedNumber for unknown string values", result);
                                                                                                                                                                                                                                                      assertEquals("Returned object should be LazilyParsedNumber", 
                                                                                                                                                                                                                                                                  LazilyParsedNumber.class, result.getClass());
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                             public void testReadReturnsCorrectNumberWithoutAppendingZero() throws IOException {
                                                                                                                                                                                                                                                 // Setup
                                                                                                                                                                                                                                                 JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                                 when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                                 when(in.nextString()).thenReturn("123.45");
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Create a TypeAdapter that just returns the string value
                                                                                                                                                                                                                                                 TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                     public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                                         return in.nextString();
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                     public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                                         out.value(value);
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Execute
                                                                                                                                                                                                                                                 String result = adapter.read(in);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                 assertEquals("123.45", result);
                                                                                                                                                                                                                                                 // If mutant exists, result would be "123.450" which would fail this assertion
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                         public void testReadReturnsCorrectNumberWithoutAppendingZero1() throws IOException, NoSuchFieldException, IllegalAccessException, InstantiationException {
                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                             JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                                             when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                                             when(in.nextString()).thenReturn("123.45");
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Mock the nameToConstant map to return a known number
                                                                                                                                                                                                                                             Map<String, Object> mockMap = new HashMap<>();
                                                                                                                                                                                                                                             mockMap.put("123.45", new BigDecimal("123.45"));
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create a TypeAdapter for BigDecimal using reflection
                                                                                                                                                                                                                                             TypeAdapter<BigDecimal> adapter = TypeAdapters.BIG_DECIMAL;
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Use reflection to set the private nameToConstant field if needed
                                                                                                                                                                                                                                             // (This part might not be needed since we're using the actual BIG_DECIMAL adapter)
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Execute
                                                                                                                                                                                                                                             BigDecimal result = adapter.read(in);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                             assertEquals(new BigDecimal("123.45"), result);
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                public void testRead_InvalidToken_ThrowsExceptionWithDetailedMessage() throws IOException {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                                                    TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                            JsonToken token = in.peek();
                                                                                                                                                                                                                                            if (token != JsonToken.NUMBER) {
                                                                                                                                                                                                                                                throw new JsonSyntaxException("Expecting number, got: " + token);
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                                                                            // Not needed for this test
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    JsonToken invalidToken = JsonToken.BEGIN_ARRAY;
                                                                                                                                                                                                                                    when(mockReader.peek()).thenReturn(invalidToken);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                        adapter.read(mockReader);
                                                                                                                                                                                                                                        fail("Expected JsonSyntaxException to be thrown");
                                                                                                                                                                                                                                    } catch (JsonSyntaxException e) {
                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                        assertTrue("Exception message should contain the token information",
                                                                                                                                                                                                                                                  e.getMessage().contains("Expecting number, got: "));
                                                                                                                                                                                                                                        assertTrue("Exception message should contain the actual token",
                                                                                                                                                                                                                                                  e.getMessage().contains(invalidToken.toString()));
                                                                                                                                                                                                                                        throw e;
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                           public void testRead_NonStringToken_ShouldThrowException() throws Exception {
                                                                                                                                                                                                                               // Arrange
                                                                                                                                                                                                                               JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                               when(in.peek()).thenReturn(JsonToken.NUMBER); // Not NULL or STRING
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create a TypeAdapter instance (since TypeAdapters is abstract/utility class)
                                                                                                                                                                                                                               TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                   public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                       JsonToken token = in.peek();
                                                                                                                                                                                                                                       if (token != JsonToken.STRING && token != JsonToken.NULL) {
                                                                                                                                                                                                                                           throw new JsonSyntaxException("Expecting string, got: " + token);
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       return in.nextString();
                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                           
                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                   public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                                       out.value(value);
                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                               };
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Expect exception
                                                                                                                                                                                                                               thrown.expect(JsonSyntaxException.class);
                                                                                                                                                                                                                               thrown.expectMessage("Expecting string, got: NUMBER");
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Act
                                                                                                                                                                                                                               adapter.read(in);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Assert - exception should be thrown (test fails if mutant returns null)
                                                                                                                                                                                                                           }

    @Test(expected = JsonSyntaxException.class)
                                                                                                                                                                                                                      public void testRead_ShouldThrowExceptionWhenNumberTokenReceived() throws IOException {
                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                          JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                                          TypeAdapter<Object> typeAdapters = new TypeAdapter<Object>() {
                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                              public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                  if (in.peek() == JsonToken.NUMBER) {
                                                                                                                                                                                                                                      throw new JsonSyntaxException("Numbers not allowed");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                              public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                                                                  // Not needed for this test
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          };
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          when(mockReader.peek()).thenReturn(JsonToken.NUMBER);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Act - should throw JsonSyntaxException
                                                                                                                                                                                                                          typeAdapters.read(mockReader);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testRead_ShouldNotReturnLazilyParsedNumberWhenNumberTokenReceived() throws IOException {
                                                                                                                                                                                                                          // Arrange
                                                                                                                                                                                                                          JsonReader mockReader = mock(JsonReader.class);
                                                                                                                                                                                                                          TypeAdapter<Object> typeAdapters = new TypeAdapter<Object>() {
                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                              public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                  if (in.peek() == JsonToken.NUMBER) {
                                                                                                                                                                                                                                      throw new JsonSyntaxException("Expecting number");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                              public void write(JsonWriter out, Object value) {
                                                                                                                                                                                                                                  // Not needed for this test
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          };
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          when(mockReader.peek()).thenReturn(JsonToken.NUMBER);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              // Act
                                                                                                                                                                                                                              typeAdapters.read(mockReader);
                                                                                                                                                                                                                              fail("Expected JsonSyntaxException to be thrown");
                                                                                                                                                                                                                          } catch (JsonSyntaxException e) {
                                                                                                                                                                                                                              // Assert - Verify exception message
                                                                                                                                                                                                                              assertTrue(e.getMessage().contains("Expecting number"));
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Additional assertion to explicitly check we don't get LazilyParsedNumber
                                                                                                                                                                                                                          // This would catch the mutant directly
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              typeAdapters.read(mockReader);
                                                                                                                                                                                                                          } catch (JsonSyntaxException e) {
                                                                                                                                                                                                                              // This is expected
                                                                                                                                                                                                                              assertNotEquals(LazilyParsedNumber.class, e.getClass());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                                                 public void testReadWithNullInput_mutantDetection() throws IOException {
                                                                                                                                                                                                                     // Arrange
                                                                                                                                                                                                                     JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                     when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // This is where the mutant differs - original would call nextNull() here
                                                                                                                                                                                                                     // Mutant calls beginObject() which would throw IllegalStateException
                                                                                                                                                                                                                     doThrow(new IllegalStateException("Expected BEGIN_OBJECT but was NULL"))
                                                                                                                                                                                                                         .when(in).beginObject();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create a TypeAdapter instance using one of the factory methods
                                                                                                                                                                                                                     TypeAdapter<Object> adapter = TypeAdapters.newFactory(
                                                                                                                                                                                                                         new TypeToken<Object>() {}, 
                                                                                                                                                                                                                         new TypeAdapter<Object>() {
                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                             public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                                 return null;
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                             public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                     ).create(null, null);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Act - should throw due to mutant's beginObject() call
                                                                                                                                                                                                                     adapter.read(in);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                            public void testReadPreservesStringCase() throws IOException {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                String testString = "MixedCaseString";
                                                                                                                                                                                                                when(in.nextString()).thenReturn(testString);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create an anonymous implementation of TypeAdapter<String> since TypeAdapters is abstract
                                                                                                                                                                                                                TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                    public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                        if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                            in.nextNull();
                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        return in.nextString();
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                    public void write(JsonWriter out, String value) {
                                                                                                                                                                                                                        // Not needed for this test
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                };
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                String result = adapter.read(in);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                assertEquals(testString, result); // Verify the string case is preserved
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                            public void testReadPreservesStringCase1() throws IOException {
                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                                when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                                                                                String testString = "MixedCaseString";
                                                                                                                                                                                                                when(in.nextString()).thenReturn(testString);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Mock the nameToConstant map to return our test object
                                                                                                                                                                                                                Map<String, Object> mockMap = new HashMap<>();
                                                                                                                                                                                                                Object expectedResult = new Object();
                                                                                                                                                                                                                mockMap.put(testString, expectedResult);
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Create anonymous TypeAdapter implementation
                                                                                                                                                                                                                TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                                                                                                    private final Map<String, Object> nameToConstant = mockMap;
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                    public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                                        if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                            in.nextNull();
                                                                                                                                                                                                                            return null;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        return nameToConstant.get(in.nextString());
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                    public void write(JsonWriter out, Object value) {}
                                                                                                                                                                                                                };
                                                                                                                                                                                                                
                                                                                                                                                                                                                // Execute and verify
                                                                                                                                                                                                                Object result = adapter.read(in);
                                                                                                                                                                                                                assertSame(expectedResult, result); // Would fail if string was lowercased
                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                       public void testMutantBehaviorWithNullToken() throws IOException {
                                                                                                                                                                                                           // This test simulates what would happen with the mutant
                                                                                                                                                                                                           JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                           when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                           when(in.nextString()).thenThrow(new JsonSyntaxException("Expected string but was NULL"));
                                                                                                                                                                                                           
                                                                                                                                                                                                           // Create a TypeAdapter for testing - using String as the type
                                                                                                                                                                                                           TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                                   return in.nextString();
                                                                                                                                                                                                               }
                                                                                                                                                                                                               
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                                   out.value(value);
                                                                                                                                                                                                               }
                                                                                                                                                                                                           };
                                                                                                                                                                                                           
                                                                                                                                                                                                           // This will throw JsonSyntaxException with the mutant
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               adapter.read(in);
                                                                                                                                                                                                               fail("Expected JsonSyntaxException to be thrown");
                                                                                                                                                                                                           } catch (JsonSyntaxException expected) {
                                                                                                                                                                                                               assertEquals("Expected string but was NULL", expected.getMessage());
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                   public void testReadWithNullToken() throws IOException {
                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                       JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                                       when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create a TypeAdapter instance (using String as an example)
                                                                                                                                                                                                       TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                                                                                                           @Override
                                                                                                                                                                                                           public void write(JsonWriter out, String value) throws IOException {
                                                                                                                                                                                                               out.value(value);
                                                                                                                                                                                                           }
                                                                                                                                                                                                   
                                                                                                                                                                                                           @Override
                                                                                                                                                                                                           public String read(JsonReader in) throws IOException {
                                                                                                                                                                                                               if (in.peek() == JsonToken.NULL) {
                                                                                                                                                                                                                   in.nextNull();
                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                               }
                                                                                                                                                                                                               return in.nextString();
                                                                                                                                                                                                           }
                                                                                                                                                                                                       };
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Test - should return null for null token
                                                                                                                                                                                                       String result = adapter.read(in);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify
                                                                                                                                                                                                       assertNull(result);
                                                                                                                                                                                                       verify(in).peek();
                                                                                                                                                                                                       verify(in).nextNull();
                                                                                                                                                                                                       verifyNoMoreInteractions(in);
                                                                                                                                                                                                   }

    @Test(expected = IllegalStateException.class)
                                                                                                                                                                                          public void testReadWithNonNullValueWhenNullExpected() throws IOException {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              JsonReader in = mock(JsonReader.class);
                                                                                                                                                                                              when(in.peek()).thenReturn(JsonToken.STRING); // Simulate non-null value
                                                                                                                                                                                              when(in.nextString()).thenReturn("someValue");
                                                                                                                                                                                              
                                                                                                                                                                                              // Create a TypeAdapter using one of the factory methods
                                                                                                                                                                                              TypeAdapter<Object> adapter = TypeAdapters.newFactory(
                                                                                                                                                                                                  TypeToken.get(Object.class),
                                                                                                                                                                                                  new TypeAdapter<Object>() {
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public Object read(JsonReader in) throws IOException {
                                                                                                                                                                                                          in.nextNull(); // This will throw IllegalStateException for non-null value
                                                                                                                                                                                                          return null; // This line won't be reached
                                                                                                                                                                                                      }
                                                                                                                                                                                                      
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                                                                                          out.nullValue();
                                                                                                                                                                                                      }
                                                                                                                                                                                                  }
                                                                                                                                                                                              ).create(null, TypeToken.get(Object.class));
                                                                                                                                                                                              
                                                                                                                                                                                              // This should throw IllegalStateException because nextNull() expects null
                                                                                                                                                                                              adapter.read(in);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify the parser interaction
                                                                                                                                                                                              verify(in).peek();
                                                                                                                                                                                          }

    @Test
                                                                                                                                                 public void testReadReturnsCorrectLazilyParsedNumber1() throws IOException {
                                                                                                                                                     // Setup
                                                                                                                                                     JsonReader in = mock(JsonReader.class);
                                                                                                                                                     when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                                     String testString = "123.45";
                                                                                                                                                     when(in.nextString()).thenReturn(testString);
                                                                                                                                                     
                                                                                                                                                     // Create a TypeAdapter that returns LazilyParsedNumber
                                                                                                                                                     TypeAdapter<Number> numberAdapter = new TypeAdapter<Number>() {
                                                                                                                                                         @Override
                                                                                                                                                         public Number read(JsonReader reader) throws IOException {
                                                                                                                                                             return new LazilyParsedNumber(reader.nextString());
                                                                                                                                                         }
                                                                                                                                                         
                                                                                                                                                         @Override
                                                                                                                                                         public void write(JsonWriter out, Number value) {
                                                                                                                                                             throw new UnsupportedOperationException();
                                                                                                                                                         }
                                                                                                                                                     };
                                                                                                                                                     
                                                                                                                                                     // Execute
                                                                                                                                                     Number result = numberAdapter.read(in);
                                                                                                                                                     
                                                                                                                                                     // Verify
                                                                                                                                                     assertNotNull(result);
                                                                                                                                                     assertTrue(result instanceof LazilyParsedNumber);
                                                                                                                                                     assertEquals(testString, result.toString());
                                                                                                                                                 }

    @Test
                                                                                                                                public void testReadWithNumberString_ShouldReturnLazilyParsedNumber() throws IOException {
                                                                                                                                    // Arrange
                                                                                                                                    JsonReader in = mock(JsonReader.class);
                                                                                                                                    when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                                    when(in.nextString()).thenReturn("123.45");
                                                                                                                                    
                                                                                                                                    // Create a test TypeAdapter that mimics the behavior we want to test
                                                                                                                                    TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                                                                        private final Map<String, Object> nameToConstant = new HashMap<>();
                                                                                                                                        {
                                                                                                                                            nameToConstant.put("123.45", new Object()); // dummy value
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public Object read(JsonReader in) throws IOException {
                                                                                                                                            String value = in.nextString();
                                                                                                                                            if (nameToConstant.containsKey(value)) {
                                                                                                                                                return new LazilyParsedNumber(value);
                                                                                                                                            }
                                                                                                                                            return null;
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        @Override
                                                                                                                                        public void write(JsonWriter out, Object value) throws IOException {
                                                                                                                                            throw new UnsupportedOperationException();
                                                                                                                                        }
                                                                                                                                    };
                                                                                                                                    
                                                                                                                                    // Act
                                                                                                                                    Object result = adapter.read(in);
                                                                                                                                    
                                                                                                                                    // Assert
                                                                                                                                    assertNotNull("Should not return null for non-null string input", result);
                                                                                                                                    assertEquals("Should return LazilyParsedNumber for number string", 
                                                                                                                                        LazilyParsedNumber.class, result.getClass());
                                                                                                                                    assertEquals("Parsed number should match input", 
                                                                                                                                        "123.45", ((LazilyParsedNumber)result).toString());
                                                                                                                                }

    @Test
                                                                                                                       public void testRead_StringValue_ReturnsCorrectLazilyParsedNumber() throws Exception {
                                                                                                                           // Arrange
                                                                                                                           JsonReader in = mock(JsonReader.class);
                                                                                                                           when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                                                           when(in.nextString()).thenReturn("123");
                                                                                                                           
                                                                                                                           // Create a TypeAdapter that converts strings to LazilyParsedNumber
                                                                                                                           TypeAdapter<Number> adapter = new TypeAdapter<Number>() {
                                                                                                                               @Override
                                                                                                                               public Number read(JsonReader in) throws IOException {
                                                                                                                                   if (in.peek() == JsonToken.NULL) {
                                                                                                                                       in.nextNull();
                                                                                                                                       return null;
                                                                                                                                   }
                                                                                                                                   return new LazilyParsedNumber(in.nextString());
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public void write(JsonWriter out, Number value) throws IOException {
                                                                                                                                   // Not needed for this test
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Act
                                                                                                                           Number result = adapter.read(in);
                                                                                                                           
                                                                                                                           // Assert
                                                                                                                           assertTrue(result instanceof LazilyParsedNumber);
                                                                                                                           LazilyParsedNumber number = (LazilyParsedNumber) result;
                                                                                                                           assertEquals("123", number.toString());
                                                                                                                           assertEquals(123, number.intValue());
                                                                                                                       }

    @Test
                                                                                                              public void testRead_InvalidToken_ThrowsExceptionWithDescriptiveMessage() throws IOException {
                                                                                                                  // Arrange
                                                                                                                  JsonReader in = mock(JsonReader.class);
                                                                                                                  when(in.peek()).thenReturn(JsonToken.NUMBER); // Not NULL
                                                                                                                  when(in.nextString()).thenThrow(new IllegalStateException("Expected string but got NUMBER"));
                                                                                                                  
                                                                                                                  // Create a concrete TypeAdapter for testing
                                                                                                                  TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                                      @Override
                                                                                                                      public String read(JsonReader in) throws IOException {
                                                                                                                          if (in.peek() == JsonToken.NULL) {
                                                                                                                              in.nextNull();
                                                                                                                              return null;
                                                                                                                          }
                                                                                                                          return in.nextString();
                                                                                                                      }
                                                                                                                      
                                                                                                                      @Override
                                                                                                                      public void write(JsonWriter out, String value) throws IOException {
                                                                                                                          // Not needed for this test
                                                                                                                      }
                                                                                                                  };
                                                                                                                  
                                                                                                                  // Set expected exception with message
                                                                                                                  ExpectedException expectedException = ExpectedException.none();
                                                                                                                  expectedException.expect(JsonSyntaxException.class);
                                                                                                                  expectedException.expectMessage("Expected string but got NUMBER");
                                                                                                                  
                                                                                                                  // Act
                                                                                                                  adapter.read(in);
                                                                                                              }

    @Test
                                                                                                         public void testReadShouldThrowExceptionForNonStringToken() throws Exception {
                                                                                                             // Arrange
                                                                                                             JsonReader mockReader = mock(JsonReader.class);
                                                                                                             TypeAdapter<String> typeAdapters = new TypeAdapter<String>() {
                                                                                                                 @Override
                                                                                                                 public String read(JsonReader in) throws IOException {
                                                                                                                     if (in.peek() != JsonToken.STRING && in.peek() != JsonToken.NULL) {
                                                                                                                         throw new JsonSyntaxException("Expecting string, got: " + in.peek());
                                                                                                                     }
                                                                                                                     return in.nextString();
                                                                                                                 }
                                                                                                         
                                                                                                                 @Override
                                                                                                                 public void write(JsonWriter out, String value) throws IOException {
                                                                                                                     out.value(value);
                                                                                                                 }
                                                                                                             };
                                                                                                             
                                                                                                             when(mockReader.peek()).thenReturn(JsonToken.NUMBER); // Not NULL and not STRING
                                                                                                             
                                                                                                             // Expect exception for original behavior
                                                                                                             thrown.expect(JsonSyntaxException.class);
                                                                                                             thrown.expectMessage("Expecting string, got: NUMBER");
                                                                                                             
                                                                                                             // Act
                                                                                                             typeAdapters.read(mockReader);
                                                                                                             
                                                                                                             // Assert - exception should be thrown (test will fail if mutant returns null)
                                                                                                         }

    @Test
                                                                                                    public void testRead_ThrowsExceptionOnNumberToken() throws Exception {
                                                                                                        // Setup
                                                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                                                        when(mockReader.peek()).thenReturn(JsonToken.NUMBER);
                                                                                                        when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected a string but was NUMBER"));
                                                                                                        
                                                                                                        // Create a TypeAdapter for String (since we're testing string parsing)
                                                                                                        TypeAdapter<String> adapter = new TypeAdapter<String>() {
                                                                                                            @Override
                                                                                                            public String read(JsonReader in) throws IOException {
                                                                                                                return in.nextString();
                                                                                                            }
                                                                                                            
                                                                                                            @Override
                                                                                                            public void write(JsonWriter out, String value) throws IOException {
                                                                                                                out.value(value);
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Expect exception
                                                                                                        thrown.expect(JsonSyntaxException.class);
                                                                                                        thrown.expectMessage("Expecting string, got: NUMBER");
                                                                                                        
                                                                                                        // Execute
                                                                                                        adapter.read(mockReader);
                                                                                                        
                                                                                                        // Verification
                                                                                                        verify(mockReader).peek();
                                                                                                    }

    @Test
                                                                                               public void testReadWithNullInput() throws IOException {
                                                                                                   // Setup
                                                                                                   JsonReader in = mock(JsonReader.class);
                                                                                                   when(in.peek()).thenReturn(JsonToken.NULL);
                                                                                                   
                                                                                                   // Create a TypeAdapter for Object type using newFactory
                                                                                                   TypeAdapter<Object> adapter = TypeAdapters.newFactory(Object.class, new TypeAdapter<Object>() {
                                                                                                       @Override
                                                                                                       public Object read(JsonReader in) throws IOException {
                                                                                                           return null; // This won't be called in this test
                                                                                                       }
                                                                                                       
                                                                                                       @Override
                                                                                                       public void write(JsonWriter out, Object value) throws IOException {
                                                                                                           // Not needed for this test
                                                                                                       }
                                                                                                   }).create(null, TypeToken.get(Object.class));
                                                                                                   
                                                                                                   // Test
                                                                                                   Object result = adapter.read(in);
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertNull("Should return null for null input", result);
                                                                                                   verify(in).nextNull(); // This will fail if mutant is present (would try to call beginObject instead)
                                                                                                   verify(in, never()).nextString(); // Should never try to read string
                                                                                                   verify(in, never()).beginObject(); // Should never try to begin object
                                                                                               }

    @Test
                                                                                  public void testReadPreservesCaseSensitivity() throws IOException {
                                                                                      // Setup
                                                                                      JsonReader in = mock(JsonReader.class);
                                                                                      when(in.peek()).thenReturn(JsonToken.STRING);
                                                                                      String testString = "MixedCaseValue";
                                                                                      when(in.nextString()).thenReturn(testString);
                                                                                      
                                                                                      // Create a case-sensitive map
                                                                                      Map<String, Object> nameToConstant = new HashMap<>();
                                                                                      Object expectedValue = new Object();
                                                                                      nameToConstant.put(testString, expectedValue);
                                                                                      
                                                                                      // Create instance under test using reflection
                                                                                      try {
                                                                                          // Get the constructor and make it accessible
                                                                                          Constructor<TypeAdapters> constructor = TypeAdapters.class.getDeclaredConstructor();
                                                                                          constructor.setAccessible(true);
                                                                                          TypeAdapters adapter = constructor.newInstance();
                                                                                          
                                                                                          // Set the private field
                                                                                          Field field = TypeAdapters.class.getDeclaredField("nameToConstant");
                                                                                          field.setAccessible(true);
                                                                                          field.set(adapter, nameToConstant);
                                                                                          
                                                                                          // Get the read method using reflection
                                                                                          Method readMethod = TypeAdapters.class.getDeclaredMethod("read", JsonReader.class);
                                                                                          readMethod.setAccessible(true);
                                                                                          
                                                                                          // Test
                                                                                          Object result = readMethod.invoke(adapter, in);
                                                                                          
                                                                                          // Verify
                                                                                          assertEquals(expectedValue, result);
                                                                                          verify(in).nextString(); // Verify original string was used, not lowercase version
                                                                                          
                                                                                          // Additional test with different case that should NOT match
                                                                                          when(in.nextString()).thenReturn(testString.toLowerCase());
                                                                                          assertNull(readMethod.invoke(adapter, in)); // Should return null since case doesn't match
                                                                                      } catch (Exception e) {
                                                                                          fail("Failed to create TypeAdapters instance or set field: " + e.getMessage());
                                                                                      }
                                                                                  }

    @Test
                                                                         public void testReadWithNullToken1() throws IOException {
                                                                             // Setup
                                                                             JsonReader in = mock(JsonReader.class);
                                                                             when(in.peek()).thenReturn(JsonToken.NULL);
                                                                             
                                                                             // Create a TypeAdapter instance for testing
                                                                             TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                                 @Override
                                                                                 public void write(JsonWriter out, Object value) throws IOException {
                                                                                     throw new UnsupportedOperationException();
                                                                                 }
                                                                         
                                                                                 @Override
                                                                                 public Object read(JsonReader in) throws IOException {
                                                                                     if (in.peek() == JsonToken.NULL) {
                                                                                         in.nextNull();
                                                                                         return null;
                                                                                     }
                                                                                     return in.nextString();
                                                                                 }
                                                                             };
                                                                             
                                                                             // Test
                                                                             Object result = adapter.read(in);
                                                                             
                                                                             // Verify
                                                                             assertNull("Should return null for NULL token", result);
                                                                             verify(in).nextNull(); // Verify proper null consumption
                                                                             verify(in, never()).nextString(); // Verify no string reading attempted
                                                                         }

    @Test
                                                                    public void testReadWithInvalidNullValueThrowsException() throws Exception {
                                                                        // Arrange
                                                                        JsonReader mockReader = mock(JsonReader.class);
                                                                        TypeAdapter<String> adapter = TypeAdapters.STRING;
                                                                        
                                                                        when(mockReader.peek()).thenReturn(JsonToken.STRING); // Non-null token
                                                                        when(mockReader.nextString()).thenReturn("some string");
                                                                        
                                                                        // The original code would throw IllegalStateException when nextNull() is called on non-null
                                                                        thrown.expect(IllegalStateException.class);
                                                                        
                                                                        // Act
                                                                        adapter.read(mockReader);
                                                                        
                                                                        // Assert - exception should be thrown before reaching these verifications
                                                                        verify(mockReader).peek();
                                                                        verify(mockReader, never()).nextString();
                                                                    }

    @Test
                                                           public void testReadReturnsCorrectLazilyParsedNumber2() throws IOException {
                                                               // Setup
                                                               JsonReader in = mock(JsonReader.class);
                                                               when(in.peek()).thenReturn(JsonToken.STRING);
                                                               String testString = "123.45";
                                                               when(in.nextString()).thenReturn(testString);
                                                               
                                                               // Create anonymous TypeAdapter implementation
                                                               TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                                   @Override
                                                                   public Object read(JsonReader in) {
                                                                       try {
                                                                           if (in.peek() == JsonToken.NULL) {
                                                                               in.nextNull();
                                                                               return null;
                                                                           }
                                                                           return new LazilyParsedNumber(in.nextString());
                                                                       } catch (IOException e) {
                                                                           throw new RuntimeException(e);
                                                                       }
                                                                   }
                                                                   
                                                                   @Override
                                                                   public void write(JsonWriter out, Object value) {
                                                                       throw new UnsupportedOperationException();
                                                                   }
                                                               };
                                                               
                                                               // Execute
                                                               Object result = adapter.read(in);
                                                               
                                                               // Verify
                                                               assertNotNull(result);
                                                               assertTrue(result instanceof LazilyParsedNumber);
                                                               assertEquals(testString, result.toString());
                                                           }

    @Test
                                              public void testRead_NonNullString_ReturnsValueFromMap() throws Exception {
                                                  // Arrange
                                                  JsonReader in = mock(JsonReader.class);
                                                  when(in.peek()).thenReturn(JsonToken.STRING);
                                                  String testString = "testValue";
                                                  when(in.nextString()).thenReturn(testString);
                                                  
                                                  // Create a real map for testing
                                                  Map<String, Object> testMap = new HashMap<>();
                                                  Object expectedValue = new Object(); // any non-null object
                                                  testMap.put(testString, expectedValue);
                                                  
                                                  // Create a TypeAdapter implementation
                                                  TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                      @Override
                                                      public Object read(JsonReader in) throws IOException {
                                                          String name = in.nextString();
                                                          return testMap.get(name);
                                                      }
                                                      
                                                      @Override
                                                      public void write(JsonWriter out, Object value) {
                                                          throw new UnsupportedOperationException();
                                                      }
                                                  };
                                                  
                                                  // Act
                                                  Object result = adapter.read(in);
                                                  
                                                  // Assert
                                                  assertNotNull("Method should not return null for non-null string input", result);
                                                  assertEquals("Should return value from nameToConstant map", expectedValue, result);
                                                  verify(in).peek();
                                                  verify(in).nextString();
                                              }

    @Test
                                         public void testReadReturnsCorrectNumberWithoutAppendingZero2() throws IOException {
                                             // Setup
                                             JsonReader in = mock(JsonReader.class);
                                             when(in.peek()).thenReturn(JsonToken.STRING);
                                             when(in.nextString()).thenReturn("123");
                                             
                                             // Create a TypeAdapter instance
                                             TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                                 @Override
                                                 public Object read(JsonReader in) throws IOException {
                                                     if (in.peek() == JsonToken.NULL) {
                                                         in.nextNull();
                                                         return null;
                                                     }
                                                     return new LazilyParsedNumber(in.nextString());
                                                 }
                                                 
                                                 @Override
                                                 public void write(JsonWriter out, Object value) {
                                                     // Not needed for this test
                                                 }
                                             };
                                             
                                             // Execute
                                             Number result = (Number) adapter.read(in);
                                             
                                             // Verify
                                             assertEquals(123, result.intValue());
                                             verify(in).peek();
                                             verify(in).nextString();
                                         }

    @Test
                                public void testRead_InvalidToken_ThrowsExceptionWithDetailedMessage1() throws Exception {
                                    // Arrange
                                    JsonReader mockReader = mock(JsonReader.class);
                                    when(mockReader.peek()).thenReturn(JsonToken.NUMBER); // Unexpected token type
                                    when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected string"));
                                    
                                    // Create a proper String adapter using TypeAdapters factory
                                    TypeAdapter<String> adapter = TypeAdapters.newFactory(String.class, 
                                        new TypeAdapter<String>() {
                                            @Override
                                            public void write(JsonWriter out, String value) {
                                                throw new UnsupportedOperationException();
                                            }
                                            @Override
                                            public String read(JsonReader in) throws IOException {
                                                return in.nextString();
                                            }
                                        }).create(null, TypeToken.get(String.class));
                                    
                                    // Expect exception with specific message
                                    thrown.expect(JsonSyntaxException.class);
                                    thrown.expectMessage("Expecting string, got: NUMBER");
                                    
                                    // Act
                                    adapter.read(mockReader);
                                }

    @Test
                           public void testReadWithNumberTokenShouldThrowException() throws Exception {
                               // Create mock objects
                               JsonReader mockReader = mock(JsonReader.class);
                               TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                   @Override
                                   public Object read(JsonReader in) throws IOException {
                                       if (in.peek() == JsonToken.NUMBER) {
                                           throw new JsonSyntaxException("Expecting number, got: NUMBER");
                                       }
                                       return null;
                                   }
                           
                                   @Override
                                   public void write(JsonWriter out, Object value) throws IOException {
                                       // Not needed for this test
                                   }
                               };
                               
                               // Setup exception handling
                               ExpectedException thrown = ExpectedException.none();
                               
                               // Setup mock to return NUMBER token
                               when(mockReader.peek()).thenReturn(JsonToken.NUMBER);
                               
                               // Expect exception for original behavior
                               thrown.expect(JsonSyntaxException.class);
                               thrown.expectMessage("Expecting number, got: NUMBER");
                               
                               adapter.read(mockReader);
                               
                               // Verify interaction
                               verify(mockReader).peek();
                               verify(mockReader, never()).nextNull();
                               verify(mockReader, never()).nextString();
                           }

    @Test
                           public void testReadWithBooleanTokenShouldThrowException() throws Exception {
                               // Create mock JsonReader
                               JsonReader mockReader = mock(JsonReader.class);
                               
                               // Create the adapter instance (assuming it's a TypeAdapter)
                               TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
                                   @Override
                                   public Object read(JsonReader in) throws IOException {
                                       JsonToken token = in.peek();
                                       if (token != JsonToken.NUMBER) {
                                           throw new JsonSyntaxException("Expecting number, got: " + token);
                                       }
                                       return null;
                                   }
                           
                                   @Override
                                   public void write(JsonWriter out, Object value) throws IOException {
                                       // Not needed for this test
                                   }
                               };
                               
                               // Setup mock to return BOOLEAN token
                               when(mockReader.peek()).thenReturn(JsonToken.BOOLEAN);
                               
                               // Setup exception rule
                               ExpectedException thrown = ExpectedException.none();
                               thrown.expect(JsonSyntaxException.class);
                               thrown.expectMessage("Expecting number, got: BOOLEAN");
                               
                               adapter.read(mockReader);
                               
                               // Verify interaction
                               verify(mockReader).peek();
                               verify(mockReader, never()).nextNull();
                               verify(mockReader, never()).nextString();
                           }

    @Test(expected = JsonSyntaxException.class)
                      public void testRead_ShouldThrowExceptionForNonStringNonNullInput() throws IOException {
                          // Arrange
                          JsonReader mockReader = mock(JsonReader.class);
                          TypeAdapter<Object> typeAdapters = new TypeAdapter<Object>() {
                              @Override
                              public Object read(JsonReader in) throws IOException {
                                  if (in.peek() != JsonToken.STRING) {
                                      throw new JsonSyntaxException("Expected string");
                                  }
                                  return in.nextString();
                              }
                      
                              @Override
                              public void write(JsonWriter out, Object value) {
                                  throw new UnsupportedOperationException();
                              }
                          };
                          
                          when(mockReader.peek()).thenReturn(JsonToken.NUMBER); // Invalid token type
                          when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected string"));
                          
                          // Act
                          typeAdapters.read(mockReader);
                          
                          // Assert - should throw JsonSyntaxException via the @Test(expected)
                      }

    @Test
                      public void testRead_ShouldNotReturnNumberForInvalidInput() throws IOException {
                          // Arrange
                          JsonReader mockReader = mock(JsonReader.class);
                          TypeAdapter<Object> typeAdapters = new TypeAdapter<Object>() {
                              @Override
                              public Object read(JsonReader in) throws IOException {
                                  return null; // Mock implementation
                              }
                      
                              @Override
                              public void write(JsonWriter out, Object value) throws IOException {
                                  // Mock implementation
                              }
                          };
                          
                          when(mockReader.peek()).thenReturn(JsonToken.NUMBER); // Invalid token type
                          when(mockReader.nextString()).thenThrow(new IllegalStateException("Expected string"));
                          
                          try {
                              // Act
                              Object result = typeAdapters.read(mockReader);
                              
                              // If we get here, mutant is present - verify it's not a Number
                              assertFalse("Method should not return Number for invalid input", 
                                         result instanceof LazilyParsedNumber);
                              if (result != null) {
                                  assertFalse("Method should not return Number for invalid input", 
                                             result instanceof Number);
                              }
                          } catch (JsonSyntaxException expected) {
                              // Original behavior - test passes
                          }
                      }

    @Test
                 public void testReadWithNullToken2() throws IOException {
                     // Arrange
                     JsonReader in = mock(JsonReader.class);
                     when(in.peek()).thenReturn(JsonToken.NULL);
                     
                     // Create a concrete TypeAdapter instance for testing
                     TypeAdapter<String> adapter = new TypeAdapter<String>() {
                         @Override
                         public String read(JsonReader in) throws IOException {
                             if (in.peek() == JsonToken.NULL) {
                                 in.nextNull();
                                 return null;
                             }
                             return in.nextString();
                         }
                 
                         @Override
                         public void write(JsonWriter out, String value) throws IOException {
                             out.value(value);
                         }
                     };
                     
                     // Act
                     String result = adapter.read(in);
                     
                     // Assert
                     assertNull("Should return null for NULL token", result);
                     verify(in).nextNull();
                 }

    @Test
    public void testRead_ReturnsExactStringValue_NotLowercase() throws IOException {
        // Arrange
        JsonReader readerMock = mock(JsonReader.class);
        when(readerMock.peek()).thenReturn(JsonToken.STRING);
        String testString = "123ABC";
        when(readerMock.nextString()).thenReturn(testString);
        
        // Create a TypeAdapter that returns LazilyParsedNumber
        TypeAdapter<Object> adapter = new TypeAdapter<Object>() {
            @Override
            public Object read(JsonReader in) throws IOException {
                return new LazilyParsedNumber(in.nextString());
            }
            
            @Override
            public void write(JsonWriter out, Object value) {
                throw new UnsupportedOperationException();
            }
        };
        
        // Act
        Object result = adapter.read(readerMock);
        
        // Assert
        assertNotNull(result);
        assertTrue(result instanceof LazilyParsedNumber);
        // The critical assertion - verify the string wasn't lowercased
        assertEquals(testString, result.toString());
    }


}
